// function apiCall(path, data){
//   jQuery.post(path, data, function(res){
//     // console.log(res);
//     var jPostRes = JSON.parse(res);
//     console.log(jPostRes);
//   });
// }
//
// var elBody = document.querySelector('body');
//
// if(elBody.classList.contains('single-tour_post_type')) {
//   var post = document.querySelector('article');
//   var postId = post.getAttribute('data-tourid');
//   var postData = {"data": postId};
//   // console.dir(postId);
//   apiCall(rootUrl+'wp-content/themes/foundationPressGit/library/api/call-by-id.php', postData);
// }

// function sendCardId(){
//   // console.log('x');
//   document.addEventListener('click', function(e){
//     // console.log(e.target);
//     if(e.target.classList.contains('btnCard')) {
//       var sGetTourId = e.target.getAttribute('data-tripid');
//       var jSendTourID = {"data":sGetTourId};
//       apiCall(rootUrl+'wp-content/themes/foundationPressGit/library/api/call-by-id.php', jSendTourID);
//       // console.log(getTourId);
//     }
//   });
// }
//
// sendCardId();
