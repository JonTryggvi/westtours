<?php
/*
Template Name: westtours front php
*/
get_header(); ?>

<?php
  $nutrition_image = get_field('hero-img');
  $img = $nutrition_image['sizes']['hero-img-sizer'];
  $alt = $nutrition_image['alt'];
?>
<div class="hero-bannerinn" style="background-image:url('<?php echo $img; ?>')">
<?php get_template_part('template-parts/main-filter'); ?>
</div>
<div id="page-full-width" role="main">

<?php do_action( 'foundationpress_before_content' ); ?>
<?php
  $args = array( 'post_type' => 'tour_post_type' );
  $query = new WP_Query( $args );
  $tripId = get_field('bokun_id');
  // var_dump(count($isPopular));
?>
  <section class="front-bigCards-container hide-for-small-only">
    <h1>Our most popular hiking tours</h1>
      <div id="big-cards" class="big-cards navCards">
        <?php
          $postCount = 0;
          if ($query->have_posts()): while ( $query->have_posts() ) : $query->the_post();
          $isPopular = get_field('is_popular');
          $bokunImg = get_field('bokun_img');
          $activety = get_field('activety');


          if($activety[0] == 'animal life'){
            $sActivety = 'animal-life';
          }else{
            $sActivety = $activety[0];
          }
          $season = get_field('season');
          $excerpt = get_the_excerpt();
          $excerpt = substr( $excerpt , 0, 180);
          $cardImg = get_field('info_img');
          $img = $cardImg['sizes']['info-img-sizer'];
          if ($isPopular != null)  :
          $postCount++;
          if($postCount <= 2):
        ?>
        <div class="card-large navCard" role="article" data-tripid="<?php echo $tripId ?>">
          <a href="<?php the_permalink(); ?>">
            <?php if(!$cardImg): ?>
            <div class="image" style="background-image:url('<?php echo $bokunImg; ?>');"></div>
            <?php else: ?>
            <div class="image" style="background-image:url('<?php echo $img; ?>');"></div>
            <?php endif; ?>
            <div class="icon" style="background-image:url(<?php echo get_template_directory_uri().'/assets/images/icons/catIcons/'.$sActivety.'.svg'; ?>);"></div>
            <p class="cat-string"> <?php echo $activety; ?> / <?php echo $season; ?> </p>
            <header class="card-content article-header">
              <h2 class="entry-title single-title" itemprop="headline"><?php the_title(); ?></h2>
              <p><?php echo $excerpt . ' ...'; ?></p>
            </header>
            <button type="button" class="readMoreBtn">Read more</button>
          </a>
        </div>
      <?php endif; endif; endwhile; endif; ?>
    </div>
  </section>

  <section class="front-smallCards-container">
    <h1>Interesting activeties</h1>
    <div id="cards" class="cards owl-carousel owl-theme">
      <?php # echo do_shortcode('[ajax_load_more id="smallCardId" posts_per_page="4" container_type="div" post_type="tour_post_type" scroll_container="#cards" button_label="Show more trips" button_loading_label="Hang on!"]'); ?>
      <?php
        $args2 = array( 'post_type' => 'tour_post_type' );
        $query_smallCards = new WP_Query( $args2 );

        if ($query_smallCards->have_posts()): while ( $query_smallCards->have_posts() ) : $query_smallCards->the_post();
        $tripId = get_field('bokun_id');
        $isPopular = get_field('is_popular');

        $bokunImg = get_field('bokun_img');

        $activety_small = get_field('activety');
        if($activety_small[0]=='WALKING_TOUR' || $activety_small[0]=='HIKING' ){
          $mainActivety = 'hiking';
          $mainActivetyIcon = $mainActivety;
        } else if ($activety_small[0]=='SAILING_OR_BOAT_TOUR' || $activety_small[0]== 'DOLPHIN_OR_WHALEWATCHING') {
          $mainActivety = 'sailing';
          $mainActivetyIcon = $mainActivety;
        } else if ($activety_small[0]=='SAFARI_AND_WILDLIFE' || $activety_small[0]== 'BIRD_WATCHING') {
          $mainActivety = 'animal life';
          $mainActivetyIcon = 'animal-life';
        }else if ($activety_small[0]=='BIKE_TOUR' ) {
          $mainActivety = 'cycling';
          $mainActivetyIcon = $mainActivety;
        }


        // var_dump($mainActivety);
        $season = get_field('season');
        if($mainActivety == 'animal life'){
          $mainActivety = 'animal-life';
        }else{
          $mainActivety = $mainActivety;
        }
         if ($isPopular == null) :
          // var_dump($activety_small);

          $title = get_the_title();
          // var_dump(strlen($title));
          if(strlen($title) > 19){
            $smallerH2 = 'smallerH2';
          }
          else {
            $smallerH2 = '';
          }
          $excerpt_small = get_the_excerpt();
          $excerpt_small = substr( $excerpt_small , 0, 50);
          $cardImg = get_field('info_img');

      ?>
        <div class="small-12 medium-6 large-4 xlarge-3 card-container">
          <div class="card" role="article" >
            <a href="<?php the_permalink(); ?>">
              <?php if(!$cardImg): ?>
              <div class="image" style="background-image:url('<?php echo $bokunImg; ?>');"></div>
              <?php else: ?>
              <div class="image" style="background-image:url('<?php echo $img; ?>');"></div>
              <?php endif; ?>
              <div class="icon icon-<?php echo $mainActivety; ?>" style="background-image:url(<?php echo get_template_directory_uri().'/assets/images/icons/catIcons/'.$mainActivetyIcon.'.svg'; ?>);" ></div>
              <p class="cat-string"> <?php echo str_replace('_', ' ',$mainActivety); ?> / <?php echo $season; ?> </p>
              <header class="card-content article-header">
                <h2 class="entry-title single-title <?php echo $smallerH2; ?>" itemprop="headline"><?php echo $title; ?></h2>
                <p><?php echo $excerpt_small.' ...'; ?></p>
              </header>
              <button href="<?php the_permalink(); ?>" type="button" class="bookBtn btnCard" data-tripid="<?php echo $tripId ?>">Book</button>
            </a>
          </div>
        </div>
      <?php endif; endwhile; endif; wp_reset_query(); ?>
    </div>
    <button id="btnShowMore" type="button" class="show-more" name="button">Show more trips</button>
  </section>

  </article>

<?php do_action( 'foundationpress_after_content' ); ?>

</div>

 <!-- information chapters -->
<section class="fw chapter-parent">
<?php $loop = new WP_Query( array( 'post_type' => 'info_post_type', 'posts_per_page' => 2, 'orderby' => 'rand' ) ); $count =0; $color; ?>
<?php while ( $loop->have_posts() ) : $loop->the_post();
$nutrition_image = get_field('info-img');
$img_info = $nutrition_image['sizes']['info-img-sizer'];
$alt = $nutrition_image['alt']; $count++;
 if($count == 1){$color = 'red';}else{$color='blue';}
$excerpt = get_field('excerpt');

if(strlen($excerpt) > 200) {
  $excerptShort = substr($excerpt,0,200);
} else {
  $excerptShort = $excerpt;
}

 ?>

  <div class="row align-center small-12 medium-12 large-6 chapter-<?php echo $color; ?>">
    <div class="small-10 small-offset-1">
      <h2><?php the_title(); ?></h2>
      <p>
        <?php echo $excerptShort . ' ...'; ?>
      </p>
    </div>
    <a class="chapter-<?php echo $color; ?>-btn" href="<?php echo get_permalink(); ?>">Read More</a>
  </div>

  <div class="small-12 medium-12 large-6 chapter-<?php echo $color; ?>-img" style="background-image:url(<?php echo $img_info ?>);">

  </div>


<?php endwhile; wp_reset_query(); ?>
</section>
<?php get_template_part('template-parts/emaillist'); ?>
<?php get_footer();
