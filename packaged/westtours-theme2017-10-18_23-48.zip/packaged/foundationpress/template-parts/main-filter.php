<div class="filter-container">
  <div id="activety-autocompleat" class="activities-container medium-5">
    <label for="activities-search">Activety</label>
    <button class="filterbutton show-for-small-only" type="button" name="button">What do you like?</button>
     <select id="activities-search" class="search-field chosen-select hide-for-small-only" type="search-field" name="" value="" placeholder="What do you like?"><option value="">What do you like?</option></select>
  </div>
  <div class="when-container medium-3 hide-for-small-only">
    <label for="when">When</label>
    <input type="text" id="from" placeholder="Pick a date">
      <input type="text" class="" id="to" placeholder="Pick a date">
  </div>
  <!-- <div class="party-container medium- hide-for-small-only">
    <label for="counter">Participants</label>
    <span id="counter">How many</span>
  </div> -->
  <div class="button-container medium-3 hide-for-small-only">
    <button class="btn" type="button" name="button">Show me</button>
  </div>

</div>
