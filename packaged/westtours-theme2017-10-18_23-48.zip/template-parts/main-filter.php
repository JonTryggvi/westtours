<nav id="navActivety" class="navActivety">
  <div class="top">
    <button id="closeActivetyNav" type="button" name="button"><span></span><span></span></button>
    <img src="<?php echo get_template_directory_uri().'/assets/images/icons/logo-single.svg'?>" alt="">
    <div class="flexfix" aria-hidden> </div>
  </div>
  <form class="frmNavActivety">
    <label class="lblMobileActivety" for="mobileActivety">
      Activety
      <input type="text" name="mobileActivety" value="" placeholder="What do you like?">
    </label>
    <label for="mobileWhen">
      When
      <input type="text" name="mobileWhen" value="" placeholder="Pick a date">
    </label>
    <label for="mobileMany">
      How many
      <input type="text" name="mobileMany" value="" placeholder="How many?">
    </label>
    <button type="button" name="button">Show me</button>
  </form>
</nav>
<form class="filter-container">
  <input id="widget_id" type="hidden" name="" value="">
  <div id="activety-autocompleat" class="activities-container medium-5">
    <label for="activities-search">Activety</label>
    <button class="filterbutton show-for-small-only" type="button" name="button">What do you like?</button>
     <input id="activitiesSearch" class="search-field hide-for-small-only" type="search-field" name="" value="" placeholder="What do you like?">
     <div id="sResultsDropdown" class="search-field__results">

     </div>
  </div>
  <div class="when-container medium-3 hide-for-small-only">
    <label for="when">When</label>
    <input type="text" id="from" class="pickTime" placeholder="Pick a date">
    <input type="text" class="pickTime" id="to" placeholder="Pick a date">
  </div>
  <div class="party-container medium- hide-for-small-only">
    <label for="counter">Participants</label>
    <span id="counter">How many</span>
  </div>
  <div class="button-container medium-3 hide-for-small-only">
    <button class="btn" type="button" name="button">Show me</button>
  </div>

</form>
