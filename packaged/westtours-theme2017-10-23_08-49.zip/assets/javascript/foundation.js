'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

!function ($) {

  "use strict";

  var FOUNDATION_VERSION = '6.3.0';

  // Global Foundation object
  // This is attached to the window, or used as a module for AMD/Browserify
  var Foundation = {
    version: FOUNDATION_VERSION,

    /**
     * Stores initialized plugins.
     */
    _plugins: {},

    /**
     * Stores generated unique ids for plugin instances
     */
    _uuids: [],

    /**
     * Returns a boolean for RTL support
     */
    rtl: function rtl() {
      return $('html').attr('dir') === 'rtl';
    },
    /**
     * Defines a Foundation plugin, adding it to the `Foundation` namespace and the list of plugins to initialize when reflowing.
     * @param {Object} plugin - The constructor of the plugin.
     */
    plugin: function plugin(_plugin, name) {
      // Object key to use when adding to global Foundation object
      // Examples: Foundation.Reveal, Foundation.OffCanvas
      var className = name || functionName(_plugin);
      // Object key to use when storing the plugin, also used to create the identifying data attribute for the plugin
      // Examples: data-reveal, data-off-canvas
      var attrName = hyphenate(className);

      // Add to the Foundation object and the plugins list (for reflowing)
      this._plugins[attrName] = this[className] = _plugin;
    },
    /**
     * @function
     * Populates the _uuids array with pointers to each individual plugin instance.
     * Adds the `zfPlugin` data-attribute to programmatically created plugins to allow use of $(selector).foundation(method) calls.
     * Also fires the initialization event for each plugin, consolidating repetitive code.
     * @param {Object} plugin - an instance of a plugin, usually `this` in context.
     * @param {String} name - the name of the plugin, passed as a camelCased string.
     * @fires Plugin#init
     */
    registerPlugin: function registerPlugin(plugin, name) {
      var pluginName = name ? hyphenate(name) : functionName(plugin.constructor).toLowerCase();
      plugin.uuid = this.GetYoDigits(6, pluginName);

      if (!plugin.$element.attr('data-' + pluginName)) {
        plugin.$element.attr('data-' + pluginName, plugin.uuid);
      }
      if (!plugin.$element.data('zfPlugin')) {
        plugin.$element.data('zfPlugin', plugin);
      }
      /**
       * Fires when the plugin has initialized.
       * @event Plugin#init
       */
      plugin.$element.trigger('init.zf.' + pluginName);

      this._uuids.push(plugin.uuid);

      return;
    },
    /**
     * @function
     * Removes the plugins uuid from the _uuids array.
     * Removes the zfPlugin data attribute, as well as the data-plugin-name attribute.
     * Also fires the destroyed event for the plugin, consolidating repetitive code.
     * @param {Object} plugin - an instance of a plugin, usually `this` in context.
     * @fires Plugin#destroyed
     */
    unregisterPlugin: function unregisterPlugin(plugin) {
      var pluginName = hyphenate(functionName(plugin.$element.data('zfPlugin').constructor));

      this._uuids.splice(this._uuids.indexOf(plugin.uuid), 1);
      plugin.$element.removeAttr('data-' + pluginName).removeData('zfPlugin')
      /**
       * Fires when the plugin has been destroyed.
       * @event Plugin#destroyed
       */
      .trigger('destroyed.zf.' + pluginName);
      for (var prop in plugin) {
        plugin[prop] = null; //clean up script to prep for garbage collection.
      }
      return;
    },

    /**
     * @function
     * Causes one or more active plugins to re-initialize, resetting event listeners, recalculating positions, etc.
     * @param {String} plugins - optional string of an individual plugin key, attained by calling `$(element).data('pluginName')`, or string of a plugin class i.e. `'dropdown'`
     * @default If no argument is passed, reflow all currently active plugins.
     */
    reInit: function reInit(plugins) {
      var isJQ = plugins instanceof $;
      try {
        if (isJQ) {
          plugins.each(function () {
            $(this).data('zfPlugin')._init();
          });
        } else {
          var type = typeof plugins === 'undefined' ? 'undefined' : _typeof(plugins),
              _this = this,
              fns = {
            'object': function object(plgs) {
              plgs.forEach(function (p) {
                p = hyphenate(p);
                $('[data-' + p + ']').foundation('_init');
              });
            },
            'string': function string() {
              plugins = hyphenate(plugins);
              $('[data-' + plugins + ']').foundation('_init');
            },
            'undefined': function undefined() {
              this['object'](Object.keys(_this._plugins));
            }
          };
          fns[type](plugins);
        }
      } catch (err) {
        console.error(err);
      } finally {
        return plugins;
      }
    },

    /**
     * returns a random base-36 uid with namespacing
     * @function
     * @param {Number} length - number of random base-36 digits desired. Increase for more random strings.
     * @param {String} namespace - name of plugin to be incorporated in uid, optional.
     * @default {String} '' - if no plugin name is provided, nothing is appended to the uid.
     * @returns {String} - unique id
     */
    GetYoDigits: function GetYoDigits(length, namespace) {
      length = length || 6;
      return Math.round(Math.pow(36, length + 1) - Math.random() * Math.pow(36, length)).toString(36).slice(1) + (namespace ? '-' + namespace : '');
    },
    /**
     * Initialize plugins on any elements within `elem` (and `elem` itself) that aren't already initialized.
     * @param {Object} elem - jQuery object containing the element to check inside. Also checks the element itself, unless it's the `document` object.
     * @param {String|Array} plugins - A list of plugins to initialize. Leave this out to initialize everything.
     */
    reflow: function reflow(elem, plugins) {

      // If plugins is undefined, just grab everything
      if (typeof plugins === 'undefined') {
        plugins = Object.keys(this._plugins);
      }
      // If plugins is a string, convert it to an array with one item
      else if (typeof plugins === 'string') {
          plugins = [plugins];
        }

      var _this = this;

      // Iterate through each plugin
      $.each(plugins, function (i, name) {
        // Get the current plugin
        var plugin = _this._plugins[name];

        // Localize the search to all elements inside elem, as well as elem itself, unless elem === document
        var $elem = $(elem).find('[data-' + name + ']').addBack('[data-' + name + ']');

        // For each plugin found, initialize it
        $elem.each(function () {
          var $el = $(this),
              opts = {};
          // Don't double-dip on plugins
          if ($el.data('zfPlugin')) {
            console.warn("Tried to initialize " + name + " on an element that already has a Foundation plugin.");
            return;
          }

          if ($el.attr('data-options')) {
            var thing = $el.attr('data-options').split(';').forEach(function (e, i) {
              var opt = e.split(':').map(function (el) {
                return el.trim();
              });
              if (opt[0]) opts[opt[0]] = parseValue(opt[1]);
            });
          }
          try {
            $el.data('zfPlugin', new plugin($(this), opts));
          } catch (er) {
            console.error(er);
          } finally {
            return;
          }
        });
      });
    },
    getFnName: functionName,
    transitionend: function transitionend($elem) {
      var transitions = {
        'transition': 'transitionend',
        'WebkitTransition': 'webkitTransitionEnd',
        'MozTransition': 'transitionend',
        'OTransition': 'otransitionend'
      };
      var elem = document.createElement('div'),
          end;

      for (var t in transitions) {
        if (typeof elem.style[t] !== 'undefined') {
          end = transitions[t];
        }
      }
      if (end) {
        return end;
      } else {
        end = setTimeout(function () {
          $elem.triggerHandler('transitionend', [$elem]);
        }, 1);
        return 'transitionend';
      }
    }
  };

  Foundation.util = {
    /**
     * Function for applying a debounce effect to a function call.
     * @function
     * @param {Function} func - Function to be called at end of timeout.
     * @param {Number} delay - Time in ms to delay the call of `func`.
     * @returns function
     */
    throttle: function throttle(func, delay) {
      var timer = null;

      return function () {
        var context = this,
            args = arguments;

        if (timer === null) {
          timer = setTimeout(function () {
            func.apply(context, args);
            timer = null;
          }, delay);
        }
      };
    }
  };

  // TODO: consider not making this a jQuery function
  // TODO: need way to reflow vs. re-initialize
  /**
   * The Foundation jQuery method.
   * @param {String|Array} method - An action to perform on the current jQuery object.
   */
  var foundation = function foundation(method) {
    var type = typeof method === 'undefined' ? 'undefined' : _typeof(method),
        $meta = $('meta.foundation-mq'),
        $noJS = $('.no-js');

    if (!$meta.length) {
      $('<meta class="foundation-mq">').appendTo(document.head);
    }
    if ($noJS.length) {
      $noJS.removeClass('no-js');
    }

    if (type === 'undefined') {
      //needs to initialize the Foundation object, or an individual plugin.
      Foundation.MediaQuery._init();
      Foundation.reflow(this);
    } else if (type === 'string') {
      //an individual method to invoke on a plugin or group of plugins
      var args = Array.prototype.slice.call(arguments, 1); //collect all the arguments, if necessary
      var plugClass = this.data('zfPlugin'); //determine the class of plugin

      if (plugClass !== undefined && plugClass[method] !== undefined) {
        //make sure both the class and method exist
        if (this.length === 1) {
          //if there's only one, call it directly.
          plugClass[method].apply(plugClass, args);
        } else {
          this.each(function (i, el) {
            //otherwise loop through the jQuery collection and invoke the method on each
            plugClass[method].apply($(el).data('zfPlugin'), args);
          });
        }
      } else {
        //error for no class or no method
        throw new ReferenceError("We're sorry, '" + method + "' is not an available method for " + (plugClass ? functionName(plugClass) : 'this element') + '.');
      }
    } else {
      //error for invalid argument type
      throw new TypeError('We\'re sorry, ' + type + ' is not a valid parameter. You must use a string representing the method you wish to invoke.');
    }
    return this;
  };

  window.Foundation = Foundation;
  $.fn.foundation = foundation;

  // Polyfill for requestAnimationFrame
  (function () {
    if (!Date.now || !window.Date.now) window.Date.now = Date.now = function () {
      return new Date().getTime();
    };

    var vendors = ['webkit', 'moz'];
    for (var i = 0; i < vendors.length && !window.requestAnimationFrame; ++i) {
      var vp = vendors[i];
      window.requestAnimationFrame = window[vp + 'RequestAnimationFrame'];
      window.cancelAnimationFrame = window[vp + 'CancelAnimationFrame'] || window[vp + 'CancelRequestAnimationFrame'];
    }
    if (/iP(ad|hone|od).*OS 6/.test(window.navigator.userAgent) || !window.requestAnimationFrame || !window.cancelAnimationFrame) {
      var lastTime = 0;
      window.requestAnimationFrame = function (callback) {
        var now = Date.now();
        var nextTime = Math.max(lastTime + 16, now);
        return setTimeout(function () {
          callback(lastTime = nextTime);
        }, nextTime - now);
      };
      window.cancelAnimationFrame = clearTimeout;
    }
    /**
     * Polyfill for performance.now, required by rAF
     */
    if (!window.performance || !window.performance.now) {
      window.performance = {
        start: Date.now(),
        now: function now() {
          return Date.now() - this.start;
        }
      };
    }
  })();
  if (!Function.prototype.bind) {
    Function.prototype.bind = function (oThis) {
      if (typeof this !== 'function') {
        // closest thing possible to the ECMAScript 5
        // internal IsCallable function
        throw new TypeError('Function.prototype.bind - what is trying to be bound is not callable');
      }

      var aArgs = Array.prototype.slice.call(arguments, 1),
          fToBind = this,
          fNOP = function fNOP() {},
          fBound = function fBound() {
        return fToBind.apply(this instanceof fNOP ? this : oThis, aArgs.concat(Array.prototype.slice.call(arguments)));
      };

      if (this.prototype) {
        // native functions don't have a prototype
        fNOP.prototype = this.prototype;
      }
      fBound.prototype = new fNOP();

      return fBound;
    };
  }
  // Polyfill to get the name of a function in IE9
  function functionName(fn) {
    if (Function.prototype.name === undefined) {
      var funcNameRegex = /function\s([^(]{1,})\(/;
      var results = funcNameRegex.exec(fn.toString());
      return results && results.length > 1 ? results[1].trim() : "";
    } else if (fn.prototype === undefined) {
      return fn.constructor.name;
    } else {
      return fn.prototype.constructor.name;
    }
  }
  function parseValue(str) {
    if ('true' === str) return true;else if ('false' === str) return false;else if (!isNaN(str * 1)) return parseFloat(str);
    return str;
  }
  // Convert PascalCase to kebab-case
  // Thank you: http://stackoverflow.com/a/8955580
  function hyphenate(str) {
    return str.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
  }
}(jQuery);
;'use strict';

!function ($) {

  Foundation.Box = {
    ImNotTouchingYou: ImNotTouchingYou,
    GetDimensions: GetDimensions,
    GetOffsets: GetOffsets

    /**
     * Compares the dimensions of an element to a container and determines collision events with container.
     * @function
     * @param {jQuery} element - jQuery object to test for collisions.
     * @param {jQuery} parent - jQuery object to use as bounding container.
     * @param {Boolean} lrOnly - set to true to check left and right values only.
     * @param {Boolean} tbOnly - set to true to check top and bottom values only.
     * @default if no parent object passed, detects collisions with `window`.
     * @returns {Boolean} - true if collision free, false if a collision in any direction.
     */
  };function ImNotTouchingYou(element, parent, lrOnly, tbOnly) {
    var eleDims = GetDimensions(element),
        top,
        bottom,
        left,
        right;

    if (parent) {
      var parDims = GetDimensions(parent);

      bottom = eleDims.offset.top + eleDims.height <= parDims.height + parDims.offset.top;
      top = eleDims.offset.top >= parDims.offset.top;
      left = eleDims.offset.left >= parDims.offset.left;
      right = eleDims.offset.left + eleDims.width <= parDims.width + parDims.offset.left;
    } else {
      bottom = eleDims.offset.top + eleDims.height <= eleDims.windowDims.height + eleDims.windowDims.offset.top;
      top = eleDims.offset.top >= eleDims.windowDims.offset.top;
      left = eleDims.offset.left >= eleDims.windowDims.offset.left;
      right = eleDims.offset.left + eleDims.width <= eleDims.windowDims.width;
    }

    var allDirs = [bottom, top, left, right];

    if (lrOnly) {
      return left === right === true;
    }

    if (tbOnly) {
      return top === bottom === true;
    }

    return allDirs.indexOf(false) === -1;
  };

  /**
   * Uses native methods to return an object of dimension values.
   * @function
   * @param {jQuery || HTML} element - jQuery object or DOM element for which to get the dimensions. Can be any element other that document or window.
   * @returns {Object} - nested object of integer pixel values
   * TODO - if element is window, return only those values.
   */
  function GetDimensions(elem, test) {
    elem = elem.length ? elem[0] : elem;

    if (elem === window || elem === document) {
      throw new Error("I'm sorry, Dave. I'm afraid I can't do that.");
    }

    var rect = elem.getBoundingClientRect(),
        parRect = elem.parentNode.getBoundingClientRect(),
        winRect = document.body.getBoundingClientRect(),
        winY = window.pageYOffset,
        winX = window.pageXOffset;

    return {
      width: rect.width,
      height: rect.height,
      offset: {
        top: rect.top + winY,
        left: rect.left + winX
      },
      parentDims: {
        width: parRect.width,
        height: parRect.height,
        offset: {
          top: parRect.top + winY,
          left: parRect.left + winX
        }
      },
      windowDims: {
        width: winRect.width,
        height: winRect.height,
        offset: {
          top: winY,
          left: winX
        }
      }
    };
  }

  /**
   * Returns an object of top and left integer pixel values for dynamically rendered elements,
   * such as: Tooltip, Reveal, and Dropdown
   * @function
   * @param {jQuery} element - jQuery object for the element being positioned.
   * @param {jQuery} anchor - jQuery object for the element's anchor point.
   * @param {String} position - a string relating to the desired position of the element, relative to it's anchor
   * @param {Number} vOffset - integer pixel value of desired vertical separation between anchor and element.
   * @param {Number} hOffset - integer pixel value of desired horizontal separation between anchor and element.
   * @param {Boolean} isOverflow - if a collision event is detected, sets to true to default the element to full width - any desired offset.
   * TODO alter/rewrite to work with `em` values as well/instead of pixels
   */
  function GetOffsets(element, anchor, position, vOffset, hOffset, isOverflow) {
    var $eleDims = GetDimensions(element),
        $anchorDims = anchor ? GetDimensions(anchor) : null;

    switch (position) {
      case 'top':
        return {
          left: Foundation.rtl() ? $anchorDims.offset.left - $eleDims.width + $anchorDims.width : $anchorDims.offset.left,
          top: $anchorDims.offset.top - ($eleDims.height + vOffset)
        };
        break;
      case 'left':
        return {
          left: $anchorDims.offset.left - ($eleDims.width + hOffset),
          top: $anchorDims.offset.top
        };
        break;
      case 'right':
        return {
          left: $anchorDims.offset.left + $anchorDims.width + hOffset,
          top: $anchorDims.offset.top
        };
        break;
      case 'center top':
        return {
          left: $anchorDims.offset.left + $anchorDims.width / 2 - $eleDims.width / 2,
          top: $anchorDims.offset.top - ($eleDims.height + vOffset)
        };
        break;
      case 'center bottom':
        return {
          left: isOverflow ? hOffset : $anchorDims.offset.left + $anchorDims.width / 2 - $eleDims.width / 2,
          top: $anchorDims.offset.top + $anchorDims.height + vOffset
        };
        break;
      case 'center left':
        return {
          left: $anchorDims.offset.left - ($eleDims.width + hOffset),
          top: $anchorDims.offset.top + $anchorDims.height / 2 - $eleDims.height / 2
        };
        break;
      case 'center right':
        return {
          left: $anchorDims.offset.left + $anchorDims.width + hOffset + 1,
          top: $anchorDims.offset.top + $anchorDims.height / 2 - $eleDims.height / 2
        };
        break;
      case 'center':
        return {
          left: $eleDims.windowDims.offset.left + $eleDims.windowDims.width / 2 - $eleDims.width / 2,
          top: $eleDims.windowDims.offset.top + $eleDims.windowDims.height / 2 - $eleDims.height / 2
        };
        break;
      case 'reveal':
        return {
          left: ($eleDims.windowDims.width - $eleDims.width) / 2,
          top: $eleDims.windowDims.offset.top + vOffset
        };
      case 'reveal full':
        return {
          left: $eleDims.windowDims.offset.left,
          top: $eleDims.windowDims.offset.top
        };
        break;
      case 'left bottom':
        return {
          left: $anchorDims.offset.left,
          top: $anchorDims.offset.top + $anchorDims.height + vOffset
        };
        break;
      case 'right bottom':
        return {
          left: $anchorDims.offset.left + $anchorDims.width + hOffset - $eleDims.width,
          top: $anchorDims.offset.top + $anchorDims.height + vOffset
        };
        break;
      default:
        return {
          left: Foundation.rtl() ? $anchorDims.offset.left - $eleDims.width + $anchorDims.width : $anchorDims.offset.left + hOffset,
          top: $anchorDims.offset.top + $anchorDims.height + vOffset
        };
    }
  }
}(jQuery);
;/*******************************************
 *                                         *
 * This util was created by Marius Olbertz *
 * Please thank Marius on GitHub /owlbertz *
 * or the web http://www.mariusolbertz.de/ *
 *                                         *
 ******************************************/

'use strict';

!function ($) {

  var keyCodes = {
    9: 'TAB',
    13: 'ENTER',
    27: 'ESCAPE',
    32: 'SPACE',
    37: 'ARROW_LEFT',
    38: 'ARROW_UP',
    39: 'ARROW_RIGHT',
    40: 'ARROW_DOWN'
  };

  var commands = {};

  var Keyboard = {
    keys: getKeyCodes(keyCodes),

    /**
     * Parses the (keyboard) event and returns a String that represents its key
     * Can be used like Foundation.parseKey(event) === Foundation.keys.SPACE
     * @param {Event} event - the event generated by the event handler
     * @return String key - String that represents the key pressed
     */
    parseKey: function parseKey(event) {
      var key = keyCodes[event.which || event.keyCode] || String.fromCharCode(event.which).toUpperCase();

      // Remove un-printable characters, e.g. for `fromCharCode` calls for CTRL only events
      key = key.replace(/\W+/, '');

      if (event.shiftKey) key = 'SHIFT_' + key;
      if (event.ctrlKey) key = 'CTRL_' + key;
      if (event.altKey) key = 'ALT_' + key;

      // Remove trailing underscore, in case only modifiers were used (e.g. only `CTRL_ALT`)
      key = key.replace(/_$/, '');

      return key;
    },


    /**
     * Handles the given (keyboard) event
     * @param {Event} event - the event generated by the event handler
     * @param {String} component - Foundation component's name, e.g. Slider or Reveal
     * @param {Objects} functions - collection of functions that are to be executed
     */
    handleKey: function handleKey(event, component, functions) {
      var commandList = commands[component],
          keyCode = this.parseKey(event),
          cmds,
          command,
          fn;

      if (!commandList) return console.warn('Component not defined!');

      if (typeof commandList.ltr === 'undefined') {
        // this component does not differentiate between ltr and rtl
        cmds = commandList; // use plain list
      } else {
        // merge ltr and rtl: if document is rtl, rtl overwrites ltr and vice versa
        if (Foundation.rtl()) cmds = $.extend({}, commandList.ltr, commandList.rtl);else cmds = $.extend({}, commandList.rtl, commandList.ltr);
      }
      command = cmds[keyCode];

      fn = functions[command];
      if (fn && typeof fn === 'function') {
        // execute function  if exists
        var returnValue = fn.apply();
        if (functions.handled || typeof functions.handled === 'function') {
          // execute function when event was handled
          functions.handled(returnValue);
        }
      } else {
        if (functions.unhandled || typeof functions.unhandled === 'function') {
          // execute function when event was not handled
          functions.unhandled();
        }
      }
    },


    /**
     * Finds all focusable elements within the given `$element`
     * @param {jQuery} $element - jQuery object to search within
     * @return {jQuery} $focusable - all focusable elements within `$element`
     */
    findFocusable: function findFocusable($element) {
      if (!$element) {
        return false;
      }
      return $element.find('a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, *[tabindex], *[contenteditable]').filter(function () {
        if (!$(this).is(':visible') || $(this).attr('tabindex') < 0) {
          return false;
        } //only have visible elements and those that have a tabindex greater or equal 0
        return true;
      });
    },


    /**
     * Returns the component name name
     * @param {Object} component - Foundation component, e.g. Slider or Reveal
     * @return String componentName
     */

    register: function register(componentName, cmds) {
      commands[componentName] = cmds;
    },


    /**
     * Traps the focus in the given element.
     * @param  {jQuery} $element  jQuery object to trap the foucs into.
     */
    trapFocus: function trapFocus($element) {
      var $focusable = Foundation.Keyboard.findFocusable($element),
          $firstFocusable = $focusable.eq(0),
          $lastFocusable = $focusable.eq(-1);

      $element.on('keydown.zf.trapfocus', function (event) {
        if (event.target === $lastFocusable[0] && Foundation.Keyboard.parseKey(event) === 'TAB') {
          event.preventDefault();
          $firstFocusable.focus();
        } else if (event.target === $firstFocusable[0] && Foundation.Keyboard.parseKey(event) === 'SHIFT_TAB') {
          event.preventDefault();
          $lastFocusable.focus();
        }
      });
    },

    /**
     * Releases the trapped focus from the given element.
     * @param  {jQuery} $element  jQuery object to release the focus for.
     */
    releaseFocus: function releaseFocus($element) {
      $element.off('keydown.zf.trapfocus');
    }
  };

  /*
   * Constants for easier comparing.
   * Can be used like Foundation.parseKey(event) === Foundation.keys.SPACE
   */
  function getKeyCodes(kcs) {
    var k = {};
    for (var kc in kcs) {
      k[kcs[kc]] = kcs[kc];
    }return k;
  }

  Foundation.Keyboard = Keyboard;
}(jQuery);
;'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

!function ($) {

  // Default set of media queries
  var defaultQueries = {
    'default': 'only screen',
    landscape: 'only screen and (orientation: landscape)',
    portrait: 'only screen and (orientation: portrait)',
    retina: 'only screen and (-webkit-min-device-pixel-ratio: 2),' + 'only screen and (min--moz-device-pixel-ratio: 2),' + 'only screen and (-o-min-device-pixel-ratio: 2/1),' + 'only screen and (min-device-pixel-ratio: 2),' + 'only screen and (min-resolution: 192dpi),' + 'only screen and (min-resolution: 2dppx)'
  };

  var MediaQuery = {
    queries: [],

    current: '',

    /**
     * Initializes the media query helper, by extracting the breakpoint list from the CSS and activating the breakpoint watcher.
     * @function
     * @private
     */
    _init: function _init() {
      var self = this;
      var extractedStyles = $('.foundation-mq').css('font-family');
      var namedQueries;

      namedQueries = parseStyleToObject(extractedStyles);

      for (var key in namedQueries) {
        if (namedQueries.hasOwnProperty(key)) {
          self.queries.push({
            name: key,
            value: 'only screen and (min-width: ' + namedQueries[key] + ')'
          });
        }
      }

      this.current = this._getCurrentSize();

      this._watcher();
    },


    /**
     * Checks if the screen is at least as wide as a breakpoint.
     * @function
     * @param {String} size - Name of the breakpoint to check.
     * @returns {Boolean} `true` if the breakpoint matches, `false` if it's smaller.
     */
    atLeast: function atLeast(size) {
      var query = this.get(size);

      if (query) {
        return window.matchMedia(query).matches;
      }

      return false;
    },


    /**
     * Checks if the screen matches to a breakpoint.
     * @function
     * @param {String} size - Name of the breakpoint to check, either 'small only' or 'small'. Omitting 'only' falls back to using atLeast() method.
     * @returns {Boolean} `true` if the breakpoint matches, `false` if it does not.
     */
    is: function is(size) {
      size = size.trim().split(' ');
      if (size.length > 1 && size[1] === 'only') {
        if (size[0] === this._getCurrentSize()) return true;
      } else {
        return this.atLeast(size[0]);
      }
      return false;
    },


    /**
     * Gets the media query of a breakpoint.
     * @function
     * @param {String} size - Name of the breakpoint to get.
     * @returns {String|null} - The media query of the breakpoint, or `null` if the breakpoint doesn't exist.
     */
    get: function get(size) {
      for (var i in this.queries) {
        if (this.queries.hasOwnProperty(i)) {
          var query = this.queries[i];
          if (size === query.name) return query.value;
        }
      }

      return null;
    },


    /**
     * Gets the current breakpoint name by testing every breakpoint and returning the last one to match (the biggest one).
     * @function
     * @private
     * @returns {String} Name of the current breakpoint.
     */
    _getCurrentSize: function _getCurrentSize() {
      var matched;

      for (var i = 0; i < this.queries.length; i++) {
        var query = this.queries[i];

        if (window.matchMedia(query.value).matches) {
          matched = query;
        }
      }

      if ((typeof matched === 'undefined' ? 'undefined' : _typeof(matched)) === 'object') {
        return matched.name;
      } else {
        return matched;
      }
    },


    /**
     * Activates the breakpoint watcher, which fires an event on the window whenever the breakpoint changes.
     * @function
     * @private
     */
    _watcher: function _watcher() {
      var _this = this;

      $(window).on('resize.zf.mediaquery', function () {
        var newSize = _this._getCurrentSize(),
            currentSize = _this.current;

        if (newSize !== currentSize) {
          // Change the current media query
          _this.current = newSize;

          // Broadcast the media query change on the window
          $(window).trigger('changed.zf.mediaquery', [newSize, currentSize]);
        }
      });
    }
  };

  Foundation.MediaQuery = MediaQuery;

  // matchMedia() polyfill - Test a CSS media type/query in JS.
  // Authors & copyright (c) 2012: Scott Jehl, Paul Irish, Nicholas Zakas, David Knight. Dual MIT/BSD license
  window.matchMedia || (window.matchMedia = function () {
    'use strict';

    // For browsers that support matchMedium api such as IE 9 and webkit

    var styleMedia = window.styleMedia || window.media;

    // For those that don't support matchMedium
    if (!styleMedia) {
      var style = document.createElement('style'),
          script = document.getElementsByTagName('script')[0],
          info = null;

      style.type = 'text/css';
      style.id = 'matchmediajs-test';

      script && script.parentNode && script.parentNode.insertBefore(style, script);

      // 'style.currentStyle' is used by IE <= 8 and 'window.getComputedStyle' for all other browsers
      info = 'getComputedStyle' in window && window.getComputedStyle(style, null) || style.currentStyle;

      styleMedia = {
        matchMedium: function matchMedium(media) {
          var text = '@media ' + media + '{ #matchmediajs-test { width: 1px; } }';

          // 'style.styleSheet' is used by IE <= 8 and 'style.textContent' for all other browsers
          if (style.styleSheet) {
            style.styleSheet.cssText = text;
          } else {
            style.textContent = text;
          }

          // Test if media query is true or false
          return info.width === '1px';
        }
      };
    }

    return function (media) {
      return {
        matches: styleMedia.matchMedium(media || 'all'),
        media: media || 'all'
      };
    };
  }());

  // Thank you: https://github.com/sindresorhus/query-string
  function parseStyleToObject(str) {
    var styleObject = {};

    if (typeof str !== 'string') {
      return styleObject;
    }

    str = str.trim().slice(1, -1); // browsers re-quote string style values

    if (!str) {
      return styleObject;
    }

    styleObject = str.split('&').reduce(function (ret, param) {
      var parts = param.replace(/\+/g, ' ').split('=');
      var key = parts[0];
      var val = parts[1];
      key = decodeURIComponent(key);

      // missing `=` should be `null`:
      // http://w3.org/TR/2012/WD-url-20120524/#collect-url-parameters
      val = val === undefined ? null : decodeURIComponent(val);

      if (!ret.hasOwnProperty(key)) {
        ret[key] = val;
      } else if (Array.isArray(ret[key])) {
        ret[key].push(val);
      } else {
        ret[key] = [ret[key], val];
      }
      return ret;
    }, {});

    return styleObject;
  }

  Foundation.MediaQuery = MediaQuery;
}(jQuery);
;'use strict';

!function ($) {

  /**
   * Motion module.
   * @module foundation.motion
   */

  var initClasses = ['mui-enter', 'mui-leave'];
  var activeClasses = ['mui-enter-active', 'mui-leave-active'];

  var Motion = {
    animateIn: function animateIn(element, animation, cb) {
      animate(true, element, animation, cb);
    },

    animateOut: function animateOut(element, animation, cb) {
      animate(false, element, animation, cb);
    }
  };

  function Move(duration, elem, fn) {
    var anim,
        prog,
        start = null;
    // console.log('called');

    if (duration === 0) {
      fn.apply(elem);
      elem.trigger('finished.zf.animate', [elem]).triggerHandler('finished.zf.animate', [elem]);
      return;
    }

    function move(ts) {
      if (!start) start = ts;
      // console.log(start, ts);
      prog = ts - start;
      fn.apply(elem);

      if (prog < duration) {
        anim = window.requestAnimationFrame(move, elem);
      } else {
        window.cancelAnimationFrame(anim);
        elem.trigger('finished.zf.animate', [elem]).triggerHandler('finished.zf.animate', [elem]);
      }
    }
    anim = window.requestAnimationFrame(move);
  }

  /**
   * Animates an element in or out using a CSS transition class.
   * @function
   * @private
   * @param {Boolean} isIn - Defines if the animation is in or out.
   * @param {Object} element - jQuery or HTML object to animate.
   * @param {String} animation - CSS class to use.
   * @param {Function} cb - Callback to run when animation is finished.
   */
  function animate(isIn, element, animation, cb) {
    element = $(element).eq(0);

    if (!element.length) return;

    var initClass = isIn ? initClasses[0] : initClasses[1];
    var activeClass = isIn ? activeClasses[0] : activeClasses[1];

    // Set up the animation
    reset();

    element.addClass(animation).css('transition', 'none');

    requestAnimationFrame(function () {
      element.addClass(initClass);
      if (isIn) element.show();
    });

    // Start the animation
    requestAnimationFrame(function () {
      element[0].offsetWidth;
      element.css('transition', '').addClass(activeClass);
    });

    // Clean up the animation when it finishes
    element.one(Foundation.transitionend(element), finish);

    // Hides the element (for out animations), resets the element, and runs a callback
    function finish() {
      if (!isIn) element.hide();
      reset();
      if (cb) cb.apply(element);
    }

    // Resets transitions and removes motion-specific classes
    function reset() {
      element[0].style.transitionDuration = 0;
      element.removeClass(initClass + ' ' + activeClass + ' ' + animation);
    }
  }

  Foundation.Move = Move;
  Foundation.Motion = Motion;
}(jQuery);
;'use strict';

!function ($) {

  var Nest = {
    Feather: function Feather(menu) {
      var type = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'zf';

      menu.attr('role', 'menubar');

      var items = menu.find('li').attr({ 'role': 'menuitem' }),
          subMenuClass = 'is-' + type + '-submenu',
          subItemClass = subMenuClass + '-item',
          hasSubClass = 'is-' + type + '-submenu-parent';

      items.each(function () {
        var $item = $(this),
            $sub = $item.children('ul');

        if ($sub.length) {
          $item.addClass(hasSubClass).attr({
            'aria-haspopup': true,
            'aria-label': $item.children('a:first').text()
          });
          // Note:  Drilldowns behave differently in how they hide, and so need
          // additional attributes.  We should look if this possibly over-generalized
          // utility (Nest) is appropriate when we rework menus in 6.4
          if (type === 'drilldown') {
            $item.attr({ 'aria-expanded': false });
          }

          $sub.addClass('submenu ' + subMenuClass).attr({
            'data-submenu': '',
            'role': 'menu'
          });
          if (type === 'drilldown') {
            $sub.attr({ 'aria-hidden': true });
          }
        }

        if ($item.parent('[data-submenu]').length) {
          $item.addClass('is-submenu-item ' + subItemClass);
        }
      });

      return;
    },
    Burn: function Burn(menu, type) {
      var //items = menu.find('li'),
      subMenuClass = 'is-' + type + '-submenu',
          subItemClass = subMenuClass + '-item',
          hasSubClass = 'is-' + type + '-submenu-parent';

      menu.find('>li, .menu, .menu > li').removeClass(subMenuClass + ' ' + subItemClass + ' ' + hasSubClass + ' is-submenu-item submenu is-active').removeAttr('data-submenu').css('display', '');

      // console.log(      menu.find('.' + subMenuClass + ', .' + subItemClass + ', .has-submenu, .is-submenu-item, .submenu, [data-submenu]')
      //           .removeClass(subMenuClass + ' ' + subItemClass + ' has-submenu is-submenu-item submenu')
      //           .removeAttr('data-submenu'));
      // items.each(function(){
      //   var $item = $(this),
      //       $sub = $item.children('ul');
      //   if($item.parent('[data-submenu]').length){
      //     $item.removeClass('is-submenu-item ' + subItemClass);
      //   }
      //   if($sub.length){
      //     $item.removeClass('has-submenu');
      //     $sub.removeClass('submenu ' + subMenuClass).removeAttr('data-submenu');
      //   }
      // });
    }
  };

  Foundation.Nest = Nest;
}(jQuery);
;'use strict';

!function ($) {

  function Timer(elem, options, cb) {
    var _this = this,
        duration = options.duration,
        //options is an object for easily adding features later.
    nameSpace = Object.keys(elem.data())[0] || 'timer',
        remain = -1,
        start,
        timer;

    this.isPaused = false;

    this.restart = function () {
      remain = -1;
      clearTimeout(timer);
      this.start();
    };

    this.start = function () {
      this.isPaused = false;
      // if(!elem.data('paused')){ return false; }//maybe implement this sanity check if used for other things.
      clearTimeout(timer);
      remain = remain <= 0 ? duration : remain;
      elem.data('paused', false);
      start = Date.now();
      timer = setTimeout(function () {
        if (options.infinite) {
          _this.restart(); //rerun the timer.
        }
        if (cb && typeof cb === 'function') {
          cb();
        }
      }, remain);
      elem.trigger('timerstart.zf.' + nameSpace);
    };

    this.pause = function () {
      this.isPaused = true;
      //if(elem.data('paused')){ return false; }//maybe implement this sanity check if used for other things.
      clearTimeout(timer);
      elem.data('paused', true);
      var end = Date.now();
      remain = remain - (end - start);
      elem.trigger('timerpaused.zf.' + nameSpace);
    };
  }

  /**
   * Runs a callback function when images are fully loaded.
   * @param {Object} images - Image(s) to check if loaded.
   * @param {Func} callback - Function to execute when image is fully loaded.
   */
  function onImagesLoaded(images, callback) {
    var self = this,
        unloaded = images.length;

    if (unloaded === 0) {
      callback();
    }

    images.each(function () {
      // Check if image is loaded
      if (this.complete || this.readyState === 4 || this.readyState === 'complete') {
        singleImageLoaded();
      }
      // Force load the image
      else {
          // fix for IE. See https://css-tricks.com/snippets/jquery/fixing-load-in-ie-for-cached-images/
          var src = $(this).attr('src');
          $(this).attr('src', src + '?' + new Date().getTime());
          $(this).one('load', function () {
            singleImageLoaded();
          });
        }
    });

    function singleImageLoaded() {
      unloaded--;
      if (unloaded === 0) {
        callback();
      }
    }
  }

  Foundation.Timer = Timer;
  Foundation.onImagesLoaded = onImagesLoaded;
}(jQuery);
;'use strict';

//**************************************************
//**Work inspired by multiple jquery swipe plugins**
//**Done by Yohai Ararat ***************************
//**************************************************
(function ($) {

	$.spotSwipe = {
		version: '1.0.0',
		enabled: 'ontouchstart' in document.documentElement,
		preventDefault: false,
		moveThreshold: 75,
		timeThreshold: 200
	};

	var startPosX,
	    startPosY,
	    startTime,
	    elapsedTime,
	    isMoving = false;

	function onTouchEnd() {
		//  alert(this);
		this.removeEventListener('touchmove', onTouchMove);
		this.removeEventListener('touchend', onTouchEnd);
		isMoving = false;
	}

	function onTouchMove(e) {
		if ($.spotSwipe.preventDefault) {
			e.preventDefault();
		}
		if (isMoving) {
			var x = e.touches[0].pageX;
			var y = e.touches[0].pageY;
			var dx = startPosX - x;
			var dy = startPosY - y;
			var dir;
			elapsedTime = new Date().getTime() - startTime;
			if (Math.abs(dx) >= $.spotSwipe.moveThreshold && elapsedTime <= $.spotSwipe.timeThreshold) {
				dir = dx > 0 ? 'left' : 'right';
			}
			// else if(Math.abs(dy) >= $.spotSwipe.moveThreshold && elapsedTime <= $.spotSwipe.timeThreshold) {
			//   dir = dy > 0 ? 'down' : 'up';
			// }
			if (dir) {
				e.preventDefault();
				onTouchEnd.call(this);
				$(this).trigger('swipe', dir).trigger('swipe' + dir);
			}
		}
	}

	function onTouchStart(e) {
		if (e.touches.length == 1) {
			startPosX = e.touches[0].pageX;
			startPosY = e.touches[0].pageY;
			isMoving = true;
			startTime = new Date().getTime();
			this.addEventListener('touchmove', onTouchMove, false);
			this.addEventListener('touchend', onTouchEnd, false);
		}
	}

	function init() {
		this.addEventListener && this.addEventListener('touchstart', onTouchStart, false);
	}

	function teardown() {
		this.removeEventListener('touchstart', onTouchStart);
	}

	$.event.special.swipe = { setup: init };

	$.each(['left', 'up', 'down', 'right'], function () {
		$.event.special['swipe' + this] = { setup: function setup() {
				$(this).on('swipe', $.noop);
			} };
	});
})(jQuery);
/****************************************************
 * Method for adding psuedo drag events to elements *
 ***************************************************/
!function ($) {
	$.fn.addTouch = function () {
		this.each(function (i, el) {
			$(el).bind('touchstart touchmove touchend touchcancel', function () {
				//we pass the original event object because the jQuery event
				//object is normalized to w3c specs and does not provide the TouchList
				handleTouch(event);
			});
		});

		var handleTouch = function handleTouch(event) {
			var touches = event.changedTouches,
			    first = touches[0],
			    eventTypes = {
				touchstart: 'mousedown',
				touchmove: 'mousemove',
				touchend: 'mouseup'
			},
			    type = eventTypes[event.type],
			    simulatedEvent;

			if ('MouseEvent' in window && typeof window.MouseEvent === 'function') {
				simulatedEvent = new window.MouseEvent(type, {
					'bubbles': true,
					'cancelable': true,
					'screenX': first.screenX,
					'screenY': first.screenY,
					'clientX': first.clientX,
					'clientY': first.clientY
				});
			} else {
				simulatedEvent = document.createEvent('MouseEvent');
				simulatedEvent.initMouseEvent(type, true, true, window, 1, first.screenX, first.screenY, first.clientX, first.clientY, false, false, false, false, 0 /*left*/, null);
			}
			first.target.dispatchEvent(simulatedEvent);
		};
	};
}(jQuery);

//**********************************
//**From the jQuery Mobile Library**
//**need to recreate functionality**
//**and try to improve if possible**
//**********************************

/* Removing the jQuery function ****
************************************

(function( $, window, undefined ) {

	var $document = $( document ),
		// supportTouch = $.mobile.support.touch,
		touchStartEvent = 'touchstart'//supportTouch ? "touchstart" : "mousedown",
		touchStopEvent = 'touchend'//supportTouch ? "touchend" : "mouseup",
		touchMoveEvent = 'touchmove'//supportTouch ? "touchmove" : "mousemove";

	// setup new event shortcuts
	$.each( ( "touchstart touchmove touchend " +
		"swipe swipeleft swiperight" ).split( " " ), function( i, name ) {

		$.fn[ name ] = function( fn ) {
			return fn ? this.bind( name, fn ) : this.trigger( name );
		};

		// jQuery < 1.8
		if ( $.attrFn ) {
			$.attrFn[ name ] = true;
		}
	});

	function triggerCustomEvent( obj, eventType, event, bubble ) {
		var originalType = event.type;
		event.type = eventType;
		if ( bubble ) {
			$.event.trigger( event, undefined, obj );
		} else {
			$.event.dispatch.call( obj, event );
		}
		event.type = originalType;
	}

	// also handles taphold

	// Also handles swipeleft, swiperight
	$.event.special.swipe = {

		// More than this horizontal displacement, and we will suppress scrolling.
		scrollSupressionThreshold: 30,

		// More time than this, and it isn't a swipe.
		durationThreshold: 1000,

		// Swipe horizontal displacement must be more than this.
		horizontalDistanceThreshold: window.devicePixelRatio >= 2 ? 15 : 30,

		// Swipe vertical displacement must be less than this.
		verticalDistanceThreshold: window.devicePixelRatio >= 2 ? 15 : 30,

		getLocation: function ( event ) {
			var winPageX = window.pageXOffset,
				winPageY = window.pageYOffset,
				x = event.clientX,
				y = event.clientY;

			if ( event.pageY === 0 && Math.floor( y ) > Math.floor( event.pageY ) ||
				event.pageX === 0 && Math.floor( x ) > Math.floor( event.pageX ) ) {

				// iOS4 clientX/clientY have the value that should have been
				// in pageX/pageY. While pageX/page/ have the value 0
				x = x - winPageX;
				y = y - winPageY;
			} else if ( y < ( event.pageY - winPageY) || x < ( event.pageX - winPageX ) ) {

				// Some Android browsers have totally bogus values for clientX/Y
				// when scrolling/zooming a page. Detectable since clientX/clientY
				// should never be smaller than pageX/pageY minus page scroll
				x = event.pageX - winPageX;
				y = event.pageY - winPageY;
			}

			return {
				x: x,
				y: y
			};
		},

		start: function( event ) {
			var data = event.originalEvent.touches ?
					event.originalEvent.touches[ 0 ] : event,
				location = $.event.special.swipe.getLocation( data );
			return {
						time: ( new Date() ).getTime(),
						coords: [ location.x, location.y ],
						origin: $( event.target )
					};
		},

		stop: function( event ) {
			var data = event.originalEvent.touches ?
					event.originalEvent.touches[ 0 ] : event,
				location = $.event.special.swipe.getLocation( data );
			return {
						time: ( new Date() ).getTime(),
						coords: [ location.x, location.y ]
					};
		},

		handleSwipe: function( start, stop, thisObject, origTarget ) {
			if ( stop.time - start.time < $.event.special.swipe.durationThreshold &&
				Math.abs( start.coords[ 0 ] - stop.coords[ 0 ] ) > $.event.special.swipe.horizontalDistanceThreshold &&
				Math.abs( start.coords[ 1 ] - stop.coords[ 1 ] ) < $.event.special.swipe.verticalDistanceThreshold ) {
				var direction = start.coords[0] > stop.coords[ 0 ] ? "swipeleft" : "swiperight";

				triggerCustomEvent( thisObject, "swipe", $.Event( "swipe", { target: origTarget, swipestart: start, swipestop: stop }), true );
				triggerCustomEvent( thisObject, direction,$.Event( direction, { target: origTarget, swipestart: start, swipestop: stop } ), true );
				return true;
			}
			return false;

		},

		// This serves as a flag to ensure that at most one swipe event event is
		// in work at any given time
		eventInProgress: false,

		setup: function() {
			var events,
				thisObject = this,
				$this = $( thisObject ),
				context = {};

			// Retrieve the events data for this element and add the swipe context
			events = $.data( this, "mobile-events" );
			if ( !events ) {
				events = { length: 0 };
				$.data( this, "mobile-events", events );
			}
			events.length++;
			events.swipe = context;

			context.start = function( event ) {

				// Bail if we're already working on a swipe event
				if ( $.event.special.swipe.eventInProgress ) {
					return;
				}
				$.event.special.swipe.eventInProgress = true;

				var stop,
					start = $.event.special.swipe.start( event ),
					origTarget = event.target,
					emitted = false;

				context.move = function( event ) {
					if ( !start || event.isDefaultPrevented() ) {
						return;
					}

					stop = $.event.special.swipe.stop( event );
					if ( !emitted ) {
						emitted = $.event.special.swipe.handleSwipe( start, stop, thisObject, origTarget );
						if ( emitted ) {

							// Reset the context to make way for the next swipe event
							$.event.special.swipe.eventInProgress = false;
						}
					}
					// prevent scrolling
					if ( Math.abs( start.coords[ 0 ] - stop.coords[ 0 ] ) > $.event.special.swipe.scrollSupressionThreshold ) {
						event.preventDefault();
					}
				};

				context.stop = function() {
						emitted = true;

						// Reset the context to make way for the next swipe event
						$.event.special.swipe.eventInProgress = false;
						$document.off( touchMoveEvent, context.move );
						context.move = null;
				};

				$document.on( touchMoveEvent, context.move )
					.one( touchStopEvent, context.stop );
			};
			$this.on( touchStartEvent, context.start );
		},

		teardown: function() {
			var events, context;

			events = $.data( this, "mobile-events" );
			if ( events ) {
				context = events.swipe;
				delete events.swipe;
				events.length--;
				if ( events.length === 0 ) {
					$.removeData( this, "mobile-events" );
				}
			}

			if ( context ) {
				if ( context.start ) {
					$( this ).off( touchStartEvent, context.start );
				}
				if ( context.move ) {
					$document.off( touchMoveEvent, context.move );
				}
				if ( context.stop ) {
					$document.off( touchStopEvent, context.stop );
				}
			}
		}
	};
	$.each({
		swipeleft: "swipe.left",
		swiperight: "swipe.right"
	}, function( event, sourceEvent ) {

		$.event.special[ event ] = {
			setup: function() {
				$( this ).bind( sourceEvent, $.noop );
			},
			teardown: function() {
				$( this ).unbind( sourceEvent );
			}
		};
	});
})( jQuery, this );
*/
;'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

!function ($) {

  var MutationObserver = function () {
    var prefixes = ['WebKit', 'Moz', 'O', 'Ms', ''];
    for (var i = 0; i < prefixes.length; i++) {
      if (prefixes[i] + 'MutationObserver' in window) {
        return window[prefixes[i] + 'MutationObserver'];
      }
    }
    return false;
  }();

  var triggers = function triggers(el, type) {
    el.data(type).split(' ').forEach(function (id) {
      $('#' + id)[type === 'close' ? 'trigger' : 'triggerHandler'](type + '.zf.trigger', [el]);
    });
  };
  // Elements with [data-open] will reveal a plugin that supports it when clicked.
  $(document).on('click.zf.trigger', '[data-open]', function () {
    triggers($(this), 'open');
  });

  // Elements with [data-close] will close a plugin that supports it when clicked.
  // If used without a value on [data-close], the event will bubble, allowing it to close a parent component.
  $(document).on('click.zf.trigger', '[data-close]', function () {
    var id = $(this).data('close');
    if (id) {
      triggers($(this), 'close');
    } else {
      $(this).trigger('close.zf.trigger');
    }
  });

  // Elements with [data-toggle] will toggle a plugin that supports it when clicked.
  $(document).on('click.zf.trigger', '[data-toggle]', function () {
    var id = $(this).data('toggle');
    if (id) {
      triggers($(this), 'toggle');
    } else {
      $(this).trigger('toggle.zf.trigger');
    }
  });

  // Elements with [data-closable] will respond to close.zf.trigger events.
  $(document).on('close.zf.trigger', '[data-closable]', function (e) {
    e.stopPropagation();
    var animation = $(this).data('closable');

    if (animation !== '') {
      Foundation.Motion.animateOut($(this), animation, function () {
        $(this).trigger('closed.zf');
      });
    } else {
      $(this).fadeOut().trigger('closed.zf');
    }
  });

  $(document).on('focus.zf.trigger blur.zf.trigger', '[data-toggle-focus]', function () {
    var id = $(this).data('toggle-focus');
    $('#' + id).triggerHandler('toggle.zf.trigger', [$(this)]);
  });

  /**
  * Fires once after all other scripts have loaded
  * @function
  * @private
  */
  $(window).on('load', function () {
    checkListeners();
  });

  function checkListeners() {
    eventsListener();
    resizeListener();
    scrollListener();
    mutateListener();
    closemeListener();
  }

  //******** only fires this function once on load, if there's something to watch ********
  function closemeListener(pluginName) {
    var yetiBoxes = $('[data-yeti-box]'),
        plugNames = ['dropdown', 'tooltip', 'reveal'];

    if (pluginName) {
      if (typeof pluginName === 'string') {
        plugNames.push(pluginName);
      } else if ((typeof pluginName === 'undefined' ? 'undefined' : _typeof(pluginName)) === 'object' && typeof pluginName[0] === 'string') {
        plugNames.concat(pluginName);
      } else {
        console.error('Plugin names must be strings');
      }
    }
    if (yetiBoxes.length) {
      var listeners = plugNames.map(function (name) {
        return 'closeme.zf.' + name;
      }).join(' ');

      $(window).off(listeners).on(listeners, function (e, pluginId) {
        var plugin = e.namespace.split('.')[0];
        var plugins = $('[data-' + plugin + ']').not('[data-yeti-box="' + pluginId + '"]');

        plugins.each(function () {
          var _this = $(this);

          _this.triggerHandler('close.zf.trigger', [_this]);
        });
      });
    }
  }

  function resizeListener(debounce) {
    var timer = void 0,
        $nodes = $('[data-resize]');
    if ($nodes.length) {
      $(window).off('resize.zf.trigger').on('resize.zf.trigger', function (e) {
        if (timer) {
          clearTimeout(timer);
        }

        timer = setTimeout(function () {

          if (!MutationObserver) {
            //fallback for IE 9
            $nodes.each(function () {
              $(this).triggerHandler('resizeme.zf.trigger');
            });
          }
          //trigger all listening elements and signal a resize event
          $nodes.attr('data-events', "resize");
        }, debounce || 10); //default time to emit resize event
      });
    }
  }

  function scrollListener(debounce) {
    var timer = void 0,
        $nodes = $('[data-scroll]');
    if ($nodes.length) {
      $(window).off('scroll.zf.trigger').on('scroll.zf.trigger', function (e) {
        if (timer) {
          clearTimeout(timer);
        }

        timer = setTimeout(function () {

          if (!MutationObserver) {
            //fallback for IE 9
            $nodes.each(function () {
              $(this).triggerHandler('scrollme.zf.trigger');
            });
          }
          //trigger all listening elements and signal a scroll event
          $nodes.attr('data-events', "scroll");
        }, debounce || 10); //default time to emit scroll event
      });
    }
  }

  function mutateListener(debounce) {
    var $nodes = $('[data-mutate]');
    if ($nodes.length && MutationObserver) {
      //trigger all listening elements and signal a mutate event
      //no IE 9 or 10
      $nodes.each(function () {
        $(this).triggerHandler('mutateme.zf.trigger');
      });
    }
  }

  function eventsListener() {
    if (!MutationObserver) {
      return false;
    }
    var nodes = document.querySelectorAll('[data-resize], [data-scroll], [data-mutate]');

    //element callback
    var listeningElementsMutation = function listeningElementsMutation(mutationRecordsList) {
      var $target = $(mutationRecordsList[0].target);

      //trigger the event handler for the element depending on type
      switch (mutationRecordsList[0].type) {

        case "attributes":
          if ($target.attr("data-events") === "scroll" && mutationRecordsList[0].attributeName === "data-events") {
            $target.triggerHandler('scrollme.zf.trigger', [$target, window.pageYOffset]);
          }
          if ($target.attr("data-events") === "resize" && mutationRecordsList[0].attributeName === "data-events") {
            $target.triggerHandler('resizeme.zf.trigger', [$target]);
          }
          if (mutationRecordsList[0].attributeName === "style") {
            $target.closest("[data-mutate]").attr("data-events", "mutate");
            $target.closest("[data-mutate]").triggerHandler('mutateme.zf.trigger', [$target.closest("[data-mutate]")]);
          }
          break;

        case "childList":
          $target.closest("[data-mutate]").attr("data-events", "mutate");
          $target.closest("[data-mutate]").triggerHandler('mutateme.zf.trigger', [$target.closest("[data-mutate]")]);
          break;

        default:
          return false;
        //nothing
      }
    };

    if (nodes.length) {
      //for each element that needs to listen for resizing, scrolling, or mutation add a single observer
      for (var i = 0; i <= nodes.length - 1; i++) {
        var elementObserver = new MutationObserver(listeningElementsMutation);
        elementObserver.observe(nodes[i], { attributes: true, childList: true, characterData: false, subtree: true, attributeFilter: ["data-events", "style"] });
      }
    }
  }

  // ------------------------------------

  // [PH]
  // Foundation.CheckWatchers = checkWatchers;
  Foundation.IHearYou = checkListeners;
  // Foundation.ISeeYou = scrollListener;
  // Foundation.IFeelYou = closemeListener;
}(jQuery);

// function domMutationObserver(debounce) {
//   // !!! This is coming soon and needs more work; not active  !!! //
//   var timer,
//   nodes = document.querySelectorAll('[data-mutate]');
//   //
//   if (nodes.length) {
//     // var MutationObserver = (function () {
//     //   var prefixes = ['WebKit', 'Moz', 'O', 'Ms', ''];
//     //   for (var i=0; i < prefixes.length; i++) {
//     //     if (prefixes[i] + 'MutationObserver' in window) {
//     //       return window[prefixes[i] + 'MutationObserver'];
//     //     }
//     //   }
//     //   return false;
//     // }());
//
//
//     //for the body, we need to listen for all changes effecting the style and class attributes
//     var bodyObserver = new MutationObserver(bodyMutation);
//     bodyObserver.observe(document.body, { attributes: true, childList: true, characterData: false, subtree:true, attributeFilter:["style", "class"]});
//
//
//     //body callback
//     function bodyMutation(mutate) {
//       //trigger all listening elements and signal a mutation event
//       if (timer) { clearTimeout(timer); }
//
//       timer = setTimeout(function() {
//         bodyObserver.disconnect();
//         $('[data-mutate]').attr('data-events',"mutate");
//       }, debounce || 150);
//     }
//   }
// }
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * AccordionMenu module.
   * @module foundation.accordionMenu
   * @requires foundation.util.keyboard
   * @requires foundation.util.motion
   * @requires foundation.util.nest
   */

  var AccordionMenu = function () {
    /**
     * Creates a new instance of an accordion menu.
     * @class
     * @fires AccordionMenu#init
     * @param {jQuery} element - jQuery object to make into an accordion menu.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function AccordionMenu(element, options) {
      _classCallCheck(this, AccordionMenu);

      this.$element = element;
      this.options = $.extend({}, AccordionMenu.defaults, this.$element.data(), options);

      Foundation.Nest.Feather(this.$element, 'accordion');

      this._init();

      Foundation.registerPlugin(this, 'AccordionMenu');
      Foundation.Keyboard.register('AccordionMenu', {
        'ENTER': 'toggle',
        'SPACE': 'toggle',
        'ARROW_RIGHT': 'open',
        'ARROW_UP': 'up',
        'ARROW_DOWN': 'down',
        'ARROW_LEFT': 'close',
        'ESCAPE': 'closeAll'
      });
    }

    /**
     * Initializes the accordion menu by hiding all nested menus.
     * @private
     */


    _createClass(AccordionMenu, [{
      key: '_init',
      value: function _init() {
        this.$element.find('[data-submenu]').not('.is-active').slideUp(0); //.find('a').css('padding-left', '1rem');
        this.$element.attr({
          'role': 'menu',
          'aria-multiselectable': this.options.multiOpen
        });

        this.$menuLinks = this.$element.find('.is-accordion-submenu-parent');
        this.$menuLinks.each(function () {
          var linkId = this.id || Foundation.GetYoDigits(6, 'acc-menu-link'),
              $elem = $(this),
              $sub = $elem.children('[data-submenu]'),
              subId = $sub[0].id || Foundation.GetYoDigits(6, 'acc-menu'),
              isActive = $sub.hasClass('is-active');
          $elem.attr({
            'aria-controls': subId,
            'aria-expanded': isActive,
            'role': 'menuitem',
            'id': linkId
          });
          $sub.attr({
            'aria-labelledby': linkId,
            'aria-hidden': !isActive,
            'role': 'menu',
            'id': subId
          });
        });
        var initPanes = this.$element.find('.is-active');
        if (initPanes.length) {
          var _this = this;
          initPanes.each(function () {
            _this.down($(this));
          });
        }
        this._events();
      }

      /**
       * Adds event handlers for items within the menu.
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this;

        this.$element.find('li').each(function () {
          var $submenu = $(this).children('[data-submenu]');

          if ($submenu.length) {
            $(this).children('a').off('click.zf.accordionMenu').on('click.zf.accordionMenu', function (e) {
              e.preventDefault();

              _this.toggle($submenu);
            });
          }
        }).on('keydown.zf.accordionmenu', function (e) {
          var $element = $(this),
              $elements = $element.parent('ul').children('li'),
              $prevElement,
              $nextElement,
              $target = $element.children('[data-submenu]');

          $elements.each(function (i) {
            if ($(this).is($element)) {
              $prevElement = $elements.eq(Math.max(0, i - 1)).find('a').first();
              $nextElement = $elements.eq(Math.min(i + 1, $elements.length - 1)).find('a').first();

              if ($(this).children('[data-submenu]:visible').length) {
                // has open sub menu
                $nextElement = $element.find('li:first-child').find('a').first();
              }
              if ($(this).is(':first-child')) {
                // is first element of sub menu
                $prevElement = $element.parents('li').first().find('a').first();
              } else if ($prevElement.parents('li').first().children('[data-submenu]:visible').length) {
                // if previous element has open sub menu
                $prevElement = $prevElement.parents('li').find('li:last-child').find('a').first();
              }
              if ($(this).is(':last-child')) {
                // is last element of sub menu
                $nextElement = $element.parents('li').first().next('li').find('a').first();
              }

              return;
            }
          });

          Foundation.Keyboard.handleKey(e, 'AccordionMenu', {
            open: function open() {
              if ($target.is(':hidden')) {
                _this.down($target);
                $target.find('li').first().find('a').first().focus();
              }
            },
            close: function close() {
              if ($target.length && !$target.is(':hidden')) {
                // close active sub of this item
                _this.up($target);
              } else if ($element.parent('[data-submenu]').length) {
                // close currently open sub
                _this.up($element.parent('[data-submenu]'));
                $element.parents('li').first().find('a').first().focus();
              }
            },
            up: function up() {
              $prevElement.focus();
              return true;
            },
            down: function down() {
              $nextElement.focus();
              return true;
            },
            toggle: function toggle() {
              if ($element.children('[data-submenu]').length) {
                _this.toggle($element.children('[data-submenu]'));
              }
            },
            closeAll: function closeAll() {
              _this.hideAll();
            },
            handled: function handled(preventDefault) {
              if (preventDefault) {
                e.preventDefault();
              }
              e.stopImmediatePropagation();
            }
          });
        }); //.attr('tabindex', 0);
      }

      /**
       * Closes all panes of the menu.
       * @function
       */

    }, {
      key: 'hideAll',
      value: function hideAll() {
        this.up(this.$element.find('[data-submenu]'));
      }

      /**
       * Opens all panes of the menu.
       * @function
       */

    }, {
      key: 'showAll',
      value: function showAll() {
        this.down(this.$element.find('[data-submenu]'));
      }

      /**
       * Toggles the open/close state of a submenu.
       * @function
       * @param {jQuery} $target - the submenu to toggle
       */

    }, {
      key: 'toggle',
      value: function toggle($target) {
        if (!$target.is(':animated')) {
          if (!$target.is(':hidden')) {
            this.up($target);
          } else {
            this.down($target);
          }
        }
      }

      /**
       * Opens the sub-menu defined by `$target`.
       * @param {jQuery} $target - Sub-menu to open.
       * @fires AccordionMenu#down
       */

    }, {
      key: 'down',
      value: function down($target) {
        var _this = this;

        if (!this.options.multiOpen) {
          this.up(this.$element.find('.is-active').not($target.parentsUntil(this.$element).add($target)));
        }

        $target.addClass('is-active').attr({ 'aria-hidden': false }).parent('.is-accordion-submenu-parent').attr({ 'aria-expanded': true });

        //Foundation.Move(this.options.slideSpeed, $target, function() {
        $target.slideDown(_this.options.slideSpeed, function () {
          /**
           * Fires when the menu is done opening.
           * @event AccordionMenu#down
           */
          _this.$element.trigger('down.zf.accordionMenu', [$target]);
        });
        //});
      }

      /**
       * Closes the sub-menu defined by `$target`. All sub-menus inside the target will be closed as well.
       * @param {jQuery} $target - Sub-menu to close.
       * @fires AccordionMenu#up
       */

    }, {
      key: 'up',
      value: function up($target) {
        var _this = this;
        //Foundation.Move(this.options.slideSpeed, $target, function(){
        $target.slideUp(_this.options.slideSpeed, function () {
          /**
           * Fires when the menu is done collapsing up.
           * @event AccordionMenu#up
           */
          _this.$element.trigger('up.zf.accordionMenu', [$target]);
        });
        //});

        var $menus = $target.find('[data-submenu]').slideUp(0).addBack().attr('aria-hidden', true);

        $menus.parent('.is-accordion-submenu-parent').attr('aria-expanded', false);
      }

      /**
       * Destroys an instance of accordion menu.
       * @fires AccordionMenu#destroyed
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.$element.find('[data-submenu]').slideDown(0).css('display', '');
        this.$element.find('a').off('click.zf.accordionMenu');

        Foundation.Nest.Burn(this.$element, 'accordion');
        Foundation.unregisterPlugin(this);
      }
    }]);

    return AccordionMenu;
  }();

  AccordionMenu.defaults = {
    /**
     * Amount of time to animate the opening of a submenu in ms.
     * @option
     * @example 250
     */
    slideSpeed: 250,
    /**
     * Allow the menu to have multiple open panes.
     * @option
     * @example true
     */
    multiOpen: true
  };

  // Window exports
  Foundation.plugin(AccordionMenu, 'AccordionMenu');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * Drilldown module.
   * @module foundation.drilldown
   * @requires foundation.util.keyboard
   * @requires foundation.util.motion
   * @requires foundation.util.nest
   */

  var Drilldown = function () {
    /**
     * Creates a new instance of a drilldown menu.
     * @class
     * @param {jQuery} element - jQuery object to make into an accordion menu.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function Drilldown(element, options) {
      _classCallCheck(this, Drilldown);

      this.$element = element;
      this.options = $.extend({}, Drilldown.defaults, this.$element.data(), options);

      Foundation.Nest.Feather(this.$element, 'drilldown');

      this._init();

      Foundation.registerPlugin(this, 'Drilldown');
      Foundation.Keyboard.register('Drilldown', {
        'ENTER': 'open',
        'SPACE': 'open',
        'ARROW_RIGHT': 'next',
        'ARROW_UP': 'up',
        'ARROW_DOWN': 'down',
        'ARROW_LEFT': 'previous',
        'ESCAPE': 'close',
        'TAB': 'down',
        'SHIFT_TAB': 'up'
      });
    }

    /**
     * Initializes the drilldown by creating jQuery collections of elements
     * @private
     */


    _createClass(Drilldown, [{
      key: '_init',
      value: function _init() {
        this.$submenuAnchors = this.$element.find('li.is-drilldown-submenu-parent').children('a');
        this.$submenus = this.$submenuAnchors.parent('li').children('[data-submenu]');
        this.$menuItems = this.$element.find('li').not('.js-drilldown-back').attr('role', 'menuitem').find('a');
        this.$element.attr('data-mutate', this.$element.attr('data-drilldown') || Foundation.GetYoDigits(6, 'drilldown'));

        this._prepareMenu();
        this._registerEvents();

        this._keyboardEvents();
      }

      /**
       * prepares drilldown menu by setting attributes to links and elements
       * sets a min height to prevent content jumping
       * wraps the element if not already wrapped
       * @private
       * @function
       */

    }, {
      key: '_prepareMenu',
      value: function _prepareMenu() {
        var _this = this;
        // if(!this.options.holdOpen){
        //   this._menuLinkEvents();
        // }
        this.$submenuAnchors.each(function () {
          var $link = $(this);
          var $sub = $link.parent();
          if (_this.options.parentLink) {
            $link.clone().prependTo($sub.children('[data-submenu]')).wrap('<li class="is-submenu-parent-item is-submenu-item is-drilldown-submenu-item" role="menu-item"></li>');
          }
          $link.data('savedHref', $link.attr('href')).removeAttr('href').attr('tabindex', 0);
          $link.children('[data-submenu]').attr({
            'aria-hidden': true,
            'tabindex': 0,
            'role': 'menu'
          });
          _this._events($link);
        });
        this.$submenus.each(function () {
          var $menu = $(this),
              $back = $menu.find('.js-drilldown-back');
          if (!$back.length) {
            switch (_this.options.backButtonPosition) {
              case "bottom":
                $menu.append(_this.options.backButton);
                break;
              case "top":
                $menu.prepend(_this.options.backButton);
                break;
              default:
                console.error("Unsupported backButtonPosition value '" + _this.options.backButtonPosition + "'");
            }
          }
          _this._back($menu);
        });

        if (!this.options.autoHeight) {
          this.$submenus.addClass('drilldown-submenu-cover-previous');
        }

        if (!this.$element.parent().hasClass('is-drilldown')) {
          this.$wrapper = $(this.options.wrapper).addClass('is-drilldown');
          if (this.options.animateHeight) this.$wrapper.addClass('animate-height');
          this.$wrapper = this.$element.wrap(this.$wrapper).parent().css(this._getMaxDims());
        }
      }
    }, {
      key: '_resize',
      value: function _resize() {
        this.$wrapper.css({ 'max-width': 'none', 'min-height': 'none' });
        // _getMaxDims has side effects (boo) but calling it should update all other necessary heights & widths
        this.$wrapper.css(this._getMaxDims());
      }

      /**
       * Adds event handlers to elements in the menu.
       * @function
       * @private
       * @param {jQuery} $elem - the current menu item to add handlers to.
       */

    }, {
      key: '_events',
      value: function _events($elem) {
        var _this = this;

        $elem.off('click.zf.drilldown').on('click.zf.drilldown', function (e) {
          if ($(e.target).parentsUntil('ul', 'li').hasClass('is-drilldown-submenu-parent')) {
            e.stopImmediatePropagation();
            e.preventDefault();
          }

          // if(e.target !== e.currentTarget.firstElementChild){
          //   return false;
          // }
          _this._show($elem.parent('li'));

          if (_this.options.closeOnClick) {
            var $body = $('body');
            $body.off('.zf.drilldown').on('click.zf.drilldown', function (e) {
              if (e.target === _this.$element[0] || $.contains(_this.$element[0], e.target)) {
                return;
              }
              e.preventDefault();
              _this._hideAll();
              $body.off('.zf.drilldown');
            });
          }
        });
        this.$element.on('mutateme.zf.trigger', this._resize.bind(this));
      }

      /**
       * Adds event handlers to the menu element.
       * @function
       * @private
       */

    }, {
      key: '_registerEvents',
      value: function _registerEvents() {
        if (this.options.scrollTop) {
          this._bindHandler = this._scrollTop.bind(this);
          this.$element.on('open.zf.drilldown hide.zf.drilldown closed.zf.drilldown', this._bindHandler);
        }
      }

      /**
       * Scroll to Top of Element or data-scroll-top-element
       * @function
       * @fires Drilldown#scrollme
       */

    }, {
      key: '_scrollTop',
      value: function _scrollTop() {
        var _this = this;
        var $scrollTopElement = _this.options.scrollTopElement != '' ? $(_this.options.scrollTopElement) : _this.$element,
            scrollPos = parseInt($scrollTopElement.offset().top + _this.options.scrollTopOffset);
        $('html, body').stop(true).animate({ scrollTop: scrollPos }, _this.options.animationDuration, _this.options.animationEasing, function () {
          /**
            * Fires after the menu has scrolled
            * @event Drilldown#scrollme
            */
          if (this === $('html')[0]) _this.$element.trigger('scrollme.zf.drilldown');
        });
      }

      /**
       * Adds keydown event listener to `li`'s in the menu.
       * @private
       */

    }, {
      key: '_keyboardEvents',
      value: function _keyboardEvents() {
        var _this = this;

        this.$menuItems.add(this.$element.find('.js-drilldown-back > a, .is-submenu-parent-item > a')).on('keydown.zf.drilldown', function (e) {
          var $element = $(this),
              $elements = $element.parent('li').parent('ul').children('li').children('a'),
              $prevElement,
              $nextElement;

          $elements.each(function (i) {
            if ($(this).is($element)) {
              $prevElement = $elements.eq(Math.max(0, i - 1));
              $nextElement = $elements.eq(Math.min(i + 1, $elements.length - 1));
              return;
            }
          });

          Foundation.Keyboard.handleKey(e, 'Drilldown', {
            next: function next() {
              if ($element.is(_this.$submenuAnchors)) {
                _this._show($element.parent('li'));
                $element.parent('li').one(Foundation.transitionend($element), function () {
                  $element.parent('li').find('ul li a').filter(_this.$menuItems).first().focus();
                });
                return true;
              }
            },
            previous: function previous() {
              _this._hide($element.parent('li').parent('ul'));
              $element.parent('li').parent('ul').one(Foundation.transitionend($element), function () {
                setTimeout(function () {
                  $element.parent('li').parent('ul').parent('li').children('a').first().focus();
                }, 1);
              });
              return true;
            },
            up: function up() {
              $prevElement.focus();
              return true;
            },
            down: function down() {
              $nextElement.focus();
              return true;
            },
            close: function close() {
              _this._back();
              //_this.$menuItems.first().focus(); // focus to first element
            },
            open: function open() {
              if (!$element.is(_this.$menuItems)) {
                // not menu item means back button
                _this._hide($element.parent('li').parent('ul'));
                $element.parent('li').parent('ul').one(Foundation.transitionend($element), function () {
                  setTimeout(function () {
                    $element.parent('li').parent('ul').parent('li').children('a').first().focus();
                  }, 1);
                });
                return true;
              } else if ($element.is(_this.$submenuAnchors)) {
                _this._show($element.parent('li'));
                $element.parent('li').one(Foundation.transitionend($element), function () {
                  $element.parent('li').find('ul li a').filter(_this.$menuItems).first().focus();
                });
                return true;
              }
            },
            handled: function handled(preventDefault) {
              if (preventDefault) {
                e.preventDefault();
              }
              e.stopImmediatePropagation();
            }
          });
        }); // end keyboardAccess
      }

      /**
       * Closes all open elements, and returns to root menu.
       * @function
       * @fires Drilldown#closed
       */

    }, {
      key: '_hideAll',
      value: function _hideAll() {
        var $elem = this.$element.find('.is-drilldown-submenu.is-active').addClass('is-closing');
        if (this.options.autoHeight) this.$wrapper.css({ height: $elem.parent().closest('ul').data('calcHeight') });
        $elem.one(Foundation.transitionend($elem), function (e) {
          $elem.removeClass('is-active is-closing');
        });
        /**
         * Fires when the menu is fully closed.
         * @event Drilldown#closed
         */
        this.$element.trigger('closed.zf.drilldown');
      }

      /**
       * Adds event listener for each `back` button, and closes open menus.
       * @function
       * @fires Drilldown#back
       * @param {jQuery} $elem - the current sub-menu to add `back` event.
       */

    }, {
      key: '_back',
      value: function _back($elem) {
        var _this = this;
        $elem.off('click.zf.drilldown');
        $elem.children('.js-drilldown-back').on('click.zf.drilldown', function (e) {
          e.stopImmediatePropagation();
          // console.log('mouseup on back');
          _this._hide($elem);

          // If there is a parent submenu, call show
          var parentSubMenu = $elem.parent('li').parent('ul').parent('li');
          if (parentSubMenu.length) {
            _this._show(parentSubMenu);
          }
        });
      }

      /**
       * Adds event listener to menu items w/o submenus to close open menus on click.
       * @function
       * @private
       */

    }, {
      key: '_menuLinkEvents',
      value: function _menuLinkEvents() {
        var _this = this;
        this.$menuItems.not('.is-drilldown-submenu-parent').off('click.zf.drilldown').on('click.zf.drilldown', function (e) {
          // e.stopImmediatePropagation();
          setTimeout(function () {
            _this._hideAll();
          }, 0);
        });
      }

      /**
       * Opens a submenu.
       * @function
       * @fires Drilldown#open
       * @param {jQuery} $elem - the current element with a submenu to open, i.e. the `li` tag.
       */

    }, {
      key: '_show',
      value: function _show($elem) {
        if (this.options.autoHeight) this.$wrapper.css({ height: $elem.children('[data-submenu]').data('calcHeight') });
        $elem.attr('aria-expanded', true);
        $elem.children('[data-submenu]').addClass('is-active').attr('aria-hidden', false);
        /**
         * Fires when the submenu has opened.
         * @event Drilldown#open
         */
        this.$element.trigger('open.zf.drilldown', [$elem]);
      }
    }, {
      key: '_hide',


      /**
       * Hides a submenu
       * @function
       * @fires Drilldown#hide
       * @param {jQuery} $elem - the current sub-menu to hide, i.e. the `ul` tag.
       */
      value: function _hide($elem) {
        if (this.options.autoHeight) this.$wrapper.css({ height: $elem.parent().closest('ul').data('calcHeight') });
        var _this = this;
        $elem.parent('li').attr('aria-expanded', false);
        $elem.attr('aria-hidden', true).addClass('is-closing');
        $elem.addClass('is-closing').one(Foundation.transitionend($elem), function () {
          $elem.removeClass('is-active is-closing');
          $elem.blur();
        });
        /**
         * Fires when the submenu has closed.
         * @event Drilldown#hide
         */
        $elem.trigger('hide.zf.drilldown', [$elem]);
      }

      /**
       * Iterates through the nested menus to calculate the min-height, and max-width for the menu.
       * Prevents content jumping.
       * @function
       * @private
       */

    }, {
      key: '_getMaxDims',
      value: function _getMaxDims() {
        var maxHeight = 0,
            result = {},
            _this = this;
        this.$submenus.add(this.$element).each(function () {
          var numOfElems = $(this).children('li').length;
          var height = Foundation.Box.GetDimensions(this).height;
          maxHeight = height > maxHeight ? height : maxHeight;
          if (_this.options.autoHeight) {
            $(this).data('calcHeight', height);
            if (!$(this).hasClass('is-drilldown-submenu')) result['height'] = height;
          }
        });

        if (!this.options.autoHeight) result['min-height'] = maxHeight + 'px';

        result['max-width'] = this.$element[0].getBoundingClientRect().width + 'px';

        return result;
      }

      /**
       * Destroys the Drilldown Menu
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        if (this.options.scrollTop) this.$element.off('.zf.drilldown', this._bindHandler);
        this._hideAll();
        this.$element.off('mutateme.zf.trigger');
        Foundation.Nest.Burn(this.$element, 'drilldown');
        this.$element.unwrap().find('.js-drilldown-back, .is-submenu-parent-item').remove().end().find('.is-active, .is-closing, .is-drilldown-submenu').removeClass('is-active is-closing is-drilldown-submenu').end().find('[data-submenu]').removeAttr('aria-hidden tabindex role');
        this.$submenuAnchors.each(function () {
          $(this).off('.zf.drilldown');
        });

        this.$submenus.removeClass('drilldown-submenu-cover-previous');

        this.$element.find('a').each(function () {
          var $link = $(this);
          $link.removeAttr('tabindex');
          if ($link.data('savedHref')) {
            $link.attr('href', $link.data('savedHref')).removeData('savedHref');
          } else {
            return;
          }
        });
        Foundation.unregisterPlugin(this);
      }
    }]);

    return Drilldown;
  }();

  Drilldown.defaults = {
    /**
     * Markup used for JS generated back button. Prepended  or appended (see backButtonPosition) to submenu lists and deleted on `destroy` method, 'js-drilldown-back' class required. Remove the backslash (`\`) if copy and pasting.
     * @option
     * @example '<\li><\a>Back<\/a><\/li>'
     */
    backButton: '<li class="js-drilldown-back"><a tabindex="0">Back</a></li>',
    /**
     * Position the back button either at the top or bottom of drilldown submenus.
     * @option
     * @example bottom
     */
    backButtonPosition: 'top',
    /**
     * Markup used to wrap drilldown menu. Use a class name for independent styling; the JS applied class: `is-drilldown` is required. Remove the backslash (`\`) if copy and pasting.
     * @option
     * @example '<\div class="is-drilldown"><\/div>'
     */
    wrapper: '<div></div>',
    /**
     * Adds the parent link to the submenu.
     * @option
     * @example false
     */
    parentLink: false,
    /**
     * Allow the menu to return to root list on body click.
     * @option
     * @example false
     */
    closeOnClick: false,
    /**
     * Allow the menu to auto adjust height.
     * @option
     * @example false
     */
    autoHeight: false,
    /**
     * Animate the auto adjust height.
     * @option
     * @example false
     */
    animateHeight: false,
    /**
     * Scroll to the top of the menu after opening a submenu or navigating back using the menu back button
     * @option
     * @example false
     */
    scrollTop: false,
    /**
     * String jquery selector (for example 'body') of element to take offset().top from, if empty string the drilldown menu offset().top is taken
     * @option
     * @example ''
     */
    scrollTopElement: '',
    /**
     * ScrollTop offset
     * @option
     * @example 100
     */
    scrollTopOffset: 0,
    /**
     * Scroll animation duration
     * @option
     * @example 500
     */
    animationDuration: 500,
    /**
     * Scroll animation easing
     * @option
     * @example 'swing'
     */
    animationEasing: 'swing'
    // holdOpen: false
  };

  // Window exports
  Foundation.plugin(Drilldown, 'Drilldown');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * Dropdown module.
   * @module foundation.dropdown
   * @requires foundation.util.keyboard
   * @requires foundation.util.box
   * @requires foundation.util.triggers
   */

  var Dropdown = function () {
    /**
     * Creates a new instance of a dropdown.
     * @class
     * @param {jQuery} element - jQuery object to make into a dropdown.
     *        Object should be of the dropdown panel, rather than its anchor.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function Dropdown(element, options) {
      _classCallCheck(this, Dropdown);

      this.$element = element;
      this.options = $.extend({}, Dropdown.defaults, this.$element.data(), options);
      this._init();

      Foundation.registerPlugin(this, 'Dropdown');
      Foundation.Keyboard.register('Dropdown', {
        'ENTER': 'open',
        'SPACE': 'open',
        'ESCAPE': 'close'
      });
    }

    /**
     * Initializes the plugin by setting/checking options and attributes, adding helper variables, and saving the anchor.
     * @function
     * @private
     */


    _createClass(Dropdown, [{
      key: '_init',
      value: function _init() {
        var $id = this.$element.attr('id');

        this.$anchor = $('[data-toggle="' + $id + '"]').length ? $('[data-toggle="' + $id + '"]') : $('[data-open="' + $id + '"]');
        this.$anchor.attr({
          'aria-controls': $id,
          'data-is-focus': false,
          'data-yeti-box': $id,
          'aria-haspopup': true,
          'aria-expanded': false

        });

        if (this.options.parentClass) {
          this.$parent = this.$element.parents('.' + this.options.parentClass);
        } else {
          this.$parent = null;
        }
        this.options.positionClass = this.getPositionClass();
        this.counter = 4;
        this.usedPositions = [];
        this.$element.attr({
          'aria-hidden': 'true',
          'data-yeti-box': $id,
          'data-resize': $id,
          'aria-labelledby': this.$anchor[0].id || Foundation.GetYoDigits(6, 'dd-anchor')
        });
        this._events();
      }

      /**
       * Helper function to determine current orientation of dropdown pane.
       * @function
       * @returns {String} position - string value of a position class.
       */

    }, {
      key: 'getPositionClass',
      value: function getPositionClass() {
        var verticalPosition = this.$element[0].className.match(/(top|left|right|bottom)/g);
        verticalPosition = verticalPosition ? verticalPosition[0] : '';
        var horizontalPosition = /float-(\S+)/.exec(this.$anchor[0].className);
        horizontalPosition = horizontalPosition ? horizontalPosition[1] : '';
        var position = horizontalPosition ? horizontalPosition + ' ' + verticalPosition : verticalPosition;

        return position;
      }

      /**
       * Adjusts the dropdown panes orientation by adding/removing positioning classes.
       * @function
       * @private
       * @param {String} position - position class to remove.
       */

    }, {
      key: '_reposition',
      value: function _reposition(position) {
        this.usedPositions.push(position ? position : 'bottom');
        //default, try switching to opposite side
        if (!position && this.usedPositions.indexOf('top') < 0) {
          this.$element.addClass('top');
        } else if (position === 'top' && this.usedPositions.indexOf('bottom') < 0) {
          this.$element.removeClass(position);
        } else if (position === 'left' && this.usedPositions.indexOf('right') < 0) {
          this.$element.removeClass(position).addClass('right');
        } else if (position === 'right' && this.usedPositions.indexOf('left') < 0) {
          this.$element.removeClass(position).addClass('left');
        }

        //if default change didn't work, try bottom or left first
        else if (!position && this.usedPositions.indexOf('top') > -1 && this.usedPositions.indexOf('left') < 0) {
            this.$element.addClass('left');
          } else if (position === 'top' && this.usedPositions.indexOf('bottom') > -1 && this.usedPositions.indexOf('left') < 0) {
            this.$element.removeClass(position).addClass('left');
          } else if (position === 'left' && this.usedPositions.indexOf('right') > -1 && this.usedPositions.indexOf('bottom') < 0) {
            this.$element.removeClass(position);
          } else if (position === 'right' && this.usedPositions.indexOf('left') > -1 && this.usedPositions.indexOf('bottom') < 0) {
            this.$element.removeClass(position);
          }
          //if nothing cleared, set to bottom
          else {
              this.$element.removeClass(position);
            }
        this.classChanged = true;
        this.counter--;
      }

      /**
       * Sets the position and orientation of the dropdown pane, checks for collisions.
       * Recursively calls itself if a collision is detected, with a new position class.
       * @function
       * @private
       */

    }, {
      key: '_setPosition',
      value: function _setPosition() {
        if (this.$anchor.attr('aria-expanded') === 'false') {
          return false;
        }
        var position = this.getPositionClass(),
            $eleDims = Foundation.Box.GetDimensions(this.$element),
            $anchorDims = Foundation.Box.GetDimensions(this.$anchor),
            _this = this,
            direction = position === 'left' ? 'left' : position === 'right' ? 'left' : 'top',
            param = direction === 'top' ? 'height' : 'width',
            offset = param === 'height' ? this.options.vOffset : this.options.hOffset;

        if ($eleDims.width >= $eleDims.windowDims.width || !this.counter && !Foundation.Box.ImNotTouchingYou(this.$element, this.$parent)) {
          var newWidth = $eleDims.windowDims.width,
              parentHOffset = 0;
          if (this.$parent) {
            var $parentDims = Foundation.Box.GetDimensions(this.$parent),
                parentHOffset = $parentDims.offset.left;
            if ($parentDims.width < newWidth) {
              newWidth = $parentDims.width;
            }
          }

          this.$element.offset(Foundation.Box.GetOffsets(this.$element, this.$anchor, 'center bottom', this.options.vOffset, this.options.hOffset + parentHOffset, true)).css({
            'width': newWidth - this.options.hOffset * 2,
            'height': 'auto'
          });
          this.classChanged = true;
          return false;
        }

        this.$element.offset(Foundation.Box.GetOffsets(this.$element, this.$anchor, position, this.options.vOffset, this.options.hOffset));

        while (!Foundation.Box.ImNotTouchingYou(this.$element, this.$parent, true) && this.counter) {
          this._reposition(position);
          this._setPosition();
        }
      }

      /**
       * Adds event listeners to the element utilizing the triggers utility library.
       * @function
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this;
        this.$element.on({
          'open.zf.trigger': this.open.bind(this),
          'close.zf.trigger': this.close.bind(this),
          'toggle.zf.trigger': this.toggle.bind(this),
          'resizeme.zf.trigger': this._setPosition.bind(this)
        });

        if (this.options.hover) {
          this.$anchor.off('mouseenter.zf.dropdown mouseleave.zf.dropdown').on('mouseenter.zf.dropdown', function () {
            var bodyData = $('body').data();
            if (typeof bodyData.whatinput === 'undefined' || bodyData.whatinput === 'mouse') {
              clearTimeout(_this.timeout);
              _this.timeout = setTimeout(function () {
                _this.open();
                _this.$anchor.data('hover', true);
              }, _this.options.hoverDelay);
            }
          }).on('mouseleave.zf.dropdown', function () {
            clearTimeout(_this.timeout);
            _this.timeout = setTimeout(function () {
              _this.close();
              _this.$anchor.data('hover', false);
            }, _this.options.hoverDelay);
          });
          if (this.options.hoverPane) {
            this.$element.off('mouseenter.zf.dropdown mouseleave.zf.dropdown').on('mouseenter.zf.dropdown', function () {
              clearTimeout(_this.timeout);
            }).on('mouseleave.zf.dropdown', function () {
              clearTimeout(_this.timeout);
              _this.timeout = setTimeout(function () {
                _this.close();
                _this.$anchor.data('hover', false);
              }, _this.options.hoverDelay);
            });
          }
        }
        this.$anchor.add(this.$element).on('keydown.zf.dropdown', function (e) {

          var $target = $(this),
              visibleFocusableElements = Foundation.Keyboard.findFocusable(_this.$element);

          Foundation.Keyboard.handleKey(e, 'Dropdown', {
            open: function open() {
              if ($target.is(_this.$anchor)) {
                _this.open();
                _this.$element.attr('tabindex', -1).focus();
                e.preventDefault();
              }
            },
            close: function close() {
              _this.close();
              _this.$anchor.focus();
            }
          });
        });
      }

      /**
       * Adds an event handler to the body to close any dropdowns on a click.
       * @function
       * @private
       */

    }, {
      key: '_addBodyHandler',
      value: function _addBodyHandler() {
        var $body = $(document.body).not(this.$element),
            _this = this;
        $body.off('click.zf.dropdown').on('click.zf.dropdown', function (e) {
          if (_this.$anchor.is(e.target) || _this.$anchor.find(e.target).length) {
            return;
          }
          if (_this.$element.find(e.target).length) {
            return;
          }
          _this.close();
          $body.off('click.zf.dropdown');
        });
      }

      /**
       * Opens the dropdown pane, and fires a bubbling event to close other dropdowns.
       * @function
       * @fires Dropdown#closeme
       * @fires Dropdown#show
       */

    }, {
      key: 'open',
      value: function open() {
        // var _this = this;
        /**
         * Fires to close other open dropdowns
         * @event Dropdown#closeme
         */
        this.$element.trigger('closeme.zf.dropdown', this.$element.attr('id'));
        this.$anchor.addClass('hover').attr({ 'aria-expanded': true });
        // this.$element/*.show()*/;
        this._setPosition();
        this.$element.addClass('is-open').attr({ 'aria-hidden': false });

        if (this.options.autoFocus) {
          var $focusable = Foundation.Keyboard.findFocusable(this.$element);
          if ($focusable.length) {
            $focusable.eq(0).focus();
          }
        }

        if (this.options.closeOnClick) {
          this._addBodyHandler();
        }

        if (this.options.trapFocus) {
          Foundation.Keyboard.trapFocus(this.$element);
        }

        /**
         * Fires once the dropdown is visible.
         * @event Dropdown#show
         */
        this.$element.trigger('show.zf.dropdown', [this.$element]);
      }

      /**
       * Closes the open dropdown pane.
       * @function
       * @fires Dropdown#hide
       */

    }, {
      key: 'close',
      value: function close() {
        if (!this.$element.hasClass('is-open')) {
          return false;
        }
        this.$element.removeClass('is-open').attr({ 'aria-hidden': true });

        this.$anchor.removeClass('hover').attr('aria-expanded', false);

        if (this.classChanged) {
          var curPositionClass = this.getPositionClass();
          if (curPositionClass) {
            this.$element.removeClass(curPositionClass);
          }
          this.$element.addClass(this.options.positionClass)
          /*.hide()*/.css({ height: '', width: '' });
          this.classChanged = false;
          this.counter = 4;
          this.usedPositions.length = 0;
        }
        this.$element.trigger('hide.zf.dropdown', [this.$element]);

        if (this.options.trapFocus) {
          Foundation.Keyboard.releaseFocus(this.$element);
        }
      }

      /**
       * Toggles the dropdown pane's visibility.
       * @function
       */

    }, {
      key: 'toggle',
      value: function toggle() {
        if (this.$element.hasClass('is-open')) {
          if (this.$anchor.data('hover')) return;
          this.close();
        } else {
          this.open();
        }
      }

      /**
       * Destroys the dropdown.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.$element.off('.zf.trigger').hide();
        this.$anchor.off('.zf.dropdown');

        Foundation.unregisterPlugin(this);
      }
    }]);

    return Dropdown;
  }();

  Dropdown.defaults = {
    /**
     * Class that designates bounding container of Dropdown (Default: window)
     * @option
     * @example 'dropdown-parent'
     */
    parentClass: null,
    /**
     * Amount of time to delay opening a submenu on hover event.
     * @option
     * @example 250
     */
    hoverDelay: 250,
    /**
     * Allow submenus to open on hover events
     * @option
     * @example false
     */
    hover: false,
    /**
     * Don't close dropdown when hovering over dropdown pane
     * @option
     * @example true
     */
    hoverPane: false,
    /**
     * Number of pixels between the dropdown pane and the triggering element on open.
     * @option
     * @example 1
     */
    vOffset: 1,
    /**
     * Number of pixels between the dropdown pane and the triggering element on open.
     * @option
     * @example 1
     */
    hOffset: 1,
    /**
     * Class applied to adjust open position. JS will test and fill this in.
     * @option
     * @example 'top'
     */
    positionClass: '',
    /**
     * Allow the plugin to trap focus to the dropdown pane if opened with keyboard commands.
     * @option
     * @example false
     */
    trapFocus: false,
    /**
     * Allow the plugin to set focus to the first focusable element within the pane, regardless of method of opening.
     * @option
     * @example true
     */
    autoFocus: false,
    /**
     * Allows a click on the body to close the dropdown.
     * @option
     * @example false
     */
    closeOnClick: false

    // Window exports
  };Foundation.plugin(Dropdown, 'Dropdown');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * DropdownMenu module.
   * @module foundation.dropdown-menu
   * @requires foundation.util.keyboard
   * @requires foundation.util.box
   * @requires foundation.util.nest
   */

  var DropdownMenu = function () {
    /**
     * Creates a new instance of DropdownMenu.
     * @class
     * @fires DropdownMenu#init
     * @param {jQuery} element - jQuery object to make into a dropdown menu.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function DropdownMenu(element, options) {
      _classCallCheck(this, DropdownMenu);

      this.$element = element;
      this.options = $.extend({}, DropdownMenu.defaults, this.$element.data(), options);

      Foundation.Nest.Feather(this.$element, 'dropdown');
      this._init();

      Foundation.registerPlugin(this, 'DropdownMenu');
      Foundation.Keyboard.register('DropdownMenu', {
        'ENTER': 'open',
        'SPACE': 'open',
        'ARROW_RIGHT': 'next',
        'ARROW_UP': 'up',
        'ARROW_DOWN': 'down',
        'ARROW_LEFT': 'previous',
        'ESCAPE': 'close'
      });
    }

    /**
     * Initializes the plugin, and calls _prepareMenu
     * @private
     * @function
     */


    _createClass(DropdownMenu, [{
      key: '_init',
      value: function _init() {
        var subs = this.$element.find('li.is-dropdown-submenu-parent');
        this.$element.children('.is-dropdown-submenu-parent').children('.is-dropdown-submenu').addClass('first-sub');

        this.$menuItems = this.$element.find('[role="menuitem"]');
        this.$tabs = this.$element.children('[role="menuitem"]');
        this.$tabs.find('ul.is-dropdown-submenu').addClass(this.options.verticalClass);

        if (this.$element.hasClass(this.options.rightClass) || this.options.alignment === 'right' || Foundation.rtl() || this.$element.parents('.top-bar-right').is('*')) {
          this.options.alignment = 'right';
          subs.addClass('opens-left');
        } else {
          subs.addClass('opens-right');
        }
        this.changed = false;
        this._events();
      }
    }, {
      key: '_isVertical',
      value: function _isVertical() {
        return this.$tabs.css('display') === 'block';
      }

      /**
       * Adds event listeners to elements within the menu
       * @private
       * @function
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this,
            hasTouch = 'ontouchstart' in window || typeof window.ontouchstart !== 'undefined',
            parClass = 'is-dropdown-submenu-parent';

        // used for onClick and in the keyboard handlers
        var handleClickFn = function handleClickFn(e) {
          var $elem = $(e.target).parentsUntil('ul', '.' + parClass),
              hasSub = $elem.hasClass(parClass),
              hasClicked = $elem.attr('data-is-click') === 'true',
              $sub = $elem.children('.is-dropdown-submenu');

          if (hasSub) {
            if (hasClicked) {
              if (!_this.options.closeOnClick || !_this.options.clickOpen && !hasTouch || _this.options.forceFollow && hasTouch) {
                return;
              } else {
                e.stopImmediatePropagation();
                e.preventDefault();
                _this._hide($elem);
              }
            } else {
              e.preventDefault();
              e.stopImmediatePropagation();
              _this._show($sub);
              $elem.add($elem.parentsUntil(_this.$element, '.' + parClass)).attr('data-is-click', true);
            }
          }
        };

        if (this.options.clickOpen || hasTouch) {
          this.$menuItems.on('click.zf.dropdownmenu touchstart.zf.dropdownmenu', handleClickFn);
        }

        // Handle Leaf element Clicks
        if (_this.options.closeOnClickInside) {
          this.$menuItems.on('click.zf.dropdownmenu touchend.zf.dropdownmenu', function (e) {
            var $elem = $(this),
                hasSub = $elem.hasClass(parClass);
            if (!hasSub) {
              _this._hide();
            }
          });
        }

        if (!this.options.disableHover) {
          this.$menuItems.on('mouseenter.zf.dropdownmenu', function (e) {
            var $elem = $(this),
                hasSub = $elem.hasClass(parClass);

            if (hasSub) {
              clearTimeout($elem.data('_delay'));
              $elem.data('_delay', setTimeout(function () {
                _this._show($elem.children('.is-dropdown-submenu'));
              }, _this.options.hoverDelay));
            }
          }).on('mouseleave.zf.dropdownmenu', function (e) {
            var $elem = $(this),
                hasSub = $elem.hasClass(parClass);
            if (hasSub && _this.options.autoclose) {
              if ($elem.attr('data-is-click') === 'true' && _this.options.clickOpen) {
                return false;
              }

              clearTimeout($elem.data('_delay'));
              $elem.data('_delay', setTimeout(function () {
                _this._hide($elem);
              }, _this.options.closingTime));
            }
          });
        }
        this.$menuItems.on('keydown.zf.dropdownmenu', function (e) {
          var $element = $(e.target).parentsUntil('ul', '[role="menuitem"]'),
              isTab = _this.$tabs.index($element) > -1,
              $elements = isTab ? _this.$tabs : $element.siblings('li').add($element),
              $prevElement,
              $nextElement;

          $elements.each(function (i) {
            if ($(this).is($element)) {
              $prevElement = $elements.eq(i - 1);
              $nextElement = $elements.eq(i + 1);
              return;
            }
          });

          var nextSibling = function nextSibling() {
            if (!$element.is(':last-child')) {
              $nextElement.children('a:first').focus();
              e.preventDefault();
            }
          },
              prevSibling = function prevSibling() {
            $prevElement.children('a:first').focus();
            e.preventDefault();
          },
              openSub = function openSub() {
            var $sub = $element.children('ul.is-dropdown-submenu');
            if ($sub.length) {
              _this._show($sub);
              $element.find('li > a:first').focus();
              e.preventDefault();
            } else {
              return;
            }
          },
              closeSub = function closeSub() {
            //if ($element.is(':first-child')) {
            var close = $element.parent('ul').parent('li');
            close.children('a:first').focus();
            _this._hide(close);
            e.preventDefault();
            //}
          };
          var functions = {
            open: openSub,
            close: function close() {
              _this._hide(_this.$element);
              _this.$menuItems.find('a:first').focus(); // focus to first element
              e.preventDefault();
            },
            handled: function handled() {
              e.stopImmediatePropagation();
            }
          };

          if (isTab) {
            if (_this._isVertical()) {
              // vertical menu
              if (Foundation.rtl()) {
                // right aligned
                $.extend(functions, {
                  down: nextSibling,
                  up: prevSibling,
                  next: closeSub,
                  previous: openSub
                });
              } else {
                // left aligned
                $.extend(functions, {
                  down: nextSibling,
                  up: prevSibling,
                  next: openSub,
                  previous: closeSub
                });
              }
            } else {
              // horizontal menu
              if (Foundation.rtl()) {
                // right aligned
                $.extend(functions, {
                  next: prevSibling,
                  previous: nextSibling,
                  down: openSub,
                  up: closeSub
                });
              } else {
                // left aligned
                $.extend(functions, {
                  next: nextSibling,
                  previous: prevSibling,
                  down: openSub,
                  up: closeSub
                });
              }
            }
          } else {
            // not tabs -> one sub
            if (Foundation.rtl()) {
              // right aligned
              $.extend(functions, {
                next: closeSub,
                previous: openSub,
                down: nextSibling,
                up: prevSibling
              });
            } else {
              // left aligned
              $.extend(functions, {
                next: openSub,
                previous: closeSub,
                down: nextSibling,
                up: prevSibling
              });
            }
          }
          Foundation.Keyboard.handleKey(e, 'DropdownMenu', functions);
        });
      }

      /**
       * Adds an event handler to the body to close any dropdowns on a click.
       * @function
       * @private
       */

    }, {
      key: '_addBodyHandler',
      value: function _addBodyHandler() {
        var $body = $(document.body),
            _this = this;
        $body.off('mouseup.zf.dropdownmenu touchend.zf.dropdownmenu').on('mouseup.zf.dropdownmenu touchend.zf.dropdownmenu', function (e) {
          var $link = _this.$element.find(e.target);
          if ($link.length) {
            return;
          }

          _this._hide();
          $body.off('mouseup.zf.dropdownmenu touchend.zf.dropdownmenu');
        });
      }

      /**
       * Opens a dropdown pane, and checks for collisions first.
       * @param {jQuery} $sub - ul element that is a submenu to show
       * @function
       * @private
       * @fires DropdownMenu#show
       */

    }, {
      key: '_show',
      value: function _show($sub) {
        var idx = this.$tabs.index(this.$tabs.filter(function (i, el) {
          return $(el).find($sub).length > 0;
        }));
        var $sibs = $sub.parent('li.is-dropdown-submenu-parent').siblings('li.is-dropdown-submenu-parent');
        this._hide($sibs, idx);
        $sub.css('visibility', 'hidden').addClass('js-dropdown-active').parent('li.is-dropdown-submenu-parent').addClass('is-active');
        var clear = Foundation.Box.ImNotTouchingYou($sub, null, true);
        if (!clear) {
          var oldClass = this.options.alignment === 'left' ? '-right' : '-left',
              $parentLi = $sub.parent('.is-dropdown-submenu-parent');
          $parentLi.removeClass('opens' + oldClass).addClass('opens-' + this.options.alignment);
          clear = Foundation.Box.ImNotTouchingYou($sub, null, true);
          if (!clear) {
            $parentLi.removeClass('opens-' + this.options.alignment).addClass('opens-inner');
          }
          this.changed = true;
        }
        $sub.css('visibility', '');
        if (this.options.closeOnClick) {
          this._addBodyHandler();
        }
        /**
         * Fires when the new dropdown pane is visible.
         * @event DropdownMenu#show
         */
        this.$element.trigger('show.zf.dropdownmenu', [$sub]);
      }

      /**
       * Hides a single, currently open dropdown pane, if passed a parameter, otherwise, hides everything.
       * @function
       * @param {jQuery} $elem - element with a submenu to hide
       * @param {Number} idx - index of the $tabs collection to hide
       * @private
       */

    }, {
      key: '_hide',
      value: function _hide($elem, idx) {
        var $toClose;
        if ($elem && $elem.length) {
          $toClose = $elem;
        } else if (idx !== undefined) {
          $toClose = this.$tabs.not(function (i, el) {
            return i === idx;
          });
        } else {
          $toClose = this.$element;
        }
        var somethingToClose = $toClose.hasClass('is-active') || $toClose.find('.is-active').length > 0;

        if (somethingToClose) {
          $toClose.find('li.is-active').add($toClose).attr({
            'data-is-click': false
          }).removeClass('is-active');

          $toClose.find('ul.js-dropdown-active').removeClass('js-dropdown-active');

          if (this.changed || $toClose.find('opens-inner').length) {
            var oldClass = this.options.alignment === 'left' ? 'right' : 'left';
            $toClose.find('li.is-dropdown-submenu-parent').add($toClose).removeClass('opens-inner opens-' + this.options.alignment).addClass('opens-' + oldClass);
            this.changed = false;
          }
          /**
           * Fires when the open menus are closed.
           * @event DropdownMenu#hide
           */
          this.$element.trigger('hide.zf.dropdownmenu', [$toClose]);
        }
      }

      /**
       * Destroys the plugin.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.$menuItems.off('.zf.dropdownmenu').removeAttr('data-is-click').removeClass('is-right-arrow is-left-arrow is-down-arrow opens-right opens-left opens-inner');
        $(document.body).off('.zf.dropdownmenu');
        Foundation.Nest.Burn(this.$element, 'dropdown');
        Foundation.unregisterPlugin(this);
      }
    }]);

    return DropdownMenu;
  }();

  /**
   * Default settings for plugin
   */


  DropdownMenu.defaults = {
    /**
     * Disallows hover events from opening submenus
     * @option
     * @example false
     */
    disableHover: false,
    /**
     * Allow a submenu to automatically close on a mouseleave event, if not clicked open.
     * @option
     * @example true
     */
    autoclose: true,
    /**
     * Amount of time to delay opening a submenu on hover event.
     * @option
     * @example 50
     */
    hoverDelay: 50,
    /**
     * Allow a submenu to open/remain open on parent click event. Allows cursor to move away from menu.
     * @option
     * @example true
     */
    clickOpen: false,
    /**
     * Amount of time to delay closing a submenu on a mouseleave event.
     * @option
     * @example 500
     */

    closingTime: 500,
    /**
     * Position of the menu relative to what direction the submenus should open. Handled by JS.
     * @option
     * @example 'left'
     */
    alignment: 'left',
    /**
     * Allow clicks on the body to close any open submenus.
     * @option
     * @example true
     */
    closeOnClick: true,
    /**
     * Allow clicks on leaf anchor links to close any open submenus.
     * @option
     * @example true
     */
    closeOnClickInside: true,
    /**
     * Class applied to vertical oriented menus, Foundation default is `vertical`. Update this if using your own class.
     * @option
     * @example 'vertical'
     */
    verticalClass: 'vertical',
    /**
     * Class applied to right-side oriented menus, Foundation default is `align-right`. Update this if using your own class.
     * @option
     * @example 'align-right'
     */
    rightClass: 'align-right',
    /**
     * Boolean to force overide the clicking of links to perform default action, on second touch event for mobile.
     * @option
     * @example false
     */
    forceFollow: true
  };

  // Window exports
  Foundation.plugin(DropdownMenu, 'DropdownMenu');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * OffCanvas module.
   * @module foundation.offcanvas
   * @requires foundation.util.mediaQuery
   * @requires foundation.util.triggers
   * @requires foundation.util.motion
   */

  var OffCanvas = function () {
    /**
     * Creates a new instance of an off-canvas wrapper.
     * @class
     * @fires OffCanvas#init
     * @param {Object} element - jQuery object to initialize.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function OffCanvas(element, options) {
      _classCallCheck(this, OffCanvas);

      this.$element = element;
      this.options = $.extend({}, OffCanvas.defaults, this.$element.data(), options);
      this.$lastTrigger = $();
      this.$triggers = $();

      this._init();
      this._events();

      Foundation.registerPlugin(this, 'OffCanvas');
      Foundation.Keyboard.register('OffCanvas', {
        'ESCAPE': 'close'
      });
    }

    /**
     * Initializes the off-canvas wrapper by adding the exit overlay (if needed).
     * @function
     * @private
     */


    _createClass(OffCanvas, [{
      key: '_init',
      value: function _init() {
        var id = this.$element.attr('id');

        this.$element.attr('aria-hidden', 'true');

        this.$element.addClass('is-transition-' + this.options.transition);

        // Find triggers that affect this element and add aria-expanded to them
        this.$triggers = $(document).find('[data-open="' + id + '"], [data-close="' + id + '"], [data-toggle="' + id + '"]').attr('aria-expanded', 'false').attr('aria-controls', id);

        // Add an overlay over the content if necessary
        if (this.options.contentOverlay === true) {
          var overlay = document.createElement('div');
          var overlayPosition = $(this.$element).css("position") === 'fixed' ? 'is-overlay-fixed' : 'is-overlay-absolute';
          overlay.setAttribute('class', 'js-off-canvas-overlay ' + overlayPosition);
          this.$overlay = $(overlay);
          if (overlayPosition === 'is-overlay-fixed') {
            $('body').append(this.$overlay);
          } else {
            this.$element.siblings('[data-off-canvas-content]').append(this.$overlay);
          }
        }

        this.options.isRevealed = this.options.isRevealed || new RegExp(this.options.revealClass, 'g').test(this.$element[0].className);

        if (this.options.isRevealed === true) {
          this.options.revealOn = this.options.revealOn || this.$element[0].className.match(/(reveal-for-medium|reveal-for-large)/g)[0].split('-')[2];
          this._setMQChecker();
        }
        if (!this.options.transitionTime === true) {
          this.options.transitionTime = parseFloat(window.getComputedStyle($('[data-off-canvas]')[0]).transitionDuration) * 1000;
        }
      }

      /**
       * Adds event handlers to the off-canvas wrapper and the exit overlay.
       * @function
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        this.$element.off('.zf.trigger .zf.offcanvas').on({
          'open.zf.trigger': this.open.bind(this),
          'close.zf.trigger': this.close.bind(this),
          'toggle.zf.trigger': this.toggle.bind(this),
          'keydown.zf.offcanvas': this._handleKeyboard.bind(this)
        });

        if (this.options.closeOnClick === true) {
          var $target = this.options.contentOverlay ? this.$overlay : $('[data-off-canvas-content]');
          $target.on({ 'click.zf.offcanvas': this.close.bind(this) });
        }
      }

      /**
       * Applies event listener for elements that will reveal at certain breakpoints.
       * @private
       */

    }, {
      key: '_setMQChecker',
      value: function _setMQChecker() {
        var _this = this;

        $(window).on('changed.zf.mediaquery', function () {
          if (Foundation.MediaQuery.atLeast(_this.options.revealOn)) {
            _this.reveal(true);
          } else {
            _this.reveal(false);
          }
        }).one('load.zf.offcanvas', function () {
          if (Foundation.MediaQuery.atLeast(_this.options.revealOn)) {
            _this.reveal(true);
          }
        });
      }

      /**
       * Handles the revealing/hiding the off-canvas at breakpoints, not the same as open.
       * @param {Boolean} isRevealed - true if element should be revealed.
       * @function
       */

    }, {
      key: 'reveal',
      value: function reveal(isRevealed) {
        var $closer = this.$element.find('[data-close]');
        if (isRevealed) {
          this.close();
          this.isRevealed = true;
          this.$element.attr('aria-hidden', 'false');
          this.$element.off('open.zf.trigger toggle.zf.trigger');
          if ($closer.length) {
            $closer.hide();
          }
        } else {
          this.isRevealed = false;
          this.$element.attr('aria-hidden', 'true');
          this.$element.on({
            'open.zf.trigger': this.open.bind(this),
            'toggle.zf.trigger': this.toggle.bind(this)
          });
          if ($closer.length) {
            $closer.show();
          }
        }
      }

      /**
       * Stops scrolling of the body when offcanvas is open on mobile Safari and other troublesome browsers.
       * @private
       */

    }, {
      key: '_stopScrolling',
      value: function _stopScrolling(event) {
        return false;
      }

      /**
       * Opens the off-canvas menu.
       * @function
       * @param {Object} event - Event object passed from listener.
       * @param {jQuery} trigger - element that triggered the off-canvas to open.
       * @fires OffCanvas#opened
       */

    }, {
      key: 'open',
      value: function open(event, trigger) {
        if (this.$element.hasClass('is-open') || this.isRevealed) {
          return;
        }
        var _this = this;

        if (trigger) {
          this.$lastTrigger = trigger;
        }

        if (this.options.forceTo === 'top') {
          window.scrollTo(0, 0);
        } else if (this.options.forceTo === 'bottom') {
          window.scrollTo(0, document.body.scrollHeight);
        }

        /**
         * Fires when the off-canvas menu opens.
         * @event OffCanvas#opened
         */
        _this.$element.addClass('is-open');

        this.$triggers.attr('aria-expanded', 'true');
        this.$element.attr('aria-hidden', 'false').trigger('opened.zf.offcanvas');

        // If `contentScroll` is set to false, add class and disable scrolling on touch devices.
        if (this.options.contentScroll === false) {
          $('body').addClass('is-off-canvas-open').on('touchmove', this._stopScrolling);
        }

        if (this.options.contentOverlay === true) {
          this.$overlay.addClass('is-visible');
        }

        if (this.options.closeOnClick === true && this.options.contentOverlay === true) {
          this.$overlay.addClass('is-closable');
        }

        if (this.options.autoFocus === true) {
          this.$element.one(Foundation.transitionend(this.$element), function () {
            _this.$element.find('a, button').eq(0).focus();
          });
        }

        if (this.options.trapFocus === true) {
          this.$element.siblings('[data-off-canvas-content]').attr('tabindex', '-1');
          Foundation.Keyboard.trapFocus(this.$element);
        }
      }

      /**
       * Closes the off-canvas menu.
       * @function
       * @param {Function} cb - optional cb to fire after closure.
       * @fires OffCanvas#closed
       */

    }, {
      key: 'close',
      value: function close(cb) {
        if (!this.$element.hasClass('is-open') || this.isRevealed) {
          return;
        }

        var _this = this;

        _this.$element.removeClass('is-open');

        this.$element.attr('aria-hidden', 'true')
        /**
         * Fires when the off-canvas menu opens.
         * @event OffCanvas#closed
         */
        .trigger('closed.zf.offcanvas');

        // If `contentScroll` is set to false, remove class and re-enable scrolling on touch devices.
        if (this.options.contentScroll === false) {
          $('body').removeClass('is-off-canvas-open').off('touchmove', this._stopScrolling);
        }

        if (this.options.contentOverlay === true) {
          this.$overlay.removeClass('is-visible');
        }

        if (this.options.closeOnClick === true && this.options.contentOverlay === true) {
          this.$overlay.removeClass('is-closable');
        }

        this.$triggers.attr('aria-expanded', 'false');

        if (this.options.trapFocus === true) {
          this.$element.siblings('[data-off-canvas-content]').removeAttr('tabindex');
          Foundation.Keyboard.releaseFocus(this.$element);
        }
      }

      /**
       * Toggles the off-canvas menu open or closed.
       * @function
       * @param {Object} event - Event object passed from listener.
       * @param {jQuery} trigger - element that triggered the off-canvas to open.
       */

    }, {
      key: 'toggle',
      value: function toggle(event, trigger) {
        if (this.$element.hasClass('is-open')) {
          this.close(event, trigger);
        } else {
          this.open(event, trigger);
        }
      }

      /**
       * Handles keyboard input when detected. When the escape key is pressed, the off-canvas menu closes, and focus is restored to the element that opened the menu.
       * @function
       * @private
       */

    }, {
      key: '_handleKeyboard',
      value: function _handleKeyboard(e) {
        var _this2 = this;

        Foundation.Keyboard.handleKey(e, 'OffCanvas', {
          close: function close() {
            _this2.close();
            _this2.$lastTrigger.focus();
            return true;
          },
          handled: function handled() {
            e.stopPropagation();
            e.preventDefault();
          }
        });
      }

      /**
       * Destroys the offcanvas plugin.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.close();
        this.$element.off('.zf.trigger .zf.offcanvas');
        this.$overlay.off('.zf.offcanvas');

        Foundation.unregisterPlugin(this);
      }
    }]);

    return OffCanvas;
  }();

  OffCanvas.defaults = {
    /**
     * Allow the user to click outside of the menu to close it.
     * @option
     * @example true
     */
    closeOnClick: true,

    /**
     * Adds an overlay on top of `[data-off-canvas-content]`.
     * @option
     * @example true
     */
    contentOverlay: true,

    /**
     * Enable/disable scrolling of the main content when an off canvas panel is open.
     * @option
     * @example true
     */
    contentScroll: true,

    /**
     * Amount of time in ms the open and close transition requires. If none selected, pulls from body style.
     * @option
     * @example 500
     */
    transitionTime: 0,

    /**
     * Type of transition for the offcanvas menu. Options are 'push', 'detached' or 'slide'.
     * @option
     * @example push
     */
    transition: 'push',

    /**
     * Force the page to scroll to top or bottom on open.
     * @option
     * @example top
     */
    forceTo: null,

    /**
     * Allow the offcanvas to remain open for certain breakpoints.
     * @option
     * @example false
     */
    isRevealed: false,

    /**
     * Breakpoint at which to reveal. JS will use a RegExp to target standard classes, if changing classnames, pass your class with the `revealClass` option.
     * @option
     * @example reveal-for-large
     */
    revealOn: null,

    /**
     * Force focus to the offcanvas on open. If true, will focus the opening trigger on close.
     * @option
     * @example true
     */
    autoFocus: true,

    /**
     * Class used to force an offcanvas to remain open. Foundation defaults for this are `reveal-for-large` & `reveal-for-medium`.
     * @option
     * TODO improve the regex testing for this.
     * @example reveal-for-large
     */
    revealClass: 'reveal-for-',

    /**
     * Triggers optional focus trapping when opening an offcanvas. Sets tabindex of [data-off-canvas-content] to -1 for accessibility purposes.
     * @option
     * @example true
     */
    trapFocus: false

    // Window exports
  };Foundation.plugin(OffCanvas, 'OffCanvas');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * ResponsiveMenu module.
   * @module foundation.responsiveMenu
   * @requires foundation.util.triggers
   * @requires foundation.util.mediaQuery
   * @requires foundation.util.accordionMenu
   * @requires foundation.util.drilldown
   * @requires foundation.util.dropdown-menu
   */

  var ResponsiveMenu = function () {
    /**
     * Creates a new instance of a responsive menu.
     * @class
     * @fires ResponsiveMenu#init
     * @param {jQuery} element - jQuery object to make into a dropdown menu.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function ResponsiveMenu(element, options) {
      _classCallCheck(this, ResponsiveMenu);

      this.$element = $(element);
      this.rules = this.$element.data('responsive-menu');
      this.currentMq = null;
      this.currentPlugin = null;

      this._init();
      this._events();

      Foundation.registerPlugin(this, 'ResponsiveMenu');
    }

    /**
     * Initializes the Menu by parsing the classes from the 'data-ResponsiveMenu' attribute on the element.
     * @function
     * @private
     */


    _createClass(ResponsiveMenu, [{
      key: '_init',
      value: function _init() {
        // The first time an Interchange plugin is initialized, this.rules is converted from a string of "classes" to an object of rules
        if (typeof this.rules === 'string') {
          var rulesTree = {};

          // Parse rules from "classes" pulled from data attribute
          var rules = this.rules.split(' ');

          // Iterate through every rule found
          for (var i = 0; i < rules.length; i++) {
            var rule = rules[i].split('-');
            var ruleSize = rule.length > 1 ? rule[0] : 'small';
            var rulePlugin = rule.length > 1 ? rule[1] : rule[0];

            if (MenuPlugins[rulePlugin] !== null) {
              rulesTree[ruleSize] = MenuPlugins[rulePlugin];
            }
          }

          this.rules = rulesTree;
        }

        if (!$.isEmptyObject(this.rules)) {
          this._checkMediaQueries();
        }
        // Add data-mutate since children may need it.
        this.$element.attr('data-mutate', this.$element.attr('data-mutate') || Foundation.GetYoDigits(6, 'responsive-menu'));
      }

      /**
       * Initializes events for the Menu.
       * @function
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this;

        $(window).on('changed.zf.mediaquery', function () {
          _this._checkMediaQueries();
        });
        // $(window).on('resize.zf.ResponsiveMenu', function() {
        //   _this._checkMediaQueries();
        // });
      }

      /**
       * Checks the current screen width against available media queries. If the media query has changed, and the plugin needed has changed, the plugins will swap out.
       * @function
       * @private
       */

    }, {
      key: '_checkMediaQueries',
      value: function _checkMediaQueries() {
        var matchedMq,
            _this = this;
        // Iterate through each rule and find the last matching rule
        $.each(this.rules, function (key) {
          if (Foundation.MediaQuery.atLeast(key)) {
            matchedMq = key;
          }
        });

        // No match? No dice
        if (!matchedMq) return;

        // Plugin already initialized? We good
        if (this.currentPlugin instanceof this.rules[matchedMq].plugin) return;

        // Remove existing plugin-specific CSS classes
        $.each(MenuPlugins, function (key, value) {
          _this.$element.removeClass(value.cssClass);
        });

        // Add the CSS class for the new plugin
        this.$element.addClass(this.rules[matchedMq].cssClass);

        // Create an instance of the new plugin
        if (this.currentPlugin) this.currentPlugin.destroy();
        this.currentPlugin = new this.rules[matchedMq].plugin(this.$element, {});
      }

      /**
       * Destroys the instance of the current plugin on this element, as well as the window resize handler that switches the plugins out.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.currentPlugin.destroy();
        $(window).off('.zf.ResponsiveMenu');
        Foundation.unregisterPlugin(this);
      }
    }]);

    return ResponsiveMenu;
  }();

  ResponsiveMenu.defaults = {};

  // The plugin matches the plugin classes with these plugin instances.
  var MenuPlugins = {
    dropdown: {
      cssClass: 'dropdown',
      plugin: Foundation._plugins['dropdown-menu'] || null
    },
    drilldown: {
      cssClass: 'drilldown',
      plugin: Foundation._plugins['drilldown'] || null
    },
    accordion: {
      cssClass: 'accordion-menu',
      plugin: Foundation._plugins['accordion-menu'] || null
    }
  };

  // Window exports
  Foundation.plugin(ResponsiveMenu, 'ResponsiveMenu');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * ResponsiveToggle module.
   * @module foundation.responsiveToggle
   * @requires foundation.util.mediaQuery
   */

  var ResponsiveToggle = function () {
    /**
     * Creates a new instance of Tab Bar.
     * @class
     * @fires ResponsiveToggle#init
     * @param {jQuery} element - jQuery object to attach tab bar functionality to.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function ResponsiveToggle(element, options) {
      _classCallCheck(this, ResponsiveToggle);

      this.$element = $(element);
      this.options = $.extend({}, ResponsiveToggle.defaults, this.$element.data(), options);

      this._init();
      this._events();

      Foundation.registerPlugin(this, 'ResponsiveToggle');
    }

    /**
     * Initializes the tab bar by finding the target element, toggling element, and running update().
     * @function
     * @private
     */


    _createClass(ResponsiveToggle, [{
      key: '_init',
      value: function _init() {
        var targetID = this.$element.data('responsive-toggle');
        if (!targetID) {
          console.error('Your tab bar needs an ID of a Menu as the value of data-tab-bar.');
        }

        this.$targetMenu = $('#' + targetID);
        this.$toggler = this.$element.find('[data-toggle]');
        this.options = $.extend({}, this.options, this.$targetMenu.data());

        // If they were set, parse the animation classes
        if (this.options.animate) {
          var input = this.options.animate.split(' ');

          this.animationIn = input[0];
          this.animationOut = input[1] || null;
        }

        this._update();
      }

      /**
       * Adds necessary event handlers for the tab bar to work.
       * @function
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this;

        this._updateMqHandler = this._update.bind(this);

        $(window).on('changed.zf.mediaquery', this._updateMqHandler);

        this.$toggler.on('click.zf.responsiveToggle', this.toggleMenu.bind(this));
      }

      /**
       * Checks the current media query to determine if the tab bar should be visible or hidden.
       * @function
       * @private
       */

    }, {
      key: '_update',
      value: function _update() {
        // Mobile
        if (!Foundation.MediaQuery.atLeast(this.options.hideFor)) {
          this.$element.show();
          this.$targetMenu.hide();
        }

        // Desktop
        else {
            this.$element.hide();
            this.$targetMenu.show();
          }
      }

      /**
       * Toggles the element attached to the tab bar. The toggle only happens if the screen is small enough to allow it.
       * @function
       * @fires ResponsiveToggle#toggled
       */

    }, {
      key: 'toggleMenu',
      value: function toggleMenu() {
        var _this2 = this;

        if (!Foundation.MediaQuery.atLeast(this.options.hideFor)) {
          if (this.options.animate) {
            if (this.$targetMenu.is(':hidden')) {
              Foundation.Motion.animateIn(this.$targetMenu, this.animationIn, function () {
                /**
                 * Fires when the element attached to the tab bar toggles.
                 * @event ResponsiveToggle#toggled
                 */
                _this2.$element.trigger('toggled.zf.responsiveToggle');
                _this2.$targetMenu.find('[data-mutate]').triggerHandler('mutateme.zf.trigger');
              });
            } else {
              Foundation.Motion.animateOut(this.$targetMenu, this.animationOut, function () {
                /**
                 * Fires when the element attached to the tab bar toggles.
                 * @event ResponsiveToggle#toggled
                 */
                _this2.$element.trigger('toggled.zf.responsiveToggle');
              });
            }
          } else {
            this.$targetMenu.toggle(0);
            this.$targetMenu.find('[data-mutate]').trigger('mutateme.zf.trigger');

            /**
             * Fires when the element attached to the tab bar toggles.
             * @event ResponsiveToggle#toggled
             */
            this.$element.trigger('toggled.zf.responsiveToggle');
          }
        }
      }
    }, {
      key: 'destroy',
      value: function destroy() {
        this.$element.off('.zf.responsiveToggle');
        this.$toggler.off('.zf.responsiveToggle');

        $(window).off('changed.zf.mediaquery', this._updateMqHandler);

        Foundation.unregisterPlugin(this);
      }
    }]);

    return ResponsiveToggle;
  }();

  ResponsiveToggle.defaults = {
    /**
     * The breakpoint after which the menu is always shown, and the tab bar is hidden.
     * @option
     * @example 'medium'
     */
    hideFor: 'medium',

    /**
     * To decide if the toggle should be animated or not.
     * @option
     * @example false
     */
    animate: false
  };

  // Window exports
  Foundation.plugin(ResponsiveToggle, 'ResponsiveToggle');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * Toggler module.
   * @module foundation.toggler
   * @requires foundation.util.motion
   * @requires foundation.util.triggers
   */

  var Toggler = function () {
    /**
     * Creates a new instance of Toggler.
     * @class
     * @fires Toggler#init
     * @param {Object} element - jQuery object to add the trigger to.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function Toggler(element, options) {
      _classCallCheck(this, Toggler);

      this.$element = element;
      this.options = $.extend({}, Toggler.defaults, element.data(), options);
      this.className = '';

      this._init();
      this._events();

      Foundation.registerPlugin(this, 'Toggler');
    }

    /**
     * Initializes the Toggler plugin by parsing the toggle class from data-toggler, or animation classes from data-animate.
     * @function
     * @private
     */


    _createClass(Toggler, [{
      key: '_init',
      value: function _init() {
        var input;
        // Parse animation classes if they were set
        if (this.options.animate) {
          input = this.options.animate.split(' ');

          this.animationIn = input[0];
          this.animationOut = input[1] || null;
        }
        // Otherwise, parse toggle class
        else {
            input = this.$element.data('toggler');
            // Allow for a . at the beginning of the string
            this.className = input[0] === '.' ? input.slice(1) : input;
          }

        // Add ARIA attributes to triggers
        var id = this.$element[0].id;
        $('[data-open="' + id + '"], [data-close="' + id + '"], [data-toggle="' + id + '"]').attr('aria-controls', id);
        // If the target is hidden, add aria-hidden
        this.$element.attr('aria-expanded', this.$element.is(':hidden') ? false : true);
      }

      /**
       * Initializes events for the toggle trigger.
       * @function
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        this.$element.off('toggle.zf.trigger').on('toggle.zf.trigger', this.toggle.bind(this));
      }

      /**
       * Toggles the target class on the target element. An event is fired from the original trigger depending on if the resultant state was "on" or "off".
       * @function
       * @fires Toggler#on
       * @fires Toggler#off
       */

    }, {
      key: 'toggle',
      value: function toggle() {
        this[this.options.animate ? '_toggleAnimate' : '_toggleClass']();
      }
    }, {
      key: '_toggleClass',
      value: function _toggleClass() {
        this.$element.toggleClass(this.className);

        var isOn = this.$element.hasClass(this.className);
        if (isOn) {
          /**
           * Fires if the target element has the class after a toggle.
           * @event Toggler#on
           */
          this.$element.trigger('on.zf.toggler');
        } else {
          /**
           * Fires if the target element does not have the class after a toggle.
           * @event Toggler#off
           */
          this.$element.trigger('off.zf.toggler');
        }

        this._updateARIA(isOn);
        this.$element.find('[data-mutate]').trigger('mutateme.zf.trigger');
      }
    }, {
      key: '_toggleAnimate',
      value: function _toggleAnimate() {
        var _this = this;

        if (this.$element.is(':hidden')) {
          Foundation.Motion.animateIn(this.$element, this.animationIn, function () {
            _this._updateARIA(true);
            this.trigger('on.zf.toggler');
            this.find('[data-mutate]').trigger('mutateme.zf.trigger');
          });
        } else {
          Foundation.Motion.animateOut(this.$element, this.animationOut, function () {
            _this._updateARIA(false);
            this.trigger('off.zf.toggler');
            this.find('[data-mutate]').trigger('mutateme.zf.trigger');
          });
        }
      }
    }, {
      key: '_updateARIA',
      value: function _updateARIA(isOn) {
        this.$element.attr('aria-expanded', isOn ? true : false);
      }

      /**
       * Destroys the instance of Toggler on the element.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.$element.off('.zf.toggler');
        Foundation.unregisterPlugin(this);
      }
    }]);

    return Toggler;
  }();

  Toggler.defaults = {
    /**
     * Tells the plugin if the element should animated when toggled.
     * @option
     * @example false
     */
    animate: false
  };

  // Window exports
  Foundation.plugin(Toggler, 'Toggler');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * Tooltip module.
   * @module foundation.tooltip
   * @requires foundation.util.box
   * @requires foundation.util.mediaQuery
   * @requires foundation.util.triggers
   */

  var Tooltip = function () {
    /**
     * Creates a new instance of a Tooltip.
     * @class
     * @fires Tooltip#init
     * @param {jQuery} element - jQuery object to attach a tooltip to.
     * @param {Object} options - object to extend the default configuration.
     */
    function Tooltip(element, options) {
      _classCallCheck(this, Tooltip);

      this.$element = element;
      this.options = $.extend({}, Tooltip.defaults, this.$element.data(), options);

      this.isActive = false;
      this.isClick = false;
      this._init();

      Foundation.registerPlugin(this, 'Tooltip');
    }

    /**
     * Initializes the tooltip by setting the creating the tip element, adding it's text, setting private variables and setting attributes on the anchor.
     * @private
     */


    _createClass(Tooltip, [{
      key: '_init',
      value: function _init() {
        var elemId = this.$element.attr('aria-describedby') || Foundation.GetYoDigits(6, 'tooltip');

        this.options.positionClass = this.options.positionClass || this._getPositionClass(this.$element);
        this.options.tipText = this.options.tipText || this.$element.attr('title');
        this.template = this.options.template ? $(this.options.template) : this._buildTemplate(elemId);

        if (this.options.allowHtml) {
          this.template.appendTo(document.body).html(this.options.tipText).hide();
        } else {
          this.template.appendTo(document.body).text(this.options.tipText).hide();
        }

        this.$element.attr({
          'title': '',
          'aria-describedby': elemId,
          'data-yeti-box': elemId,
          'data-toggle': elemId,
          'data-resize': elemId
        }).addClass(this.options.triggerClass);

        //helper variables to track movement on collisions
        this.usedPositions = [];
        this.counter = 4;
        this.classChanged = false;

        this._events();
      }

      /**
       * Grabs the current positioning class, if present, and returns the value or an empty string.
       * @private
       */

    }, {
      key: '_getPositionClass',
      value: function _getPositionClass(element) {
        if (!element) {
          return '';
        }
        // var position = element.attr('class').match(/top|left|right/g);
        var position = element[0].className.match(/\b(top|left|right)\b/g);
        position = position ? position[0] : '';
        return position;
      }
    }, {
      key: '_buildTemplate',

      /**
       * builds the tooltip element, adds attributes, and returns the template.
       * @private
       */
      value: function _buildTemplate(id) {
        var templateClasses = (this.options.tooltipClass + ' ' + this.options.positionClass + ' ' + this.options.templateClasses).trim();
        var $template = $('<div></div>').addClass(templateClasses).attr({
          'role': 'tooltip',
          'aria-hidden': true,
          'data-is-active': false,
          'data-is-focus': false,
          'id': id
        });
        return $template;
      }

      /**
       * Function that gets called if a collision event is detected.
       * @param {String} position - positioning class to try
       * @private
       */

    }, {
      key: '_reposition',
      value: function _reposition(position) {
        this.usedPositions.push(position ? position : 'bottom');

        //default, try switching to opposite side
        if (!position && this.usedPositions.indexOf('top') < 0) {
          this.template.addClass('top');
        } else if (position === 'top' && this.usedPositions.indexOf('bottom') < 0) {
          this.template.removeClass(position);
        } else if (position === 'left' && this.usedPositions.indexOf('right') < 0) {
          this.template.removeClass(position).addClass('right');
        } else if (position === 'right' && this.usedPositions.indexOf('left') < 0) {
          this.template.removeClass(position).addClass('left');
        }

        //if default change didn't work, try bottom or left first
        else if (!position && this.usedPositions.indexOf('top') > -1 && this.usedPositions.indexOf('left') < 0) {
            this.template.addClass('left');
          } else if (position === 'top' && this.usedPositions.indexOf('bottom') > -1 && this.usedPositions.indexOf('left') < 0) {
            this.template.removeClass(position).addClass('left');
          } else if (position === 'left' && this.usedPositions.indexOf('right') > -1 && this.usedPositions.indexOf('bottom') < 0) {
            this.template.removeClass(position);
          } else if (position === 'right' && this.usedPositions.indexOf('left') > -1 && this.usedPositions.indexOf('bottom') < 0) {
            this.template.removeClass(position);
          }
          //if nothing cleared, set to bottom
          else {
              this.template.removeClass(position);
            }
        this.classChanged = true;
        this.counter--;
      }

      /**
       * sets the position class of an element and recursively calls itself until there are no more possible positions to attempt, or the tooltip element is no longer colliding.
       * if the tooltip is larger than the screen width, default to full width - any user selected margin
       * @private
       */

    }, {
      key: '_setPosition',
      value: function _setPosition() {
        var position = this._getPositionClass(this.template),
            $tipDims = Foundation.Box.GetDimensions(this.template),
            $anchorDims = Foundation.Box.GetDimensions(this.$element),
            direction = position === 'left' ? 'left' : position === 'right' ? 'left' : 'top',
            param = direction === 'top' ? 'height' : 'width',
            offset = param === 'height' ? this.options.vOffset : this.options.hOffset,
            _this = this;

        if ($tipDims.width >= $tipDims.windowDims.width || !this.counter && !Foundation.Box.ImNotTouchingYou(this.template)) {
          this.template.offset(Foundation.Box.GetOffsets(this.template, this.$element, 'center bottom', this.options.vOffset, this.options.hOffset, true)).css({
            // this.$element.offset(Foundation.GetOffsets(this.template, this.$element, 'center bottom', this.options.vOffset, this.options.hOffset, true)).css({
            'width': $anchorDims.windowDims.width - this.options.hOffset * 2,
            'height': 'auto'
          });
          return false;
        }

        this.template.offset(Foundation.Box.GetOffsets(this.template, this.$element, 'center ' + (position || 'bottom'), this.options.vOffset, this.options.hOffset));

        while (!Foundation.Box.ImNotTouchingYou(this.template) && this.counter) {
          this._reposition(position);
          this._setPosition();
        }
      }

      /**
       * reveals the tooltip, and fires an event to close any other open tooltips on the page
       * @fires Tooltip#closeme
       * @fires Tooltip#show
       * @function
       */

    }, {
      key: 'show',
      value: function show() {
        if (this.options.showOn !== 'all' && !Foundation.MediaQuery.is(this.options.showOn)) {
          // console.error('The screen is too small to display this tooltip');
          return false;
        }

        var _this = this;
        this.template.css('visibility', 'hidden').show();
        this._setPosition();

        /**
         * Fires to close all other open tooltips on the page
         * @event Closeme#tooltip
         */
        this.$element.trigger('closeme.zf.tooltip', this.template.attr('id'));

        this.template.attr({
          'data-is-active': true,
          'aria-hidden': false
        });
        _this.isActive = true;
        // console.log(this.template);
        this.template.stop().hide().css('visibility', '').fadeIn(this.options.fadeInDuration, function () {
          //maybe do stuff?
        });
        /**
         * Fires when the tooltip is shown
         * @event Tooltip#show
         */
        this.$element.trigger('show.zf.tooltip');
      }

      /**
       * Hides the current tooltip, and resets the positioning class if it was changed due to collision
       * @fires Tooltip#hide
       * @function
       */

    }, {
      key: 'hide',
      value: function hide() {
        // console.log('hiding', this.$element.data('yeti-box'));
        var _this = this;
        this.template.stop().attr({
          'aria-hidden': true,
          'data-is-active': false
        }).fadeOut(this.options.fadeOutDuration, function () {
          _this.isActive = false;
          _this.isClick = false;
          if (_this.classChanged) {
            _this.template.removeClass(_this._getPositionClass(_this.template)).addClass(_this.options.positionClass);

            _this.usedPositions = [];
            _this.counter = 4;
            _this.classChanged = false;
          }
        });
        /**
         * fires when the tooltip is hidden
         * @event Tooltip#hide
         */
        this.$element.trigger('hide.zf.tooltip');
      }

      /**
       * adds event listeners for the tooltip and its anchor
       * TODO combine some of the listeners like focus and mouseenter, etc.
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this;
        var $template = this.template;
        var isFocus = false;

        if (!this.options.disableHover) {

          this.$element.on('mouseenter.zf.tooltip', function (e) {
            if (!_this.isActive) {
              _this.timeout = setTimeout(function () {
                _this.show();
              }, _this.options.hoverDelay);
            }
          }).on('mouseleave.zf.tooltip', function (e) {
            clearTimeout(_this.timeout);
            if (!isFocus || _this.isClick && !_this.options.clickOpen) {
              _this.hide();
            }
          });
        }

        if (this.options.clickOpen) {
          this.$element.on('mousedown.zf.tooltip', function (e) {
            e.stopImmediatePropagation();
            if (_this.isClick) {
              //_this.hide();
              // _this.isClick = false;
            } else {
              _this.isClick = true;
              if ((_this.options.disableHover || !_this.$element.attr('tabindex')) && !_this.isActive) {
                _this.show();
              }
            }
          });
        } else {
          this.$element.on('mousedown.zf.tooltip', function (e) {
            e.stopImmediatePropagation();
            _this.isClick = true;
          });
        }

        if (!this.options.disableForTouch) {
          this.$element.on('tap.zf.tooltip touchend.zf.tooltip', function (e) {
            _this.isActive ? _this.hide() : _this.show();
          });
        }

        this.$element.on({
          // 'toggle.zf.trigger': this.toggle.bind(this),
          // 'close.zf.trigger': this.hide.bind(this)
          'close.zf.trigger': this.hide.bind(this)
        });

        this.$element.on('focus.zf.tooltip', function (e) {
          isFocus = true;
          if (_this.isClick) {
            // If we're not showing open on clicks, we need to pretend a click-launched focus isn't
            // a real focus, otherwise on hover and come back we get bad behavior
            if (!_this.options.clickOpen) {
              isFocus = false;
            }
            return false;
          } else {
            _this.show();
          }
        }).on('focusout.zf.tooltip', function (e) {
          isFocus = false;
          _this.isClick = false;
          _this.hide();
        }).on('resizeme.zf.trigger', function () {
          if (_this.isActive) {
            _this._setPosition();
          }
        });
      }

      /**
       * adds a toggle method, in addition to the static show() & hide() functions
       * @function
       */

    }, {
      key: 'toggle',
      value: function toggle() {
        if (this.isActive) {
          this.hide();
        } else {
          this.show();
        }
      }

      /**
       * Destroys an instance of tooltip, removes template element from the view.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.$element.attr('title', this.template.text()).off('.zf.trigger .zf.tooltip').removeClass('has-tip top right left').removeAttr('aria-describedby aria-haspopup data-disable-hover data-resize data-toggle data-tooltip data-yeti-box');

        this.template.remove();

        Foundation.unregisterPlugin(this);
      }
    }]);

    return Tooltip;
  }();

  Tooltip.defaults = {
    disableForTouch: false,
    /**
     * Time, in ms, before a tooltip should open on hover.
     * @option
     * @example 200
     */
    hoverDelay: 200,
    /**
     * Time, in ms, a tooltip should take to fade into view.
     * @option
     * @example 150
     */
    fadeInDuration: 150,
    /**
     * Time, in ms, a tooltip should take to fade out of view.
     * @option
     * @example 150
     */
    fadeOutDuration: 150,
    /**
     * Disables hover events from opening the tooltip if set to true
     * @option
     * @example false
     */
    disableHover: false,
    /**
     * Optional addtional classes to apply to the tooltip template on init.
     * @option
     * @example 'my-cool-tip-class'
     */
    templateClasses: '',
    /**
     * Non-optional class added to tooltip templates. Foundation default is 'tooltip'.
     * @option
     * @example 'tooltip'
     */
    tooltipClass: 'tooltip',
    /**
     * Class applied to the tooltip anchor element.
     * @option
     * @example 'has-tip'
     */
    triggerClass: 'has-tip',
    /**
     * Minimum breakpoint size at which to open the tooltip.
     * @option
     * @example 'small'
     */
    showOn: 'small',
    /**
     * Custom template to be used to generate markup for tooltip.
     * @option
     * @example '&lt;div class="tooltip"&gt;&lt;/div&gt;'
     */
    template: '',
    /**
     * Text displayed in the tooltip template on open.
     * @option
     * @example 'Some cool space fact here.'
     */
    tipText: '',
    touchCloseText: 'Tap to close.',
    /**
     * Allows the tooltip to remain open if triggered with a click or touch event.
     * @option
     * @example true
     */
    clickOpen: true,
    /**
     * Additional positioning classes, set by the JS
     * @option
     * @example 'top'
     */
    positionClass: '',
    /**
     * Distance, in pixels, the template should push away from the anchor on the Y axis.
     * @option
     * @example 10
     */
    vOffset: 10,
    /**
     * Distance, in pixels, the template should push away from the anchor on the X axis, if aligned to a side.
     * @option
     * @example 12
     */
    hOffset: 12,
    /**
    * Allow HTML in tooltip. Warning: If you are loading user-generated content into tooltips,
    * allowing HTML may open yourself up to XSS attacks.
    * @option
    * @example false
    */
    allowHtml: false
  };

  /**
   * TODO utilize resize event trigger
   */

  // Window exports
  Foundation.plugin(Tooltip, 'Tooltip');
}(jQuery);
;"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/**
 * Owl Carousel v2.2.1
 * Copyright 2013-2017 David Deutsch
 * Licensed under  ()
 */
!function (a, b, c, d) {
  function e(b, c) {
    this.settings = null, this.options = a.extend({}, e.Defaults, c), this.$element = a(b), this._handlers = {}, this._plugins = {}, this._supress = {}, this._current = null, this._speed = null, this._coordinates = [], this._breakpoint = null, this._width = null, this._items = [], this._clones = [], this._mergers = [], this._widths = [], this._invalidated = {}, this._pipe = [], this._drag = { time: null, target: null, pointer: null, stage: { start: null, current: null }, direction: null }, this._states = { current: {}, tags: { initializing: ["busy"], animating: ["busy"], dragging: ["interacting"] } }, a.each(["onResize", "onThrottledResize"], a.proxy(function (b, c) {
      this._handlers[c] = a.proxy(this[c], this);
    }, this)), a.each(e.Plugins, a.proxy(function (a, b) {
      this._plugins[a.charAt(0).toLowerCase() + a.slice(1)] = new b(this);
    }, this)), a.each(e.Workers, a.proxy(function (b, c) {
      this._pipe.push({ filter: c.filter, run: a.proxy(c.run, this) });
    }, this)), this.setup(), this.initialize();
  }e.Defaults = { items: 3, loop: !1, center: !1, rewind: !1, mouseDrag: !0, touchDrag: !0, pullDrag: !0, freeDrag: !1, margin: 0, stagePadding: 0, merge: !1, mergeFit: !0, autoWidth: !1, startPosition: 0, rtl: !1, smartSpeed: 250, fluidSpeed: !1, dragEndSpeed: !1, responsive: {}, responsiveRefreshRate: 200, responsiveBaseElement: b, fallbackEasing: "swing", info: !1, nestedItemSelector: !1, itemElement: "div", stageElement: "div", refreshClass: "owl-refresh", loadedClass: "owl-loaded", loadingClass: "owl-loading", rtlClass: "owl-rtl", responsiveClass: "owl-responsive", dragClass: "owl-drag", itemClass: "owl-item", stageClass: "owl-stage", stageOuterClass: "owl-stage-outer", grabClass: "owl-grab" }, e.Width = { Default: "default", Inner: "inner", Outer: "outer" }, e.Type = { Event: "event", State: "state" }, e.Plugins = {}, e.Workers = [{ filter: ["width", "settings"], run: function run() {
      this._width = this.$element.width();
    } }, { filter: ["width", "items", "settings"], run: function run(a) {
      a.current = this._items && this._items[this.relative(this._current)];
    } }, { filter: ["items", "settings"], run: function run() {
      this.$stage.children(".cloned").remove();
    } }, { filter: ["width", "items", "settings"], run: function run(a) {
      var b = this.settings.margin || "",
          c = !this.settings.autoWidth,
          d = this.settings.rtl,
          e = { width: "auto", "margin-left": d ? b : "", "margin-right": d ? "" : b };!c && this.$stage.children().css(e), a.css = e;
    } }, { filter: ["width", "items", "settings"], run: function run(a) {
      var b = (this.width() / this.settings.items).toFixed(3) - this.settings.margin,
          c = null,
          d = this._items.length,
          e = !this.settings.autoWidth,
          f = [];for (a.items = { merge: !1, width: b }; d--;) {
        c = this._mergers[d], c = this.settings.mergeFit && Math.min(c, this.settings.items) || c, a.items.merge = c > 1 || a.items.merge, f[d] = e ? b * c : this._items[d].width();
      }this._widths = f;
    } }, { filter: ["items", "settings"], run: function run() {
      var b = [],
          c = this._items,
          d = this.settings,
          e = Math.max(2 * d.items, 4),
          f = 2 * Math.ceil(c.length / 2),
          g = d.loop && c.length ? d.rewind ? e : Math.max(e, f) : 0,
          h = "",
          i = "";for (g /= 2; g--;) {
        b.push(this.normalize(b.length / 2, !0)), h += c[b[b.length - 1]][0].outerHTML, b.push(this.normalize(c.length - 1 - (b.length - 1) / 2, !0)), i = c[b[b.length - 1]][0].outerHTML + i;
      }this._clones = b, a(h).addClass("cloned").appendTo(this.$stage), a(i).addClass("cloned").prependTo(this.$stage);
    } }, { filter: ["width", "items", "settings"], run: function run() {
      for (var a = this.settings.rtl ? 1 : -1, b = this._clones.length + this._items.length, c = -1, d = 0, e = 0, f = []; ++c < b;) {
        d = f[c - 1] || 0, e = this._widths[this.relative(c)] + this.settings.margin, f.push(d + e * a);
      }this._coordinates = f;
    } }, { filter: ["width", "items", "settings"], run: function run() {
      var a = this.settings.stagePadding,
          b = this._coordinates,
          c = { width: Math.ceil(Math.abs(b[b.length - 1])) + 2 * a, "padding-left": a || "", "padding-right": a || "" };this.$stage.css(c);
    } }, { filter: ["width", "items", "settings"], run: function run(a) {
      var b = this._coordinates.length,
          c = !this.settings.autoWidth,
          d = this.$stage.children();if (c && a.items.merge) for (; b--;) {
        a.css.width = this._widths[this.relative(b)], d.eq(b).css(a.css);
      } else c && (a.css.width = a.items.width, d.css(a.css));
    } }, { filter: ["items"], run: function run() {
      this._coordinates.length < 1 && this.$stage.removeAttr("style");
    } }, { filter: ["width", "items", "settings"], run: function run(a) {
      a.current = a.current ? this.$stage.children().index(a.current) : 0, a.current = Math.max(this.minimum(), Math.min(this.maximum(), a.current)), this.reset(a.current);
    } }, { filter: ["position"], run: function run() {
      this.animate(this.coordinates(this._current));
    } }, { filter: ["width", "position", "items", "settings"], run: function run() {
      var a,
          b,
          c,
          d,
          e = this.settings.rtl ? 1 : -1,
          f = 2 * this.settings.stagePadding,
          g = this.coordinates(this.current()) + f,
          h = g + this.width() * e,
          i = [];for (c = 0, d = this._coordinates.length; c < d; c++) {
        a = this._coordinates[c - 1] || 0, b = Math.abs(this._coordinates[c]) + f * e, (this.op(a, "<=", g) && this.op(a, ">", h) || this.op(b, "<", g) && this.op(b, ">", h)) && i.push(c);
      }this.$stage.children(".active").removeClass("active"), this.$stage.children(":eq(" + i.join("), :eq(") + ")").addClass("active"), this.settings.center && (this.$stage.children(".center").removeClass("center"), this.$stage.children().eq(this.current()).addClass("center"));
    } }], e.prototype.initialize = function () {
    if (this.enter("initializing"), this.trigger("initialize"), this.$element.toggleClass(this.settings.rtlClass, this.settings.rtl), this.settings.autoWidth && !this.is("pre-loading")) {
      var b, c, e;b = this.$element.find("img"), c = this.settings.nestedItemSelector ? "." + this.settings.nestedItemSelector : d, e = this.$element.children(c).width(), b.length && e <= 0 && this.preloadAutoWidthImages(b);
    }this.$element.addClass(this.options.loadingClass), this.$stage = a("<" + this.settings.stageElement + ' class="' + this.settings.stageClass + '"/>').wrap('<div class="' + this.settings.stageOuterClass + '"/>'), this.$element.append(this.$stage.parent()), this.replace(this.$element.children().not(this.$stage.parent())), this.$element.is(":visible") ? this.refresh() : this.invalidate("width"), this.$element.removeClass(this.options.loadingClass).addClass(this.options.loadedClass), this.registerEventHandlers(), this.leave("initializing"), this.trigger("initialized");
  }, e.prototype.setup = function () {
    var b = this.viewport(),
        c = this.options.responsive,
        d = -1,
        e = null;c ? (a.each(c, function (a) {
      a <= b && a > d && (d = Number(a));
    }), e = a.extend({}, this.options, c[d]), "function" == typeof e.stagePadding && (e.stagePadding = e.stagePadding()), delete e.responsive, e.responsiveClass && this.$element.attr("class", this.$element.attr("class").replace(new RegExp("(" + this.options.responsiveClass + "-)\\S+\\s", "g"), "$1" + d))) : e = a.extend({}, this.options), this.trigger("change", { property: { name: "settings", value: e } }), this._breakpoint = d, this.settings = e, this.invalidate("settings"), this.trigger("changed", { property: { name: "settings", value: this.settings } });
  }, e.prototype.optionsLogic = function () {
    this.settings.autoWidth && (this.settings.stagePadding = !1, this.settings.merge = !1);
  }, e.prototype.prepare = function (b) {
    var c = this.trigger("prepare", { content: b });return c.data || (c.data = a("<" + this.settings.itemElement + "/>").addClass(this.options.itemClass).append(b)), this.trigger("prepared", { content: c.data }), c.data;
  }, e.prototype.update = function () {
    for (var b = 0, c = this._pipe.length, d = a.proxy(function (a) {
      return this[a];
    }, this._invalidated), e = {}; b < c;) {
      (this._invalidated.all || a.grep(this._pipe[b].filter, d).length > 0) && this._pipe[b].run(e), b++;
    }this._invalidated = {}, !this.is("valid") && this.enter("valid");
  }, e.prototype.width = function (a) {
    switch (a = a || e.Width.Default) {case e.Width.Inner:case e.Width.Outer:
        return this._width;default:
        return this._width - 2 * this.settings.stagePadding + this.settings.margin;}
  }, e.prototype.refresh = function () {
    this.enter("refreshing"), this.trigger("refresh"), this.setup(), this.optionsLogic(), this.$element.addClass(this.options.refreshClass), this.update(), this.$element.removeClass(this.options.refreshClass), this.leave("refreshing"), this.trigger("refreshed");
  }, e.prototype.onThrottledResize = function () {
    b.clearTimeout(this.resizeTimer), this.resizeTimer = b.setTimeout(this._handlers.onResize, this.settings.responsiveRefreshRate);
  }, e.prototype.onResize = function () {
    return !!this._items.length && this._width !== this.$element.width() && !!this.$element.is(":visible") && (this.enter("resizing"), this.trigger("resize").isDefaultPrevented() ? (this.leave("resizing"), !1) : (this.invalidate("width"), this.refresh(), this.leave("resizing"), void this.trigger("resized")));
  }, e.prototype.registerEventHandlers = function () {
    a.support.transition && this.$stage.on(a.support.transition.end + ".owl.core", a.proxy(this.onTransitionEnd, this)), this.settings.responsive !== !1 && this.on(b, "resize", this._handlers.onThrottledResize), this.settings.mouseDrag && (this.$element.addClass(this.options.dragClass), this.$stage.on("mousedown.owl.core", a.proxy(this.onDragStart, this)), this.$stage.on("dragstart.owl.core selectstart.owl.core", function () {
      return !1;
    })), this.settings.touchDrag && (this.$stage.on("touchstart.owl.core", a.proxy(this.onDragStart, this)), this.$stage.on("touchcancel.owl.core", a.proxy(this.onDragEnd, this)));
  }, e.prototype.onDragStart = function (b) {
    var d = null;3 !== b.which && (a.support.transform ? (d = this.$stage.css("transform").replace(/.*\(|\)| /g, "").split(","), d = { x: d[16 === d.length ? 12 : 4], y: d[16 === d.length ? 13 : 5] }) : (d = this.$stage.position(), d = { x: this.settings.rtl ? d.left + this.$stage.width() - this.width() + this.settings.margin : d.left, y: d.top }), this.is("animating") && (a.support.transform ? this.animate(d.x) : this.$stage.stop(), this.invalidate("position")), this.$element.toggleClass(this.options.grabClass, "mousedown" === b.type), this.speed(0), this._drag.time = new Date().getTime(), this._drag.target = a(b.target), this._drag.stage.start = d, this._drag.stage.current = d, this._drag.pointer = this.pointer(b), a(c).on("mouseup.owl.core touchend.owl.core", a.proxy(this.onDragEnd, this)), a(c).one("mousemove.owl.core touchmove.owl.core", a.proxy(function (b) {
      var d = this.difference(this._drag.pointer, this.pointer(b));a(c).on("mousemove.owl.core touchmove.owl.core", a.proxy(this.onDragMove, this)), Math.abs(d.x) < Math.abs(d.y) && this.is("valid") || (b.preventDefault(), this.enter("dragging"), this.trigger("drag"));
    }, this)));
  }, e.prototype.onDragMove = function (a) {
    var b = null,
        c = null,
        d = null,
        e = this.difference(this._drag.pointer, this.pointer(a)),
        f = this.difference(this._drag.stage.start, e);this.is("dragging") && (a.preventDefault(), this.settings.loop ? (b = this.coordinates(this.minimum()), c = this.coordinates(this.maximum() + 1) - b, f.x = ((f.x - b) % c + c) % c + b) : (b = this.settings.rtl ? this.coordinates(this.maximum()) : this.coordinates(this.minimum()), c = this.settings.rtl ? this.coordinates(this.minimum()) : this.coordinates(this.maximum()), d = this.settings.pullDrag ? -1 * e.x / 5 : 0, f.x = Math.max(Math.min(f.x, b + d), c + d)), this._drag.stage.current = f, this.animate(f.x));
  }, e.prototype.onDragEnd = function (b) {
    var d = this.difference(this._drag.pointer, this.pointer(b)),
        e = this._drag.stage.current,
        f = d.x > 0 ^ this.settings.rtl ? "left" : "right";a(c).off(".owl.core"), this.$element.removeClass(this.options.grabClass), (0 !== d.x && this.is("dragging") || !this.is("valid")) && (this.speed(this.settings.dragEndSpeed || this.settings.smartSpeed), this.current(this.closest(e.x, 0 !== d.x ? f : this._drag.direction)), this.invalidate("position"), this.update(), this._drag.direction = f, (Math.abs(d.x) > 3 || new Date().getTime() - this._drag.time > 300) && this._drag.target.one("click.owl.core", function () {
      return !1;
    })), this.is("dragging") && (this.leave("dragging"), this.trigger("dragged"));
  }, e.prototype.closest = function (b, c) {
    var d = -1,
        e = 30,
        f = this.width(),
        g = this.coordinates();return this.settings.freeDrag || a.each(g, a.proxy(function (a, h) {
      return "left" === c && b > h - e && b < h + e ? d = a : "right" === c && b > h - f - e && b < h - f + e ? d = a + 1 : this.op(b, "<", h) && this.op(b, ">", g[a + 1] || h - f) && (d = "left" === c ? a + 1 : a), d === -1;
    }, this)), this.settings.loop || (this.op(b, ">", g[this.minimum()]) ? d = b = this.minimum() : this.op(b, "<", g[this.maximum()]) && (d = b = this.maximum())), d;
  }, e.prototype.animate = function (b) {
    var c = this.speed() > 0;this.is("animating") && this.onTransitionEnd(), c && (this.enter("animating"), this.trigger("translate")), a.support.transform3d && a.support.transition ? this.$stage.css({ transform: "translate3d(" + b + "px,0px,0px)", transition: this.speed() / 1e3 + "s" }) : c ? this.$stage.animate({ left: b + "px" }, this.speed(), this.settings.fallbackEasing, a.proxy(this.onTransitionEnd, this)) : this.$stage.css({ left: b + "px" });
  }, e.prototype.is = function (a) {
    return this._states.current[a] && this._states.current[a] > 0;
  }, e.prototype.current = function (a) {
    if (a === d) return this._current;if (0 === this._items.length) return d;if (a = this.normalize(a), this._current !== a) {
      var b = this.trigger("change", { property: { name: "position", value: a } });b.data !== d && (a = this.normalize(b.data)), this._current = a, this.invalidate("position"), this.trigger("changed", { property: { name: "position", value: this._current } });
    }return this._current;
  }, e.prototype.invalidate = function (b) {
    return "string" === a.type(b) && (this._invalidated[b] = !0, this.is("valid") && this.leave("valid")), a.map(this._invalidated, function (a, b) {
      return b;
    });
  }, e.prototype.reset = function (a) {
    a = this.normalize(a), a !== d && (this._speed = 0, this._current = a, this.suppress(["translate", "translated"]), this.animate(this.coordinates(a)), this.release(["translate", "translated"]));
  }, e.prototype.normalize = function (a, b) {
    var c = this._items.length,
        e = b ? 0 : this._clones.length;return !this.isNumeric(a) || c < 1 ? a = d : (a < 0 || a >= c + e) && (a = ((a - e / 2) % c + c) % c + e / 2), a;
  }, e.prototype.relative = function (a) {
    return a -= this._clones.length / 2, this.normalize(a, !0);
  }, e.prototype.maximum = function (a) {
    var b,
        c,
        d,
        e = this.settings,
        f = this._coordinates.length;if (e.loop) f = this._clones.length / 2 + this._items.length - 1;else if (e.autoWidth || e.merge) {
      for (b = this._items.length, c = this._items[--b].width(), d = this.$element.width(); b-- && (c += this._items[b].width() + this.settings.margin, !(c > d));) {}f = b + 1;
    } else f = e.center ? this._items.length - 1 : this._items.length - e.items;return a && (f -= this._clones.length / 2), Math.max(f, 0);
  }, e.prototype.minimum = function (a) {
    return a ? 0 : this._clones.length / 2;
  }, e.prototype.items = function (a) {
    return a === d ? this._items.slice() : (a = this.normalize(a, !0), this._items[a]);
  }, e.prototype.mergers = function (a) {
    return a === d ? this._mergers.slice() : (a = this.normalize(a, !0), this._mergers[a]);
  }, e.prototype.clones = function (b) {
    var c = this._clones.length / 2,
        e = c + this._items.length,
        f = function f(a) {
      return a % 2 === 0 ? e + a / 2 : c - (a + 1) / 2;
    };return b === d ? a.map(this._clones, function (a, b) {
      return f(b);
    }) : a.map(this._clones, function (a, c) {
      return a === b ? f(c) : null;
    });
  }, e.prototype.speed = function (a) {
    return a !== d && (this._speed = a), this._speed;
  }, e.prototype.coordinates = function (b) {
    var c,
        e = 1,
        f = b - 1;return b === d ? a.map(this._coordinates, a.proxy(function (a, b) {
      return this.coordinates(b);
    }, this)) : (this.settings.center ? (this.settings.rtl && (e = -1, f = b + 1), c = this._coordinates[b], c += (this.width() - c + (this._coordinates[f] || 0)) / 2 * e) : c = this._coordinates[f] || 0, c = Math.ceil(c));
  }, e.prototype.duration = function (a, b, c) {
    return 0 === c ? 0 : Math.min(Math.max(Math.abs(b - a), 1), 6) * Math.abs(c || this.settings.smartSpeed);
  }, e.prototype.to = function (a, b) {
    var c = this.current(),
        d = null,
        e = a - this.relative(c),
        f = (e > 0) - (e < 0),
        g = this._items.length,
        h = this.minimum(),
        i = this.maximum();this.settings.loop ? (!this.settings.rewind && Math.abs(e) > g / 2 && (e += f * -1 * g), a = c + e, d = ((a - h) % g + g) % g + h, d !== a && d - e <= i && d - e > 0 && (c = d - e, a = d, this.reset(c))) : this.settings.rewind ? (i += 1, a = (a % i + i) % i) : a = Math.max(h, Math.min(i, a)), this.speed(this.duration(c, a, b)), this.current(a), this.$element.is(":visible") && this.update();
  }, e.prototype.next = function (a) {
    a = a || !1, this.to(this.relative(this.current()) + 1, a);
  }, e.prototype.prev = function (a) {
    a = a || !1, this.to(this.relative(this.current()) - 1, a);
  }, e.prototype.onTransitionEnd = function (a) {
    if (a !== d && (a.stopPropagation(), (a.target || a.srcElement || a.originalTarget) !== this.$stage.get(0))) return !1;this.leave("animating"), this.trigger("translated");
  }, e.prototype.viewport = function () {
    var d;return this.options.responsiveBaseElement !== b ? d = a(this.options.responsiveBaseElement).width() : b.innerWidth ? d = b.innerWidth : c.documentElement && c.documentElement.clientWidth ? d = c.documentElement.clientWidth : console.warn("Can not detect viewport width."), d;
  }, e.prototype.replace = function (b) {
    this.$stage.empty(), this._items = [], b && (b = b instanceof jQuery ? b : a(b)), this.settings.nestedItemSelector && (b = b.find("." + this.settings.nestedItemSelector)), b.filter(function () {
      return 1 === this.nodeType;
    }).each(a.proxy(function (a, b) {
      b = this.prepare(b), this.$stage.append(b), this._items.push(b), this._mergers.push(1 * b.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1);
    }, this)), this.reset(this.isNumeric(this.settings.startPosition) ? this.settings.startPosition : 0), this.invalidate("items");
  }, e.prototype.add = function (b, c) {
    var e = this.relative(this._current);c = c === d ? this._items.length : this.normalize(c, !0), b = b instanceof jQuery ? b : a(b), this.trigger("add", { content: b, position: c }), b = this.prepare(b), 0 === this._items.length || c === this._items.length ? (0 === this._items.length && this.$stage.append(b), 0 !== this._items.length && this._items[c - 1].after(b), this._items.push(b), this._mergers.push(1 * b.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1)) : (this._items[c].before(b), this._items.splice(c, 0, b), this._mergers.splice(c, 0, 1 * b.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1)), this._items[e] && this.reset(this._items[e].index()), this.invalidate("items"), this.trigger("added", { content: b, position: c });
  }, e.prototype.remove = function (a) {
    a = this.normalize(a, !0), a !== d && (this.trigger("remove", { content: this._items[a], position: a }), this._items[a].remove(), this._items.splice(a, 1), this._mergers.splice(a, 1), this.invalidate("items"), this.trigger("removed", { content: null, position: a }));
  }, e.prototype.preloadAutoWidthImages = function (b) {
    b.each(a.proxy(function (b, c) {
      this.enter("pre-loading"), c = a(c), a(new Image()).one("load", a.proxy(function (a) {
        c.attr("src", a.target.src), c.css("opacity", 1), this.leave("pre-loading"), !this.is("pre-loading") && !this.is("initializing") && this.refresh();
      }, this)).attr("src", c.attr("src") || c.attr("data-src") || c.attr("data-src-retina"));
    }, this));
  }, e.prototype.destroy = function () {
    this.$element.off(".owl.core"), this.$stage.off(".owl.core"), a(c).off(".owl.core"), this.settings.responsive !== !1 && (b.clearTimeout(this.resizeTimer), this.off(b, "resize", this._handlers.onThrottledResize));for (var d in this._plugins) {
      this._plugins[d].destroy();
    }this.$stage.children(".cloned").remove(), this.$stage.unwrap(), this.$stage.children().contents().unwrap(), this.$stage.children().unwrap(), this.$element.removeClass(this.options.refreshClass).removeClass(this.options.loadingClass).removeClass(this.options.loadedClass).removeClass(this.options.rtlClass).removeClass(this.options.dragClass).removeClass(this.options.grabClass).attr("class", this.$element.attr("class").replace(new RegExp(this.options.responsiveClass + "-\\S+\\s", "g"), "")).removeData("owl.carousel");
  }, e.prototype.op = function (a, b, c) {
    var d = this.settings.rtl;switch (b) {case "<":
        return d ? a > c : a < c;case ">":
        return d ? a < c : a > c;case ">=":
        return d ? a <= c : a >= c;case "<=":
        return d ? a >= c : a <= c;}
  }, e.prototype.on = function (a, b, c, d) {
    a.addEventListener ? a.addEventListener(b, c, d) : a.attachEvent && a.attachEvent("on" + b, c);
  }, e.prototype.off = function (a, b, c, d) {
    a.removeEventListener ? a.removeEventListener(b, c, d) : a.detachEvent && a.detachEvent("on" + b, c);
  }, e.prototype.trigger = function (b, c, d, f, g) {
    var h = { item: { count: this._items.length, index: this.current() } },
        i = a.camelCase(a.grep(["on", b, d], function (a) {
      return a;
    }).join("-").toLowerCase()),
        j = a.Event([b, "owl", d || "carousel"].join(".").toLowerCase(), a.extend({ relatedTarget: this }, h, c));return this._supress[b] || (a.each(this._plugins, function (a, b) {
      b.onTrigger && b.onTrigger(j);
    }), this.register({ type: e.Type.Event, name: b }), this.$element.trigger(j), this.settings && "function" == typeof this.settings[i] && this.settings[i].call(this, j)), j;
  }, e.prototype.enter = function (b) {
    a.each([b].concat(this._states.tags[b] || []), a.proxy(function (a, b) {
      this._states.current[b] === d && (this._states.current[b] = 0), this._states.current[b]++;
    }, this));
  }, e.prototype.leave = function (b) {
    a.each([b].concat(this._states.tags[b] || []), a.proxy(function (a, b) {
      this._states.current[b]--;
    }, this));
  }, e.prototype.register = function (b) {
    if (b.type === e.Type.Event) {
      if (a.event.special[b.name] || (a.event.special[b.name] = {}), !a.event.special[b.name].owl) {
        var c = a.event.special[b.name]._default;a.event.special[b.name]._default = function (a) {
          return !c || !c.apply || a.namespace && a.namespace.indexOf("owl") !== -1 ? a.namespace && a.namespace.indexOf("owl") > -1 : c.apply(this, arguments);
        }, a.event.special[b.name].owl = !0;
      }
    } else b.type === e.Type.State && (this._states.tags[b.name] ? this._states.tags[b.name] = this._states.tags[b.name].concat(b.tags) : this._states.tags[b.name] = b.tags, this._states.tags[b.name] = a.grep(this._states.tags[b.name], a.proxy(function (c, d) {
      return a.inArray(c, this._states.tags[b.name]) === d;
    }, this)));
  }, e.prototype.suppress = function (b) {
    a.each(b, a.proxy(function (a, b) {
      this._supress[b] = !0;
    }, this));
  }, e.prototype.release = function (b) {
    a.each(b, a.proxy(function (a, b) {
      delete this._supress[b];
    }, this));
  }, e.prototype.pointer = function (a) {
    var c = { x: null, y: null };return a = a.originalEvent || a || b.event, a = a.touches && a.touches.length ? a.touches[0] : a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : a, a.pageX ? (c.x = a.pageX, c.y = a.pageY) : (c.x = a.clientX, c.y = a.clientY), c;
  }, e.prototype.isNumeric = function (a) {
    return !isNaN(parseFloat(a));
  }, e.prototype.difference = function (a, b) {
    return { x: a.x - b.x, y: a.y - b.y };
  }, a.fn.owlCarousel = function (b) {
    var c = Array.prototype.slice.call(arguments, 1);return this.each(function () {
      var d = a(this),
          f = d.data("owl.carousel");f || (f = new e(this, "object" == (typeof b === "undefined" ? "undefined" : _typeof(b)) && b), d.data("owl.carousel", f), a.each(["next", "prev", "to", "destroy", "refresh", "replace", "add", "remove"], function (b, c) {
        f.register({ type: e.Type.Event, name: c }), f.$element.on(c + ".owl.carousel.core", a.proxy(function (a) {
          a.namespace && a.relatedTarget !== this && (this.suppress([c]), f[c].apply(this, [].slice.call(arguments, 1)), this.release([c]));
        }, f));
      })), "string" == typeof b && "_" !== b.charAt(0) && f[b].apply(f, c);
    });
  }, a.fn.owlCarousel.Constructor = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this._core = b, this._interval = null, this._visible = null, this._handlers = { "initialized.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.autoRefresh && this.watch();
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers);
  };e.Defaults = { autoRefresh: !0, autoRefreshInterval: 500 }, e.prototype.watch = function () {
    this._interval || (this._visible = this._core.$element.is(":visible"), this._interval = b.setInterval(a.proxy(this.refresh, this), this._core.settings.autoRefreshInterval));
  }, e.prototype.refresh = function () {
    this._core.$element.is(":visible") !== this._visible && (this._visible = !this._visible, this._core.$element.toggleClass("owl-hidden", !this._visible), this._visible && this._core.invalidate("width") && this._core.refresh());
  }, e.prototype.destroy = function () {
    var a, c;b.clearInterval(this._interval);for (a in this._handlers) {
      this._core.$element.off(a, this._handlers[a]);
    }for (c in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[c] && (this[c] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.AutoRefresh = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this._core = b, this._loaded = [], this._handlers = { "initialized.owl.carousel change.owl.carousel resized.owl.carousel": a.proxy(function (b) {
        if (b.namespace && this._core.settings && this._core.settings.lazyLoad && (b.property && "position" == b.property.name || "initialized" == b.type)) for (var c = this._core.settings, e = c.center && Math.ceil(c.items / 2) || c.items, f = c.center && e * -1 || 0, g = (b.property && b.property.value !== d ? b.property.value : this._core.current()) + f, h = this._core.clones().length, i = a.proxy(function (a, b) {
          this.load(b);
        }, this); f++ < e;) {
          this.load(h / 2 + this._core.relative(g)), h && a.each(this._core.clones(this._core.relative(g)), i), g++;
        }
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers);
  };e.Defaults = { lazyLoad: !1 }, e.prototype.load = function (c) {
    var d = this._core.$stage.children().eq(c),
        e = d && d.find(".owl-lazy");!e || a.inArray(d.get(0), this._loaded) > -1 || (e.each(a.proxy(function (c, d) {
      var e,
          f = a(d),
          g = b.devicePixelRatio > 1 && f.attr("data-src-retina") || f.attr("data-src");this._core.trigger("load", { element: f, url: g }, "lazy"), f.is("img") ? f.one("load.owl.lazy", a.proxy(function () {
        f.css("opacity", 1), this._core.trigger("loaded", { element: f, url: g }, "lazy");
      }, this)).attr("src", g) : (e = new Image(), e.onload = a.proxy(function () {
        f.css({ "background-image": 'url("' + g + '")', opacity: "1" }), this._core.trigger("loaded", { element: f, url: g }, "lazy");
      }, this), e.src = g);
    }, this)), this._loaded.push(d.get(0)));
  }, e.prototype.destroy = function () {
    var a, b;for (a in this.handlers) {
      this._core.$element.off(a, this.handlers[a]);
    }for (b in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[b] && (this[b] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.Lazy = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this._core = b, this._handlers = { "initialized.owl.carousel refreshed.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.autoHeight && this.update();
      }, this), "changed.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.autoHeight && "position" == a.property.name && this.update();
      }, this), "loaded.owl.lazy": a.proxy(function (a) {
        a.namespace && this._core.settings.autoHeight && a.element.closest("." + this._core.settings.itemClass).index() === this._core.current() && this.update();
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers);
  };e.Defaults = { autoHeight: !1, autoHeightClass: "owl-height" }, e.prototype.update = function () {
    var b = this._core._current,
        c = b + this._core.settings.items,
        d = this._core.$stage.children().toArray().slice(b, c),
        e = [],
        f = 0;a.each(d, function (b, c) {
      e.push(a(c).height());
    }), f = Math.max.apply(null, e), this._core.$stage.parent().height(f).addClass(this._core.settings.autoHeightClass);
  }, e.prototype.destroy = function () {
    var a, b;for (a in this._handlers) {
      this._core.$element.off(a, this._handlers[a]);
    }for (b in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[b] && (this[b] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.AutoHeight = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this._core = b, this._videos = {}, this._playing = null, this._handlers = { "initialized.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.register({ type: "state", name: "playing", tags: ["interacting"] });
      }, this), "resize.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.video && this.isInFullScreen() && a.preventDefault();
      }, this), "refreshed.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.is("resizing") && this._core.$stage.find(".cloned .owl-video-frame").remove();
      }, this), "changed.owl.carousel": a.proxy(function (a) {
        a.namespace && "position" === a.property.name && this._playing && this.stop();
      }, this), "prepared.owl.carousel": a.proxy(function (b) {
        if (b.namespace) {
          var c = a(b.content).find(".owl-video");c.length && (c.css("display", "none"), this.fetch(c, a(b.content)));
        }
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers), this._core.$element.on("click.owl.video", ".owl-video-play-icon", a.proxy(function (a) {
      this.play(a);
    }, this));
  };e.Defaults = { video: !1, videoHeight: !1, videoWidth: !1 }, e.prototype.fetch = function (a, b) {
    var c = function () {
      return a.attr("data-vimeo-id") ? "vimeo" : a.attr("data-vzaar-id") ? "vzaar" : "youtube";
    }(),
        d = a.attr("data-vimeo-id") || a.attr("data-youtube-id") || a.attr("data-vzaar-id"),
        e = a.attr("data-width") || this._core.settings.videoWidth,
        f = a.attr("data-height") || this._core.settings.videoHeight,
        g = a.attr("href");if (!g) throw new Error("Missing video URL.");if (d = g.match(/(http:|https:|)\/\/(player.|www.|app.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com)|vzaar\.com)\/(video\/|videos\/|embed\/|channels\/.+\/|groups\/.+\/|watch\?v=|v\/)?([A-Za-z0-9._%-]*)(\&\S+)?/), d[3].indexOf("youtu") > -1) c = "youtube";else if (d[3].indexOf("vimeo") > -1) c = "vimeo";else {
      if (!(d[3].indexOf("vzaar") > -1)) throw new Error("Video URL not supported.");c = "vzaar";
    }d = d[6], this._videos[g] = { type: c, id: d, width: e, height: f }, b.attr("data-video", g), this.thumbnail(a, this._videos[g]);
  }, e.prototype.thumbnail = function (b, c) {
    var d,
        e,
        f,
        g = c.width && c.height ? 'style="width:' + c.width + "px;height:" + c.height + 'px;"' : "",
        h = b.find("img"),
        i = "src",
        j = "",
        k = this._core.settings,
        l = function l(a) {
      e = '<div class="owl-video-play-icon"></div>', d = k.lazyLoad ? '<div class="owl-video-tn ' + j + '" ' + i + '="' + a + '"></div>' : '<div class="owl-video-tn" style="opacity:1;background-image:url(' + a + ')"></div>', b.after(d), b.after(e);
    };if (b.wrap('<div class="owl-video-wrapper"' + g + "></div>"), this._core.settings.lazyLoad && (i = "data-src", j = "owl-lazy"), h.length) return l(h.attr(i)), h.remove(), !1;"youtube" === c.type ? (f = "//img.youtube.com/vi/" + c.id + "/hqdefault.jpg", l(f)) : "vimeo" === c.type ? a.ajax({ type: "GET", url: "//vimeo.com/api/v2/video/" + c.id + ".json", jsonp: "callback", dataType: "jsonp", success: function success(a) {
        f = a[0].thumbnail_large, l(f);
      } }) : "vzaar" === c.type && a.ajax({ type: "GET", url: "//vzaar.com/api/videos/" + c.id + ".json", jsonp: "callback", dataType: "jsonp", success: function success(a) {
        f = a.framegrab_url, l(f);
      } });
  }, e.prototype.stop = function () {
    this._core.trigger("stop", null, "video"), this._playing.find(".owl-video-frame").remove(), this._playing.removeClass("owl-video-playing"), this._playing = null, this._core.leave("playing"), this._core.trigger("stopped", null, "video");
  }, e.prototype.play = function (b) {
    var c,
        d = a(b.target),
        e = d.closest("." + this._core.settings.itemClass),
        f = this._videos[e.attr("data-video")],
        g = f.width || "100%",
        h = f.height || this._core.$stage.height();this._playing || (this._core.enter("playing"), this._core.trigger("play", null, "video"), e = this._core.items(this._core.relative(e.index())), this._core.reset(e.index()), "youtube" === f.type ? c = '<iframe width="' + g + '" height="' + h + '" src="//www.youtube.com/embed/' + f.id + "?autoplay=1&rel=0&v=" + f.id + '" frameborder="0" allowfullscreen></iframe>' : "vimeo" === f.type ? c = '<iframe src="//player.vimeo.com/video/' + f.id + '?autoplay=1" width="' + g + '" height="' + h + '" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>' : "vzaar" === f.type && (c = '<iframe frameborder="0"height="' + h + '"width="' + g + '" allowfullscreen mozallowfullscreen webkitAllowFullScreen src="//view.vzaar.com/' + f.id + '/player?autoplay=true"></iframe>'), a('<div class="owl-video-frame">' + c + "</div>").insertAfter(e.find(".owl-video")), this._playing = e.addClass("owl-video-playing"));
  }, e.prototype.isInFullScreen = function () {
    var b = c.fullscreenElement || c.mozFullScreenElement || c.webkitFullscreenElement;return b && a(b).parent().hasClass("owl-video-frame");
  }, e.prototype.destroy = function () {
    var a, b;this._core.$element.off("click.owl.video");for (a in this._handlers) {
      this._core.$element.off(a, this._handlers[a]);
    }for (b in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[b] && (this[b] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.Video = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this.core = b, this.core.options = a.extend({}, e.Defaults, this.core.options), this.swapping = !0, this.previous = d, this.next = d, this.handlers = { "change.owl.carousel": a.proxy(function (a) {
        a.namespace && "position" == a.property.name && (this.previous = this.core.current(), this.next = a.property.value);
      }, this), "drag.owl.carousel dragged.owl.carousel translated.owl.carousel": a.proxy(function (a) {
        a.namespace && (this.swapping = "translated" == a.type);
      }, this), "translate.owl.carousel": a.proxy(function (a) {
        a.namespace && this.swapping && (this.core.options.animateOut || this.core.options.animateIn) && this.swap();
      }, this) }, this.core.$element.on(this.handlers);
  };e.Defaults = { animateOut: !1, animateIn: !1 }, e.prototype.swap = function () {
    if (1 === this.core.settings.items && a.support.animation && a.support.transition) {
      this.core.speed(0);var b,
          c = a.proxy(this.clear, this),
          d = this.core.$stage.children().eq(this.previous),
          e = this.core.$stage.children().eq(this.next),
          f = this.core.settings.animateIn,
          g = this.core.settings.animateOut;this.core.current() !== this.previous && (g && (b = this.core.coordinates(this.previous) - this.core.coordinates(this.next), d.one(a.support.animation.end, c).css({ left: b + "px" }).addClass("animated owl-animated-out").addClass(g)), f && e.one(a.support.animation.end, c).addClass("animated owl-animated-in").addClass(f));
    }
  }, e.prototype.clear = function (b) {
    a(b.target).css({ left: "" }).removeClass("animated owl-animated-out owl-animated-in").removeClass(this.core.settings.animateIn).removeClass(this.core.settings.animateOut), this.core.onTransitionEnd();
  }, e.prototype.destroy = function () {
    var a, b;for (a in this.handlers) {
      this.core.$element.off(a, this.handlers[a]);
    }for (b in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[b] && (this[b] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.Animate = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this._core = b, this._timeout = null, this._paused = !1, this._handlers = { "changed.owl.carousel": a.proxy(function (a) {
        a.namespace && "settings" === a.property.name ? this._core.settings.autoplay ? this.play() : this.stop() : a.namespace && "position" === a.property.name && this._core.settings.autoplay && this._setAutoPlayInterval();
      }, this), "initialized.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.autoplay && this.play();
      }, this), "play.owl.autoplay": a.proxy(function (a, b, c) {
        a.namespace && this.play(b, c);
      }, this), "stop.owl.autoplay": a.proxy(function (a) {
        a.namespace && this.stop();
      }, this), "mouseover.owl.autoplay": a.proxy(function () {
        this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.pause();
      }, this), "mouseleave.owl.autoplay": a.proxy(function () {
        this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.play();
      }, this), "touchstart.owl.core": a.proxy(function () {
        this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.pause();
      }, this), "touchend.owl.core": a.proxy(function () {
        this._core.settings.autoplayHoverPause && this.play();
      }, this) }, this._core.$element.on(this._handlers), this._core.options = a.extend({}, e.Defaults, this._core.options);
  };e.Defaults = { autoplay: !1, autoplayTimeout: 5e3, autoplayHoverPause: !1, autoplaySpeed: !1 }, e.prototype.play = function (a, b) {
    this._paused = !1, this._core.is("rotating") || (this._core.enter("rotating"), this._setAutoPlayInterval());
  }, e.prototype._getNextTimeout = function (d, e) {
    return this._timeout && b.clearTimeout(this._timeout), b.setTimeout(a.proxy(function () {
      this._paused || this._core.is("busy") || this._core.is("interacting") || c.hidden || this._core.next(e || this._core.settings.autoplaySpeed);
    }, this), d || this._core.settings.autoplayTimeout);
  }, e.prototype._setAutoPlayInterval = function () {
    this._timeout = this._getNextTimeout();
  }, e.prototype.stop = function () {
    this._core.is("rotating") && (b.clearTimeout(this._timeout), this._core.leave("rotating"));
  }, e.prototype.pause = function () {
    this._core.is("rotating") && (this._paused = !0);
  }, e.prototype.destroy = function () {
    var a, b;this.stop();for (a in this._handlers) {
      this._core.$element.off(a, this._handlers[a]);
    }for (b in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[b] && (this[b] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.autoplay = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  "use strict";
  var e = function e(b) {
    this._core = b, this._initialized = !1, this._pages = [], this._controls = {}, this._templates = [], this.$element = this._core.$element, this._overrides = { next: this._core.next, prev: this._core.prev, to: this._core.to }, this._handlers = { "prepared.owl.carousel": a.proxy(function (b) {
        b.namespace && this._core.settings.dotsData && this._templates.push('<div class="' + this._core.settings.dotClass + '">' + a(b.content).find("[data-dot]").addBack("[data-dot]").attr("data-dot") + "</div>");
      }, this), "added.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.dotsData && this._templates.splice(a.position, 0, this._templates.pop());
      }, this), "remove.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.dotsData && this._templates.splice(a.position, 1);
      }, this), "changed.owl.carousel": a.proxy(function (a) {
        a.namespace && "position" == a.property.name && this.draw();
      }, this), "initialized.owl.carousel": a.proxy(function (a) {
        a.namespace && !this._initialized && (this._core.trigger("initialize", null, "navigation"), this.initialize(), this.update(), this.draw(), this._initialized = !0, this._core.trigger("initialized", null, "navigation"));
      }, this), "refreshed.owl.carousel": a.proxy(function (a) {
        a.namespace && this._initialized && (this._core.trigger("refresh", null, "navigation"), this.update(), this.draw(), this._core.trigger("refreshed", null, "navigation"));
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this.$element.on(this._handlers);
  };e.Defaults = { nav: !1, navText: ["prev", "next"], navSpeed: !1, navElement: "div", navContainer: !1, navContainerClass: "owl-nav", navClass: ["owl-prev", "owl-next"], slideBy: 1, dotClass: "owl-dot", dotsClass: "owl-dots", dots: !0, dotsEach: !1, dotsData: !1, dotsSpeed: !1, dotsContainer: !1 }, e.prototype.initialize = function () {
    var b,
        c = this._core.settings;this._controls.$relative = (c.navContainer ? a(c.navContainer) : a("<div>").addClass(c.navContainerClass).appendTo(this.$element)).addClass("disabled"), this._controls.$previous = a("<" + c.navElement + ">").addClass(c.navClass[0]).html(c.navText[0]).prependTo(this._controls.$relative).on("click", a.proxy(function (a) {
      this.prev(c.navSpeed);
    }, this)), this._controls.$next = a("<" + c.navElement + ">").addClass(c.navClass[1]).html(c.navText[1]).appendTo(this._controls.$relative).on("click", a.proxy(function (a) {
      this.next(c.navSpeed);
    }, this)), c.dotsData || (this._templates = [a("<div>").addClass(c.dotClass).append(a("<span>")).prop("outerHTML")]), this._controls.$absolute = (c.dotsContainer ? a(c.dotsContainer) : a("<div>").addClass(c.dotsClass).appendTo(this.$element)).addClass("disabled"), this._controls.$absolute.on("click", "div", a.proxy(function (b) {
      var d = a(b.target).parent().is(this._controls.$absolute) ? a(b.target).index() : a(b.target).parent().index();b.preventDefault(), this.to(d, c.dotsSpeed);
    }, this));for (b in this._overrides) {
      this._core[b] = a.proxy(this[b], this);
    }
  }, e.prototype.destroy = function () {
    var a, b, c, d;for (a in this._handlers) {
      this.$element.off(a, this._handlers[a]);
    }for (b in this._controls) {
      this._controls[b].remove();
    }for (d in this.overides) {
      this._core[d] = this._overrides[d];
    }for (c in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[c] && (this[c] = null);
    }
  }, e.prototype.update = function () {
    var a,
        b,
        c,
        d = this._core.clones().length / 2,
        e = d + this._core.items().length,
        f = this._core.maximum(!0),
        g = this._core.settings,
        h = g.center || g.autoWidth || g.dotsData ? 1 : g.dotsEach || g.items;if ("page" !== g.slideBy && (g.slideBy = Math.min(g.slideBy, g.items)), g.dots || "page" == g.slideBy) for (this._pages = [], a = d, b = 0, c = 0; a < e; a++) {
      if (b >= h || 0 === b) {
        if (this._pages.push({ start: Math.min(f, a - d), end: a - d + h - 1 }), Math.min(f, a - d) === f) break;b = 0, ++c;
      }b += this._core.mergers(this._core.relative(a));
    }
  }, e.prototype.draw = function () {
    var b,
        c = this._core.settings,
        d = this._core.items().length <= c.items,
        e = this._core.relative(this._core.current()),
        f = c.loop || c.rewind;this._controls.$relative.toggleClass("disabled", !c.nav || d), c.nav && (this._controls.$previous.toggleClass("disabled", !f && e <= this._core.minimum(!0)), this._controls.$next.toggleClass("disabled", !f && e >= this._core.maximum(!0))), this._controls.$absolute.toggleClass("disabled", !c.dots || d), c.dots && (b = this._pages.length - this._controls.$absolute.children().length, c.dotsData && 0 !== b ? this._controls.$absolute.html(this._templates.join("")) : b > 0 ? this._controls.$absolute.append(new Array(b + 1).join(this._templates[0])) : b < 0 && this._controls.$absolute.children().slice(b).remove(), this._controls.$absolute.find(".active").removeClass("active"), this._controls.$absolute.children().eq(a.inArray(this.current(), this._pages)).addClass("active"));
  }, e.prototype.onTrigger = function (b) {
    var c = this._core.settings;b.page = { index: a.inArray(this.current(), this._pages), count: this._pages.length, size: c && (c.center || c.autoWidth || c.dotsData ? 1 : c.dotsEach || c.items) };
  }, e.prototype.current = function () {
    var b = this._core.relative(this._core.current());return a.grep(this._pages, a.proxy(function (a, c) {
      return a.start <= b && a.end >= b;
    }, this)).pop();
  }, e.prototype.getPosition = function (b) {
    var c,
        d,
        e = this._core.settings;return "page" == e.slideBy ? (c = a.inArray(this.current(), this._pages), d = this._pages.length, b ? ++c : --c, c = this._pages[(c % d + d) % d].start) : (c = this._core.relative(this._core.current()), d = this._core.items().length, b ? c += e.slideBy : c -= e.slideBy), c;
  }, e.prototype.next = function (b) {
    a.proxy(this._overrides.to, this._core)(this.getPosition(!0), b);
  }, e.prototype.prev = function (b) {
    a.proxy(this._overrides.to, this._core)(this.getPosition(!1), b);
  }, e.prototype.to = function (b, c, d) {
    var e;!d && this._pages.length ? (e = this._pages.length, a.proxy(this._overrides.to, this._core)(this._pages[(b % e + e) % e].start, c)) : a.proxy(this._overrides.to, this._core)(b, c);
  }, a.fn.owlCarousel.Constructor.Plugins.Navigation = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  "use strict";
  var e = function e(c) {
    this._core = c, this._hashes = {}, this.$element = this._core.$element, this._handlers = { "initialized.owl.carousel": a.proxy(function (c) {
        c.namespace && "URLHash" === this._core.settings.startPosition && a(b).trigger("hashchange.owl.navigation");
      }, this), "prepared.owl.carousel": a.proxy(function (b) {
        if (b.namespace) {
          var c = a(b.content).find("[data-hash]").addBack("[data-hash]").attr("data-hash");if (!c) return;this._hashes[c] = b.content;
        }
      }, this), "changed.owl.carousel": a.proxy(function (c) {
        if (c.namespace && "position" === c.property.name) {
          var d = this._core.items(this._core.relative(this._core.current())),
              e = a.map(this._hashes, function (a, b) {
            return a === d ? b : null;
          }).join();if (!e || b.location.hash.slice(1) === e) return;b.location.hash = e;
        }
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this.$element.on(this._handlers), a(b).on("hashchange.owl.navigation", a.proxy(function (a) {
      var c = b.location.hash.substring(1),
          e = this._core.$stage.children(),
          f = this._hashes[c] && e.index(this._hashes[c]);f !== d && f !== this._core.current() && this._core.to(this._core.relative(f), !1, !0);
    }, this));
  };e.Defaults = { URLhashListener: !1 }, e.prototype.destroy = function () {
    var c, d;a(b).off("hashchange.owl.navigation");for (c in this._handlers) {
      this._core.$element.off(c, this._handlers[c]);
    }for (d in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[d] && (this[d] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.Hash = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  function e(b, c) {
    var e = !1,
        f = b.charAt(0).toUpperCase() + b.slice(1);return a.each((b + " " + h.join(f + " ") + f).split(" "), function (a, b) {
      if (g[b] !== d) return e = !c || b, !1;
    }), e;
  }function f(a) {
    return e(a, !0);
  }var g = a("<support>").get(0).style,
      h = "Webkit Moz O ms".split(" "),
      i = { transition: { end: { WebkitTransition: "webkitTransitionEnd", MozTransition: "transitionend", OTransition: "oTransitionEnd", transition: "transitionend" } }, animation: { end: { WebkitAnimation: "webkitAnimationEnd", MozAnimation: "animationend", OAnimation: "oAnimationEnd", animation: "animationend" } } },
      j = { csstransforms: function csstransforms() {
      return !!e("transform");
    }, csstransforms3d: function csstransforms3d() {
      return !!e("perspective");
    }, csstransitions: function csstransitions() {
      return !!e("transition");
    }, cssanimations: function cssanimations() {
      return !!e("animation");
    } };j.csstransitions() && (a.support.transition = new String(f("transition")), a.support.transition.end = i.transition.end[a.support.transition]), j.cssanimations() && (a.support.animation = new String(f("animation")), a.support.animation.end = i.animation.end[a.support.animation]), j.csstransforms() && (a.support.transform = new String(f("transform")), a.support.transform3d = j.csstransforms3d());
}(window.Zepto || window.jQuery, window, document);
;"use strict";

var rootUrl = window.location.origin;
var templateUrl = themeUrl.templateUrl;
// console.log(templateUrl);
if (rootUrl === "http://localhost:3000" || rootUrl === "http://localhost:8888") {
  rootUrl = rootUrl + "/westtours/";
} else {
  rootUrl = window.location.origin;
}
;// //
// var rootUrl = window.location.origin;
// if(rootUrl === "http://localhost:3000" || rootUrl === "http://localhost:8888") {
//   rootUrl = rootUrl + "/westtours/";
// }else{
//   rootUrl = "test"+window.location.origin;
// }
//
// var categories = rootUrl+"/wp-json/wp/v2/categories?per_page=50";
// var bikeToursHttp = rootUrl+"/wp-json/wp/v2/tour_post_type?per_page=50";
// var customTest = rootUrl+"/wp-json/wp/v2/custom_api";
// var media = rootUrl+"/wp-json/wp/v2/media?per_page=50";
//
// console.log(rootUrl);
// var category = [];
//
// function shuffle (array) {
//   var i = 0;
//   var j = 0;
//   var temp = null;
//
//   for (i = array.length - 1; i > 0; i -= 1) {
//     j = Math.floor(Math.random() * (i + 1));
//     temp = array[i];
//     array[i] = array[j];
//     array[j] = temp;
//   }
// }
// $.getJSON(categories, function(result){
// category = result;
// // console.log(category);
// });
//
// var mediaObj =[];
// $.getJSON(media, function(result){
// mediaObj = result;
// });
// // JSONgetter is a way for multiple custom post calls from the wp rest
// var JSONgetter = function(http, resultname){
//   $.getJSON(http, function(resultname){
//     var popular = [];
//     var smallCards = [];
//     $.each(resultname, function(i, field){
//       if (field.acf.is_popular) {
//         popular.push(field);
//       }
//       smallCards.push(field);
//       //  console.log(field);
//
//      var option = "<option value='"+field.title.rendered+" "+field.acf.activety+"'><p>"+field.title.rendered+"</p>   <p>"+field.acf.activety+"</p></option>";
//
//      $('#activities-search').append(option);
//
//      });
//
//     shuffle(popular);
//       $.each(popular, function(i, popular){
//       var activety = popular.acf.activety.toLowerCase();
//       var season = popular.acf.season.toLowerCase();
//       var cardIcon = activety;
//       if (cardIcon == "animal life") {
//        cardIcon = "animal-life";
//       }
//       //  console.log('pop');
//       var iconClass = activety;
//
//       function getWords(parameter) {
//           return parameter.split(/\s+/).slice(0,4).join(" ")+"..";
//       }
//       var largeCardHeading = popular.title.rendered;
//
//       getWords(largeCardHeading);
//
//       var StrippedStringBig = popular.excerpt.rendered.replace(/(<([^>]+)>)/ig,"");
//       var shorterTextBig = StrippedStringBig.substr(0, 112) + "...";
//
//       var bigCard = "<div id='' class='card-large' role='article'><a href='"+popular.link+"'><div class='image' style='background-image:url("+popular.acf.info_img.sizes.large+");'><img src='' alt=''/></div><div class='icon' style='background-image:url("+rootUrl+"/wp-content/themes/foundationPressGit/assets/images/icons/catIcons/"+cardIcon+".svg);' ></div><p class='cat-string'> "+activety+" / "+season+" </p><header class='card-content article-header'><h2 class='entry-title single-title' itemprop='headline'>"+popular.title.rendered+"</h2><p>"+shorterTextBig+"</p></header><button type='button' class='readMoreBtn'>Read more</button></a></div>";
//
//       if (popular.acf.is_popular) {
//         $("#big-cards").append(bigCard);
//       }
//
//       return i < 1;
//      });
//       shuffle(smallCards);
//       $.each(smallCards, function(i, card){
//         var activety = card.acf.activety.toLowerCase();
//         var season = card.acf.season.toLowerCase();
//         var cardIcon = activety;
//         if (cardIcon == "animal life") {
//          cardIcon = "animal-life";
//         }
//         var iconClass = activety;
//
//         var smallerH2;
//         //  if (card.title.rendered.length > 21) {
//         //     smallerH2 = 'smallerH2';
//         //  }else{
//         //    smallerH2 = '';
//         //  }
//         function getWords(parameter, numWords) {
//           return parameter.split(/\s+/).slice(0,numWords).join(" ")+"..";
//         }
//
//         var cardHeading = card.title.rendered;
//         var inFewerWords = card.excerpt.rendered;
//         getWords(cardHeading, 3);
//
//         var StrippedString = card.excerpt.rendered.replace(/(<([^>]+)>)/ig,"");
//         var shorterText = StrippedString.substr(0, 48) + "...";
//
//         var smallCard = "<div class='small-12 medium-6 large-4 xlarge-3 card-container hidden'><div  class='card' role='article' ><a href='"+card.link+"'><div class='image' style='background-image:url("+card.acf.info_img.sizes.medium+");'><img src='' alt='' /></div><div class='icon icon-"+iconClass+"' style='background-image:url("+rootUrl+"/wp-content/themes/foundationPressGit/assets/images/icons/catIcons/"+cardIcon+".svg);' ></div><p class='cat-string'> "+activety+" / "+season+" </p><header class='card-content article-header'><h2 class='entry-title single-title "+smallerH2+"' itemprop='headline'>"+getWords(cardHeading, 3)+"</h2><p>"+shorterText+"</p></header><button type='button' class='bookBtn'>Book</button></a></div></div>";
//
//
//         if(!popular.acf.is_popular)
//         {
//           $("#cards").append(smallCard);
//         }
//       });
//   });
// };
// // setTimeout("JSONgetter(bikeToursHttp, 'bikeObject')",200);
// JSONgetter(bikeToursHttp, 'bikeObject');
// function loadMore(){
//         $("#cards .hidden").slice(0,4).removeClass("hidden");
//     }
// setTimeout(function() { loadMore(); }, 1500);
// $(".show-more").on("click",loadMore);
//
// // JSONgetter(customTest, 'test');
"use strict";
;// function apiCall(path, data){
//   jQuery.post(path, data, function(res){
//     // console.log(res);
//     var jPostRes = JSON.parse(res);
//     console.log(jPostRes);
//   });
// }
//
// var elBody = document.querySelector('body');
//
// if(elBody.classList.contains('single-tour_post_type')) {
//   var post = document.querySelector('article');
//   var postId = post.getAttribute('data-tourid');
//   var postData = {"data": postId};
//   // console.dir(postId);
//   apiCall(rootUrl+'wp-content/themes/foundationPressGit/library/api/call-by-id.php', postData);
// }

// function sendCardId(){
//   // console.log('x');
//   document.addEventListener('click', function(e){
//     // console.log(e.target);
//     if(e.target.classList.contains('btnCard')) {
//       var sGetTourId = e.target.getAttribute('data-tripid');
//       var jSendTourID = {"data":sGetTourId};
//       apiCall(rootUrl+'wp-content/themes/foundationPressGit/library/api/call-by-id.php', jSendTourID);
//       // console.log(getTourId);
//     }
//   });
// }
//
// sendCardId();
"use strict";
;'use strict';

// console.log(rootUrl);

// console.log(sSearchString);

$.getJSON(templateUrl + "/library/detailedtrips.json", function (data) {
  $('#activitiesSearch').on('keyup', function () {

    var sSearchString = $(this).val();
    var aItems = [];
    // console.log(typeof sSearchString);
    // sResultsDropdown.innerHTML = "";
    var title = '';
    var mainActivety = "";
    var tripDescription = "";
    var season = "";
    var allActiveties = [];
    var trips = data.trips;
    var allActivToLowerCase = "";
    // console.log(trips);
    for (var i = 0; i < trips.length; i++) {
      title = trips[i].title.toLowerCase();
      tripDescription = trips[i].description.toLowerCase();
      mainActivety = trips[i].activityCategories[0];
      allActiveties = trips[i].activityCategories;
      season = trips[i].season.toLowerCase();

      for (var t = 0; t < allActiveties.length; t++) {
        allActivToLowerCase = allActiveties[t].replace(/_/g, " ").toLowerCase();
        // console.log(allActivToLowerCase);
        if ((title.includes(sSearchString.toLowerCase()) || tripDescription.includes(sSearchString.toLowerCase()) || allActivToLowerCase.includes(sSearchString.toLowerCase()) || season.includes(sSearchString.toLowerCase())) && sSearchString !== " " && sSearchString.length > 0) {
          // console.log(trips[i]);
          sResultsDropdown.classList.add('searchActive');
          aItems.push(trips[i]);
        }
        // else {
        //     sResultsDropdown.classList.remove('searchActive');
        // }
        if (sResultsDropdown.offsetHeight > 21) {

          sResultsDropdown.classList.remove('searchActive');
        }
        // else {
        //   sResultsDropdown.classList.add('searchActive');
        // }
      }
    }
    var resultTitle = '';
    var resultActivety = '';

    var filteredArray = aItems.filter(function (item, pos) {
      return aItems.indexOf(item) == pos;
    });
    // console.log(aItems);
    var sResultRender = "";
    // console.log(filteredArray);

    for (var j = 0; j < filteredArray.length; j++) {
      // console.log(filteredArray[j].title);
      resultTitle = filteredArray[j].title;
      resultActivety = filteredArray[j].season;
      sResultRender += '<div class="resultItem" data-tripid="' + filteredArray[j].id + '"><span class="sSearchVal">' + resultTitle + '</span><span class="result_season sSearchVal">' + resultActivety.replace(/_/g, " ") + '</span></div>';
    }
    // console.log(sResultRender);
    sResultsDropdown.innerHTML = sResultRender;
  });
});

document.addEventListener('click', function (e) {
  // console.log(e.target);
  if (e.target.classList.contains('sSearchVal')) {
    // console.log('x');
    var parentID = e.target.parentElement.getAttribute('data-tripid');
    // $('#activitiesSearch').val() = parentID;
    widget_id.value = parentID;
    // console.log(parentID);
  }
});
;"use strict";

jQuery(document).foundation();
;'use strict';

// Joyride demo
$('#start-jr').on('click', function () {
  $(document).foundation('joyride', 'start');
});
;'use strict';

function resize(event) {
  // console.log(event);
  owl.trigger('destroy.owl.carousel');
}
if (window.innerWidth <= 1024) {
  var owl = $('#cards');
  owl.owlCarousel({
    dots: false,
    responsive: {
      0: {
        items: 1,
        nav: false,
        loop: true,
        stagePadding: 30,
        dots: false
      },
      640: {
        items: 2,
        nav: false,
        loop: true,
        stagePadding: 10,
        dots: false
      },
      1024: {
        items: 2,
        nav: false,
        loop: true,
        stagePadding: 35,
        dots: false,
        onResize: resize
      }
    }
  });
}

var postOwl = $('#cardsPost');
postOwl.owlCarousel({
  items: 1,
  nav: false,
  loop: true,
  stagePadding: 10,
  dots: false,
  autoplay: true,

  responsive: {
    0: {
      items: 1,
      nav: false,
      loop: true,
      stagePadding: 30,
      dots: false
    },
    640: {
      items: 2,
      nav: false,
      loop: true,
      stagePadding: 90,
      dots: false
    },
    1024: {
      items: 3,
      nav: false,
      loop: true,
      stagePadding: 10,
      dots: false
      // onResize: resize
    },
    1200: {
      items: 4,
      nav: false,
      loop: true,
      stagePadding: 10,
      dots: false
      // onResize: resize
    }
  }
});

// $(window).resize(function(){
//   console.log('x');
//   if(window.innerWidth <= 1024) {
//      owl.trigger('destroy.owl.carousel');
//   }
//
// })
;"use strict";
;'use strict';

$(document).ready(function () {
    var videos = $('iframe[src*="vimeo.com"], iframe[src*="youtube.com"]');

    videos.each(function () {
        var el = $(this);
        el.wrap('<div class="responsive-embed widescreen"/>');
    });
});
;'use strict';

var onScroll = function onScroll(container, theclass, amount) {
	var wrap = $(container);
	$(window).scroll(function () {
		if ($(document).scrollTop() > amount) {
			wrap.addClass(theclass);
		} else {
			wrap.removeClass(theclass);
		}
	});
};

onScroll('.main-nav-container', 'set-nav-position', 1);

$('.call').click(function () {
	$('.burger').toggleClass('thex');
	$('body').toggleClass('stop-scrolling');
	// $('#offCanvas').toggleClass('position-left');
	//  $(document).foundation();
});

$('.is-accordion-submenu-parent').click(function () {
	// $('body').toggleClass('stop-scrolling');
});

$('.is-dropdown-submenu-parent').mouseover(function () {
	$('.first-sub').toggleClass('menu-animation');
});

$('.filterbutton').on('click', function () {
	$('#navActivety').addClass('showNavActivety');
	$('body').addClass('stop-scrolling');
});

$('#closeActivetyNav').on('click', function () {
	$('#navActivety').removeClass('showNavActivety');
	$('body').removeClass('stop-scrolling');
});
;'use strict';

$(window).bind(' load resize orientationChange ', function () {
  var footer = $("#footer-container");
  var pos = footer.position();
  var height = $(window).height();
  height = height - pos.top;
  height = height - footer.height() - 1;

  function stickyFooter() {
    footer.css({
      'margin-top': height + 'px'
    });
  }

  if (height > 0) {
    stickyFooter();
  }
});
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvdW5kYXRpb24uY29yZS5qcyIsImZvdW5kYXRpb24udXRpbC5ib3guanMiLCJmb3VuZGF0aW9uLnV0aWwua2V5Ym9hcmQuanMiLCJmb3VuZGF0aW9uLnV0aWwubWVkaWFRdWVyeS5qcyIsImZvdW5kYXRpb24udXRpbC5tb3Rpb24uanMiLCJmb3VuZGF0aW9uLnV0aWwubmVzdC5qcyIsImZvdW5kYXRpb24udXRpbC50aW1lckFuZEltYWdlTG9hZGVyLmpzIiwiZm91bmRhdGlvbi51dGlsLnRvdWNoLmpzIiwiZm91bmRhdGlvbi51dGlsLnRyaWdnZXJzLmpzIiwiZm91bmRhdGlvbi5hY2NvcmRpb25NZW51LmpzIiwiZm91bmRhdGlvbi5kcmlsbGRvd24uanMiLCJmb3VuZGF0aW9uLmRyb3Bkb3duLmpzIiwiZm91bmRhdGlvbi5kcm9wZG93bk1lbnUuanMiLCJmb3VuZGF0aW9uLm9mZmNhbnZhcy5qcyIsImZvdW5kYXRpb24ucmVzcG9uc2l2ZU1lbnUuanMiLCJmb3VuZGF0aW9uLnJlc3BvbnNpdmVUb2dnbGUuanMiLCJmb3VuZGF0aW9uLnRvZ2dsZXIuanMiLCJmb3VuZGF0aW9uLnRvb2x0aXAuanMiLCJvd2wuY2Fyb3VzZWwubWluLmpzIiwicm9vdHVybC5qcyIsImFwaS5qcyIsImJva3VuLWFwaS5qcyIsImZpbHRlci5qcyIsImluaXQtZm91bmRhdGlvbi5qcyIsImpveXJpZGUtZGVtby5qcyIsIm15LXNsaWNrLmpzIiwib2ZmQ2FudmFzLmpzIiwicmVzcG9uc2l2ZS12aWRlby5qcyIsInNjcmlwdHMuanMiLCJzdGlja3lmb290ZXIuanMiXSwibmFtZXMiOlsiJCIsIkZPVU5EQVRJT05fVkVSU0lPTiIsIkZvdW5kYXRpb24iLCJ2ZXJzaW9uIiwiX3BsdWdpbnMiLCJfdXVpZHMiLCJydGwiLCJhdHRyIiwicGx1Z2luIiwibmFtZSIsImNsYXNzTmFtZSIsImZ1bmN0aW9uTmFtZSIsImF0dHJOYW1lIiwiaHlwaGVuYXRlIiwicmVnaXN0ZXJQbHVnaW4iLCJwbHVnaW5OYW1lIiwiY29uc3RydWN0b3IiLCJ0b0xvd2VyQ2FzZSIsInV1aWQiLCJHZXRZb0RpZ2l0cyIsIiRlbGVtZW50IiwiZGF0YSIsInRyaWdnZXIiLCJwdXNoIiwidW5yZWdpc3RlclBsdWdpbiIsInNwbGljZSIsImluZGV4T2YiLCJyZW1vdmVBdHRyIiwicmVtb3ZlRGF0YSIsInByb3AiLCJyZUluaXQiLCJwbHVnaW5zIiwiaXNKUSIsImVhY2giLCJfaW5pdCIsInR5cGUiLCJfdGhpcyIsImZucyIsInBsZ3MiLCJmb3JFYWNoIiwicCIsImZvdW5kYXRpb24iLCJPYmplY3QiLCJrZXlzIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwibGVuZ3RoIiwibmFtZXNwYWNlIiwiTWF0aCIsInJvdW5kIiwicG93IiwicmFuZG9tIiwidG9TdHJpbmciLCJzbGljZSIsInJlZmxvdyIsImVsZW0iLCJpIiwiJGVsZW0iLCJmaW5kIiwiYWRkQmFjayIsIiRlbCIsIm9wdHMiLCJ3YXJuIiwidGhpbmciLCJzcGxpdCIsImUiLCJvcHQiLCJtYXAiLCJlbCIsInRyaW0iLCJwYXJzZVZhbHVlIiwiZXIiLCJnZXRGbk5hbWUiLCJ0cmFuc2l0aW9uZW5kIiwidHJhbnNpdGlvbnMiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJlbmQiLCJ0Iiwic3R5bGUiLCJzZXRUaW1lb3V0IiwidHJpZ2dlckhhbmRsZXIiLCJ1dGlsIiwidGhyb3R0bGUiLCJmdW5jIiwiZGVsYXkiLCJ0aW1lciIsImNvbnRleHQiLCJhcmdzIiwiYXJndW1lbnRzIiwiYXBwbHkiLCJtZXRob2QiLCIkbWV0YSIsIiRub0pTIiwiYXBwZW5kVG8iLCJoZWFkIiwicmVtb3ZlQ2xhc3MiLCJNZWRpYVF1ZXJ5IiwiQXJyYXkiLCJwcm90b3R5cGUiLCJjYWxsIiwicGx1Z0NsYXNzIiwidW5kZWZpbmVkIiwiUmVmZXJlbmNlRXJyb3IiLCJUeXBlRXJyb3IiLCJ3aW5kb3ciLCJmbiIsIkRhdGUiLCJub3ciLCJnZXRUaW1lIiwidmVuZG9ycyIsInJlcXVlc3RBbmltYXRpb25GcmFtZSIsInZwIiwiY2FuY2VsQW5pbWF0aW9uRnJhbWUiLCJ0ZXN0IiwibmF2aWdhdG9yIiwidXNlckFnZW50IiwibGFzdFRpbWUiLCJjYWxsYmFjayIsIm5leHRUaW1lIiwibWF4IiwiY2xlYXJUaW1lb3V0IiwicGVyZm9ybWFuY2UiLCJzdGFydCIsIkZ1bmN0aW9uIiwiYmluZCIsIm9UaGlzIiwiYUFyZ3MiLCJmVG9CaW5kIiwiZk5PUCIsImZCb3VuZCIsImNvbmNhdCIsImZ1bmNOYW1lUmVnZXgiLCJyZXN1bHRzIiwiZXhlYyIsInN0ciIsImlzTmFOIiwicGFyc2VGbG9hdCIsInJlcGxhY2UiLCJqUXVlcnkiLCJCb3giLCJJbU5vdFRvdWNoaW5nWW91IiwiR2V0RGltZW5zaW9ucyIsIkdldE9mZnNldHMiLCJlbGVtZW50IiwicGFyZW50IiwibHJPbmx5IiwidGJPbmx5IiwiZWxlRGltcyIsInRvcCIsImJvdHRvbSIsImxlZnQiLCJyaWdodCIsInBhckRpbXMiLCJvZmZzZXQiLCJoZWlnaHQiLCJ3aWR0aCIsIndpbmRvd0RpbXMiLCJhbGxEaXJzIiwiRXJyb3IiLCJyZWN0IiwiZ2V0Qm91bmRpbmdDbGllbnRSZWN0IiwicGFyUmVjdCIsInBhcmVudE5vZGUiLCJ3aW5SZWN0IiwiYm9keSIsIndpblkiLCJwYWdlWU9mZnNldCIsIndpblgiLCJwYWdlWE9mZnNldCIsInBhcmVudERpbXMiLCJhbmNob3IiLCJwb3NpdGlvbiIsInZPZmZzZXQiLCJoT2Zmc2V0IiwiaXNPdmVyZmxvdyIsIiRlbGVEaW1zIiwiJGFuY2hvckRpbXMiLCJrZXlDb2RlcyIsImNvbW1hbmRzIiwiS2V5Ym9hcmQiLCJnZXRLZXlDb2RlcyIsInBhcnNlS2V5IiwiZXZlbnQiLCJrZXkiLCJ3aGljaCIsImtleUNvZGUiLCJTdHJpbmciLCJmcm9tQ2hhckNvZGUiLCJ0b1VwcGVyQ2FzZSIsInNoaWZ0S2V5IiwiY3RybEtleSIsImFsdEtleSIsImhhbmRsZUtleSIsImNvbXBvbmVudCIsImZ1bmN0aW9ucyIsImNvbW1hbmRMaXN0IiwiY21kcyIsImNvbW1hbmQiLCJsdHIiLCJleHRlbmQiLCJyZXR1cm5WYWx1ZSIsImhhbmRsZWQiLCJ1bmhhbmRsZWQiLCJmaW5kRm9jdXNhYmxlIiwiZmlsdGVyIiwiaXMiLCJyZWdpc3RlciIsImNvbXBvbmVudE5hbWUiLCJ0cmFwRm9jdXMiLCIkZm9jdXNhYmxlIiwiJGZpcnN0Rm9jdXNhYmxlIiwiZXEiLCIkbGFzdEZvY3VzYWJsZSIsIm9uIiwidGFyZ2V0IiwicHJldmVudERlZmF1bHQiLCJmb2N1cyIsInJlbGVhc2VGb2N1cyIsIm9mZiIsImtjcyIsImsiLCJrYyIsImRlZmF1bHRRdWVyaWVzIiwibGFuZHNjYXBlIiwicG9ydHJhaXQiLCJyZXRpbmEiLCJxdWVyaWVzIiwiY3VycmVudCIsInNlbGYiLCJleHRyYWN0ZWRTdHlsZXMiLCJjc3MiLCJuYW1lZFF1ZXJpZXMiLCJwYXJzZVN0eWxlVG9PYmplY3QiLCJoYXNPd25Qcm9wZXJ0eSIsInZhbHVlIiwiX2dldEN1cnJlbnRTaXplIiwiX3dhdGNoZXIiLCJhdExlYXN0Iiwic2l6ZSIsInF1ZXJ5IiwiZ2V0IiwibWF0Y2hNZWRpYSIsIm1hdGNoZXMiLCJtYXRjaGVkIiwibmV3U2l6ZSIsImN1cnJlbnRTaXplIiwic3R5bGVNZWRpYSIsIm1lZGlhIiwic2NyaXB0IiwiZ2V0RWxlbWVudHNCeVRhZ05hbWUiLCJpbmZvIiwiaWQiLCJpbnNlcnRCZWZvcmUiLCJnZXRDb21wdXRlZFN0eWxlIiwiY3VycmVudFN0eWxlIiwibWF0Y2hNZWRpdW0iLCJ0ZXh0Iiwic3R5bGVTaGVldCIsImNzc1RleHQiLCJ0ZXh0Q29udGVudCIsInN0eWxlT2JqZWN0IiwicmVkdWNlIiwicmV0IiwicGFyYW0iLCJwYXJ0cyIsInZhbCIsImRlY29kZVVSSUNvbXBvbmVudCIsImlzQXJyYXkiLCJpbml0Q2xhc3NlcyIsImFjdGl2ZUNsYXNzZXMiLCJNb3Rpb24iLCJhbmltYXRlSW4iLCJhbmltYXRpb24iLCJjYiIsImFuaW1hdGUiLCJhbmltYXRlT3V0IiwiTW92ZSIsImR1cmF0aW9uIiwiYW5pbSIsInByb2ciLCJtb3ZlIiwidHMiLCJpc0luIiwiaW5pdENsYXNzIiwiYWN0aXZlQ2xhc3MiLCJyZXNldCIsImFkZENsYXNzIiwic2hvdyIsIm9mZnNldFdpZHRoIiwib25lIiwiZmluaXNoIiwiaGlkZSIsInRyYW5zaXRpb25EdXJhdGlvbiIsIk5lc3QiLCJGZWF0aGVyIiwibWVudSIsIml0ZW1zIiwic3ViTWVudUNsYXNzIiwic3ViSXRlbUNsYXNzIiwiaGFzU3ViQ2xhc3MiLCIkaXRlbSIsIiRzdWIiLCJjaGlsZHJlbiIsIkJ1cm4iLCJUaW1lciIsIm9wdGlvbnMiLCJuYW1lU3BhY2UiLCJyZW1haW4iLCJpc1BhdXNlZCIsInJlc3RhcnQiLCJpbmZpbml0ZSIsInBhdXNlIiwib25JbWFnZXNMb2FkZWQiLCJpbWFnZXMiLCJ1bmxvYWRlZCIsImNvbXBsZXRlIiwicmVhZHlTdGF0ZSIsInNpbmdsZUltYWdlTG9hZGVkIiwic3JjIiwic3BvdFN3aXBlIiwiZW5hYmxlZCIsImRvY3VtZW50RWxlbWVudCIsIm1vdmVUaHJlc2hvbGQiLCJ0aW1lVGhyZXNob2xkIiwic3RhcnRQb3NYIiwic3RhcnRQb3NZIiwic3RhcnRUaW1lIiwiZWxhcHNlZFRpbWUiLCJpc01vdmluZyIsIm9uVG91Y2hFbmQiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwib25Ub3VjaE1vdmUiLCJ4IiwidG91Y2hlcyIsInBhZ2VYIiwieSIsInBhZ2VZIiwiZHgiLCJkeSIsImRpciIsImFicyIsIm9uVG91Y2hTdGFydCIsImFkZEV2ZW50TGlzdGVuZXIiLCJpbml0IiwidGVhcmRvd24iLCJzcGVjaWFsIiwic3dpcGUiLCJzZXR1cCIsIm5vb3AiLCJhZGRUb3VjaCIsImhhbmRsZVRvdWNoIiwiY2hhbmdlZFRvdWNoZXMiLCJmaXJzdCIsImV2ZW50VHlwZXMiLCJ0b3VjaHN0YXJ0IiwidG91Y2htb3ZlIiwidG91Y2hlbmQiLCJzaW11bGF0ZWRFdmVudCIsIk1vdXNlRXZlbnQiLCJzY3JlZW5YIiwic2NyZWVuWSIsImNsaWVudFgiLCJjbGllbnRZIiwiY3JlYXRlRXZlbnQiLCJpbml0TW91c2VFdmVudCIsImRpc3BhdGNoRXZlbnQiLCJNdXRhdGlvbk9ic2VydmVyIiwicHJlZml4ZXMiLCJ0cmlnZ2VycyIsInN0b3BQcm9wYWdhdGlvbiIsImZhZGVPdXQiLCJjaGVja0xpc3RlbmVycyIsImV2ZW50c0xpc3RlbmVyIiwicmVzaXplTGlzdGVuZXIiLCJzY3JvbGxMaXN0ZW5lciIsIm11dGF0ZUxpc3RlbmVyIiwiY2xvc2VtZUxpc3RlbmVyIiwieWV0aUJveGVzIiwicGx1Z05hbWVzIiwibGlzdGVuZXJzIiwiam9pbiIsInBsdWdpbklkIiwibm90IiwiZGVib3VuY2UiLCIkbm9kZXMiLCJub2RlcyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJsaXN0ZW5pbmdFbGVtZW50c011dGF0aW9uIiwibXV0YXRpb25SZWNvcmRzTGlzdCIsIiR0YXJnZXQiLCJhdHRyaWJ1dGVOYW1lIiwiY2xvc2VzdCIsImVsZW1lbnRPYnNlcnZlciIsIm9ic2VydmUiLCJhdHRyaWJ1dGVzIiwiY2hpbGRMaXN0IiwiY2hhcmFjdGVyRGF0YSIsInN1YnRyZWUiLCJhdHRyaWJ1dGVGaWx0ZXIiLCJJSGVhcllvdSIsIkFjY29yZGlvbk1lbnUiLCJkZWZhdWx0cyIsInNsaWRlVXAiLCJtdWx0aU9wZW4iLCIkbWVudUxpbmtzIiwibGlua0lkIiwic3ViSWQiLCJpc0FjdGl2ZSIsImhhc0NsYXNzIiwiaW5pdFBhbmVzIiwiZG93biIsIl9ldmVudHMiLCIkc3VibWVudSIsInRvZ2dsZSIsIiRlbGVtZW50cyIsIiRwcmV2RWxlbWVudCIsIiRuZXh0RWxlbWVudCIsIm1pbiIsInBhcmVudHMiLCJuZXh0Iiwib3BlbiIsImNsb3NlIiwidXAiLCJjbG9zZUFsbCIsImhpZGVBbGwiLCJzdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24iLCJwYXJlbnRzVW50aWwiLCJhZGQiLCJzbGlkZURvd24iLCJzbGlkZVNwZWVkIiwiJG1lbnVzIiwiRHJpbGxkb3duIiwiJHN1Ym1lbnVBbmNob3JzIiwiJHN1Ym1lbnVzIiwiJG1lbnVJdGVtcyIsIl9wcmVwYXJlTWVudSIsIl9yZWdpc3RlckV2ZW50cyIsIl9rZXlib2FyZEV2ZW50cyIsIiRsaW5rIiwicGFyZW50TGluayIsImNsb25lIiwicHJlcGVuZFRvIiwid3JhcCIsIiRtZW51IiwiJGJhY2siLCJiYWNrQnV0dG9uUG9zaXRpb24iLCJhcHBlbmQiLCJiYWNrQnV0dG9uIiwicHJlcGVuZCIsIl9iYWNrIiwiYXV0b0hlaWdodCIsIiR3cmFwcGVyIiwid3JhcHBlciIsImFuaW1hdGVIZWlnaHQiLCJfZ2V0TWF4RGltcyIsIl9zaG93IiwiY2xvc2VPbkNsaWNrIiwiJGJvZHkiLCJjb250YWlucyIsIl9oaWRlQWxsIiwiX3Jlc2l6ZSIsInNjcm9sbFRvcCIsIl9iaW5kSGFuZGxlciIsIl9zY3JvbGxUb3AiLCIkc2Nyb2xsVG9wRWxlbWVudCIsInNjcm9sbFRvcEVsZW1lbnQiLCJzY3JvbGxQb3MiLCJwYXJzZUludCIsInNjcm9sbFRvcE9mZnNldCIsInN0b3AiLCJhbmltYXRpb25EdXJhdGlvbiIsImFuaW1hdGlvbkVhc2luZyIsInByZXZpb3VzIiwiX2hpZGUiLCJwYXJlbnRTdWJNZW51IiwiYmx1ciIsIm1heEhlaWdodCIsInJlc3VsdCIsIm51bU9mRWxlbXMiLCJ1bndyYXAiLCJyZW1vdmUiLCJEcm9wZG93biIsIiRpZCIsIiRhbmNob3IiLCJwYXJlbnRDbGFzcyIsIiRwYXJlbnQiLCJwb3NpdGlvbkNsYXNzIiwiZ2V0UG9zaXRpb25DbGFzcyIsImNvdW50ZXIiLCJ1c2VkUG9zaXRpb25zIiwidmVydGljYWxQb3NpdGlvbiIsIm1hdGNoIiwiaG9yaXpvbnRhbFBvc2l0aW9uIiwiY2xhc3NDaGFuZ2VkIiwiZGlyZWN0aW9uIiwibmV3V2lkdGgiLCJwYXJlbnRIT2Zmc2V0IiwiJHBhcmVudERpbXMiLCJfcmVwb3NpdGlvbiIsIl9zZXRQb3NpdGlvbiIsImhvdmVyIiwiYm9keURhdGEiLCJ3aGF0aW5wdXQiLCJ0aW1lb3V0IiwiaG92ZXJEZWxheSIsImhvdmVyUGFuZSIsInZpc2libGVGb2N1c2FibGVFbGVtZW50cyIsImF1dG9Gb2N1cyIsIl9hZGRCb2R5SGFuZGxlciIsImN1clBvc2l0aW9uQ2xhc3MiLCJEcm9wZG93bk1lbnUiLCJzdWJzIiwiJHRhYnMiLCJ2ZXJ0aWNhbENsYXNzIiwicmlnaHRDbGFzcyIsImFsaWdubWVudCIsImNoYW5nZWQiLCJoYXNUb3VjaCIsIm9udG91Y2hzdGFydCIsInBhckNsYXNzIiwiaGFuZGxlQ2xpY2tGbiIsImhhc1N1YiIsImhhc0NsaWNrZWQiLCJjbGlja09wZW4iLCJmb3JjZUZvbGxvdyIsImNsb3NlT25DbGlja0luc2lkZSIsImRpc2FibGVIb3ZlciIsImF1dG9jbG9zZSIsImNsb3NpbmdUaW1lIiwiaXNUYWIiLCJpbmRleCIsInNpYmxpbmdzIiwibmV4dFNpYmxpbmciLCJwcmV2U2libGluZyIsIm9wZW5TdWIiLCJjbG9zZVN1YiIsIl9pc1ZlcnRpY2FsIiwiaWR4IiwiJHNpYnMiLCJjbGVhciIsIm9sZENsYXNzIiwiJHBhcmVudExpIiwiJHRvQ2xvc2UiLCJzb21ldGhpbmdUb0Nsb3NlIiwiT2ZmQ2FudmFzIiwiJGxhc3RUcmlnZ2VyIiwiJHRyaWdnZXJzIiwidHJhbnNpdGlvbiIsImNvbnRlbnRPdmVybGF5Iiwib3ZlcmxheSIsIm92ZXJsYXlQb3NpdGlvbiIsInNldEF0dHJpYnV0ZSIsIiRvdmVybGF5IiwiaXNSZXZlYWxlZCIsIlJlZ0V4cCIsInJldmVhbENsYXNzIiwicmV2ZWFsT24iLCJfc2V0TVFDaGVja2VyIiwidHJhbnNpdGlvblRpbWUiLCJfaGFuZGxlS2V5Ym9hcmQiLCJyZXZlYWwiLCIkY2xvc2VyIiwiZm9yY2VUbyIsInNjcm9sbFRvIiwic2Nyb2xsSGVpZ2h0IiwiY29udGVudFNjcm9sbCIsIl9zdG9wU2Nyb2xsaW5nIiwiUmVzcG9uc2l2ZU1lbnUiLCJydWxlcyIsImN1cnJlbnRNcSIsImN1cnJlbnRQbHVnaW4iLCJydWxlc1RyZWUiLCJydWxlIiwicnVsZVNpemUiLCJydWxlUGx1Z2luIiwiTWVudVBsdWdpbnMiLCJpc0VtcHR5T2JqZWN0IiwiX2NoZWNrTWVkaWFRdWVyaWVzIiwibWF0Y2hlZE1xIiwiY3NzQ2xhc3MiLCJkZXN0cm95IiwiZHJvcGRvd24iLCJkcmlsbGRvd24iLCJhY2NvcmRpb24iLCJSZXNwb25zaXZlVG9nZ2xlIiwidGFyZ2V0SUQiLCIkdGFyZ2V0TWVudSIsIiR0b2dnbGVyIiwiaW5wdXQiLCJhbmltYXRpb25JbiIsImFuaW1hdGlvbk91dCIsIl91cGRhdGUiLCJfdXBkYXRlTXFIYW5kbGVyIiwidG9nZ2xlTWVudSIsImhpZGVGb3IiLCJUb2dnbGVyIiwidG9nZ2xlQ2xhc3MiLCJpc09uIiwiX3VwZGF0ZUFSSUEiLCJUb29sdGlwIiwiaXNDbGljayIsImVsZW1JZCIsIl9nZXRQb3NpdGlvbkNsYXNzIiwidGlwVGV4dCIsInRlbXBsYXRlIiwiX2J1aWxkVGVtcGxhdGUiLCJhbGxvd0h0bWwiLCJodG1sIiwidHJpZ2dlckNsYXNzIiwidGVtcGxhdGVDbGFzc2VzIiwidG9vbHRpcENsYXNzIiwiJHRlbXBsYXRlIiwiJHRpcERpbXMiLCJzaG93T24iLCJmYWRlSW4iLCJmYWRlSW5EdXJhdGlvbiIsImZhZGVPdXREdXJhdGlvbiIsImlzRm9jdXMiLCJkaXNhYmxlRm9yVG91Y2giLCJ0b3VjaENsb3NlVGV4dCIsImEiLCJiIiwiYyIsImQiLCJzZXR0aW5ncyIsIkRlZmF1bHRzIiwiX2hhbmRsZXJzIiwiX3N1cHJlc3MiLCJfY3VycmVudCIsIl9zcGVlZCIsIl9jb29yZGluYXRlcyIsIl9icmVha3BvaW50IiwiX3dpZHRoIiwiX2l0ZW1zIiwiX2Nsb25lcyIsIl9tZXJnZXJzIiwiX3dpZHRocyIsIl9pbnZhbGlkYXRlZCIsIl9waXBlIiwiX2RyYWciLCJ0aW1lIiwicG9pbnRlciIsInN0YWdlIiwiX3N0YXRlcyIsInRhZ3MiLCJpbml0aWFsaXppbmciLCJhbmltYXRpbmciLCJkcmFnZ2luZyIsInByb3h5IiwiUGx1Z2lucyIsImNoYXJBdCIsIldvcmtlcnMiLCJydW4iLCJpbml0aWFsaXplIiwibG9vcCIsImNlbnRlciIsInJld2luZCIsIm1vdXNlRHJhZyIsInRvdWNoRHJhZyIsInB1bGxEcmFnIiwiZnJlZURyYWciLCJtYXJnaW4iLCJzdGFnZVBhZGRpbmciLCJtZXJnZSIsIm1lcmdlRml0IiwiYXV0b1dpZHRoIiwic3RhcnRQb3NpdGlvbiIsInNtYXJ0U3BlZWQiLCJmbHVpZFNwZWVkIiwiZHJhZ0VuZFNwZWVkIiwicmVzcG9uc2l2ZSIsInJlc3BvbnNpdmVSZWZyZXNoUmF0ZSIsInJlc3BvbnNpdmVCYXNlRWxlbWVudCIsImZhbGxiYWNrRWFzaW5nIiwibmVzdGVkSXRlbVNlbGVjdG9yIiwiaXRlbUVsZW1lbnQiLCJzdGFnZUVsZW1lbnQiLCJyZWZyZXNoQ2xhc3MiLCJsb2FkZWRDbGFzcyIsImxvYWRpbmdDbGFzcyIsInJ0bENsYXNzIiwicmVzcG9uc2l2ZUNsYXNzIiwiZHJhZ0NsYXNzIiwiaXRlbUNsYXNzIiwic3RhZ2VDbGFzcyIsInN0YWdlT3V0ZXJDbGFzcyIsImdyYWJDbGFzcyIsIldpZHRoIiwiRGVmYXVsdCIsIklubmVyIiwiT3V0ZXIiLCJUeXBlIiwiRXZlbnQiLCJTdGF0ZSIsInJlbGF0aXZlIiwiJHN0YWdlIiwidG9GaXhlZCIsImYiLCJjZWlsIiwiZyIsImgiLCJub3JtYWxpemUiLCJvdXRlckhUTUwiLCJtaW5pbXVtIiwibWF4aW11bSIsImNvb3JkaW5hdGVzIiwib3AiLCJlbnRlciIsInByZWxvYWRBdXRvV2lkdGhJbWFnZXMiLCJyZWZyZXNoIiwiaW52YWxpZGF0ZSIsInJlZ2lzdGVyRXZlbnRIYW5kbGVycyIsImxlYXZlIiwidmlld3BvcnQiLCJOdW1iZXIiLCJwcm9wZXJ0eSIsIm9wdGlvbnNMb2dpYyIsInByZXBhcmUiLCJjb250ZW50IiwidXBkYXRlIiwiYWxsIiwiZ3JlcCIsIm9uVGhyb3R0bGVkUmVzaXplIiwicmVzaXplVGltZXIiLCJvblJlc2l6ZSIsImlzRGVmYXVsdFByZXZlbnRlZCIsInN1cHBvcnQiLCJvblRyYW5zaXRpb25FbmQiLCJvbkRyYWdTdGFydCIsIm9uRHJhZ0VuZCIsInRyYW5zZm9ybSIsInNwZWVkIiwiZGlmZmVyZW5jZSIsIm9uRHJhZ01vdmUiLCJ0cmFuc2Zvcm0zZCIsInN1cHByZXNzIiwicmVsZWFzZSIsImlzTnVtZXJpYyIsIm1lcmdlcnMiLCJjbG9uZXMiLCJ0byIsInByZXYiLCJzcmNFbGVtZW50Iiwib3JpZ2luYWxUYXJnZXQiLCJpbm5lcldpZHRoIiwiY2xpZW50V2lkdGgiLCJlbXB0eSIsIm5vZGVUeXBlIiwiYWZ0ZXIiLCJiZWZvcmUiLCJJbWFnZSIsImNvbnRlbnRzIiwiYXR0YWNoRXZlbnQiLCJkZXRhY2hFdmVudCIsIml0ZW0iLCJjb3VudCIsImNhbWVsQ2FzZSIsImoiLCJyZWxhdGVkVGFyZ2V0Iiwib25UcmlnZ2VyIiwib3dsIiwiX2RlZmF1bHQiLCJpbkFycmF5Iiwib3JpZ2luYWxFdmVudCIsIm93bENhcm91c2VsIiwiQ29uc3RydWN0b3IiLCJaZXB0byIsIl9jb3JlIiwiX2ludGVydmFsIiwiX3Zpc2libGUiLCJhdXRvUmVmcmVzaCIsIndhdGNoIiwiYXV0b1JlZnJlc2hJbnRlcnZhbCIsInNldEludGVydmFsIiwiY2xlYXJJbnRlcnZhbCIsImdldE93blByb3BlcnR5TmFtZXMiLCJBdXRvUmVmcmVzaCIsIl9sb2FkZWQiLCJsYXp5TG9hZCIsImxvYWQiLCJkZXZpY2VQaXhlbFJhdGlvIiwidXJsIiwib25sb2FkIiwib3BhY2l0eSIsImhhbmRsZXJzIiwiTGF6eSIsImF1dG9IZWlnaHRDbGFzcyIsInRvQXJyYXkiLCJBdXRvSGVpZ2h0IiwiX3ZpZGVvcyIsIl9wbGF5aW5nIiwidmlkZW8iLCJpc0luRnVsbFNjcmVlbiIsImZldGNoIiwicGxheSIsInZpZGVvSGVpZ2h0IiwidmlkZW9XaWR0aCIsInRodW1ibmFpbCIsImwiLCJhamF4IiwianNvbnAiLCJkYXRhVHlwZSIsInN1Y2Nlc3MiLCJ0aHVtYm5haWxfbGFyZ2UiLCJmcmFtZWdyYWJfdXJsIiwiaW5zZXJ0QWZ0ZXIiLCJmdWxsc2NyZWVuRWxlbWVudCIsIm1vekZ1bGxTY3JlZW5FbGVtZW50Iiwid2Via2l0RnVsbHNjcmVlbkVsZW1lbnQiLCJWaWRlbyIsImNvcmUiLCJzd2FwcGluZyIsInN3YXAiLCJBbmltYXRlIiwiX3RpbWVvdXQiLCJfcGF1c2VkIiwiYXV0b3BsYXkiLCJfc2V0QXV0b1BsYXlJbnRlcnZhbCIsImF1dG9wbGF5SG92ZXJQYXVzZSIsImF1dG9wbGF5VGltZW91dCIsImF1dG9wbGF5U3BlZWQiLCJfZ2V0TmV4dFRpbWVvdXQiLCJoaWRkZW4iLCJfaW5pdGlhbGl6ZWQiLCJfcGFnZXMiLCJfY29udHJvbHMiLCJfdGVtcGxhdGVzIiwiX292ZXJyaWRlcyIsImRvdHNEYXRhIiwiZG90Q2xhc3MiLCJwb3AiLCJkcmF3IiwibmF2IiwibmF2VGV4dCIsIm5hdlNwZWVkIiwibmF2RWxlbWVudCIsIm5hdkNvbnRhaW5lciIsIm5hdkNvbnRhaW5lckNsYXNzIiwibmF2Q2xhc3MiLCJzbGlkZUJ5IiwiZG90c0NsYXNzIiwiZG90cyIsImRvdHNFYWNoIiwiZG90c1NwZWVkIiwiZG90c0NvbnRhaW5lciIsIiRyZWxhdGl2ZSIsIiRwcmV2aW91cyIsIiRuZXh0IiwiJGFic29sdXRlIiwib3ZlcmlkZXMiLCJwYWdlIiwiZ2V0UG9zaXRpb24iLCJOYXZpZ2F0aW9uIiwiX2hhc2hlcyIsImxvY2F0aW9uIiwiaGFzaCIsInN1YnN0cmluZyIsIlVSTGhhc2hMaXN0ZW5lciIsIkhhc2giLCJXZWJraXRUcmFuc2l0aW9uIiwiTW96VHJhbnNpdGlvbiIsIk9UcmFuc2l0aW9uIiwiV2Via2l0QW5pbWF0aW9uIiwiTW96QW5pbWF0aW9uIiwiT0FuaW1hdGlvbiIsImNzc3RyYW5zZm9ybXMiLCJjc3N0cmFuc2Zvcm1zM2QiLCJjc3N0cmFuc2l0aW9ucyIsImNzc2FuaW1hdGlvbnMiLCJyb290VXJsIiwib3JpZ2luIiwidGVtcGxhdGVVcmwiLCJ0aGVtZVVybCIsImdldEpTT04iLCJzU2VhcmNoU3RyaW5nIiwiYUl0ZW1zIiwidGl0bGUiLCJtYWluQWN0aXZldHkiLCJ0cmlwRGVzY3JpcHRpb24iLCJzZWFzb24iLCJhbGxBY3RpdmV0aWVzIiwidHJpcHMiLCJhbGxBY3RpdlRvTG93ZXJDYXNlIiwiZGVzY3JpcHRpb24iLCJhY3Rpdml0eUNhdGVnb3JpZXMiLCJpbmNsdWRlcyIsInNSZXN1bHRzRHJvcGRvd24iLCJjbGFzc0xpc3QiLCJvZmZzZXRIZWlnaHQiLCJyZXN1bHRUaXRsZSIsInJlc3VsdEFjdGl2ZXR5IiwiZmlsdGVyZWRBcnJheSIsInBvcyIsInNSZXN1bHRSZW5kZXIiLCJpbm5lckhUTUwiLCJwYXJlbnRJRCIsInBhcmVudEVsZW1lbnQiLCJnZXRBdHRyaWJ1dGUiLCJ3aWRnZXRfaWQiLCJyZXNpemUiLCJwb3N0T3dsIiwicmVhZHkiLCJ2aWRlb3MiLCJvblNjcm9sbCIsImNvbnRhaW5lciIsInRoZWNsYXNzIiwiYW1vdW50Iiwic2Nyb2xsIiwiY2xpY2siLCJtb3VzZW92ZXIiLCJmb290ZXIiLCJzdGlja3lGb290ZXIiXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxDQUFDLFVBQVNBLENBQVQsRUFBWTs7QUFFYjs7QUFFQSxNQUFJQyxxQkFBcUIsT0FBekI7O0FBRUE7QUFDQTtBQUNBLE1BQUlDLGFBQWE7QUFDZkMsYUFBU0Ysa0JBRE07O0FBR2Y7OztBQUdBRyxjQUFVLEVBTks7O0FBUWY7OztBQUdBQyxZQUFRLEVBWE87O0FBYWY7OztBQUdBQyxTQUFLLGVBQVU7QUFDYixhQUFPTixFQUFFLE1BQUYsRUFBVU8sSUFBVixDQUFlLEtBQWYsTUFBMEIsS0FBakM7QUFDRCxLQWxCYztBQW1CZjs7OztBQUlBQyxZQUFRLGdCQUFTQSxPQUFULEVBQWlCQyxJQUFqQixFQUF1QjtBQUM3QjtBQUNBO0FBQ0EsVUFBSUMsWUFBYUQsUUFBUUUsYUFBYUgsT0FBYixDQUF6QjtBQUNBO0FBQ0E7QUFDQSxVQUFJSSxXQUFZQyxVQUFVSCxTQUFWLENBQWhCOztBQUVBO0FBQ0EsV0FBS04sUUFBTCxDQUFjUSxRQUFkLElBQTBCLEtBQUtGLFNBQUwsSUFBa0JGLE9BQTVDO0FBQ0QsS0FqQ2M7QUFrQ2Y7Ozs7Ozs7OztBQVNBTSxvQkFBZ0Isd0JBQVNOLE1BQVQsRUFBaUJDLElBQWpCLEVBQXNCO0FBQ3BDLFVBQUlNLGFBQWFOLE9BQU9JLFVBQVVKLElBQVYsQ0FBUCxHQUF5QkUsYUFBYUgsT0FBT1EsV0FBcEIsRUFBaUNDLFdBQWpDLEVBQTFDO0FBQ0FULGFBQU9VLElBQVAsR0FBYyxLQUFLQyxXQUFMLENBQWlCLENBQWpCLEVBQW9CSixVQUFwQixDQUFkOztBQUVBLFVBQUcsQ0FBQ1AsT0FBT1ksUUFBUCxDQUFnQmIsSUFBaEIsV0FBNkJRLFVBQTdCLENBQUosRUFBK0M7QUFBRVAsZUFBT1ksUUFBUCxDQUFnQmIsSUFBaEIsV0FBNkJRLFVBQTdCLEVBQTJDUCxPQUFPVSxJQUFsRDtBQUEwRDtBQUMzRyxVQUFHLENBQUNWLE9BQU9ZLFFBQVAsQ0FBZ0JDLElBQWhCLENBQXFCLFVBQXJCLENBQUosRUFBcUM7QUFBRWIsZUFBT1ksUUFBUCxDQUFnQkMsSUFBaEIsQ0FBcUIsVUFBckIsRUFBaUNiLE1BQWpDO0FBQTJDO0FBQzVFOzs7O0FBSU5BLGFBQU9ZLFFBQVAsQ0FBZ0JFLE9BQWhCLGNBQW1DUCxVQUFuQzs7QUFFQSxXQUFLVixNQUFMLENBQVlrQixJQUFaLENBQWlCZixPQUFPVSxJQUF4Qjs7QUFFQTtBQUNELEtBMURjO0FBMkRmOzs7Ozs7OztBQVFBTSxzQkFBa0IsMEJBQVNoQixNQUFULEVBQWdCO0FBQ2hDLFVBQUlPLGFBQWFGLFVBQVVGLGFBQWFILE9BQU9ZLFFBQVAsQ0FBZ0JDLElBQWhCLENBQXFCLFVBQXJCLEVBQWlDTCxXQUE5QyxDQUFWLENBQWpCOztBQUVBLFdBQUtYLE1BQUwsQ0FBWW9CLE1BQVosQ0FBbUIsS0FBS3BCLE1BQUwsQ0FBWXFCLE9BQVosQ0FBb0JsQixPQUFPVSxJQUEzQixDQUFuQixFQUFxRCxDQUFyRDtBQUNBVixhQUFPWSxRQUFQLENBQWdCTyxVQUFoQixXQUFtQ1osVUFBbkMsRUFBaURhLFVBQWpELENBQTRELFVBQTVEO0FBQ007Ozs7QUFETixPQUtPTixPQUxQLG1CQUsrQlAsVUFML0I7QUFNQSxXQUFJLElBQUljLElBQVIsSUFBZ0JyQixNQUFoQixFQUF1QjtBQUNyQkEsZUFBT3FCLElBQVAsSUFBZSxJQUFmLENBRHFCLENBQ0Q7QUFDckI7QUFDRDtBQUNELEtBakZjOztBQW1GZjs7Ozs7O0FBTUNDLFlBQVEsZ0JBQVNDLE9BQVQsRUFBaUI7QUFDdkIsVUFBSUMsT0FBT0QsbUJBQW1CL0IsQ0FBOUI7QUFDQSxVQUFHO0FBQ0QsWUFBR2dDLElBQUgsRUFBUTtBQUNORCxrQkFBUUUsSUFBUixDQUFhLFlBQVU7QUFDckJqQyxjQUFFLElBQUYsRUFBUXFCLElBQVIsQ0FBYSxVQUFiLEVBQXlCYSxLQUF6QjtBQUNELFdBRkQ7QUFHRCxTQUpELE1BSUs7QUFDSCxjQUFJQyxjQUFjSixPQUFkLHlDQUFjQSxPQUFkLENBQUo7QUFBQSxjQUNBSyxRQUFRLElBRFI7QUFBQSxjQUVBQyxNQUFNO0FBQ0osc0JBQVUsZ0JBQVNDLElBQVQsRUFBYztBQUN0QkEsbUJBQUtDLE9BQUwsQ0FBYSxVQUFTQyxDQUFULEVBQVc7QUFDdEJBLG9CQUFJM0IsVUFBVTJCLENBQVYsQ0FBSjtBQUNBeEMsa0JBQUUsV0FBVXdDLENBQVYsR0FBYSxHQUFmLEVBQW9CQyxVQUFwQixDQUErQixPQUEvQjtBQUNELGVBSEQ7QUFJRCxhQU5HO0FBT0osc0JBQVUsa0JBQVU7QUFDbEJWLHdCQUFVbEIsVUFBVWtCLE9BQVYsQ0FBVjtBQUNBL0IsZ0JBQUUsV0FBVStCLE9BQVYsR0FBbUIsR0FBckIsRUFBMEJVLFVBQTFCLENBQXFDLE9BQXJDO0FBQ0QsYUFWRztBQVdKLHlCQUFhLHFCQUFVO0FBQ3JCLG1CQUFLLFFBQUwsRUFBZUMsT0FBT0MsSUFBUCxDQUFZUCxNQUFNaEMsUUFBbEIsQ0FBZjtBQUNEO0FBYkcsV0FGTjtBQWlCQWlDLGNBQUlGLElBQUosRUFBVUosT0FBVjtBQUNEO0FBQ0YsT0F6QkQsQ0F5QkMsT0FBTWEsR0FBTixFQUFVO0FBQ1RDLGdCQUFRQyxLQUFSLENBQWNGLEdBQWQ7QUFDRCxPQTNCRCxTQTJCUTtBQUNOLGVBQU9iLE9BQVA7QUFDRDtBQUNGLEtBekhhOztBQTJIZjs7Ozs7Ozs7QUFRQVosaUJBQWEscUJBQVM0QixNQUFULEVBQWlCQyxTQUFqQixFQUEyQjtBQUN0Q0QsZUFBU0EsVUFBVSxDQUFuQjtBQUNBLGFBQU9FLEtBQUtDLEtBQUwsQ0FBWUQsS0FBS0UsR0FBTCxDQUFTLEVBQVQsRUFBYUosU0FBUyxDQUF0QixJQUEyQkUsS0FBS0csTUFBTCxLQUFnQkgsS0FBS0UsR0FBTCxDQUFTLEVBQVQsRUFBYUosTUFBYixDQUF2RCxFQUE4RU0sUUFBOUUsQ0FBdUYsRUFBdkYsRUFBMkZDLEtBQTNGLENBQWlHLENBQWpHLEtBQXVHTixrQkFBZ0JBLFNBQWhCLEdBQThCLEVBQXJJLENBQVA7QUFDRCxLQXRJYztBQXVJZjs7Ozs7QUFLQU8sWUFBUSxnQkFBU0MsSUFBVCxFQUFlekIsT0FBZixFQUF3Qjs7QUFFOUI7QUFDQSxVQUFJLE9BQU9BLE9BQVAsS0FBbUIsV0FBdkIsRUFBb0M7QUFDbENBLGtCQUFVVyxPQUFPQyxJQUFQLENBQVksS0FBS3ZDLFFBQWpCLENBQVY7QUFDRDtBQUNEO0FBSEEsV0FJSyxJQUFJLE9BQU8yQixPQUFQLEtBQW1CLFFBQXZCLEVBQWlDO0FBQ3BDQSxvQkFBVSxDQUFDQSxPQUFELENBQVY7QUFDRDs7QUFFRCxVQUFJSyxRQUFRLElBQVo7O0FBRUE7QUFDQXBDLFFBQUVpQyxJQUFGLENBQU9GLE9BQVAsRUFBZ0IsVUFBUzBCLENBQVQsRUFBWWhELElBQVosRUFBa0I7QUFDaEM7QUFDQSxZQUFJRCxTQUFTNEIsTUFBTWhDLFFBQU4sQ0FBZUssSUFBZixDQUFiOztBQUVBO0FBQ0EsWUFBSWlELFFBQVExRCxFQUFFd0QsSUFBRixFQUFRRyxJQUFSLENBQWEsV0FBU2xELElBQVQsR0FBYyxHQUEzQixFQUFnQ21ELE9BQWhDLENBQXdDLFdBQVNuRCxJQUFULEdBQWMsR0FBdEQsQ0FBWjs7QUFFQTtBQUNBaUQsY0FBTXpCLElBQU4sQ0FBVyxZQUFXO0FBQ3BCLGNBQUk0QixNQUFNN0QsRUFBRSxJQUFGLENBQVY7QUFBQSxjQUNJOEQsT0FBTyxFQURYO0FBRUE7QUFDQSxjQUFJRCxJQUFJeEMsSUFBSixDQUFTLFVBQVQsQ0FBSixFQUEwQjtBQUN4QndCLG9CQUFRa0IsSUFBUixDQUFhLHlCQUF1QnRELElBQXZCLEdBQTRCLHNEQUF6QztBQUNBO0FBQ0Q7O0FBRUQsY0FBR29ELElBQUl0RCxJQUFKLENBQVMsY0FBVCxDQUFILEVBQTRCO0FBQzFCLGdCQUFJeUQsUUFBUUgsSUFBSXRELElBQUosQ0FBUyxjQUFULEVBQXlCMEQsS0FBekIsQ0FBK0IsR0FBL0IsRUFBb0MxQixPQUFwQyxDQUE0QyxVQUFTMkIsQ0FBVCxFQUFZVCxDQUFaLEVBQWM7QUFDcEUsa0JBQUlVLE1BQU1ELEVBQUVELEtBQUYsQ0FBUSxHQUFSLEVBQWFHLEdBQWIsQ0FBaUIsVUFBU0MsRUFBVCxFQUFZO0FBQUUsdUJBQU9BLEdBQUdDLElBQUgsRUFBUDtBQUFtQixlQUFsRCxDQUFWO0FBQ0Esa0JBQUdILElBQUksQ0FBSixDQUFILEVBQVdMLEtBQUtLLElBQUksQ0FBSixDQUFMLElBQWVJLFdBQVdKLElBQUksQ0FBSixDQUFYLENBQWY7QUFDWixhQUhXLENBQVo7QUFJRDtBQUNELGNBQUc7QUFDRE4sZ0JBQUl4QyxJQUFKLENBQVMsVUFBVCxFQUFxQixJQUFJYixNQUFKLENBQVdSLEVBQUUsSUFBRixDQUFYLEVBQW9COEQsSUFBcEIsQ0FBckI7QUFDRCxXQUZELENBRUMsT0FBTVUsRUFBTixFQUFTO0FBQ1IzQixvQkFBUUMsS0FBUixDQUFjMEIsRUFBZDtBQUNELFdBSkQsU0FJUTtBQUNOO0FBQ0Q7QUFDRixTQXRCRDtBQXVCRCxPQS9CRDtBQWdDRCxLQTFMYztBQTJMZkMsZUFBVzlELFlBM0xJO0FBNExmK0QsbUJBQWUsdUJBQVNoQixLQUFULEVBQWU7QUFDNUIsVUFBSWlCLGNBQWM7QUFDaEIsc0JBQWMsZUFERTtBQUVoQiw0QkFBb0IscUJBRko7QUFHaEIseUJBQWlCLGVBSEQ7QUFJaEIsdUJBQWU7QUFKQyxPQUFsQjtBQU1BLFVBQUluQixPQUFPb0IsU0FBU0MsYUFBVCxDQUF1QixLQUF2QixDQUFYO0FBQUEsVUFDSUMsR0FESjs7QUFHQSxXQUFLLElBQUlDLENBQVQsSUFBY0osV0FBZCxFQUEwQjtBQUN4QixZQUFJLE9BQU9uQixLQUFLd0IsS0FBTCxDQUFXRCxDQUFYLENBQVAsS0FBeUIsV0FBN0IsRUFBeUM7QUFDdkNELGdCQUFNSCxZQUFZSSxDQUFaLENBQU47QUFDRDtBQUNGO0FBQ0QsVUFBR0QsR0FBSCxFQUFPO0FBQ0wsZUFBT0EsR0FBUDtBQUNELE9BRkQsTUFFSztBQUNIQSxjQUFNRyxXQUFXLFlBQVU7QUFDekJ2QixnQkFBTXdCLGNBQU4sQ0FBcUIsZUFBckIsRUFBc0MsQ0FBQ3hCLEtBQUQsQ0FBdEM7QUFDRCxTQUZLLEVBRUgsQ0FGRyxDQUFOO0FBR0EsZUFBTyxlQUFQO0FBQ0Q7QUFDRjtBQW5OYyxHQUFqQjs7QUFzTkF4RCxhQUFXaUYsSUFBWCxHQUFrQjtBQUNoQjs7Ozs7OztBQU9BQyxjQUFVLGtCQUFVQyxJQUFWLEVBQWdCQyxLQUFoQixFQUF1QjtBQUMvQixVQUFJQyxRQUFRLElBQVo7O0FBRUEsYUFBTyxZQUFZO0FBQ2pCLFlBQUlDLFVBQVUsSUFBZDtBQUFBLFlBQW9CQyxPQUFPQyxTQUEzQjs7QUFFQSxZQUFJSCxVQUFVLElBQWQsRUFBb0I7QUFDbEJBLGtCQUFRTixXQUFXLFlBQVk7QUFDN0JJLGlCQUFLTSxLQUFMLENBQVdILE9BQVgsRUFBb0JDLElBQXBCO0FBQ0FGLG9CQUFRLElBQVI7QUFDRCxXQUhPLEVBR0xELEtBSEssQ0FBUjtBQUlEO0FBQ0YsT0FURDtBQVVEO0FBckJlLEdBQWxCOztBQXdCQTtBQUNBO0FBQ0E7Ozs7QUFJQSxNQUFJN0MsYUFBYSxTQUFiQSxVQUFhLENBQVNtRCxNQUFULEVBQWlCO0FBQ2hDLFFBQUl6RCxjQUFjeUQsTUFBZCx5Q0FBY0EsTUFBZCxDQUFKO0FBQUEsUUFDSUMsUUFBUTdGLEVBQUUsb0JBQUYsQ0FEWjtBQUFBLFFBRUk4RixRQUFROUYsRUFBRSxRQUFGLENBRlo7O0FBSUEsUUFBRyxDQUFDNkYsTUFBTTlDLE1BQVYsRUFBaUI7QUFDZi9DLFFBQUUsOEJBQUYsRUFBa0MrRixRQUFsQyxDQUEyQ25CLFNBQVNvQixJQUFwRDtBQUNEO0FBQ0QsUUFBR0YsTUFBTS9DLE1BQVQsRUFBZ0I7QUFDZCtDLFlBQU1HLFdBQU4sQ0FBa0IsT0FBbEI7QUFDRDs7QUFFRCxRQUFHOUQsU0FBUyxXQUFaLEVBQXdCO0FBQUM7QUFDdkJqQyxpQkFBV2dHLFVBQVgsQ0FBc0JoRSxLQUF0QjtBQUNBaEMsaUJBQVdxRCxNQUFYLENBQWtCLElBQWxCO0FBQ0QsS0FIRCxNQUdNLElBQUdwQixTQUFTLFFBQVosRUFBcUI7QUFBQztBQUMxQixVQUFJc0QsT0FBT1UsTUFBTUMsU0FBTixDQUFnQjlDLEtBQWhCLENBQXNCK0MsSUFBdEIsQ0FBMkJYLFNBQTNCLEVBQXNDLENBQXRDLENBQVgsQ0FEeUIsQ0FDMkI7QUFDcEQsVUFBSVksWUFBWSxLQUFLakYsSUFBTCxDQUFVLFVBQVYsQ0FBaEIsQ0FGeUIsQ0FFYTs7QUFFdEMsVUFBR2lGLGNBQWNDLFNBQWQsSUFBMkJELFVBQVVWLE1BQVYsTUFBc0JXLFNBQXBELEVBQThEO0FBQUM7QUFDN0QsWUFBRyxLQUFLeEQsTUFBTCxLQUFnQixDQUFuQixFQUFxQjtBQUFDO0FBQ2xCdUQsb0JBQVVWLE1BQVYsRUFBa0JELEtBQWxCLENBQXdCVyxTQUF4QixFQUFtQ2IsSUFBbkM7QUFDSCxTQUZELE1BRUs7QUFDSCxlQUFLeEQsSUFBTCxDQUFVLFVBQVN3QixDQUFULEVBQVlZLEVBQVosRUFBZTtBQUFDO0FBQ3hCaUMsc0JBQVVWLE1BQVYsRUFBa0JELEtBQWxCLENBQXdCM0YsRUFBRXFFLEVBQUYsRUFBTWhELElBQU4sQ0FBVyxVQUFYLENBQXhCLEVBQWdEb0UsSUFBaEQ7QUFDRCxXQUZEO0FBR0Q7QUFDRixPQVJELE1BUUs7QUFBQztBQUNKLGNBQU0sSUFBSWUsY0FBSixDQUFtQixtQkFBbUJaLE1BQW5CLEdBQTRCLG1DQUE1QixJQUFtRVUsWUFBWTNGLGFBQWEyRixTQUFiLENBQVosR0FBc0MsY0FBekcsSUFBMkgsR0FBOUksQ0FBTjtBQUNEO0FBQ0YsS0FmSyxNQWVEO0FBQUM7QUFDSixZQUFNLElBQUlHLFNBQUosb0JBQThCdEUsSUFBOUIsa0dBQU47QUFDRDtBQUNELFdBQU8sSUFBUDtBQUNELEdBbENEOztBQW9DQXVFLFNBQU94RyxVQUFQLEdBQW9CQSxVQUFwQjtBQUNBRixJQUFFMkcsRUFBRixDQUFLbEUsVUFBTCxHQUFrQkEsVUFBbEI7O0FBRUE7QUFDQSxHQUFDLFlBQVc7QUFDVixRQUFJLENBQUNtRSxLQUFLQyxHQUFOLElBQWEsQ0FBQ0gsT0FBT0UsSUFBUCxDQUFZQyxHQUE5QixFQUNFSCxPQUFPRSxJQUFQLENBQVlDLEdBQVosR0FBa0JELEtBQUtDLEdBQUwsR0FBVyxZQUFXO0FBQUUsYUFBTyxJQUFJRCxJQUFKLEdBQVdFLE9BQVgsRUFBUDtBQUE4QixLQUF4RTs7QUFFRixRQUFJQyxVQUFVLENBQUMsUUFBRCxFQUFXLEtBQVgsQ0FBZDtBQUNBLFNBQUssSUFBSXRELElBQUksQ0FBYixFQUFnQkEsSUFBSXNELFFBQVFoRSxNQUFaLElBQXNCLENBQUMyRCxPQUFPTSxxQkFBOUMsRUFBcUUsRUFBRXZELENBQXZFLEVBQTBFO0FBQ3RFLFVBQUl3RCxLQUFLRixRQUFRdEQsQ0FBUixDQUFUO0FBQ0FpRCxhQUFPTSxxQkFBUCxHQUErQk4sT0FBT08sS0FBRyx1QkFBVixDQUEvQjtBQUNBUCxhQUFPUSxvQkFBUCxHQUErQlIsT0FBT08sS0FBRyxzQkFBVixLQUNEUCxPQUFPTyxLQUFHLDZCQUFWLENBRDlCO0FBRUg7QUFDRCxRQUFJLHVCQUF1QkUsSUFBdkIsQ0FBNEJULE9BQU9VLFNBQVAsQ0FBaUJDLFNBQTdDLEtBQ0MsQ0FBQ1gsT0FBT00scUJBRFQsSUFDa0MsQ0FBQ04sT0FBT1Esb0JBRDlDLEVBQ29FO0FBQ2xFLFVBQUlJLFdBQVcsQ0FBZjtBQUNBWixhQUFPTSxxQkFBUCxHQUErQixVQUFTTyxRQUFULEVBQW1CO0FBQzlDLFlBQUlWLE1BQU1ELEtBQUtDLEdBQUwsRUFBVjtBQUNBLFlBQUlXLFdBQVd2RSxLQUFLd0UsR0FBTCxDQUFTSCxXQUFXLEVBQXBCLEVBQXdCVCxHQUF4QixDQUFmO0FBQ0EsZUFBTzVCLFdBQVcsWUFBVztBQUFFc0MsbUJBQVNELFdBQVdFLFFBQXBCO0FBQWdDLFNBQXhELEVBQ1dBLFdBQVdYLEdBRHRCLENBQVA7QUFFSCxPQUxEO0FBTUFILGFBQU9RLG9CQUFQLEdBQThCUSxZQUE5QjtBQUNEO0FBQ0Q7OztBQUdBLFFBQUcsQ0FBQ2hCLE9BQU9pQixXQUFSLElBQXVCLENBQUNqQixPQUFPaUIsV0FBUCxDQUFtQmQsR0FBOUMsRUFBa0Q7QUFDaERILGFBQU9pQixXQUFQLEdBQXFCO0FBQ25CQyxlQUFPaEIsS0FBS0MsR0FBTCxFQURZO0FBRW5CQSxhQUFLLGVBQVU7QUFBRSxpQkFBT0QsS0FBS0MsR0FBTCxLQUFhLEtBQUtlLEtBQXpCO0FBQWlDO0FBRi9CLE9BQXJCO0FBSUQ7QUFDRixHQS9CRDtBQWdDQSxNQUFJLENBQUNDLFNBQVN6QixTQUFULENBQW1CMEIsSUFBeEIsRUFBOEI7QUFDNUJELGFBQVN6QixTQUFULENBQW1CMEIsSUFBbkIsR0FBMEIsVUFBU0MsS0FBVCxFQUFnQjtBQUN4QyxVQUFJLE9BQU8sSUFBUCxLQUFnQixVQUFwQixFQUFnQztBQUM5QjtBQUNBO0FBQ0EsY0FBTSxJQUFJdEIsU0FBSixDQUFjLHNFQUFkLENBQU47QUFDRDs7QUFFRCxVQUFJdUIsUUFBVTdCLE1BQU1DLFNBQU4sQ0FBZ0I5QyxLQUFoQixDQUFzQitDLElBQXRCLENBQTJCWCxTQUEzQixFQUFzQyxDQUF0QyxDQUFkO0FBQUEsVUFDSXVDLFVBQVUsSUFEZDtBQUFBLFVBRUlDLE9BQVUsU0FBVkEsSUFBVSxHQUFXLENBQUUsQ0FGM0I7QUFBQSxVQUdJQyxTQUFVLFNBQVZBLE1BQVUsR0FBVztBQUNuQixlQUFPRixRQUFRdEMsS0FBUixDQUFjLGdCQUFnQnVDLElBQWhCLEdBQ1osSUFEWSxHQUVaSCxLQUZGLEVBR0FDLE1BQU1JLE1BQU4sQ0FBYWpDLE1BQU1DLFNBQU4sQ0FBZ0I5QyxLQUFoQixDQUFzQitDLElBQXRCLENBQTJCWCxTQUEzQixDQUFiLENBSEEsQ0FBUDtBQUlELE9BUkw7O0FBVUEsVUFBSSxLQUFLVSxTQUFULEVBQW9CO0FBQ2xCO0FBQ0E4QixhQUFLOUIsU0FBTCxHQUFpQixLQUFLQSxTQUF0QjtBQUNEO0FBQ0QrQixhQUFPL0IsU0FBUCxHQUFtQixJQUFJOEIsSUFBSixFQUFuQjs7QUFFQSxhQUFPQyxNQUFQO0FBQ0QsS0F4QkQ7QUF5QkQ7QUFDRDtBQUNBLFdBQVN4SCxZQUFULENBQXNCZ0csRUFBdEIsRUFBMEI7QUFDeEIsUUFBSWtCLFNBQVN6QixTQUFULENBQW1CM0YsSUFBbkIsS0FBNEI4RixTQUFoQyxFQUEyQztBQUN6QyxVQUFJOEIsZ0JBQWdCLHdCQUFwQjtBQUNBLFVBQUlDLFVBQVdELGFBQUQsQ0FBZ0JFLElBQWhCLENBQXNCNUIsRUFBRCxDQUFLdEQsUUFBTCxFQUFyQixDQUFkO0FBQ0EsYUFBUWlGLFdBQVdBLFFBQVF2RixNQUFSLEdBQWlCLENBQTdCLEdBQWtDdUYsUUFBUSxDQUFSLEVBQVdoRSxJQUFYLEVBQWxDLEdBQXNELEVBQTdEO0FBQ0QsS0FKRCxNQUtLLElBQUlxQyxHQUFHUCxTQUFILEtBQWlCRyxTQUFyQixFQUFnQztBQUNuQyxhQUFPSSxHQUFHM0YsV0FBSCxDQUFlUCxJQUF0QjtBQUNELEtBRkksTUFHQTtBQUNILGFBQU9rRyxHQUFHUCxTQUFILENBQWFwRixXQUFiLENBQXlCUCxJQUFoQztBQUNEO0FBQ0Y7QUFDRCxXQUFTOEQsVUFBVCxDQUFvQmlFLEdBQXBCLEVBQXdCO0FBQ3RCLFFBQUksV0FBV0EsR0FBZixFQUFvQixPQUFPLElBQVAsQ0FBcEIsS0FDSyxJQUFJLFlBQVlBLEdBQWhCLEVBQXFCLE9BQU8sS0FBUCxDQUFyQixLQUNBLElBQUksQ0FBQ0MsTUFBTUQsTUFBTSxDQUFaLENBQUwsRUFBcUIsT0FBT0UsV0FBV0YsR0FBWCxDQUFQO0FBQzFCLFdBQU9BLEdBQVA7QUFDRDtBQUNEO0FBQ0E7QUFDQSxXQUFTM0gsU0FBVCxDQUFtQjJILEdBQW5CLEVBQXdCO0FBQ3RCLFdBQU9BLElBQUlHLE9BQUosQ0FBWSxpQkFBWixFQUErQixPQUEvQixFQUF3QzFILFdBQXhDLEVBQVA7QUFDRDtBQUVBLENBelhBLENBeVhDMkgsTUF6WEQsQ0FBRDtDQ0FBOztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYkUsYUFBVzJJLEdBQVgsR0FBaUI7QUFDZkMsc0JBQWtCQSxnQkFESDtBQUVmQyxtQkFBZUEsYUFGQTtBQUdmQyxnQkFBWUE7O0FBR2Q7Ozs7Ozs7Ozs7QUFOaUIsR0FBakIsQ0FnQkEsU0FBU0YsZ0JBQVQsQ0FBMEJHLE9BQTFCLEVBQW1DQyxNQUFuQyxFQUEyQ0MsTUFBM0MsRUFBbURDLE1BQW5ELEVBQTJEO0FBQ3pELFFBQUlDLFVBQVVOLGNBQWNFLE9BQWQsQ0FBZDtBQUFBLFFBQ0lLLEdBREo7QUFBQSxRQUNTQyxNQURUO0FBQUEsUUFDaUJDLElBRGpCO0FBQUEsUUFDdUJDLEtBRHZCOztBQUdBLFFBQUlQLE1BQUosRUFBWTtBQUNWLFVBQUlRLFVBQVVYLGNBQWNHLE1BQWQsQ0FBZDs7QUFFQUssZUFBVUYsUUFBUU0sTUFBUixDQUFlTCxHQUFmLEdBQXFCRCxRQUFRTyxNQUE3QixJQUF1Q0YsUUFBUUUsTUFBUixHQUFpQkYsUUFBUUMsTUFBUixDQUFlTCxHQUFqRjtBQUNBQSxZQUFVRCxRQUFRTSxNQUFSLENBQWVMLEdBQWYsSUFBc0JJLFFBQVFDLE1BQVIsQ0FBZUwsR0FBL0M7QUFDQUUsYUFBVUgsUUFBUU0sTUFBUixDQUFlSCxJQUFmLElBQXVCRSxRQUFRQyxNQUFSLENBQWVILElBQWhEO0FBQ0FDLGNBQVVKLFFBQVFNLE1BQVIsQ0FBZUgsSUFBZixHQUFzQkgsUUFBUVEsS0FBOUIsSUFBdUNILFFBQVFHLEtBQVIsR0FBZ0JILFFBQVFDLE1BQVIsQ0FBZUgsSUFBaEY7QUFDRCxLQVBELE1BUUs7QUFDSEQsZUFBVUYsUUFBUU0sTUFBUixDQUFlTCxHQUFmLEdBQXFCRCxRQUFRTyxNQUE3QixJQUF1Q1AsUUFBUVMsVUFBUixDQUFtQkYsTUFBbkIsR0FBNEJQLFFBQVFTLFVBQVIsQ0FBbUJILE1BQW5CLENBQTBCTCxHQUF2RztBQUNBQSxZQUFVRCxRQUFRTSxNQUFSLENBQWVMLEdBQWYsSUFBc0JELFFBQVFTLFVBQVIsQ0FBbUJILE1BQW5CLENBQTBCTCxHQUExRDtBQUNBRSxhQUFVSCxRQUFRTSxNQUFSLENBQWVILElBQWYsSUFBdUJILFFBQVFTLFVBQVIsQ0FBbUJILE1BQW5CLENBQTBCSCxJQUEzRDtBQUNBQyxjQUFVSixRQUFRTSxNQUFSLENBQWVILElBQWYsR0FBc0JILFFBQVFRLEtBQTlCLElBQXVDUixRQUFRUyxVQUFSLENBQW1CRCxLQUFwRTtBQUNEOztBQUVELFFBQUlFLFVBQVUsQ0FBQ1IsTUFBRCxFQUFTRCxHQUFULEVBQWNFLElBQWQsRUFBb0JDLEtBQXBCLENBQWQ7O0FBRUEsUUFBSU4sTUFBSixFQUFZO0FBQ1YsYUFBT0ssU0FBU0MsS0FBVCxLQUFtQixJQUExQjtBQUNEOztBQUVELFFBQUlMLE1BQUosRUFBWTtBQUNWLGFBQU9FLFFBQVFDLE1BQVIsS0FBbUIsSUFBMUI7QUFDRDs7QUFFRCxXQUFPUSxRQUFRckksT0FBUixDQUFnQixLQUFoQixNQUEyQixDQUFDLENBQW5DO0FBQ0Q7O0FBRUQ7Ozs7Ozs7QUFPQSxXQUFTcUgsYUFBVCxDQUF1QnZGLElBQXZCLEVBQTZCMkQsSUFBN0IsRUFBa0M7QUFDaEMzRCxXQUFPQSxLQUFLVCxNQUFMLEdBQWNTLEtBQUssQ0FBTCxDQUFkLEdBQXdCQSxJQUEvQjs7QUFFQSxRQUFJQSxTQUFTa0QsTUFBVCxJQUFtQmxELFNBQVNvQixRQUFoQyxFQUEwQztBQUN4QyxZQUFNLElBQUlvRixLQUFKLENBQVUsOENBQVYsQ0FBTjtBQUNEOztBQUVELFFBQUlDLE9BQU96RyxLQUFLMEcscUJBQUwsRUFBWDtBQUFBLFFBQ0lDLFVBQVUzRyxLQUFLNEcsVUFBTCxDQUFnQkYscUJBQWhCLEVBRGQ7QUFBQSxRQUVJRyxVQUFVekYsU0FBUzBGLElBQVQsQ0FBY0oscUJBQWQsRUFGZDtBQUFBLFFBR0lLLE9BQU83RCxPQUFPOEQsV0FIbEI7QUFBQSxRQUlJQyxPQUFPL0QsT0FBT2dFLFdBSmxCOztBQU1BLFdBQU87QUFDTGIsYUFBT0ksS0FBS0osS0FEUDtBQUVMRCxjQUFRSyxLQUFLTCxNQUZSO0FBR0xELGNBQVE7QUFDTkwsYUFBS1csS0FBS1gsR0FBTCxHQUFXaUIsSUFEVjtBQUVOZixjQUFNUyxLQUFLVCxJQUFMLEdBQVlpQjtBQUZaLE9BSEg7QUFPTEUsa0JBQVk7QUFDVmQsZUFBT00sUUFBUU4sS0FETDtBQUVWRCxnQkFBUU8sUUFBUVAsTUFGTjtBQUdWRCxnQkFBUTtBQUNOTCxlQUFLYSxRQUFRYixHQUFSLEdBQWNpQixJQURiO0FBRU5mLGdCQUFNVyxRQUFRWCxJQUFSLEdBQWVpQjtBQUZmO0FBSEUsT0FQUDtBQWVMWCxrQkFBWTtBQUNWRCxlQUFPUSxRQUFRUixLQURMO0FBRVZELGdCQUFRUyxRQUFRVCxNQUZOO0FBR1ZELGdCQUFRO0FBQ05MLGVBQUtpQixJQURDO0FBRU5mLGdCQUFNaUI7QUFGQTtBQUhFO0FBZlAsS0FBUDtBQXdCRDs7QUFFRDs7Ozs7Ozs7Ozs7O0FBWUEsV0FBU3pCLFVBQVQsQ0FBb0JDLE9BQXBCLEVBQTZCMkIsTUFBN0IsRUFBcUNDLFFBQXJDLEVBQStDQyxPQUEvQyxFQUF3REMsT0FBeEQsRUFBaUVDLFVBQWpFLEVBQTZFO0FBQzNFLFFBQUlDLFdBQVdsQyxjQUFjRSxPQUFkLENBQWY7QUFBQSxRQUNJaUMsY0FBY04sU0FBUzdCLGNBQWM2QixNQUFkLENBQVQsR0FBaUMsSUFEbkQ7O0FBR0EsWUFBUUMsUUFBUjtBQUNFLFdBQUssS0FBTDtBQUNFLGVBQU87QUFDTHJCLGdCQUFPdEosV0FBV0ksR0FBWCxLQUFtQjRLLFlBQVl2QixNQUFaLENBQW1CSCxJQUFuQixHQUEwQnlCLFNBQVNwQixLQUFuQyxHQUEyQ3FCLFlBQVlyQixLQUExRSxHQUFrRnFCLFlBQVl2QixNQUFaLENBQW1CSCxJQUR2RztBQUVMRixlQUFLNEIsWUFBWXZCLE1BQVosQ0FBbUJMLEdBQW5CLElBQTBCMkIsU0FBU3JCLE1BQVQsR0FBa0JrQixPQUE1QztBQUZBLFNBQVA7QUFJQTtBQUNGLFdBQUssTUFBTDtBQUNFLGVBQU87QUFDTHRCLGdCQUFNMEIsWUFBWXZCLE1BQVosQ0FBbUJILElBQW5CLElBQTJCeUIsU0FBU3BCLEtBQVQsR0FBaUJrQixPQUE1QyxDQUREO0FBRUx6QixlQUFLNEIsWUFBWXZCLE1BQVosQ0FBbUJMO0FBRm5CLFNBQVA7QUFJQTtBQUNGLFdBQUssT0FBTDtBQUNFLGVBQU87QUFDTEUsZ0JBQU0wQixZQUFZdkIsTUFBWixDQUFtQkgsSUFBbkIsR0FBMEIwQixZQUFZckIsS0FBdEMsR0FBOENrQixPQUQvQztBQUVMekIsZUFBSzRCLFlBQVl2QixNQUFaLENBQW1CTDtBQUZuQixTQUFQO0FBSUE7QUFDRixXQUFLLFlBQUw7QUFDRSxlQUFPO0FBQ0xFLGdCQUFPMEIsWUFBWXZCLE1BQVosQ0FBbUJILElBQW5CLEdBQTJCMEIsWUFBWXJCLEtBQVosR0FBb0IsQ0FBaEQsR0FBdURvQixTQUFTcEIsS0FBVCxHQUFpQixDQUR6RTtBQUVMUCxlQUFLNEIsWUFBWXZCLE1BQVosQ0FBbUJMLEdBQW5CLElBQTBCMkIsU0FBU3JCLE1BQVQsR0FBa0JrQixPQUE1QztBQUZBLFNBQVA7QUFJQTtBQUNGLFdBQUssZUFBTDtBQUNFLGVBQU87QUFDTHRCLGdCQUFNd0IsYUFBYUQsT0FBYixHQUF5QkcsWUFBWXZCLE1BQVosQ0FBbUJILElBQW5CLEdBQTJCMEIsWUFBWXJCLEtBQVosR0FBb0IsQ0FBaEQsR0FBdURvQixTQUFTcEIsS0FBVCxHQUFpQixDQURqRztBQUVMUCxlQUFLNEIsWUFBWXZCLE1BQVosQ0FBbUJMLEdBQW5CLEdBQXlCNEIsWUFBWXRCLE1BQXJDLEdBQThDa0I7QUFGOUMsU0FBUDtBQUlBO0FBQ0YsV0FBSyxhQUFMO0FBQ0UsZUFBTztBQUNMdEIsZ0JBQU0wQixZQUFZdkIsTUFBWixDQUFtQkgsSUFBbkIsSUFBMkJ5QixTQUFTcEIsS0FBVCxHQUFpQmtCLE9BQTVDLENBREQ7QUFFTHpCLGVBQU00QixZQUFZdkIsTUFBWixDQUFtQkwsR0FBbkIsR0FBMEI0QixZQUFZdEIsTUFBWixHQUFxQixDQUFoRCxHQUF1RHFCLFNBQVNyQixNQUFULEdBQWtCO0FBRnpFLFNBQVA7QUFJQTtBQUNGLFdBQUssY0FBTDtBQUNFLGVBQU87QUFDTEosZ0JBQU0wQixZQUFZdkIsTUFBWixDQUFtQkgsSUFBbkIsR0FBMEIwQixZQUFZckIsS0FBdEMsR0FBOENrQixPQUE5QyxHQUF3RCxDQUR6RDtBQUVMekIsZUFBTTRCLFlBQVl2QixNQUFaLENBQW1CTCxHQUFuQixHQUEwQjRCLFlBQVl0QixNQUFaLEdBQXFCLENBQWhELEdBQXVEcUIsU0FBU3JCLE1BQVQsR0FBa0I7QUFGekUsU0FBUDtBQUlBO0FBQ0YsV0FBSyxRQUFMO0FBQ0UsZUFBTztBQUNMSixnQkFBT3lCLFNBQVNuQixVQUFULENBQW9CSCxNQUFwQixDQUEyQkgsSUFBM0IsR0FBbUN5QixTQUFTbkIsVUFBVCxDQUFvQkQsS0FBcEIsR0FBNEIsQ0FBaEUsR0FBdUVvQixTQUFTcEIsS0FBVCxHQUFpQixDQUR6RjtBQUVMUCxlQUFNMkIsU0FBU25CLFVBQVQsQ0FBb0JILE1BQXBCLENBQTJCTCxHQUEzQixHQUFrQzJCLFNBQVNuQixVQUFULENBQW9CRixNQUFwQixHQUE2QixDQUFoRSxHQUF1RXFCLFNBQVNyQixNQUFULEdBQWtCO0FBRnpGLFNBQVA7QUFJQTtBQUNGLFdBQUssUUFBTDtBQUNFLGVBQU87QUFDTEosZ0JBQU0sQ0FBQ3lCLFNBQVNuQixVQUFULENBQW9CRCxLQUFwQixHQUE0Qm9CLFNBQVNwQixLQUF0QyxJQUErQyxDQURoRDtBQUVMUCxlQUFLMkIsU0FBU25CLFVBQVQsQ0FBb0JILE1BQXBCLENBQTJCTCxHQUEzQixHQUFpQ3dCO0FBRmpDLFNBQVA7QUFJRixXQUFLLGFBQUw7QUFDRSxlQUFPO0FBQ0x0QixnQkFBTXlCLFNBQVNuQixVQUFULENBQW9CSCxNQUFwQixDQUEyQkgsSUFENUI7QUFFTEYsZUFBSzJCLFNBQVNuQixVQUFULENBQW9CSCxNQUFwQixDQUEyQkw7QUFGM0IsU0FBUDtBQUlBO0FBQ0YsV0FBSyxhQUFMO0FBQ0UsZUFBTztBQUNMRSxnQkFBTTBCLFlBQVl2QixNQUFaLENBQW1CSCxJQURwQjtBQUVMRixlQUFLNEIsWUFBWXZCLE1BQVosQ0FBbUJMLEdBQW5CLEdBQXlCNEIsWUFBWXRCLE1BQXJDLEdBQThDa0I7QUFGOUMsU0FBUDtBQUlBO0FBQ0YsV0FBSyxjQUFMO0FBQ0UsZUFBTztBQUNMdEIsZ0JBQU0wQixZQUFZdkIsTUFBWixDQUFtQkgsSUFBbkIsR0FBMEIwQixZQUFZckIsS0FBdEMsR0FBOENrQixPQUE5QyxHQUF3REUsU0FBU3BCLEtBRGxFO0FBRUxQLGVBQUs0QixZQUFZdkIsTUFBWixDQUFtQkwsR0FBbkIsR0FBeUI0QixZQUFZdEIsTUFBckMsR0FBOENrQjtBQUY5QyxTQUFQO0FBSUE7QUFDRjtBQUNFLGVBQU87QUFDTHRCLGdCQUFPdEosV0FBV0ksR0FBWCxLQUFtQjRLLFlBQVl2QixNQUFaLENBQW1CSCxJQUFuQixHQUEwQnlCLFNBQVNwQixLQUFuQyxHQUEyQ3FCLFlBQVlyQixLQUExRSxHQUFrRnFCLFlBQVl2QixNQUFaLENBQW1CSCxJQUFuQixHQUEwQnVCLE9BRDlHO0FBRUx6QixlQUFLNEIsWUFBWXZCLE1BQVosQ0FBbUJMLEdBQW5CLEdBQXlCNEIsWUFBWXRCLE1BQXJDLEdBQThDa0I7QUFGOUMsU0FBUDtBQXpFSjtBQThFRDtBQUVBLENBaE1BLENBZ01DbEMsTUFoTUQsQ0FBRDtDQ0ZBOzs7Ozs7OztBQVFBOztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYixNQUFNbUwsV0FBVztBQUNmLE9BQUcsS0FEWTtBQUVmLFFBQUksT0FGVztBQUdmLFFBQUksUUFIVztBQUlmLFFBQUksT0FKVztBQUtmLFFBQUksWUFMVztBQU1mLFFBQUksVUFOVztBQU9mLFFBQUksYUFQVztBQVFmLFFBQUk7QUFSVyxHQUFqQjs7QUFXQSxNQUFJQyxXQUFXLEVBQWY7O0FBRUEsTUFBSUMsV0FBVztBQUNiMUksVUFBTTJJLFlBQVlILFFBQVosQ0FETzs7QUFHYjs7Ozs7O0FBTUFJLFlBVGEsb0JBU0pDLEtBVEksRUFTRztBQUNkLFVBQUlDLE1BQU1OLFNBQVNLLE1BQU1FLEtBQU4sSUFBZUYsTUFBTUcsT0FBOUIsS0FBMENDLE9BQU9DLFlBQVAsQ0FBb0JMLE1BQU1FLEtBQTFCLEVBQWlDSSxXQUFqQyxFQUFwRDs7QUFFQTtBQUNBTCxZQUFNQSxJQUFJOUMsT0FBSixDQUFZLEtBQVosRUFBbUIsRUFBbkIsQ0FBTjs7QUFFQSxVQUFJNkMsTUFBTU8sUUFBVixFQUFvQk4saUJBQWVBLEdBQWY7QUFDcEIsVUFBSUQsTUFBTVEsT0FBVixFQUFtQlAsZ0JBQWNBLEdBQWQ7QUFDbkIsVUFBSUQsTUFBTVMsTUFBVixFQUFrQlIsZUFBYUEsR0FBYjs7QUFFbEI7QUFDQUEsWUFBTUEsSUFBSTlDLE9BQUosQ0FBWSxJQUFaLEVBQWtCLEVBQWxCLENBQU47O0FBRUEsYUFBTzhDLEdBQVA7QUFDRCxLQXZCWTs7O0FBeUJiOzs7Ozs7QUFNQVMsYUEvQmEscUJBK0JIVixLQS9CRyxFQStCSVcsU0EvQkosRUErQmVDLFNBL0JmLEVBK0IwQjtBQUNyQyxVQUFJQyxjQUFjakIsU0FBU2UsU0FBVCxDQUFsQjtBQUFBLFVBQ0VSLFVBQVUsS0FBS0osUUFBTCxDQUFjQyxLQUFkLENBRFo7QUFBQSxVQUVFYyxJQUZGO0FBQUEsVUFHRUMsT0FIRjtBQUFBLFVBSUU1RixFQUpGOztBQU1BLFVBQUksQ0FBQzBGLFdBQUwsRUFBa0IsT0FBT3hKLFFBQVFrQixJQUFSLENBQWEsd0JBQWIsQ0FBUDs7QUFFbEIsVUFBSSxPQUFPc0ksWUFBWUcsR0FBbkIsS0FBMkIsV0FBL0IsRUFBNEM7QUFBRTtBQUMxQ0YsZUFBT0QsV0FBUCxDQUR3QyxDQUNwQjtBQUN2QixPQUZELE1BRU87QUFBRTtBQUNMLFlBQUluTSxXQUFXSSxHQUFYLEVBQUosRUFBc0JnTSxPQUFPdE0sRUFBRXlNLE1BQUYsQ0FBUyxFQUFULEVBQWFKLFlBQVlHLEdBQXpCLEVBQThCSCxZQUFZL0wsR0FBMUMsQ0FBUCxDQUF0QixLQUVLZ00sT0FBT3RNLEVBQUV5TSxNQUFGLENBQVMsRUFBVCxFQUFhSixZQUFZL0wsR0FBekIsRUFBOEIrTCxZQUFZRyxHQUExQyxDQUFQO0FBQ1I7QUFDREQsZ0JBQVVELEtBQUtYLE9BQUwsQ0FBVjs7QUFFQWhGLFdBQUt5RixVQUFVRyxPQUFWLENBQUw7QUFDQSxVQUFJNUYsTUFBTSxPQUFPQSxFQUFQLEtBQWMsVUFBeEIsRUFBb0M7QUFBRTtBQUNwQyxZQUFJK0YsY0FBYy9GLEdBQUdoQixLQUFILEVBQWxCO0FBQ0EsWUFBSXlHLFVBQVVPLE9BQVYsSUFBcUIsT0FBT1AsVUFBVU8sT0FBakIsS0FBNkIsVUFBdEQsRUFBa0U7QUFBRTtBQUNoRVAsb0JBQVVPLE9BQVYsQ0FBa0JELFdBQWxCO0FBQ0g7QUFDRixPQUxELE1BS087QUFDTCxZQUFJTixVQUFVUSxTQUFWLElBQXVCLE9BQU9SLFVBQVVRLFNBQWpCLEtBQStCLFVBQTFELEVBQXNFO0FBQUU7QUFDcEVSLG9CQUFVUSxTQUFWO0FBQ0g7QUFDRjtBQUNGLEtBNURZOzs7QUE4RGI7Ozs7O0FBS0FDLGlCQW5FYSx5QkFtRUN6TCxRQW5FRCxFQW1FVztBQUN0QixVQUFHLENBQUNBLFFBQUosRUFBYztBQUFDLGVBQU8sS0FBUDtBQUFlO0FBQzlCLGFBQU9BLFNBQVN1QyxJQUFULENBQWMsOEtBQWQsRUFBOExtSixNQUE5TCxDQUFxTSxZQUFXO0FBQ3JOLFlBQUksQ0FBQzlNLEVBQUUsSUFBRixFQUFRK00sRUFBUixDQUFXLFVBQVgsQ0FBRCxJQUEyQi9NLEVBQUUsSUFBRixFQUFRTyxJQUFSLENBQWEsVUFBYixJQUEyQixDQUExRCxFQUE2RDtBQUFFLGlCQUFPLEtBQVA7QUFBZSxTQUR1SSxDQUN0STtBQUMvRSxlQUFPLElBQVA7QUFDRCxPQUhNLENBQVA7QUFJRCxLQXpFWTs7O0FBMkViOzs7Ozs7QUFNQXlNLFlBakZhLG9CQWlGSkMsYUFqRkksRUFpRldYLElBakZYLEVBaUZpQjtBQUM1QmxCLGVBQVM2QixhQUFULElBQTBCWCxJQUExQjtBQUNELEtBbkZZOzs7QUFxRmI7Ozs7QUFJQVksYUF6RmEscUJBeUZIOUwsUUF6RkcsRUF5Rk87QUFDbEIsVUFBSStMLGFBQWFqTixXQUFXbUwsUUFBWCxDQUFvQndCLGFBQXBCLENBQWtDekwsUUFBbEMsQ0FBakI7QUFBQSxVQUNJZ00sa0JBQWtCRCxXQUFXRSxFQUFYLENBQWMsQ0FBZCxDQUR0QjtBQUFBLFVBRUlDLGlCQUFpQkgsV0FBV0UsRUFBWCxDQUFjLENBQUMsQ0FBZixDQUZyQjs7QUFJQWpNLGVBQVNtTSxFQUFULENBQVksc0JBQVosRUFBb0MsVUFBUy9CLEtBQVQsRUFBZ0I7QUFDbEQsWUFBSUEsTUFBTWdDLE1BQU4sS0FBaUJGLGVBQWUsQ0FBZixDQUFqQixJQUFzQ3BOLFdBQVdtTCxRQUFYLENBQW9CRSxRQUFwQixDQUE2QkMsS0FBN0IsTUFBd0MsS0FBbEYsRUFBeUY7QUFDdkZBLGdCQUFNaUMsY0FBTjtBQUNBTCwwQkFBZ0JNLEtBQWhCO0FBQ0QsU0FIRCxNQUlLLElBQUlsQyxNQUFNZ0MsTUFBTixLQUFpQkosZ0JBQWdCLENBQWhCLENBQWpCLElBQXVDbE4sV0FBV21MLFFBQVgsQ0FBb0JFLFFBQXBCLENBQTZCQyxLQUE3QixNQUF3QyxXQUFuRixFQUFnRztBQUNuR0EsZ0JBQU1pQyxjQUFOO0FBQ0FILHlCQUFlSSxLQUFmO0FBQ0Q7QUFDRixPQVREO0FBVUQsS0F4R1k7O0FBeUdiOzs7O0FBSUFDLGdCQTdHYSx3QkE2R0F2TSxRQTdHQSxFQTZHVTtBQUNyQkEsZUFBU3dNLEdBQVQsQ0FBYSxzQkFBYjtBQUNEO0FBL0dZLEdBQWY7O0FBa0hBOzs7O0FBSUEsV0FBU3RDLFdBQVQsQ0FBcUJ1QyxHQUFyQixFQUEwQjtBQUN4QixRQUFJQyxJQUFJLEVBQVI7QUFDQSxTQUFLLElBQUlDLEVBQVQsSUFBZUYsR0FBZjtBQUFvQkMsUUFBRUQsSUFBSUUsRUFBSixDQUFGLElBQWFGLElBQUlFLEVBQUosQ0FBYjtBQUFwQixLQUNBLE9BQU9ELENBQVA7QUFDRDs7QUFFRDVOLGFBQVdtTCxRQUFYLEdBQXNCQSxRQUF0QjtBQUVDLENBN0lBLENBNklDekMsTUE3SUQsQ0FBRDtDQ1ZBOzs7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViO0FBQ0EsTUFBTWdPLGlCQUFpQjtBQUNyQixlQUFZLGFBRFM7QUFFckJDLGVBQVksMENBRlM7QUFHckJDLGNBQVcseUNBSFU7QUFJckJDLFlBQVMseURBQ1AsbURBRE8sR0FFUCxtREFGTyxHQUdQLDhDQUhPLEdBSVAsMkNBSk8sR0FLUDtBQVRtQixHQUF2Qjs7QUFZQSxNQUFJakksYUFBYTtBQUNma0ksYUFBUyxFQURNOztBQUdmQyxhQUFTLEVBSE07O0FBS2Y7Ozs7O0FBS0FuTSxTQVZlLG1CQVVQO0FBQ04sVUFBSW9NLE9BQU8sSUFBWDtBQUNBLFVBQUlDLGtCQUFrQnZPLEVBQUUsZ0JBQUYsRUFBb0J3TyxHQUFwQixDQUF3QixhQUF4QixDQUF0QjtBQUNBLFVBQUlDLFlBQUo7O0FBRUFBLHFCQUFlQyxtQkFBbUJILGVBQW5CLENBQWY7O0FBRUEsV0FBSyxJQUFJOUMsR0FBVCxJQUFnQmdELFlBQWhCLEVBQThCO0FBQzVCLFlBQUdBLGFBQWFFLGNBQWIsQ0FBNEJsRCxHQUE1QixDQUFILEVBQXFDO0FBQ25DNkMsZUFBS0YsT0FBTCxDQUFhN00sSUFBYixDQUFrQjtBQUNoQmQsa0JBQU1nTCxHQURVO0FBRWhCbUQsb0RBQXNDSCxhQUFhaEQsR0FBYixDQUF0QztBQUZnQixXQUFsQjtBQUlEO0FBQ0Y7O0FBRUQsV0FBSzRDLE9BQUwsR0FBZSxLQUFLUSxlQUFMLEVBQWY7O0FBRUEsV0FBS0MsUUFBTDtBQUNELEtBN0JjOzs7QUErQmY7Ozs7OztBQU1BQyxXQXJDZSxtQkFxQ1BDLElBckNPLEVBcUNEO0FBQ1osVUFBSUMsUUFBUSxLQUFLQyxHQUFMLENBQVNGLElBQVQsQ0FBWjs7QUFFQSxVQUFJQyxLQUFKLEVBQVc7QUFDVCxlQUFPdkksT0FBT3lJLFVBQVAsQ0FBa0JGLEtBQWxCLEVBQXlCRyxPQUFoQztBQUNEOztBQUVELGFBQU8sS0FBUDtBQUNELEtBN0NjOzs7QUErQ2Y7Ozs7OztBQU1BckMsTUFyRGUsY0FxRFppQyxJQXJEWSxFQXFETjtBQUNQQSxhQUFPQSxLQUFLMUssSUFBTCxHQUFZTCxLQUFaLENBQWtCLEdBQWxCLENBQVA7QUFDQSxVQUFHK0ssS0FBS2pNLE1BQUwsR0FBYyxDQUFkLElBQW1CaU0sS0FBSyxDQUFMLE1BQVksTUFBbEMsRUFBMEM7QUFDeEMsWUFBR0EsS0FBSyxDQUFMLE1BQVksS0FBS0gsZUFBTCxFQUFmLEVBQXVDLE9BQU8sSUFBUDtBQUN4QyxPQUZELE1BRU87QUFDTCxlQUFPLEtBQUtFLE9BQUwsQ0FBYUMsS0FBSyxDQUFMLENBQWIsQ0FBUDtBQUNEO0FBQ0QsYUFBTyxLQUFQO0FBQ0QsS0E3RGM7OztBQStEZjs7Ozs7O0FBTUFFLE9BckVlLGVBcUVYRixJQXJFVyxFQXFFTDtBQUNSLFdBQUssSUFBSXZMLENBQVQsSUFBYyxLQUFLMkssT0FBbkIsRUFBNEI7QUFDMUIsWUFBRyxLQUFLQSxPQUFMLENBQWFPLGNBQWIsQ0FBNEJsTCxDQUE1QixDQUFILEVBQW1DO0FBQ2pDLGNBQUl3TCxRQUFRLEtBQUtiLE9BQUwsQ0FBYTNLLENBQWIsQ0FBWjtBQUNBLGNBQUl1TCxTQUFTQyxNQUFNeE8sSUFBbkIsRUFBeUIsT0FBT3dPLE1BQU1MLEtBQWI7QUFDMUI7QUFDRjs7QUFFRCxhQUFPLElBQVA7QUFDRCxLQTlFYzs7O0FBZ0ZmOzs7Ozs7QUFNQUMsbUJBdEZlLDZCQXNGRztBQUNoQixVQUFJUSxPQUFKOztBQUVBLFdBQUssSUFBSTVMLElBQUksQ0FBYixFQUFnQkEsSUFBSSxLQUFLMkssT0FBTCxDQUFhckwsTUFBakMsRUFBeUNVLEdBQXpDLEVBQThDO0FBQzVDLFlBQUl3TCxRQUFRLEtBQUtiLE9BQUwsQ0FBYTNLLENBQWIsQ0FBWjs7QUFFQSxZQUFJaUQsT0FBT3lJLFVBQVAsQ0FBa0JGLE1BQU1MLEtBQXhCLEVBQStCUSxPQUFuQyxFQUE0QztBQUMxQ0Msb0JBQVVKLEtBQVY7QUFDRDtBQUNGOztBQUVELFVBQUksUUFBT0ksT0FBUCx5Q0FBT0EsT0FBUCxPQUFtQixRQUF2QixFQUFpQztBQUMvQixlQUFPQSxRQUFRNU8sSUFBZjtBQUNELE9BRkQsTUFFTztBQUNMLGVBQU80TyxPQUFQO0FBQ0Q7QUFDRixLQXRHYzs7O0FBd0dmOzs7OztBQUtBUCxZQTdHZSxzQkE2R0o7QUFBQTs7QUFDVDlPLFFBQUUwRyxNQUFGLEVBQVU2RyxFQUFWLENBQWEsc0JBQWIsRUFBcUMsWUFBTTtBQUN6QyxZQUFJK0IsVUFBVSxNQUFLVCxlQUFMLEVBQWQ7QUFBQSxZQUFzQ1UsY0FBYyxNQUFLbEIsT0FBekQ7O0FBRUEsWUFBSWlCLFlBQVlDLFdBQWhCLEVBQTZCO0FBQzNCO0FBQ0EsZ0JBQUtsQixPQUFMLEdBQWVpQixPQUFmOztBQUVBO0FBQ0F0UCxZQUFFMEcsTUFBRixFQUFVcEYsT0FBVixDQUFrQix1QkFBbEIsRUFBMkMsQ0FBQ2dPLE9BQUQsRUFBVUMsV0FBVixDQUEzQztBQUNEO0FBQ0YsT0FWRDtBQVdEO0FBekhjLEdBQWpCOztBQTRIQXJQLGFBQVdnRyxVQUFYLEdBQXdCQSxVQUF4Qjs7QUFFQTtBQUNBO0FBQ0FRLFNBQU95SSxVQUFQLEtBQXNCekksT0FBT3lJLFVBQVAsR0FBb0IsWUFBVztBQUNuRDs7QUFFQTs7QUFDQSxRQUFJSyxhQUFjOUksT0FBTzhJLFVBQVAsSUFBcUI5SSxPQUFPK0ksS0FBOUM7O0FBRUE7QUFDQSxRQUFJLENBQUNELFVBQUwsRUFBaUI7QUFDZixVQUFJeEssUUFBVUosU0FBU0MsYUFBVCxDQUF1QixPQUF2QixDQUFkO0FBQUEsVUFDQTZLLFNBQWM5SyxTQUFTK0ssb0JBQVQsQ0FBOEIsUUFBOUIsRUFBd0MsQ0FBeEMsQ0FEZDtBQUFBLFVBRUFDLE9BQWMsSUFGZDs7QUFJQTVLLFlBQU03QyxJQUFOLEdBQWMsVUFBZDtBQUNBNkMsWUFBTTZLLEVBQU4sR0FBYyxtQkFBZDs7QUFFQUgsZ0JBQVVBLE9BQU90RixVQUFqQixJQUErQnNGLE9BQU90RixVQUFQLENBQWtCMEYsWUFBbEIsQ0FBK0I5SyxLQUEvQixFQUFzQzBLLE1BQXRDLENBQS9COztBQUVBO0FBQ0FFLGFBQVEsc0JBQXNCbEosTUFBdkIsSUFBa0NBLE9BQU9xSixnQkFBUCxDQUF3Qi9LLEtBQXhCLEVBQStCLElBQS9CLENBQWxDLElBQTBFQSxNQUFNZ0wsWUFBdkY7O0FBRUFSLG1CQUFhO0FBQ1hTLG1CQURXLHVCQUNDUixLQURELEVBQ1E7QUFDakIsY0FBSVMsbUJBQWlCVCxLQUFqQiwyQ0FBSjs7QUFFQTtBQUNBLGNBQUl6SyxNQUFNbUwsVUFBVixFQUFzQjtBQUNwQm5MLGtCQUFNbUwsVUFBTixDQUFpQkMsT0FBakIsR0FBMkJGLElBQTNCO0FBQ0QsV0FGRCxNQUVPO0FBQ0xsTCxrQkFBTXFMLFdBQU4sR0FBb0JILElBQXBCO0FBQ0Q7O0FBRUQ7QUFDQSxpQkFBT04sS0FBSy9GLEtBQUwsS0FBZSxLQUF0QjtBQUNEO0FBYlUsT0FBYjtBQWVEOztBQUVELFdBQU8sVUFBUzRGLEtBQVQsRUFBZ0I7QUFDckIsYUFBTztBQUNMTCxpQkFBU0ksV0FBV1MsV0FBWCxDQUF1QlIsU0FBUyxLQUFoQyxDQURKO0FBRUxBLGVBQU9BLFNBQVM7QUFGWCxPQUFQO0FBSUQsS0FMRDtBQU1ELEdBM0N5QyxFQUExQzs7QUE2Q0E7QUFDQSxXQUFTZixrQkFBVCxDQUE0QmxHLEdBQTVCLEVBQWlDO0FBQy9CLFFBQUk4SCxjQUFjLEVBQWxCOztBQUVBLFFBQUksT0FBTzlILEdBQVAsS0FBZSxRQUFuQixFQUE2QjtBQUMzQixhQUFPOEgsV0FBUDtBQUNEOztBQUVEOUgsVUFBTUEsSUFBSWxFLElBQUosR0FBV2hCLEtBQVgsQ0FBaUIsQ0FBakIsRUFBb0IsQ0FBQyxDQUFyQixDQUFOLENBUCtCLENBT0E7O0FBRS9CLFFBQUksQ0FBQ2tGLEdBQUwsRUFBVTtBQUNSLGFBQU84SCxXQUFQO0FBQ0Q7O0FBRURBLGtCQUFjOUgsSUFBSXZFLEtBQUosQ0FBVSxHQUFWLEVBQWVzTSxNQUFmLENBQXNCLFVBQVNDLEdBQVQsRUFBY0MsS0FBZCxFQUFxQjtBQUN2RCxVQUFJQyxRQUFRRCxNQUFNOUgsT0FBTixDQUFjLEtBQWQsRUFBcUIsR0FBckIsRUFBMEIxRSxLQUExQixDQUFnQyxHQUFoQyxDQUFaO0FBQ0EsVUFBSXdILE1BQU1pRixNQUFNLENBQU4sQ0FBVjtBQUNBLFVBQUlDLE1BQU1ELE1BQU0sQ0FBTixDQUFWO0FBQ0FqRixZQUFNbUYsbUJBQW1CbkYsR0FBbkIsQ0FBTjs7QUFFQTtBQUNBO0FBQ0FrRixZQUFNQSxRQUFRcEssU0FBUixHQUFvQixJQUFwQixHQUEyQnFLLG1CQUFtQkQsR0FBbkIsQ0FBakM7O0FBRUEsVUFBSSxDQUFDSCxJQUFJN0IsY0FBSixDQUFtQmxELEdBQW5CLENBQUwsRUFBOEI7QUFDNUIrRSxZQUFJL0UsR0FBSixJQUFXa0YsR0FBWDtBQUNELE9BRkQsTUFFTyxJQUFJeEssTUFBTTBLLE9BQU4sQ0FBY0wsSUFBSS9FLEdBQUosQ0FBZCxDQUFKLEVBQTZCO0FBQ2xDK0UsWUFBSS9FLEdBQUosRUFBU2xLLElBQVQsQ0FBY29QLEdBQWQ7QUFDRCxPQUZNLE1BRUE7QUFDTEgsWUFBSS9FLEdBQUosSUFBVyxDQUFDK0UsSUFBSS9FLEdBQUosQ0FBRCxFQUFXa0YsR0FBWCxDQUFYO0FBQ0Q7QUFDRCxhQUFPSCxHQUFQO0FBQ0QsS0FsQmEsRUFrQlgsRUFsQlcsQ0FBZDs7QUFvQkEsV0FBT0YsV0FBUDtBQUNEOztBQUVEcFEsYUFBV2dHLFVBQVgsR0FBd0JBLFVBQXhCO0FBRUMsQ0FuT0EsQ0FtT0MwQyxNQW5PRCxDQUFEO0NDRkE7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViOzs7OztBQUtBLE1BQU04USxjQUFnQixDQUFDLFdBQUQsRUFBYyxXQUFkLENBQXRCO0FBQ0EsTUFBTUMsZ0JBQWdCLENBQUMsa0JBQUQsRUFBcUIsa0JBQXJCLENBQXRCOztBQUVBLE1BQU1DLFNBQVM7QUFDYkMsZUFBVyxtQkFBU2hJLE9BQVQsRUFBa0JpSSxTQUFsQixFQUE2QkMsRUFBN0IsRUFBaUM7QUFDMUNDLGNBQVEsSUFBUixFQUFjbkksT0FBZCxFQUF1QmlJLFNBQXZCLEVBQWtDQyxFQUFsQztBQUNELEtBSFk7O0FBS2JFLGdCQUFZLG9CQUFTcEksT0FBVCxFQUFrQmlJLFNBQWxCLEVBQTZCQyxFQUE3QixFQUFpQztBQUMzQ0MsY0FBUSxLQUFSLEVBQWVuSSxPQUFmLEVBQXdCaUksU0FBeEIsRUFBbUNDLEVBQW5DO0FBQ0Q7QUFQWSxHQUFmOztBQVVBLFdBQVNHLElBQVQsQ0FBY0MsUUFBZCxFQUF3Qi9OLElBQXhCLEVBQThCbUQsRUFBOUIsRUFBaUM7QUFDL0IsUUFBSTZLLElBQUo7QUFBQSxRQUFVQyxJQUFWO0FBQUEsUUFBZ0I3SixRQUFRLElBQXhCO0FBQ0E7O0FBRUEsUUFBSTJKLGFBQWEsQ0FBakIsRUFBb0I7QUFDbEI1SyxTQUFHaEIsS0FBSCxDQUFTbkMsSUFBVDtBQUNBQSxXQUFLbEMsT0FBTCxDQUFhLHFCQUFiLEVBQW9DLENBQUNrQyxJQUFELENBQXBDLEVBQTRDMEIsY0FBNUMsQ0FBMkQscUJBQTNELEVBQWtGLENBQUMxQixJQUFELENBQWxGO0FBQ0E7QUFDRDs7QUFFRCxhQUFTa08sSUFBVCxDQUFjQyxFQUFkLEVBQWlCO0FBQ2YsVUFBRyxDQUFDL0osS0FBSixFQUFXQSxRQUFRK0osRUFBUjtBQUNYO0FBQ0FGLGFBQU9FLEtBQUsvSixLQUFaO0FBQ0FqQixTQUFHaEIsS0FBSCxDQUFTbkMsSUFBVDs7QUFFQSxVQUFHaU8sT0FBT0YsUUFBVixFQUFtQjtBQUFFQyxlQUFPOUssT0FBT00scUJBQVAsQ0FBNkIwSyxJQUE3QixFQUFtQ2xPLElBQW5DLENBQVA7QUFBa0QsT0FBdkUsTUFDSTtBQUNGa0QsZUFBT1Esb0JBQVAsQ0FBNEJzSyxJQUE1QjtBQUNBaE8sYUFBS2xDLE9BQUwsQ0FBYSxxQkFBYixFQUFvQyxDQUFDa0MsSUFBRCxDQUFwQyxFQUE0QzBCLGNBQTVDLENBQTJELHFCQUEzRCxFQUFrRixDQUFDMUIsSUFBRCxDQUFsRjtBQUNEO0FBQ0Y7QUFDRGdPLFdBQU85SyxPQUFPTSxxQkFBUCxDQUE2QjBLLElBQTdCLENBQVA7QUFDRDs7QUFFRDs7Ozs7Ozs7O0FBU0EsV0FBU04sT0FBVCxDQUFpQlEsSUFBakIsRUFBdUIzSSxPQUF2QixFQUFnQ2lJLFNBQWhDLEVBQTJDQyxFQUEzQyxFQUErQztBQUM3Q2xJLGNBQVVqSixFQUFFaUosT0FBRixFQUFXb0UsRUFBWCxDQUFjLENBQWQsQ0FBVjs7QUFFQSxRQUFJLENBQUNwRSxRQUFRbEcsTUFBYixFQUFxQjs7QUFFckIsUUFBSThPLFlBQVlELE9BQU9kLFlBQVksQ0FBWixDQUFQLEdBQXdCQSxZQUFZLENBQVosQ0FBeEM7QUFDQSxRQUFJZ0IsY0FBY0YsT0FBT2IsY0FBYyxDQUFkLENBQVAsR0FBMEJBLGNBQWMsQ0FBZCxDQUE1Qzs7QUFFQTtBQUNBZ0I7O0FBRUE5SSxZQUNHK0ksUUFESCxDQUNZZCxTQURaLEVBRUcxQyxHQUZILENBRU8sWUFGUCxFQUVxQixNQUZyQjs7QUFJQXhILDBCQUFzQixZQUFNO0FBQzFCaUMsY0FBUStJLFFBQVIsQ0FBaUJILFNBQWpCO0FBQ0EsVUFBSUQsSUFBSixFQUFVM0ksUUFBUWdKLElBQVI7QUFDWCxLQUhEOztBQUtBO0FBQ0FqTCwwQkFBc0IsWUFBTTtBQUMxQmlDLGNBQVEsQ0FBUixFQUFXaUosV0FBWDtBQUNBakosY0FDR3VGLEdBREgsQ0FDTyxZQURQLEVBQ3FCLEVBRHJCLEVBRUd3RCxRQUZILENBRVlGLFdBRlo7QUFHRCxLQUxEOztBQU9BO0FBQ0E3SSxZQUFRa0osR0FBUixDQUFZalMsV0FBV3dFLGFBQVgsQ0FBeUJ1RSxPQUF6QixDQUFaLEVBQStDbUosTUFBL0M7O0FBRUE7QUFDQSxhQUFTQSxNQUFULEdBQWtCO0FBQ2hCLFVBQUksQ0FBQ1IsSUFBTCxFQUFXM0ksUUFBUW9KLElBQVI7QUFDWE47QUFDQSxVQUFJWixFQUFKLEVBQVFBLEdBQUd4TCxLQUFILENBQVNzRCxPQUFUO0FBQ1Q7O0FBRUQ7QUFDQSxhQUFTOEksS0FBVCxHQUFpQjtBQUNmOUksY0FBUSxDQUFSLEVBQVdqRSxLQUFYLENBQWlCc04sa0JBQWpCLEdBQXNDLENBQXRDO0FBQ0FySixjQUFRaEQsV0FBUixDQUF1QjRMLFNBQXZCLFNBQW9DQyxXQUFwQyxTQUFtRFosU0FBbkQ7QUFDRDtBQUNGOztBQUVEaFIsYUFBV29SLElBQVgsR0FBa0JBLElBQWxCO0FBQ0FwUixhQUFXOFEsTUFBWCxHQUFvQkEsTUFBcEI7QUFFQyxDQXRHQSxDQXNHQ3BJLE1BdEdELENBQUQ7Q0NGQTs7QUFFQSxDQUFDLFVBQVM1SSxDQUFULEVBQVk7O0FBRWIsTUFBTXVTLE9BQU87QUFDWEMsV0FEVyxtQkFDSEMsSUFERyxFQUNnQjtBQUFBLFVBQWJ0USxJQUFhLHVFQUFOLElBQU07O0FBQ3pCc1EsV0FBS2xTLElBQUwsQ0FBVSxNQUFWLEVBQWtCLFNBQWxCOztBQUVBLFVBQUltUyxRQUFRRCxLQUFLOU8sSUFBTCxDQUFVLElBQVYsRUFBZ0JwRCxJQUFoQixDQUFxQixFQUFDLFFBQVEsVUFBVCxFQUFyQixDQUFaO0FBQUEsVUFDSW9TLHVCQUFxQnhRLElBQXJCLGFBREo7QUFBQSxVQUVJeVEsZUFBa0JELFlBQWxCLFVBRko7QUFBQSxVQUdJRSxzQkFBb0IxUSxJQUFwQixvQkFISjs7QUFLQXVRLFlBQU16USxJQUFOLENBQVcsWUFBVztBQUNwQixZQUFJNlEsUUFBUTlTLEVBQUUsSUFBRixDQUFaO0FBQUEsWUFDSStTLE9BQU9ELE1BQU1FLFFBQU4sQ0FBZSxJQUFmLENBRFg7O0FBR0EsWUFBSUQsS0FBS2hRLE1BQVQsRUFBaUI7QUFDZitQLGdCQUNHZCxRQURILENBQ1lhLFdBRFosRUFFR3RTLElBRkgsQ0FFUTtBQUNKLDZCQUFpQixJQURiO0FBRUosMEJBQWN1UyxNQUFNRSxRQUFOLENBQWUsU0FBZixFQUEwQjlDLElBQTFCO0FBRlYsV0FGUjtBQU1FO0FBQ0E7QUFDQTtBQUNBLGNBQUcvTixTQUFTLFdBQVosRUFBeUI7QUFDdkIyUSxrQkFBTXZTLElBQU4sQ0FBVyxFQUFDLGlCQUFpQixLQUFsQixFQUFYO0FBQ0Q7O0FBRUh3UyxlQUNHZixRQURILGNBQ3VCVyxZQUR2QixFQUVHcFMsSUFGSCxDQUVRO0FBQ0osNEJBQWdCLEVBRFo7QUFFSixvQkFBUTtBQUZKLFdBRlI7QUFNQSxjQUFHNEIsU0FBUyxXQUFaLEVBQXlCO0FBQ3ZCNFEsaUJBQUt4UyxJQUFMLENBQVUsRUFBQyxlQUFlLElBQWhCLEVBQVY7QUFDRDtBQUNGOztBQUVELFlBQUl1UyxNQUFNNUosTUFBTixDQUFhLGdCQUFiLEVBQStCbkcsTUFBbkMsRUFBMkM7QUFDekMrUCxnQkFBTWQsUUFBTixzQkFBa0NZLFlBQWxDO0FBQ0Q7QUFDRixPQWhDRDs7QUFrQ0E7QUFDRCxLQTVDVTtBQThDWEssUUE5Q1csZ0JBOENOUixJQTlDTSxFQThDQXRRLElBOUNBLEVBOENNO0FBQ2YsVUFBSTtBQUNBd1EsNkJBQXFCeFEsSUFBckIsYUFESjtBQUFBLFVBRUl5USxlQUFrQkQsWUFBbEIsVUFGSjtBQUFBLFVBR0lFLHNCQUFvQjFRLElBQXBCLG9CQUhKOztBQUtBc1EsV0FDRzlPLElBREgsQ0FDUSx3QkFEUixFQUVHc0MsV0FGSCxDQUVrQjBNLFlBRmxCLFNBRWtDQyxZQUZsQyxTQUVrREMsV0FGbEQseUNBR0dsUixVQUhILENBR2MsY0FIZCxFQUc4QjZNLEdBSDlCLENBR2tDLFNBSGxDLEVBRzZDLEVBSDdDOztBQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRDtBQXZFVSxHQUFiOztBQTBFQXRPLGFBQVdxUyxJQUFYLEdBQWtCQSxJQUFsQjtBQUVDLENBOUVBLENBOEVDM0osTUE5RUQsQ0FBRDtDQ0ZBOztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYixXQUFTa1QsS0FBVCxDQUFlMVAsSUFBZixFQUFxQjJQLE9BQXJCLEVBQThCaEMsRUFBOUIsRUFBa0M7QUFDaEMsUUFBSS9PLFFBQVEsSUFBWjtBQUFBLFFBQ0ltUCxXQUFXNEIsUUFBUTVCLFFBRHZCO0FBQUEsUUFDZ0M7QUFDNUI2QixnQkFBWTFRLE9BQU9DLElBQVAsQ0FBWWEsS0FBS25DLElBQUwsRUFBWixFQUF5QixDQUF6QixLQUErQixPQUYvQztBQUFBLFFBR0lnUyxTQUFTLENBQUMsQ0FIZDtBQUFBLFFBSUl6TCxLQUpKO0FBQUEsUUFLSXJDLEtBTEo7O0FBT0EsU0FBSytOLFFBQUwsR0FBZ0IsS0FBaEI7O0FBRUEsU0FBS0MsT0FBTCxHQUFlLFlBQVc7QUFDeEJGLGVBQVMsQ0FBQyxDQUFWO0FBQ0EzTCxtQkFBYW5DLEtBQWI7QUFDQSxXQUFLcUMsS0FBTDtBQUNELEtBSkQ7O0FBTUEsU0FBS0EsS0FBTCxHQUFhLFlBQVc7QUFDdEIsV0FBSzBMLFFBQUwsR0FBZ0IsS0FBaEI7QUFDQTtBQUNBNUwsbUJBQWFuQyxLQUFiO0FBQ0E4TixlQUFTQSxVQUFVLENBQVYsR0FBYzlCLFFBQWQsR0FBeUI4QixNQUFsQztBQUNBN1AsV0FBS25DLElBQUwsQ0FBVSxRQUFWLEVBQW9CLEtBQXBCO0FBQ0F1RyxjQUFRaEIsS0FBS0MsR0FBTCxFQUFSO0FBQ0F0QixjQUFRTixXQUFXLFlBQVU7QUFDM0IsWUFBR2tPLFFBQVFLLFFBQVgsRUFBb0I7QUFDbEJwUixnQkFBTW1SLE9BQU4sR0FEa0IsQ0FDRjtBQUNqQjtBQUNELFlBQUlwQyxNQUFNLE9BQU9BLEVBQVAsS0FBYyxVQUF4QixFQUFvQztBQUFFQTtBQUFPO0FBQzlDLE9BTE8sRUFLTGtDLE1BTEssQ0FBUjtBQU1BN1AsV0FBS2xDLE9BQUwsb0JBQThCOFIsU0FBOUI7QUFDRCxLQWREOztBQWdCQSxTQUFLSyxLQUFMLEdBQWEsWUFBVztBQUN0QixXQUFLSCxRQUFMLEdBQWdCLElBQWhCO0FBQ0E7QUFDQTVMLG1CQUFhbkMsS0FBYjtBQUNBL0IsV0FBS25DLElBQUwsQ0FBVSxRQUFWLEVBQW9CLElBQXBCO0FBQ0EsVUFBSXlELE1BQU04QixLQUFLQyxHQUFMLEVBQVY7QUFDQXdNLGVBQVNBLFVBQVV2TyxNQUFNOEMsS0FBaEIsQ0FBVDtBQUNBcEUsV0FBS2xDLE9BQUwscUJBQStCOFIsU0FBL0I7QUFDRCxLQVJEO0FBU0Q7O0FBRUQ7Ozs7O0FBS0EsV0FBU00sY0FBVCxDQUF3QkMsTUFBeEIsRUFBZ0NwTSxRQUFoQyxFQUF5QztBQUN2QyxRQUFJK0csT0FBTyxJQUFYO0FBQUEsUUFDSXNGLFdBQVdELE9BQU81USxNQUR0Qjs7QUFHQSxRQUFJNlEsYUFBYSxDQUFqQixFQUFvQjtBQUNsQnJNO0FBQ0Q7O0FBRURvTSxXQUFPMVIsSUFBUCxDQUFZLFlBQVc7QUFDckI7QUFDQSxVQUFJLEtBQUs0UixRQUFMLElBQWtCLEtBQUtDLFVBQUwsS0FBb0IsQ0FBdEMsSUFBNkMsS0FBS0EsVUFBTCxLQUFvQixVQUFyRSxFQUFrRjtBQUNoRkM7QUFDRDtBQUNEO0FBSEEsV0FJSztBQUNIO0FBQ0EsY0FBSUMsTUFBTWhVLEVBQUUsSUFBRixFQUFRTyxJQUFSLENBQWEsS0FBYixDQUFWO0FBQ0FQLFlBQUUsSUFBRixFQUFRTyxJQUFSLENBQWEsS0FBYixFQUFvQnlULE1BQU0sR0FBTixHQUFhLElBQUlwTixJQUFKLEdBQVdFLE9BQVgsRUFBakM7QUFDQTlHLFlBQUUsSUFBRixFQUFRbVMsR0FBUixDQUFZLE1BQVosRUFBb0IsWUFBVztBQUM3QjRCO0FBQ0QsV0FGRDtBQUdEO0FBQ0YsS0FkRDs7QUFnQkEsYUFBU0EsaUJBQVQsR0FBNkI7QUFDM0JIO0FBQ0EsVUFBSUEsYUFBYSxDQUFqQixFQUFvQjtBQUNsQnJNO0FBQ0Q7QUFDRjtBQUNGOztBQUVEckgsYUFBV2dULEtBQVgsR0FBbUJBLEtBQW5CO0FBQ0FoVCxhQUFXd1QsY0FBWCxHQUE0QkEsY0FBNUI7QUFFQyxDQXJGQSxDQXFGQzlLLE1BckZELENBQUQ7OztBQ0ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUVYQSxHQUFFaVUsU0FBRixHQUFjO0FBQ1o5VCxXQUFTLE9BREc7QUFFWitULFdBQVMsa0JBQWtCdFAsU0FBU3VQLGVBRnhCO0FBR1oxRyxrQkFBZ0IsS0FISjtBQUlaMkcsaUJBQWUsRUFKSDtBQUtaQyxpQkFBZTtBQUxILEVBQWQ7O0FBUUEsS0FBTUMsU0FBTjtBQUFBLEtBQ01DLFNBRE47QUFBQSxLQUVNQyxTQUZOO0FBQUEsS0FHTUMsV0FITjtBQUFBLEtBSU1DLFdBQVcsS0FKakI7O0FBTUEsVUFBU0MsVUFBVCxHQUFzQjtBQUNwQjtBQUNBLE9BQUtDLG1CQUFMLENBQXlCLFdBQXpCLEVBQXNDQyxXQUF0QztBQUNBLE9BQUtELG1CQUFMLENBQXlCLFVBQXpCLEVBQXFDRCxVQUFyQztBQUNBRCxhQUFXLEtBQVg7QUFDRDs7QUFFRCxVQUFTRyxXQUFULENBQXFCM1EsQ0FBckIsRUFBd0I7QUFDdEIsTUFBSWxFLEVBQUVpVSxTQUFGLENBQVl4RyxjQUFoQixFQUFnQztBQUFFdkosS0FBRXVKLGNBQUY7QUFBcUI7QUFDdkQsTUFBR2lILFFBQUgsRUFBYTtBQUNYLE9BQUlJLElBQUk1USxFQUFFNlEsT0FBRixDQUFVLENBQVYsRUFBYUMsS0FBckI7QUFDQSxPQUFJQyxJQUFJL1EsRUFBRTZRLE9BQUYsQ0FBVSxDQUFWLEVBQWFHLEtBQXJCO0FBQ0EsT0FBSUMsS0FBS2IsWUFBWVEsQ0FBckI7QUFDQSxPQUFJTSxLQUFLYixZQUFZVSxDQUFyQjtBQUNBLE9BQUlJLEdBQUo7QUFDQVosaUJBQWMsSUFBSTdOLElBQUosR0FBV0UsT0FBWCxLQUF1QjBOLFNBQXJDO0FBQ0EsT0FBR3ZSLEtBQUtxUyxHQUFMLENBQVNILEVBQVQsS0FBZ0JuVixFQUFFaVUsU0FBRixDQUFZRyxhQUE1QixJQUE2Q0ssZUFBZXpVLEVBQUVpVSxTQUFGLENBQVlJLGFBQTNFLEVBQTBGO0FBQ3hGZ0IsVUFBTUYsS0FBSyxDQUFMLEdBQVMsTUFBVCxHQUFrQixPQUF4QjtBQUNEO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsT0FBR0UsR0FBSCxFQUFRO0FBQ05uUixNQUFFdUosY0FBRjtBQUNBa0gsZUFBV3RPLElBQVgsQ0FBZ0IsSUFBaEI7QUFDQXJHLE1BQUUsSUFBRixFQUFRc0IsT0FBUixDQUFnQixPQUFoQixFQUF5QitULEdBQXpCLEVBQThCL1QsT0FBOUIsV0FBOEMrVCxHQUE5QztBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxVQUFTRSxZQUFULENBQXNCclIsQ0FBdEIsRUFBeUI7QUFDdkIsTUFBSUEsRUFBRTZRLE9BQUYsQ0FBVWhTLE1BQVYsSUFBb0IsQ0FBeEIsRUFBMkI7QUFDekJ1UixlQUFZcFEsRUFBRTZRLE9BQUYsQ0FBVSxDQUFWLEVBQWFDLEtBQXpCO0FBQ0FULGVBQVlyUSxFQUFFNlEsT0FBRixDQUFVLENBQVYsRUFBYUcsS0FBekI7QUFDQVIsY0FBVyxJQUFYO0FBQ0FGLGVBQVksSUFBSTVOLElBQUosR0FBV0UsT0FBWCxFQUFaO0FBQ0EsUUFBSzBPLGdCQUFMLENBQXNCLFdBQXRCLEVBQW1DWCxXQUFuQyxFQUFnRCxLQUFoRDtBQUNBLFFBQUtXLGdCQUFMLENBQXNCLFVBQXRCLEVBQWtDYixVQUFsQyxFQUE4QyxLQUE5QztBQUNEO0FBQ0Y7O0FBRUQsVUFBU2MsSUFBVCxHQUFnQjtBQUNkLE9BQUtELGdCQUFMLElBQXlCLEtBQUtBLGdCQUFMLENBQXNCLFlBQXRCLEVBQW9DRCxZQUFwQyxFQUFrRCxLQUFsRCxDQUF6QjtBQUNEOztBQUVELFVBQVNHLFFBQVQsR0FBb0I7QUFDbEIsT0FBS2QsbUJBQUwsQ0FBeUIsWUFBekIsRUFBdUNXLFlBQXZDO0FBQ0Q7O0FBRUR2VixHQUFFd0wsS0FBRixDQUFRbUssT0FBUixDQUFnQkMsS0FBaEIsR0FBd0IsRUFBRUMsT0FBT0osSUFBVCxFQUF4Qjs7QUFFQXpWLEdBQUVpQyxJQUFGLENBQU8sQ0FBQyxNQUFELEVBQVMsSUFBVCxFQUFlLE1BQWYsRUFBdUIsT0FBdkIsQ0FBUCxFQUF3QyxZQUFZO0FBQ2xEakMsSUFBRXdMLEtBQUYsQ0FBUW1LLE9BQVIsV0FBd0IsSUFBeEIsSUFBa0MsRUFBRUUsT0FBTyxpQkFBVTtBQUNuRDdWLE1BQUUsSUFBRixFQUFRdU4sRUFBUixDQUFXLE9BQVgsRUFBb0J2TixFQUFFOFYsSUFBdEI7QUFDRCxJQUZpQyxFQUFsQztBQUdELEVBSkQ7QUFLRCxDQXhFRCxFQXdFR2xOLE1BeEVIO0FBeUVBOzs7QUFHQSxDQUFDLFVBQVM1SSxDQUFULEVBQVc7QUFDVkEsR0FBRTJHLEVBQUYsQ0FBS29QLFFBQUwsR0FBZ0IsWUFBVTtBQUN4QixPQUFLOVQsSUFBTCxDQUFVLFVBQVN3QixDQUFULEVBQVdZLEVBQVgsRUFBYztBQUN0QnJFLEtBQUVxRSxFQUFGLEVBQU15RCxJQUFOLENBQVcsMkNBQVgsRUFBdUQsWUFBVTtBQUMvRDtBQUNBO0FBQ0FrTyxnQkFBWXhLLEtBQVo7QUFDRCxJQUpEO0FBS0QsR0FORDs7QUFRQSxNQUFJd0ssY0FBYyxTQUFkQSxXQUFjLENBQVN4SyxLQUFULEVBQWU7QUFDL0IsT0FBSXVKLFVBQVV2SixNQUFNeUssY0FBcEI7QUFBQSxPQUNJQyxRQUFRbkIsUUFBUSxDQUFSLENBRFo7QUFBQSxPQUVJb0IsYUFBYTtBQUNYQyxnQkFBWSxXQUREO0FBRVhDLGVBQVcsV0FGQTtBQUdYQyxjQUFVO0FBSEMsSUFGakI7QUFBQSxPQU9JblUsT0FBT2dVLFdBQVczSyxNQUFNckosSUFBakIsQ0FQWDtBQUFBLE9BUUlvVSxjQVJKOztBQVdBLE9BQUcsZ0JBQWdCN1AsTUFBaEIsSUFBMEIsT0FBT0EsT0FBTzhQLFVBQWQsS0FBNkIsVUFBMUQsRUFBc0U7QUFDcEVELHFCQUFpQixJQUFJN1AsT0FBTzhQLFVBQVgsQ0FBc0JyVSxJQUF0QixFQUE0QjtBQUMzQyxnQkFBVyxJQURnQztBQUUzQyxtQkFBYyxJQUY2QjtBQUczQyxnQkFBVytULE1BQU1PLE9BSDBCO0FBSTNDLGdCQUFXUCxNQUFNUSxPQUowQjtBQUszQyxnQkFBV1IsTUFBTVMsT0FMMEI7QUFNM0MsZ0JBQVdULE1BQU1VO0FBTjBCLEtBQTVCLENBQWpCO0FBUUQsSUFURCxNQVNPO0FBQ0xMLHFCQUFpQjNSLFNBQVNpUyxXQUFULENBQXFCLFlBQXJCLENBQWpCO0FBQ0FOLG1CQUFlTyxjQUFmLENBQThCM1UsSUFBOUIsRUFBb0MsSUFBcEMsRUFBMEMsSUFBMUMsRUFBZ0R1RSxNQUFoRCxFQUF3RCxDQUF4RCxFQUEyRHdQLE1BQU1PLE9BQWpFLEVBQTBFUCxNQUFNUSxPQUFoRixFQUF5RlIsTUFBTVMsT0FBL0YsRUFBd0dULE1BQU1VLE9BQTlHLEVBQXVILEtBQXZILEVBQThILEtBQTlILEVBQXFJLEtBQXJJLEVBQTRJLEtBQTVJLEVBQW1KLENBQW5KLENBQW9KLFFBQXBKLEVBQThKLElBQTlKO0FBQ0Q7QUFDRFYsU0FBTTFJLE1BQU4sQ0FBYXVKLGFBQWIsQ0FBMkJSLGNBQTNCO0FBQ0QsR0ExQkQ7QUEyQkQsRUFwQ0Q7QUFxQ0QsQ0F0Q0EsQ0FzQ0MzTixNQXRDRCxDQUFEOztBQXlDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0MvSEE7Ozs7QUFFQSxDQUFDLFVBQVM1SSxDQUFULEVBQVk7O0FBRWIsTUFBTWdYLG1CQUFvQixZQUFZO0FBQ3BDLFFBQUlDLFdBQVcsQ0FBQyxRQUFELEVBQVcsS0FBWCxFQUFrQixHQUFsQixFQUF1QixJQUF2QixFQUE2QixFQUE3QixDQUFmO0FBQ0EsU0FBSyxJQUFJeFQsSUFBRSxDQUFYLEVBQWNBLElBQUl3VCxTQUFTbFUsTUFBM0IsRUFBbUNVLEdBQW5DLEVBQXdDO0FBQ3RDLFVBQU93VCxTQUFTeFQsQ0FBVCxDQUFILHlCQUFvQ2lELE1BQXhDLEVBQWdEO0FBQzlDLGVBQU9BLE9BQVV1USxTQUFTeFQsQ0FBVCxDQUFWLHNCQUFQO0FBQ0Q7QUFDRjtBQUNELFdBQU8sS0FBUDtBQUNELEdBUnlCLEVBQTFCOztBQVVBLE1BQU15VCxXQUFXLFNBQVhBLFFBQVcsQ0FBQzdTLEVBQUQsRUFBS2xDLElBQUwsRUFBYztBQUM3QmtDLE9BQUdoRCxJQUFILENBQVFjLElBQVIsRUFBYzhCLEtBQWQsQ0FBb0IsR0FBcEIsRUFBeUIxQixPQUF6QixDQUFpQyxjQUFNO0FBQ3JDdkMsY0FBTTZQLEVBQU4sRUFBYTFOLFNBQVMsT0FBVCxHQUFtQixTQUFuQixHQUErQixnQkFBNUMsRUFBaUVBLElBQWpFLGtCQUFvRixDQUFDa0MsRUFBRCxDQUFwRjtBQUNELEtBRkQ7QUFHRCxHQUpEO0FBS0E7QUFDQXJFLElBQUU0RSxRQUFGLEVBQVkySSxFQUFaLENBQWUsa0JBQWYsRUFBbUMsYUFBbkMsRUFBa0QsWUFBVztBQUMzRDJKLGFBQVNsWCxFQUFFLElBQUYsQ0FBVCxFQUFrQixNQUFsQjtBQUNELEdBRkQ7O0FBSUE7QUFDQTtBQUNBQSxJQUFFNEUsUUFBRixFQUFZMkksRUFBWixDQUFlLGtCQUFmLEVBQW1DLGNBQW5DLEVBQW1ELFlBQVc7QUFDNUQsUUFBSXNDLEtBQUs3UCxFQUFFLElBQUYsRUFBUXFCLElBQVIsQ0FBYSxPQUFiLENBQVQ7QUFDQSxRQUFJd08sRUFBSixFQUFRO0FBQ05xSCxlQUFTbFgsRUFBRSxJQUFGLENBQVQsRUFBa0IsT0FBbEI7QUFDRCxLQUZELE1BR0s7QUFDSEEsUUFBRSxJQUFGLEVBQVFzQixPQUFSLENBQWdCLGtCQUFoQjtBQUNEO0FBQ0YsR0FSRDs7QUFVQTtBQUNBdEIsSUFBRTRFLFFBQUYsRUFBWTJJLEVBQVosQ0FBZSxrQkFBZixFQUFtQyxlQUFuQyxFQUFvRCxZQUFXO0FBQzdELFFBQUlzQyxLQUFLN1AsRUFBRSxJQUFGLEVBQVFxQixJQUFSLENBQWEsUUFBYixDQUFUO0FBQ0EsUUFBSXdPLEVBQUosRUFBUTtBQUNOcUgsZUFBU2xYLEVBQUUsSUFBRixDQUFULEVBQWtCLFFBQWxCO0FBQ0QsS0FGRCxNQUVPO0FBQ0xBLFFBQUUsSUFBRixFQUFRc0IsT0FBUixDQUFnQixtQkFBaEI7QUFDRDtBQUNGLEdBUEQ7O0FBU0E7QUFDQXRCLElBQUU0RSxRQUFGLEVBQVkySSxFQUFaLENBQWUsa0JBQWYsRUFBbUMsaUJBQW5DLEVBQXNELFVBQVNySixDQUFULEVBQVc7QUFDL0RBLE1BQUVpVCxlQUFGO0FBQ0EsUUFBSWpHLFlBQVlsUixFQUFFLElBQUYsRUFBUXFCLElBQVIsQ0FBYSxVQUFiLENBQWhCOztBQUVBLFFBQUc2UCxjQUFjLEVBQWpCLEVBQW9CO0FBQ2xCaFIsaUJBQVc4USxNQUFYLENBQWtCSyxVQUFsQixDQUE2QnJSLEVBQUUsSUFBRixDQUE3QixFQUFzQ2tSLFNBQXRDLEVBQWlELFlBQVc7QUFDMURsUixVQUFFLElBQUYsRUFBUXNCLE9BQVIsQ0FBZ0IsV0FBaEI7QUFDRCxPQUZEO0FBR0QsS0FKRCxNQUlLO0FBQ0h0QixRQUFFLElBQUYsRUFBUW9YLE9BQVIsR0FBa0I5VixPQUFsQixDQUEwQixXQUExQjtBQUNEO0FBQ0YsR0FYRDs7QUFhQXRCLElBQUU0RSxRQUFGLEVBQVkySSxFQUFaLENBQWUsa0NBQWYsRUFBbUQscUJBQW5ELEVBQTBFLFlBQVc7QUFDbkYsUUFBSXNDLEtBQUs3UCxFQUFFLElBQUYsRUFBUXFCLElBQVIsQ0FBYSxjQUFiLENBQVQ7QUFDQXJCLFlBQU02UCxFQUFOLEVBQVkzSyxjQUFaLENBQTJCLG1CQUEzQixFQUFnRCxDQUFDbEYsRUFBRSxJQUFGLENBQUQsQ0FBaEQ7QUFDRCxHQUhEOztBQUtBOzs7OztBQUtBQSxJQUFFMEcsTUFBRixFQUFVNkcsRUFBVixDQUFhLE1BQWIsRUFBcUIsWUFBTTtBQUN6QjhKO0FBQ0QsR0FGRDs7QUFJQSxXQUFTQSxjQUFULEdBQTBCO0FBQ3hCQztBQUNBQztBQUNBQztBQUNBQztBQUNBQztBQUNEOztBQUVEO0FBQ0EsV0FBU0EsZUFBVCxDQUF5QjNXLFVBQXpCLEVBQXFDO0FBQ25DLFFBQUk0VyxZQUFZM1gsRUFBRSxpQkFBRixDQUFoQjtBQUFBLFFBQ0k0WCxZQUFZLENBQUMsVUFBRCxFQUFhLFNBQWIsRUFBd0IsUUFBeEIsQ0FEaEI7O0FBR0EsUUFBRzdXLFVBQUgsRUFBYztBQUNaLFVBQUcsT0FBT0EsVUFBUCxLQUFzQixRQUF6QixFQUFrQztBQUNoQzZXLGtCQUFVclcsSUFBVixDQUFlUixVQUFmO0FBQ0QsT0FGRCxNQUVNLElBQUcsUUFBT0EsVUFBUCx5Q0FBT0EsVUFBUCxPQUFzQixRQUF0QixJQUFrQyxPQUFPQSxXQUFXLENBQVgsQ0FBUCxLQUF5QixRQUE5RCxFQUF1RTtBQUMzRTZXLGtCQUFVeFAsTUFBVixDQUFpQnJILFVBQWpCO0FBQ0QsT0FGSyxNQUVEO0FBQ0g4QixnQkFBUUMsS0FBUixDQUFjLDhCQUFkO0FBQ0Q7QUFDRjtBQUNELFFBQUc2VSxVQUFVNVUsTUFBYixFQUFvQjtBQUNsQixVQUFJOFUsWUFBWUQsVUFBVXhULEdBQVYsQ0FBYyxVQUFDM0QsSUFBRCxFQUFVO0FBQ3RDLCtCQUFxQkEsSUFBckI7QUFDRCxPQUZlLEVBRWJxWCxJQUZhLENBRVIsR0FGUSxDQUFoQjs7QUFJQTlYLFFBQUUwRyxNQUFGLEVBQVVrSCxHQUFWLENBQWNpSyxTQUFkLEVBQXlCdEssRUFBekIsQ0FBNEJzSyxTQUE1QixFQUF1QyxVQUFTM1QsQ0FBVCxFQUFZNlQsUUFBWixFQUFxQjtBQUMxRCxZQUFJdlgsU0FBUzBELEVBQUVsQixTQUFGLENBQVlpQixLQUFaLENBQWtCLEdBQWxCLEVBQXVCLENBQXZCLENBQWI7QUFDQSxZQUFJbEMsVUFBVS9CLGFBQVdRLE1BQVgsUUFBc0J3WCxHQUF0QixzQkFBNkNELFFBQTdDLFFBQWQ7O0FBRUFoVyxnQkFBUUUsSUFBUixDQUFhLFlBQVU7QUFDckIsY0FBSUcsUUFBUXBDLEVBQUUsSUFBRixDQUFaOztBQUVBb0MsZ0JBQU04QyxjQUFOLENBQXFCLGtCQUFyQixFQUF5QyxDQUFDOUMsS0FBRCxDQUF6QztBQUNELFNBSkQ7QUFLRCxPQVREO0FBVUQ7QUFDRjs7QUFFRCxXQUFTbVYsY0FBVCxDQUF3QlUsUUFBeEIsRUFBaUM7QUFDL0IsUUFBSTFTLGNBQUo7QUFBQSxRQUNJMlMsU0FBU2xZLEVBQUUsZUFBRixDQURiO0FBRUEsUUFBR2tZLE9BQU9uVixNQUFWLEVBQWlCO0FBQ2YvQyxRQUFFMEcsTUFBRixFQUFVa0gsR0FBVixDQUFjLG1CQUFkLEVBQ0NMLEVBREQsQ0FDSSxtQkFESixFQUN5QixVQUFTckosQ0FBVCxFQUFZO0FBQ25DLFlBQUlxQixLQUFKLEVBQVc7QUFBRW1DLHVCQUFhbkMsS0FBYjtBQUFzQjs7QUFFbkNBLGdCQUFRTixXQUFXLFlBQVU7O0FBRTNCLGNBQUcsQ0FBQytSLGdCQUFKLEVBQXFCO0FBQUM7QUFDcEJrQixtQkFBT2pXLElBQVAsQ0FBWSxZQUFVO0FBQ3BCakMsZ0JBQUUsSUFBRixFQUFRa0YsY0FBUixDQUF1QixxQkFBdkI7QUFDRCxhQUZEO0FBR0Q7QUFDRDtBQUNBZ1QsaUJBQU8zWCxJQUFQLENBQVksYUFBWixFQUEyQixRQUEzQjtBQUNELFNBVE8sRUFTTDBYLFlBQVksRUFUUCxDQUFSLENBSG1DLENBWWhCO0FBQ3BCLE9BZEQ7QUFlRDtBQUNGOztBQUVELFdBQVNULGNBQVQsQ0FBd0JTLFFBQXhCLEVBQWlDO0FBQy9CLFFBQUkxUyxjQUFKO0FBQUEsUUFDSTJTLFNBQVNsWSxFQUFFLGVBQUYsQ0FEYjtBQUVBLFFBQUdrWSxPQUFPblYsTUFBVixFQUFpQjtBQUNmL0MsUUFBRTBHLE1BQUYsRUFBVWtILEdBQVYsQ0FBYyxtQkFBZCxFQUNDTCxFQURELENBQ0ksbUJBREosRUFDeUIsVUFBU3JKLENBQVQsRUFBVztBQUNsQyxZQUFHcUIsS0FBSCxFQUFTO0FBQUVtQyx1QkFBYW5DLEtBQWI7QUFBc0I7O0FBRWpDQSxnQkFBUU4sV0FBVyxZQUFVOztBQUUzQixjQUFHLENBQUMrUixnQkFBSixFQUFxQjtBQUFDO0FBQ3BCa0IsbUJBQU9qVyxJQUFQLENBQVksWUFBVTtBQUNwQmpDLGdCQUFFLElBQUYsRUFBUWtGLGNBQVIsQ0FBdUIscUJBQXZCO0FBQ0QsYUFGRDtBQUdEO0FBQ0Q7QUFDQWdULGlCQUFPM1gsSUFBUCxDQUFZLGFBQVosRUFBMkIsUUFBM0I7QUFDRCxTQVRPLEVBU0wwWCxZQUFZLEVBVFAsQ0FBUixDQUhrQyxDQVlmO0FBQ3BCLE9BZEQ7QUFlRDtBQUNGOztBQUVELFdBQVNSLGNBQVQsQ0FBd0JRLFFBQXhCLEVBQWtDO0FBQzlCLFFBQUlDLFNBQVNsWSxFQUFFLGVBQUYsQ0FBYjtBQUNBLFFBQUlrWSxPQUFPblYsTUFBUCxJQUFpQmlVLGdCQUFyQixFQUFzQztBQUN2QztBQUNHO0FBQ0hrQixhQUFPalcsSUFBUCxDQUFZLFlBQVk7QUFDdEJqQyxVQUFFLElBQUYsRUFBUWtGLGNBQVIsQ0FBdUIscUJBQXZCO0FBQ0QsT0FGRDtBQUdFO0FBQ0g7O0FBRUYsV0FBU29TLGNBQVQsR0FBMEI7QUFDeEIsUUFBRyxDQUFDTixnQkFBSixFQUFxQjtBQUFFLGFBQU8sS0FBUDtBQUFlO0FBQ3RDLFFBQUltQixRQUFRdlQsU0FBU3dULGdCQUFULENBQTBCLDZDQUExQixDQUFaOztBQUVBO0FBQ0EsUUFBSUMsNEJBQTRCLFNBQTVCQSx5QkFBNEIsQ0FBVUMsbUJBQVYsRUFBK0I7QUFDM0QsVUFBSUMsVUFBVXZZLEVBQUVzWSxvQkFBb0IsQ0FBcEIsRUFBdUI5SyxNQUF6QixDQUFkOztBQUVIO0FBQ0csY0FBUThLLG9CQUFvQixDQUFwQixFQUF1Qm5XLElBQS9COztBQUVFLGFBQUssWUFBTDtBQUNFLGNBQUlvVyxRQUFRaFksSUFBUixDQUFhLGFBQWIsTUFBZ0MsUUFBaEMsSUFBNEMrWCxvQkFBb0IsQ0FBcEIsRUFBdUJFLGFBQXZCLEtBQXlDLGFBQXpGLEVBQXdHO0FBQzdHRCxvQkFBUXJULGNBQVIsQ0FBdUIscUJBQXZCLEVBQThDLENBQUNxVCxPQUFELEVBQVU3UixPQUFPOEQsV0FBakIsQ0FBOUM7QUFDQTtBQUNELGNBQUkrTixRQUFRaFksSUFBUixDQUFhLGFBQWIsTUFBZ0MsUUFBaEMsSUFBNEMrWCxvQkFBb0IsQ0FBcEIsRUFBdUJFLGFBQXZCLEtBQXlDLGFBQXpGLEVBQXdHO0FBQ3ZHRCxvQkFBUXJULGNBQVIsQ0FBdUIscUJBQXZCLEVBQThDLENBQUNxVCxPQUFELENBQTlDO0FBQ0M7QUFDRixjQUFJRCxvQkFBb0IsQ0FBcEIsRUFBdUJFLGFBQXZCLEtBQXlDLE9BQTdDLEVBQXNEO0FBQ3JERCxvQkFBUUUsT0FBUixDQUFnQixlQUFoQixFQUFpQ2xZLElBQWpDLENBQXNDLGFBQXRDLEVBQW9ELFFBQXBEO0FBQ0FnWSxvQkFBUUUsT0FBUixDQUFnQixlQUFoQixFQUFpQ3ZULGNBQWpDLENBQWdELHFCQUFoRCxFQUF1RSxDQUFDcVQsUUFBUUUsT0FBUixDQUFnQixlQUFoQixDQUFELENBQXZFO0FBQ0E7QUFDRDs7QUFFSSxhQUFLLFdBQUw7QUFDSkYsa0JBQVFFLE9BQVIsQ0FBZ0IsZUFBaEIsRUFBaUNsWSxJQUFqQyxDQUFzQyxhQUF0QyxFQUFvRCxRQUFwRDtBQUNBZ1ksa0JBQVFFLE9BQVIsQ0FBZ0IsZUFBaEIsRUFBaUN2VCxjQUFqQyxDQUFnRCxxQkFBaEQsRUFBdUUsQ0FBQ3FULFFBQVFFLE9BQVIsQ0FBZ0IsZUFBaEIsQ0FBRCxDQUF2RTtBQUNNOztBQUVGO0FBQ0UsaUJBQU8sS0FBUDtBQUNGO0FBdEJGO0FBd0JELEtBNUJIOztBQThCRSxRQUFJTixNQUFNcFYsTUFBVixFQUFrQjtBQUNoQjtBQUNBLFdBQUssSUFBSVUsSUFBSSxDQUFiLEVBQWdCQSxLQUFLMFUsTUFBTXBWLE1BQU4sR0FBZSxDQUFwQyxFQUF1Q1UsR0FBdkMsRUFBNEM7QUFDMUMsWUFBSWlWLGtCQUFrQixJQUFJMUIsZ0JBQUosQ0FBcUJxQix5QkFBckIsQ0FBdEI7QUFDQUssd0JBQWdCQyxPQUFoQixDQUF3QlIsTUFBTTFVLENBQU4sQ0FBeEIsRUFBa0MsRUFBRW1WLFlBQVksSUFBZCxFQUFvQkMsV0FBVyxJQUEvQixFQUFxQ0MsZUFBZSxLQUFwRCxFQUEyREMsU0FBUyxJQUFwRSxFQUEwRUMsaUJBQWlCLENBQUMsYUFBRCxFQUFnQixPQUFoQixDQUEzRixFQUFsQztBQUNEO0FBQ0Y7QUFDRjs7QUFFSDs7QUFFQTtBQUNBO0FBQ0E5WSxhQUFXK1ksUUFBWCxHQUFzQjVCLGNBQXRCO0FBQ0E7QUFDQTtBQUVDLENBM05BLENBMk5Dek8sTUEzTkQsQ0FBRDs7QUE2TkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Q0NoUUE7Ozs7OztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYjs7Ozs7Ozs7QUFGYSxNQVVQa1osYUFWTztBQVdYOzs7Ozs7O0FBT0EsMkJBQVlqUSxPQUFaLEVBQXFCa0ssT0FBckIsRUFBOEI7QUFBQTs7QUFDNUIsV0FBSy9SLFFBQUwsR0FBZ0I2SCxPQUFoQjtBQUNBLFdBQUtrSyxPQUFMLEdBQWVuVCxFQUFFeU0sTUFBRixDQUFTLEVBQVQsRUFBYXlNLGNBQWNDLFFBQTNCLEVBQXFDLEtBQUsvWCxRQUFMLENBQWNDLElBQWQsRUFBckMsRUFBMkQ4UixPQUEzRCxDQUFmOztBQUVBalQsaUJBQVdxUyxJQUFYLENBQWdCQyxPQUFoQixDQUF3QixLQUFLcFIsUUFBN0IsRUFBdUMsV0FBdkM7O0FBRUEsV0FBS2MsS0FBTDs7QUFFQWhDLGlCQUFXWSxjQUFYLENBQTBCLElBQTFCLEVBQWdDLGVBQWhDO0FBQ0FaLGlCQUFXbUwsUUFBWCxDQUFvQjJCLFFBQXBCLENBQTZCLGVBQTdCLEVBQThDO0FBQzVDLGlCQUFTLFFBRG1DO0FBRTVDLGlCQUFTLFFBRm1DO0FBRzVDLHVCQUFlLE1BSDZCO0FBSTVDLG9CQUFZLElBSmdDO0FBSzVDLHNCQUFjLE1BTDhCO0FBTTVDLHNCQUFjLE9BTjhCO0FBTzVDLGtCQUFVO0FBUGtDLE9BQTlDO0FBU0Q7O0FBSUQ7Ozs7OztBQXhDVztBQUFBO0FBQUEsOEJBNENIO0FBQ04sYUFBSzVMLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsZ0JBQW5CLEVBQXFDcVUsR0FBckMsQ0FBeUMsWUFBekMsRUFBdURvQixPQUF2RCxDQUErRCxDQUEvRCxFQURNLENBQzREO0FBQ2xFLGFBQUtoWSxRQUFMLENBQWNiLElBQWQsQ0FBbUI7QUFDakIsa0JBQVEsTUFEUztBQUVqQixrQ0FBd0IsS0FBSzRTLE9BQUwsQ0FBYWtHO0FBRnBCLFNBQW5COztBQUtBLGFBQUtDLFVBQUwsR0FBa0IsS0FBS2xZLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsOEJBQW5CLENBQWxCO0FBQ0EsYUFBSzJWLFVBQUwsQ0FBZ0JyWCxJQUFoQixDQUFxQixZQUFVO0FBQzdCLGNBQUlzWCxTQUFTLEtBQUsxSixFQUFMLElBQVczUCxXQUFXaUIsV0FBWCxDQUF1QixDQUF2QixFQUEwQixlQUExQixDQUF4QjtBQUFBLGNBQ0l1QyxRQUFRMUQsRUFBRSxJQUFGLENBRFo7QUFBQSxjQUVJK1MsT0FBT3JQLE1BQU1zUCxRQUFOLENBQWUsZ0JBQWYsQ0FGWDtBQUFBLGNBR0l3RyxRQUFRekcsS0FBSyxDQUFMLEVBQVFsRCxFQUFSLElBQWMzUCxXQUFXaUIsV0FBWCxDQUF1QixDQUF2QixFQUEwQixVQUExQixDQUgxQjtBQUFBLGNBSUlzWSxXQUFXMUcsS0FBSzJHLFFBQUwsQ0FBYyxXQUFkLENBSmY7QUFLQWhXLGdCQUFNbkQsSUFBTixDQUFXO0FBQ1QsNkJBQWlCaVosS0FEUjtBQUVULDZCQUFpQkMsUUFGUjtBQUdULG9CQUFRLFVBSEM7QUFJVCxrQkFBTUY7QUFKRyxXQUFYO0FBTUF4RyxlQUFLeFMsSUFBTCxDQUFVO0FBQ1IsK0JBQW1CZ1osTUFEWDtBQUVSLDJCQUFlLENBQUNFLFFBRlI7QUFHUixvQkFBUSxNQUhBO0FBSVIsa0JBQU1EO0FBSkUsV0FBVjtBQU1ELFNBbEJEO0FBbUJBLFlBQUlHLFlBQVksS0FBS3ZZLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsWUFBbkIsQ0FBaEI7QUFDQSxZQUFHZ1csVUFBVTVXLE1BQWIsRUFBb0I7QUFDbEIsY0FBSVgsUUFBUSxJQUFaO0FBQ0F1WCxvQkFBVTFYLElBQVYsQ0FBZSxZQUFVO0FBQ3ZCRyxrQkFBTXdYLElBQU4sQ0FBVzVaLEVBQUUsSUFBRixDQUFYO0FBQ0QsV0FGRDtBQUdEO0FBQ0QsYUFBSzZaLE9BQUw7QUFDRDs7QUFFRDs7Ozs7QUFqRlc7QUFBQTtBQUFBLGdDQXFGRDtBQUNSLFlBQUl6WCxRQUFRLElBQVo7O0FBRUEsYUFBS2hCLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsSUFBbkIsRUFBeUIxQixJQUF6QixDQUE4QixZQUFXO0FBQ3ZDLGNBQUk2WCxXQUFXOVosRUFBRSxJQUFGLEVBQVFnVCxRQUFSLENBQWlCLGdCQUFqQixDQUFmOztBQUVBLGNBQUk4RyxTQUFTL1csTUFBYixFQUFxQjtBQUNuQi9DLGNBQUUsSUFBRixFQUFRZ1QsUUFBUixDQUFpQixHQUFqQixFQUFzQnBGLEdBQXRCLENBQTBCLHdCQUExQixFQUFvREwsRUFBcEQsQ0FBdUQsd0JBQXZELEVBQWlGLFVBQVNySixDQUFULEVBQVk7QUFDM0ZBLGdCQUFFdUosY0FBRjs7QUFFQXJMLG9CQUFNMlgsTUFBTixDQUFhRCxRQUFiO0FBQ0QsYUFKRDtBQUtEO0FBQ0YsU0FWRCxFQVVHdk0sRUFWSCxDQVVNLDBCQVZOLEVBVWtDLFVBQVNySixDQUFULEVBQVc7QUFDM0MsY0FBSTlDLFdBQVdwQixFQUFFLElBQUYsQ0FBZjtBQUFBLGNBQ0lnYSxZQUFZNVksU0FBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsRUFBc0I4SixRQUF0QixDQUErQixJQUEvQixDQURoQjtBQUFBLGNBRUlpSCxZQUZKO0FBQUEsY0FHSUMsWUFISjtBQUFBLGNBSUkzQixVQUFVblgsU0FBUzRSLFFBQVQsQ0FBa0IsZ0JBQWxCLENBSmQ7O0FBTUFnSCxvQkFBVS9YLElBQVYsQ0FBZSxVQUFTd0IsQ0FBVCxFQUFZO0FBQ3pCLGdCQUFJekQsRUFBRSxJQUFGLEVBQVErTSxFQUFSLENBQVczTCxRQUFYLENBQUosRUFBMEI7QUFDeEI2WSw2QkFBZUQsVUFBVTNNLEVBQVYsQ0FBYXBLLEtBQUt3RSxHQUFMLENBQVMsQ0FBVCxFQUFZaEUsSUFBRSxDQUFkLENBQWIsRUFBK0JFLElBQS9CLENBQW9DLEdBQXBDLEVBQXlDdVMsS0FBekMsRUFBZjtBQUNBZ0UsNkJBQWVGLFVBQVUzTSxFQUFWLENBQWFwSyxLQUFLa1gsR0FBTCxDQUFTMVcsSUFBRSxDQUFYLEVBQWN1VyxVQUFValgsTUFBVixHQUFpQixDQUEvQixDQUFiLEVBQWdEWSxJQUFoRCxDQUFxRCxHQUFyRCxFQUEwRHVTLEtBQTFELEVBQWY7O0FBRUEsa0JBQUlsVyxFQUFFLElBQUYsRUFBUWdULFFBQVIsQ0FBaUIsd0JBQWpCLEVBQTJDalEsTUFBL0MsRUFBdUQ7QUFBRTtBQUN2RG1YLCtCQUFlOVksU0FBU3VDLElBQVQsQ0FBYyxnQkFBZCxFQUFnQ0EsSUFBaEMsQ0FBcUMsR0FBckMsRUFBMEN1UyxLQUExQyxFQUFmO0FBQ0Q7QUFDRCxrQkFBSWxXLEVBQUUsSUFBRixFQUFRK00sRUFBUixDQUFXLGNBQVgsQ0FBSixFQUFnQztBQUFFO0FBQ2hDa04sK0JBQWU3WSxTQUFTZ1osT0FBVCxDQUFpQixJQUFqQixFQUF1QmxFLEtBQXZCLEdBQStCdlMsSUFBL0IsQ0FBb0MsR0FBcEMsRUFBeUN1UyxLQUF6QyxFQUFmO0FBQ0QsZUFGRCxNQUVPLElBQUkrRCxhQUFhRyxPQUFiLENBQXFCLElBQXJCLEVBQTJCbEUsS0FBM0IsR0FBbUNsRCxRQUFuQyxDQUE0Qyx3QkFBNUMsRUFBc0VqUSxNQUExRSxFQUFrRjtBQUFFO0FBQ3pGa1gsK0JBQWVBLGFBQWFHLE9BQWIsQ0FBcUIsSUFBckIsRUFBMkJ6VyxJQUEzQixDQUFnQyxlQUFoQyxFQUFpREEsSUFBakQsQ0FBc0QsR0FBdEQsRUFBMkR1UyxLQUEzRCxFQUFmO0FBQ0Q7QUFDRCxrQkFBSWxXLEVBQUUsSUFBRixFQUFRK00sRUFBUixDQUFXLGFBQVgsQ0FBSixFQUErQjtBQUFFO0FBQy9CbU4sK0JBQWU5WSxTQUFTZ1osT0FBVCxDQUFpQixJQUFqQixFQUF1QmxFLEtBQXZCLEdBQStCbUUsSUFBL0IsQ0FBb0MsSUFBcEMsRUFBMEMxVyxJQUExQyxDQUErQyxHQUEvQyxFQUFvRHVTLEtBQXBELEVBQWY7QUFDRDs7QUFFRDtBQUNEO0FBQ0YsV0FuQkQ7O0FBcUJBaFcscUJBQVdtTCxRQUFYLENBQW9CYSxTQUFwQixDQUE4QmhJLENBQTlCLEVBQWlDLGVBQWpDLEVBQWtEO0FBQ2hEb1csa0JBQU0sZ0JBQVc7QUFDZixrQkFBSS9CLFFBQVF4TCxFQUFSLENBQVcsU0FBWCxDQUFKLEVBQTJCO0FBQ3pCM0ssc0JBQU13WCxJQUFOLENBQVdyQixPQUFYO0FBQ0FBLHdCQUFRNVUsSUFBUixDQUFhLElBQWIsRUFBbUJ1UyxLQUFuQixHQUEyQnZTLElBQTNCLENBQWdDLEdBQWhDLEVBQXFDdVMsS0FBckMsR0FBNkN4SSxLQUE3QztBQUNEO0FBQ0YsYUFOK0M7QUFPaEQ2TSxtQkFBTyxpQkFBVztBQUNoQixrQkFBSWhDLFFBQVF4VixNQUFSLElBQWtCLENBQUN3VixRQUFReEwsRUFBUixDQUFXLFNBQVgsQ0FBdkIsRUFBOEM7QUFBRTtBQUM5QzNLLHNCQUFNb1ksRUFBTixDQUFTakMsT0FBVDtBQUNELGVBRkQsTUFFTyxJQUFJblgsU0FBUzhILE1BQVQsQ0FBZ0IsZ0JBQWhCLEVBQWtDbkcsTUFBdEMsRUFBOEM7QUFBRTtBQUNyRFgsc0JBQU1vWSxFQUFOLENBQVNwWixTQUFTOEgsTUFBVCxDQUFnQixnQkFBaEIsQ0FBVDtBQUNBOUgseUJBQVNnWixPQUFULENBQWlCLElBQWpCLEVBQXVCbEUsS0FBdkIsR0FBK0J2UyxJQUEvQixDQUFvQyxHQUFwQyxFQUF5Q3VTLEtBQXpDLEdBQWlEeEksS0FBakQ7QUFDRDtBQUNGLGFBZCtDO0FBZWhEOE0sZ0JBQUksY0FBVztBQUNiUCwyQkFBYXZNLEtBQWI7QUFDQSxxQkFBTyxJQUFQO0FBQ0QsYUFsQitDO0FBbUJoRGtNLGtCQUFNLGdCQUFXO0FBQ2ZNLDJCQUFheE0sS0FBYjtBQUNBLHFCQUFPLElBQVA7QUFDRCxhQXRCK0M7QUF1QmhEcU0sb0JBQVEsa0JBQVc7QUFDakIsa0JBQUkzWSxTQUFTNFIsUUFBVCxDQUFrQixnQkFBbEIsRUFBb0NqUSxNQUF4QyxFQUFnRDtBQUM5Q1gsc0JBQU0yWCxNQUFOLENBQWEzWSxTQUFTNFIsUUFBVCxDQUFrQixnQkFBbEIsQ0FBYjtBQUNEO0FBQ0YsYUEzQitDO0FBNEJoRHlILHNCQUFVLG9CQUFXO0FBQ25Cclksb0JBQU1zWSxPQUFOO0FBQ0QsYUE5QitDO0FBK0JoRC9OLHFCQUFTLGlCQUFTYyxjQUFULEVBQXlCO0FBQ2hDLGtCQUFJQSxjQUFKLEVBQW9CO0FBQ2xCdkosa0JBQUV1SixjQUFGO0FBQ0Q7QUFDRHZKLGdCQUFFeVcsd0JBQUY7QUFDRDtBQXBDK0MsV0FBbEQ7QUFzQ0QsU0E1RUQsRUFIUSxDQStFTDtBQUNKOztBQUVEOzs7OztBQXZLVztBQUFBO0FBQUEsZ0NBMktEO0FBQ1IsYUFBS0gsRUFBTCxDQUFRLEtBQUtwWixRQUFMLENBQWN1QyxJQUFkLENBQW1CLGdCQUFuQixDQUFSO0FBQ0Q7O0FBRUQ7Ozs7O0FBL0tXO0FBQUE7QUFBQSxnQ0FtTEQ7QUFDUixhQUFLaVcsSUFBTCxDQUFVLEtBQUt4WSxRQUFMLENBQWN1QyxJQUFkLENBQW1CLGdCQUFuQixDQUFWO0FBQ0Q7O0FBRUQ7Ozs7OztBQXZMVztBQUFBO0FBQUEsNkJBNExKNFUsT0E1TEksRUE0TEk7QUFDYixZQUFHLENBQUNBLFFBQVF4TCxFQUFSLENBQVcsV0FBWCxDQUFKLEVBQTZCO0FBQzNCLGNBQUksQ0FBQ3dMLFFBQVF4TCxFQUFSLENBQVcsU0FBWCxDQUFMLEVBQTRCO0FBQzFCLGlCQUFLeU4sRUFBTCxDQUFRakMsT0FBUjtBQUNELFdBRkQsTUFHSztBQUNILGlCQUFLcUIsSUFBTCxDQUFVckIsT0FBVjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRDs7Ozs7O0FBdk1XO0FBQUE7QUFBQSwyQkE0TU5BLE9BNU1NLEVBNE1HO0FBQ1osWUFBSW5XLFFBQVEsSUFBWjs7QUFFQSxZQUFHLENBQUMsS0FBSytRLE9BQUwsQ0FBYWtHLFNBQWpCLEVBQTRCO0FBQzFCLGVBQUttQixFQUFMLENBQVEsS0FBS3BaLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsWUFBbkIsRUFBaUNxVSxHQUFqQyxDQUFxQ08sUUFBUXFDLFlBQVIsQ0FBcUIsS0FBS3haLFFBQTFCLEVBQW9DeVosR0FBcEMsQ0FBd0N0QyxPQUF4QyxDQUFyQyxDQUFSO0FBQ0Q7O0FBRURBLGdCQUFRdkcsUUFBUixDQUFpQixXQUFqQixFQUE4QnpSLElBQTlCLENBQW1DLEVBQUMsZUFBZSxLQUFoQixFQUFuQyxFQUNHMkksTUFESCxDQUNVLDhCQURWLEVBQzBDM0ksSUFEMUMsQ0FDK0MsRUFBQyxpQkFBaUIsSUFBbEIsRUFEL0M7O0FBR0U7QUFDRWdZLGdCQUFRdUMsU0FBUixDQUFrQjFZLE1BQU0rUSxPQUFOLENBQWM0SCxVQUFoQyxFQUE0QyxZQUFZO0FBQ3REOzs7O0FBSUEzWSxnQkFBTWhCLFFBQU4sQ0FBZUUsT0FBZixDQUF1Qix1QkFBdkIsRUFBZ0QsQ0FBQ2lYLE9BQUQsQ0FBaEQ7QUFDRCxTQU5EO0FBT0Y7QUFDSDs7QUFFRDs7Ozs7O0FBak9XO0FBQUE7QUFBQSx5QkFzT1JBLE9BdE9RLEVBc09DO0FBQ1YsWUFBSW5XLFFBQVEsSUFBWjtBQUNBO0FBQ0VtVyxnQkFBUWEsT0FBUixDQUFnQmhYLE1BQU0rUSxPQUFOLENBQWM0SCxVQUE5QixFQUEwQyxZQUFZO0FBQ3BEOzs7O0FBSUEzWSxnQkFBTWhCLFFBQU4sQ0FBZUUsT0FBZixDQUF1QixxQkFBdkIsRUFBOEMsQ0FBQ2lYLE9BQUQsQ0FBOUM7QUFDRCxTQU5EO0FBT0Y7O0FBRUEsWUFBSXlDLFNBQVN6QyxRQUFRNVUsSUFBUixDQUFhLGdCQUFiLEVBQStCeVYsT0FBL0IsQ0FBdUMsQ0FBdkMsRUFBMEN4VixPQUExQyxHQUFvRHJELElBQXBELENBQXlELGFBQXpELEVBQXdFLElBQXhFLENBQWI7O0FBRUF5YSxlQUFPOVIsTUFBUCxDQUFjLDhCQUFkLEVBQThDM0ksSUFBOUMsQ0FBbUQsZUFBbkQsRUFBb0UsS0FBcEU7QUFDRDs7QUFFRDs7Ozs7QUF2UFc7QUFBQTtBQUFBLGdDQTJQRDtBQUNSLGFBQUthLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsZ0JBQW5CLEVBQXFDbVgsU0FBckMsQ0FBK0MsQ0FBL0MsRUFBa0R0TSxHQUFsRCxDQUFzRCxTQUF0RCxFQUFpRSxFQUFqRTtBQUNBLGFBQUtwTixRQUFMLENBQWN1QyxJQUFkLENBQW1CLEdBQW5CLEVBQXdCaUssR0FBeEIsQ0FBNEIsd0JBQTVCOztBQUVBMU4sbUJBQVdxUyxJQUFYLENBQWdCVSxJQUFoQixDQUFxQixLQUFLN1IsUUFBMUIsRUFBb0MsV0FBcEM7QUFDQWxCLG1CQUFXc0IsZ0JBQVgsQ0FBNEIsSUFBNUI7QUFDRDtBQWpRVTs7QUFBQTtBQUFBOztBQW9RYjBYLGdCQUFjQyxRQUFkLEdBQXlCO0FBQ3ZCOzs7OztBQUtBNEIsZ0JBQVksR0FOVztBQU92Qjs7Ozs7QUFLQTFCLGVBQVc7QUFaWSxHQUF6Qjs7QUFlQTtBQUNBblosYUFBV00sTUFBWCxDQUFrQjBZLGFBQWxCLEVBQWlDLGVBQWpDO0FBRUMsQ0F0UkEsQ0FzUkN0USxNQXRSRCxDQUFEO0NDRkE7Ozs7OztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYjs7Ozs7Ozs7QUFGYSxNQVVQaWIsU0FWTztBQVdYOzs7Ozs7QUFNQSx1QkFBWWhTLE9BQVosRUFBcUJrSyxPQUFyQixFQUE4QjtBQUFBOztBQUM1QixXQUFLL1IsUUFBTCxHQUFnQjZILE9BQWhCO0FBQ0EsV0FBS2tLLE9BQUwsR0FBZW5ULEVBQUV5TSxNQUFGLENBQVMsRUFBVCxFQUFhd08sVUFBVTlCLFFBQXZCLEVBQWlDLEtBQUsvWCxRQUFMLENBQWNDLElBQWQsRUFBakMsRUFBdUQ4UixPQUF2RCxDQUFmOztBQUVBalQsaUJBQVdxUyxJQUFYLENBQWdCQyxPQUFoQixDQUF3QixLQUFLcFIsUUFBN0IsRUFBdUMsV0FBdkM7O0FBRUEsV0FBS2MsS0FBTDs7QUFFQWhDLGlCQUFXWSxjQUFYLENBQTBCLElBQTFCLEVBQWdDLFdBQWhDO0FBQ0FaLGlCQUFXbUwsUUFBWCxDQUFvQjJCLFFBQXBCLENBQTZCLFdBQTdCLEVBQTBDO0FBQ3hDLGlCQUFTLE1BRCtCO0FBRXhDLGlCQUFTLE1BRitCO0FBR3hDLHVCQUFlLE1BSHlCO0FBSXhDLG9CQUFZLElBSjRCO0FBS3hDLHNCQUFjLE1BTDBCO0FBTXhDLHNCQUFjLFVBTjBCO0FBT3hDLGtCQUFVLE9BUDhCO0FBUXhDLGVBQU8sTUFSaUM7QUFTeEMscUJBQWE7QUFUMkIsT0FBMUM7QUFXRDs7QUFFRDs7Ozs7O0FBdkNXO0FBQUE7QUFBQSw4QkEyQ0g7QUFDTixhQUFLa08sZUFBTCxHQUF1QixLQUFLOVosUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixnQ0FBbkIsRUFBcURxUCxRQUFyRCxDQUE4RCxHQUE5RCxDQUF2QjtBQUNBLGFBQUttSSxTQUFMLEdBQWlCLEtBQUtELGVBQUwsQ0FBcUJoUyxNQUFyQixDQUE0QixJQUE1QixFQUFrQzhKLFFBQWxDLENBQTJDLGdCQUEzQyxDQUFqQjtBQUNBLGFBQUtvSSxVQUFMLEdBQWtCLEtBQUtoYSxRQUFMLENBQWN1QyxJQUFkLENBQW1CLElBQW5CLEVBQXlCcVUsR0FBekIsQ0FBNkIsb0JBQTdCLEVBQW1EelgsSUFBbkQsQ0FBd0QsTUFBeEQsRUFBZ0UsVUFBaEUsRUFBNEVvRCxJQUE1RSxDQUFpRixHQUFqRixDQUFsQjtBQUNBLGFBQUt2QyxRQUFMLENBQWNiLElBQWQsQ0FBbUIsYUFBbkIsRUFBbUMsS0FBS2EsUUFBTCxDQUFjYixJQUFkLENBQW1CLGdCQUFuQixLQUF3Q0wsV0FBV2lCLFdBQVgsQ0FBdUIsQ0FBdkIsRUFBMEIsV0FBMUIsQ0FBM0U7O0FBRUEsYUFBS2thLFlBQUw7QUFDQSxhQUFLQyxlQUFMOztBQUVBLGFBQUtDLGVBQUw7QUFDRDs7QUFFRDs7Ozs7Ozs7QUF2RFc7QUFBQTtBQUFBLHFDQThESTtBQUNiLFlBQUluWixRQUFRLElBQVo7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFLOFksZUFBTCxDQUFxQmpaLElBQXJCLENBQTBCLFlBQVU7QUFDbEMsY0FBSXVaLFFBQVF4YixFQUFFLElBQUYsQ0FBWjtBQUNBLGNBQUkrUyxPQUFPeUksTUFBTXRTLE1BQU4sRUFBWDtBQUNBLGNBQUc5RyxNQUFNK1EsT0FBTixDQUFjc0ksVUFBakIsRUFBNEI7QUFDMUJELGtCQUFNRSxLQUFOLEdBQWNDLFNBQWQsQ0FBd0I1SSxLQUFLQyxRQUFMLENBQWMsZ0JBQWQsQ0FBeEIsRUFBeUQ0SSxJQUF6RCxDQUE4RCxxR0FBOUQ7QUFDRDtBQUNESixnQkFBTW5hLElBQU4sQ0FBVyxXQUFYLEVBQXdCbWEsTUFBTWpiLElBQU4sQ0FBVyxNQUFYLENBQXhCLEVBQTRDb0IsVUFBNUMsQ0FBdUQsTUFBdkQsRUFBK0RwQixJQUEvRCxDQUFvRSxVQUFwRSxFQUFnRixDQUFoRjtBQUNBaWIsZ0JBQU14SSxRQUFOLENBQWUsZ0JBQWYsRUFDS3pTLElBREwsQ0FDVTtBQUNKLDJCQUFlLElBRFg7QUFFSix3QkFBWSxDQUZSO0FBR0osb0JBQVE7QUFISixXQURWO0FBTUE2QixnQkFBTXlYLE9BQU4sQ0FBYzJCLEtBQWQ7QUFDRCxTQWREO0FBZUEsYUFBS0wsU0FBTCxDQUFlbFosSUFBZixDQUFvQixZQUFVO0FBQzVCLGNBQUk0WixRQUFRN2IsRUFBRSxJQUFGLENBQVo7QUFBQSxjQUNJOGIsUUFBUUQsTUFBTWxZLElBQU4sQ0FBVyxvQkFBWCxDQURaO0FBRUEsY0FBRyxDQUFDbVksTUFBTS9ZLE1BQVYsRUFBaUI7QUFDZixvQkFBUVgsTUFBTStRLE9BQU4sQ0FBYzRJLGtCQUF0QjtBQUNFLG1CQUFLLFFBQUw7QUFDRUYsc0JBQU1HLE1BQU4sQ0FBYTVaLE1BQU0rUSxPQUFOLENBQWM4SSxVQUEzQjtBQUNBO0FBQ0YsbUJBQUssS0FBTDtBQUNFSixzQkFBTUssT0FBTixDQUFjOVosTUFBTStRLE9BQU4sQ0FBYzhJLFVBQTVCO0FBQ0E7QUFDRjtBQUNFcFosd0JBQVFDLEtBQVIsQ0FBYywyQ0FBMkNWLE1BQU0rUSxPQUFOLENBQWM0SSxrQkFBekQsR0FBOEUsR0FBNUY7QUFSSjtBQVVEO0FBQ0QzWixnQkFBTStaLEtBQU4sQ0FBWU4sS0FBWjtBQUNELFNBaEJEOztBQWtCQSxZQUFHLENBQUMsS0FBSzFJLE9BQUwsQ0FBYWlKLFVBQWpCLEVBQTZCO0FBQzNCLGVBQUtqQixTQUFMLENBQWVuSixRQUFmLENBQXdCLGtDQUF4QjtBQUNEOztBQUVELFlBQUcsQ0FBQyxLQUFLNVEsUUFBTCxDQUFjOEgsTUFBZCxHQUF1QndRLFFBQXZCLENBQWdDLGNBQWhDLENBQUosRUFBb0Q7QUFDbEQsZUFBSzJDLFFBQUwsR0FBZ0JyYyxFQUFFLEtBQUttVCxPQUFMLENBQWFtSixPQUFmLEVBQXdCdEssUUFBeEIsQ0FBaUMsY0FBakMsQ0FBaEI7QUFDQSxjQUFHLEtBQUttQixPQUFMLENBQWFvSixhQUFoQixFQUErQixLQUFLRixRQUFMLENBQWNySyxRQUFkLENBQXVCLGdCQUF2QjtBQUMvQixlQUFLcUssUUFBTCxHQUFnQixLQUFLamIsUUFBTCxDQUFjd2EsSUFBZCxDQUFtQixLQUFLUyxRQUF4QixFQUFrQ25ULE1BQWxDLEdBQTJDc0YsR0FBM0MsQ0FBK0MsS0FBS2dPLFdBQUwsRUFBL0MsQ0FBaEI7QUFDRDtBQUNGO0FBN0dVO0FBQUE7QUFBQSxnQ0ErR0Q7QUFDUixhQUFLSCxRQUFMLENBQWM3TixHQUFkLENBQWtCLEVBQUMsYUFBYSxNQUFkLEVBQXNCLGNBQWMsTUFBcEMsRUFBbEI7QUFDQTtBQUNBLGFBQUs2TixRQUFMLENBQWM3TixHQUFkLENBQWtCLEtBQUtnTyxXQUFMLEVBQWxCO0FBQ0Q7O0FBRUQ7Ozs7Ozs7QUFySFc7QUFBQTtBQUFBLDhCQTJISDlZLEtBM0hHLEVBMkhJO0FBQ2IsWUFBSXRCLFFBQVEsSUFBWjs7QUFFQXNCLGNBQU1rSyxHQUFOLENBQVUsb0JBQVYsRUFDQ0wsRUFERCxDQUNJLG9CQURKLEVBQzBCLFVBQVNySixDQUFULEVBQVc7QUFDbkMsY0FBR2xFLEVBQUVrRSxFQUFFc0osTUFBSixFQUFZb04sWUFBWixDQUF5QixJQUF6QixFQUErQixJQUEvQixFQUFxQ2xCLFFBQXJDLENBQThDLDZCQUE5QyxDQUFILEVBQWdGO0FBQzlFeFYsY0FBRXlXLHdCQUFGO0FBQ0F6VyxjQUFFdUosY0FBRjtBQUNEOztBQUVEO0FBQ0E7QUFDQTtBQUNBckwsZ0JBQU1xYSxLQUFOLENBQVkvWSxNQUFNd0YsTUFBTixDQUFhLElBQWIsQ0FBWjs7QUFFQSxjQUFHOUcsTUFBTStRLE9BQU4sQ0FBY3VKLFlBQWpCLEVBQThCO0FBQzVCLGdCQUFJQyxRQUFRM2MsRUFBRSxNQUFGLENBQVo7QUFDQTJjLGtCQUFNL08sR0FBTixDQUFVLGVBQVYsRUFBMkJMLEVBQTNCLENBQThCLG9CQUE5QixFQUFvRCxVQUFTckosQ0FBVCxFQUFXO0FBQzdELGtCQUFJQSxFQUFFc0osTUFBRixLQUFhcEwsTUFBTWhCLFFBQU4sQ0FBZSxDQUFmLENBQWIsSUFBa0NwQixFQUFFNGMsUUFBRixDQUFXeGEsTUFBTWhCLFFBQU4sQ0FBZSxDQUFmLENBQVgsRUFBOEI4QyxFQUFFc0osTUFBaEMsQ0FBdEMsRUFBK0U7QUFBRTtBQUFTO0FBQzFGdEosZ0JBQUV1SixjQUFGO0FBQ0FyTCxvQkFBTXlhLFFBQU47QUFDQUYsb0JBQU0vTyxHQUFOLENBQVUsZUFBVjtBQUNELGFBTEQ7QUFNRDtBQUNGLFNBckJEO0FBc0JELGFBQUt4TSxRQUFMLENBQWNtTSxFQUFkLENBQWlCLHFCQUFqQixFQUF3QyxLQUFLdVAsT0FBTCxDQUFhaFYsSUFBYixDQUFrQixJQUFsQixDQUF4QztBQUNBOztBQUVEOzs7Ozs7QUF2Slc7QUFBQTtBQUFBLHdDQTRKTztBQUNoQixZQUFHLEtBQUtxTCxPQUFMLENBQWE0SixTQUFoQixFQUEwQjtBQUN4QixlQUFLQyxZQUFMLEdBQW9CLEtBQUtDLFVBQUwsQ0FBZ0JuVixJQUFoQixDQUFxQixJQUFyQixDQUFwQjtBQUNBLGVBQUsxRyxRQUFMLENBQWNtTSxFQUFkLENBQWlCLHlEQUFqQixFQUEyRSxLQUFLeVAsWUFBaEY7QUFDRDtBQUNGOztBQUVEOzs7Ozs7QUFuS1c7QUFBQTtBQUFBLG1DQXdLRTtBQUNYLFlBQUk1YSxRQUFRLElBQVo7QUFDQSxZQUFJOGEsb0JBQW9COWEsTUFBTStRLE9BQU4sQ0FBY2dLLGdCQUFkLElBQWdDLEVBQWhDLEdBQW1DbmQsRUFBRW9DLE1BQU0rUSxPQUFOLENBQWNnSyxnQkFBaEIsQ0FBbkMsR0FBcUUvYSxNQUFNaEIsUUFBbkc7QUFBQSxZQUNJZ2MsWUFBWUMsU0FBU0gsa0JBQWtCdlQsTUFBbEIsR0FBMkJMLEdBQTNCLEdBQStCbEgsTUFBTStRLE9BQU4sQ0FBY21LLGVBQXRELENBRGhCO0FBRUF0ZCxVQUFFLFlBQUYsRUFBZ0J1ZCxJQUFoQixDQUFxQixJQUFyQixFQUEyQm5NLE9BQTNCLENBQW1DLEVBQUUyTCxXQUFXSyxTQUFiLEVBQW5DLEVBQTZEaGIsTUFBTStRLE9BQU4sQ0FBY3FLLGlCQUEzRSxFQUE4RnBiLE1BQU0rUSxPQUFOLENBQWNzSyxlQUE1RyxFQUE0SCxZQUFVO0FBQ3BJOzs7O0FBSUEsY0FBRyxTQUFPemQsRUFBRSxNQUFGLEVBQVUsQ0FBVixDQUFWLEVBQXVCb0MsTUFBTWhCLFFBQU4sQ0FBZUUsT0FBZixDQUF1Qix1QkFBdkI7QUFDeEIsU0FORDtBQU9EOztBQUVEOzs7OztBQXJMVztBQUFBO0FBQUEsd0NBeUxPO0FBQ2hCLFlBQUljLFFBQVEsSUFBWjs7QUFFQSxhQUFLZ1osVUFBTCxDQUFnQlAsR0FBaEIsQ0FBb0IsS0FBS3paLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIscURBQW5CLENBQXBCLEVBQStGNEosRUFBL0YsQ0FBa0csc0JBQWxHLEVBQTBILFVBQVNySixDQUFULEVBQVc7QUFDbkksY0FBSTlDLFdBQVdwQixFQUFFLElBQUYsQ0FBZjtBQUFBLGNBQ0lnYSxZQUFZNVksU0FBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsRUFBc0JBLE1BQXRCLENBQTZCLElBQTdCLEVBQW1DOEosUUFBbkMsQ0FBNEMsSUFBNUMsRUFBa0RBLFFBQWxELENBQTJELEdBQTNELENBRGhCO0FBQUEsY0FFSWlILFlBRko7QUFBQSxjQUdJQyxZQUhKOztBQUtBRixvQkFBVS9YLElBQVYsQ0FBZSxVQUFTd0IsQ0FBVCxFQUFZO0FBQ3pCLGdCQUFJekQsRUFBRSxJQUFGLEVBQVErTSxFQUFSLENBQVczTCxRQUFYLENBQUosRUFBMEI7QUFDeEI2WSw2QkFBZUQsVUFBVTNNLEVBQVYsQ0FBYXBLLEtBQUt3RSxHQUFMLENBQVMsQ0FBVCxFQUFZaEUsSUFBRSxDQUFkLENBQWIsQ0FBZjtBQUNBeVcsNkJBQWVGLFVBQVUzTSxFQUFWLENBQWFwSyxLQUFLa1gsR0FBTCxDQUFTMVcsSUFBRSxDQUFYLEVBQWN1VyxVQUFValgsTUFBVixHQUFpQixDQUEvQixDQUFiLENBQWY7QUFDQTtBQUNEO0FBQ0YsV0FORDs7QUFRQTdDLHFCQUFXbUwsUUFBWCxDQUFvQmEsU0FBcEIsQ0FBOEJoSSxDQUE5QixFQUFpQyxXQUFqQyxFQUE4QztBQUM1Q21XLGtCQUFNLGdCQUFXO0FBQ2Ysa0JBQUlqWixTQUFTMkwsRUFBVCxDQUFZM0ssTUFBTThZLGVBQWxCLENBQUosRUFBd0M7QUFDdEM5WSxzQkFBTXFhLEtBQU4sQ0FBWXJiLFNBQVM4SCxNQUFULENBQWdCLElBQWhCLENBQVo7QUFDQTlILHlCQUFTOEgsTUFBVCxDQUFnQixJQUFoQixFQUFzQmlKLEdBQXRCLENBQTBCalMsV0FBV3dFLGFBQVgsQ0FBeUJ0RCxRQUF6QixDQUExQixFQUE4RCxZQUFVO0FBQ3RFQSwyQkFBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsRUFBc0J2RixJQUF0QixDQUEyQixTQUEzQixFQUFzQ21KLE1BQXRDLENBQTZDMUssTUFBTWdaLFVBQW5ELEVBQStEbEYsS0FBL0QsR0FBdUV4SSxLQUF2RTtBQUNELGlCQUZEO0FBR0EsdUJBQU8sSUFBUDtBQUNEO0FBQ0YsYUFUMkM7QUFVNUNnUSxzQkFBVSxvQkFBVztBQUNuQnRiLG9CQUFNdWIsS0FBTixDQUFZdmMsU0FBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsRUFBc0JBLE1BQXRCLENBQTZCLElBQTdCLENBQVo7QUFDQTlILHVCQUFTOEgsTUFBVCxDQUFnQixJQUFoQixFQUFzQkEsTUFBdEIsQ0FBNkIsSUFBN0IsRUFBbUNpSixHQUFuQyxDQUF1Q2pTLFdBQVd3RSxhQUFYLENBQXlCdEQsUUFBekIsQ0FBdkMsRUFBMkUsWUFBVTtBQUNuRjZELDJCQUFXLFlBQVc7QUFDcEI3RCwyQkFBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsRUFBc0JBLE1BQXRCLENBQTZCLElBQTdCLEVBQW1DQSxNQUFuQyxDQUEwQyxJQUExQyxFQUFnRDhKLFFBQWhELENBQXlELEdBQXpELEVBQThEa0QsS0FBOUQsR0FBc0V4SSxLQUF0RTtBQUNELGlCQUZELEVBRUcsQ0FGSDtBQUdELGVBSkQ7QUFLQSxxQkFBTyxJQUFQO0FBQ0QsYUFsQjJDO0FBbUI1QzhNLGdCQUFJLGNBQVc7QUFDYlAsMkJBQWF2TSxLQUFiO0FBQ0EscUJBQU8sSUFBUDtBQUNELGFBdEIyQztBQXVCNUNrTSxrQkFBTSxnQkFBVztBQUNmTSwyQkFBYXhNLEtBQWI7QUFDQSxxQkFBTyxJQUFQO0FBQ0QsYUExQjJDO0FBMkI1QzZNLG1CQUFPLGlCQUFXO0FBQ2hCblksb0JBQU0rWixLQUFOO0FBQ0E7QUFDRCxhQTlCMkM7QUErQjVDN0Isa0JBQU0sZ0JBQVc7QUFDZixrQkFBSSxDQUFDbFosU0FBUzJMLEVBQVQsQ0FBWTNLLE1BQU1nWixVQUFsQixDQUFMLEVBQW9DO0FBQUU7QUFDcENoWixzQkFBTXViLEtBQU4sQ0FBWXZjLFNBQVM4SCxNQUFULENBQWdCLElBQWhCLEVBQXNCQSxNQUF0QixDQUE2QixJQUE3QixDQUFaO0FBQ0E5SCx5QkFBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsRUFBc0JBLE1BQXRCLENBQTZCLElBQTdCLEVBQW1DaUosR0FBbkMsQ0FBdUNqUyxXQUFXd0UsYUFBWCxDQUF5QnRELFFBQXpCLENBQXZDLEVBQTJFLFlBQVU7QUFDbkY2RCw2QkFBVyxZQUFXO0FBQ3BCN0QsNkJBQVM4SCxNQUFULENBQWdCLElBQWhCLEVBQXNCQSxNQUF0QixDQUE2QixJQUE3QixFQUFtQ0EsTUFBbkMsQ0FBMEMsSUFBMUMsRUFBZ0Q4SixRQUFoRCxDQUF5RCxHQUF6RCxFQUE4RGtELEtBQTlELEdBQXNFeEksS0FBdEU7QUFDRCxtQkFGRCxFQUVHLENBRkg7QUFHRCxpQkFKRDtBQUtBLHVCQUFPLElBQVA7QUFDRCxlQVJELE1BUU8sSUFBSXRNLFNBQVMyTCxFQUFULENBQVkzSyxNQUFNOFksZUFBbEIsQ0FBSixFQUF3QztBQUM3QzlZLHNCQUFNcWEsS0FBTixDQUFZcmIsU0FBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsQ0FBWjtBQUNBOUgseUJBQVM4SCxNQUFULENBQWdCLElBQWhCLEVBQXNCaUosR0FBdEIsQ0FBMEJqUyxXQUFXd0UsYUFBWCxDQUF5QnRELFFBQXpCLENBQTFCLEVBQThELFlBQVU7QUFDdEVBLDJCQUFTOEgsTUFBVCxDQUFnQixJQUFoQixFQUFzQnZGLElBQXRCLENBQTJCLFNBQTNCLEVBQXNDbUosTUFBdEMsQ0FBNkMxSyxNQUFNZ1osVUFBbkQsRUFBK0RsRixLQUEvRCxHQUF1RXhJLEtBQXZFO0FBQ0QsaUJBRkQ7QUFHQSx1QkFBTyxJQUFQO0FBQ0Q7QUFDRixhQS9DMkM7QUFnRDVDZixxQkFBUyxpQkFBU2MsY0FBVCxFQUF5QjtBQUNoQyxrQkFBSUEsY0FBSixFQUFvQjtBQUNsQnZKLGtCQUFFdUosY0FBRjtBQUNEO0FBQ0R2SixnQkFBRXlXLHdCQUFGO0FBQ0Q7QUFyRDJDLFdBQTlDO0FBdURELFNBckVELEVBSGdCLENBd0VaO0FBQ0w7O0FBRUQ7Ozs7OztBQXBRVztBQUFBO0FBQUEsaUNBeVFBO0FBQ1QsWUFBSWpYLFFBQVEsS0FBS3RDLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsaUNBQW5CLEVBQXNEcU8sUUFBdEQsQ0FBK0QsWUFBL0QsQ0FBWjtBQUNBLFlBQUcsS0FBS21CLE9BQUwsQ0FBYWlKLFVBQWhCLEVBQTRCLEtBQUtDLFFBQUwsQ0FBYzdOLEdBQWQsQ0FBa0IsRUFBQzVFLFFBQU9sRyxNQUFNd0YsTUFBTixHQUFldVAsT0FBZixDQUF1QixJQUF2QixFQUE2QnBYLElBQTdCLENBQWtDLFlBQWxDLENBQVIsRUFBbEI7QUFDNUJxQyxjQUFNeU8sR0FBTixDQUFValMsV0FBV3dFLGFBQVgsQ0FBeUJoQixLQUF6QixDQUFWLEVBQTJDLFVBQVNRLENBQVQsRUFBVztBQUNwRFIsZ0JBQU11QyxXQUFOLENBQWtCLHNCQUFsQjtBQUNELFNBRkQ7QUFHSTs7OztBQUlKLGFBQUs3RSxRQUFMLENBQWNFLE9BQWQsQ0FBc0IscUJBQXRCO0FBQ0Q7O0FBRUQ7Ozs7Ozs7QUF0Ulc7QUFBQTtBQUFBLDRCQTRSTG9DLEtBNVJLLEVBNFJFO0FBQ1gsWUFBSXRCLFFBQVEsSUFBWjtBQUNBc0IsY0FBTWtLLEdBQU4sQ0FBVSxvQkFBVjtBQUNBbEssY0FBTXNQLFFBQU4sQ0FBZSxvQkFBZixFQUNHekYsRUFESCxDQUNNLG9CQUROLEVBQzRCLFVBQVNySixDQUFULEVBQVc7QUFDbkNBLFlBQUV5Vyx3QkFBRjtBQUNBO0FBQ0F2WSxnQkFBTXViLEtBQU4sQ0FBWWphLEtBQVo7O0FBRUE7QUFDQSxjQUFJa2EsZ0JBQWdCbGEsTUFBTXdGLE1BQU4sQ0FBYSxJQUFiLEVBQW1CQSxNQUFuQixDQUEwQixJQUExQixFQUFnQ0EsTUFBaEMsQ0FBdUMsSUFBdkMsQ0FBcEI7QUFDQSxjQUFJMFUsY0FBYzdhLE1BQWxCLEVBQTBCO0FBQ3hCWCxrQkFBTXFhLEtBQU4sQ0FBWW1CLGFBQVo7QUFDRDtBQUNGLFNBWEg7QUFZRDs7QUFFRDs7Ozs7O0FBN1NXO0FBQUE7QUFBQSx3Q0FrVE87QUFDaEIsWUFBSXhiLFFBQVEsSUFBWjtBQUNBLGFBQUtnWixVQUFMLENBQWdCcEQsR0FBaEIsQ0FBb0IsOEJBQXBCLEVBQ0twSyxHQURMLENBQ1Msb0JBRFQsRUFFS0wsRUFGTCxDQUVRLG9CQUZSLEVBRThCLFVBQVNySixDQUFULEVBQVc7QUFDbkM7QUFDQWUscUJBQVcsWUFBVTtBQUNuQjdDLGtCQUFNeWEsUUFBTjtBQUNELFdBRkQsRUFFRyxDQUZIO0FBR0gsU0FQSDtBQVFEOztBQUVEOzs7Ozs7O0FBOVRXO0FBQUE7QUFBQSw0QkFvVUxuWixLQXBVSyxFQW9VRTtBQUNYLFlBQUcsS0FBS3lQLE9BQUwsQ0FBYWlKLFVBQWhCLEVBQTRCLEtBQUtDLFFBQUwsQ0FBYzdOLEdBQWQsQ0FBa0IsRUFBQzVFLFFBQU9sRyxNQUFNc1AsUUFBTixDQUFlLGdCQUFmLEVBQWlDM1IsSUFBakMsQ0FBc0MsWUFBdEMsQ0FBUixFQUFsQjtBQUM1QnFDLGNBQU1uRCxJQUFOLENBQVcsZUFBWCxFQUE0QixJQUE1QjtBQUNBbUQsY0FBTXNQLFFBQU4sQ0FBZSxnQkFBZixFQUFpQ2hCLFFBQWpDLENBQTBDLFdBQTFDLEVBQXVEelIsSUFBdkQsQ0FBNEQsYUFBNUQsRUFBMkUsS0FBM0U7QUFDQTs7OztBQUlBLGFBQUthLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQixtQkFBdEIsRUFBMkMsQ0FBQ29DLEtBQUQsQ0FBM0M7QUFDRDtBQTdVVTtBQUFBOzs7QUErVVg7Ozs7OztBQS9VVyw0QkFxVkxBLEtBclZLLEVBcVZFO0FBQ1gsWUFBRyxLQUFLeVAsT0FBTCxDQUFhaUosVUFBaEIsRUFBNEIsS0FBS0MsUUFBTCxDQUFjN04sR0FBZCxDQUFrQixFQUFDNUUsUUFBT2xHLE1BQU13RixNQUFOLEdBQWV1UCxPQUFmLENBQXVCLElBQXZCLEVBQTZCcFgsSUFBN0IsQ0FBa0MsWUFBbEMsQ0FBUixFQUFsQjtBQUM1QixZQUFJZSxRQUFRLElBQVo7QUFDQXNCLGNBQU13RixNQUFOLENBQWEsSUFBYixFQUFtQjNJLElBQW5CLENBQXdCLGVBQXhCLEVBQXlDLEtBQXpDO0FBQ0FtRCxjQUFNbkQsSUFBTixDQUFXLGFBQVgsRUFBMEIsSUFBMUIsRUFBZ0N5UixRQUFoQyxDQUF5QyxZQUF6QztBQUNBdE8sY0FBTXNPLFFBQU4sQ0FBZSxZQUFmLEVBQ01HLEdBRE4sQ0FDVWpTLFdBQVd3RSxhQUFYLENBQXlCaEIsS0FBekIsQ0FEVixFQUMyQyxZQUFVO0FBQzlDQSxnQkFBTXVDLFdBQU4sQ0FBa0Isc0JBQWxCO0FBQ0F2QyxnQkFBTW1hLElBQU47QUFDRCxTQUpOO0FBS0E7Ozs7QUFJQW5hLGNBQU1wQyxPQUFOLENBQWMsbUJBQWQsRUFBbUMsQ0FBQ29DLEtBQUQsQ0FBbkM7QUFDRDs7QUFFRDs7Ozs7OztBQXRXVztBQUFBO0FBQUEsb0NBNFdHO0FBQ1osWUFBS29hLFlBQVksQ0FBakI7QUFBQSxZQUFvQkMsU0FBUyxFQUE3QjtBQUFBLFlBQWlDM2IsUUFBUSxJQUF6QztBQUNBLGFBQUsrWSxTQUFMLENBQWVOLEdBQWYsQ0FBbUIsS0FBS3paLFFBQXhCLEVBQWtDYSxJQUFsQyxDQUF1QyxZQUFVO0FBQy9DLGNBQUkrYixhQUFhaGUsRUFBRSxJQUFGLEVBQVFnVCxRQUFSLENBQWlCLElBQWpCLEVBQXVCalEsTUFBeEM7QUFDQSxjQUFJNkcsU0FBUzFKLFdBQVcySSxHQUFYLENBQWVFLGFBQWYsQ0FBNkIsSUFBN0IsRUFBbUNhLE1BQWhEO0FBQ0FrVSxzQkFBWWxVLFNBQVNrVSxTQUFULEdBQXFCbFUsTUFBckIsR0FBOEJrVSxTQUExQztBQUNBLGNBQUcxYixNQUFNK1EsT0FBTixDQUFjaUosVUFBakIsRUFBNkI7QUFDM0JwYyxjQUFFLElBQUYsRUFBUXFCLElBQVIsQ0FBYSxZQUFiLEVBQTBCdUksTUFBMUI7QUFDQSxnQkFBSSxDQUFDNUosRUFBRSxJQUFGLEVBQVEwWixRQUFSLENBQWlCLHNCQUFqQixDQUFMLEVBQStDcUUsT0FBTyxRQUFQLElBQW1CblUsTUFBbkI7QUFDaEQ7QUFDRixTQVJEOztBQVVBLFlBQUcsQ0FBQyxLQUFLdUosT0FBTCxDQUFhaUosVUFBakIsRUFBNkIyQixPQUFPLFlBQVAsSUFBMEJELFNBQTFCOztBQUU3QkMsZUFBTyxXQUFQLElBQXlCLEtBQUszYyxRQUFMLENBQWMsQ0FBZCxFQUFpQjhJLHFCQUFqQixHQUF5Q0wsS0FBbEU7O0FBRUEsZUFBT2tVLE1BQVA7QUFDRDs7QUFFRDs7Ozs7QUEvWFc7QUFBQTtBQUFBLGdDQW1ZRDtBQUNSLFlBQUcsS0FBSzVLLE9BQUwsQ0FBYTRKLFNBQWhCLEVBQTJCLEtBQUszYixRQUFMLENBQWN3TSxHQUFkLENBQWtCLGVBQWxCLEVBQWtDLEtBQUtvUCxZQUF2QztBQUMzQixhQUFLSCxRQUFMO0FBQ0QsYUFBS3piLFFBQUwsQ0FBY3dNLEdBQWQsQ0FBa0IscUJBQWxCO0FBQ0MxTixtQkFBV3FTLElBQVgsQ0FBZ0JVLElBQWhCLENBQXFCLEtBQUs3UixRQUExQixFQUFvQyxXQUFwQztBQUNBLGFBQUtBLFFBQUwsQ0FBYzZjLE1BQWQsR0FDY3RhLElBRGQsQ0FDbUIsNkNBRG5CLEVBQ2tFdWEsTUFEbEUsR0FFY3BaLEdBRmQsR0FFb0JuQixJQUZwQixDQUV5QixnREFGekIsRUFFMkVzQyxXQUYzRSxDQUV1RiwyQ0FGdkYsRUFHY25CLEdBSGQsR0FHb0JuQixJQUhwQixDQUd5QixnQkFIekIsRUFHMkNoQyxVQUgzQyxDQUdzRCwyQkFIdEQ7QUFJQSxhQUFLdVosZUFBTCxDQUFxQmpaLElBQXJCLENBQTBCLFlBQVc7QUFDbkNqQyxZQUFFLElBQUYsRUFBUTROLEdBQVIsQ0FBWSxlQUFaO0FBQ0QsU0FGRDs7QUFJQSxhQUFLdU4sU0FBTCxDQUFlbFYsV0FBZixDQUEyQixrQ0FBM0I7O0FBRUEsYUFBSzdFLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsR0FBbkIsRUFBd0IxQixJQUF4QixDQUE2QixZQUFVO0FBQ3JDLGNBQUl1WixRQUFReGIsRUFBRSxJQUFGLENBQVo7QUFDQXdiLGdCQUFNN1osVUFBTixDQUFpQixVQUFqQjtBQUNBLGNBQUc2WixNQUFNbmEsSUFBTixDQUFXLFdBQVgsQ0FBSCxFQUEyQjtBQUN6Qm1hLGtCQUFNamIsSUFBTixDQUFXLE1BQVgsRUFBbUJpYixNQUFNbmEsSUFBTixDQUFXLFdBQVgsQ0FBbkIsRUFBNENPLFVBQTVDLENBQXVELFdBQXZEO0FBQ0QsV0FGRCxNQUVLO0FBQUU7QUFBUztBQUNqQixTQU5EO0FBT0ExQixtQkFBV3NCLGdCQUFYLENBQTRCLElBQTVCO0FBQ0Q7QUExWlU7O0FBQUE7QUFBQTs7QUE2WmJ5WixZQUFVOUIsUUFBVixHQUFxQjtBQUNuQjs7Ozs7QUFLQThDLGdCQUFZLDZEQU5PO0FBT25COzs7OztBQUtBRix3QkFBb0IsS0FaRDtBQWFuQjs7Ozs7QUFLQU8sYUFBUyxhQWxCVTtBQW1CbkI7Ozs7O0FBS0FiLGdCQUFZLEtBeEJPO0FBeUJuQjs7Ozs7QUFLQWlCLGtCQUFjLEtBOUJLO0FBK0JuQjs7Ozs7QUFLQU4sZ0JBQVksS0FwQ087QUFxQ25COzs7OztBQUtBRyxtQkFBZSxLQTFDSTtBQTJDbkI7Ozs7O0FBS0FRLGVBQVcsS0FoRFE7QUFpRG5COzs7OztBQUtBSSxzQkFBa0IsRUF0REM7QUF1RG5COzs7OztBQUtBRyxxQkFBaUIsQ0E1REU7QUE2RG5COzs7OztBQUtBRSx1QkFBbUIsR0FsRUE7QUFtRW5COzs7OztBQUtBQyxxQkFBaUI7QUFDakI7QUF6RW1CLEdBQXJCOztBQTRFQTtBQUNBdmQsYUFBV00sTUFBWCxDQUFrQnlhLFNBQWxCLEVBQTZCLFdBQTdCO0FBRUMsQ0E1ZUEsQ0E0ZUNyUyxNQTVlRCxDQUFEO0NDRkE7Ozs7OztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYjs7Ozs7Ozs7QUFGYSxNQVVQbWUsUUFWTztBQVdYOzs7Ozs7O0FBT0Esc0JBQVlsVixPQUFaLEVBQXFCa0ssT0FBckIsRUFBOEI7QUFBQTs7QUFDNUIsV0FBSy9SLFFBQUwsR0FBZ0I2SCxPQUFoQjtBQUNBLFdBQUtrSyxPQUFMLEdBQWVuVCxFQUFFeU0sTUFBRixDQUFTLEVBQVQsRUFBYTBSLFNBQVNoRixRQUF0QixFQUFnQyxLQUFLL1gsUUFBTCxDQUFjQyxJQUFkLEVBQWhDLEVBQXNEOFIsT0FBdEQsQ0FBZjtBQUNBLFdBQUtqUixLQUFMOztBQUVBaEMsaUJBQVdZLGNBQVgsQ0FBMEIsSUFBMUIsRUFBZ0MsVUFBaEM7QUFDQVosaUJBQVdtTCxRQUFYLENBQW9CMkIsUUFBcEIsQ0FBNkIsVUFBN0IsRUFBeUM7QUFDdkMsaUJBQVMsTUFEOEI7QUFFdkMsaUJBQVMsTUFGOEI7QUFHdkMsa0JBQVU7QUFINkIsT0FBekM7QUFLRDs7QUFFRDs7Ozs7OztBQS9CVztBQUFBO0FBQUEsOEJBb0NIO0FBQ04sWUFBSW9SLE1BQU0sS0FBS2hkLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixJQUFuQixDQUFWOztBQUVBLGFBQUs4ZCxPQUFMLEdBQWVyZSxxQkFBbUJvZSxHQUFuQixTQUE0QnJiLE1BQTVCLEdBQXFDL0MscUJBQW1Cb2UsR0FBbkIsUUFBckMsR0FBbUVwZSxtQkFBaUJvZSxHQUFqQixRQUFsRjtBQUNBLGFBQUtDLE9BQUwsQ0FBYTlkLElBQWIsQ0FBa0I7QUFDaEIsMkJBQWlCNmQsR0FERDtBQUVoQiwyQkFBaUIsS0FGRDtBQUdoQiwyQkFBaUJBLEdBSEQ7QUFJaEIsMkJBQWlCLElBSkQ7QUFLaEIsMkJBQWlCOztBQUxELFNBQWxCOztBQVNBLFlBQUcsS0FBS2pMLE9BQUwsQ0FBYW1MLFdBQWhCLEVBQTRCO0FBQzFCLGVBQUtDLE9BQUwsR0FBZSxLQUFLbmQsUUFBTCxDQUFjZ1osT0FBZCxDQUFzQixNQUFNLEtBQUtqSCxPQUFMLENBQWFtTCxXQUF6QyxDQUFmO0FBQ0QsU0FGRCxNQUVLO0FBQ0gsZUFBS0MsT0FBTCxHQUFlLElBQWY7QUFDRDtBQUNELGFBQUtwTCxPQUFMLENBQWFxTCxhQUFiLEdBQTZCLEtBQUtDLGdCQUFMLEVBQTdCO0FBQ0EsYUFBS0MsT0FBTCxHQUFlLENBQWY7QUFDQSxhQUFLQyxhQUFMLEdBQXFCLEVBQXJCO0FBQ0EsYUFBS3ZkLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQjtBQUNqQix5QkFBZSxNQURFO0FBRWpCLDJCQUFpQjZkLEdBRkE7QUFHakIseUJBQWVBLEdBSEU7QUFJakIsNkJBQW1CLEtBQUtDLE9BQUwsQ0FBYSxDQUFiLEVBQWdCeE8sRUFBaEIsSUFBc0IzUCxXQUFXaUIsV0FBWCxDQUF1QixDQUF2QixFQUEwQixXQUExQjtBQUp4QixTQUFuQjtBQU1BLGFBQUswWSxPQUFMO0FBQ0Q7O0FBRUQ7Ozs7OztBQWxFVztBQUFBO0FBQUEseUNBdUVRO0FBQ2pCLFlBQUkrRSxtQkFBbUIsS0FBS3hkLFFBQUwsQ0FBYyxDQUFkLEVBQWlCVixTQUFqQixDQUEyQm1lLEtBQTNCLENBQWlDLDBCQUFqQyxDQUF2QjtBQUNJRCwyQkFBbUJBLG1CQUFtQkEsaUJBQWlCLENBQWpCLENBQW5CLEdBQXlDLEVBQTVEO0FBQ0osWUFBSUUscUJBQXFCLGNBQWN2VyxJQUFkLENBQW1CLEtBQUs4VixPQUFMLENBQWEsQ0FBYixFQUFnQjNkLFNBQW5DLENBQXpCO0FBQ0lvZSw2QkFBcUJBLHFCQUFxQkEsbUJBQW1CLENBQW5CLENBQXJCLEdBQTZDLEVBQWxFO0FBQ0osWUFBSWpVLFdBQVdpVSxxQkFBcUJBLHFCQUFxQixHQUFyQixHQUEyQkYsZ0JBQWhELEdBQW1FQSxnQkFBbEY7O0FBRUEsZUFBTy9ULFFBQVA7QUFDRDs7QUFFRDs7Ozs7OztBQWpGVztBQUFBO0FBQUEsa0NBdUZDQSxRQXZGRCxFQXVGVztBQUNwQixhQUFLOFQsYUFBTCxDQUFtQnBkLElBQW5CLENBQXdCc0osV0FBV0EsUUFBWCxHQUFzQixRQUE5QztBQUNBO0FBQ0EsWUFBRyxDQUFDQSxRQUFELElBQWMsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixLQUEzQixJQUFvQyxDQUFyRCxFQUF3RDtBQUN0RCxlQUFLTixRQUFMLENBQWM0USxRQUFkLENBQXVCLEtBQXZCO0FBQ0QsU0FGRCxNQUVNLElBQUduSCxhQUFhLEtBQWIsSUFBdUIsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixRQUEzQixJQUF1QyxDQUFqRSxFQUFvRTtBQUN4RSxlQUFLTixRQUFMLENBQWM2RSxXQUFkLENBQTBCNEUsUUFBMUI7QUFDRCxTQUZLLE1BRUEsSUFBR0EsYUFBYSxNQUFiLElBQXdCLEtBQUs4VCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsT0FBM0IsSUFBc0MsQ0FBakUsRUFBb0U7QUFDeEUsZUFBS04sUUFBTCxDQUFjNkUsV0FBZCxDQUEwQjRFLFFBQTFCLEVBQ0ttSCxRQURMLENBQ2MsT0FEZDtBQUVELFNBSEssTUFHQSxJQUFHbkgsYUFBYSxPQUFiLElBQXlCLEtBQUs4VCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsTUFBM0IsSUFBcUMsQ0FBakUsRUFBb0U7QUFDeEUsZUFBS04sUUFBTCxDQUFjNkUsV0FBZCxDQUEwQjRFLFFBQTFCLEVBQ0ttSCxRQURMLENBQ2MsTUFEZDtBQUVEOztBQUVEO0FBTE0sYUFNRCxJQUFHLENBQUNuSCxRQUFELElBQWMsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixLQUEzQixJQUFvQyxDQUFDLENBQW5ELElBQTBELEtBQUtpZCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsTUFBM0IsSUFBcUMsQ0FBbEcsRUFBcUc7QUFDeEcsaUJBQUtOLFFBQUwsQ0FBYzRRLFFBQWQsQ0FBdUIsTUFBdkI7QUFDRCxXQUZJLE1BRUMsSUFBR25ILGFBQWEsS0FBYixJQUF1QixLQUFLOFQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLFFBQTNCLElBQXVDLENBQUMsQ0FBL0QsSUFBc0UsS0FBS2lkLGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixNQUEzQixJQUFxQyxDQUE5RyxFQUFpSDtBQUNySCxpQkFBS04sUUFBTCxDQUFjNkUsV0FBZCxDQUEwQjRFLFFBQTFCLEVBQ0ttSCxRQURMLENBQ2MsTUFEZDtBQUVELFdBSEssTUFHQSxJQUFHbkgsYUFBYSxNQUFiLElBQXdCLEtBQUs4VCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsT0FBM0IsSUFBc0MsQ0FBQyxDQUEvRCxJQUFzRSxLQUFLaWQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLFFBQTNCLElBQXVDLENBQWhILEVBQW1IO0FBQ3ZILGlCQUFLTixRQUFMLENBQWM2RSxXQUFkLENBQTBCNEUsUUFBMUI7QUFDRCxXQUZLLE1BRUEsSUFBR0EsYUFBYSxPQUFiLElBQXlCLEtBQUs4VCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsTUFBM0IsSUFBcUMsQ0FBQyxDQUEvRCxJQUFzRSxLQUFLaWQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLFFBQTNCLElBQXVDLENBQWhILEVBQW1IO0FBQ3ZILGlCQUFLTixRQUFMLENBQWM2RSxXQUFkLENBQTBCNEUsUUFBMUI7QUFDRDtBQUNEO0FBSE0sZUFJRjtBQUNGLG1CQUFLekosUUFBTCxDQUFjNkUsV0FBZCxDQUEwQjRFLFFBQTFCO0FBQ0Q7QUFDRCxhQUFLa1UsWUFBTCxHQUFvQixJQUFwQjtBQUNBLGFBQUtMLE9BQUw7QUFDRDs7QUFFRDs7Ozs7OztBQXpIVztBQUFBO0FBQUEscUNBK0hJO0FBQ2IsWUFBRyxLQUFLTCxPQUFMLENBQWE5ZCxJQUFiLENBQWtCLGVBQWxCLE1BQXVDLE9BQTFDLEVBQWtEO0FBQUUsaUJBQU8sS0FBUDtBQUFlO0FBQ25FLFlBQUlzSyxXQUFXLEtBQUs0VCxnQkFBTCxFQUFmO0FBQUEsWUFDSXhULFdBQVcvSyxXQUFXMkksR0FBWCxDQUFlRSxhQUFmLENBQTZCLEtBQUszSCxRQUFsQyxDQURmO0FBQUEsWUFFSThKLGNBQWNoTCxXQUFXMkksR0FBWCxDQUFlRSxhQUFmLENBQTZCLEtBQUtzVixPQUFsQyxDQUZsQjtBQUFBLFlBR0lqYyxRQUFRLElBSFo7QUFBQSxZQUlJNGMsWUFBYW5VLGFBQWEsTUFBYixHQUFzQixNQUF0QixHQUFpQ0EsYUFBYSxPQUFkLEdBQXlCLE1BQXpCLEdBQWtDLEtBSm5GO0FBQUEsWUFLSTRGLFFBQVN1TyxjQUFjLEtBQWYsR0FBd0IsUUFBeEIsR0FBbUMsT0FML0M7QUFBQSxZQU1JclYsU0FBVThHLFVBQVUsUUFBWCxHQUF1QixLQUFLMEMsT0FBTCxDQUFhckksT0FBcEMsR0FBOEMsS0FBS3FJLE9BQUwsQ0FBYXBJLE9BTnhFOztBQVFBLFlBQUlFLFNBQVNwQixLQUFULElBQWtCb0IsU0FBU25CLFVBQVQsQ0FBb0JELEtBQXZDLElBQWtELENBQUMsS0FBSzZVLE9BQU4sSUFBaUIsQ0FBQ3hlLFdBQVcySSxHQUFYLENBQWVDLGdCQUFmLENBQWdDLEtBQUsxSCxRQUFyQyxFQUErQyxLQUFLbWQsT0FBcEQsQ0FBdkUsRUFBcUk7QUFDbkksY0FBSVUsV0FBV2hVLFNBQVNuQixVQUFULENBQW9CRCxLQUFuQztBQUFBLGNBQ0lxVixnQkFBZ0IsQ0FEcEI7QUFFQSxjQUFHLEtBQUtYLE9BQVIsRUFBZ0I7QUFDZCxnQkFBSVksY0FBY2pmLFdBQVcySSxHQUFYLENBQWVFLGFBQWYsQ0FBNkIsS0FBS3dWLE9BQWxDLENBQWxCO0FBQUEsZ0JBQ0lXLGdCQUFnQkMsWUFBWXhWLE1BQVosQ0FBbUJILElBRHZDO0FBRUEsZ0JBQUkyVixZQUFZdFYsS0FBWixHQUFvQm9WLFFBQXhCLEVBQWlDO0FBQy9CQSx5QkFBV0UsWUFBWXRWLEtBQXZCO0FBQ0Q7QUFDRjs7QUFFRCxlQUFLekksUUFBTCxDQUFjdUksTUFBZCxDQUFxQnpKLFdBQVcySSxHQUFYLENBQWVHLFVBQWYsQ0FBMEIsS0FBSzVILFFBQS9CLEVBQXlDLEtBQUtpZCxPQUE5QyxFQUF1RCxlQUF2RCxFQUF3RSxLQUFLbEwsT0FBTCxDQUFhckksT0FBckYsRUFBOEYsS0FBS3FJLE9BQUwsQ0FBYXBJLE9BQWIsR0FBdUJtVSxhQUFySCxFQUFvSSxJQUFwSSxDQUFyQixFQUFnSzFRLEdBQWhLLENBQW9LO0FBQ2xLLHFCQUFTeVEsV0FBWSxLQUFLOUwsT0FBTCxDQUFhcEksT0FBYixHQUF1QixDQURzSDtBQUVsSyxzQkFBVTtBQUZ3SixXQUFwSztBQUlBLGVBQUtnVSxZQUFMLEdBQW9CLElBQXBCO0FBQ0EsaUJBQU8sS0FBUDtBQUNEOztBQUVELGFBQUszZCxRQUFMLENBQWN1SSxNQUFkLENBQXFCekosV0FBVzJJLEdBQVgsQ0FBZUcsVUFBZixDQUEwQixLQUFLNUgsUUFBL0IsRUFBeUMsS0FBS2lkLE9BQTlDLEVBQXVEeFQsUUFBdkQsRUFBaUUsS0FBS3NJLE9BQUwsQ0FBYXJJLE9BQTlFLEVBQXVGLEtBQUtxSSxPQUFMLENBQWFwSSxPQUFwRyxDQUFyQjs7QUFFQSxlQUFNLENBQUM3SyxXQUFXMkksR0FBWCxDQUFlQyxnQkFBZixDQUFnQyxLQUFLMUgsUUFBckMsRUFBK0MsS0FBS21kLE9BQXBELEVBQTZELElBQTdELENBQUQsSUFBdUUsS0FBS0csT0FBbEYsRUFBMEY7QUFDeEYsZUFBS1UsV0FBTCxDQUFpQnZVLFFBQWpCO0FBQ0EsZUFBS3dVLFlBQUw7QUFDRDtBQUNGOztBQUVEOzs7Ozs7QUFwS1c7QUFBQTtBQUFBLGdDQXlLRDtBQUNSLFlBQUlqZCxRQUFRLElBQVo7QUFDQSxhQUFLaEIsUUFBTCxDQUFjbU0sRUFBZCxDQUFpQjtBQUNmLDZCQUFtQixLQUFLK00sSUFBTCxDQUFVeFMsSUFBVixDQUFlLElBQWYsQ0FESjtBQUVmLDhCQUFvQixLQUFLeVMsS0FBTCxDQUFXelMsSUFBWCxDQUFnQixJQUFoQixDQUZMO0FBR2YsK0JBQXFCLEtBQUtpUyxNQUFMLENBQVlqUyxJQUFaLENBQWlCLElBQWpCLENBSE47QUFJZixpQ0FBdUIsS0FBS3VYLFlBQUwsQ0FBa0J2WCxJQUFsQixDQUF1QixJQUF2QjtBQUpSLFNBQWpCOztBQU9BLFlBQUcsS0FBS3FMLE9BQUwsQ0FBYW1NLEtBQWhCLEVBQXNCO0FBQ3BCLGVBQUtqQixPQUFMLENBQWF6USxHQUFiLENBQWlCLCtDQUFqQixFQUNDTCxFQURELENBQ0ksd0JBREosRUFDOEIsWUFBVTtBQUN0QyxnQkFBSWdTLFdBQVd2ZixFQUFFLE1BQUYsRUFBVXFCLElBQVYsRUFBZjtBQUNBLGdCQUFHLE9BQU9rZSxTQUFTQyxTQUFoQixLQUErQixXQUEvQixJQUE4Q0QsU0FBU0MsU0FBVCxLQUF1QixPQUF4RSxFQUFpRjtBQUMvRTlYLDJCQUFhdEYsTUFBTXFkLE9BQW5CO0FBQ0FyZCxvQkFBTXFkLE9BQU4sR0FBZ0J4YSxXQUFXLFlBQVU7QUFDbkM3QyxzQkFBTWtZLElBQU47QUFDQWxZLHNCQUFNaWMsT0FBTixDQUFjaGQsSUFBZCxDQUFtQixPQUFuQixFQUE0QixJQUE1QjtBQUNELGVBSGUsRUFHYmUsTUFBTStRLE9BQU4sQ0FBY3VNLFVBSEQsQ0FBaEI7QUFJRDtBQUNGLFdBVkQsRUFVR25TLEVBVkgsQ0FVTSx3QkFWTixFQVVnQyxZQUFVO0FBQ3hDN0YseUJBQWF0RixNQUFNcWQsT0FBbkI7QUFDQXJkLGtCQUFNcWQsT0FBTixHQUFnQnhhLFdBQVcsWUFBVTtBQUNuQzdDLG9CQUFNbVksS0FBTjtBQUNBblksb0JBQU1pYyxPQUFOLENBQWNoZCxJQUFkLENBQW1CLE9BQW5CLEVBQTRCLEtBQTVCO0FBQ0QsYUFIZSxFQUdiZSxNQUFNK1EsT0FBTixDQUFjdU0sVUFIRCxDQUFoQjtBQUlELFdBaEJEO0FBaUJBLGNBQUcsS0FBS3ZNLE9BQUwsQ0FBYXdNLFNBQWhCLEVBQTBCO0FBQ3hCLGlCQUFLdmUsUUFBTCxDQUFjd00sR0FBZCxDQUFrQiwrQ0FBbEIsRUFDS0wsRUFETCxDQUNRLHdCQURSLEVBQ2tDLFlBQVU7QUFDdEM3RiwyQkFBYXRGLE1BQU1xZCxPQUFuQjtBQUNELGFBSEwsRUFHT2xTLEVBSFAsQ0FHVSx3QkFIVixFQUdvQyxZQUFVO0FBQ3hDN0YsMkJBQWF0RixNQUFNcWQsT0FBbkI7QUFDQXJkLG9CQUFNcWQsT0FBTixHQUFnQnhhLFdBQVcsWUFBVTtBQUNuQzdDLHNCQUFNbVksS0FBTjtBQUNBblksc0JBQU1pYyxPQUFOLENBQWNoZCxJQUFkLENBQW1CLE9BQW5CLEVBQTRCLEtBQTVCO0FBQ0QsZUFIZSxFQUdiZSxNQUFNK1EsT0FBTixDQUFjdU0sVUFIRCxDQUFoQjtBQUlELGFBVEw7QUFVRDtBQUNGO0FBQ0QsYUFBS3JCLE9BQUwsQ0FBYXhELEdBQWIsQ0FBaUIsS0FBS3paLFFBQXRCLEVBQWdDbU0sRUFBaEMsQ0FBbUMscUJBQW5DLEVBQTBELFVBQVNySixDQUFULEVBQVk7O0FBRXBFLGNBQUlxVSxVQUFVdlksRUFBRSxJQUFGLENBQWQ7QUFBQSxjQUNFNGYsMkJBQTJCMWYsV0FBV21MLFFBQVgsQ0FBb0J3QixhQUFwQixDQUFrQ3pLLE1BQU1oQixRQUF4QyxDQUQ3Qjs7QUFHQWxCLHFCQUFXbUwsUUFBWCxDQUFvQmEsU0FBcEIsQ0FBOEJoSSxDQUE5QixFQUFpQyxVQUFqQyxFQUE2QztBQUMzQ29XLGtCQUFNLGdCQUFXO0FBQ2Ysa0JBQUkvQixRQUFReEwsRUFBUixDQUFXM0ssTUFBTWljLE9BQWpCLENBQUosRUFBK0I7QUFDN0JqYyxzQkFBTWtZLElBQU47QUFDQWxZLHNCQUFNaEIsUUFBTixDQUFlYixJQUFmLENBQW9CLFVBQXBCLEVBQWdDLENBQUMsQ0FBakMsRUFBb0NtTixLQUFwQztBQUNBeEosa0JBQUV1SixjQUFGO0FBQ0Q7QUFDRixhQVAwQztBQVEzQzhNLG1CQUFPLGlCQUFXO0FBQ2hCblksb0JBQU1tWSxLQUFOO0FBQ0FuWSxvQkFBTWljLE9BQU4sQ0FBYzNRLEtBQWQ7QUFDRDtBQVgwQyxXQUE3QztBQWFELFNBbEJEO0FBbUJEOztBQUVEOzs7Ozs7QUF0T1c7QUFBQTtBQUFBLHdDQTJPTztBQUNmLFlBQUlpUCxRQUFRM2MsRUFBRTRFLFNBQVMwRixJQUFYLEVBQWlCME4sR0FBakIsQ0FBcUIsS0FBSzVXLFFBQTFCLENBQVo7QUFBQSxZQUNJZ0IsUUFBUSxJQURaO0FBRUF1YSxjQUFNL08sR0FBTixDQUFVLG1CQUFWLEVBQ01MLEVBRE4sQ0FDUyxtQkFEVCxFQUM4QixVQUFTckosQ0FBVCxFQUFXO0FBQ2xDLGNBQUc5QixNQUFNaWMsT0FBTixDQUFjdFIsRUFBZCxDQUFpQjdJLEVBQUVzSixNQUFuQixLQUE4QnBMLE1BQU1pYyxPQUFOLENBQWMxYSxJQUFkLENBQW1CTyxFQUFFc0osTUFBckIsRUFBNkJ6SyxNQUE5RCxFQUFzRTtBQUNwRTtBQUNEO0FBQ0QsY0FBR1gsTUFBTWhCLFFBQU4sQ0FBZXVDLElBQWYsQ0FBb0JPLEVBQUVzSixNQUF0QixFQUE4QnpLLE1BQWpDLEVBQXlDO0FBQ3ZDO0FBQ0Q7QUFDRFgsZ0JBQU1tWSxLQUFOO0FBQ0FvQyxnQkFBTS9PLEdBQU4sQ0FBVSxtQkFBVjtBQUNELFNBVk47QUFXRjs7QUFFRDs7Ozs7OztBQTNQVztBQUFBO0FBQUEsNkJBaVFKO0FBQ0w7QUFDQTs7OztBQUlBLGFBQUt4TSxRQUFMLENBQWNFLE9BQWQsQ0FBc0IscUJBQXRCLEVBQTZDLEtBQUtGLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixJQUFuQixDQUE3QztBQUNBLGFBQUs4ZCxPQUFMLENBQWFyTSxRQUFiLENBQXNCLE9BQXRCLEVBQ0t6UixJQURMLENBQ1UsRUFBQyxpQkFBaUIsSUFBbEIsRUFEVjtBQUVBO0FBQ0EsYUFBSzhlLFlBQUw7QUFDQSxhQUFLamUsUUFBTCxDQUFjNFEsUUFBZCxDQUF1QixTQUF2QixFQUNLelIsSUFETCxDQUNVLEVBQUMsZUFBZSxLQUFoQixFQURWOztBQUdBLFlBQUcsS0FBSzRTLE9BQUwsQ0FBYTBNLFNBQWhCLEVBQTBCO0FBQ3hCLGNBQUkxUyxhQUFhak4sV0FBV21MLFFBQVgsQ0FBb0J3QixhQUFwQixDQUFrQyxLQUFLekwsUUFBdkMsQ0FBakI7QUFDQSxjQUFHK0wsV0FBV3BLLE1BQWQsRUFBcUI7QUFDbkJvSyx1QkFBV0UsRUFBWCxDQUFjLENBQWQsRUFBaUJLLEtBQWpCO0FBQ0Q7QUFDRjs7QUFFRCxZQUFHLEtBQUt5RixPQUFMLENBQWF1SixZQUFoQixFQUE2QjtBQUFFLGVBQUtvRCxlQUFMO0FBQXlCOztBQUV4RCxZQUFJLEtBQUszTSxPQUFMLENBQWFqRyxTQUFqQixFQUE0QjtBQUMxQmhOLHFCQUFXbUwsUUFBWCxDQUFvQjZCLFNBQXBCLENBQThCLEtBQUs5TCxRQUFuQztBQUNEOztBQUVEOzs7O0FBSUEsYUFBS0EsUUFBTCxDQUFjRSxPQUFkLENBQXNCLGtCQUF0QixFQUEwQyxDQUFDLEtBQUtGLFFBQU4sQ0FBMUM7QUFDRDs7QUFFRDs7Ozs7O0FBblNXO0FBQUE7QUFBQSw4QkF3U0g7QUFDTixZQUFHLENBQUMsS0FBS0EsUUFBTCxDQUFjc1ksUUFBZCxDQUF1QixTQUF2QixDQUFKLEVBQXNDO0FBQ3BDLGlCQUFPLEtBQVA7QUFDRDtBQUNELGFBQUt0WSxRQUFMLENBQWM2RSxXQUFkLENBQTBCLFNBQTFCLEVBQ0sxRixJQURMLENBQ1UsRUFBQyxlQUFlLElBQWhCLEVBRFY7O0FBR0EsYUFBSzhkLE9BQUwsQ0FBYXBZLFdBQWIsQ0FBeUIsT0FBekIsRUFDSzFGLElBREwsQ0FDVSxlQURWLEVBQzJCLEtBRDNCOztBQUdBLFlBQUcsS0FBS3dlLFlBQVIsRUFBcUI7QUFDbkIsY0FBSWdCLG1CQUFtQixLQUFLdEIsZ0JBQUwsRUFBdkI7QUFDQSxjQUFHc0IsZ0JBQUgsRUFBb0I7QUFDbEIsaUJBQUszZSxRQUFMLENBQWM2RSxXQUFkLENBQTBCOFosZ0JBQTFCO0FBQ0Q7QUFDRCxlQUFLM2UsUUFBTCxDQUFjNFEsUUFBZCxDQUF1QixLQUFLbUIsT0FBTCxDQUFhcUwsYUFBcEM7QUFDSSxxQkFESixDQUNnQmhRLEdBRGhCLENBQ29CLEVBQUM1RSxRQUFRLEVBQVQsRUFBYUMsT0FBTyxFQUFwQixFQURwQjtBQUVBLGVBQUtrVixZQUFMLEdBQW9CLEtBQXBCO0FBQ0EsZUFBS0wsT0FBTCxHQUFlLENBQWY7QUFDQSxlQUFLQyxhQUFMLENBQW1CNWIsTUFBbkIsR0FBNEIsQ0FBNUI7QUFDRDtBQUNELGFBQUszQixRQUFMLENBQWNFLE9BQWQsQ0FBc0Isa0JBQXRCLEVBQTBDLENBQUMsS0FBS0YsUUFBTixDQUExQzs7QUFFQSxZQUFJLEtBQUsrUixPQUFMLENBQWFqRyxTQUFqQixFQUE0QjtBQUMxQmhOLHFCQUFXbUwsUUFBWCxDQUFvQnNDLFlBQXBCLENBQWlDLEtBQUt2TSxRQUF0QztBQUNEO0FBQ0Y7O0FBRUQ7Ozs7O0FBcFVXO0FBQUE7QUFBQSwrQkF3VUY7QUFDUCxZQUFHLEtBQUtBLFFBQUwsQ0FBY3NZLFFBQWQsQ0FBdUIsU0FBdkIsQ0FBSCxFQUFxQztBQUNuQyxjQUFHLEtBQUsyRSxPQUFMLENBQWFoZCxJQUFiLENBQWtCLE9BQWxCLENBQUgsRUFBK0I7QUFDL0IsZUFBS2taLEtBQUw7QUFDRCxTQUhELE1BR0s7QUFDSCxlQUFLRCxJQUFMO0FBQ0Q7QUFDRjs7QUFFRDs7Ozs7QUFqVlc7QUFBQTtBQUFBLGdDQXFWRDtBQUNSLGFBQUtsWixRQUFMLENBQWN3TSxHQUFkLENBQWtCLGFBQWxCLEVBQWlDeUUsSUFBakM7QUFDQSxhQUFLZ00sT0FBTCxDQUFhelEsR0FBYixDQUFpQixjQUFqQjs7QUFFQTFOLG1CQUFXc0IsZ0JBQVgsQ0FBNEIsSUFBNUI7QUFDRDtBQTFWVTs7QUFBQTtBQUFBOztBQTZWYjJjLFdBQVNoRixRQUFULEdBQW9CO0FBQ2xCOzs7OztBQUtBbUYsaUJBQWEsSUFOSztBQU9sQjs7Ozs7QUFLQW9CLGdCQUFZLEdBWk07QUFhbEI7Ozs7O0FBS0FKLFdBQU8sS0FsQlc7QUFtQmxCOzs7OztBQUtBSyxlQUFXLEtBeEJPO0FBeUJsQjs7Ozs7QUFLQTdVLGFBQVMsQ0E5QlM7QUErQmxCOzs7OztBQUtBQyxhQUFTLENBcENTO0FBcUNsQjs7Ozs7QUFLQXlULG1CQUFlLEVBMUNHO0FBMkNsQjs7Ozs7QUFLQXRSLGVBQVcsS0FoRE87QUFpRGxCOzs7OztBQUtBMlMsZUFBVyxLQXRETztBQXVEbEI7Ozs7O0FBS0FuRCxrQkFBYzs7QUFHaEI7QUEvRG9CLEdBQXBCLENBZ0VBeGMsV0FBV00sTUFBWCxDQUFrQjJkLFFBQWxCLEVBQTRCLFVBQTVCO0FBRUMsQ0EvWkEsQ0ErWkN2VixNQS9aRCxDQUFEO0NDRkE7Ozs7OztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYjs7Ozs7Ozs7QUFGYSxNQVVQZ2dCLFlBVk87QUFXWDs7Ozs7OztBQU9BLDBCQUFZL1csT0FBWixFQUFxQmtLLE9BQXJCLEVBQThCO0FBQUE7O0FBQzVCLFdBQUsvUixRQUFMLEdBQWdCNkgsT0FBaEI7QUFDQSxXQUFLa0ssT0FBTCxHQUFlblQsRUFBRXlNLE1BQUYsQ0FBUyxFQUFULEVBQWF1VCxhQUFhN0csUUFBMUIsRUFBb0MsS0FBSy9YLFFBQUwsQ0FBY0MsSUFBZCxFQUFwQyxFQUEwRDhSLE9BQTFELENBQWY7O0FBRUFqVCxpQkFBV3FTLElBQVgsQ0FBZ0JDLE9BQWhCLENBQXdCLEtBQUtwUixRQUE3QixFQUF1QyxVQUF2QztBQUNBLFdBQUtjLEtBQUw7O0FBRUFoQyxpQkFBV1ksY0FBWCxDQUEwQixJQUExQixFQUFnQyxjQUFoQztBQUNBWixpQkFBV21MLFFBQVgsQ0FBb0IyQixRQUFwQixDQUE2QixjQUE3QixFQUE2QztBQUMzQyxpQkFBUyxNQURrQztBQUUzQyxpQkFBUyxNQUZrQztBQUczQyx1QkFBZSxNQUg0QjtBQUkzQyxvQkFBWSxJQUorQjtBQUszQyxzQkFBYyxNQUw2QjtBQU0zQyxzQkFBYyxVQU42QjtBQU8zQyxrQkFBVTtBQVBpQyxPQUE3QztBQVNEOztBQUVEOzs7Ozs7O0FBckNXO0FBQUE7QUFBQSw4QkEwQ0g7QUFDTixZQUFJaVQsT0FBTyxLQUFLN2UsUUFBTCxDQUFjdUMsSUFBZCxDQUFtQiwrQkFBbkIsQ0FBWDtBQUNBLGFBQUt2QyxRQUFMLENBQWM0UixRQUFkLENBQXVCLDZCQUF2QixFQUFzREEsUUFBdEQsQ0FBK0Qsc0JBQS9ELEVBQXVGaEIsUUFBdkYsQ0FBZ0csV0FBaEc7O0FBRUEsYUFBS29KLFVBQUwsR0FBa0IsS0FBS2hhLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsbUJBQW5CLENBQWxCO0FBQ0EsYUFBS3VjLEtBQUwsR0FBYSxLQUFLOWUsUUFBTCxDQUFjNFIsUUFBZCxDQUF1QixtQkFBdkIsQ0FBYjtBQUNBLGFBQUtrTixLQUFMLENBQVd2YyxJQUFYLENBQWdCLHdCQUFoQixFQUEwQ3FPLFFBQTFDLENBQW1ELEtBQUttQixPQUFMLENBQWFnTixhQUFoRTs7QUFFQSxZQUFJLEtBQUsvZSxRQUFMLENBQWNzWSxRQUFkLENBQXVCLEtBQUt2RyxPQUFMLENBQWFpTixVQUFwQyxLQUFtRCxLQUFLak4sT0FBTCxDQUFha04sU0FBYixLQUEyQixPQUE5RSxJQUF5Rm5nQixXQUFXSSxHQUFYLEVBQXpGLElBQTZHLEtBQUtjLFFBQUwsQ0FBY2daLE9BQWQsQ0FBc0IsZ0JBQXRCLEVBQXdDck4sRUFBeEMsQ0FBMkMsR0FBM0MsQ0FBakgsRUFBa0s7QUFDaEssZUFBS29HLE9BQUwsQ0FBYWtOLFNBQWIsR0FBeUIsT0FBekI7QUFDQUosZUFBS2pPLFFBQUwsQ0FBYyxZQUFkO0FBQ0QsU0FIRCxNQUdPO0FBQ0xpTyxlQUFLak8sUUFBTCxDQUFjLGFBQWQ7QUFDRDtBQUNELGFBQUtzTyxPQUFMLEdBQWUsS0FBZjtBQUNBLGFBQUt6RyxPQUFMO0FBQ0Q7QUExRFU7QUFBQTtBQUFBLG9DQTRERztBQUNaLGVBQU8sS0FBS3FHLEtBQUwsQ0FBVzFSLEdBQVgsQ0FBZSxTQUFmLE1BQThCLE9BQXJDO0FBQ0Q7O0FBRUQ7Ozs7OztBQWhFVztBQUFBO0FBQUEsZ0NBcUVEO0FBQ1IsWUFBSXBNLFFBQVEsSUFBWjtBQUFBLFlBQ0ltZSxXQUFXLGtCQUFrQjdaLE1BQWxCLElBQTZCLE9BQU9BLE9BQU84WixZQUFkLEtBQStCLFdBRDNFO0FBQUEsWUFFSUMsV0FBVyw0QkFGZjs7QUFJQTtBQUNBLFlBQUlDLGdCQUFnQixTQUFoQkEsYUFBZ0IsQ0FBU3hjLENBQVQsRUFBWTtBQUM5QixjQUFJUixRQUFRMUQsRUFBRWtFLEVBQUVzSixNQUFKLEVBQVlvTixZQUFaLENBQXlCLElBQXpCLFFBQW1DNkYsUUFBbkMsQ0FBWjtBQUFBLGNBQ0lFLFNBQVNqZCxNQUFNZ1csUUFBTixDQUFlK0csUUFBZixDQURiO0FBQUEsY0FFSUcsYUFBYWxkLE1BQU1uRCxJQUFOLENBQVcsZUFBWCxNQUFnQyxNQUZqRDtBQUFBLGNBR0l3UyxPQUFPclAsTUFBTXNQLFFBQU4sQ0FBZSxzQkFBZixDQUhYOztBQUtBLGNBQUkyTixNQUFKLEVBQVk7QUFDVixnQkFBSUMsVUFBSixFQUFnQjtBQUNkLGtCQUFJLENBQUN4ZSxNQUFNK1EsT0FBTixDQUFjdUosWUFBZixJQUFnQyxDQUFDdGEsTUFBTStRLE9BQU4sQ0FBYzBOLFNBQWYsSUFBNEIsQ0FBQ04sUUFBN0QsSUFBMkVuZSxNQUFNK1EsT0FBTixDQUFjMk4sV0FBZCxJQUE2QlAsUUFBNUcsRUFBdUg7QUFBRTtBQUFTLGVBQWxJLE1BQ0s7QUFDSHJjLGtCQUFFeVcsd0JBQUY7QUFDQXpXLGtCQUFFdUosY0FBRjtBQUNBckwsc0JBQU11YixLQUFOLENBQVlqYSxLQUFaO0FBQ0Q7QUFDRixhQVBELE1BT087QUFDTFEsZ0JBQUV1SixjQUFGO0FBQ0F2SixnQkFBRXlXLHdCQUFGO0FBQ0F2WSxvQkFBTXFhLEtBQU4sQ0FBWTFKLElBQVo7QUFDQXJQLG9CQUFNbVgsR0FBTixDQUFVblgsTUFBTWtYLFlBQU4sQ0FBbUJ4WSxNQUFNaEIsUUFBekIsUUFBdUNxZixRQUF2QyxDQUFWLEVBQThEbGdCLElBQTlELENBQW1FLGVBQW5FLEVBQW9GLElBQXBGO0FBQ0Q7QUFDRjtBQUNGLFNBckJEOztBQXVCQSxZQUFJLEtBQUs0UyxPQUFMLENBQWEwTixTQUFiLElBQTBCTixRQUE5QixFQUF3QztBQUN0QyxlQUFLbkYsVUFBTCxDQUFnQjdOLEVBQWhCLENBQW1CLGtEQUFuQixFQUF1RW1ULGFBQXZFO0FBQ0Q7O0FBRUQ7QUFDQSxZQUFHdGUsTUFBTStRLE9BQU4sQ0FBYzROLGtCQUFqQixFQUFvQztBQUNsQyxlQUFLM0YsVUFBTCxDQUFnQjdOLEVBQWhCLENBQW1CLGdEQUFuQixFQUFxRSxVQUFTckosQ0FBVCxFQUFZO0FBQy9FLGdCQUFJUixRQUFRMUQsRUFBRSxJQUFGLENBQVo7QUFBQSxnQkFDSTJnQixTQUFTamQsTUFBTWdXLFFBQU4sQ0FBZStHLFFBQWYsQ0FEYjtBQUVBLGdCQUFHLENBQUNFLE1BQUosRUFBVztBQUNUdmUsb0JBQU11YixLQUFOO0FBQ0Q7QUFDRixXQU5EO0FBT0Q7O0FBRUQsWUFBSSxDQUFDLEtBQUt4SyxPQUFMLENBQWE2TixZQUFsQixFQUFnQztBQUM5QixlQUFLNUYsVUFBTCxDQUFnQjdOLEVBQWhCLENBQW1CLDRCQUFuQixFQUFpRCxVQUFTckosQ0FBVCxFQUFZO0FBQzNELGdCQUFJUixRQUFRMUQsRUFBRSxJQUFGLENBQVo7QUFBQSxnQkFDSTJnQixTQUFTamQsTUFBTWdXLFFBQU4sQ0FBZStHLFFBQWYsQ0FEYjs7QUFHQSxnQkFBSUUsTUFBSixFQUFZO0FBQ1ZqWiwyQkFBYWhFLE1BQU1yQyxJQUFOLENBQVcsUUFBWCxDQUFiO0FBQ0FxQyxvQkFBTXJDLElBQU4sQ0FBVyxRQUFYLEVBQXFCNEQsV0FBVyxZQUFXO0FBQ3pDN0Msc0JBQU1xYSxLQUFOLENBQVkvWSxNQUFNc1AsUUFBTixDQUFlLHNCQUFmLENBQVo7QUFDRCxlQUZvQixFQUVsQjVRLE1BQU0rUSxPQUFOLENBQWN1TSxVQUZJLENBQXJCO0FBR0Q7QUFDRixXQVZELEVBVUduUyxFQVZILENBVU0sNEJBVk4sRUFVb0MsVUFBU3JKLENBQVQsRUFBWTtBQUM5QyxnQkFBSVIsUUFBUTFELEVBQUUsSUFBRixDQUFaO0FBQUEsZ0JBQ0kyZ0IsU0FBU2pkLE1BQU1nVyxRQUFOLENBQWUrRyxRQUFmLENBRGI7QUFFQSxnQkFBSUUsVUFBVXZlLE1BQU0rUSxPQUFOLENBQWM4TixTQUE1QixFQUF1QztBQUNyQyxrQkFBSXZkLE1BQU1uRCxJQUFOLENBQVcsZUFBWCxNQUFnQyxNQUFoQyxJQUEwQzZCLE1BQU0rUSxPQUFOLENBQWMwTixTQUE1RCxFQUF1RTtBQUFFLHVCQUFPLEtBQVA7QUFBZTs7QUFFeEZuWiwyQkFBYWhFLE1BQU1yQyxJQUFOLENBQVcsUUFBWCxDQUFiO0FBQ0FxQyxvQkFBTXJDLElBQU4sQ0FBVyxRQUFYLEVBQXFCNEQsV0FBVyxZQUFXO0FBQ3pDN0Msc0JBQU11YixLQUFOLENBQVlqYSxLQUFaO0FBQ0QsZUFGb0IsRUFFbEJ0QixNQUFNK1EsT0FBTixDQUFjK04sV0FGSSxDQUFyQjtBQUdEO0FBQ0YsV0FyQkQ7QUFzQkQ7QUFDRCxhQUFLOUYsVUFBTCxDQUFnQjdOLEVBQWhCLENBQW1CLHlCQUFuQixFQUE4QyxVQUFTckosQ0FBVCxFQUFZO0FBQ3hELGNBQUk5QyxXQUFXcEIsRUFBRWtFLEVBQUVzSixNQUFKLEVBQVlvTixZQUFaLENBQXlCLElBQXpCLEVBQStCLG1CQUEvQixDQUFmO0FBQUEsY0FDSXVHLFFBQVEvZSxNQUFNOGQsS0FBTixDQUFZa0IsS0FBWixDQUFrQmhnQixRQUFsQixJQUE4QixDQUFDLENBRDNDO0FBQUEsY0FFSTRZLFlBQVltSCxRQUFRL2UsTUFBTThkLEtBQWQsR0FBc0I5ZSxTQUFTaWdCLFFBQVQsQ0FBa0IsSUFBbEIsRUFBd0J4RyxHQUF4QixDQUE0QnpaLFFBQTVCLENBRnRDO0FBQUEsY0FHSTZZLFlBSEo7QUFBQSxjQUlJQyxZQUpKOztBQU1BRixvQkFBVS9YLElBQVYsQ0FBZSxVQUFTd0IsQ0FBVCxFQUFZO0FBQ3pCLGdCQUFJekQsRUFBRSxJQUFGLEVBQVErTSxFQUFSLENBQVczTCxRQUFYLENBQUosRUFBMEI7QUFDeEI2WSw2QkFBZUQsVUFBVTNNLEVBQVYsQ0FBYTVKLElBQUUsQ0FBZixDQUFmO0FBQ0F5Vyw2QkFBZUYsVUFBVTNNLEVBQVYsQ0FBYTVKLElBQUUsQ0FBZixDQUFmO0FBQ0E7QUFDRDtBQUNGLFdBTkQ7O0FBUUEsY0FBSTZkLGNBQWMsU0FBZEEsV0FBYyxHQUFXO0FBQzNCLGdCQUFJLENBQUNsZ0IsU0FBUzJMLEVBQVQsQ0FBWSxhQUFaLENBQUwsRUFBaUM7QUFDL0JtTiwyQkFBYWxILFFBQWIsQ0FBc0IsU0FBdEIsRUFBaUN0RixLQUFqQztBQUNBeEosZ0JBQUV1SixjQUFGO0FBQ0Q7QUFDRixXQUxEO0FBQUEsY0FLRzhULGNBQWMsU0FBZEEsV0FBYyxHQUFXO0FBQzFCdEgseUJBQWFqSCxRQUFiLENBQXNCLFNBQXRCLEVBQWlDdEYsS0FBakM7QUFDQXhKLGNBQUV1SixjQUFGO0FBQ0QsV0FSRDtBQUFBLGNBUUcrVCxVQUFVLFNBQVZBLE9BQVUsR0FBVztBQUN0QixnQkFBSXpPLE9BQU8zUixTQUFTNFIsUUFBVCxDQUFrQix3QkFBbEIsQ0FBWDtBQUNBLGdCQUFJRCxLQUFLaFEsTUFBVCxFQUFpQjtBQUNmWCxvQkFBTXFhLEtBQU4sQ0FBWTFKLElBQVo7QUFDQTNSLHVCQUFTdUMsSUFBVCxDQUFjLGNBQWQsRUFBOEIrSixLQUE5QjtBQUNBeEosZ0JBQUV1SixjQUFGO0FBQ0QsYUFKRCxNQUlPO0FBQUU7QUFBUztBQUNuQixXQWZEO0FBQUEsY0FlR2dVLFdBQVcsU0FBWEEsUUFBVyxHQUFXO0FBQ3ZCO0FBQ0EsZ0JBQUlsSCxRQUFRblosU0FBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsRUFBc0JBLE1BQXRCLENBQTZCLElBQTdCLENBQVo7QUFDQXFSLGtCQUFNdkgsUUFBTixDQUFlLFNBQWYsRUFBMEJ0RixLQUExQjtBQUNBdEwsa0JBQU11YixLQUFOLENBQVlwRCxLQUFaO0FBQ0FyVyxjQUFFdUosY0FBRjtBQUNBO0FBQ0QsV0F0QkQ7QUF1QkEsY0FBSXJCLFlBQVk7QUFDZGtPLGtCQUFNa0gsT0FEUTtBQUVkakgsbUJBQU8saUJBQVc7QUFDaEJuWSxvQkFBTXViLEtBQU4sQ0FBWXZiLE1BQU1oQixRQUFsQjtBQUNBZ0Isb0JBQU1nWixVQUFOLENBQWlCelgsSUFBakIsQ0FBc0IsU0FBdEIsRUFBaUMrSixLQUFqQyxHQUZnQixDQUUwQjtBQUMxQ3hKLGdCQUFFdUosY0FBRjtBQUNELGFBTmE7QUFPZGQscUJBQVMsbUJBQVc7QUFDbEJ6SSxnQkFBRXlXLHdCQUFGO0FBQ0Q7QUFUYSxXQUFoQjs7QUFZQSxjQUFJd0csS0FBSixFQUFXO0FBQ1QsZ0JBQUkvZSxNQUFNc2YsV0FBTixFQUFKLEVBQXlCO0FBQUU7QUFDekIsa0JBQUl4aEIsV0FBV0ksR0FBWCxFQUFKLEVBQXNCO0FBQUU7QUFDdEJOLGtCQUFFeU0sTUFBRixDQUFTTCxTQUFULEVBQW9CO0FBQ2xCd04sd0JBQU0wSCxXQURZO0FBRWxCOUcsc0JBQUkrRyxXQUZjO0FBR2xCbEgsd0JBQU1vSCxRQUhZO0FBSWxCL0QsNEJBQVU4RDtBQUpRLGlCQUFwQjtBQU1ELGVBUEQsTUFPTztBQUFFO0FBQ1B4aEIsa0JBQUV5TSxNQUFGLENBQVNMLFNBQVQsRUFBb0I7QUFDbEJ3Tix3QkFBTTBILFdBRFk7QUFFbEI5RyxzQkFBSStHLFdBRmM7QUFHbEJsSCx3QkFBTW1ILE9BSFk7QUFJbEI5RCw0QkFBVStEO0FBSlEsaUJBQXBCO0FBTUQ7QUFDRixhQWhCRCxNQWdCTztBQUFFO0FBQ1Asa0JBQUl2aEIsV0FBV0ksR0FBWCxFQUFKLEVBQXNCO0FBQUU7QUFDdEJOLGtCQUFFeU0sTUFBRixDQUFTTCxTQUFULEVBQW9CO0FBQ2xCaU8sd0JBQU1rSCxXQURZO0FBRWxCN0QsNEJBQVU0RCxXQUZRO0FBR2xCMUgsd0JBQU00SCxPQUhZO0FBSWxCaEgsc0JBQUlpSDtBQUpjLGlCQUFwQjtBQU1ELGVBUEQsTUFPTztBQUFFO0FBQ1B6aEIsa0JBQUV5TSxNQUFGLENBQVNMLFNBQVQsRUFBb0I7QUFDbEJpTyx3QkFBTWlILFdBRFk7QUFFbEI1RCw0QkFBVTZELFdBRlE7QUFHbEIzSCx3QkFBTTRILE9BSFk7QUFJbEJoSCxzQkFBSWlIO0FBSmMsaUJBQXBCO0FBTUQ7QUFDRjtBQUNGLFdBbENELE1Ba0NPO0FBQUU7QUFDUCxnQkFBSXZoQixXQUFXSSxHQUFYLEVBQUosRUFBc0I7QUFBRTtBQUN0Qk4sZ0JBQUV5TSxNQUFGLENBQVNMLFNBQVQsRUFBb0I7QUFDbEJpTyxzQkFBTW9ILFFBRFk7QUFFbEIvRCwwQkFBVThELE9BRlE7QUFHbEI1SCxzQkFBTTBILFdBSFk7QUFJbEI5RyxvQkFBSStHO0FBSmMsZUFBcEI7QUFNRCxhQVBELE1BT087QUFBRTtBQUNQdmhCLGdCQUFFeU0sTUFBRixDQUFTTCxTQUFULEVBQW9CO0FBQ2xCaU8sc0JBQU1tSCxPQURZO0FBRWxCOUQsMEJBQVUrRCxRQUZRO0FBR2xCN0gsc0JBQU0wSCxXQUhZO0FBSWxCOUcsb0JBQUkrRztBQUpjLGVBQXBCO0FBTUQ7QUFDRjtBQUNEcmhCLHFCQUFXbUwsUUFBWCxDQUFvQmEsU0FBcEIsQ0FBOEJoSSxDQUE5QixFQUFpQyxjQUFqQyxFQUFpRGtJLFNBQWpEO0FBRUQsU0F2R0Q7QUF3R0Q7O0FBRUQ7Ozs7OztBQW5QVztBQUFBO0FBQUEsd0NBd1BPO0FBQ2hCLFlBQUl1USxRQUFRM2MsRUFBRTRFLFNBQVMwRixJQUFYLENBQVo7QUFBQSxZQUNJbEksUUFBUSxJQURaO0FBRUF1YSxjQUFNL08sR0FBTixDQUFVLGtEQUFWLEVBQ01MLEVBRE4sQ0FDUyxrREFEVCxFQUM2RCxVQUFTckosQ0FBVCxFQUFZO0FBQ2xFLGNBQUlzWCxRQUFRcFosTUFBTWhCLFFBQU4sQ0FBZXVDLElBQWYsQ0FBb0JPLEVBQUVzSixNQUF0QixDQUFaO0FBQ0EsY0FBSWdPLE1BQU16WSxNQUFWLEVBQWtCO0FBQUU7QUFBUzs7QUFFN0JYLGdCQUFNdWIsS0FBTjtBQUNBaEIsZ0JBQU0vTyxHQUFOLENBQVUsa0RBQVY7QUFDRCxTQVBOO0FBUUQ7O0FBRUQ7Ozs7Ozs7O0FBclFXO0FBQUE7QUFBQSw0QkE0UUxtRixJQTVRSyxFQTRRQztBQUNWLFlBQUk0TyxNQUFNLEtBQUt6QixLQUFMLENBQVdrQixLQUFYLENBQWlCLEtBQUtsQixLQUFMLENBQVdwVCxNQUFYLENBQWtCLFVBQVNySixDQUFULEVBQVlZLEVBQVosRUFBZ0I7QUFDM0QsaUJBQU9yRSxFQUFFcUUsRUFBRixFQUFNVixJQUFOLENBQVdvUCxJQUFYLEVBQWlCaFEsTUFBakIsR0FBMEIsQ0FBakM7QUFDRCxTQUYwQixDQUFqQixDQUFWO0FBR0EsWUFBSTZlLFFBQVE3TyxLQUFLN0osTUFBTCxDQUFZLCtCQUFaLEVBQTZDbVksUUFBN0MsQ0FBc0QsK0JBQXRELENBQVo7QUFDQSxhQUFLMUQsS0FBTCxDQUFXaUUsS0FBWCxFQUFrQkQsR0FBbEI7QUFDQTVPLGFBQUt2RSxHQUFMLENBQVMsWUFBVCxFQUF1QixRQUF2QixFQUFpQ3dELFFBQWpDLENBQTBDLG9CQUExQyxFQUNLOUksTUFETCxDQUNZLCtCQURaLEVBQzZDOEksUUFEN0MsQ0FDc0QsV0FEdEQ7QUFFQSxZQUFJNlAsUUFBUTNoQixXQUFXMkksR0FBWCxDQUFlQyxnQkFBZixDQUFnQ2lLLElBQWhDLEVBQXNDLElBQXRDLEVBQTRDLElBQTVDLENBQVo7QUFDQSxZQUFJLENBQUM4TyxLQUFMLEVBQVk7QUFDVixjQUFJQyxXQUFXLEtBQUszTyxPQUFMLENBQWFrTixTQUFiLEtBQTJCLE1BQTNCLEdBQW9DLFFBQXBDLEdBQStDLE9BQTlEO0FBQUEsY0FDSTBCLFlBQVloUCxLQUFLN0osTUFBTCxDQUFZLDZCQUFaLENBRGhCO0FBRUE2WSxvQkFBVTliLFdBQVYsV0FBOEI2YixRQUE5QixFQUEwQzlQLFFBQTFDLFlBQTRELEtBQUttQixPQUFMLENBQWFrTixTQUF6RTtBQUNBd0Isa0JBQVEzaEIsV0FBVzJJLEdBQVgsQ0FBZUMsZ0JBQWYsQ0FBZ0NpSyxJQUFoQyxFQUFzQyxJQUF0QyxFQUE0QyxJQUE1QyxDQUFSO0FBQ0EsY0FBSSxDQUFDOE8sS0FBTCxFQUFZO0FBQ1ZFLHNCQUFVOWIsV0FBVixZQUErQixLQUFLa04sT0FBTCxDQUFha04sU0FBNUMsRUFBeURyTyxRQUF6RCxDQUFrRSxhQUFsRTtBQUNEO0FBQ0QsZUFBS3NPLE9BQUwsR0FBZSxJQUFmO0FBQ0Q7QUFDRHZOLGFBQUt2RSxHQUFMLENBQVMsWUFBVCxFQUF1QixFQUF2QjtBQUNBLFlBQUksS0FBSzJFLE9BQUwsQ0FBYXVKLFlBQWpCLEVBQStCO0FBQUUsZUFBS29ELGVBQUw7QUFBeUI7QUFDMUQ7Ozs7QUFJQSxhQUFLMWUsUUFBTCxDQUFjRSxPQUFkLENBQXNCLHNCQUF0QixFQUE4QyxDQUFDeVIsSUFBRCxDQUE5QztBQUNEOztBQUVEOzs7Ozs7OztBQXhTVztBQUFBO0FBQUEsNEJBK1NMclAsS0EvU0ssRUErU0VpZSxHQS9TRixFQStTTztBQUNoQixZQUFJSyxRQUFKO0FBQ0EsWUFBSXRlLFNBQVNBLE1BQU1YLE1BQW5CLEVBQTJCO0FBQ3pCaWYscUJBQVd0ZSxLQUFYO0FBQ0QsU0FGRCxNQUVPLElBQUlpZSxRQUFRcGIsU0FBWixFQUF1QjtBQUM1QnliLHFCQUFXLEtBQUs5QixLQUFMLENBQVdsSSxHQUFYLENBQWUsVUFBU3ZVLENBQVQsRUFBWVksRUFBWixFQUFnQjtBQUN4QyxtQkFBT1osTUFBTWtlLEdBQWI7QUFDRCxXQUZVLENBQVg7QUFHRCxTQUpNLE1BS0Y7QUFDSEsscUJBQVcsS0FBSzVnQixRQUFoQjtBQUNEO0FBQ0QsWUFBSTZnQixtQkFBbUJELFNBQVN0SSxRQUFULENBQWtCLFdBQWxCLEtBQWtDc0ksU0FBU3JlLElBQVQsQ0FBYyxZQUFkLEVBQTRCWixNQUE1QixHQUFxQyxDQUE5Rjs7QUFFQSxZQUFJa2YsZ0JBQUosRUFBc0I7QUFDcEJELG1CQUFTcmUsSUFBVCxDQUFjLGNBQWQsRUFBOEJrWCxHQUE5QixDQUFrQ21ILFFBQWxDLEVBQTRDemhCLElBQTVDLENBQWlEO0FBQy9DLDZCQUFpQjtBQUQ4QixXQUFqRCxFQUVHMEYsV0FGSCxDQUVlLFdBRmY7O0FBSUErYixtQkFBU3JlLElBQVQsQ0FBYyx1QkFBZCxFQUF1Q3NDLFdBQXZDLENBQW1ELG9CQUFuRDs7QUFFQSxjQUFJLEtBQUtxYSxPQUFMLElBQWdCMEIsU0FBU3JlLElBQVQsQ0FBYyxhQUFkLEVBQTZCWixNQUFqRCxFQUF5RDtBQUN2RCxnQkFBSStlLFdBQVcsS0FBSzNPLE9BQUwsQ0FBYWtOLFNBQWIsS0FBMkIsTUFBM0IsR0FBb0MsT0FBcEMsR0FBOEMsTUFBN0Q7QUFDQTJCLHFCQUFTcmUsSUFBVCxDQUFjLCtCQUFkLEVBQStDa1gsR0FBL0MsQ0FBbURtSCxRQUFuRCxFQUNTL2IsV0FEVCx3QkFDMEMsS0FBS2tOLE9BQUwsQ0FBYWtOLFNBRHZELEVBRVNyTyxRQUZULFlBRTJCOFAsUUFGM0I7QUFHQSxpQkFBS3hCLE9BQUwsR0FBZSxLQUFmO0FBQ0Q7QUFDRDs7OztBQUlBLGVBQUtsZixRQUFMLENBQWNFLE9BQWQsQ0FBc0Isc0JBQXRCLEVBQThDLENBQUMwZ0IsUUFBRCxDQUE5QztBQUNEO0FBQ0Y7O0FBRUQ7Ozs7O0FBblZXO0FBQUE7QUFBQSxnQ0F1VkQ7QUFDUixhQUFLNUcsVUFBTCxDQUFnQnhOLEdBQWhCLENBQW9CLGtCQUFwQixFQUF3Q2pNLFVBQXhDLENBQW1ELGVBQW5ELEVBQ0tzRSxXQURMLENBQ2lCLCtFQURqQjtBQUVBakcsVUFBRTRFLFNBQVMwRixJQUFYLEVBQWlCc0QsR0FBakIsQ0FBcUIsa0JBQXJCO0FBQ0ExTixtQkFBV3FTLElBQVgsQ0FBZ0JVLElBQWhCLENBQXFCLEtBQUs3UixRQUExQixFQUFvQyxVQUFwQztBQUNBbEIsbUJBQVdzQixnQkFBWCxDQUE0QixJQUE1QjtBQUNEO0FBN1ZVOztBQUFBO0FBQUE7O0FBZ1diOzs7OztBQUdBd2UsZUFBYTdHLFFBQWIsR0FBd0I7QUFDdEI7Ozs7O0FBS0E2SCxrQkFBYyxLQU5RO0FBT3RCOzs7OztBQUtBQyxlQUFXLElBWlc7QUFhdEI7Ozs7O0FBS0F2QixnQkFBWSxFQWxCVTtBQW1CdEI7Ozs7O0FBS0FtQixlQUFXLEtBeEJXO0FBeUJ0Qjs7Ozs7O0FBTUFLLGlCQUFhLEdBL0JTO0FBZ0N0Qjs7Ozs7QUFLQWIsZUFBVyxNQXJDVztBQXNDdEI7Ozs7O0FBS0EzRCxrQkFBYyxJQTNDUTtBQTRDdEI7Ozs7O0FBS0FxRSx3QkFBb0IsSUFqREU7QUFrRHRCOzs7OztBQUtBWixtQkFBZSxVQXZETztBQXdEdEI7Ozs7O0FBS0FDLGdCQUFZLGFBN0RVO0FBOER0Qjs7Ozs7QUFLQVUsaUJBQWE7QUFuRVMsR0FBeEI7O0FBc0VBO0FBQ0E1Z0IsYUFBV00sTUFBWCxDQUFrQndmLFlBQWxCLEVBQWdDLGNBQWhDO0FBRUMsQ0E1YUEsQ0E0YUNwWCxNQTVhRCxDQUFEO0NDRkE7Ozs7OztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYjs7Ozs7Ozs7QUFGYSxNQVVQa2lCLFNBVk87QUFXWDs7Ozs7OztBQU9BLHVCQUFZalosT0FBWixFQUFxQmtLLE9BQXJCLEVBQThCO0FBQUE7O0FBQzVCLFdBQUsvUixRQUFMLEdBQWdCNkgsT0FBaEI7QUFDQSxXQUFLa0ssT0FBTCxHQUFlblQsRUFBRXlNLE1BQUYsQ0FBUyxFQUFULEVBQWF5VixVQUFVL0ksUUFBdkIsRUFBaUMsS0FBSy9YLFFBQUwsQ0FBY0MsSUFBZCxFQUFqQyxFQUF1RDhSLE9BQXZELENBQWY7QUFDQSxXQUFLZ1AsWUFBTCxHQUFvQm5pQixHQUFwQjtBQUNBLFdBQUtvaUIsU0FBTCxHQUFpQnBpQixHQUFqQjs7QUFFQSxXQUFLa0MsS0FBTDtBQUNBLFdBQUsyWCxPQUFMOztBQUVBM1osaUJBQVdZLGNBQVgsQ0FBMEIsSUFBMUIsRUFBZ0MsV0FBaEM7QUFDQVosaUJBQVdtTCxRQUFYLENBQW9CMkIsUUFBcEIsQ0FBNkIsV0FBN0IsRUFBMEM7QUFDeEMsa0JBQVU7QUFEOEIsT0FBMUM7QUFJRDs7QUFFRDs7Ozs7OztBQWxDVztBQUFBO0FBQUEsOEJBdUNIO0FBQ04sWUFBSTZDLEtBQUssS0FBS3pPLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixJQUFuQixDQUFUOztBQUVBLGFBQUthLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixhQUFuQixFQUFrQyxNQUFsQzs7QUFFQSxhQUFLYSxRQUFMLENBQWM0USxRQUFkLG9CQUF3QyxLQUFLbUIsT0FBTCxDQUFha1AsVUFBckQ7O0FBRUE7QUFDQSxhQUFLRCxTQUFMLEdBQWlCcGlCLEVBQUU0RSxRQUFGLEVBQ2RqQixJQURjLENBQ1QsaUJBQWVrTSxFQUFmLEdBQWtCLG1CQUFsQixHQUFzQ0EsRUFBdEMsR0FBeUMsb0JBQXpDLEdBQThEQSxFQUE5RCxHQUFpRSxJQUR4RCxFQUVkdFAsSUFGYyxDQUVULGVBRlMsRUFFUSxPQUZSLEVBR2RBLElBSGMsQ0FHVCxlQUhTLEVBR1FzUCxFQUhSLENBQWpCOztBQUtBO0FBQ0EsWUFBSSxLQUFLc0QsT0FBTCxDQUFhbVAsY0FBYixLQUFnQyxJQUFwQyxFQUEwQztBQUN4QyxjQUFJQyxVQUFVM2QsU0FBU0MsYUFBVCxDQUF1QixLQUF2QixDQUFkO0FBQ0EsY0FBSTJkLGtCQUFrQnhpQixFQUFFLEtBQUtvQixRQUFQLEVBQWlCb04sR0FBakIsQ0FBcUIsVUFBckIsTUFBcUMsT0FBckMsR0FBK0Msa0JBQS9DLEdBQW9FLHFCQUExRjtBQUNBK1Qsa0JBQVFFLFlBQVIsQ0FBcUIsT0FBckIsRUFBOEIsMkJBQTJCRCxlQUF6RDtBQUNBLGVBQUtFLFFBQUwsR0FBZ0IxaUIsRUFBRXVpQixPQUFGLENBQWhCO0FBQ0EsY0FBR0Msb0JBQW9CLGtCQUF2QixFQUEyQztBQUN6Q3hpQixjQUFFLE1BQUYsRUFBVWdjLE1BQVYsQ0FBaUIsS0FBSzBHLFFBQXRCO0FBQ0QsV0FGRCxNQUVPO0FBQ0wsaUJBQUt0aEIsUUFBTCxDQUFjaWdCLFFBQWQsQ0FBdUIsMkJBQXZCLEVBQW9EckYsTUFBcEQsQ0FBMkQsS0FBSzBHLFFBQWhFO0FBQ0Q7QUFDRjs7QUFFRCxhQUFLdlAsT0FBTCxDQUFhd1AsVUFBYixHQUEwQixLQUFLeFAsT0FBTCxDQUFhd1AsVUFBYixJQUEyQixJQUFJQyxNQUFKLENBQVcsS0FBS3pQLE9BQUwsQ0FBYTBQLFdBQXhCLEVBQXFDLEdBQXJDLEVBQTBDMWIsSUFBMUMsQ0FBK0MsS0FBSy9GLFFBQUwsQ0FBYyxDQUFkLEVBQWlCVixTQUFoRSxDQUFyRDs7QUFFQSxZQUFJLEtBQUt5UyxPQUFMLENBQWF3UCxVQUFiLEtBQTRCLElBQWhDLEVBQXNDO0FBQ3BDLGVBQUt4UCxPQUFMLENBQWEyUCxRQUFiLEdBQXdCLEtBQUszUCxPQUFMLENBQWEyUCxRQUFiLElBQXlCLEtBQUsxaEIsUUFBTCxDQUFjLENBQWQsRUFBaUJWLFNBQWpCLENBQTJCbWUsS0FBM0IsQ0FBaUMsdUNBQWpDLEVBQTBFLENBQTFFLEVBQTZFNWEsS0FBN0UsQ0FBbUYsR0FBbkYsRUFBd0YsQ0FBeEYsQ0FBakQ7QUFDQSxlQUFLOGUsYUFBTDtBQUNEO0FBQ0QsWUFBSSxDQUFDLEtBQUs1UCxPQUFMLENBQWE2UCxjQUFkLEtBQWlDLElBQXJDLEVBQTJDO0FBQ3pDLGVBQUs3UCxPQUFMLENBQWE2UCxjQUFiLEdBQThCdGEsV0FBV2hDLE9BQU9xSixnQkFBUCxDQUF3Qi9QLEVBQUUsbUJBQUYsRUFBdUIsQ0FBdkIsQ0FBeEIsRUFBbURzUyxrQkFBOUQsSUFBb0YsSUFBbEg7QUFDRDtBQUNGOztBQUVEOzs7Ozs7QUE1RVc7QUFBQTtBQUFBLGdDQWlGRDtBQUNSLGFBQUtsUixRQUFMLENBQWN3TSxHQUFkLENBQWtCLDJCQUFsQixFQUErQ0wsRUFBL0MsQ0FBa0Q7QUFDaEQsNkJBQW1CLEtBQUsrTSxJQUFMLENBQVV4UyxJQUFWLENBQWUsSUFBZixDQUQ2QjtBQUVoRCw4QkFBb0IsS0FBS3lTLEtBQUwsQ0FBV3pTLElBQVgsQ0FBZ0IsSUFBaEIsQ0FGNEI7QUFHaEQsK0JBQXFCLEtBQUtpUyxNQUFMLENBQVlqUyxJQUFaLENBQWlCLElBQWpCLENBSDJCO0FBSWhELGtDQUF3QixLQUFLbWIsZUFBTCxDQUFxQm5iLElBQXJCLENBQTBCLElBQTFCO0FBSndCLFNBQWxEOztBQU9BLFlBQUksS0FBS3FMLE9BQUwsQ0FBYXVKLFlBQWIsS0FBOEIsSUFBbEMsRUFBd0M7QUFDdEMsY0FBSW5FLFVBQVUsS0FBS3BGLE9BQUwsQ0FBYW1QLGNBQWIsR0FBOEIsS0FBS0ksUUFBbkMsR0FBOEMxaUIsRUFBRSwyQkFBRixDQUE1RDtBQUNBdVksa0JBQVFoTCxFQUFSLENBQVcsRUFBQyxzQkFBc0IsS0FBS2dOLEtBQUwsQ0FBV3pTLElBQVgsQ0FBZ0IsSUFBaEIsQ0FBdkIsRUFBWDtBQUNEO0FBQ0Y7O0FBRUQ7Ozs7O0FBL0ZXO0FBQUE7QUFBQSxzQ0FtR0s7QUFDZCxZQUFJMUYsUUFBUSxJQUFaOztBQUVBcEMsVUFBRTBHLE1BQUYsRUFBVTZHLEVBQVYsQ0FBYSx1QkFBYixFQUFzQyxZQUFXO0FBQy9DLGNBQUlyTixXQUFXZ0csVUFBWCxDQUFzQjZJLE9BQXRCLENBQThCM00sTUFBTStRLE9BQU4sQ0FBYzJQLFFBQTVDLENBQUosRUFBMkQ7QUFDekQxZ0Isa0JBQU04Z0IsTUFBTixDQUFhLElBQWI7QUFDRCxXQUZELE1BRU87QUFDTDlnQixrQkFBTThnQixNQUFOLENBQWEsS0FBYjtBQUNEO0FBQ0YsU0FORCxFQU1HL1EsR0FOSCxDQU1PLG1CQU5QLEVBTTRCLFlBQVc7QUFDckMsY0FBSWpTLFdBQVdnRyxVQUFYLENBQXNCNkksT0FBdEIsQ0FBOEIzTSxNQUFNK1EsT0FBTixDQUFjMlAsUUFBNUMsQ0FBSixFQUEyRDtBQUN6RDFnQixrQkFBTThnQixNQUFOLENBQWEsSUFBYjtBQUNEO0FBQ0YsU0FWRDtBQVdEOztBQUVEOzs7Ozs7QUFuSFc7QUFBQTtBQUFBLDZCQXdISlAsVUF4SEksRUF3SFE7QUFDakIsWUFBSVEsVUFBVSxLQUFLL2hCLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsY0FBbkIsQ0FBZDtBQUNBLFlBQUlnZixVQUFKLEVBQWdCO0FBQ2QsZUFBS3BJLEtBQUw7QUFDQSxlQUFLb0ksVUFBTCxHQUFrQixJQUFsQjtBQUNBLGVBQUt2aEIsUUFBTCxDQUFjYixJQUFkLENBQW1CLGFBQW5CLEVBQWtDLE9BQWxDO0FBQ0EsZUFBS2EsUUFBTCxDQUFjd00sR0FBZCxDQUFrQixtQ0FBbEI7QUFDQSxjQUFJdVYsUUFBUXBnQixNQUFaLEVBQW9CO0FBQUVvZ0Isb0JBQVE5USxJQUFSO0FBQWlCO0FBQ3hDLFNBTkQsTUFNTztBQUNMLGVBQUtzUSxVQUFMLEdBQWtCLEtBQWxCO0FBQ0EsZUFBS3ZoQixRQUFMLENBQWNiLElBQWQsQ0FBbUIsYUFBbkIsRUFBa0MsTUFBbEM7QUFDQSxlQUFLYSxRQUFMLENBQWNtTSxFQUFkLENBQWlCO0FBQ2YsK0JBQW1CLEtBQUsrTSxJQUFMLENBQVV4UyxJQUFWLENBQWUsSUFBZixDQURKO0FBRWYsaUNBQXFCLEtBQUtpUyxNQUFMLENBQVlqUyxJQUFaLENBQWlCLElBQWpCO0FBRk4sV0FBakI7QUFJQSxjQUFJcWIsUUFBUXBnQixNQUFaLEVBQW9CO0FBQ2xCb2dCLG9CQUFRbFIsSUFBUjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRDs7Ozs7QUE3SVc7QUFBQTtBQUFBLHFDQWlKSXpHLEtBakpKLEVBaUpXO0FBQ3JCLGVBQU8sS0FBUDtBQUNBOztBQUVEOzs7Ozs7OztBQXJKVztBQUFBO0FBQUEsMkJBNEpOQSxLQTVKTSxFQTRKQ2xLLE9BNUpELEVBNEpVO0FBQ25CLFlBQUksS0FBS0YsUUFBTCxDQUFjc1ksUUFBZCxDQUF1QixTQUF2QixLQUFxQyxLQUFLaUosVUFBOUMsRUFBMEQ7QUFBRTtBQUFTO0FBQ3JFLFlBQUl2Z0IsUUFBUSxJQUFaOztBQUVBLFlBQUlkLE9BQUosRUFBYTtBQUNYLGVBQUs2Z0IsWUFBTCxHQUFvQjdnQixPQUFwQjtBQUNEOztBQUVELFlBQUksS0FBSzZSLE9BQUwsQ0FBYWlRLE9BQWIsS0FBeUIsS0FBN0IsRUFBb0M7QUFDbEMxYyxpQkFBTzJjLFFBQVAsQ0FBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkI7QUFDRCxTQUZELE1BRU8sSUFBSSxLQUFLbFEsT0FBTCxDQUFhaVEsT0FBYixLQUF5QixRQUE3QixFQUF1QztBQUM1QzFjLGlCQUFPMmMsUUFBUCxDQUFnQixDQUFoQixFQUFrQnplLFNBQVMwRixJQUFULENBQWNnWixZQUFoQztBQUNEOztBQUVEOzs7O0FBSUFsaEIsY0FBTWhCLFFBQU4sQ0FBZTRRLFFBQWYsQ0FBd0IsU0FBeEI7O0FBRUEsYUFBS29RLFNBQUwsQ0FBZTdoQixJQUFmLENBQW9CLGVBQXBCLEVBQXFDLE1BQXJDO0FBQ0EsYUFBS2EsUUFBTCxDQUFjYixJQUFkLENBQW1CLGFBQW5CLEVBQWtDLE9BQWxDLEVBQ0tlLE9BREwsQ0FDYSxxQkFEYjs7QUFHQTtBQUNBLFlBQUksS0FBSzZSLE9BQUwsQ0FBYW9RLGFBQWIsS0FBK0IsS0FBbkMsRUFBMEM7QUFDeEN2akIsWUFBRSxNQUFGLEVBQVVnUyxRQUFWLENBQW1CLG9CQUFuQixFQUF5Q3pFLEVBQXpDLENBQTRDLFdBQTVDLEVBQXlELEtBQUtpVyxjQUE5RDtBQUNEOztBQUVELFlBQUksS0FBS3JRLE9BQUwsQ0FBYW1QLGNBQWIsS0FBZ0MsSUFBcEMsRUFBMEM7QUFDeEMsZUFBS0ksUUFBTCxDQUFjMVEsUUFBZCxDQUF1QixZQUF2QjtBQUNEOztBQUVELFlBQUksS0FBS21CLE9BQUwsQ0FBYXVKLFlBQWIsS0FBOEIsSUFBOUIsSUFBc0MsS0FBS3ZKLE9BQUwsQ0FBYW1QLGNBQWIsS0FBZ0MsSUFBMUUsRUFBZ0Y7QUFDOUUsZUFBS0ksUUFBTCxDQUFjMVEsUUFBZCxDQUF1QixhQUF2QjtBQUNEOztBQUVELFlBQUksS0FBS21CLE9BQUwsQ0FBYTBNLFNBQWIsS0FBMkIsSUFBL0IsRUFBcUM7QUFDbkMsZUFBS3plLFFBQUwsQ0FBYytRLEdBQWQsQ0FBa0JqUyxXQUFXd0UsYUFBWCxDQUF5QixLQUFLdEQsUUFBOUIsQ0FBbEIsRUFBMkQsWUFBVztBQUNwRWdCLGtCQUFNaEIsUUFBTixDQUFldUMsSUFBZixDQUFvQixXQUFwQixFQUFpQzBKLEVBQWpDLENBQW9DLENBQXBDLEVBQXVDSyxLQUF2QztBQUNELFdBRkQ7QUFHRDs7QUFFRCxZQUFJLEtBQUt5RixPQUFMLENBQWFqRyxTQUFiLEtBQTJCLElBQS9CLEVBQXFDO0FBQ25DLGVBQUs5TCxRQUFMLENBQWNpZ0IsUUFBZCxDQUF1QiwyQkFBdkIsRUFBb0Q5Z0IsSUFBcEQsQ0FBeUQsVUFBekQsRUFBcUUsSUFBckU7QUFDQUwscUJBQVdtTCxRQUFYLENBQW9CNkIsU0FBcEIsQ0FBOEIsS0FBSzlMLFFBQW5DO0FBQ0Q7QUFDRjs7QUFFRDs7Ozs7OztBQTdNVztBQUFBO0FBQUEsNEJBbU5MK1AsRUFuTkssRUFtTkQ7QUFDUixZQUFJLENBQUMsS0FBSy9QLFFBQUwsQ0FBY3NZLFFBQWQsQ0FBdUIsU0FBdkIsQ0FBRCxJQUFzQyxLQUFLaUosVUFBL0MsRUFBMkQ7QUFBRTtBQUFTOztBQUV0RSxZQUFJdmdCLFFBQVEsSUFBWjs7QUFFQUEsY0FBTWhCLFFBQU4sQ0FBZTZFLFdBQWYsQ0FBMkIsU0FBM0I7O0FBRUEsYUFBSzdFLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixhQUFuQixFQUFrQyxNQUFsQztBQUNFOzs7O0FBREYsU0FLS2UsT0FMTCxDQUthLHFCQUxiOztBQU9BO0FBQ0EsWUFBSSxLQUFLNlIsT0FBTCxDQUFhb1EsYUFBYixLQUErQixLQUFuQyxFQUEwQztBQUN4Q3ZqQixZQUFFLE1BQUYsRUFBVWlHLFdBQVYsQ0FBc0Isb0JBQXRCLEVBQTRDMkgsR0FBNUMsQ0FBZ0QsV0FBaEQsRUFBNkQsS0FBSzRWLGNBQWxFO0FBQ0Q7O0FBRUQsWUFBSSxLQUFLclEsT0FBTCxDQUFhbVAsY0FBYixLQUFnQyxJQUFwQyxFQUEwQztBQUN4QyxlQUFLSSxRQUFMLENBQWN6YyxXQUFkLENBQTBCLFlBQTFCO0FBQ0Q7O0FBRUQsWUFBSSxLQUFLa04sT0FBTCxDQUFhdUosWUFBYixLQUE4QixJQUE5QixJQUFzQyxLQUFLdkosT0FBTCxDQUFhbVAsY0FBYixLQUFnQyxJQUExRSxFQUFnRjtBQUM5RSxlQUFLSSxRQUFMLENBQWN6YyxXQUFkLENBQTBCLGFBQTFCO0FBQ0Q7O0FBRUQsYUFBS21jLFNBQUwsQ0FBZTdoQixJQUFmLENBQW9CLGVBQXBCLEVBQXFDLE9BQXJDOztBQUVBLFlBQUksS0FBSzRTLE9BQUwsQ0FBYWpHLFNBQWIsS0FBMkIsSUFBL0IsRUFBcUM7QUFDbkMsZUFBSzlMLFFBQUwsQ0FBY2lnQixRQUFkLENBQXVCLDJCQUF2QixFQUFvRDFmLFVBQXBELENBQStELFVBQS9EO0FBQ0F6QixxQkFBV21MLFFBQVgsQ0FBb0JzQyxZQUFwQixDQUFpQyxLQUFLdk0sUUFBdEM7QUFDRDtBQUNGOztBQUVEOzs7Ozs7O0FBdFBXO0FBQUE7QUFBQSw2QkE0UEpvSyxLQTVQSSxFQTRQR2xLLE9BNVBILEVBNFBZO0FBQ3JCLFlBQUksS0FBS0YsUUFBTCxDQUFjc1ksUUFBZCxDQUF1QixTQUF2QixDQUFKLEVBQXVDO0FBQ3JDLGVBQUthLEtBQUwsQ0FBVy9PLEtBQVgsRUFBa0JsSyxPQUFsQjtBQUNELFNBRkQsTUFHSztBQUNILGVBQUtnWixJQUFMLENBQVU5TyxLQUFWLEVBQWlCbEssT0FBakI7QUFDRDtBQUNGOztBQUVEOzs7Ozs7QUFyUVc7QUFBQTtBQUFBLHNDQTBRSzRDLENBMVFMLEVBMFFRO0FBQUE7O0FBQ2pCaEUsbUJBQVdtTCxRQUFYLENBQW9CYSxTQUFwQixDQUE4QmhJLENBQTlCLEVBQWlDLFdBQWpDLEVBQThDO0FBQzVDcVcsaUJBQU8saUJBQU07QUFDWCxtQkFBS0EsS0FBTDtBQUNBLG1CQUFLNEgsWUFBTCxDQUFrQnpVLEtBQWxCO0FBQ0EsbUJBQU8sSUFBUDtBQUNELFdBTDJDO0FBTTVDZixtQkFBUyxtQkFBTTtBQUNiekksY0FBRWlULGVBQUY7QUFDQWpULGNBQUV1SixjQUFGO0FBQ0Q7QUFUMkMsU0FBOUM7QUFXRDs7QUFFRDs7Ozs7QUF4Ulc7QUFBQTtBQUFBLGdDQTRSRDtBQUNSLGFBQUs4TSxLQUFMO0FBQ0EsYUFBS25aLFFBQUwsQ0FBY3dNLEdBQWQsQ0FBa0IsMkJBQWxCO0FBQ0EsYUFBSzhVLFFBQUwsQ0FBYzlVLEdBQWQsQ0FBa0IsZUFBbEI7O0FBRUExTixtQkFBV3NCLGdCQUFYLENBQTRCLElBQTVCO0FBQ0Q7QUFsU1U7O0FBQUE7QUFBQTs7QUFxU2IwZ0IsWUFBVS9JLFFBQVYsR0FBcUI7QUFDbkI7Ozs7O0FBS0F1RCxrQkFBYyxJQU5LOztBQVFuQjs7Ozs7QUFLQTRGLG9CQUFnQixJQWJHOztBQWVuQjs7Ozs7QUFLQWlCLG1CQUFlLElBcEJJOztBQXNCbkI7Ozs7O0FBS0FQLG9CQUFnQixDQTNCRzs7QUE2Qm5COzs7OztBQUtBWCxnQkFBWSxNQWxDTzs7QUFvQ25COzs7OztBQUtBZSxhQUFTLElBekNVOztBQTJDbkI7Ozs7O0FBS0FULGdCQUFZLEtBaERPOztBQWtEbkI7Ozs7O0FBS0FHLGNBQVUsSUF2RFM7O0FBeURuQjs7Ozs7QUFLQWpELGVBQVcsSUE5RFE7O0FBZ0VuQjs7Ozs7O0FBTUFnRCxpQkFBYSxhQXRFTTs7QUF3RW5COzs7OztBQUtBM1YsZUFBVzs7QUFHYjtBQWhGcUIsR0FBckIsQ0FpRkFoTixXQUFXTSxNQUFYLENBQWtCMGhCLFNBQWxCLEVBQTZCLFdBQTdCO0FBRUMsQ0F4WEEsQ0F3WEN0WixNQXhYRCxDQUFEO0NDRkE7Ozs7OztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYjs7Ozs7Ozs7OztBQUZhLE1BWVB5akIsY0FaTztBQWFYOzs7Ozs7O0FBT0EsNEJBQVl4YSxPQUFaLEVBQXFCa0ssT0FBckIsRUFBOEI7QUFBQTs7QUFDNUIsV0FBSy9SLFFBQUwsR0FBZ0JwQixFQUFFaUosT0FBRixDQUFoQjtBQUNBLFdBQUt5YSxLQUFMLEdBQWEsS0FBS3RpQixRQUFMLENBQWNDLElBQWQsQ0FBbUIsaUJBQW5CLENBQWI7QUFDQSxXQUFLc2lCLFNBQUwsR0FBaUIsSUFBakI7QUFDQSxXQUFLQyxhQUFMLEdBQXFCLElBQXJCOztBQUVBLFdBQUsxaEIsS0FBTDtBQUNBLFdBQUsyWCxPQUFMOztBQUVBM1osaUJBQVdZLGNBQVgsQ0FBMEIsSUFBMUIsRUFBZ0MsZ0JBQWhDO0FBQ0Q7O0FBRUQ7Ozs7Ozs7QUFoQ1c7QUFBQTtBQUFBLDhCQXFDSDtBQUNOO0FBQ0EsWUFBSSxPQUFPLEtBQUs0aUIsS0FBWixLQUFzQixRQUExQixFQUFvQztBQUNsQyxjQUFJRyxZQUFZLEVBQWhCOztBQUVBO0FBQ0EsY0FBSUgsUUFBUSxLQUFLQSxLQUFMLENBQVd6ZixLQUFYLENBQWlCLEdBQWpCLENBQVo7O0FBRUE7QUFDQSxlQUFLLElBQUlSLElBQUksQ0FBYixFQUFnQkEsSUFBSWlnQixNQUFNM2dCLE1BQTFCLEVBQWtDVSxHQUFsQyxFQUF1QztBQUNyQyxnQkFBSXFnQixPQUFPSixNQUFNamdCLENBQU4sRUFBU1EsS0FBVCxDQUFlLEdBQWYsQ0FBWDtBQUNBLGdCQUFJOGYsV0FBV0QsS0FBSy9nQixNQUFMLEdBQWMsQ0FBZCxHQUFrQitnQixLQUFLLENBQUwsQ0FBbEIsR0FBNEIsT0FBM0M7QUFDQSxnQkFBSUUsYUFBYUYsS0FBSy9nQixNQUFMLEdBQWMsQ0FBZCxHQUFrQitnQixLQUFLLENBQUwsQ0FBbEIsR0FBNEJBLEtBQUssQ0FBTCxDQUE3Qzs7QUFFQSxnQkFBSUcsWUFBWUQsVUFBWixNQUE0QixJQUFoQyxFQUFzQztBQUNwQ0gsd0JBQVVFLFFBQVYsSUFBc0JFLFlBQVlELFVBQVosQ0FBdEI7QUFDRDtBQUNGOztBQUVELGVBQUtOLEtBQUwsR0FBYUcsU0FBYjtBQUNEOztBQUVELFlBQUksQ0FBQzdqQixFQUFFa2tCLGFBQUYsQ0FBZ0IsS0FBS1IsS0FBckIsQ0FBTCxFQUFrQztBQUNoQyxlQUFLUyxrQkFBTDtBQUNEO0FBQ0Q7QUFDQSxhQUFLL2lCLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixhQUFuQixFQUFtQyxLQUFLYSxRQUFMLENBQWNiLElBQWQsQ0FBbUIsYUFBbkIsS0FBcUNMLFdBQVdpQixXQUFYLENBQXVCLENBQXZCLEVBQTBCLGlCQUExQixDQUF4RTtBQUNEOztBQUVEOzs7Ozs7QUFsRVc7QUFBQTtBQUFBLGdDQXVFRDtBQUNSLFlBQUlpQixRQUFRLElBQVo7O0FBRUFwQyxVQUFFMEcsTUFBRixFQUFVNkcsRUFBVixDQUFhLHVCQUFiLEVBQXNDLFlBQVc7QUFDL0NuTCxnQkFBTStoQixrQkFBTjtBQUNELFNBRkQ7QUFHQTtBQUNBO0FBQ0E7QUFDRDs7QUFFRDs7Ozs7O0FBbEZXO0FBQUE7QUFBQSwyQ0F1RlU7QUFDbkIsWUFBSUMsU0FBSjtBQUFBLFlBQWVoaUIsUUFBUSxJQUF2QjtBQUNBO0FBQ0FwQyxVQUFFaUMsSUFBRixDQUFPLEtBQUt5aEIsS0FBWixFQUFtQixVQUFTalksR0FBVCxFQUFjO0FBQy9CLGNBQUl2TCxXQUFXZ0csVUFBWCxDQUFzQjZJLE9BQXRCLENBQThCdEQsR0FBOUIsQ0FBSixFQUF3QztBQUN0QzJZLHdCQUFZM1ksR0FBWjtBQUNEO0FBQ0YsU0FKRDs7QUFNQTtBQUNBLFlBQUksQ0FBQzJZLFNBQUwsRUFBZ0I7O0FBRWhCO0FBQ0EsWUFBSSxLQUFLUixhQUFMLFlBQThCLEtBQUtGLEtBQUwsQ0FBV1UsU0FBWCxFQUFzQjVqQixNQUF4RCxFQUFnRTs7QUFFaEU7QUFDQVIsVUFBRWlDLElBQUYsQ0FBT2dpQixXQUFQLEVBQW9CLFVBQVN4WSxHQUFULEVBQWNtRCxLQUFkLEVBQXFCO0FBQ3ZDeE0sZ0JBQU1oQixRQUFOLENBQWU2RSxXQUFmLENBQTJCMkksTUFBTXlWLFFBQWpDO0FBQ0QsU0FGRDs7QUFJQTtBQUNBLGFBQUtqakIsUUFBTCxDQUFjNFEsUUFBZCxDQUF1QixLQUFLMFIsS0FBTCxDQUFXVSxTQUFYLEVBQXNCQyxRQUE3Qzs7QUFFQTtBQUNBLFlBQUksS0FBS1QsYUFBVCxFQUF3QixLQUFLQSxhQUFMLENBQW1CVSxPQUFuQjtBQUN4QixhQUFLVixhQUFMLEdBQXFCLElBQUksS0FBS0YsS0FBTCxDQUFXVSxTQUFYLEVBQXNCNWpCLE1BQTFCLENBQWlDLEtBQUtZLFFBQXRDLEVBQWdELEVBQWhELENBQXJCO0FBQ0Q7O0FBRUQ7Ozs7O0FBbkhXO0FBQUE7QUFBQSxnQ0F1SEQ7QUFDUixhQUFLd2lCLGFBQUwsQ0FBbUJVLE9BQW5CO0FBQ0F0a0IsVUFBRTBHLE1BQUYsRUFBVWtILEdBQVYsQ0FBYyxvQkFBZDtBQUNBMU4sbUJBQVdzQixnQkFBWCxDQUE0QixJQUE1QjtBQUNEO0FBM0hVOztBQUFBO0FBQUE7O0FBOEhiaWlCLGlCQUFldEssUUFBZixHQUEwQixFQUExQjs7QUFFQTtBQUNBLE1BQUk4SyxjQUFjO0FBQ2hCTSxjQUFVO0FBQ1JGLGdCQUFVLFVBREY7QUFFUjdqQixjQUFRTixXQUFXRSxRQUFYLENBQW9CLGVBQXBCLEtBQXdDO0FBRnhDLEtBRE07QUFLakJva0IsZUFBVztBQUNSSCxnQkFBVSxXQURGO0FBRVI3akIsY0FBUU4sV0FBV0UsUUFBWCxDQUFvQixXQUFwQixLQUFvQztBQUZwQyxLQUxNO0FBU2hCcWtCLGVBQVc7QUFDVEosZ0JBQVUsZ0JBREQ7QUFFVDdqQixjQUFRTixXQUFXRSxRQUFYLENBQW9CLGdCQUFwQixLQUF5QztBQUZ4QztBQVRLLEdBQWxCOztBQWVBO0FBQ0FGLGFBQVdNLE1BQVgsQ0FBa0JpakIsY0FBbEIsRUFBa0MsZ0JBQWxDO0FBRUMsQ0FuSkEsQ0FtSkM3YSxNQW5KRCxDQUFEO0NDRkE7Ozs7OztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYjs7Ozs7O0FBRmEsTUFRUDBrQixnQkFSTztBQVNYOzs7Ozs7O0FBT0EsOEJBQVl6YixPQUFaLEVBQXFCa0ssT0FBckIsRUFBOEI7QUFBQTs7QUFDNUIsV0FBSy9SLFFBQUwsR0FBZ0JwQixFQUFFaUosT0FBRixDQUFoQjtBQUNBLFdBQUtrSyxPQUFMLEdBQWVuVCxFQUFFeU0sTUFBRixDQUFTLEVBQVQsRUFBYWlZLGlCQUFpQnZMLFFBQTlCLEVBQXdDLEtBQUsvWCxRQUFMLENBQWNDLElBQWQsRUFBeEMsRUFBOEQ4UixPQUE5RCxDQUFmOztBQUVBLFdBQUtqUixLQUFMO0FBQ0EsV0FBSzJYLE9BQUw7O0FBRUEzWixpQkFBV1ksY0FBWCxDQUEwQixJQUExQixFQUFnQyxrQkFBaEM7QUFDRDs7QUFFRDs7Ozs7OztBQTFCVztBQUFBO0FBQUEsOEJBK0JIO0FBQ04sWUFBSTZqQixXQUFXLEtBQUt2akIsUUFBTCxDQUFjQyxJQUFkLENBQW1CLG1CQUFuQixDQUFmO0FBQ0EsWUFBSSxDQUFDc2pCLFFBQUwsRUFBZTtBQUNiOWhCLGtCQUFRQyxLQUFSLENBQWMsa0VBQWQ7QUFDRDs7QUFFRCxhQUFLOGhCLFdBQUwsR0FBbUI1a0IsUUFBTTJrQixRQUFOLENBQW5CO0FBQ0EsYUFBS0UsUUFBTCxHQUFnQixLQUFLempCLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsZUFBbkIsQ0FBaEI7QUFDQSxhQUFLd1AsT0FBTCxHQUFlblQsRUFBRXlNLE1BQUYsQ0FBUyxFQUFULEVBQWEsS0FBSzBHLE9BQWxCLEVBQTJCLEtBQUt5UixXQUFMLENBQWlCdmpCLElBQWpCLEVBQTNCLENBQWY7O0FBRUE7QUFDQSxZQUFHLEtBQUs4UixPQUFMLENBQWEvQixPQUFoQixFQUF5QjtBQUN2QixjQUFJMFQsUUFBUSxLQUFLM1IsT0FBTCxDQUFhL0IsT0FBYixDQUFxQm5OLEtBQXJCLENBQTJCLEdBQTNCLENBQVo7O0FBRUEsZUFBSzhnQixXQUFMLEdBQW1CRCxNQUFNLENBQU4sQ0FBbkI7QUFDQSxlQUFLRSxZQUFMLEdBQW9CRixNQUFNLENBQU4sS0FBWSxJQUFoQztBQUNEOztBQUVELGFBQUtHLE9BQUw7QUFDRDs7QUFFRDs7Ozs7O0FBcERXO0FBQUE7QUFBQSxnQ0F5REQ7QUFDUixZQUFJN2lCLFFBQVEsSUFBWjs7QUFFQSxhQUFLOGlCLGdCQUFMLEdBQXdCLEtBQUtELE9BQUwsQ0FBYW5kLElBQWIsQ0FBa0IsSUFBbEIsQ0FBeEI7O0FBRUE5SCxVQUFFMEcsTUFBRixFQUFVNkcsRUFBVixDQUFhLHVCQUFiLEVBQXNDLEtBQUsyWCxnQkFBM0M7O0FBRUEsYUFBS0wsUUFBTCxDQUFjdFgsRUFBZCxDQUFpQiwyQkFBakIsRUFBOEMsS0FBSzRYLFVBQUwsQ0FBZ0JyZCxJQUFoQixDQUFxQixJQUFyQixDQUE5QztBQUNEOztBQUVEOzs7Ozs7QUFuRVc7QUFBQTtBQUFBLGdDQXdFRDtBQUNSO0FBQ0EsWUFBSSxDQUFDNUgsV0FBV2dHLFVBQVgsQ0FBc0I2SSxPQUF0QixDQUE4QixLQUFLb0UsT0FBTCxDQUFhaVMsT0FBM0MsQ0FBTCxFQUEwRDtBQUN4RCxlQUFLaGtCLFFBQUwsQ0FBYzZRLElBQWQ7QUFDQSxlQUFLMlMsV0FBTCxDQUFpQnZTLElBQWpCO0FBQ0Q7O0FBRUQ7QUFMQSxhQU1LO0FBQ0gsaUJBQUtqUixRQUFMLENBQWNpUixJQUFkO0FBQ0EsaUJBQUt1UyxXQUFMLENBQWlCM1MsSUFBakI7QUFDRDtBQUNGOztBQUVEOzs7Ozs7QUF0Rlc7QUFBQTtBQUFBLG1DQTJGRTtBQUFBOztBQUNYLFlBQUksQ0FBQy9SLFdBQVdnRyxVQUFYLENBQXNCNkksT0FBdEIsQ0FBOEIsS0FBS29FLE9BQUwsQ0FBYWlTLE9BQTNDLENBQUwsRUFBMEQ7QUFDeEQsY0FBRyxLQUFLalMsT0FBTCxDQUFhL0IsT0FBaEIsRUFBeUI7QUFDdkIsZ0JBQUksS0FBS3dULFdBQUwsQ0FBaUI3WCxFQUFqQixDQUFvQixTQUFwQixDQUFKLEVBQW9DO0FBQ2xDN00seUJBQVc4USxNQUFYLENBQWtCQyxTQUFsQixDQUE0QixLQUFLMlQsV0FBakMsRUFBOEMsS0FBS0csV0FBbkQsRUFBZ0UsWUFBTTtBQUNwRTs7OztBQUlBLHVCQUFLM2pCLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQiw2QkFBdEI7QUFDQSx1QkFBS3NqQixXQUFMLENBQWlCamhCLElBQWpCLENBQXNCLGVBQXRCLEVBQXVDdUIsY0FBdkMsQ0FBc0QscUJBQXREO0FBQ0QsZUFQRDtBQVFELGFBVEQsTUFVSztBQUNIaEYseUJBQVc4USxNQUFYLENBQWtCSyxVQUFsQixDQUE2QixLQUFLdVQsV0FBbEMsRUFBK0MsS0FBS0ksWUFBcEQsRUFBa0UsWUFBTTtBQUN0RTs7OztBQUlBLHVCQUFLNWpCLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQiw2QkFBdEI7QUFDRCxlQU5EO0FBT0Q7QUFDRixXQXBCRCxNQXFCSztBQUNILGlCQUFLc2pCLFdBQUwsQ0FBaUI3SyxNQUFqQixDQUF3QixDQUF4QjtBQUNBLGlCQUFLNkssV0FBTCxDQUFpQmpoQixJQUFqQixDQUFzQixlQUF0QixFQUF1Q3JDLE9BQXZDLENBQStDLHFCQUEvQzs7QUFFQTs7OztBQUlBLGlCQUFLRixRQUFMLENBQWNFLE9BQWQsQ0FBc0IsNkJBQXRCO0FBQ0Q7QUFDRjtBQUNGO0FBN0hVO0FBQUE7QUFBQSxnQ0ErSEQ7QUFDUixhQUFLRixRQUFMLENBQWN3TSxHQUFkLENBQWtCLHNCQUFsQjtBQUNBLGFBQUtpWCxRQUFMLENBQWNqWCxHQUFkLENBQWtCLHNCQUFsQjs7QUFFQTVOLFVBQUUwRyxNQUFGLEVBQVVrSCxHQUFWLENBQWMsdUJBQWQsRUFBdUMsS0FBS3NYLGdCQUE1Qzs7QUFFQWhsQixtQkFBV3NCLGdCQUFYLENBQTRCLElBQTVCO0FBQ0Q7QUF0SVU7O0FBQUE7QUFBQTs7QUF5SWJrakIsbUJBQWlCdkwsUUFBakIsR0FBNEI7QUFDMUI7Ozs7O0FBS0FpTSxhQUFTLFFBTmlCOztBQVExQjs7Ozs7QUFLQWhVLGFBQVM7QUFiaUIsR0FBNUI7O0FBZ0JBO0FBQ0FsUixhQUFXTSxNQUFYLENBQWtCa2tCLGdCQUFsQixFQUFvQyxrQkFBcEM7QUFFQyxDQTVKQSxDQTRKQzliLE1BNUpELENBQUQ7Q0NGQTs7Ozs7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViOzs7Ozs7O0FBRmEsTUFTUHFsQixPQVRPO0FBVVg7Ozs7Ozs7QUFPQSxxQkFBWXBjLE9BQVosRUFBcUJrSyxPQUFyQixFQUE4QjtBQUFBOztBQUM1QixXQUFLL1IsUUFBTCxHQUFnQjZILE9BQWhCO0FBQ0EsV0FBS2tLLE9BQUwsR0FBZW5ULEVBQUV5TSxNQUFGLENBQVMsRUFBVCxFQUFhNFksUUFBUWxNLFFBQXJCLEVBQStCbFEsUUFBUTVILElBQVIsRUFBL0IsRUFBK0M4UixPQUEvQyxDQUFmO0FBQ0EsV0FBS3pTLFNBQUwsR0FBaUIsRUFBakI7O0FBRUEsV0FBS3dCLEtBQUw7QUFDQSxXQUFLMlgsT0FBTDs7QUFFQTNaLGlCQUFXWSxjQUFYLENBQTBCLElBQTFCLEVBQWdDLFNBQWhDO0FBQ0Q7O0FBRUQ7Ozs7Ozs7QUE1Qlc7QUFBQTtBQUFBLDhCQWlDSDtBQUNOLFlBQUlna0IsS0FBSjtBQUNBO0FBQ0EsWUFBSSxLQUFLM1IsT0FBTCxDQUFhL0IsT0FBakIsRUFBMEI7QUFDeEIwVCxrQkFBUSxLQUFLM1IsT0FBTCxDQUFhL0IsT0FBYixDQUFxQm5OLEtBQXJCLENBQTJCLEdBQTNCLENBQVI7O0FBRUEsZUFBSzhnQixXQUFMLEdBQW1CRCxNQUFNLENBQU4sQ0FBbkI7QUFDQSxlQUFLRSxZQUFMLEdBQW9CRixNQUFNLENBQU4sS0FBWSxJQUFoQztBQUNEO0FBQ0Q7QUFOQSxhQU9LO0FBQ0hBLG9CQUFRLEtBQUsxakIsUUFBTCxDQUFjQyxJQUFkLENBQW1CLFNBQW5CLENBQVI7QUFDQTtBQUNBLGlCQUFLWCxTQUFMLEdBQWlCb2tCLE1BQU0sQ0FBTixNQUFhLEdBQWIsR0FBbUJBLE1BQU14aEIsS0FBTixDQUFZLENBQVosQ0FBbkIsR0FBb0N3aEIsS0FBckQ7QUFDRDs7QUFFRDtBQUNBLFlBQUlqVixLQUFLLEtBQUt6TyxRQUFMLENBQWMsQ0FBZCxFQUFpQnlPLEVBQTFCO0FBQ0E3UCwyQkFBaUI2UCxFQUFqQix5QkFBdUNBLEVBQXZDLDBCQUE4REEsRUFBOUQsU0FDR3RQLElBREgsQ0FDUSxlQURSLEVBQ3lCc1AsRUFEekI7QUFFQTtBQUNBLGFBQUt6TyxRQUFMLENBQWNiLElBQWQsQ0FBbUIsZUFBbkIsRUFBb0MsS0FBS2EsUUFBTCxDQUFjMkwsRUFBZCxDQUFpQixTQUFqQixJQUE4QixLQUE5QixHQUFzQyxJQUExRTtBQUNEOztBQUVEOzs7Ozs7QUF6RFc7QUFBQTtBQUFBLGdDQThERDtBQUNSLGFBQUszTCxRQUFMLENBQWN3TSxHQUFkLENBQWtCLG1CQUFsQixFQUF1Q0wsRUFBdkMsQ0FBMEMsbUJBQTFDLEVBQStELEtBQUt3TSxNQUFMLENBQVlqUyxJQUFaLENBQWlCLElBQWpCLENBQS9EO0FBQ0Q7O0FBRUQ7Ozs7Ozs7QUFsRVc7QUFBQTtBQUFBLCtCQXdFRjtBQUNQLGFBQU0sS0FBS3FMLE9BQUwsQ0FBYS9CLE9BQWIsR0FBdUIsZ0JBQXZCLEdBQTBDLGNBQWhEO0FBQ0Q7QUExRVU7QUFBQTtBQUFBLHFDQTRFSTtBQUNiLGFBQUtoUSxRQUFMLENBQWNra0IsV0FBZCxDQUEwQixLQUFLNWtCLFNBQS9COztBQUVBLFlBQUk2a0IsT0FBTyxLQUFLbmtCLFFBQUwsQ0FBY3NZLFFBQWQsQ0FBdUIsS0FBS2haLFNBQTVCLENBQVg7QUFDQSxZQUFJNmtCLElBQUosRUFBVTtBQUNSOzs7O0FBSUEsZUFBS25rQixRQUFMLENBQWNFLE9BQWQsQ0FBc0IsZUFBdEI7QUFDRCxTQU5ELE1BT0s7QUFDSDs7OztBQUlBLGVBQUtGLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQixnQkFBdEI7QUFDRDs7QUFFRCxhQUFLa2tCLFdBQUwsQ0FBaUJELElBQWpCO0FBQ0EsYUFBS25rQixRQUFMLENBQWN1QyxJQUFkLENBQW1CLGVBQW5CLEVBQW9DckMsT0FBcEMsQ0FBNEMscUJBQTVDO0FBQ0Q7QUFqR1U7QUFBQTtBQUFBLHVDQW1HTTtBQUNmLFlBQUljLFFBQVEsSUFBWjs7QUFFQSxZQUFJLEtBQUtoQixRQUFMLENBQWMyTCxFQUFkLENBQWlCLFNBQWpCLENBQUosRUFBaUM7QUFDL0I3TSxxQkFBVzhRLE1BQVgsQ0FBa0JDLFNBQWxCLENBQTRCLEtBQUs3UCxRQUFqQyxFQUEyQyxLQUFLMmpCLFdBQWhELEVBQTZELFlBQVc7QUFDdEUzaUIsa0JBQU1vakIsV0FBTixDQUFrQixJQUFsQjtBQUNBLGlCQUFLbGtCLE9BQUwsQ0FBYSxlQUFiO0FBQ0EsaUJBQUtxQyxJQUFMLENBQVUsZUFBVixFQUEyQnJDLE9BQTNCLENBQW1DLHFCQUFuQztBQUNELFdBSkQ7QUFLRCxTQU5ELE1BT0s7QUFDSHBCLHFCQUFXOFEsTUFBWCxDQUFrQkssVUFBbEIsQ0FBNkIsS0FBS2pRLFFBQWxDLEVBQTRDLEtBQUs0akIsWUFBakQsRUFBK0QsWUFBVztBQUN4RTVpQixrQkFBTW9qQixXQUFOLENBQWtCLEtBQWxCO0FBQ0EsaUJBQUtsa0IsT0FBTCxDQUFhLGdCQUFiO0FBQ0EsaUJBQUtxQyxJQUFMLENBQVUsZUFBVixFQUEyQnJDLE9BQTNCLENBQW1DLHFCQUFuQztBQUNELFdBSkQ7QUFLRDtBQUNGO0FBcEhVO0FBQUE7QUFBQSxrQ0FzSENpa0IsSUF0SEQsRUFzSE87QUFDaEIsYUFBS25rQixRQUFMLENBQWNiLElBQWQsQ0FBbUIsZUFBbkIsRUFBb0NnbEIsT0FBTyxJQUFQLEdBQWMsS0FBbEQ7QUFDRDs7QUFFRDs7Ozs7QUExSFc7QUFBQTtBQUFBLGdDQThIRDtBQUNSLGFBQUtua0IsUUFBTCxDQUFjd00sR0FBZCxDQUFrQixhQUFsQjtBQUNBMU4sbUJBQVdzQixnQkFBWCxDQUE0QixJQUE1QjtBQUNEO0FBaklVOztBQUFBO0FBQUE7O0FBb0liNmpCLFVBQVFsTSxRQUFSLEdBQW1CO0FBQ2pCOzs7OztBQUtBL0gsYUFBUztBQU5RLEdBQW5COztBQVNBO0FBQ0FsUixhQUFXTSxNQUFYLENBQWtCNmtCLE9BQWxCLEVBQTJCLFNBQTNCO0FBRUMsQ0FoSkEsQ0FnSkN6YyxNQWhKRCxDQUFEO0NDRkE7Ozs7OztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYjs7Ozs7Ozs7QUFGYSxNQVVQeWxCLE9BVk87QUFXWDs7Ozs7OztBQU9BLHFCQUFZeGMsT0FBWixFQUFxQmtLLE9BQXJCLEVBQThCO0FBQUE7O0FBQzVCLFdBQUsvUixRQUFMLEdBQWdCNkgsT0FBaEI7QUFDQSxXQUFLa0ssT0FBTCxHQUFlblQsRUFBRXlNLE1BQUYsQ0FBUyxFQUFULEVBQWFnWixRQUFRdE0sUUFBckIsRUFBK0IsS0FBSy9YLFFBQUwsQ0FBY0MsSUFBZCxFQUEvQixFQUFxRDhSLE9BQXJELENBQWY7O0FBRUEsV0FBS3NHLFFBQUwsR0FBZ0IsS0FBaEI7QUFDQSxXQUFLaU0sT0FBTCxHQUFlLEtBQWY7QUFDQSxXQUFLeGpCLEtBQUw7O0FBRUFoQyxpQkFBV1ksY0FBWCxDQUEwQixJQUExQixFQUFnQyxTQUFoQztBQUNEOztBQUVEOzs7Ozs7QUE3Qlc7QUFBQTtBQUFBLDhCQWlDSDtBQUNOLFlBQUk2a0IsU0FBUyxLQUFLdmtCLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixrQkFBbkIsS0FBMENMLFdBQVdpQixXQUFYLENBQXVCLENBQXZCLEVBQTBCLFNBQTFCLENBQXZEOztBQUVBLGFBQUtnUyxPQUFMLENBQWFxTCxhQUFiLEdBQTZCLEtBQUtyTCxPQUFMLENBQWFxTCxhQUFiLElBQThCLEtBQUtvSCxpQkFBTCxDQUF1QixLQUFLeGtCLFFBQTVCLENBQTNEO0FBQ0EsYUFBSytSLE9BQUwsQ0FBYTBTLE9BQWIsR0FBdUIsS0FBSzFTLE9BQUwsQ0FBYTBTLE9BQWIsSUFBd0IsS0FBS3prQixRQUFMLENBQWNiLElBQWQsQ0FBbUIsT0FBbkIsQ0FBL0M7QUFDQSxhQUFLdWxCLFFBQUwsR0FBZ0IsS0FBSzNTLE9BQUwsQ0FBYTJTLFFBQWIsR0FBd0I5bEIsRUFBRSxLQUFLbVQsT0FBTCxDQUFhMlMsUUFBZixDQUF4QixHQUFtRCxLQUFLQyxjQUFMLENBQW9CSixNQUFwQixDQUFuRTs7QUFFQSxZQUFJLEtBQUt4UyxPQUFMLENBQWE2UyxTQUFqQixFQUE0QjtBQUMxQixlQUFLRixRQUFMLENBQWMvZixRQUFkLENBQXVCbkIsU0FBUzBGLElBQWhDLEVBQ0cyYixJQURILENBQ1EsS0FBSzlTLE9BQUwsQ0FBYTBTLE9BRHJCLEVBRUd4VCxJQUZIO0FBR0QsU0FKRCxNQUlPO0FBQ0wsZUFBS3lULFFBQUwsQ0FBYy9mLFFBQWQsQ0FBdUJuQixTQUFTMEYsSUFBaEMsRUFDRzRGLElBREgsQ0FDUSxLQUFLaUQsT0FBTCxDQUFhMFMsT0FEckIsRUFFR3hULElBRkg7QUFHRDs7QUFFRCxhQUFLalIsUUFBTCxDQUFjYixJQUFkLENBQW1CO0FBQ2pCLG1CQUFTLEVBRFE7QUFFakIsOEJBQW9Cb2xCLE1BRkg7QUFHakIsMkJBQWlCQSxNQUhBO0FBSWpCLHlCQUFlQSxNQUpFO0FBS2pCLHlCQUFlQTtBQUxFLFNBQW5CLEVBTUczVCxRQU5ILENBTVksS0FBS21CLE9BQUwsQ0FBYStTLFlBTnpCOztBQVFBO0FBQ0EsYUFBS3ZILGFBQUwsR0FBcUIsRUFBckI7QUFDQSxhQUFLRCxPQUFMLEdBQWUsQ0FBZjtBQUNBLGFBQUtLLFlBQUwsR0FBb0IsS0FBcEI7O0FBRUEsYUFBS2xGLE9BQUw7QUFDRDs7QUFFRDs7Ozs7QUFsRVc7QUFBQTtBQUFBLHdDQXNFTzVRLE9BdEVQLEVBc0VnQjtBQUN6QixZQUFJLENBQUNBLE9BQUwsRUFBYztBQUFFLGlCQUFPLEVBQVA7QUFBWTtBQUM1QjtBQUNBLFlBQUk0QixXQUFXNUIsUUFBUSxDQUFSLEVBQVd2SSxTQUFYLENBQXFCbWUsS0FBckIsQ0FBMkIsdUJBQTNCLENBQWY7QUFDSWhVLG1CQUFXQSxXQUFXQSxTQUFTLENBQVQsQ0FBWCxHQUF5QixFQUFwQztBQUNKLGVBQU9BLFFBQVA7QUFDRDtBQTVFVTtBQUFBOztBQTZFWDs7OztBQTdFVyxxQ0FpRklnRixFQWpGSixFQWlGUTtBQUNqQixZQUFJc1csa0JBQWtCLENBQUksS0FBS2hULE9BQUwsQ0FBYWlULFlBQWpCLFNBQWlDLEtBQUtqVCxPQUFMLENBQWFxTCxhQUE5QyxTQUErRCxLQUFLckwsT0FBTCxDQUFhZ1QsZUFBNUUsRUFBK0Y3aEIsSUFBL0YsRUFBdEI7QUFDQSxZQUFJK2hCLFlBQWFybUIsRUFBRSxhQUFGLEVBQWlCZ1MsUUFBakIsQ0FBMEJtVSxlQUExQixFQUEyQzVsQixJQUEzQyxDQUFnRDtBQUMvRCxrQkFBUSxTQUR1RDtBQUUvRCx5QkFBZSxJQUZnRDtBQUcvRCw0QkFBa0IsS0FINkM7QUFJL0QsMkJBQWlCLEtBSjhDO0FBSy9ELGdCQUFNc1A7QUFMeUQsU0FBaEQsQ0FBakI7QUFPQSxlQUFPd1csU0FBUDtBQUNEOztBQUVEOzs7Ozs7QUE3Rlc7QUFBQTtBQUFBLGtDQWtHQ3hiLFFBbEdELEVBa0dXO0FBQ3BCLGFBQUs4VCxhQUFMLENBQW1CcGQsSUFBbkIsQ0FBd0JzSixXQUFXQSxRQUFYLEdBQXNCLFFBQTlDOztBQUVBO0FBQ0EsWUFBSSxDQUFDQSxRQUFELElBQWMsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixLQUEzQixJQUFvQyxDQUF0RCxFQUEwRDtBQUN4RCxlQUFLb2tCLFFBQUwsQ0FBYzlULFFBQWQsQ0FBdUIsS0FBdkI7QUFDRCxTQUZELE1BRU8sSUFBSW5ILGFBQWEsS0FBYixJQUF1QixLQUFLOFQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLFFBQTNCLElBQXVDLENBQWxFLEVBQXNFO0FBQzNFLGVBQUtva0IsUUFBTCxDQUFjN2YsV0FBZCxDQUEwQjRFLFFBQTFCO0FBQ0QsU0FGTSxNQUVBLElBQUlBLGFBQWEsTUFBYixJQUF3QixLQUFLOFQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLE9BQTNCLElBQXNDLENBQWxFLEVBQXNFO0FBQzNFLGVBQUtva0IsUUFBTCxDQUFjN2YsV0FBZCxDQUEwQjRFLFFBQTFCLEVBQ0ttSCxRQURMLENBQ2MsT0FEZDtBQUVELFNBSE0sTUFHQSxJQUFJbkgsYUFBYSxPQUFiLElBQXlCLEtBQUs4VCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsTUFBM0IsSUFBcUMsQ0FBbEUsRUFBc0U7QUFDM0UsZUFBS29rQixRQUFMLENBQWM3ZixXQUFkLENBQTBCNEUsUUFBMUIsRUFDS21ILFFBREwsQ0FDYyxNQURkO0FBRUQ7O0FBRUQ7QUFMTyxhQU1GLElBQUksQ0FBQ25ILFFBQUQsSUFBYyxLQUFLOFQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLEtBQTNCLElBQW9DLENBQUMsQ0FBbkQsSUFBMEQsS0FBS2lkLGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixNQUEzQixJQUFxQyxDQUFuRyxFQUF1RztBQUMxRyxpQkFBS29rQixRQUFMLENBQWM5VCxRQUFkLENBQXVCLE1BQXZCO0FBQ0QsV0FGSSxNQUVFLElBQUluSCxhQUFhLEtBQWIsSUFBdUIsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixRQUEzQixJQUF1QyxDQUFDLENBQS9ELElBQXNFLEtBQUtpZCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsTUFBM0IsSUFBcUMsQ0FBL0csRUFBbUg7QUFDeEgsaUJBQUtva0IsUUFBTCxDQUFjN2YsV0FBZCxDQUEwQjRFLFFBQTFCLEVBQ0ttSCxRQURMLENBQ2MsTUFEZDtBQUVELFdBSE0sTUFHQSxJQUFJbkgsYUFBYSxNQUFiLElBQXdCLEtBQUs4VCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsT0FBM0IsSUFBc0MsQ0FBQyxDQUEvRCxJQUFzRSxLQUFLaWQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLFFBQTNCLElBQXVDLENBQWpILEVBQXFIO0FBQzFILGlCQUFLb2tCLFFBQUwsQ0FBYzdmLFdBQWQsQ0FBMEI0RSxRQUExQjtBQUNELFdBRk0sTUFFQSxJQUFJQSxhQUFhLE9BQWIsSUFBeUIsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixNQUEzQixJQUFxQyxDQUFDLENBQS9ELElBQXNFLEtBQUtpZCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsUUFBM0IsSUFBdUMsQ0FBakgsRUFBcUg7QUFDMUgsaUJBQUtva0IsUUFBTCxDQUFjN2YsV0FBZCxDQUEwQjRFLFFBQTFCO0FBQ0Q7QUFDRDtBQUhPLGVBSUY7QUFDSCxtQkFBS2liLFFBQUwsQ0FBYzdmLFdBQWQsQ0FBMEI0RSxRQUExQjtBQUNEO0FBQ0QsYUFBS2tVLFlBQUwsR0FBb0IsSUFBcEI7QUFDQSxhQUFLTCxPQUFMO0FBQ0Q7O0FBRUQ7Ozs7OztBQXJJVztBQUFBO0FBQUEscUNBMElJO0FBQ2IsWUFBSTdULFdBQVcsS0FBSythLGlCQUFMLENBQXVCLEtBQUtFLFFBQTVCLENBQWY7QUFBQSxZQUNJUSxXQUFXcG1CLFdBQVcySSxHQUFYLENBQWVFLGFBQWYsQ0FBNkIsS0FBSytjLFFBQWxDLENBRGY7QUFBQSxZQUVJNWEsY0FBY2hMLFdBQVcySSxHQUFYLENBQWVFLGFBQWYsQ0FBNkIsS0FBSzNILFFBQWxDLENBRmxCO0FBQUEsWUFHSTRkLFlBQWFuVSxhQUFhLE1BQWIsR0FBc0IsTUFBdEIsR0FBaUNBLGFBQWEsT0FBZCxHQUF5QixNQUF6QixHQUFrQyxLQUhuRjtBQUFBLFlBSUk0RixRQUFTdU8sY0FBYyxLQUFmLEdBQXdCLFFBQXhCLEdBQW1DLE9BSi9DO0FBQUEsWUFLSXJWLFNBQVU4RyxVQUFVLFFBQVgsR0FBdUIsS0FBSzBDLE9BQUwsQ0FBYXJJLE9BQXBDLEdBQThDLEtBQUtxSSxPQUFMLENBQWFwSSxPQUx4RTtBQUFBLFlBTUkzSSxRQUFRLElBTlo7O0FBUUEsWUFBS2trQixTQUFTemMsS0FBVCxJQUFrQnljLFNBQVN4YyxVQUFULENBQW9CRCxLQUF2QyxJQUFrRCxDQUFDLEtBQUs2VSxPQUFOLElBQWlCLENBQUN4ZSxXQUFXMkksR0FBWCxDQUFlQyxnQkFBZixDQUFnQyxLQUFLZ2QsUUFBckMsQ0FBeEUsRUFBeUg7QUFDdkgsZUFBS0EsUUFBTCxDQUFjbmMsTUFBZCxDQUFxQnpKLFdBQVcySSxHQUFYLENBQWVHLFVBQWYsQ0FBMEIsS0FBSzhjLFFBQS9CLEVBQXlDLEtBQUsxa0IsUUFBOUMsRUFBd0QsZUFBeEQsRUFBeUUsS0FBSytSLE9BQUwsQ0FBYXJJLE9BQXRGLEVBQStGLEtBQUtxSSxPQUFMLENBQWFwSSxPQUE1RyxFQUFxSCxJQUFySCxDQUFyQixFQUFpSnlELEdBQWpKLENBQXFKO0FBQ3JKO0FBQ0UscUJBQVN0RCxZQUFZcEIsVUFBWixDQUF1QkQsS0FBdkIsR0FBZ0MsS0FBS3NKLE9BQUwsQ0FBYXBJLE9BQWIsR0FBdUIsQ0FGbUY7QUFHbkosc0JBQVU7QUFIeUksV0FBcko7QUFLQSxpQkFBTyxLQUFQO0FBQ0Q7O0FBRUQsYUFBSythLFFBQUwsQ0FBY25jLE1BQWQsQ0FBcUJ6SixXQUFXMkksR0FBWCxDQUFlRyxVQUFmLENBQTBCLEtBQUs4YyxRQUEvQixFQUF5QyxLQUFLMWtCLFFBQTlDLEVBQXVELGFBQWF5SixZQUFZLFFBQXpCLENBQXZELEVBQTJGLEtBQUtzSSxPQUFMLENBQWFySSxPQUF4RyxFQUFpSCxLQUFLcUksT0FBTCxDQUFhcEksT0FBOUgsQ0FBckI7O0FBRUEsZUFBTSxDQUFDN0ssV0FBVzJJLEdBQVgsQ0FBZUMsZ0JBQWYsQ0FBZ0MsS0FBS2dkLFFBQXJDLENBQUQsSUFBbUQsS0FBS3BILE9BQTlELEVBQXVFO0FBQ3JFLGVBQUtVLFdBQUwsQ0FBaUJ2VSxRQUFqQjtBQUNBLGVBQUt3VSxZQUFMO0FBQ0Q7QUFDRjs7QUFFRDs7Ozs7OztBQXBLVztBQUFBO0FBQUEsNkJBMEtKO0FBQ0wsWUFBSSxLQUFLbE0sT0FBTCxDQUFhb1QsTUFBYixLQUF3QixLQUF4QixJQUFpQyxDQUFDcm1CLFdBQVdnRyxVQUFYLENBQXNCNkcsRUFBdEIsQ0FBeUIsS0FBS29HLE9BQUwsQ0FBYW9ULE1BQXRDLENBQXRDLEVBQXFGO0FBQ25GO0FBQ0EsaUJBQU8sS0FBUDtBQUNEOztBQUVELFlBQUlua0IsUUFBUSxJQUFaO0FBQ0EsYUFBSzBqQixRQUFMLENBQWN0WCxHQUFkLENBQWtCLFlBQWxCLEVBQWdDLFFBQWhDLEVBQTBDeUQsSUFBMUM7QUFDQSxhQUFLb04sWUFBTDs7QUFFQTs7OztBQUlBLGFBQUtqZSxRQUFMLENBQWNFLE9BQWQsQ0FBc0Isb0JBQXRCLEVBQTRDLEtBQUt3a0IsUUFBTCxDQUFjdmxCLElBQWQsQ0FBbUIsSUFBbkIsQ0FBNUM7O0FBR0EsYUFBS3VsQixRQUFMLENBQWN2bEIsSUFBZCxDQUFtQjtBQUNqQiw0QkFBa0IsSUFERDtBQUVqQix5QkFBZTtBQUZFLFNBQW5CO0FBSUE2QixjQUFNcVgsUUFBTixHQUFpQixJQUFqQjtBQUNBO0FBQ0EsYUFBS3FNLFFBQUwsQ0FBY3ZJLElBQWQsR0FBcUJsTCxJQUFyQixHQUE0QjdELEdBQTVCLENBQWdDLFlBQWhDLEVBQThDLEVBQTlDLEVBQWtEZ1ksTUFBbEQsQ0FBeUQsS0FBS3JULE9BQUwsQ0FBYXNULGNBQXRFLEVBQXNGLFlBQVc7QUFDL0Y7QUFDRCxTQUZEO0FBR0E7Ozs7QUFJQSxhQUFLcmxCLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQixpQkFBdEI7QUFDRDs7QUFFRDs7Ozs7O0FBM01XO0FBQUE7QUFBQSw2QkFnTko7QUFDTDtBQUNBLFlBQUljLFFBQVEsSUFBWjtBQUNBLGFBQUswakIsUUFBTCxDQUFjdkksSUFBZCxHQUFxQmhkLElBQXJCLENBQTBCO0FBQ3hCLHlCQUFlLElBRFM7QUFFeEIsNEJBQWtCO0FBRk0sU0FBMUIsRUFHRzZXLE9BSEgsQ0FHVyxLQUFLakUsT0FBTCxDQUFhdVQsZUFIeEIsRUFHeUMsWUFBVztBQUNsRHRrQixnQkFBTXFYLFFBQU4sR0FBaUIsS0FBakI7QUFDQXJYLGdCQUFNc2pCLE9BQU4sR0FBZ0IsS0FBaEI7QUFDQSxjQUFJdGpCLE1BQU0yYyxZQUFWLEVBQXdCO0FBQ3RCM2Msa0JBQU0wakIsUUFBTixDQUNNN2YsV0FETixDQUNrQjdELE1BQU13akIsaUJBQU4sQ0FBd0J4akIsTUFBTTBqQixRQUE5QixDQURsQixFQUVNOVQsUUFGTixDQUVlNVAsTUFBTStRLE9BQU4sQ0FBY3FMLGFBRjdCOztBQUlEcGMsa0JBQU11YyxhQUFOLEdBQXNCLEVBQXRCO0FBQ0F2YyxrQkFBTXNjLE9BQU4sR0FBZ0IsQ0FBaEI7QUFDQXRjLGtCQUFNMmMsWUFBTixHQUFxQixLQUFyQjtBQUNBO0FBQ0YsU0FmRDtBQWdCQTs7OztBQUlBLGFBQUszZCxRQUFMLENBQWNFLE9BQWQsQ0FBc0IsaUJBQXRCO0FBQ0Q7O0FBRUQ7Ozs7OztBQTFPVztBQUFBO0FBQUEsZ0NBK09EO0FBQ1IsWUFBSWMsUUFBUSxJQUFaO0FBQ0EsWUFBSWlrQixZQUFZLEtBQUtQLFFBQXJCO0FBQ0EsWUFBSWEsVUFBVSxLQUFkOztBQUVBLFlBQUksQ0FBQyxLQUFLeFQsT0FBTCxDQUFhNk4sWUFBbEIsRUFBZ0M7O0FBRTlCLGVBQUs1ZixRQUFMLENBQ0NtTSxFQURELENBQ0ksdUJBREosRUFDNkIsVUFBU3JKLENBQVQsRUFBWTtBQUN2QyxnQkFBSSxDQUFDOUIsTUFBTXFYLFFBQVgsRUFBcUI7QUFDbkJyWCxvQkFBTXFkLE9BQU4sR0FBZ0J4YSxXQUFXLFlBQVc7QUFDcEM3QyxzQkFBTTZQLElBQU47QUFDRCxlQUZlLEVBRWI3UCxNQUFNK1EsT0FBTixDQUFjdU0sVUFGRCxDQUFoQjtBQUdEO0FBQ0YsV0FQRCxFQVFDblMsRUFSRCxDQVFJLHVCQVJKLEVBUTZCLFVBQVNySixDQUFULEVBQVk7QUFDdkN3RCx5QkFBYXRGLE1BQU1xZCxPQUFuQjtBQUNBLGdCQUFJLENBQUNrSCxPQUFELElBQWF2a0IsTUFBTXNqQixPQUFOLElBQWlCLENBQUN0akIsTUFBTStRLE9BQU4sQ0FBYzBOLFNBQWpELEVBQTZEO0FBQzNEemUsb0JBQU1pUSxJQUFOO0FBQ0Q7QUFDRixXQWJEO0FBY0Q7O0FBRUQsWUFBSSxLQUFLYyxPQUFMLENBQWEwTixTQUFqQixFQUE0QjtBQUMxQixlQUFLemYsUUFBTCxDQUFjbU0sRUFBZCxDQUFpQixzQkFBakIsRUFBeUMsVUFBU3JKLENBQVQsRUFBWTtBQUNuREEsY0FBRXlXLHdCQUFGO0FBQ0EsZ0JBQUl2WSxNQUFNc2pCLE9BQVYsRUFBbUI7QUFDakI7QUFDQTtBQUNELGFBSEQsTUFHTztBQUNMdGpCLG9CQUFNc2pCLE9BQU4sR0FBZ0IsSUFBaEI7QUFDQSxrQkFBSSxDQUFDdGpCLE1BQU0rUSxPQUFOLENBQWM2TixZQUFkLElBQThCLENBQUM1ZSxNQUFNaEIsUUFBTixDQUFlYixJQUFmLENBQW9CLFVBQXBCLENBQWhDLEtBQW9FLENBQUM2QixNQUFNcVgsUUFBL0UsRUFBeUY7QUFDdkZyWCxzQkFBTTZQLElBQU47QUFDRDtBQUNGO0FBQ0YsV0FYRDtBQVlELFNBYkQsTUFhTztBQUNMLGVBQUs3USxRQUFMLENBQWNtTSxFQUFkLENBQWlCLHNCQUFqQixFQUF5QyxVQUFTckosQ0FBVCxFQUFZO0FBQ25EQSxjQUFFeVcsd0JBQUY7QUFDQXZZLGtCQUFNc2pCLE9BQU4sR0FBZ0IsSUFBaEI7QUFDRCxXQUhEO0FBSUQ7O0FBRUQsWUFBSSxDQUFDLEtBQUt2UyxPQUFMLENBQWF5VCxlQUFsQixFQUFtQztBQUNqQyxlQUFLeGxCLFFBQUwsQ0FDQ21NLEVBREQsQ0FDSSxvQ0FESixFQUMwQyxVQUFTckosQ0FBVCxFQUFZO0FBQ3BEOUIsa0JBQU1xWCxRQUFOLEdBQWlCclgsTUFBTWlRLElBQU4sRUFBakIsR0FBZ0NqUSxNQUFNNlAsSUFBTixFQUFoQztBQUNELFdBSEQ7QUFJRDs7QUFFRCxhQUFLN1EsUUFBTCxDQUFjbU0sRUFBZCxDQUFpQjtBQUNmO0FBQ0E7QUFDQSw4QkFBb0IsS0FBSzhFLElBQUwsQ0FBVXZLLElBQVYsQ0FBZSxJQUFmO0FBSEwsU0FBakI7O0FBTUEsYUFBSzFHLFFBQUwsQ0FDR21NLEVBREgsQ0FDTSxrQkFETixFQUMwQixVQUFTckosQ0FBVCxFQUFZO0FBQ2xDeWlCLG9CQUFVLElBQVY7QUFDQSxjQUFJdmtCLE1BQU1zakIsT0FBVixFQUFtQjtBQUNqQjtBQUNBO0FBQ0EsZ0JBQUcsQ0FBQ3RqQixNQUFNK1EsT0FBTixDQUFjME4sU0FBbEIsRUFBNkI7QUFBRThGLHdCQUFVLEtBQVY7QUFBa0I7QUFDakQsbUJBQU8sS0FBUDtBQUNELFdBTEQsTUFLTztBQUNMdmtCLGtCQUFNNlAsSUFBTjtBQUNEO0FBQ0YsU0FYSCxFQWFHMUUsRUFiSCxDQWFNLHFCQWJOLEVBYTZCLFVBQVNySixDQUFULEVBQVk7QUFDckN5aUIsb0JBQVUsS0FBVjtBQUNBdmtCLGdCQUFNc2pCLE9BQU4sR0FBZ0IsS0FBaEI7QUFDQXRqQixnQkFBTWlRLElBQU47QUFDRCxTQWpCSCxFQW1CRzlFLEVBbkJILENBbUJNLHFCQW5CTixFQW1CNkIsWUFBVztBQUNwQyxjQUFJbkwsTUFBTXFYLFFBQVYsRUFBb0I7QUFDbEJyWCxrQkFBTWlkLFlBQU47QUFDRDtBQUNGLFNBdkJIO0FBd0JEOztBQUVEOzs7OztBQWpVVztBQUFBO0FBQUEsK0JBcVVGO0FBQ1AsWUFBSSxLQUFLNUYsUUFBVCxFQUFtQjtBQUNqQixlQUFLcEgsSUFBTDtBQUNELFNBRkQsTUFFTztBQUNMLGVBQUtKLElBQUw7QUFDRDtBQUNGOztBQUVEOzs7OztBQTdVVztBQUFBO0FBQUEsZ0NBaVZEO0FBQ1IsYUFBSzdRLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixPQUFuQixFQUE0QixLQUFLdWxCLFFBQUwsQ0FBYzVWLElBQWQsRUFBNUIsRUFDY3RDLEdBRGQsQ0FDa0IseUJBRGxCLEVBRWMzSCxXQUZkLENBRTBCLHdCQUYxQixFQUdjdEUsVUFIZCxDQUd5QixzR0FIekI7O0FBS0EsYUFBS21rQixRQUFMLENBQWM1SCxNQUFkOztBQUVBaGUsbUJBQVdzQixnQkFBWCxDQUE0QixJQUE1QjtBQUNEO0FBMVZVOztBQUFBO0FBQUE7O0FBNlZiaWtCLFVBQVF0TSxRQUFSLEdBQW1CO0FBQ2pCeU4scUJBQWlCLEtBREE7QUFFakI7Ozs7O0FBS0FsSCxnQkFBWSxHQVBLO0FBUWpCOzs7OztBQUtBK0csb0JBQWdCLEdBYkM7QUFjakI7Ozs7O0FBS0FDLHFCQUFpQixHQW5CQTtBQW9CakI7Ozs7O0FBS0ExRixrQkFBYyxLQXpCRztBQTBCakI7Ozs7O0FBS0FtRixxQkFBaUIsRUEvQkE7QUFnQ2pCOzs7OztBQUtBQyxrQkFBYyxTQXJDRztBQXNDakI7Ozs7O0FBS0FGLGtCQUFjLFNBM0NHO0FBNENqQjs7Ozs7QUFLQUssWUFBUSxPQWpEUztBQWtEakI7Ozs7O0FBS0FULGNBQVUsRUF2RE87QUF3RGpCOzs7OztBQUtBRCxhQUFTLEVBN0RRO0FBOERqQmdCLG9CQUFnQixlQTlEQztBQStEakI7Ozs7O0FBS0FoRyxlQUFXLElBcEVNO0FBcUVqQjs7Ozs7QUFLQXJDLG1CQUFlLEVBMUVFO0FBMkVqQjs7Ozs7QUFLQTFULGFBQVMsRUFoRlE7QUFpRmpCOzs7OztBQUtBQyxhQUFTLEVBdEZRO0FBdUZmOzs7Ozs7QUFNRmliLGVBQVc7QUE3Rk0sR0FBbkI7O0FBZ0dBOzs7O0FBSUE7QUFDQTlsQixhQUFXTSxNQUFYLENBQWtCaWxCLE9BQWxCLEVBQTJCLFNBQTNCO0FBRUMsQ0FwY0EsQ0FvY0M3YyxNQXBjRCxDQUFEOzs7OztBQ0ZBOzs7OztBQUtBLENBQUMsVUFBU2tlLENBQVQsRUFBV0MsQ0FBWCxFQUFhQyxDQUFiLEVBQWVDLENBQWYsRUFBaUI7QUFBQyxXQUFTL2lCLENBQVQsQ0FBVzZpQixDQUFYLEVBQWFDLENBQWIsRUFBZTtBQUFDLFNBQUtFLFFBQUwsR0FBYyxJQUFkLEVBQW1CLEtBQUsvVCxPQUFMLEdBQWEyVCxFQUFFcmEsTUFBRixDQUFTLEVBQVQsRUFBWXZJLEVBQUVpakIsUUFBZCxFQUF1QkgsQ0FBdkIsQ0FBaEMsRUFBMEQsS0FBSzVsQixRQUFMLEdBQWMwbEIsRUFBRUMsQ0FBRixDQUF4RSxFQUE2RSxLQUFLSyxTQUFMLEdBQWUsRUFBNUYsRUFBK0YsS0FBS2huQixRQUFMLEdBQWMsRUFBN0csRUFBZ0gsS0FBS2luQixRQUFMLEdBQWMsRUFBOUgsRUFBaUksS0FBS0MsUUFBTCxHQUFjLElBQS9JLEVBQW9KLEtBQUtDLE1BQUwsR0FBWSxJQUFoSyxFQUFxSyxLQUFLQyxZQUFMLEdBQWtCLEVBQXZMLEVBQTBMLEtBQUtDLFdBQUwsR0FBaUIsSUFBM00sRUFBZ04sS0FBS0MsTUFBTCxHQUFZLElBQTVOLEVBQWlPLEtBQUtDLE1BQUwsR0FBWSxFQUE3TyxFQUFnUCxLQUFLQyxPQUFMLEdBQWEsRUFBN1AsRUFBZ1EsS0FBS0MsUUFBTCxHQUFjLEVBQTlRLEVBQWlSLEtBQUtDLE9BQUwsR0FBYSxFQUE5UixFQUFpUyxLQUFLQyxZQUFMLEdBQWtCLEVBQW5ULEVBQXNULEtBQUtDLEtBQUwsR0FBVyxFQUFqVSxFQUFvVSxLQUFLQyxLQUFMLEdBQVcsRUFBQ0MsTUFBSyxJQUFOLEVBQVcxYSxRQUFPLElBQWxCLEVBQXVCMmEsU0FBUSxJQUEvQixFQUFvQ0MsT0FBTSxFQUFDeGdCLE9BQU0sSUFBUCxFQUFZeUcsU0FBUSxJQUFwQixFQUExQyxFQUFvRTJRLFdBQVUsSUFBOUUsRUFBL1UsRUFBbWEsS0FBS3FKLE9BQUwsR0FBYSxFQUFDaGEsU0FBUSxFQUFULEVBQVlpYSxNQUFLLEVBQUNDLGNBQWEsQ0FBQyxNQUFELENBQWQsRUFBdUJDLFdBQVUsQ0FBQyxNQUFELENBQWpDLEVBQTBDQyxVQUFTLENBQUMsYUFBRCxDQUFuRCxFQUFqQixFQUFoYixFQUFzZ0IzQixFQUFFN2tCLElBQUYsQ0FBTyxDQUFDLFVBQUQsRUFBWSxtQkFBWixDQUFQLEVBQXdDNmtCLEVBQUU0QixLQUFGLENBQVEsVUFBUzNCLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsV0FBS0ksU0FBTCxDQUFlSixDQUFmLElBQWtCRixFQUFFNEIsS0FBRixDQUFRLEtBQUsxQixDQUFMLENBQVIsRUFBZ0IsSUFBaEIsQ0FBbEI7QUFBd0MsS0FBOUQsRUFBK0QsSUFBL0QsQ0FBeEMsQ0FBdGdCLEVBQW9uQkYsRUFBRTdrQixJQUFGLENBQU9pQyxFQUFFeWtCLE9BQVQsRUFBaUI3QixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFdBQUszbUIsUUFBTCxDQUFjMG1CLEVBQUU4QixNQUFGLENBQVMsQ0FBVCxFQUFZM25CLFdBQVosS0FBMEI2bEIsRUFBRXhqQixLQUFGLENBQVEsQ0FBUixDQUF4QyxJQUFvRCxJQUFJeWpCLENBQUosQ0FBTSxJQUFOLENBQXBEO0FBQWdFLEtBQXRGLEVBQXVGLElBQXZGLENBQWpCLENBQXBuQixFQUFtdUJELEVBQUU3a0IsSUFBRixDQUFPaUMsRUFBRTJrQixPQUFULEVBQWlCL0IsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTM0IsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxXQUFLZ0IsS0FBTCxDQUFXem1CLElBQVgsQ0FBZ0IsRUFBQ3VMLFFBQU9rYSxFQUFFbGEsTUFBVixFQUFpQmdjLEtBQUloQyxFQUFFNEIsS0FBRixDQUFRMUIsRUFBRThCLEdBQVYsRUFBYyxJQUFkLENBQXJCLEVBQWhCO0FBQTJELEtBQWpGLEVBQWtGLElBQWxGLENBQWpCLENBQW51QixFQUE2MEIsS0FBS2pULEtBQUwsRUFBNzBCLEVBQTAxQixLQUFLa1QsVUFBTCxFQUExMUI7QUFBNDJCLEtBQUU1QixRQUFGLEdBQVcsRUFBQ3pVLE9BQU0sQ0FBUCxFQUFTc1csTUFBSyxDQUFDLENBQWYsRUFBaUJDLFFBQU8sQ0FBQyxDQUF6QixFQUEyQkMsUUFBTyxDQUFDLENBQW5DLEVBQXFDQyxXQUFVLENBQUMsQ0FBaEQsRUFBa0RDLFdBQVUsQ0FBQyxDQUE3RCxFQUErREMsVUFBUyxDQUFDLENBQXpFLEVBQTJFQyxVQUFTLENBQUMsQ0FBckYsRUFBdUZDLFFBQU8sQ0FBOUYsRUFBZ0dDLGNBQWEsQ0FBN0csRUFBK0dDLE9BQU0sQ0FBQyxDQUF0SCxFQUF3SEMsVUFBUyxDQUFDLENBQWxJLEVBQW9JQyxXQUFVLENBQUMsQ0FBL0ksRUFBaUpDLGVBQWMsQ0FBL0osRUFBaUt0cEIsS0FBSSxDQUFDLENBQXRLLEVBQXdLdXBCLFlBQVcsR0FBbkwsRUFBdUxDLFlBQVcsQ0FBQyxDQUFuTSxFQUFxTUMsY0FBYSxDQUFDLENBQW5OLEVBQXFOQyxZQUFXLEVBQWhPLEVBQW1PQyx1QkFBc0IsR0FBelAsRUFBNlBDLHVCQUFzQm5ELENBQW5SLEVBQXFSb0QsZ0JBQWUsT0FBcFMsRUFBNFN2YSxNQUFLLENBQUMsQ0FBbFQsRUFBb1R3YSxvQkFBbUIsQ0FBQyxDQUF4VSxFQUEwVUMsYUFBWSxLQUF0VixFQUE0VkMsY0FBYSxLQUF6VyxFQUErV0MsY0FBYSxhQUE1WCxFQUEwWUMsYUFBWSxZQUF0WixFQUFtYUMsY0FBYSxhQUFoYixFQUE4YkMsVUFBUyxTQUF2YyxFQUFpZEMsaUJBQWdCLGdCQUFqZSxFQUFrZkMsV0FBVSxVQUE1ZixFQUF1Z0JDLFdBQVUsVUFBamhCLEVBQTRoQkMsWUFBVyxXQUF2aUIsRUFBbWpCQyxpQkFBZ0IsaUJBQW5rQixFQUFxbEJDLFdBQVUsVUFBL2xCLEVBQVgsRUFBc25COW1CLEVBQUUrbUIsS0FBRixHQUFRLEVBQUNDLFNBQVEsU0FBVCxFQUFtQkMsT0FBTSxPQUF6QixFQUFpQ0MsT0FBTSxPQUF2QyxFQUE5bkIsRUFBOHFCbG5CLEVBQUVtbkIsSUFBRixHQUFPLEVBQUNDLE9BQU0sT0FBUCxFQUFlQyxPQUFNLE9BQXJCLEVBQXJyQixFQUFtdEJybkIsRUFBRXlrQixPQUFGLEdBQVUsRUFBN3RCLEVBQWd1QnprQixFQUFFMmtCLE9BQUYsR0FBVSxDQUFDLEVBQUMvYixRQUFPLENBQUMsT0FBRCxFQUFTLFVBQVQsQ0FBUixFQUE2QmdjLEtBQUksZUFBVTtBQUFDLFdBQUtwQixNQUFMLEdBQVksS0FBS3RtQixRQUFMLENBQWN5SSxLQUFkLEVBQVo7QUFBa0MsS0FBOUUsRUFBRCxFQUFpRixFQUFDaUQsUUFBTyxDQUFDLE9BQUQsRUFBUyxPQUFULEVBQWlCLFVBQWpCLENBQVIsRUFBcUNnYyxLQUFJLGFBQVNoQyxDQUFULEVBQVc7QUFBQ0EsUUFBRXpZLE9BQUYsR0FBVSxLQUFLc1osTUFBTCxJQUFhLEtBQUtBLE1BQUwsQ0FBWSxLQUFLNkQsUUFBTCxDQUFjLEtBQUtsRSxRQUFuQixDQUFaLENBQXZCO0FBQWlFLEtBQXRILEVBQWpGLEVBQXlNLEVBQUN4YSxRQUFPLENBQUMsT0FBRCxFQUFTLFVBQVQsQ0FBUixFQUE2QmdjLEtBQUksZUFBVTtBQUFDLFdBQUsyQyxNQUFMLENBQVl6WSxRQUFaLENBQXFCLFNBQXJCLEVBQWdDa0wsTUFBaEM7QUFBeUMsS0FBckYsRUFBek0sRUFBZ1MsRUFBQ3BSLFFBQU8sQ0FBQyxPQUFELEVBQVMsT0FBVCxFQUFpQixVQUFqQixDQUFSLEVBQXFDZ2MsS0FBSSxhQUFTaEMsQ0FBVCxFQUFXO0FBQUMsVUFBSUMsSUFBRSxLQUFLRyxRQUFMLENBQWNxQyxNQUFkLElBQXNCLEVBQTVCO0FBQUEsVUFBK0J2QyxJQUFFLENBQUMsS0FBS0UsUUFBTCxDQUFjeUMsU0FBaEQ7QUFBQSxVQUEwRDFDLElBQUUsS0FBS0MsUUFBTCxDQUFjNW1CLEdBQTFFO0FBQUEsVUFBOEU0RCxJQUFFLEVBQUMyRixPQUFNLE1BQVAsRUFBYyxlQUFjb2QsSUFBRUYsQ0FBRixHQUFJLEVBQWhDLEVBQW1DLGdCQUFlRSxJQUFFLEVBQUYsR0FBS0YsQ0FBdkQsRUFBaEYsQ0FBMEksQ0FBQ0MsQ0FBRCxJQUFJLEtBQUt5RSxNQUFMLENBQVl6WSxRQUFaLEdBQXVCeEUsR0FBdkIsQ0FBMkJ0SyxDQUEzQixDQUFKLEVBQWtDNGlCLEVBQUV0WSxHQUFGLEdBQU10SyxDQUF4QztBQUEwQyxLQUF6TyxFQUFoUyxFQUEyZ0IsRUFBQzRJLFFBQU8sQ0FBQyxPQUFELEVBQVMsT0FBVCxFQUFpQixVQUFqQixDQUFSLEVBQXFDZ2MsS0FBSSxhQUFTaEMsQ0FBVCxFQUFXO0FBQUMsVUFBSUMsSUFBRSxDQUFDLEtBQUtsZCxLQUFMLEtBQWEsS0FBS3FkLFFBQUwsQ0FBY3hVLEtBQTVCLEVBQW1DZ1osT0FBbkMsQ0FBMkMsQ0FBM0MsSUFBOEMsS0FBS3hFLFFBQUwsQ0FBY3FDLE1BQWxFO0FBQUEsVUFBeUV2QyxJQUFFLElBQTNFO0FBQUEsVUFBZ0ZDLElBQUUsS0FBS1UsTUFBTCxDQUFZNWtCLE1BQTlGO0FBQUEsVUFBcUdtQixJQUFFLENBQUMsS0FBS2dqQixRQUFMLENBQWN5QyxTQUF0SDtBQUFBLFVBQWdJZ0MsSUFBRSxFQUFsSSxDQUFxSSxLQUFJN0UsRUFBRXBVLEtBQUYsR0FBUSxFQUFDK1csT0FBTSxDQUFDLENBQVIsRUFBVTVmLE9BQU1rZCxDQUFoQixFQUFaLEVBQStCRSxHQUEvQjtBQUFvQ0QsWUFBRSxLQUFLYSxRQUFMLENBQWNaLENBQWQsQ0FBRixFQUFtQkQsSUFBRSxLQUFLRSxRQUFMLENBQWN3QyxRQUFkLElBQXdCem1CLEtBQUtrWCxHQUFMLENBQVM2TSxDQUFULEVBQVcsS0FBS0UsUUFBTCxDQUFjeFUsS0FBekIsQ0FBeEIsSUFBeURzVSxDQUE5RSxFQUFnRkYsRUFBRXBVLEtBQUYsQ0FBUStXLEtBQVIsR0FBY3pDLElBQUUsQ0FBRixJQUFLRixFQUFFcFUsS0FBRixDQUFRK1csS0FBM0csRUFBaUhrQyxFQUFFMUUsQ0FBRixJQUFLL2lCLElBQUU2aUIsSUFBRUMsQ0FBSixHQUFNLEtBQUtXLE1BQUwsQ0FBWVYsQ0FBWixFQUFlcGQsS0FBZixFQUE1SDtBQUFwQyxPQUF1TCxLQUFLaWUsT0FBTCxHQUFhNkQsQ0FBYjtBQUFlLEtBQWhZLEVBQTNnQixFQUE2NEIsRUFBQzdlLFFBQU8sQ0FBQyxPQUFELEVBQVMsVUFBVCxDQUFSLEVBQTZCZ2MsS0FBSSxlQUFVO0FBQUMsVUFBSS9CLElBQUUsRUFBTjtBQUFBLFVBQVNDLElBQUUsS0FBS1csTUFBaEI7QUFBQSxVQUF1QlYsSUFBRSxLQUFLQyxRQUE5QjtBQUFBLFVBQXVDaGpCLElBQUVqQixLQUFLd0UsR0FBTCxDQUFTLElBQUV3ZixFQUFFdlUsS0FBYixFQUFtQixDQUFuQixDQUF6QztBQUFBLFVBQStEaVosSUFBRSxJQUFFMW9CLEtBQUsyb0IsSUFBTCxDQUFVNUUsRUFBRWprQixNQUFGLEdBQVMsQ0FBbkIsQ0FBbkU7QUFBQSxVQUF5RjhvQixJQUFFNUUsRUFBRStCLElBQUYsSUFBUWhDLEVBQUVqa0IsTUFBVixHQUFpQmtrQixFQUFFaUMsTUFBRixHQUFTaGxCLENBQVQsR0FBV2pCLEtBQUt3RSxHQUFMLENBQVN2RCxDQUFULEVBQVd5bkIsQ0FBWCxDQUE1QixHQUEwQyxDQUFySTtBQUFBLFVBQXVJRyxJQUFFLEVBQXpJO0FBQUEsVUFBNElyb0IsSUFBRSxFQUE5SSxDQUFpSixLQUFJb29CLEtBQUcsQ0FBUCxFQUFTQSxHQUFUO0FBQWM5RSxVQUFFeGxCLElBQUYsQ0FBTyxLQUFLd3FCLFNBQUwsQ0FBZWhGLEVBQUVoa0IsTUFBRixHQUFTLENBQXhCLEVBQTBCLENBQUMsQ0FBM0IsQ0FBUCxHQUFzQytvQixLQUFHOUUsRUFBRUQsRUFBRUEsRUFBRWhrQixNQUFGLEdBQVMsQ0FBWCxDQUFGLEVBQWlCLENBQWpCLEVBQW9CaXBCLFNBQTdELEVBQXVFakYsRUFBRXhsQixJQUFGLENBQU8sS0FBS3dxQixTQUFMLENBQWUvRSxFQUFFamtCLE1BQUYsR0FBUyxDQUFULEdBQVcsQ0FBQ2drQixFQUFFaGtCLE1BQUYsR0FBUyxDQUFWLElBQWEsQ0FBdkMsRUFBeUMsQ0FBQyxDQUExQyxDQUFQLENBQXZFLEVBQTRIVSxJQUFFdWpCLEVBQUVELEVBQUVBLEVBQUVoa0IsTUFBRixHQUFTLENBQVgsQ0FBRixFQUFpQixDQUFqQixFQUFvQmlwQixTQUFwQixHQUE4QnZvQixDQUE1SjtBQUFkLE9BQTRLLEtBQUtta0IsT0FBTCxHQUFhYixDQUFiLEVBQWVELEVBQUVnRixDQUFGLEVBQUs5WixRQUFMLENBQWMsUUFBZCxFQUF3QmpNLFFBQXhCLENBQWlDLEtBQUswbEIsTUFBdEMsQ0FBZixFQUE2RDNFLEVBQUVyakIsQ0FBRixFQUFLdU8sUUFBTCxDQUFjLFFBQWQsRUFBd0IySixTQUF4QixDQUFrQyxLQUFLOFAsTUFBdkMsQ0FBN0Q7QUFBNEcsS0FBcmQsRUFBNzRCLEVBQW8yQyxFQUFDM2UsUUFBTyxDQUFDLE9BQUQsRUFBUyxPQUFULEVBQWlCLFVBQWpCLENBQVIsRUFBcUNnYyxLQUFJLGVBQVU7QUFBQyxXQUFJLElBQUloQyxJQUFFLEtBQUtJLFFBQUwsQ0FBYzVtQixHQUFkLEdBQWtCLENBQWxCLEdBQW9CLENBQUMsQ0FBM0IsRUFBNkJ5bUIsSUFBRSxLQUFLYSxPQUFMLENBQWE3a0IsTUFBYixHQUFvQixLQUFLNGtCLE1BQUwsQ0FBWTVrQixNQUEvRCxFQUFzRWlrQixJQUFFLENBQUMsQ0FBekUsRUFBMkVDLElBQUUsQ0FBN0UsRUFBK0UvaUIsSUFBRSxDQUFqRixFQUFtRnluQixJQUFFLEVBQXpGLEVBQTRGLEVBQUUzRSxDQUFGLEdBQUlELENBQWhHO0FBQW1HRSxZQUFFMEUsRUFBRTNFLElBQUUsQ0FBSixLQUFRLENBQVYsRUFBWTlpQixJQUFFLEtBQUs0akIsT0FBTCxDQUFhLEtBQUswRCxRQUFMLENBQWN4RSxDQUFkLENBQWIsSUFBK0IsS0FBS0UsUUFBTCxDQUFjcUMsTUFBM0QsRUFBa0VvQyxFQUFFcHFCLElBQUYsQ0FBTzBsQixJQUFFL2lCLElBQUU0aUIsQ0FBWCxDQUFsRTtBQUFuRyxPQUFtTCxLQUFLVSxZQUFMLEdBQWtCbUUsQ0FBbEI7QUFBb0IsS0FBM1AsRUFBcDJDLEVBQWltRCxFQUFDN2UsUUFBTyxDQUFDLE9BQUQsRUFBUyxPQUFULEVBQWlCLFVBQWpCLENBQVIsRUFBcUNnYyxLQUFJLGVBQVU7QUFBQyxVQUFJaEMsSUFBRSxLQUFLSSxRQUFMLENBQWNzQyxZQUFwQjtBQUFBLFVBQWlDekMsSUFBRSxLQUFLUyxZQUF4QztBQUFBLFVBQXFEUixJQUFFLEVBQUNuZCxPQUFNNUcsS0FBSzJvQixJQUFMLENBQVUzb0IsS0FBS3FTLEdBQUwsQ0FBU3lSLEVBQUVBLEVBQUVoa0IsTUFBRixHQUFTLENBQVgsQ0FBVCxDQUFWLElBQW1DLElBQUUrakIsQ0FBNUMsRUFBOEMsZ0JBQWVBLEtBQUcsRUFBaEUsRUFBbUUsaUJBQWdCQSxLQUFHLEVBQXRGLEVBQXZELENBQWlKLEtBQUsyRSxNQUFMLENBQVlqZCxHQUFaLENBQWdCd1ksQ0FBaEI7QUFBbUIsS0FBeE4sRUFBam1ELEVBQTJ6RCxFQUFDbGEsUUFBTyxDQUFDLE9BQUQsRUFBUyxPQUFULEVBQWlCLFVBQWpCLENBQVIsRUFBcUNnYyxLQUFJLGFBQVNoQyxDQUFULEVBQVc7QUFBQyxVQUFJQyxJQUFFLEtBQUtTLFlBQUwsQ0FBa0J6a0IsTUFBeEI7QUFBQSxVQUErQmlrQixJQUFFLENBQUMsS0FBS0UsUUFBTCxDQUFjeUMsU0FBaEQ7QUFBQSxVQUEwRDFDLElBQUUsS0FBS3dFLE1BQUwsQ0FBWXpZLFFBQVosRUFBNUQsQ0FBbUYsSUFBR2dVLEtBQUdGLEVBQUVwVSxLQUFGLENBQVErVyxLQUFkLEVBQW9CLE9BQUsxQyxHQUFMO0FBQVVELFVBQUV0WSxHQUFGLENBQU0zRSxLQUFOLEdBQVksS0FBS2llLE9BQUwsQ0FBYSxLQUFLMEQsUUFBTCxDQUFjekUsQ0FBZCxDQUFiLENBQVosRUFBMkNFLEVBQUU1WixFQUFGLENBQUswWixDQUFMLEVBQVF2WSxHQUFSLENBQVlzWSxFQUFFdFksR0FBZCxDQUEzQztBQUFWLE9BQXBCLE1BQWlHd1ksTUFBSUYsRUFBRXRZLEdBQUYsQ0FBTTNFLEtBQU4sR0FBWWlkLEVBQUVwVSxLQUFGLENBQVE3SSxLQUFwQixFQUEwQm9kLEVBQUV6WSxHQUFGLENBQU1zWSxFQUFFdFksR0FBUixDQUE5QjtBQUE0QyxLQUFyUixFQUEzekQsRUFBa2xFLEVBQUMxQixRQUFPLENBQUMsT0FBRCxDQUFSLEVBQWtCZ2MsS0FBSSxlQUFVO0FBQUMsV0FBS3RCLFlBQUwsQ0FBa0J6a0IsTUFBbEIsR0FBeUIsQ0FBekIsSUFBNEIsS0FBSzBvQixNQUFMLENBQVk5cEIsVUFBWixDQUF1QixPQUF2QixDQUE1QjtBQUE0RCxLQUE3RixFQUFsbEUsRUFBaXJFLEVBQUNtTCxRQUFPLENBQUMsT0FBRCxFQUFTLE9BQVQsRUFBaUIsVUFBakIsQ0FBUixFQUFxQ2djLEtBQUksYUFBU2hDLENBQVQsRUFBVztBQUFDQSxRQUFFelksT0FBRixHQUFVeVksRUFBRXpZLE9BQUYsR0FBVSxLQUFLb2QsTUFBTCxDQUFZelksUUFBWixHQUF1Qm9PLEtBQXZCLENBQTZCMEYsRUFBRXpZLE9BQS9CLENBQVYsR0FBa0QsQ0FBNUQsRUFBOER5WSxFQUFFelksT0FBRixHQUFVcEwsS0FBS3dFLEdBQUwsQ0FBUyxLQUFLd2tCLE9BQUwsRUFBVCxFQUF3QmhwQixLQUFLa1gsR0FBTCxDQUFTLEtBQUsrUixPQUFMLEVBQVQsRUFBd0JwRixFQUFFelksT0FBMUIsQ0FBeEIsQ0FBeEUsRUFBb0ksS0FBSzBELEtBQUwsQ0FBVytVLEVBQUV6WSxPQUFiLENBQXBJO0FBQTBKLEtBQS9NLEVBQWpyRSxFQUFrNEUsRUFBQ3ZCLFFBQU8sQ0FBQyxVQUFELENBQVIsRUFBcUJnYyxLQUFJLGVBQVU7QUFBQyxXQUFLMVgsT0FBTCxDQUFhLEtBQUsrYSxXQUFMLENBQWlCLEtBQUs3RSxRQUF0QixDQUFiO0FBQThDLEtBQWxGLEVBQWw0RSxFQUFzOUUsRUFBQ3hhLFFBQU8sQ0FBQyxPQUFELEVBQVMsVUFBVCxFQUFvQixPQUFwQixFQUE0QixVQUE1QixDQUFSLEVBQWdEZ2MsS0FBSSxlQUFVO0FBQUMsVUFBSWhDLENBQUo7QUFBQSxVQUFNQyxDQUFOO0FBQUEsVUFBUUMsQ0FBUjtBQUFBLFVBQVVDLENBQVY7QUFBQSxVQUFZL2lCLElBQUUsS0FBS2dqQixRQUFMLENBQWM1bUIsR0FBZCxHQUFrQixDQUFsQixHQUFvQixDQUFDLENBQW5DO0FBQUEsVUFBcUNxckIsSUFBRSxJQUFFLEtBQUt6RSxRQUFMLENBQWNzQyxZQUF2RDtBQUFBLFVBQW9FcUMsSUFBRSxLQUFLTSxXQUFMLENBQWlCLEtBQUs5ZCxPQUFMLEVBQWpCLElBQWlDc2QsQ0FBdkc7QUFBQSxVQUF5R0csSUFBRUQsSUFBRSxLQUFLaGlCLEtBQUwsS0FBYTNGLENBQTFIO0FBQUEsVUFBNEhULElBQUUsRUFBOUgsQ0FBaUksS0FBSXVqQixJQUFFLENBQUYsRUFBSUMsSUFBRSxLQUFLTyxZQUFMLENBQWtCemtCLE1BQTVCLEVBQW1DaWtCLElBQUVDLENBQXJDLEVBQXVDRCxHQUF2QztBQUEyQ0YsWUFBRSxLQUFLVSxZQUFMLENBQWtCUixJQUFFLENBQXBCLEtBQXdCLENBQTFCLEVBQTRCRCxJQUFFOWpCLEtBQUtxUyxHQUFMLENBQVMsS0FBS2tTLFlBQUwsQ0FBa0JSLENBQWxCLENBQVQsSUFBK0IyRSxJQUFFem5CLENBQS9ELEVBQWlFLENBQUMsS0FBS2tvQixFQUFMLENBQVF0RixDQUFSLEVBQVUsSUFBVixFQUFlK0UsQ0FBZixLQUFtQixLQUFLTyxFQUFMLENBQVF0RixDQUFSLEVBQVUsR0FBVixFQUFjZ0YsQ0FBZCxDQUFuQixJQUFxQyxLQUFLTSxFQUFMLENBQVFyRixDQUFSLEVBQVUsR0FBVixFQUFjOEUsQ0FBZCxLQUFrQixLQUFLTyxFQUFMLENBQVFyRixDQUFSLEVBQVUsR0FBVixFQUFjK0UsQ0FBZCxDQUF4RCxLQUEyRXJvQixFQUFFbEMsSUFBRixDQUFPeWxCLENBQVAsQ0FBNUk7QUFBM0MsT0FBaU0sS0FBS3lFLE1BQUwsQ0FBWXpZLFFBQVosQ0FBcUIsU0FBckIsRUFBZ0MvTSxXQUFoQyxDQUE0QyxRQUE1QyxHQUFzRCxLQUFLd2xCLE1BQUwsQ0FBWXpZLFFBQVosQ0FBcUIsU0FBT3ZQLEVBQUVxVSxJQUFGLENBQU8sU0FBUCxDQUFQLEdBQXlCLEdBQTlDLEVBQW1EOUYsUUFBbkQsQ0FBNEQsUUFBNUQsQ0FBdEQsRUFBNEgsS0FBS2tWLFFBQUwsQ0FBYytCLE1BQWQsS0FBdUIsS0FBS3dDLE1BQUwsQ0FBWXpZLFFBQVosQ0FBcUIsU0FBckIsRUFBZ0MvTSxXQUFoQyxDQUE0QyxRQUE1QyxHQUFzRCxLQUFLd2xCLE1BQUwsQ0FBWXpZLFFBQVosR0FBdUIzRixFQUF2QixDQUEwQixLQUFLZ0IsT0FBTCxFQUExQixFQUEwQzJELFFBQTFDLENBQW1ELFFBQW5ELENBQTdFLENBQTVIO0FBQXVRLEtBQXhvQixFQUF0OUUsQ0FBMXVCLEVBQTIwSDlOLEVBQUVrQyxTQUFGLENBQVkyaUIsVUFBWixHQUF1QixZQUFVO0FBQUMsUUFBRyxLQUFLc0QsS0FBTCxDQUFXLGNBQVgsR0FBMkIsS0FBSy9xQixPQUFMLENBQWEsWUFBYixDQUEzQixFQUFzRCxLQUFLRixRQUFMLENBQWNra0IsV0FBZCxDQUEwQixLQUFLNEIsUUFBTCxDQUFjd0QsUUFBeEMsRUFBaUQsS0FBS3hELFFBQUwsQ0FBYzVtQixHQUEvRCxDQUF0RCxFQUEwSCxLQUFLNG1CLFFBQUwsQ0FBY3lDLFNBQWQsSUFBeUIsQ0FBQyxLQUFLNWMsRUFBTCxDQUFRLGFBQVIsQ0FBdkosRUFBOEs7QUFBQyxVQUFJZ2EsQ0FBSixFQUFNQyxDQUFOLEVBQVE5aUIsQ0FBUixDQUFVNmlCLElBQUUsS0FBSzNsQixRQUFMLENBQWN1QyxJQUFkLENBQW1CLEtBQW5CLENBQUYsRUFBNEJxakIsSUFBRSxLQUFLRSxRQUFMLENBQWNrRCxrQkFBZCxHQUFpQyxNQUFJLEtBQUtsRCxRQUFMLENBQWNrRCxrQkFBbkQsR0FBc0VuRCxDQUFwRyxFQUFzRy9pQixJQUFFLEtBQUs5QyxRQUFMLENBQWM0UixRQUFkLENBQXVCZ1UsQ0FBdkIsRUFBMEJuZCxLQUExQixFQUF4RyxFQUEwSWtkLEVBQUVoa0IsTUFBRixJQUFVbUIsS0FBRyxDQUFiLElBQWdCLEtBQUtvb0Isc0JBQUwsQ0FBNEJ2RixDQUE1QixDQUExSjtBQUF5TCxVQUFLM2xCLFFBQUwsQ0FBYzRRLFFBQWQsQ0FBdUIsS0FBS21CLE9BQUwsQ0FBYXNYLFlBQXBDLEdBQWtELEtBQUtnQixNQUFMLEdBQVkzRSxFQUFFLE1BQUksS0FBS0ksUUFBTCxDQUFjb0QsWUFBbEIsR0FBK0IsVUFBL0IsR0FBMEMsS0FBS3BELFFBQUwsQ0FBYzRELFVBQXhELEdBQW1FLEtBQXJFLEVBQTRFbFAsSUFBNUUsQ0FBaUYsaUJBQWUsS0FBS3NMLFFBQUwsQ0FBYzZELGVBQTdCLEdBQTZDLEtBQTlILENBQTlELEVBQW1NLEtBQUszcEIsUUFBTCxDQUFjNGEsTUFBZCxDQUFxQixLQUFLeVAsTUFBTCxDQUFZdmlCLE1BQVosRUFBckIsQ0FBbk0sRUFBOE8sS0FBS1AsT0FBTCxDQUFhLEtBQUt2SCxRQUFMLENBQWM0UixRQUFkLEdBQXlCZ0YsR0FBekIsQ0FBNkIsS0FBS3lULE1BQUwsQ0FBWXZpQixNQUFaLEVBQTdCLENBQWIsQ0FBOU8sRUFBK1MsS0FBSzlILFFBQUwsQ0FBYzJMLEVBQWQsQ0FBaUIsVUFBakIsSUFBNkIsS0FBS3dmLE9BQUwsRUFBN0IsR0FBNEMsS0FBS0MsVUFBTCxDQUFnQixPQUFoQixDQUEzVixFQUFvWCxLQUFLcHJCLFFBQUwsQ0FBYzZFLFdBQWQsQ0FBMEIsS0FBS2tOLE9BQUwsQ0FBYXNYLFlBQXZDLEVBQXFEelksUUFBckQsQ0FBOEQsS0FBS21CLE9BQUwsQ0FBYXFYLFdBQTNFLENBQXBYLEVBQTRjLEtBQUtpQyxxQkFBTCxFQUE1YyxFQUF5ZSxLQUFLQyxLQUFMLENBQVcsY0FBWCxDQUF6ZSxFQUFvZ0IsS0FBS3ByQixPQUFMLENBQWEsYUFBYixDQUFwZ0I7QUFBZ2lCLEdBQS92SixFQUFnd0o0QyxFQUFFa0MsU0FBRixDQUFZeVAsS0FBWixHQUFrQixZQUFVO0FBQUMsUUFBSWtSLElBQUUsS0FBSzRGLFFBQUwsRUFBTjtBQUFBLFFBQXNCM0YsSUFBRSxLQUFLN1QsT0FBTCxDQUFhNlcsVUFBckM7QUFBQSxRQUFnRC9DLElBQUUsQ0FBQyxDQUFuRDtBQUFBLFFBQXFEL2lCLElBQUUsSUFBdkQsQ0FBNEQ4aUIsS0FBR0YsRUFBRTdrQixJQUFGLENBQU8ra0IsQ0FBUCxFQUFTLFVBQVNGLENBQVQsRUFBVztBQUFDQSxXQUFHQyxDQUFILElBQU1ELElBQUVHLENBQVIsS0FBWUEsSUFBRTJGLE9BQU85RixDQUFQLENBQWQ7QUFBeUIsS0FBOUMsR0FBZ0Q1aUIsSUFBRTRpQixFQUFFcmEsTUFBRixDQUFTLEVBQVQsRUFBWSxLQUFLMEcsT0FBakIsRUFBeUI2VCxFQUFFQyxDQUFGLENBQXpCLENBQWxELEVBQWlGLGNBQVksT0FBTy9pQixFQUFFc2xCLFlBQXJCLEtBQW9DdGxCLEVBQUVzbEIsWUFBRixHQUFldGxCLEVBQUVzbEIsWUFBRixFQUFuRCxDQUFqRixFQUFzSixPQUFPdGxCLEVBQUU4bEIsVUFBL0osRUFBMEs5bEIsRUFBRXltQixlQUFGLElBQW1CLEtBQUt2cEIsUUFBTCxDQUFjYixJQUFkLENBQW1CLE9BQW5CLEVBQTJCLEtBQUthLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixPQUFuQixFQUE0Qm9JLE9BQTVCLENBQW9DLElBQUlpYSxNQUFKLENBQVcsTUFBSSxLQUFLelAsT0FBTCxDQUFhd1gsZUFBakIsR0FBaUMsV0FBNUMsRUFBd0QsR0FBeEQsQ0FBcEMsRUFBaUcsT0FBSzFELENBQXRHLENBQTNCLENBQWhNLElBQXNVL2lCLElBQUU0aUIsRUFBRXJhLE1BQUYsQ0FBUyxFQUFULEVBQVksS0FBSzBHLE9BQWpCLENBQXhVLEVBQWtXLEtBQUs3UixPQUFMLENBQWEsUUFBYixFQUFzQixFQUFDdXJCLFVBQVMsRUFBQ3BzQixNQUFLLFVBQU4sRUFBaUJtTyxPQUFNMUssQ0FBdkIsRUFBVixFQUF0QixDQUFsVyxFQUE4WixLQUFLdWpCLFdBQUwsR0FBaUJSLENBQS9hLEVBQWliLEtBQUtDLFFBQUwsR0FBY2hqQixDQUEvYixFQUFpYyxLQUFLc29CLFVBQUwsQ0FBZ0IsVUFBaEIsQ0FBamMsRUFBNmQsS0FBS2xyQixPQUFMLENBQWEsU0FBYixFQUF1QixFQUFDdXJCLFVBQVMsRUFBQ3BzQixNQUFLLFVBQU4sRUFBaUJtTyxPQUFNLEtBQUtzWSxRQUE1QixFQUFWLEVBQXZCLENBQTdkO0FBQXNpQixHQUEvM0ssRUFBZzRLaGpCLEVBQUVrQyxTQUFGLENBQVkwbUIsWUFBWixHQUF5QixZQUFVO0FBQUMsU0FBSzVGLFFBQUwsQ0FBY3lDLFNBQWQsS0FBMEIsS0FBS3pDLFFBQUwsQ0FBY3NDLFlBQWQsR0FBMkIsQ0FBQyxDQUE1QixFQUE4QixLQUFLdEMsUUFBTCxDQUFjdUMsS0FBZCxHQUFvQixDQUFDLENBQTdFO0FBQWdGLEdBQXAvSyxFQUFxL0t2bEIsRUFBRWtDLFNBQUYsQ0FBWTJtQixPQUFaLEdBQW9CLFVBQVNoRyxDQUFULEVBQVc7QUFBQyxRQUFJQyxJQUFFLEtBQUsxbEIsT0FBTCxDQUFhLFNBQWIsRUFBdUIsRUFBQzByQixTQUFRakcsQ0FBVCxFQUF2QixDQUFOLENBQTBDLE9BQU9DLEVBQUUzbEIsSUFBRixLQUFTMmxCLEVBQUUzbEIsSUFBRixHQUFPeWxCLEVBQUUsTUFBSSxLQUFLSSxRQUFMLENBQWNtRCxXQUFsQixHQUE4QixJQUFoQyxFQUFzQ3JZLFFBQXRDLENBQStDLEtBQUttQixPQUFMLENBQWEwWCxTQUE1RCxFQUF1RTdPLE1BQXZFLENBQThFK0ssQ0FBOUUsQ0FBaEIsR0FBa0csS0FBS3psQixPQUFMLENBQWEsVUFBYixFQUF3QixFQUFDMHJCLFNBQVFoRyxFQUFFM2xCLElBQVgsRUFBeEIsQ0FBbEcsRUFBNEkybEIsRUFBRTNsQixJQUFySjtBQUEwSixHQUF6dEwsRUFBMHRMNkMsRUFBRWtDLFNBQUYsQ0FBWTZtQixNQUFaLEdBQW1CLFlBQVU7QUFBQyxTQUFJLElBQUlsRyxJQUFFLENBQU4sRUFBUUMsSUFBRSxLQUFLZ0IsS0FBTCxDQUFXamxCLE1BQXJCLEVBQTRCa2tCLElBQUVILEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDLGFBQU8sS0FBS0EsQ0FBTCxDQUFQO0FBQWUsS0FBbkMsRUFBb0MsS0FBS2lCLFlBQXpDLENBQTlCLEVBQXFGN2pCLElBQUUsRUFBM0YsRUFBOEY2aUIsSUFBRUMsQ0FBaEc7QUFBbUcsT0FBQyxLQUFLZSxZQUFMLENBQWtCbUYsR0FBbEIsSUFBdUJwRyxFQUFFcUcsSUFBRixDQUFPLEtBQUtuRixLQUFMLENBQVdqQixDQUFYLEVBQWNqYSxNQUFyQixFQUE0Qm1hLENBQTVCLEVBQStCbGtCLE1BQS9CLEdBQXNDLENBQTlELEtBQWtFLEtBQUtpbEIsS0FBTCxDQUFXakIsQ0FBWCxFQUFjK0IsR0FBZCxDQUFrQjVrQixDQUFsQixDQUFsRSxFQUF1RjZpQixHQUF2RjtBQUFuRyxLQUE4TCxLQUFLZ0IsWUFBTCxHQUFrQixFQUFsQixFQUFxQixDQUFDLEtBQUtoYixFQUFMLENBQVEsT0FBUixDQUFELElBQW1CLEtBQUtzZixLQUFMLENBQVcsT0FBWCxDQUF4QztBQUE0RCxHQUFsL0wsRUFBbS9Mbm9CLEVBQUVrQyxTQUFGLENBQVl5RCxLQUFaLEdBQWtCLFVBQVNpZCxDQUFULEVBQVc7QUFBQyxZQUFPQSxJQUFFQSxLQUFHNWlCLEVBQUUrbUIsS0FBRixDQUFRQyxPQUFwQixHQUE2QixLQUFLaG5CLEVBQUUrbUIsS0FBRixDQUFRRSxLQUFiLENBQW1CLEtBQUtqbkIsRUFBRSttQixLQUFGLENBQVFHLEtBQWI7QUFBbUIsZUFBTyxLQUFLMUQsTUFBWixDQUFtQjtBQUFRLGVBQU8sS0FBS0EsTUFBTCxHQUFZLElBQUUsS0FBS1IsUUFBTCxDQUFjc0MsWUFBNUIsR0FBeUMsS0FBS3RDLFFBQUwsQ0FBY3FDLE1BQTlELENBQTlGO0FBQW9LLEdBQXJyTSxFQUFzck1ybEIsRUFBRWtDLFNBQUYsQ0FBWW1tQixPQUFaLEdBQW9CLFlBQVU7QUFBQyxTQUFLRixLQUFMLENBQVcsWUFBWCxHQUF5QixLQUFLL3FCLE9BQUwsQ0FBYSxTQUFiLENBQXpCLEVBQWlELEtBQUt1VSxLQUFMLEVBQWpELEVBQThELEtBQUtpWCxZQUFMLEVBQTlELEVBQWtGLEtBQUsxckIsUUFBTCxDQUFjNFEsUUFBZCxDQUF1QixLQUFLbUIsT0FBTCxDQUFhb1gsWUFBcEMsQ0FBbEYsRUFBb0ksS0FBSzBDLE1BQUwsRUFBcEksRUFBa0osS0FBSzdyQixRQUFMLENBQWM2RSxXQUFkLENBQTBCLEtBQUtrTixPQUFMLENBQWFvWCxZQUF2QyxDQUFsSixFQUF1TSxLQUFLbUMsS0FBTCxDQUFXLFlBQVgsQ0FBdk0sRUFBZ08sS0FBS3ByQixPQUFMLENBQWEsV0FBYixDQUFoTztBQUEwUCxHQUEvOE0sRUFBZzlNNEMsRUFBRWtDLFNBQUYsQ0FBWWduQixpQkFBWixHQUE4QixZQUFVO0FBQUNyRyxNQUFFcmYsWUFBRixDQUFlLEtBQUsybEIsV0FBcEIsR0FBaUMsS0FBS0EsV0FBTCxHQUFpQnRHLEVBQUU5aEIsVUFBRixDQUFhLEtBQUttaUIsU0FBTCxDQUFla0csUUFBNUIsRUFBcUMsS0FBS3BHLFFBQUwsQ0FBYytDLHFCQUFuRCxDQUFsRDtBQUE0SCxHQUFybk4sRUFBc25OL2xCLEVBQUVrQyxTQUFGLENBQVlrbkIsUUFBWixHQUFxQixZQUFVO0FBQUMsV0FBTSxDQUFDLENBQUMsS0FBSzNGLE1BQUwsQ0FBWTVrQixNQUFkLElBQXVCLEtBQUsya0IsTUFBTCxLQUFjLEtBQUt0bUIsUUFBTCxDQUFjeUksS0FBZCxFQUFkLElBQXNDLENBQUMsQ0FBQyxLQUFLekksUUFBTCxDQUFjMkwsRUFBZCxDQUFpQixVQUFqQixDQUFGLEtBQWlDLEtBQUtzZixLQUFMLENBQVcsVUFBWCxHQUF1QixLQUFLL3FCLE9BQUwsQ0FBYSxRQUFiLEVBQXVCaXNCLGtCQUF2QixNQUE2QyxLQUFLYixLQUFMLENBQVcsVUFBWCxHQUF1QixDQUFDLENBQXJFLEtBQXlFLEtBQUtGLFVBQUwsQ0FBZ0IsT0FBaEIsR0FBeUIsS0FBS0QsT0FBTCxFQUF6QixFQUF3QyxLQUFLRyxLQUFMLENBQVcsVUFBWCxDQUF4QyxFQUErRCxLQUFLLEtBQUtwckIsT0FBTCxDQUFhLFNBQWIsQ0FBN0ksQ0FBeEQsQ0FBbkU7QUFBb1MsR0FBMTdOLEVBQTI3TjRDLEVBQUVrQyxTQUFGLENBQVlxbUIscUJBQVosR0FBa0MsWUFBVTtBQUFDM0YsTUFBRTBHLE9BQUYsQ0FBVW5MLFVBQVYsSUFBc0IsS0FBS29KLE1BQUwsQ0FBWWxlLEVBQVosQ0FBZXVaLEVBQUUwRyxPQUFGLENBQVVuTCxVQUFWLENBQXFCdmQsR0FBckIsR0FBeUIsV0FBeEMsRUFBb0RnaUIsRUFBRTRCLEtBQUYsQ0FBUSxLQUFLK0UsZUFBYixFQUE2QixJQUE3QixDQUFwRCxDQUF0QixFQUE4RyxLQUFLdkcsUUFBTCxDQUFjOEMsVUFBZCxLQUEyQixDQUFDLENBQTVCLElBQStCLEtBQUt6YyxFQUFMLENBQVF3WixDQUFSLEVBQVUsUUFBVixFQUFtQixLQUFLSyxTQUFMLENBQWVnRyxpQkFBbEMsQ0FBN0ksRUFBa00sS0FBS2xHLFFBQUwsQ0FBY2lDLFNBQWQsS0FBMEIsS0FBSy9uQixRQUFMLENBQWM0USxRQUFkLENBQXVCLEtBQUttQixPQUFMLENBQWF5WCxTQUFwQyxHQUErQyxLQUFLYSxNQUFMLENBQVlsZSxFQUFaLENBQWUsb0JBQWYsRUFBb0N1WixFQUFFNEIsS0FBRixDQUFRLEtBQUtnRixXQUFiLEVBQXlCLElBQXpCLENBQXBDLENBQS9DLEVBQW1ILEtBQUtqQyxNQUFMLENBQVlsZSxFQUFaLENBQWUseUNBQWYsRUFBeUQsWUFBVTtBQUFDLGFBQU0sQ0FBQyxDQUFQO0FBQVMsS0FBN0UsQ0FBN0ksQ0FBbE0sRUFBK1osS0FBSzJaLFFBQUwsQ0FBY2tDLFNBQWQsS0FBMEIsS0FBS3FDLE1BQUwsQ0FBWWxlLEVBQVosQ0FBZSxxQkFBZixFQUFxQ3VaLEVBQUU0QixLQUFGLENBQVEsS0FBS2dGLFdBQWIsRUFBeUIsSUFBekIsQ0FBckMsR0FBcUUsS0FBS2pDLE1BQUwsQ0FBWWxlLEVBQVosQ0FBZSxzQkFBZixFQUFzQ3VaLEVBQUU0QixLQUFGLENBQVEsS0FBS2lGLFNBQWIsRUFBdUIsSUFBdkIsQ0FBdEMsQ0FBL0YsQ0FBL1o7QUFBbWtCLEdBQTNpUCxFQUE0aVB6cEIsRUFBRWtDLFNBQUYsQ0FBWXNuQixXQUFaLEdBQXdCLFVBQVMzRyxDQUFULEVBQVc7QUFBQyxRQUFJRSxJQUFFLElBQU4sQ0FBVyxNQUFJRixFQUFFcmIsS0FBTixLQUFjb2IsRUFBRTBHLE9BQUYsQ0FBVUksU0FBVixJQUFxQjNHLElBQUUsS0FBS3dFLE1BQUwsQ0FBWWpkLEdBQVosQ0FBZ0IsV0FBaEIsRUFBNkI3RixPQUE3QixDQUFxQyxZQUFyQyxFQUFrRCxFQUFsRCxFQUFzRDFFLEtBQXRELENBQTRELEdBQTVELENBQUYsRUFBbUVnakIsSUFBRSxFQUFDblMsR0FBRW1TLEVBQUUsT0FBS0EsRUFBRWxrQixNQUFQLEdBQWMsRUFBZCxHQUFpQixDQUFuQixDQUFILEVBQXlCa1MsR0FBRWdTLEVBQUUsT0FBS0EsRUFBRWxrQixNQUFQLEdBQWMsRUFBZCxHQUFpQixDQUFuQixDQUEzQixFQUExRixLQUE4SWtrQixJQUFFLEtBQUt3RSxNQUFMLENBQVk1Z0IsUUFBWixFQUFGLEVBQXlCb2MsSUFBRSxFQUFDblMsR0FBRSxLQUFLb1MsUUFBTCxDQUFjNW1CLEdBQWQsR0FBa0IybUIsRUFBRXpkLElBQUYsR0FBTyxLQUFLaWlCLE1BQUwsQ0FBWTVoQixLQUFaLEVBQVAsR0FBMkIsS0FBS0EsS0FBTCxFQUEzQixHQUF3QyxLQUFLcWQsUUFBTCxDQUFjcUMsTUFBeEUsR0FBK0V0QyxFQUFFemQsSUFBcEYsRUFBeUZ5TCxHQUFFZ1MsRUFBRTNkLEdBQTdGLEVBQXpLLEdBQTRRLEtBQUt5RCxFQUFMLENBQVEsV0FBUixNQUF1QitaLEVBQUUwRyxPQUFGLENBQVVJLFNBQVYsR0FBb0IsS0FBS3hjLE9BQUwsQ0FBYTZWLEVBQUVuUyxDQUFmLENBQXBCLEdBQXNDLEtBQUsyVyxNQUFMLENBQVlsTyxJQUFaLEVBQXRDLEVBQXlELEtBQUtpUCxVQUFMLENBQWdCLFVBQWhCLENBQWhGLENBQTVRLEVBQXlYLEtBQUtwckIsUUFBTCxDQUFja2tCLFdBQWQsQ0FBMEIsS0FBS25TLE9BQUwsQ0FBYTZYLFNBQXZDLEVBQWlELGdCQUFjakUsRUFBRTVrQixJQUFqRSxDQUF6WCxFQUFnYyxLQUFLMHJCLEtBQUwsQ0FBVyxDQUFYLENBQWhjLEVBQThjLEtBQUs1RixLQUFMLENBQVdDLElBQVgsR0FBaUIsSUFBSXRoQixJQUFKLEVBQUQsQ0FBV0UsT0FBWCxFQUE5ZCxFQUFtZixLQUFLbWhCLEtBQUwsQ0FBV3phLE1BQVgsR0FBa0JzWixFQUFFQyxFQUFFdlosTUFBSixDQUFyZ0IsRUFBaWhCLEtBQUt5YSxLQUFMLENBQVdHLEtBQVgsQ0FBaUJ4Z0IsS0FBakIsR0FBdUJxZixDQUF4aUIsRUFBMGlCLEtBQUtnQixLQUFMLENBQVdHLEtBQVgsQ0FBaUIvWixPQUFqQixHQUF5QjRZLENBQW5rQixFQUFxa0IsS0FBS2dCLEtBQUwsQ0FBV0UsT0FBWCxHQUFtQixLQUFLQSxPQUFMLENBQWFwQixDQUFiLENBQXhsQixFQUF3bUJELEVBQUVFLENBQUYsRUFBS3paLEVBQUwsQ0FBUSxvQ0FBUixFQUE2Q3VaLEVBQUU0QixLQUFGLENBQVEsS0FBS2lGLFNBQWIsRUFBdUIsSUFBdkIsQ0FBN0MsQ0FBeG1CLEVBQW1yQjdHLEVBQUVFLENBQUYsRUFBSzdVLEdBQUwsQ0FBUyx1Q0FBVCxFQUFpRDJVLEVBQUU0QixLQUFGLENBQVEsVUFBUzNCLENBQVQsRUFBVztBQUFDLFVBQUlFLElBQUUsS0FBSzZHLFVBQUwsQ0FBZ0IsS0FBSzdGLEtBQUwsQ0FBV0UsT0FBM0IsRUFBbUMsS0FBS0EsT0FBTCxDQUFhcEIsQ0FBYixDQUFuQyxDQUFOLENBQTBERCxFQUFFRSxDQUFGLEVBQUt6WixFQUFMLENBQVEsdUNBQVIsRUFBZ0R1WixFQUFFNEIsS0FBRixDQUFRLEtBQUtxRixVQUFiLEVBQXdCLElBQXhCLENBQWhELEdBQStFOXFCLEtBQUtxUyxHQUFMLENBQVMyUixFQUFFblMsQ0FBWCxJQUFjN1IsS0FBS3FTLEdBQUwsQ0FBUzJSLEVBQUVoUyxDQUFYLENBQWQsSUFBNkIsS0FBS2xJLEVBQUwsQ0FBUSxPQUFSLENBQTdCLEtBQWdEZ2EsRUFBRXRaLGNBQUYsSUFBbUIsS0FBSzRlLEtBQUwsQ0FBVyxVQUFYLENBQW5CLEVBQTBDLEtBQUsvcUIsT0FBTCxDQUFhLE1BQWIsQ0FBMUYsQ0FBL0U7QUFBK0wsS0FBN1EsRUFBOFEsSUFBOVEsQ0FBakQsQ0FBanNCO0FBQXdnQyxHQUFubVIsRUFBb21SNEMsRUFBRWtDLFNBQUYsQ0FBWTJuQixVQUFaLEdBQXVCLFVBQVNqSCxDQUFULEVBQVc7QUFBQyxRQUFJQyxJQUFFLElBQU47QUFBQSxRQUFXQyxJQUFFLElBQWI7QUFBQSxRQUFrQkMsSUFBRSxJQUFwQjtBQUFBLFFBQXlCL2lCLElBQUUsS0FBSzRwQixVQUFMLENBQWdCLEtBQUs3RixLQUFMLENBQVdFLE9BQTNCLEVBQW1DLEtBQUtBLE9BQUwsQ0FBYXJCLENBQWIsQ0FBbkMsQ0FBM0I7QUFBQSxRQUErRTZFLElBQUUsS0FBS21DLFVBQUwsQ0FBZ0IsS0FBSzdGLEtBQUwsQ0FBV0csS0FBWCxDQUFpQnhnQixLQUFqQyxFQUF1QzFELENBQXZDLENBQWpGLENBQTJILEtBQUs2SSxFQUFMLENBQVEsVUFBUixNQUFzQitaLEVBQUVyWixjQUFGLElBQW1CLEtBQUt5WixRQUFMLENBQWM4QixJQUFkLElBQW9CakMsSUFBRSxLQUFLb0YsV0FBTCxDQUFpQixLQUFLRixPQUFMLEVBQWpCLENBQUYsRUFBbUNqRixJQUFFLEtBQUttRixXQUFMLENBQWlCLEtBQUtELE9BQUwsS0FBZSxDQUFoQyxJQUFtQ25GLENBQXhFLEVBQTBFNEUsRUFBRTdXLENBQUYsR0FBSSxDQUFDLENBQUM2VyxFQUFFN1csQ0FBRixHQUFJaVMsQ0FBTCxJQUFRQyxDQUFSLEdBQVVBLENBQVgsSUFBY0EsQ0FBZCxHQUFnQkQsQ0FBbEgsS0FBc0hBLElBQUUsS0FBS0csUUFBTCxDQUFjNW1CLEdBQWQsR0FBa0IsS0FBSzZyQixXQUFMLENBQWlCLEtBQUtELE9BQUwsRUFBakIsQ0FBbEIsR0FBbUQsS0FBS0MsV0FBTCxDQUFpQixLQUFLRixPQUFMLEVBQWpCLENBQXJELEVBQXNGakYsSUFBRSxLQUFLRSxRQUFMLENBQWM1bUIsR0FBZCxHQUFrQixLQUFLNnJCLFdBQUwsQ0FBaUIsS0FBS0YsT0FBTCxFQUFqQixDQUFsQixHQUFtRCxLQUFLRSxXQUFMLENBQWlCLEtBQUtELE9BQUwsRUFBakIsQ0FBM0ksRUFBNEtqRixJQUFFLEtBQUtDLFFBQUwsQ0FBY21DLFFBQWQsR0FBdUIsQ0FBQyxDQUFELEdBQUdubEIsRUFBRTRRLENBQUwsR0FBTyxDQUE5QixHQUFnQyxDQUE5TSxFQUFnTjZXLEVBQUU3VyxDQUFGLEdBQUk3UixLQUFLd0UsR0FBTCxDQUFTeEUsS0FBS2tYLEdBQUwsQ0FBU3dSLEVBQUU3VyxDQUFYLEVBQWFpUyxJQUFFRSxDQUFmLENBQVQsRUFBMkJELElBQUVDLENBQTdCLENBQTFVLENBQW5CLEVBQThYLEtBQUtnQixLQUFMLENBQVdHLEtBQVgsQ0FBaUIvWixPQUFqQixHQUF5QnNkLENBQXZaLEVBQXlaLEtBQUt2YSxPQUFMLENBQWF1YSxFQUFFN1csQ0FBZixDQUEvYTtBQUFrYyxHQUFwc1MsRUFBcXNTNVEsRUFBRWtDLFNBQUYsQ0FBWXVuQixTQUFaLEdBQXNCLFVBQVM1RyxDQUFULEVBQVc7QUFBQyxRQUFJRSxJQUFFLEtBQUs2RyxVQUFMLENBQWdCLEtBQUs3RixLQUFMLENBQVdFLE9BQTNCLEVBQW1DLEtBQUtBLE9BQUwsQ0FBYXBCLENBQWIsQ0FBbkMsQ0FBTjtBQUFBLFFBQTBEN2lCLElBQUUsS0FBSytqQixLQUFMLENBQVdHLEtBQVgsQ0FBaUIvWixPQUE3RTtBQUFBLFFBQXFGc2QsSUFBRTFFLEVBQUVuUyxDQUFGLEdBQUksQ0FBSixHQUFNLEtBQUtvUyxRQUFMLENBQWM1bUIsR0FBcEIsR0FBd0IsTUFBeEIsR0FBK0IsT0FBdEgsQ0FBOEh3bUIsRUFBRUUsQ0FBRixFQUFLcFosR0FBTCxDQUFTLFdBQVQsR0FBc0IsS0FBS3hNLFFBQUwsQ0FBYzZFLFdBQWQsQ0FBMEIsS0FBS2tOLE9BQUwsQ0FBYTZYLFNBQXZDLENBQXRCLEVBQXdFLENBQUMsTUFBSS9ELEVBQUVuUyxDQUFOLElBQVMsS0FBSy9ILEVBQUwsQ0FBUSxVQUFSLENBQVQsSUFBOEIsQ0FBQyxLQUFLQSxFQUFMLENBQVEsT0FBUixDQUFoQyxNQUFvRCxLQUFLOGdCLEtBQUwsQ0FBVyxLQUFLM0csUUFBTCxDQUFjNkMsWUFBZCxJQUE0QixLQUFLN0MsUUFBTCxDQUFjMkMsVUFBckQsR0FBaUUsS0FBS3hiLE9BQUwsQ0FBYSxLQUFLb0ssT0FBTCxDQUFhdlUsRUFBRTRRLENBQWYsRUFBaUIsTUFBSW1TLEVBQUVuUyxDQUFOLEdBQVE2VyxDQUFSLEdBQVUsS0FBSzFELEtBQUwsQ0FBV2pKLFNBQXRDLENBQWIsQ0FBakUsRUFBZ0ksS0FBS3dOLFVBQUwsQ0FBZ0IsVUFBaEIsQ0FBaEksRUFBNEosS0FBS1MsTUFBTCxFQUE1SixFQUEwSyxLQUFLaEYsS0FBTCxDQUFXakosU0FBWCxHQUFxQjJNLENBQS9MLEVBQWlNLENBQUMxb0IsS0FBS3FTLEdBQUwsQ0FBUzJSLEVBQUVuUyxDQUFYLElBQWMsQ0FBZCxJQUFrQixJQUFJbE8sSUFBSixFQUFELENBQVdFLE9BQVgsS0FBcUIsS0FBS21oQixLQUFMLENBQVdDLElBQWhDLEdBQXFDLEdBQXZELEtBQTZELEtBQUtELEtBQUwsQ0FBV3phLE1BQVgsQ0FBa0IyRSxHQUFsQixDQUFzQixnQkFBdEIsRUFBdUMsWUFBVTtBQUFDLGFBQU0sQ0FBQyxDQUFQO0FBQVMsS0FBM0QsQ0FBbFQsQ0FBeEUsRUFBd2IsS0FBS3BGLEVBQUwsQ0FBUSxVQUFSLE1BQXNCLEtBQUsyZixLQUFMLENBQVcsVUFBWCxHQUF1QixLQUFLcHJCLE9BQUwsQ0FBYSxTQUFiLENBQTdDLENBQXhiO0FBQThmLEdBQW4yVCxFQUFvMlQ0QyxFQUFFa0MsU0FBRixDQUFZcVMsT0FBWixHQUFvQixVQUFTc08sQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxRQUFJQyxJQUFFLENBQUMsQ0FBUDtBQUFBLFFBQVMvaUIsSUFBRSxFQUFYO0FBQUEsUUFBY3luQixJQUFFLEtBQUs5aEIsS0FBTCxFQUFoQjtBQUFBLFFBQTZCZ2lCLElBQUUsS0FBS00sV0FBTCxFQUEvQixDQUFrRCxPQUFPLEtBQUtqRixRQUFMLENBQWNvQyxRQUFkLElBQXdCeEMsRUFBRTdrQixJQUFGLENBQU80cEIsQ0FBUCxFQUFTL0UsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXZ0YsQ0FBWCxFQUFhO0FBQUMsYUFBTSxXQUFTOUUsQ0FBVCxJQUFZRCxJQUFFK0UsSUFBRTVuQixDQUFoQixJQUFtQjZpQixJQUFFK0UsSUFBRTVuQixDQUF2QixHQUF5QitpQixJQUFFSCxDQUEzQixHQUE2QixZQUFVRSxDQUFWLElBQWFELElBQUUrRSxJQUFFSCxDQUFGLEdBQUl6bkIsQ0FBbkIsSUFBc0I2aUIsSUFBRStFLElBQUVILENBQUYsR0FBSXpuQixDQUE1QixHQUE4QitpQixJQUFFSCxJQUFFLENBQWxDLEdBQW9DLEtBQUtzRixFQUFMLENBQVFyRixDQUFSLEVBQVUsR0FBVixFQUFjK0UsQ0FBZCxLQUFrQixLQUFLTSxFQUFMLENBQVFyRixDQUFSLEVBQVUsR0FBVixFQUFjOEUsRUFBRS9FLElBQUUsQ0FBSixLQUFRZ0YsSUFBRUgsQ0FBeEIsQ0FBbEIsS0FBK0MxRSxJQUFFLFdBQVNELENBQVQsR0FBV0YsSUFBRSxDQUFiLEdBQWVBLENBQWhFLENBQWpFLEVBQW9JRyxNQUFJLENBQUMsQ0FBL0k7QUFBaUosS0FBdkssRUFBd0ssSUFBeEssQ0FBVCxDQUF4QixFQUFnTixLQUFLQyxRQUFMLENBQWM4QixJQUFkLEtBQXFCLEtBQUtvRCxFQUFMLENBQVFyRixDQUFSLEVBQVUsR0FBVixFQUFjOEUsRUFBRSxLQUFLSSxPQUFMLEVBQUYsQ0FBZCxJQUFpQ2hGLElBQUVGLElBQUUsS0FBS2tGLE9BQUwsRUFBckMsR0FBb0QsS0FBS0csRUFBTCxDQUFRckYsQ0FBUixFQUFVLEdBQVYsRUFBYzhFLEVBQUUsS0FBS0ssT0FBTCxFQUFGLENBQWQsTUFBbUNqRixJQUFFRixJQUFFLEtBQUttRixPQUFMLEVBQXZDLENBQXpFLENBQWhOLEVBQWlWakYsQ0FBeFY7QUFBMFYsR0FBbHhVLEVBQW14VS9pQixFQUFFa0MsU0FBRixDQUFZZ0wsT0FBWixHQUFvQixVQUFTMlYsQ0FBVCxFQUFXO0FBQUMsUUFBSUMsSUFBRSxLQUFLNkcsS0FBTCxLQUFhLENBQW5CLENBQXFCLEtBQUs5Z0IsRUFBTCxDQUFRLFdBQVIsS0FBc0IsS0FBSzBnQixlQUFMLEVBQXRCLEVBQTZDekcsTUFBSSxLQUFLcUYsS0FBTCxDQUFXLFdBQVgsR0FBd0IsS0FBSy9xQixPQUFMLENBQWEsV0FBYixDQUE1QixDQUE3QyxFQUFvR3dsQixFQUFFMEcsT0FBRixDQUFVUSxXQUFWLElBQXVCbEgsRUFBRTBHLE9BQUYsQ0FBVW5MLFVBQWpDLEdBQTRDLEtBQUtvSixNQUFMLENBQVlqZCxHQUFaLENBQWdCLEVBQUNvZixXQUFVLGlCQUFlN0csQ0FBZixHQUFpQixhQUE1QixFQUEwQzFFLFlBQVcsS0FBS3dMLEtBQUwsS0FBYSxHQUFiLEdBQWlCLEdBQXRFLEVBQWhCLENBQTVDLEdBQXdJN0csSUFBRSxLQUFLeUUsTUFBTCxDQUFZcmEsT0FBWixDQUFvQixFQUFDNUgsTUFBS3VkLElBQUUsSUFBUixFQUFwQixFQUFrQyxLQUFLOEcsS0FBTCxFQUFsQyxFQUErQyxLQUFLM0csUUFBTCxDQUFjaUQsY0FBN0QsRUFBNEVyRCxFQUFFNEIsS0FBRixDQUFRLEtBQUsrRSxlQUFiLEVBQTZCLElBQTdCLENBQTVFLENBQUYsR0FBa0gsS0FBS2hDLE1BQUwsQ0FBWWpkLEdBQVosQ0FBZ0IsRUFBQ2hGLE1BQUt1ZCxJQUFFLElBQVIsRUFBaEIsQ0FBOVY7QUFBNlgsR0FBcnNWLEVBQXNzVjdpQixFQUFFa0MsU0FBRixDQUFZMkcsRUFBWixHQUFlLFVBQVMrWixDQUFULEVBQVc7QUFBQyxXQUFPLEtBQUt1QixPQUFMLENBQWFoYSxPQUFiLENBQXFCeVksQ0FBckIsS0FBeUIsS0FBS3VCLE9BQUwsQ0FBYWhhLE9BQWIsQ0FBcUJ5WSxDQUFyQixJQUF3QixDQUF4RDtBQUEwRCxHQUEzeFYsRUFBNHhWNWlCLEVBQUVrQyxTQUFGLENBQVlpSSxPQUFaLEdBQW9CLFVBQVN5WSxDQUFULEVBQVc7QUFBQyxRQUFHQSxNQUFJRyxDQUFQLEVBQVMsT0FBTyxLQUFLSyxRQUFaLENBQXFCLElBQUcsTUFBSSxLQUFLSyxNQUFMLENBQVk1a0IsTUFBbkIsRUFBMEIsT0FBT2trQixDQUFQLENBQVMsSUFBR0gsSUFBRSxLQUFLaUYsU0FBTCxDQUFlakYsQ0FBZixDQUFGLEVBQW9CLEtBQUtRLFFBQUwsS0FBZ0JSLENBQXZDLEVBQXlDO0FBQUMsVUFBSUMsSUFBRSxLQUFLemxCLE9BQUwsQ0FBYSxRQUFiLEVBQXNCLEVBQUN1ckIsVUFBUyxFQUFDcHNCLE1BQUssVUFBTixFQUFpQm1PLE9BQU1rWSxDQUF2QixFQUFWLEVBQXRCLENBQU4sQ0FBa0VDLEVBQUUxbEIsSUFBRixLQUFTNGxCLENBQVQsS0FBYUgsSUFBRSxLQUFLaUYsU0FBTCxDQUFlaEYsRUFBRTFsQixJQUFqQixDQUFmLEdBQXVDLEtBQUtpbUIsUUFBTCxHQUFjUixDQUFyRCxFQUF1RCxLQUFLMEYsVUFBTCxDQUFnQixVQUFoQixDQUF2RCxFQUFtRixLQUFLbHJCLE9BQUwsQ0FBYSxTQUFiLEVBQXVCLEVBQUN1ckIsVUFBUyxFQUFDcHNCLE1BQUssVUFBTixFQUFpQm1PLE9BQU0sS0FBSzBZLFFBQTVCLEVBQVYsRUFBdkIsQ0FBbkY7QUFBNEosWUFBTyxLQUFLQSxRQUFaO0FBQXFCLEdBQTFwVyxFQUEycFdwakIsRUFBRWtDLFNBQUYsQ0FBWW9tQixVQUFaLEdBQXVCLFVBQVN6RixDQUFULEVBQVc7QUFBQyxXQUFNLGFBQVdELEVBQUUza0IsSUFBRixDQUFPNGtCLENBQVAsQ0FBWCxLQUF1QixLQUFLZ0IsWUFBTCxDQUFrQmhCLENBQWxCLElBQXFCLENBQUMsQ0FBdEIsRUFBd0IsS0FBS2hhLEVBQUwsQ0FBUSxPQUFSLEtBQWtCLEtBQUsyZixLQUFMLENBQVcsT0FBWCxDQUFqRSxHQUFzRjVGLEVBQUUxaUIsR0FBRixDQUFNLEtBQUsyakIsWUFBWCxFQUF3QixVQUFTakIsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxhQUFPQSxDQUFQO0FBQVMsS0FBL0MsQ0FBNUY7QUFBNkksR0FBMzBXLEVBQTQwVzdpQixFQUFFa0MsU0FBRixDQUFZMkwsS0FBWixHQUFrQixVQUFTK1UsQ0FBVCxFQUFXO0FBQUNBLFFBQUUsS0FBS2lGLFNBQUwsQ0FBZWpGLENBQWYsQ0FBRixFQUFvQkEsTUFBSUcsQ0FBSixLQUFRLEtBQUtNLE1BQUwsR0FBWSxDQUFaLEVBQWMsS0FBS0QsUUFBTCxHQUFjUixDQUE1QixFQUE4QixLQUFLbUgsUUFBTCxDQUFjLENBQUMsV0FBRCxFQUFhLFlBQWIsQ0FBZCxDQUE5QixFQUF3RSxLQUFLN2MsT0FBTCxDQUFhLEtBQUsrYSxXQUFMLENBQWlCckYsQ0FBakIsQ0FBYixDQUF4RSxFQUEwRyxLQUFLb0gsT0FBTCxDQUFhLENBQUMsV0FBRCxFQUFhLFlBQWIsQ0FBYixDQUFsSCxDQUFwQjtBQUFnTCxHQUExaFgsRUFBMmhYaHFCLEVBQUVrQyxTQUFGLENBQVkybEIsU0FBWixHQUFzQixVQUFTakYsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxRQUFJQyxJQUFFLEtBQUtXLE1BQUwsQ0FBWTVrQixNQUFsQjtBQUFBLFFBQXlCbUIsSUFBRTZpQixJQUFFLENBQUYsR0FBSSxLQUFLYSxPQUFMLENBQWE3a0IsTUFBNUMsQ0FBbUQsT0FBTSxDQUFDLEtBQUtvckIsU0FBTCxDQUFlckgsQ0FBZixDQUFELElBQW9CRSxJQUFFLENBQXRCLEdBQXdCRixJQUFFRyxDQUExQixHQUE0QixDQUFDSCxJQUFFLENBQUYsSUFBS0EsS0FBR0UsSUFBRTlpQixDQUFYLE1BQWdCNGlCLElBQUUsQ0FBQyxDQUFDQSxJQUFFNWlCLElBQUUsQ0FBTCxJQUFROGlCLENBQVIsR0FBVUEsQ0FBWCxJQUFjQSxDQUFkLEdBQWdCOWlCLElBQUUsQ0FBcEMsQ0FBNUIsRUFBbUU0aUIsQ0FBekU7QUFBMkUsR0FBN3JYLEVBQThyWDVpQixFQUFFa0MsU0FBRixDQUFZb2xCLFFBQVosR0FBcUIsVUFBUzFFLENBQVQsRUFBVztBQUFDLFdBQU9BLEtBQUcsS0FBS2MsT0FBTCxDQUFhN2tCLE1BQWIsR0FBb0IsQ0FBdkIsRUFBeUIsS0FBS2dwQixTQUFMLENBQWVqRixDQUFmLEVBQWlCLENBQUMsQ0FBbEIsQ0FBaEM7QUFBcUQsR0FBcHhYLEVBQXF4WDVpQixFQUFFa0MsU0FBRixDQUFZOGxCLE9BQVosR0FBb0IsVUFBU3BGLENBQVQsRUFBVztBQUFDLFFBQUlDLENBQUo7QUFBQSxRQUFNQyxDQUFOO0FBQUEsUUFBUUMsQ0FBUjtBQUFBLFFBQVUvaUIsSUFBRSxLQUFLZ2pCLFFBQWpCO0FBQUEsUUFBMEJ5RSxJQUFFLEtBQUtuRSxZQUFMLENBQWtCemtCLE1BQTlDLENBQXFELElBQUdtQixFQUFFOGtCLElBQUwsRUFBVTJDLElBQUUsS0FBSy9ELE9BQUwsQ0FBYTdrQixNQUFiLEdBQW9CLENBQXBCLEdBQXNCLEtBQUs0a0IsTUFBTCxDQUFZNWtCLE1BQWxDLEdBQXlDLENBQTNDLENBQVYsS0FBNEQsSUFBR21CLEVBQUV5bEIsU0FBRixJQUFhemxCLEVBQUV1bEIsS0FBbEIsRUFBd0I7QUFBQyxXQUFJMUMsSUFBRSxLQUFLWSxNQUFMLENBQVk1a0IsTUFBZCxFQUFxQmlrQixJQUFFLEtBQUtXLE1BQUwsQ0FBWSxFQUFFWixDQUFkLEVBQWlCbGQsS0FBakIsRUFBdkIsRUFBZ0RvZCxJQUFFLEtBQUs3bEIsUUFBTCxDQUFjeUksS0FBZCxFQUF0RCxFQUE0RWtkLFFBQU1DLEtBQUcsS0FBS1csTUFBTCxDQUFZWixDQUFaLEVBQWVsZCxLQUFmLEtBQXVCLEtBQUtxZCxRQUFMLENBQWNxQyxNQUF4QyxFQUErQyxFQUFFdkMsSUFBRUMsQ0FBSixDQUFyRCxDQUE1RSxLQUEySTBFLElBQUU1RSxJQUFFLENBQUo7QUFBTSxLQUExSyxNQUErSzRFLElBQUV6bkIsRUFBRStrQixNQUFGLEdBQVMsS0FBS3RCLE1BQUwsQ0FBWTVrQixNQUFaLEdBQW1CLENBQTVCLEdBQThCLEtBQUs0a0IsTUFBTCxDQUFZNWtCLE1BQVosR0FBbUJtQixFQUFFd08sS0FBckQsQ0FBMkQsT0FBT29VLE1BQUk2RSxLQUFHLEtBQUsvRCxPQUFMLENBQWE3a0IsTUFBYixHQUFvQixDQUEzQixHQUE4QkUsS0FBS3dFLEdBQUwsQ0FBU2trQixDQUFULEVBQVcsQ0FBWCxDQUFyQztBQUFtRCxHQUFuc1ksRUFBb3NZem5CLEVBQUVrQyxTQUFGLENBQVk2bEIsT0FBWixHQUFvQixVQUFTbkYsQ0FBVCxFQUFXO0FBQUMsV0FBT0EsSUFBRSxDQUFGLEdBQUksS0FBS2MsT0FBTCxDQUFhN2tCLE1BQWIsR0FBb0IsQ0FBL0I7QUFBaUMsR0FBcndZLEVBQXN3WW1CLEVBQUVrQyxTQUFGLENBQVlzTSxLQUFaLEdBQWtCLFVBQVNvVSxDQUFULEVBQVc7QUFBQyxXQUFPQSxNQUFJRyxDQUFKLEdBQU0sS0FBS1UsTUFBTCxDQUFZcmtCLEtBQVosRUFBTixJQUEyQndqQixJQUFFLEtBQUtpRixTQUFMLENBQWVqRixDQUFmLEVBQWlCLENBQUMsQ0FBbEIsQ0FBRixFQUF1QixLQUFLYSxNQUFMLENBQVliLENBQVosQ0FBbEQsQ0FBUDtBQUF5RSxHQUE3MlksRUFBODJZNWlCLEVBQUVrQyxTQUFGLENBQVlnb0IsT0FBWixHQUFvQixVQUFTdEgsQ0FBVCxFQUFXO0FBQUMsV0FBT0EsTUFBSUcsQ0FBSixHQUFNLEtBQUtZLFFBQUwsQ0FBY3ZrQixLQUFkLEVBQU4sSUFBNkJ3akIsSUFBRSxLQUFLaUYsU0FBTCxDQUFlakYsQ0FBZixFQUFpQixDQUFDLENBQWxCLENBQUYsRUFBdUIsS0FBS2UsUUFBTCxDQUFjZixDQUFkLENBQXBELENBQVA7QUFBNkUsR0FBMzlZLEVBQTQ5WTVpQixFQUFFa0MsU0FBRixDQUFZaW9CLE1BQVosR0FBbUIsVUFBU3RILENBQVQsRUFBVztBQUFDLFFBQUlDLElBQUUsS0FBS1ksT0FBTCxDQUFhN2tCLE1BQWIsR0FBb0IsQ0FBMUI7QUFBQSxRQUE0Qm1CLElBQUU4aUIsSUFBRSxLQUFLVyxNQUFMLENBQVk1a0IsTUFBNUM7QUFBQSxRQUFtRDRvQixJQUFFLFNBQUZBLENBQUUsQ0FBUzdFLENBQVQsRUFBVztBQUFDLGFBQU9BLElBQUUsQ0FBRixLQUFNLENBQU4sR0FBUTVpQixJQUFFNGlCLElBQUUsQ0FBWixHQUFjRSxJQUFFLENBQUNGLElBQUUsQ0FBSCxJQUFNLENBQTdCO0FBQStCLEtBQWhHLENBQWlHLE9BQU9DLE1BQUlFLENBQUosR0FBTUgsRUFBRTFpQixHQUFGLENBQU0sS0FBS3dqQixPQUFYLEVBQW1CLFVBQVNkLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsYUFBTzRFLEVBQUU1RSxDQUFGLENBQVA7QUFBWSxLQUE3QyxDQUFOLEdBQXFERCxFQUFFMWlCLEdBQUYsQ0FBTSxLQUFLd2pCLE9BQVgsRUFBbUIsVUFBU2QsQ0FBVCxFQUFXRSxDQUFYLEVBQWE7QUFBQyxhQUFPRixNQUFJQyxDQUFKLEdBQU00RSxFQUFFM0UsQ0FBRixDQUFOLEdBQVcsSUFBbEI7QUFBdUIsS0FBeEQsQ0FBNUQ7QUFBc0gsR0FBbHRaLEVBQW10WjlpQixFQUFFa0MsU0FBRixDQUFZeW5CLEtBQVosR0FBa0IsVUFBUy9HLENBQVQsRUFBVztBQUFDLFdBQU9BLE1BQUlHLENBQUosS0FBUSxLQUFLTSxNQUFMLEdBQVlULENBQXBCLEdBQXVCLEtBQUtTLE1BQW5DO0FBQTBDLEdBQTN4WixFQUE0eFpyakIsRUFBRWtDLFNBQUYsQ0FBWStsQixXQUFaLEdBQXdCLFVBQVNwRixDQUFULEVBQVc7QUFBQyxRQUFJQyxDQUFKO0FBQUEsUUFBTTlpQixJQUFFLENBQVI7QUFBQSxRQUFVeW5CLElBQUU1RSxJQUFFLENBQWQsQ0FBZ0IsT0FBT0EsTUFBSUUsQ0FBSixHQUFNSCxFQUFFMWlCLEdBQUYsQ0FBTSxLQUFLb2pCLFlBQVgsRUFBd0JWLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsYUFBTyxLQUFLb0YsV0FBTCxDQUFpQnBGLENBQWpCLENBQVA7QUFBMkIsS0FBakQsRUFBa0QsSUFBbEQsQ0FBeEIsQ0FBTixJQUF3RixLQUFLRyxRQUFMLENBQWMrQixNQUFkLElBQXNCLEtBQUsvQixRQUFMLENBQWM1bUIsR0FBZCxLQUFvQjRELElBQUUsQ0FBQyxDQUFILEVBQUt5bkIsSUFBRTVFLElBQUUsQ0FBN0IsR0FBZ0NDLElBQUUsS0FBS1EsWUFBTCxDQUFrQlQsQ0FBbEIsQ0FBbEMsRUFBdURDLEtBQUcsQ0FBQyxLQUFLbmQsS0FBTCxLQUFhbWQsQ0FBYixJQUFnQixLQUFLUSxZQUFMLENBQWtCbUUsQ0FBbEIsS0FBc0IsQ0FBdEMsQ0FBRCxJQUEyQyxDQUEzQyxHQUE2Q3puQixDQUE3SCxJQUFnSThpQixJQUFFLEtBQUtRLFlBQUwsQ0FBa0JtRSxDQUFsQixLQUFzQixDQUF4SixFQUEwSjNFLElBQUUvakIsS0FBSzJvQixJQUFMLENBQVU1RSxDQUFWLENBQXBQLENBQVA7QUFBeVEsR0FBemxhLEVBQTBsYTlpQixFQUFFa0MsU0FBRixDQUFZbUwsUUFBWixHQUFxQixVQUFTdVYsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZTtBQUFDLFdBQU8sTUFBSUEsQ0FBSixHQUFNLENBQU4sR0FBUS9qQixLQUFLa1gsR0FBTCxDQUFTbFgsS0FBS3dFLEdBQUwsQ0FBU3hFLEtBQUtxUyxHQUFMLENBQVN5UixJQUFFRCxDQUFYLENBQVQsRUFBdUIsQ0FBdkIsQ0FBVCxFQUFtQyxDQUFuQyxJQUFzQzdqQixLQUFLcVMsR0FBTCxDQUFTMFIsS0FBRyxLQUFLRSxRQUFMLENBQWMyQyxVQUExQixDQUFyRDtBQUEyRixHQUExdGEsRUFBMnRhM2xCLEVBQUVrQyxTQUFGLENBQVlrb0IsRUFBWixHQUFlLFVBQVN4SCxDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFFBQUlDLElBQUUsS0FBSzNZLE9BQUwsRUFBTjtBQUFBLFFBQXFCNFksSUFBRSxJQUF2QjtBQUFBLFFBQTRCL2lCLElBQUU0aUIsSUFBRSxLQUFLMEUsUUFBTCxDQUFjeEUsQ0FBZCxDQUFoQztBQUFBLFFBQWlEMkUsSUFBRSxDQUFDem5CLElBQUUsQ0FBSCxLQUFPQSxJQUFFLENBQVQsQ0FBbkQ7QUFBQSxRQUErRDJuQixJQUFFLEtBQUtsRSxNQUFMLENBQVk1a0IsTUFBN0U7QUFBQSxRQUFvRitvQixJQUFFLEtBQUtHLE9BQUwsRUFBdEY7QUFBQSxRQUFxR3hvQixJQUFFLEtBQUt5b0IsT0FBTCxFQUF2RyxDQUFzSCxLQUFLaEYsUUFBTCxDQUFjOEIsSUFBZCxJQUFvQixDQUFDLEtBQUs5QixRQUFMLENBQWNnQyxNQUFmLElBQXVCam1CLEtBQUtxUyxHQUFMLENBQVNwUixDQUFULElBQVkybkIsSUFBRSxDQUFyQyxLQUF5QzNuQixLQUFHeW5CLElBQUUsQ0FBQyxDQUFILEdBQUtFLENBQWpELEdBQW9EL0UsSUFBRUUsSUFBRTlpQixDQUF4RCxFQUEwRCtpQixJQUFFLENBQUMsQ0FBQ0gsSUFBRWdGLENBQUgsSUFBTUQsQ0FBTixHQUFRQSxDQUFULElBQVlBLENBQVosR0FBY0MsQ0FBMUUsRUFBNEU3RSxNQUFJSCxDQUFKLElBQU9HLElBQUUvaUIsQ0FBRixJQUFLVCxDQUFaLElBQWV3akIsSUFBRS9pQixDQUFGLEdBQUksQ0FBbkIsS0FBdUI4aUIsSUFBRUMsSUFBRS9pQixDQUFKLEVBQU00aUIsSUFBRUcsQ0FBUixFQUFVLEtBQUtsVixLQUFMLENBQVdpVixDQUFYLENBQWpDLENBQWhHLElBQWlKLEtBQUtFLFFBQUwsQ0FBY2dDLE1BQWQsSUFBc0J6bEIsS0FBRyxDQUFILEVBQUtxakIsSUFBRSxDQUFDQSxJQUFFcmpCLENBQUYsR0FBSUEsQ0FBTCxJQUFRQSxDQUFyQyxJQUF3Q3FqQixJQUFFN2pCLEtBQUt3RSxHQUFMLENBQVNxa0IsQ0FBVCxFQUFXN29CLEtBQUtrWCxHQUFMLENBQVMxVyxDQUFULEVBQVdxakIsQ0FBWCxDQUFYLENBQTNMLEVBQXFOLEtBQUsrRyxLQUFMLENBQVcsS0FBS3RjLFFBQUwsQ0FBY3lWLENBQWQsRUFBZ0JGLENBQWhCLEVBQWtCQyxDQUFsQixDQUFYLENBQXJOLEVBQXNQLEtBQUsxWSxPQUFMLENBQWF5WSxDQUFiLENBQXRQLEVBQXNRLEtBQUsxbEIsUUFBTCxDQUFjMkwsRUFBZCxDQUFpQixVQUFqQixLQUE4QixLQUFLa2dCLE1BQUwsRUFBcFM7QUFBa1QsR0FBaHFiLEVBQWlxYi9vQixFQUFFa0MsU0FBRixDQUFZaVUsSUFBWixHQUFpQixVQUFTeU0sQ0FBVCxFQUFXO0FBQUNBLFFBQUVBLEtBQUcsQ0FBQyxDQUFOLEVBQVEsS0FBS3dILEVBQUwsQ0FBUSxLQUFLOUMsUUFBTCxDQUFjLEtBQUtuZCxPQUFMLEVBQWQsSUFBOEIsQ0FBdEMsRUFBd0N5WSxDQUF4QyxDQUFSO0FBQW1ELEdBQWp2YixFQUFrdmI1aUIsRUFBRWtDLFNBQUYsQ0FBWW1vQixJQUFaLEdBQWlCLFVBQVN6SCxDQUFULEVBQVc7QUFBQ0EsUUFBRUEsS0FBRyxDQUFDLENBQU4sRUFBUSxLQUFLd0gsRUFBTCxDQUFRLEtBQUs5QyxRQUFMLENBQWMsS0FBS25kLE9BQUwsRUFBZCxJQUE4QixDQUF0QyxFQUF3Q3lZLENBQXhDLENBQVI7QUFBbUQsR0FBbDBiLEVBQW0wYjVpQixFQUFFa0MsU0FBRixDQUFZcW5CLGVBQVosR0FBNEIsVUFBUzNHLENBQVQsRUFBVztBQUFDLFFBQUdBLE1BQUlHLENBQUosS0FBUUgsRUFBRTNQLGVBQUYsSUFBb0IsQ0FBQzJQLEVBQUV0WixNQUFGLElBQVVzWixFQUFFMEgsVUFBWixJQUF3QjFILEVBQUUySCxjQUEzQixNQUE2QyxLQUFLaEQsTUFBTCxDQUFZdmMsR0FBWixDQUFnQixDQUFoQixDQUF6RSxDQUFILEVBQWdHLE9BQU0sQ0FBQyxDQUFQLENBQVMsS0FBS3dkLEtBQUwsQ0FBVyxXQUFYLEdBQXdCLEtBQUtwckIsT0FBTCxDQUFhLFlBQWIsQ0FBeEI7QUFBbUQsR0FBdmdjLEVBQXdnYzRDLEVBQUVrQyxTQUFGLENBQVl1bUIsUUFBWixHQUFxQixZQUFVO0FBQUMsUUFBSTFGLENBQUosQ0FBTSxPQUFPLEtBQUs5VCxPQUFMLENBQWErVyxxQkFBYixLQUFxQ25ELENBQXJDLEdBQXVDRSxJQUFFSCxFQUFFLEtBQUszVCxPQUFMLENBQWErVyxxQkFBZixFQUFzQ3JnQixLQUF0QyxFQUF6QyxHQUF1RmtkLEVBQUUySCxVQUFGLEdBQWF6SCxJQUFFRixFQUFFMkgsVUFBakIsR0FBNEIxSCxFQUFFN1MsZUFBRixJQUFtQjZTLEVBQUU3UyxlQUFGLENBQWtCd2EsV0FBckMsR0FBaUQxSCxJQUFFRCxFQUFFN1MsZUFBRixDQUFrQndhLFdBQXJFLEdBQWlGOXJCLFFBQVFrQixJQUFSLENBQWEsZ0NBQWIsQ0FBcE0sRUFBbVBrakIsQ0FBMVA7QUFBNFAsR0FBMXljLEVBQTJ5Yy9pQixFQUFFa0MsU0FBRixDQUFZdUMsT0FBWixHQUFvQixVQUFTb2UsQ0FBVCxFQUFXO0FBQUMsU0FBSzBFLE1BQUwsQ0FBWW1ELEtBQVosSUFBb0IsS0FBS2pILE1BQUwsR0FBWSxFQUFoQyxFQUFtQ1osTUFBSUEsSUFBRUEsYUFBYW5lLE1BQWIsR0FBb0JtZSxDQUFwQixHQUFzQkQsRUFBRUMsQ0FBRixDQUE1QixDQUFuQyxFQUFxRSxLQUFLRyxRQUFMLENBQWNrRCxrQkFBZCxLQUFtQ3JELElBQUVBLEVBQUVwakIsSUFBRixDQUFPLE1BQUksS0FBS3VqQixRQUFMLENBQWNrRCxrQkFBekIsQ0FBckMsQ0FBckUsRUFBd0pyRCxFQUFFamEsTUFBRixDQUFTLFlBQVU7QUFBQyxhQUFPLE1BQUksS0FBSytoQixRQUFoQjtBQUF5QixLQUE3QyxFQUErQzVzQixJQUEvQyxDQUFvRDZrQixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDQSxVQUFFLEtBQUtnRyxPQUFMLENBQWFoRyxDQUFiLENBQUYsRUFBa0IsS0FBSzBFLE1BQUwsQ0FBWXpQLE1BQVosQ0FBbUIrSyxDQUFuQixDQUFsQixFQUF3QyxLQUFLWSxNQUFMLENBQVlwbUIsSUFBWixDQUFpQndsQixDQUFqQixDQUF4QyxFQUE0RCxLQUFLYyxRQUFMLENBQWN0bUIsSUFBZCxDQUFtQixJQUFFd2xCLEVBQUVwakIsSUFBRixDQUFPLGNBQVAsRUFBdUJDLE9BQXZCLENBQStCLGNBQS9CLEVBQStDckQsSUFBL0MsQ0FBb0QsWUFBcEQsQ0FBRixJQUFxRSxDQUF4RixDQUE1RDtBQUF1SixLQUE3SyxFQUE4SyxJQUE5SyxDQUFwRCxDQUF4SixFQUFpWSxLQUFLd1IsS0FBTCxDQUFXLEtBQUtvYyxTQUFMLENBQWUsS0FBS2pILFFBQUwsQ0FBYzBDLGFBQTdCLElBQTRDLEtBQUsxQyxRQUFMLENBQWMwQyxhQUExRCxHQUF3RSxDQUFuRixDQUFqWSxFQUF1ZCxLQUFLNEMsVUFBTCxDQUFnQixPQUFoQixDQUF2ZDtBQUFnZixHQUEzemQsRUFBNHpkdG9CLEVBQUVrQyxTQUFGLENBQVl5VSxHQUFaLEdBQWdCLFVBQVNrTSxDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFFBQUk5aUIsSUFBRSxLQUFLc25CLFFBQUwsQ0FBYyxLQUFLbEUsUUFBbkIsQ0FBTixDQUFtQ04sSUFBRUEsTUFBSUMsQ0FBSixHQUFNLEtBQUtVLE1BQUwsQ0FBWTVrQixNQUFsQixHQUF5QixLQUFLZ3BCLFNBQUwsQ0FBZS9FLENBQWYsRUFBaUIsQ0FBQyxDQUFsQixDQUEzQixFQUFnREQsSUFBRUEsYUFBYW5lLE1BQWIsR0FBb0JtZSxDQUFwQixHQUFzQkQsRUFBRUMsQ0FBRixDQUF4RSxFQUE2RSxLQUFLemxCLE9BQUwsQ0FBYSxLQUFiLEVBQW1CLEVBQUMwckIsU0FBUWpHLENBQVQsRUFBV2xjLFVBQVNtYyxDQUFwQixFQUFuQixDQUE3RSxFQUF3SEQsSUFBRSxLQUFLZ0csT0FBTCxDQUFhaEcsQ0FBYixDQUExSCxFQUEwSSxNQUFJLEtBQUtZLE1BQUwsQ0FBWTVrQixNQUFoQixJQUF3QmlrQixNQUFJLEtBQUtXLE1BQUwsQ0FBWTVrQixNQUF4QyxJQUFnRCxNQUFJLEtBQUs0a0IsTUFBTCxDQUFZNWtCLE1BQWhCLElBQXdCLEtBQUswb0IsTUFBTCxDQUFZelAsTUFBWixDQUFtQitLLENBQW5CLENBQXhCLEVBQThDLE1BQUksS0FBS1ksTUFBTCxDQUFZNWtCLE1BQWhCLElBQXdCLEtBQUs0a0IsTUFBTCxDQUFZWCxJQUFFLENBQWQsRUFBaUI4SCxLQUFqQixDQUF1Qi9ILENBQXZCLENBQXRFLEVBQWdHLEtBQUtZLE1BQUwsQ0FBWXBtQixJQUFaLENBQWlCd2xCLENBQWpCLENBQWhHLEVBQW9ILEtBQUtjLFFBQUwsQ0FBY3RtQixJQUFkLENBQW1CLElBQUV3bEIsRUFBRXBqQixJQUFGLENBQU8sY0FBUCxFQUF1QkMsT0FBdkIsQ0FBK0IsY0FBL0IsRUFBK0NyRCxJQUEvQyxDQUFvRCxZQUFwRCxDQUFGLElBQXFFLENBQXhGLENBQXBLLEtBQWlRLEtBQUtvbkIsTUFBTCxDQUFZWCxDQUFaLEVBQWUrSCxNQUFmLENBQXNCaEksQ0FBdEIsR0FBeUIsS0FBS1ksTUFBTCxDQUFZbG1CLE1BQVosQ0FBbUJ1bEIsQ0FBbkIsRUFBcUIsQ0FBckIsRUFBdUJELENBQXZCLENBQXpCLEVBQW1ELEtBQUtjLFFBQUwsQ0FBY3BtQixNQUFkLENBQXFCdWxCLENBQXJCLEVBQXVCLENBQXZCLEVBQXlCLElBQUVELEVBQUVwakIsSUFBRixDQUFPLGNBQVAsRUFBdUJDLE9BQXZCLENBQStCLGNBQS9CLEVBQStDckQsSUFBL0MsQ0FBb0QsWUFBcEQsQ0FBRixJQUFxRSxDQUE5RixDQUFwVCxDQUExSSxFQUFnaUIsS0FBS29uQixNQUFMLENBQVl6akIsQ0FBWixLQUFnQixLQUFLNk4sS0FBTCxDQUFXLEtBQUs0VixNQUFMLENBQVl6akIsQ0FBWixFQUFla2QsS0FBZixFQUFYLENBQWhqQixFQUFtbEIsS0FBS29MLFVBQUwsQ0FBZ0IsT0FBaEIsQ0FBbmxCLEVBQTRtQixLQUFLbHJCLE9BQUwsQ0FBYSxPQUFiLEVBQXFCLEVBQUMwckIsU0FBUWpHLENBQVQsRUFBV2xjLFVBQVNtYyxDQUFwQixFQUFyQixDQUE1bUI7QUFBeXBCLEdBQXRoZixFQUF1aGY5aUIsRUFBRWtDLFNBQUYsQ0FBWThYLE1BQVosR0FBbUIsVUFBUzRJLENBQVQsRUFBVztBQUFDQSxRQUFFLEtBQUtpRixTQUFMLENBQWVqRixDQUFmLEVBQWlCLENBQUMsQ0FBbEIsQ0FBRixFQUF1QkEsTUFBSUcsQ0FBSixLQUFRLEtBQUszbEIsT0FBTCxDQUFhLFFBQWIsRUFBc0IsRUFBQzByQixTQUFRLEtBQUtyRixNQUFMLENBQVliLENBQVosQ0FBVCxFQUF3QmpjLFVBQVNpYyxDQUFqQyxFQUF0QixHQUEyRCxLQUFLYSxNQUFMLENBQVliLENBQVosRUFBZTVJLE1BQWYsRUFBM0QsRUFBbUYsS0FBS3lKLE1BQUwsQ0FBWWxtQixNQUFaLENBQW1CcWxCLENBQW5CLEVBQXFCLENBQXJCLENBQW5GLEVBQTJHLEtBQUtlLFFBQUwsQ0FBY3BtQixNQUFkLENBQXFCcWxCLENBQXJCLEVBQXVCLENBQXZCLENBQTNHLEVBQXFJLEtBQUswRixVQUFMLENBQWdCLE9BQWhCLENBQXJJLEVBQThKLEtBQUtsckIsT0FBTCxDQUFhLFNBQWIsRUFBdUIsRUFBQzByQixTQUFRLElBQVQsRUFBY25pQixVQUFTaWMsQ0FBdkIsRUFBdkIsQ0FBdEssQ0FBdkI7QUFBZ1AsR0FBdHlmLEVBQXV5ZjVpQixFQUFFa0MsU0FBRixDQUFZa21CLHNCQUFaLEdBQW1DLFVBQVN2RixDQUFULEVBQVc7QUFBQ0EsTUFBRTlrQixJQUFGLENBQU82a0IsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTM0IsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxXQUFLcUYsS0FBTCxDQUFXLGFBQVgsR0FBMEJyRixJQUFFRixFQUFFRSxDQUFGLENBQTVCLEVBQWlDRixFQUFFLElBQUlrSSxLQUFKLEVBQUYsRUFBYTdjLEdBQWIsQ0FBaUIsTUFBakIsRUFBd0IyVSxFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0UsVUFBRXptQixJQUFGLENBQU8sS0FBUCxFQUFhdW1CLEVBQUV0WixNQUFGLENBQVN3RyxHQUF0QixHQUEyQmdULEVBQUV4WSxHQUFGLENBQU0sU0FBTixFQUFnQixDQUFoQixDQUEzQixFQUE4QyxLQUFLa2UsS0FBTCxDQUFXLGFBQVgsQ0FBOUMsRUFBd0UsQ0FBQyxLQUFLM2YsRUFBTCxDQUFRLGFBQVIsQ0FBRCxJQUF5QixDQUFDLEtBQUtBLEVBQUwsQ0FBUSxjQUFSLENBQTFCLElBQW1ELEtBQUt3ZixPQUFMLEVBQTNIO0FBQTBJLE9BQTlKLEVBQStKLElBQS9KLENBQXhCLEVBQThMaHNCLElBQTlMLENBQW1NLEtBQW5NLEVBQXlNeW1CLEVBQUV6bUIsSUFBRixDQUFPLEtBQVAsS0FBZXltQixFQUFFem1CLElBQUYsQ0FBTyxVQUFQLENBQWYsSUFBbUN5bUIsRUFBRXptQixJQUFGLENBQU8saUJBQVAsQ0FBNU8sQ0FBakM7QUFBd1MsS0FBOVQsRUFBK1QsSUFBL1QsQ0FBUDtBQUE2VSxHQUFucWdCLEVBQW9xZ0IyRCxFQUFFa0MsU0FBRixDQUFZa2UsT0FBWixHQUFvQixZQUFVO0FBQUMsU0FBS2xqQixRQUFMLENBQWN3TSxHQUFkLENBQWtCLFdBQWxCLEdBQStCLEtBQUs2ZCxNQUFMLENBQVk3ZCxHQUFaLENBQWdCLFdBQWhCLENBQS9CLEVBQTREa1osRUFBRUUsQ0FBRixFQUFLcFosR0FBTCxDQUFTLFdBQVQsQ0FBNUQsRUFBa0YsS0FBS3NaLFFBQUwsQ0FBYzhDLFVBQWQsS0FBMkIsQ0FBQyxDQUE1QixLQUFnQ2pELEVBQUVyZixZQUFGLENBQWUsS0FBSzJsQixXQUFwQixHQUFpQyxLQUFLemYsR0FBTCxDQUFTbVosQ0FBVCxFQUFXLFFBQVgsRUFBb0IsS0FBS0ssU0FBTCxDQUFlZ0csaUJBQW5DLENBQWpFLENBQWxGLENBQTBNLEtBQUksSUFBSW5HLENBQVIsSUFBYSxLQUFLN21CLFFBQWxCO0FBQTJCLFdBQUtBLFFBQUwsQ0FBYzZtQixDQUFkLEVBQWlCM0MsT0FBakI7QUFBM0IsS0FBc0QsS0FBS21ILE1BQUwsQ0FBWXpZLFFBQVosQ0FBcUIsU0FBckIsRUFBZ0NrTCxNQUFoQyxJQUF5QyxLQUFLdU4sTUFBTCxDQUFZeE4sTUFBWixFQUF6QyxFQUE4RCxLQUFLd04sTUFBTCxDQUFZelksUUFBWixHQUF1QmljLFFBQXZCLEdBQWtDaFIsTUFBbEMsRUFBOUQsRUFBeUcsS0FBS3dOLE1BQUwsQ0FBWXpZLFFBQVosR0FBdUJpTCxNQUF2QixFQUF6RyxFQUF5SSxLQUFLN2MsUUFBTCxDQUFjNkUsV0FBZCxDQUEwQixLQUFLa04sT0FBTCxDQUFhb1gsWUFBdkMsRUFBcUR0a0IsV0FBckQsQ0FBaUUsS0FBS2tOLE9BQUwsQ0FBYXNYLFlBQTlFLEVBQTRGeGtCLFdBQTVGLENBQXdHLEtBQUtrTixPQUFMLENBQWFxWCxXQUFySCxFQUFrSXZrQixXQUFsSSxDQUE4SSxLQUFLa04sT0FBTCxDQUFhdVgsUUFBM0osRUFBcUt6a0IsV0FBckssQ0FBaUwsS0FBS2tOLE9BQUwsQ0FBYXlYLFNBQTlMLEVBQXlNM2tCLFdBQXpNLENBQXFOLEtBQUtrTixPQUFMLENBQWE2WCxTQUFsTyxFQUE2T3pxQixJQUE3TyxDQUFrUCxPQUFsUCxFQUEwUCxLQUFLYSxRQUFMLENBQWNiLElBQWQsQ0FBbUIsT0FBbkIsRUFBNEJvSSxPQUE1QixDQUFvQyxJQUFJaWEsTUFBSixDQUFXLEtBQUt6UCxPQUFMLENBQWF3WCxlQUFiLEdBQTZCLFVBQXhDLEVBQW1ELEdBQW5ELENBQXBDLEVBQTRGLEVBQTVGLENBQTFQLEVBQTJWL29CLFVBQTNWLENBQXNXLGNBQXRXLENBQXpJO0FBQStmLEdBQWw4aEIsRUFBbThoQnNDLEVBQUVrQyxTQUFGLENBQVlnbUIsRUFBWixHQUFlLFVBQVN0RixDQUFULEVBQVdDLENBQVgsRUFBYUMsQ0FBYixFQUFlO0FBQUMsUUFBSUMsSUFBRSxLQUFLQyxRQUFMLENBQWM1bUIsR0FBcEIsQ0FBd0IsUUFBT3ltQixDQUFQLEdBQVUsS0FBSSxHQUFKO0FBQVEsZUFBT0UsSUFBRUgsSUFBRUUsQ0FBSixHQUFNRixJQUFFRSxDQUFmLENBQWlCLEtBQUksR0FBSjtBQUFRLGVBQU9DLElBQUVILElBQUVFLENBQUosR0FBTUYsSUFBRUUsQ0FBZixDQUFpQixLQUFJLElBQUo7QUFBUyxlQUFPQyxJQUFFSCxLQUFHRSxDQUFMLEdBQU9GLEtBQUdFLENBQWpCLENBQW1CLEtBQUksSUFBSjtBQUFTLGVBQU9DLElBQUVILEtBQUdFLENBQUwsR0FBT0YsS0FBR0UsQ0FBakIsQ0FBakc7QUFBcUgsR0FBL21pQixFQUFnbmlCOWlCLEVBQUVrQyxTQUFGLENBQVltSCxFQUFaLEdBQWUsVUFBU3VaLENBQVQsRUFBV0MsQ0FBWCxFQUFhQyxDQUFiLEVBQWVDLENBQWYsRUFBaUI7QUFBQ0gsTUFBRXRSLGdCQUFGLEdBQW1Cc1IsRUFBRXRSLGdCQUFGLENBQW1CdVIsQ0FBbkIsRUFBcUJDLENBQXJCLEVBQXVCQyxDQUF2QixDQUFuQixHQUE2Q0gsRUFBRW9JLFdBQUYsSUFBZXBJLEVBQUVvSSxXQUFGLENBQWMsT0FBS25JLENBQW5CLEVBQXFCQyxDQUFyQixDQUE1RDtBQUFvRixHQUFydWlCLEVBQXN1aUI5aUIsRUFBRWtDLFNBQUYsQ0FBWXdILEdBQVosR0FBZ0IsVUFBU2taLENBQVQsRUFBV0MsQ0FBWCxFQUFhQyxDQUFiLEVBQWVDLENBQWYsRUFBaUI7QUFBQ0gsTUFBRWxTLG1CQUFGLEdBQXNCa1MsRUFBRWxTLG1CQUFGLENBQXNCbVMsQ0FBdEIsRUFBd0JDLENBQXhCLEVBQTBCQyxDQUExQixDQUF0QixHQUFtREgsRUFBRXFJLFdBQUYsSUFBZXJJLEVBQUVxSSxXQUFGLENBQWMsT0FBS3BJLENBQW5CLEVBQXFCQyxDQUFyQixDQUFsRTtBQUEwRixHQUFsMmlCLEVBQW0yaUI5aUIsRUFBRWtDLFNBQUYsQ0FBWTlFLE9BQVosR0FBb0IsVUFBU3lsQixDQUFULEVBQVdDLENBQVgsRUFBYUMsQ0FBYixFQUFlMEUsQ0FBZixFQUFpQkUsQ0FBakIsRUFBbUI7QUFBQyxRQUFJQyxJQUFFLEVBQUNzRCxNQUFLLEVBQUNDLE9BQU0sS0FBSzFILE1BQUwsQ0FBWTVrQixNQUFuQixFQUEwQnFlLE9BQU0sS0FBSy9TLE9BQUwsRUFBaEMsRUFBTixFQUFOO0FBQUEsUUFBNkQ1SyxJQUFFcWpCLEVBQUV3SSxTQUFGLENBQVl4SSxFQUFFcUcsSUFBRixDQUFPLENBQUMsSUFBRCxFQUFNcEcsQ0FBTixFQUFRRSxDQUFSLENBQVAsRUFBa0IsVUFBU0gsQ0FBVCxFQUFXO0FBQUMsYUFBT0EsQ0FBUDtBQUFTLEtBQXZDLEVBQXlDaFAsSUFBekMsQ0FBOEMsR0FBOUMsRUFBbUQ3VyxXQUFuRCxFQUFaLENBQS9EO0FBQUEsUUFBNklzdUIsSUFBRXpJLEVBQUV3RSxLQUFGLENBQVEsQ0FBQ3ZFLENBQUQsRUFBRyxLQUFILEVBQVNFLEtBQUcsVUFBWixFQUF3Qm5QLElBQXhCLENBQTZCLEdBQTdCLEVBQWtDN1csV0FBbEMsRUFBUixFQUF3RDZsQixFQUFFcmEsTUFBRixDQUFTLEVBQUMraUIsZUFBYyxJQUFmLEVBQVQsRUFBOEIxRCxDQUE5QixFQUFnQzlFLENBQWhDLENBQXhELENBQS9JLENBQTJPLE9BQU8sS0FBS0ssUUFBTCxDQUFjTixDQUFkLE1BQW1CRCxFQUFFN2tCLElBQUYsQ0FBTyxLQUFLN0IsUUFBWixFQUFxQixVQUFTMG1CLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUNBLFFBQUUwSSxTQUFGLElBQWExSSxFQUFFMEksU0FBRixDQUFZRixDQUFaLENBQWI7QUFBNEIsS0FBL0QsR0FBaUUsS0FBS3ZpQixRQUFMLENBQWMsRUFBQzdLLE1BQUsrQixFQUFFbW5CLElBQUYsQ0FBT0MsS0FBYixFQUFtQjdxQixNQUFLc21CLENBQXhCLEVBQWQsQ0FBakUsRUFBMkcsS0FBSzNsQixRQUFMLENBQWNFLE9BQWQsQ0FBc0JpdUIsQ0FBdEIsQ0FBM0csRUFBb0ksS0FBS3JJLFFBQUwsSUFBZSxjQUFZLE9BQU8sS0FBS0EsUUFBTCxDQUFjempCLENBQWQsQ0FBbEMsSUFBb0QsS0FBS3lqQixRQUFMLENBQWN6akIsQ0FBZCxFQUFpQjRDLElBQWpCLENBQXNCLElBQXRCLEVBQTJCa3BCLENBQTNCLENBQTNNLEdBQTBPQSxDQUFqUDtBQUFtUCxHQUF6MmpCLEVBQTAyakJyckIsRUFBRWtDLFNBQUYsQ0FBWWltQixLQUFaLEdBQWtCLFVBQVN0RixDQUFULEVBQVc7QUFBQ0QsTUFBRTdrQixJQUFGLENBQU8sQ0FBQzhrQixDQUFELEVBQUkzZSxNQUFKLENBQVcsS0FBS2lnQixPQUFMLENBQWFDLElBQWIsQ0FBa0J2QixDQUFsQixLQUFzQixFQUFqQyxDQUFQLEVBQTRDRCxFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFdBQUtzQixPQUFMLENBQWFoYSxPQUFiLENBQXFCMFksQ0FBckIsTUFBMEJFLENBQTFCLEtBQThCLEtBQUtvQixPQUFMLENBQWFoYSxPQUFiLENBQXFCMFksQ0FBckIsSUFBd0IsQ0FBdEQsR0FBeUQsS0FBS3NCLE9BQUwsQ0FBYWhhLE9BQWIsQ0FBcUIwWSxDQUFyQixHQUF6RDtBQUFtRixLQUF6RyxFQUEwRyxJQUExRyxDQUE1QztBQUE2SixHQUFyaWtCLEVBQXNpa0I3aUIsRUFBRWtDLFNBQUYsQ0FBWXNtQixLQUFaLEdBQWtCLFVBQVMzRixDQUFULEVBQVc7QUFBQ0QsTUFBRTdrQixJQUFGLENBQU8sQ0FBQzhrQixDQUFELEVBQUkzZSxNQUFKLENBQVcsS0FBS2lnQixPQUFMLENBQWFDLElBQWIsQ0FBa0J2QixDQUFsQixLQUFzQixFQUFqQyxDQUFQLEVBQTRDRCxFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFdBQUtzQixPQUFMLENBQWFoYSxPQUFiLENBQXFCMFksQ0FBckI7QUFBMEIsS0FBaEQsRUFBaUQsSUFBakQsQ0FBNUM7QUFBb0csR0FBeHFrQixFQUF5cWtCN2lCLEVBQUVrQyxTQUFGLENBQVk0RyxRQUFaLEdBQXFCLFVBQVMrWixDQUFULEVBQVc7QUFBQyxRQUFHQSxFQUFFNWtCLElBQUYsS0FBUytCLEVBQUVtbkIsSUFBRixDQUFPQyxLQUFuQixFQUF5QjtBQUFDLFVBQUd4RSxFQUFFdGIsS0FBRixDQUFRbUssT0FBUixDQUFnQm9SLEVBQUV0bUIsSUFBbEIsTUFBMEJxbUIsRUFBRXRiLEtBQUYsQ0FBUW1LLE9BQVIsQ0FBZ0JvUixFQUFFdG1CLElBQWxCLElBQXdCLEVBQWxELEdBQXNELENBQUNxbUIsRUFBRXRiLEtBQUYsQ0FBUW1LLE9BQVIsQ0FBZ0JvUixFQUFFdG1CLElBQWxCLEVBQXdCaXZCLEdBQWxGLEVBQXNGO0FBQUMsWUFBSTFJLElBQUVGLEVBQUV0YixLQUFGLENBQVFtSyxPQUFSLENBQWdCb1IsRUFBRXRtQixJQUFsQixFQUF3Qmt2QixRQUE5QixDQUF1QzdJLEVBQUV0YixLQUFGLENBQVFtSyxPQUFSLENBQWdCb1IsRUFBRXRtQixJQUFsQixFQUF3Qmt2QixRQUF4QixHQUFpQyxVQUFTN0ksQ0FBVCxFQUFXO0FBQUMsaUJBQU0sQ0FBQ0UsQ0FBRCxJQUFJLENBQUNBLEVBQUVyaEIsS0FBUCxJQUFjbWhCLEVBQUU5akIsU0FBRixJQUFhOGpCLEVBQUU5akIsU0FBRixDQUFZdEIsT0FBWixDQUFvQixLQUFwQixNQUE2QixDQUFDLENBQXpELEdBQTJEb2xCLEVBQUU5akIsU0FBRixJQUFhOGpCLEVBQUU5akIsU0FBRixDQUFZdEIsT0FBWixDQUFvQixLQUFwQixJQUEyQixDQUFDLENBQXBHLEdBQXNHc2xCLEVBQUVyaEIsS0FBRixDQUFRLElBQVIsRUFBYUQsU0FBYixDQUE1RztBQUFvSSxTQUFqTCxFQUFrTG9oQixFQUFFdGIsS0FBRixDQUFRbUssT0FBUixDQUFnQm9SLEVBQUV0bUIsSUFBbEIsRUFBd0JpdkIsR0FBeEIsR0FBNEIsQ0FBQyxDQUEvTTtBQUFpTjtBQUFDLEtBQTFXLE1BQStXM0ksRUFBRTVrQixJQUFGLEtBQVMrQixFQUFFbW5CLElBQUYsQ0FBT0UsS0FBaEIsS0FBd0IsS0FBS2xELE9BQUwsQ0FBYUMsSUFBYixDQUFrQnZCLEVBQUV0bUIsSUFBcEIsSUFBMEIsS0FBSzRuQixPQUFMLENBQWFDLElBQWIsQ0FBa0J2QixFQUFFdG1CLElBQXBCLElBQTBCLEtBQUs0bkIsT0FBTCxDQUFhQyxJQUFiLENBQWtCdkIsRUFBRXRtQixJQUFwQixFQUEwQjJILE1BQTFCLENBQWlDMmUsRUFBRXVCLElBQW5DLENBQXBELEdBQTZGLEtBQUtELE9BQUwsQ0FBYUMsSUFBYixDQUFrQnZCLEVBQUV0bUIsSUFBcEIsSUFBMEJzbUIsRUFBRXVCLElBQXpILEVBQThILEtBQUtELE9BQUwsQ0FBYUMsSUFBYixDQUFrQnZCLEVBQUV0bUIsSUFBcEIsSUFBMEJxbUIsRUFBRXFHLElBQUYsQ0FBTyxLQUFLOUUsT0FBTCxDQUFhQyxJQUFiLENBQWtCdkIsRUFBRXRtQixJQUFwQixDQUFQLEVBQWlDcW1CLEVBQUU0QixLQUFGLENBQVEsVUFBUzFCLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsYUFBT0gsRUFBRThJLE9BQUYsQ0FBVTVJLENBQVYsRUFBWSxLQUFLcUIsT0FBTCxDQUFhQyxJQUFiLENBQWtCdkIsRUFBRXRtQixJQUFwQixDQUFaLE1BQXlDd21CLENBQWhEO0FBQWtELEtBQXhFLEVBQXlFLElBQXpFLENBQWpDLENBQWhMO0FBQWtTLEdBQTMxbEIsRUFBNDFsQi9pQixFQUFFa0MsU0FBRixDQUFZNm5CLFFBQVosR0FBcUIsVUFBU2xILENBQVQsRUFBVztBQUFDRCxNQUFFN2tCLElBQUYsQ0FBTzhrQixDQUFQLEVBQVNELEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsV0FBS00sUUFBTCxDQUFjTixDQUFkLElBQWlCLENBQUMsQ0FBbEI7QUFBb0IsS0FBMUMsRUFBMkMsSUFBM0MsQ0FBVDtBQUEyRCxHQUF4N2xCLEVBQXk3bEI3aUIsRUFBRWtDLFNBQUYsQ0FBWThuQixPQUFaLEdBQW9CLFVBQVNuSCxDQUFULEVBQVc7QUFBQ0QsTUFBRTdrQixJQUFGLENBQU84a0IsQ0FBUCxFQUFTRCxFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLGFBQU8sS0FBS00sUUFBTCxDQUFjTixDQUFkLENBQVA7QUFBd0IsS0FBOUMsRUFBK0MsSUFBL0MsQ0FBVDtBQUErRCxHQUF4aG1CLEVBQXlobUI3aUIsRUFBRWtDLFNBQUYsQ0FBWStoQixPQUFaLEdBQW9CLFVBQVNyQixDQUFULEVBQVc7QUFBQyxRQUFJRSxJQUFFLEVBQUNsUyxHQUFFLElBQUgsRUFBUUcsR0FBRSxJQUFWLEVBQU4sQ0FBc0IsT0FBTzZSLElBQUVBLEVBQUUrSSxhQUFGLElBQWlCL0ksQ0FBakIsSUFBb0JDLEVBQUV2YixLQUF4QixFQUE4QnNiLElBQUVBLEVBQUUvUixPQUFGLElBQVcrUixFQUFFL1IsT0FBRixDQUFVaFMsTUFBckIsR0FBNEIrakIsRUFBRS9SLE9BQUYsQ0FBVSxDQUFWLENBQTVCLEdBQXlDK1IsRUFBRTdRLGNBQUYsSUFBa0I2USxFQUFFN1EsY0FBRixDQUFpQmxULE1BQW5DLEdBQTBDK2pCLEVBQUU3USxjQUFGLENBQWlCLENBQWpCLENBQTFDLEdBQThENlEsQ0FBdkksRUFBeUlBLEVBQUU5UixLQUFGLElBQVNnUyxFQUFFbFMsQ0FBRixHQUFJZ1MsRUFBRTlSLEtBQU4sRUFBWWdTLEVBQUUvUixDQUFGLEdBQUk2UixFQUFFNVIsS0FBM0IsS0FBbUM4UixFQUFFbFMsQ0FBRixHQUFJZ1MsRUFBRW5RLE9BQU4sRUFBY3FRLEVBQUUvUixDQUFGLEdBQUk2UixFQUFFbFEsT0FBdkQsQ0FBekksRUFBeU1vUSxDQUFoTjtBQUFrTixHQUFqeW1CLEVBQWt5bUI5aUIsRUFBRWtDLFNBQUYsQ0FBWStuQixTQUFaLEdBQXNCLFVBQVNySCxDQUFULEVBQVc7QUFBQyxXQUFNLENBQUNyZSxNQUFNQyxXQUFXb2UsQ0FBWCxDQUFOLENBQVA7QUFBNEIsR0FBaDJtQixFQUFpMm1CNWlCLEVBQUVrQyxTQUFGLENBQVkwbkIsVUFBWixHQUF1QixVQUFTaEgsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxXQUFNLEVBQUNqUyxHQUFFZ1MsRUFBRWhTLENBQUYsR0FBSWlTLEVBQUVqUyxDQUFULEVBQVdHLEdBQUU2UixFQUFFN1IsQ0FBRixHQUFJOFIsRUFBRTlSLENBQW5CLEVBQU47QUFBNEIsR0FBbDZtQixFQUFtNm1CNlIsRUFBRW5nQixFQUFGLENBQUttcEIsV0FBTCxHQUFpQixVQUFTL0ksQ0FBVCxFQUFXO0FBQUMsUUFBSUMsSUFBRTdnQixNQUFNQyxTQUFOLENBQWdCOUMsS0FBaEIsQ0FBc0IrQyxJQUF0QixDQUEyQlgsU0FBM0IsRUFBcUMsQ0FBckMsQ0FBTixDQUE4QyxPQUFPLEtBQUt6RCxJQUFMLENBQVUsWUFBVTtBQUFDLFVBQUlnbEIsSUFBRUgsRUFBRSxJQUFGLENBQU47QUFBQSxVQUFjNkUsSUFBRTFFLEVBQUU1bEIsSUFBRixDQUFPLGNBQVAsQ0FBaEIsQ0FBdUNzcUIsTUFBSUEsSUFBRSxJQUFJem5CLENBQUosQ0FBTSxJQUFOLEVBQVcsb0JBQWlCNmlCLENBQWpCLHlDQUFpQkEsQ0FBakIsTUFBb0JBLENBQS9CLENBQUYsRUFBb0NFLEVBQUU1bEIsSUFBRixDQUFPLGNBQVAsRUFBc0JzcUIsQ0FBdEIsQ0FBcEMsRUFBNkQ3RSxFQUFFN2tCLElBQUYsQ0FBTyxDQUFDLE1BQUQsRUFBUSxNQUFSLEVBQWUsSUFBZixFQUFvQixTQUFwQixFQUE4QixTQUE5QixFQUF3QyxTQUF4QyxFQUFrRCxLQUFsRCxFQUF3RCxRQUF4RCxDQUFQLEVBQXlFLFVBQVM4a0IsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQzJFLFVBQUUzZSxRQUFGLENBQVcsRUFBQzdLLE1BQUsrQixFQUFFbW5CLElBQUYsQ0FBT0MsS0FBYixFQUFtQjdxQixNQUFLdW1CLENBQXhCLEVBQVgsR0FBdUMyRSxFQUFFdnFCLFFBQUYsQ0FBV21NLEVBQVgsQ0FBY3laLElBQUUsb0JBQWhCLEVBQXFDRixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0EsWUFBRTlqQixTQUFGLElBQWE4akIsRUFBRTBJLGFBQUYsS0FBa0IsSUFBL0IsS0FBc0MsS0FBS3ZCLFFBQUwsQ0FBYyxDQUFDakgsQ0FBRCxDQUFkLEdBQW1CMkUsRUFBRTNFLENBQUYsRUFBS3JoQixLQUFMLENBQVcsSUFBWCxFQUFnQixHQUFHckMsS0FBSCxDQUFTK0MsSUFBVCxDQUFjWCxTQUFkLEVBQXdCLENBQXhCLENBQWhCLENBQW5CLEVBQStELEtBQUt3b0IsT0FBTCxDQUFhLENBQUNsSCxDQUFELENBQWIsQ0FBckc7QUFBd0gsU0FBNUksRUFBNkkyRSxDQUE3SSxDQUFyQyxDQUF2QztBQUE2TixPQUFwVCxDQUFqRSxHQUF3WCxZQUFVLE9BQU81RSxDQUFqQixJQUFvQixRQUFNQSxFQUFFNkIsTUFBRixDQUFTLENBQVQsQ0FBMUIsSUFBdUMrQyxFQUFFNUUsQ0FBRixFQUFLcGhCLEtBQUwsQ0FBV2dtQixDQUFYLEVBQWEzRSxDQUFiLENBQS9aO0FBQSthLEtBQTNlLENBQVA7QUFBb2YsR0FBbCtuQixFQUFtK25CRixFQUFFbmdCLEVBQUYsQ0FBS21wQixXQUFMLENBQWlCQyxXQUFqQixHQUE2QjdyQixDQUFoZ29CO0FBQWtnb0IsQ0FBaDVwQixDQUFpNXBCd0MsT0FBT3NwQixLQUFQLElBQWN0cEIsT0FBT2tDLE1BQXQ2cEIsRUFBNjZwQmxDLE1BQTc2cEIsRUFBbzdwQjlCLFFBQXA3cEIsQ0FBRCxFQUErN3BCLFVBQVNraUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZUMsQ0FBZixFQUFpQjtBQUFDLE1BQUkvaUIsSUFBRSxTQUFGQSxDQUFFLENBQVM2aUIsQ0FBVCxFQUFXO0FBQUMsU0FBS2tKLEtBQUwsR0FBV2xKLENBQVgsRUFBYSxLQUFLbUosU0FBTCxHQUFlLElBQTVCLEVBQWlDLEtBQUtDLFFBQUwsR0FBYyxJQUEvQyxFQUFvRCxLQUFLL0ksU0FBTCxHQUFlLEVBQUMsNEJBQTJCTixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0EsVUFBRTlqQixTQUFGLElBQWEsS0FBS2l0QixLQUFMLENBQVcvSSxRQUFYLENBQW9Ca0osV0FBakMsSUFBOEMsS0FBS0MsS0FBTCxFQUE5QztBQUEyRCxPQUEvRSxFQUFnRixJQUFoRixDQUE1QixFQUFuRSxFQUFzTCxLQUFLSixLQUFMLENBQVc5YyxPQUFYLEdBQW1CMlQsRUFBRXJhLE1BQUYsQ0FBUyxFQUFULEVBQVl2SSxFQUFFaWpCLFFBQWQsRUFBdUIsS0FBSzhJLEtBQUwsQ0FBVzljLE9BQWxDLENBQXpNLEVBQW9QLEtBQUs4YyxLQUFMLENBQVc3dUIsUUFBWCxDQUFvQm1NLEVBQXBCLENBQXVCLEtBQUs2WixTQUE1QixDQUFwUDtBQUEyUixHQUE3UyxDQUE4U2xqQixFQUFFaWpCLFFBQUYsR0FBVyxFQUFDaUosYUFBWSxDQUFDLENBQWQsRUFBZ0JFLHFCQUFvQixHQUFwQyxFQUFYLEVBQW9EcHNCLEVBQUVrQyxTQUFGLENBQVlpcUIsS0FBWixHQUFrQixZQUFVO0FBQUMsU0FBS0gsU0FBTCxLQUFpQixLQUFLQyxRQUFMLEdBQWMsS0FBS0YsS0FBTCxDQUFXN3VCLFFBQVgsQ0FBb0IyTCxFQUFwQixDQUF1QixVQUF2QixDQUFkLEVBQWlELEtBQUttakIsU0FBTCxHQUFlbkosRUFBRXdKLFdBQUYsQ0FBY3pKLEVBQUU0QixLQUFGLENBQVEsS0FBSzZELE9BQWIsRUFBcUIsSUFBckIsQ0FBZCxFQUF5QyxLQUFLMEQsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQm9KLG1CQUE3RCxDQUFqRjtBQUFvSyxHQUFyUCxFQUFzUHBzQixFQUFFa0MsU0FBRixDQUFZbW1CLE9BQVosR0FBb0IsWUFBVTtBQUFDLFNBQUswRCxLQUFMLENBQVc3dUIsUUFBWCxDQUFvQjJMLEVBQXBCLENBQXVCLFVBQXZCLE1BQXFDLEtBQUtvakIsUUFBMUMsS0FBcUQsS0FBS0EsUUFBTCxHQUFjLENBQUMsS0FBS0EsUUFBcEIsRUFBNkIsS0FBS0YsS0FBTCxDQUFXN3VCLFFBQVgsQ0FBb0Jra0IsV0FBcEIsQ0FBZ0MsWUFBaEMsRUFBNkMsQ0FBQyxLQUFLNkssUUFBbkQsQ0FBN0IsRUFBMEYsS0FBS0EsUUFBTCxJQUFlLEtBQUtGLEtBQUwsQ0FBV3pELFVBQVgsQ0FBc0IsT0FBdEIsQ0FBZixJQUErQyxLQUFLeUQsS0FBTCxDQUFXMUQsT0FBWCxFQUE5TDtBQUFvTixHQUF6ZSxFQUEwZXJvQixFQUFFa0MsU0FBRixDQUFZa2UsT0FBWixHQUFvQixZQUFVO0FBQUMsUUFBSXdDLENBQUosRUFBTUUsQ0FBTixDQUFRRCxFQUFFeUosYUFBRixDQUFnQixLQUFLTixTQUFyQixFQUFnQyxLQUFJcEosQ0FBSixJQUFTLEtBQUtNLFNBQWQ7QUFBd0IsV0FBSzZJLEtBQUwsQ0FBVzd1QixRQUFYLENBQW9Cd00sR0FBcEIsQ0FBd0JrWixDQUF4QixFQUEwQixLQUFLTSxTQUFMLENBQWVOLENBQWYsQ0FBMUI7QUFBeEIsS0FBcUUsS0FBSUUsQ0FBSixJQUFTdGtCLE9BQU8rdEIsbUJBQVAsQ0FBMkIsSUFBM0IsQ0FBVDtBQUEwQyxvQkFBWSxPQUFPLEtBQUt6SixDQUFMLENBQW5CLEtBQTZCLEtBQUtBLENBQUwsSUFBUSxJQUFyQztBQUExQztBQUFxRixHQUEzc0IsRUFBNHNCRixFQUFFbmdCLEVBQUYsQ0FBS21wQixXQUFMLENBQWlCQyxXQUFqQixDQUE2QnBILE9BQTdCLENBQXFDK0gsV0FBckMsR0FBaUR4c0IsQ0FBN3ZCO0FBQSt2QixDQUEvakMsQ0FBZ2tDd0MsT0FBT3NwQixLQUFQLElBQWN0cEIsT0FBT2tDLE1BQXJsQyxFQUE0bENsQyxNQUE1bEMsRUFBbW1DOUIsUUFBbm1DLENBQS83cEIsRUFBNGlzQixVQUFTa2lCLENBQVQsRUFBV0MsQ0FBWCxFQUFhQyxDQUFiLEVBQWVDLENBQWYsRUFBaUI7QUFBQyxNQUFJL2lCLElBQUUsU0FBRkEsQ0FBRSxDQUFTNmlCLENBQVQsRUFBVztBQUFDLFNBQUtrSixLQUFMLEdBQVdsSixDQUFYLEVBQWEsS0FBSzRKLE9BQUwsR0FBYSxFQUExQixFQUE2QixLQUFLdkosU0FBTCxHQUFlLEVBQUMscUVBQW9FTixFQUFFNEIsS0FBRixDQUFRLFVBQVMzQixDQUFULEVBQVc7QUFBQyxZQUFHQSxFQUFFL2pCLFNBQUYsSUFBYSxLQUFLaXRCLEtBQUwsQ0FBVy9JLFFBQXhCLElBQWtDLEtBQUsrSSxLQUFMLENBQVcvSSxRQUFYLENBQW9CMEosUUFBdEQsS0FBaUU3SixFQUFFOEYsUUFBRixJQUFZLGNBQVk5RixFQUFFOEYsUUFBRixDQUFXcHNCLElBQW5DLElBQXlDLGlCQUFlc21CLEVBQUU1a0IsSUFBM0gsQ0FBSCxFQUFvSSxLQUFJLElBQUk2a0IsSUFBRSxLQUFLaUosS0FBTCxDQUFXL0ksUUFBakIsRUFBMEJoakIsSUFBRThpQixFQUFFaUMsTUFBRixJQUFVaG1CLEtBQUsyb0IsSUFBTCxDQUFVNUUsRUFBRXRVLEtBQUYsR0FBUSxDQUFsQixDQUFWLElBQWdDc1UsRUFBRXRVLEtBQTlELEVBQW9FaVosSUFBRTNFLEVBQUVpQyxNQUFGLElBQVUva0IsSUFBRSxDQUFDLENBQWIsSUFBZ0IsQ0FBdEYsRUFBd0YybkIsSUFBRSxDQUFDOUUsRUFBRThGLFFBQUYsSUFBWTlGLEVBQUU4RixRQUFGLENBQVdqZSxLQUFYLEtBQW1CcVksQ0FBL0IsR0FBaUNGLEVBQUU4RixRQUFGLENBQVdqZSxLQUE1QyxHQUFrRCxLQUFLcWhCLEtBQUwsQ0FBVzVoQixPQUFYLEVBQW5ELElBQXlFc2QsQ0FBbkssRUFBcUtHLElBQUUsS0FBS21FLEtBQUwsQ0FBVzVCLE1BQVgsR0FBb0J0ckIsTUFBM0wsRUFBa01VLElBQUVxakIsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxlQUFLOEosSUFBTCxDQUFVOUosQ0FBVjtBQUFhLFNBQW5DLEVBQW9DLElBQXBDLENBQXhNLEVBQWtQNEUsTUFBSXpuQixDQUF0UDtBQUF5UCxlQUFLMnNCLElBQUwsQ0FBVS9FLElBQUUsQ0FBRixHQUFJLEtBQUttRSxLQUFMLENBQVd6RSxRQUFYLENBQW9CSyxDQUFwQixDQUFkLEdBQXNDQyxLQUFHaEYsRUFBRTdrQixJQUFGLENBQU8sS0FBS2d1QixLQUFMLENBQVc1QixNQUFYLENBQWtCLEtBQUs0QixLQUFMLENBQVd6RSxRQUFYLENBQW9CSyxDQUFwQixDQUFsQixDQUFQLEVBQWlEcG9CLENBQWpELENBQXpDLEVBQTZGb29CLEdBQTdGO0FBQXpQO0FBQTBWLE9BQWxmLEVBQW1mLElBQW5mLENBQXJFLEVBQTVDLEVBQTJtQixLQUFLb0UsS0FBTCxDQUFXOWMsT0FBWCxHQUFtQjJULEVBQUVyYSxNQUFGLENBQVMsRUFBVCxFQUFZdkksRUFBRWlqQixRQUFkLEVBQXVCLEtBQUs4SSxLQUFMLENBQVc5YyxPQUFsQyxDQUE5bkIsRUFBeXFCLEtBQUs4YyxLQUFMLENBQVc3dUIsUUFBWCxDQUFvQm1NLEVBQXBCLENBQXVCLEtBQUs2WixTQUE1QixDQUF6cUI7QUFBZ3RCLEdBQWx1QixDQUFtdUJsakIsRUFBRWlqQixRQUFGLEdBQVcsRUFBQ3lKLFVBQVMsQ0FBQyxDQUFYLEVBQVgsRUFBeUIxc0IsRUFBRWtDLFNBQUYsQ0FBWXlxQixJQUFaLEdBQWlCLFVBQVM3SixDQUFULEVBQVc7QUFBQyxRQUFJQyxJQUFFLEtBQUtnSixLQUFMLENBQVd4RSxNQUFYLENBQWtCelksUUFBbEIsR0FBNkIzRixFQUE3QixDQUFnQzJaLENBQWhDLENBQU47QUFBQSxRQUF5QzlpQixJQUFFK2lCLEtBQUdBLEVBQUV0akIsSUFBRixDQUFPLFdBQVAsQ0FBOUMsQ0FBa0UsQ0FBQ08sQ0FBRCxJQUFJNGlCLEVBQUU4SSxPQUFGLENBQVUzSSxFQUFFL1gsR0FBRixDQUFNLENBQU4sQ0FBVixFQUFtQixLQUFLeWhCLE9BQXhCLElBQWlDLENBQUMsQ0FBdEMsS0FBMEN6c0IsRUFBRWpDLElBQUYsQ0FBTzZrQixFQUFFNEIsS0FBRixDQUFRLFVBQVMxQixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFVBQUkvaUIsQ0FBSjtBQUFBLFVBQU15bkIsSUFBRTdFLEVBQUVHLENBQUYsQ0FBUjtBQUFBLFVBQWE0RSxJQUFFOUUsRUFBRStKLGdCQUFGLEdBQW1CLENBQW5CLElBQXNCbkYsRUFBRXByQixJQUFGLENBQU8saUJBQVAsQ0FBdEIsSUFBaURvckIsRUFBRXByQixJQUFGLENBQU8sVUFBUCxDQUFoRSxDQUFtRixLQUFLMHZCLEtBQUwsQ0FBVzN1QixPQUFYLENBQW1CLE1BQW5CLEVBQTBCLEVBQUMySCxTQUFRMGlCLENBQVQsRUFBV29GLEtBQUlsRixDQUFmLEVBQTFCLEVBQTRDLE1BQTVDLEdBQW9ERixFQUFFNWUsRUFBRixDQUFLLEtBQUwsSUFBWTRlLEVBQUV4WixHQUFGLENBQU0sZUFBTixFQUFzQjJVLEVBQUU0QixLQUFGLENBQVEsWUFBVTtBQUFDaUQsVUFBRW5kLEdBQUYsQ0FBTSxTQUFOLEVBQWdCLENBQWhCLEdBQW1CLEtBQUt5aEIsS0FBTCxDQUFXM3VCLE9BQVgsQ0FBbUIsUUFBbkIsRUFBNEIsRUFBQzJILFNBQVEwaUIsQ0FBVCxFQUFXb0YsS0FBSWxGLENBQWYsRUFBNUIsRUFBOEMsTUFBOUMsQ0FBbkI7QUFBeUUsT0FBNUYsRUFBNkYsSUFBN0YsQ0FBdEIsRUFBMEh0ckIsSUFBMUgsQ0FBK0gsS0FBL0gsRUFBcUlzckIsQ0FBckksQ0FBWixJQUFxSjNuQixJQUFFLElBQUk4cUIsS0FBSixFQUFGLEVBQVk5cUIsRUFBRThzQixNQUFGLEdBQVNsSyxFQUFFNEIsS0FBRixDQUFRLFlBQVU7QUFBQ2lELFVBQUVuZCxHQUFGLENBQU0sRUFBQyxvQkFBbUIsVUFBUXFkLENBQVIsR0FBVSxJQUE5QixFQUFtQ29GLFNBQVEsR0FBM0MsRUFBTixHQUF1RCxLQUFLaEIsS0FBTCxDQUFXM3VCLE9BQVgsQ0FBbUIsUUFBbkIsRUFBNEIsRUFBQzJILFNBQVEwaUIsQ0FBVCxFQUFXb0YsS0FBSWxGLENBQWYsRUFBNUIsRUFBOEMsTUFBOUMsQ0FBdkQ7QUFBNkcsT0FBaEksRUFBaUksSUFBakksQ0FBckIsRUFBNEozbkIsRUFBRThQLEdBQUYsR0FBTTZYLENBQXZULENBQXBEO0FBQThXLEtBQXZkLEVBQXdkLElBQXhkLENBQVAsR0FBc2UsS0FBSzhFLE9BQUwsQ0FBYXB2QixJQUFiLENBQWtCMGxCLEVBQUUvWCxHQUFGLENBQU0sQ0FBTixDQUFsQixDQUFoaEI7QUFBNmlCLEdBQXJxQixFQUFzcUJoTCxFQUFFa0MsU0FBRixDQUFZa2UsT0FBWixHQUFvQixZQUFVO0FBQUMsUUFBSXdDLENBQUosRUFBTUMsQ0FBTixDQUFRLEtBQUlELENBQUosSUFBUyxLQUFLb0ssUUFBZDtBQUF1QixXQUFLakIsS0FBTCxDQUFXN3VCLFFBQVgsQ0FBb0J3TSxHQUFwQixDQUF3QmtaLENBQXhCLEVBQTBCLEtBQUtvSyxRQUFMLENBQWNwSyxDQUFkLENBQTFCO0FBQXZCLEtBQW1FLEtBQUlDLENBQUosSUFBU3JrQixPQUFPK3RCLG1CQUFQLENBQTJCLElBQTNCLENBQVQ7QUFBMEMsb0JBQVksT0FBTyxLQUFLMUosQ0FBTCxDQUFuQixLQUE2QixLQUFLQSxDQUFMLElBQVEsSUFBckM7QUFBMUM7QUFBcUYsR0FBcjJCLEVBQXMyQkQsRUFBRW5nQixFQUFGLENBQUttcEIsV0FBTCxDQUFpQkMsV0FBakIsQ0FBNkJwSCxPQUE3QixDQUFxQ3dJLElBQXJDLEdBQTBDanRCLENBQWg1QjtBQUFrNUIsQ0FBdm9ELENBQXdvRHdDLE9BQU9zcEIsS0FBUCxJQUFjdHBCLE9BQU9rQyxNQUE3cEQsRUFBb3FEbEMsTUFBcHFELEVBQTJxRDlCLFFBQTNxRCxDQUE1aXNCLEVBQWl1dkIsVUFBU2tpQixDQUFULEVBQVdDLENBQVgsRUFBYUMsQ0FBYixFQUFlQyxDQUFmLEVBQWlCO0FBQUMsTUFBSS9pQixJQUFFLFNBQUZBLENBQUUsQ0FBUzZpQixDQUFULEVBQVc7QUFBQyxTQUFLa0osS0FBTCxHQUFXbEosQ0FBWCxFQUFhLEtBQUtLLFNBQUwsR0FBZSxFQUFDLG1EQUFrRE4sRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLEtBQUtpdEIsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQjlLLFVBQWpDLElBQTZDLEtBQUs2USxNQUFMLEVBQTdDO0FBQTJELE9BQS9FLEVBQWdGLElBQWhGLENBQW5ELEVBQXlJLHdCQUF1Qm5HLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsSUFBYSxLQUFLaXRCLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0I5SyxVQUFqQyxJQUE2QyxjQUFZMEssRUFBRStGLFFBQUYsQ0FBV3BzQixJQUFwRSxJQUEwRSxLQUFLd3NCLE1BQUwsRUFBMUU7QUFBd0YsT0FBNUcsRUFBNkcsSUFBN0csQ0FBaEssRUFBbVIsbUJBQWtCbkcsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLEtBQUtpdEIsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQjlLLFVBQWpDLElBQTZDMEssRUFBRTdkLE9BQUYsQ0FBVXdQLE9BQVYsQ0FBa0IsTUFBSSxLQUFLd1gsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQjJELFNBQTFDLEVBQXFEekosS0FBckQsT0FBK0QsS0FBSzZPLEtBQUwsQ0FBVzVoQixPQUFYLEVBQTVHLElBQWtJLEtBQUs0ZSxNQUFMLEVBQWxJO0FBQWdKLE9BQXBLLEVBQXFLLElBQXJLLENBQXJTLEVBQTVCLEVBQTZlLEtBQUtnRCxLQUFMLENBQVc5YyxPQUFYLEdBQW1CMlQsRUFBRXJhLE1BQUYsQ0FBUyxFQUFULEVBQVl2SSxFQUFFaWpCLFFBQWQsRUFBdUIsS0FBSzhJLEtBQUwsQ0FBVzljLE9BQWxDLENBQWhnQixFQUEyaUIsS0FBSzhjLEtBQUwsQ0FBVzd1QixRQUFYLENBQW9CbU0sRUFBcEIsQ0FBdUIsS0FBSzZaLFNBQTVCLENBQTNpQjtBQUFrbEIsR0FBcG1CLENBQXFtQmxqQixFQUFFaWpCLFFBQUYsR0FBVyxFQUFDL0ssWUFBVyxDQUFDLENBQWIsRUFBZWdWLGlCQUFnQixZQUEvQixFQUFYLEVBQXdEbHRCLEVBQUVrQyxTQUFGLENBQVk2bUIsTUFBWixHQUFtQixZQUFVO0FBQUMsUUFBSWxHLElBQUUsS0FBS2tKLEtBQUwsQ0FBVzNJLFFBQWpCO0FBQUEsUUFBMEJOLElBQUVELElBQUUsS0FBS2tKLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0J4VSxLQUFsRDtBQUFBLFFBQXdEdVUsSUFBRSxLQUFLZ0osS0FBTCxDQUFXeEUsTUFBWCxDQUFrQnpZLFFBQWxCLEdBQTZCcWUsT0FBN0IsR0FBdUMvdEIsS0FBdkMsQ0FBNkN5akIsQ0FBN0MsRUFBK0NDLENBQS9DLENBQTFEO0FBQUEsUUFBNEc5aUIsSUFBRSxFQUE5RztBQUFBLFFBQWlIeW5CLElBQUUsQ0FBbkgsQ0FBcUg3RSxFQUFFN2tCLElBQUYsQ0FBT2dsQixDQUFQLEVBQVMsVUFBU0YsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQzlpQixRQUFFM0MsSUFBRixDQUFPdWxCLEVBQUVFLENBQUYsRUFBS3BkLE1BQUwsRUFBUDtBQUFzQixLQUE3QyxHQUErQytoQixJQUFFMW9CLEtBQUt3RSxHQUFMLENBQVM5QixLQUFULENBQWUsSUFBZixFQUFvQnpCLENBQXBCLENBQWpELEVBQXdFLEtBQUsrckIsS0FBTCxDQUFXeEUsTUFBWCxDQUFrQnZpQixNQUFsQixHQUEyQlUsTUFBM0IsQ0FBa0MraEIsQ0FBbEMsRUFBcUMzWixRQUFyQyxDQUE4QyxLQUFLaWUsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQmtLLGVBQWxFLENBQXhFO0FBQTJKLEdBQXRXLEVBQXVXbHRCLEVBQUVrQyxTQUFGLENBQVlrZSxPQUFaLEdBQW9CLFlBQVU7QUFBQyxRQUFJd0MsQ0FBSixFQUFNQyxDQUFOLENBQVEsS0FBSUQsQ0FBSixJQUFTLEtBQUtNLFNBQWQ7QUFBd0IsV0FBSzZJLEtBQUwsQ0FBVzd1QixRQUFYLENBQW9Cd00sR0FBcEIsQ0FBd0JrWixDQUF4QixFQUEwQixLQUFLTSxTQUFMLENBQWVOLENBQWYsQ0FBMUI7QUFBeEIsS0FBcUUsS0FBSUMsQ0FBSixJQUFTcmtCLE9BQU8rdEIsbUJBQVAsQ0FBMkIsSUFBM0IsQ0FBVDtBQUEwQyxvQkFBWSxPQUFPLEtBQUsxSixDQUFMLENBQW5CLEtBQTZCLEtBQUtBLENBQUwsSUFBUSxJQUFyQztBQUExQztBQUFxRixHQUF4aUIsRUFBeWlCRCxFQUFFbmdCLEVBQUYsQ0FBS21wQixXQUFMLENBQWlCQyxXQUFqQixDQUE2QnBILE9BQTdCLENBQXFDMkksVUFBckMsR0FBZ0RwdEIsQ0FBemxCO0FBQTJsQixDQUFsdEMsQ0FBbXRDd0MsT0FBT3NwQixLQUFQLElBQWN0cEIsT0FBT2tDLE1BQXh1QyxFQUErdUNsQyxNQUEvdUMsRUFBc3ZDOUIsUUFBdHZDLENBQWp1dkIsRUFBaSt4QixVQUFTa2lCLENBQVQsRUFBV0MsQ0FBWCxFQUFhQyxDQUFiLEVBQWVDLENBQWYsRUFBaUI7QUFBQyxNQUFJL2lCLElBQUUsU0FBRkEsQ0FBRSxDQUFTNmlCLENBQVQsRUFBVztBQUFDLFNBQUtrSixLQUFMLEdBQVdsSixDQUFYLEVBQWEsS0FBS3dLLE9BQUwsR0FBYSxFQUExQixFQUE2QixLQUFLQyxRQUFMLEdBQWMsSUFBM0MsRUFBZ0QsS0FBS3BLLFNBQUwsR0FBZSxFQUFDLDRCQUEyQk4sRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLEtBQUtpdEIsS0FBTCxDQUFXampCLFFBQVgsQ0FBb0IsRUFBQzdLLE1BQUssT0FBTixFQUFjMUIsTUFBSyxTQUFuQixFQUE2QjZuQixNQUFLLENBQUMsYUFBRCxDQUFsQyxFQUFwQixDQUFiO0FBQXFGLE9BQXpHLEVBQTBHLElBQTFHLENBQTVCLEVBQTRJLHVCQUFzQnhCLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsSUFBYSxLQUFLaXRCLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0J1SyxLQUFqQyxJQUF3QyxLQUFLQyxjQUFMLEVBQXhDLElBQStENUssRUFBRXJaLGNBQUYsRUFBL0Q7QUFBa0YsT0FBdEcsRUFBdUcsSUFBdkcsQ0FBbEssRUFBK1EsMEJBQXlCcVosRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLEtBQUtpdEIsS0FBTCxDQUFXbGpCLEVBQVgsQ0FBYyxVQUFkLENBQWIsSUFBd0MsS0FBS2tqQixLQUFMLENBQVd4RSxNQUFYLENBQWtCOW5CLElBQWxCLENBQXVCLDBCQUF2QixFQUFtRHVhLE1BQW5ELEVBQXhDO0FBQW9HLE9BQXhILEVBQXlILElBQXpILENBQXhTLEVBQXVhLHdCQUF1QjRJLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsSUFBYSxlQUFhOGpCLEVBQUUrRixRQUFGLENBQVdwc0IsSUFBckMsSUFBMkMsS0FBSyt3QixRQUFoRCxJQUEwRCxLQUFLalUsSUFBTCxFQUExRDtBQUFzRSxPQUExRixFQUEyRixJQUEzRixDQUE5YixFQUEraEIseUJBQXdCdUosRUFBRTRCLEtBQUYsQ0FBUSxVQUFTM0IsQ0FBVCxFQUFXO0FBQUMsWUFBR0EsRUFBRS9qQixTQUFMLEVBQWU7QUFBQyxjQUFJZ2tCLElBQUVGLEVBQUVDLEVBQUVpRyxPQUFKLEVBQWFycEIsSUFBYixDQUFrQixZQUFsQixDQUFOLENBQXNDcWpCLEVBQUVqa0IsTUFBRixLQUFXaWtCLEVBQUV4WSxHQUFGLENBQU0sU0FBTixFQUFnQixNQUFoQixHQUF3QixLQUFLbWpCLEtBQUwsQ0FBVzNLLENBQVgsRUFBYUYsRUFBRUMsRUFBRWlHLE9BQUosQ0FBYixDQUFuQztBQUErRDtBQUFDLE9BQTFJLEVBQTJJLElBQTNJLENBQXZqQixFQUEvRCxFQUF3d0IsS0FBS2lELEtBQUwsQ0FBVzljLE9BQVgsR0FBbUIyVCxFQUFFcmEsTUFBRixDQUFTLEVBQVQsRUFBWXZJLEVBQUVpakIsUUFBZCxFQUF1QixLQUFLOEksS0FBTCxDQUFXOWMsT0FBbEMsQ0FBM3hCLEVBQXMwQixLQUFLOGMsS0FBTCxDQUFXN3VCLFFBQVgsQ0FBb0JtTSxFQUFwQixDQUF1QixLQUFLNlosU0FBNUIsQ0FBdDBCLEVBQTYyQixLQUFLNkksS0FBTCxDQUFXN3VCLFFBQVgsQ0FBb0JtTSxFQUFwQixDQUF1QixpQkFBdkIsRUFBeUMsc0JBQXpDLEVBQWdFdVosRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUMsV0FBSzhLLElBQUwsQ0FBVTlLLENBQVY7QUFBYSxLQUFqQyxFQUFrQyxJQUFsQyxDQUFoRSxDQUE3MkI7QUFBczlCLEdBQXgrQixDQUF5K0I1aUIsRUFBRWlqQixRQUFGLEdBQVcsRUFBQ3NLLE9BQU0sQ0FBQyxDQUFSLEVBQVVJLGFBQVksQ0FBQyxDQUF2QixFQUF5QkMsWUFBVyxDQUFDLENBQXJDLEVBQVgsRUFBbUQ1dEIsRUFBRWtDLFNBQUYsQ0FBWXVyQixLQUFaLEdBQWtCLFVBQVM3SyxDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFFBQUlDLElBQUUsWUFBVTtBQUFDLGFBQU9GLEVBQUV2bUIsSUFBRixDQUFPLGVBQVAsSUFBd0IsT0FBeEIsR0FBZ0N1bUIsRUFBRXZtQixJQUFGLENBQU8sZUFBUCxJQUF3QixPQUF4QixHQUFnQyxTQUF2RTtBQUFpRixLQUE1RixFQUFOO0FBQUEsUUFBcUcwbUIsSUFBRUgsRUFBRXZtQixJQUFGLENBQU8sZUFBUCxLQUF5QnVtQixFQUFFdm1CLElBQUYsQ0FBTyxpQkFBUCxDQUF6QixJQUFvRHVtQixFQUFFdm1CLElBQUYsQ0FBTyxlQUFQLENBQTNKO0FBQUEsUUFBbUwyRCxJQUFFNGlCLEVBQUV2bUIsSUFBRixDQUFPLFlBQVAsS0FBc0IsS0FBSzB2QixLQUFMLENBQVcvSSxRQUFYLENBQW9CNEssVUFBL047QUFBQSxRQUEwT25HLElBQUU3RSxFQUFFdm1CLElBQUYsQ0FBTyxhQUFQLEtBQXVCLEtBQUswdkIsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQjJLLFdBQXZSO0FBQUEsUUFBbVNoRyxJQUFFL0UsRUFBRXZtQixJQUFGLENBQU8sTUFBUCxDQUFyUyxDQUFvVCxJQUFHLENBQUNzckIsQ0FBSixFQUFNLE1BQU0sSUFBSTdoQixLQUFKLENBQVUsb0JBQVYsQ0FBTixDQUFzQyxJQUFHaWQsSUFBRTRFLEVBQUVoTixLQUFGLENBQVEseU1BQVIsQ0FBRixFQUFxTm9JLEVBQUUsQ0FBRixFQUFLdmxCLE9BQUwsQ0FBYSxPQUFiLElBQXNCLENBQUMsQ0FBL08sRUFBaVBzbEIsSUFBRSxTQUFGLENBQWpQLEtBQWtRLElBQUdDLEVBQUUsQ0FBRixFQUFLdmxCLE9BQUwsQ0FBYSxPQUFiLElBQXNCLENBQUMsQ0FBMUIsRUFBNEJzbEIsSUFBRSxPQUFGLENBQTVCLEtBQTBDO0FBQUMsVUFBRyxFQUFFQyxFQUFFLENBQUYsRUFBS3ZsQixPQUFMLENBQWEsT0FBYixJQUFzQixDQUFDLENBQXpCLENBQUgsRUFBK0IsTUFBTSxJQUFJc0ksS0FBSixDQUFVLDBCQUFWLENBQU4sQ0FBNENnZCxJQUFFLE9BQUY7QUFBVSxTQUFFQyxFQUFFLENBQUYsQ0FBRixFQUFPLEtBQUtzSyxPQUFMLENBQWExRixDQUFiLElBQWdCLEVBQUMxcEIsTUFBSzZrQixDQUFOLEVBQVFuWCxJQUFHb1gsQ0FBWCxFQUFhcGQsT0FBTTNGLENBQW5CLEVBQXFCMEYsUUFBTytoQixDQUE1QixFQUF2QixFQUFzRDVFLEVBQUV4bUIsSUFBRixDQUFPLFlBQVAsRUFBb0JzckIsQ0FBcEIsQ0FBdEQsRUFBNkUsS0FBS2tHLFNBQUwsQ0FBZWpMLENBQWYsRUFBaUIsS0FBS3lLLE9BQUwsQ0FBYTFGLENBQWIsQ0FBakIsQ0FBN0U7QUFBK0csR0FBcDZCLEVBQXE2QjNuQixFQUFFa0MsU0FBRixDQUFZMnJCLFNBQVosR0FBc0IsVUFBU2hMLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsUUFBSUMsQ0FBSjtBQUFBLFFBQU0vaUIsQ0FBTjtBQUFBLFFBQVF5bkIsQ0FBUjtBQUFBLFFBQVVFLElBQUU3RSxFQUFFbmQsS0FBRixJQUFTbWQsRUFBRXBkLE1BQVgsR0FBa0Isa0JBQWdCb2QsRUFBRW5kLEtBQWxCLEdBQXdCLFlBQXhCLEdBQXFDbWQsRUFBRXBkLE1BQXZDLEdBQThDLE1BQWhFLEdBQXVFLEVBQW5GO0FBQUEsUUFBc0ZraUIsSUFBRS9FLEVBQUVwakIsSUFBRixDQUFPLEtBQVAsQ0FBeEY7QUFBQSxRQUFzR0YsSUFBRSxLQUF4RztBQUFBLFFBQThHOHJCLElBQUUsRUFBaEg7QUFBQSxRQUFtSHpoQixJQUFFLEtBQUttaUIsS0FBTCxDQUFXL0ksUUFBaEk7QUFBQSxRQUF5SThLLElBQUUsU0FBRkEsQ0FBRSxDQUFTbEwsQ0FBVCxFQUFXO0FBQUM1aUIsVUFBRSx5Q0FBRixFQUE0QytpQixJQUFFblosRUFBRThpQixRQUFGLEdBQVcsOEJBQTRCckIsQ0FBNUIsR0FBOEIsSUFBOUIsR0FBbUM5ckIsQ0FBbkMsR0FBcUMsSUFBckMsR0FBMENxakIsQ0FBMUMsR0FBNEMsVUFBdkQsR0FBa0UscUVBQW1FQSxDQUFuRSxHQUFxRSxXQUFyTCxFQUFpTUMsRUFBRStILEtBQUYsQ0FBUTdILENBQVIsQ0FBak0sRUFBNE1GLEVBQUUrSCxLQUFGLENBQVE1cUIsQ0FBUixDQUE1TTtBQUF1TixLQUE5VyxDQUErVyxJQUFHNmlCLEVBQUVuTCxJQUFGLENBQU8sbUNBQWlDaVEsQ0FBakMsR0FBbUMsU0FBMUMsR0FBcUQsS0FBS29FLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0IwSixRQUFwQixLQUErQm50QixJQUFFLFVBQUYsRUFBYThyQixJQUFFLFVBQTlDLENBQXJELEVBQStHekQsRUFBRS9vQixNQUFwSCxFQUEySCxPQUFPaXZCLEVBQUVsRyxFQUFFdnJCLElBQUYsQ0FBT2tELENBQVAsQ0FBRixHQUFhcW9CLEVBQUU1TixNQUFGLEVBQWIsRUFBd0IsQ0FBQyxDQUFoQyxDQUFrQyxjQUFZOEksRUFBRTdrQixJQUFkLElBQW9Cd3BCLElBQUUsMEJBQXdCM0UsRUFBRW5YLEVBQTFCLEdBQTZCLGdCQUEvQixFQUFnRG1pQixFQUFFckcsQ0FBRixDQUFwRSxJQUEwRSxZQUFVM0UsRUFBRTdrQixJQUFaLEdBQWlCMmtCLEVBQUVtTCxJQUFGLENBQU8sRUFBQzl2QixNQUFLLEtBQU4sRUFBWTR1QixLQUFJLDhCQUE0Qi9KLEVBQUVuWCxFQUE5QixHQUFpQyxPQUFqRCxFQUF5RHFpQixPQUFNLFVBQS9ELEVBQTBFQyxVQUFTLE9BQW5GLEVBQTJGQyxTQUFRLGlCQUFTdEwsQ0FBVCxFQUFXO0FBQUM2RSxZQUFFN0UsRUFBRSxDQUFGLEVBQUt1TCxlQUFQLEVBQXVCTCxFQUFFckcsQ0FBRixDQUF2QjtBQUE0QixPQUEzSSxFQUFQLENBQWpCLEdBQXNLLFlBQVUzRSxFQUFFN2tCLElBQVosSUFBa0Iya0IsRUFBRW1MLElBQUYsQ0FBTyxFQUFDOXZCLE1BQUssS0FBTixFQUFZNHVCLEtBQUksNEJBQTBCL0osRUFBRW5YLEVBQTVCLEdBQStCLE9BQS9DLEVBQXVEcWlCLE9BQU0sVUFBN0QsRUFBd0VDLFVBQVMsT0FBakYsRUFBeUZDLFNBQVEsaUJBQVN0TCxDQUFULEVBQVc7QUFBQzZFLFlBQUU3RSxFQUFFd0wsYUFBSixFQUFrQk4sRUFBRXJHLENBQUYsQ0FBbEI7QUFBdUIsT0FBcEksRUFBUCxDQUFsUTtBQUFnWixHQUFyMkQsRUFBczJEem5CLEVBQUVrQyxTQUFGLENBQVltWCxJQUFaLEdBQWlCLFlBQVU7QUFBQyxTQUFLMFMsS0FBTCxDQUFXM3VCLE9BQVgsQ0FBbUIsTUFBbkIsRUFBMEIsSUFBMUIsRUFBK0IsT0FBL0IsR0FBd0MsS0FBS2t3QixRQUFMLENBQWM3dEIsSUFBZCxDQUFtQixrQkFBbkIsRUFBdUN1YSxNQUF2QyxFQUF4QyxFQUF3RixLQUFLc1QsUUFBTCxDQUFjdnJCLFdBQWQsQ0FBMEIsbUJBQTFCLENBQXhGLEVBQXVJLEtBQUt1ckIsUUFBTCxHQUFjLElBQXJKLEVBQTBKLEtBQUt2QixLQUFMLENBQVd2RCxLQUFYLENBQWlCLFNBQWpCLENBQTFKLEVBQXNMLEtBQUt1RCxLQUFMLENBQVczdUIsT0FBWCxDQUFtQixTQUFuQixFQUE2QixJQUE3QixFQUFrQyxPQUFsQyxDQUF0TDtBQUFpTyxHQUFubUUsRUFBb21FNEMsRUFBRWtDLFNBQUYsQ0FBWXdyQixJQUFaLEdBQWlCLFVBQVM3SyxDQUFULEVBQVc7QUFBQyxRQUFJQyxDQUFKO0FBQUEsUUFBTUMsSUFBRUgsRUFBRUMsRUFBRXZaLE1BQUosQ0FBUjtBQUFBLFFBQW9CdEosSUFBRStpQixFQUFFeE8sT0FBRixDQUFVLE1BQUksS0FBS3dYLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0IyRCxTQUFsQyxDQUF0QjtBQUFBLFFBQW1FYyxJQUFFLEtBQUs0RixPQUFMLENBQWFydEIsRUFBRTNELElBQUYsQ0FBTyxZQUFQLENBQWIsQ0FBckU7QUFBQSxRQUF3R3NyQixJQUFFRixFQUFFOWhCLEtBQUYsSUFBUyxNQUFuSDtBQUFBLFFBQTBIaWlCLElBQUVILEVBQUUvaEIsTUFBRixJQUFVLEtBQUtxbUIsS0FBTCxDQUFXeEUsTUFBWCxDQUFrQjdoQixNQUFsQixFQUF0SSxDQUFpSyxLQUFLNG5CLFFBQUwsS0FBZ0IsS0FBS3ZCLEtBQUwsQ0FBVzVELEtBQVgsQ0FBaUIsU0FBakIsR0FBNEIsS0FBSzRELEtBQUwsQ0FBVzN1QixPQUFYLENBQW1CLE1BQW5CLEVBQTBCLElBQTFCLEVBQStCLE9BQS9CLENBQTVCLEVBQW9FNEMsSUFBRSxLQUFLK3JCLEtBQUwsQ0FBV3ZkLEtBQVgsQ0FBaUIsS0FBS3VkLEtBQUwsQ0FBV3pFLFFBQVgsQ0FBb0J0bkIsRUFBRWtkLEtBQUYsRUFBcEIsQ0FBakIsQ0FBdEUsRUFBdUgsS0FBSzZPLEtBQUwsQ0FBV2xlLEtBQVgsQ0FBaUI3TixFQUFFa2QsS0FBRixFQUFqQixDQUF2SCxFQUFtSixjQUFZdUssRUFBRXhwQixJQUFkLEdBQW1CNmtCLElBQUUsb0JBQWtCNkUsQ0FBbEIsR0FBb0IsWUFBcEIsR0FBaUNDLENBQWpDLEdBQW1DLGlDQUFuQyxHQUFxRUgsRUFBRTliLEVBQXZFLEdBQTBFLHNCQUExRSxHQUFpRzhiLEVBQUU5YixFQUFuRyxHQUFzRyw2Q0FBM0gsR0FBeUssWUFBVThiLEVBQUV4cEIsSUFBWixHQUFpQjZrQixJQUFFLDJDQUF5QzJFLEVBQUU5YixFQUEzQyxHQUE4QyxzQkFBOUMsR0FBcUVnYyxDQUFyRSxHQUF1RSxZQUF2RSxHQUFvRkMsQ0FBcEYsR0FBc0Ysc0ZBQXpHLEdBQWdNLFlBQVVILEVBQUV4cEIsSUFBWixLQUFtQjZrQixJQUFFLG9DQUFrQzhFLENBQWxDLEdBQW9DLFVBQXBDLEdBQStDRCxDQUEvQyxHQUFpRCxtRkFBakQsR0FBcUlGLEVBQUU5YixFQUF2SSxHQUEwSSxrQ0FBL0osQ0FBNWYsRUFBK3JCaVgsRUFBRSxrQ0FBZ0NFLENBQWhDLEdBQWtDLFFBQXBDLEVBQThDdUwsV0FBOUMsQ0FBMERydUIsRUFBRVAsSUFBRixDQUFPLFlBQVAsQ0FBMUQsQ0FBL3JCLEVBQSt3QixLQUFLNnRCLFFBQUwsR0FBY3R0QixFQUFFOE4sUUFBRixDQUFXLG1CQUFYLENBQTd5QjtBQUE4MEIsR0FBaG5HLEVBQWluRzlOLEVBQUVrQyxTQUFGLENBQVlzckIsY0FBWixHQUEyQixZQUFVO0FBQUMsUUFBSTNLLElBQUVDLEVBQUV3TCxpQkFBRixJQUFxQnhMLEVBQUV5TCxvQkFBdkIsSUFBNkN6TCxFQUFFMEwsdUJBQXJELENBQTZFLE9BQU8zTCxLQUFHRCxFQUFFQyxDQUFGLEVBQUs3ZCxNQUFMLEdBQWN3USxRQUFkLENBQXVCLGlCQUF2QixDQUFWO0FBQW9ELEdBQXh4RyxFQUF5eEd4VixFQUFFa0MsU0FBRixDQUFZa2UsT0FBWixHQUFvQixZQUFVO0FBQUMsUUFBSXdDLENBQUosRUFBTUMsQ0FBTixDQUFRLEtBQUtrSixLQUFMLENBQVc3dUIsUUFBWCxDQUFvQndNLEdBQXBCLENBQXdCLGlCQUF4QixFQUEyQyxLQUFJa1osQ0FBSixJQUFTLEtBQUtNLFNBQWQ7QUFBd0IsV0FBSzZJLEtBQUwsQ0FBVzd1QixRQUFYLENBQW9Cd00sR0FBcEIsQ0FBd0JrWixDQUF4QixFQUEwQixLQUFLTSxTQUFMLENBQWVOLENBQWYsQ0FBMUI7QUFBeEIsS0FBcUUsS0FBSUMsQ0FBSixJQUFTcmtCLE9BQU8rdEIsbUJBQVAsQ0FBMkIsSUFBM0IsQ0FBVDtBQUEwQyxvQkFBWSxPQUFPLEtBQUsxSixDQUFMLENBQW5CLEtBQTZCLEtBQUtBLENBQUwsSUFBUSxJQUFyQztBQUExQztBQUFxRixHQUFyZ0gsRUFBc2dIRCxFQUFFbmdCLEVBQUYsQ0FBS21wQixXQUFMLENBQWlCQyxXQUFqQixDQUE2QnBILE9BQTdCLENBQXFDZ0ssS0FBckMsR0FBMkN6dUIsQ0FBampIO0FBQW1qSCxDQUE5aUosQ0FBK2lKd0MsT0FBT3NwQixLQUFQLElBQWN0cEIsT0FBT2tDLE1BQXBrSixFQUEya0psQyxNQUEza0osRUFBa2xKOUIsUUFBbGxKLENBQWoreEIsRUFBNmo3QixVQUFTa2lCLENBQVQsRUFBV0MsQ0FBWCxFQUFhQyxDQUFiLEVBQWVDLENBQWYsRUFBaUI7QUFBQyxNQUFJL2lCLElBQUUsU0FBRkEsQ0FBRSxDQUFTNmlCLENBQVQsRUFBVztBQUFDLFNBQUs2TCxJQUFMLEdBQVU3TCxDQUFWLEVBQVksS0FBSzZMLElBQUwsQ0FBVXpmLE9BQVYsR0FBa0IyVCxFQUFFcmEsTUFBRixDQUFTLEVBQVQsRUFBWXZJLEVBQUVpakIsUUFBZCxFQUF1QixLQUFLeUwsSUFBTCxDQUFVemYsT0FBakMsQ0FBOUIsRUFBd0UsS0FBSzBmLFFBQUwsR0FBYyxDQUFDLENBQXZGLEVBQXlGLEtBQUtuVixRQUFMLEdBQWN1SixDQUF2RyxFQUF5RyxLQUFLNU0sSUFBTCxHQUFVNE0sQ0FBbkgsRUFBcUgsS0FBS2lLLFFBQUwsR0FBYyxFQUFDLHVCQUFzQnBLLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsSUFBYSxjQUFZOGpCLEVBQUUrRixRQUFGLENBQVdwc0IsSUFBcEMsS0FBMkMsS0FBS2lkLFFBQUwsR0FBYyxLQUFLa1YsSUFBTCxDQUFVdmtCLE9BQVYsRUFBZCxFQUFrQyxLQUFLZ00sSUFBTCxHQUFVeU0sRUFBRStGLFFBQUYsQ0FBV2plLEtBQWxHO0FBQXlHLE9BQTdILEVBQThILElBQTlILENBQXZCLEVBQTJKLGtFQUFpRWtZLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsS0FBYyxLQUFLNnZCLFFBQUwsR0FBYyxnQkFBYy9MLEVBQUUza0IsSUFBNUM7QUFBa0QsT0FBdEUsRUFBdUUsSUFBdkUsQ0FBNU4sRUFBeVMsMEJBQXlCMmtCLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsSUFBYSxLQUFLNnZCLFFBQWxCLEtBQTZCLEtBQUtELElBQUwsQ0FBVXpmLE9BQVYsQ0FBa0I5QixVQUFsQixJQUE4QixLQUFLdWhCLElBQUwsQ0FBVXpmLE9BQVYsQ0FBa0JsQyxTQUE3RSxLQUF5RixLQUFLNmhCLElBQUwsRUFBekY7QUFBcUcsT0FBekgsRUFBMEgsSUFBMUgsQ0FBbFUsRUFBbkksRUFBc2tCLEtBQUtGLElBQUwsQ0FBVXh4QixRQUFWLENBQW1CbU0sRUFBbkIsQ0FBc0IsS0FBSzJqQixRQUEzQixDQUF0a0I7QUFBMm1CLEdBQTduQixDQUE4bkJodEIsRUFBRWlqQixRQUFGLEdBQVcsRUFBQzlWLFlBQVcsQ0FBQyxDQUFiLEVBQWVKLFdBQVUsQ0FBQyxDQUExQixFQUFYLEVBQXdDL00sRUFBRWtDLFNBQUYsQ0FBWTBzQixJQUFaLEdBQWlCLFlBQVU7QUFBQyxRQUFHLE1BQUksS0FBS0YsSUFBTCxDQUFVMUwsUUFBVixDQUFtQnhVLEtBQXZCLElBQThCb1UsRUFBRTBHLE9BQUYsQ0FBVXRjLFNBQXhDLElBQW1ENFYsRUFBRTBHLE9BQUYsQ0FBVW5MLFVBQWhFLEVBQTJFO0FBQUMsV0FBS3VRLElBQUwsQ0FBVS9FLEtBQVYsQ0FBZ0IsQ0FBaEIsRUFBbUIsSUFBSTlHLENBQUo7QUFBQSxVQUFNQyxJQUFFRixFQUFFNEIsS0FBRixDQUFRLEtBQUs3RyxLQUFiLEVBQW1CLElBQW5CLENBQVI7QUFBQSxVQUFpQ29GLElBQUUsS0FBSzJMLElBQUwsQ0FBVW5ILE1BQVYsQ0FBaUJ6WSxRQUFqQixHQUE0QjNGLEVBQTVCLENBQStCLEtBQUtxUSxRQUFwQyxDQUFuQztBQUFBLFVBQWlGeFosSUFBRSxLQUFLMHVCLElBQUwsQ0FBVW5ILE1BQVYsQ0FBaUJ6WSxRQUFqQixHQUE0QjNGLEVBQTVCLENBQStCLEtBQUtnTixJQUFwQyxDQUFuRjtBQUFBLFVBQTZIc1IsSUFBRSxLQUFLaUgsSUFBTCxDQUFVMUwsUUFBVixDQUFtQmpXLFNBQWxKO0FBQUEsVUFBNEo0YSxJQUFFLEtBQUsrRyxJQUFMLENBQVUxTCxRQUFWLENBQW1CN1YsVUFBakwsQ0FBNEwsS0FBS3VoQixJQUFMLENBQVV2a0IsT0FBVixPQUFzQixLQUFLcVAsUUFBM0IsS0FBc0NtTyxNQUFJOUUsSUFBRSxLQUFLNkwsSUFBTCxDQUFVekcsV0FBVixDQUFzQixLQUFLek8sUUFBM0IsSUFBcUMsS0FBS2tWLElBQUwsQ0FBVXpHLFdBQVYsQ0FBc0IsS0FBSzlSLElBQTNCLENBQXZDLEVBQXdFNE0sRUFBRTlVLEdBQUYsQ0FBTTJVLEVBQUUwRyxPQUFGLENBQVV0YyxTQUFWLENBQW9CcE0sR0FBMUIsRUFBOEJraUIsQ0FBOUIsRUFBaUN4WSxHQUFqQyxDQUFxQyxFQUFDaEYsTUFBS3VkLElBQUUsSUFBUixFQUFyQyxFQUFvRC9VLFFBQXBELENBQTZELDJCQUE3RCxFQUEwRkEsUUFBMUYsQ0FBbUc2WixDQUFuRyxDQUE1RSxHQUFtTEYsS0FBR3puQixFQUFFaU8sR0FBRixDQUFNMlUsRUFBRTBHLE9BQUYsQ0FBVXRjLFNBQVYsQ0FBb0JwTSxHQUExQixFQUE4QmtpQixDQUE5QixFQUFpQ2hWLFFBQWpDLENBQTBDLDBCQUExQyxFQUFzRUEsUUFBdEUsQ0FBK0UyWixDQUEvRSxDQUE1TjtBQUErUztBQUFDLEdBQS9vQixFQUFncEJ6bkIsRUFBRWtDLFNBQUYsQ0FBWXliLEtBQVosR0FBa0IsVUFBU2tGLENBQVQsRUFBVztBQUFDRCxNQUFFQyxFQUFFdlosTUFBSixFQUFZZ0IsR0FBWixDQUFnQixFQUFDaEYsTUFBSyxFQUFOLEVBQWhCLEVBQTJCdkQsV0FBM0IsQ0FBdUMsMkNBQXZDLEVBQW9GQSxXQUFwRixDQUFnRyxLQUFLMnNCLElBQUwsQ0FBVTFMLFFBQVYsQ0FBbUJqVyxTQUFuSCxFQUE4SGhMLFdBQTlILENBQTBJLEtBQUsyc0IsSUFBTCxDQUFVMUwsUUFBVixDQUFtQjdWLFVBQTdKLEdBQXlLLEtBQUt1aEIsSUFBTCxDQUFVbkYsZUFBVixFQUF6SztBQUFxTSxHQUFuM0IsRUFBbzNCdnBCLEVBQUVrQyxTQUFGLENBQVlrZSxPQUFaLEdBQW9CLFlBQVU7QUFBQyxRQUFJd0MsQ0FBSixFQUFNQyxDQUFOLENBQVEsS0FBSUQsQ0FBSixJQUFTLEtBQUtvSyxRQUFkO0FBQXVCLFdBQUswQixJQUFMLENBQVV4eEIsUUFBVixDQUFtQndNLEdBQW5CLENBQXVCa1osQ0FBdkIsRUFBeUIsS0FBS29LLFFBQUwsQ0FBY3BLLENBQWQsQ0FBekI7QUFBdkIsS0FBa0UsS0FBSUMsQ0FBSixJQUFTcmtCLE9BQU8rdEIsbUJBQVAsQ0FBMkIsSUFBM0IsQ0FBVDtBQUEwQyxvQkFBWSxPQUFPLEtBQUsxSixDQUFMLENBQW5CLEtBQTZCLEtBQUtBLENBQUwsSUFBUSxJQUFyQztBQUExQztBQUFxRixHQUFsakMsRUFDN3M4QkQsRUFBRW5nQixFQUFGLENBQUttcEIsV0FBTCxDQUFpQkMsV0FBakIsQ0FBNkJwSCxPQUE3QixDQUFxQ29LLE9BQXJDLEdBQTZDN3VCLENBRGdxOEI7QUFDOXA4QixDQUQ4ZzdCLENBQzdnN0J3QyxPQUFPc3BCLEtBQVAsSUFBY3RwQixPQUFPa0MsTUFEdy82QixFQUNqLzZCbEMsTUFEaS82QixFQUMxKzZCOUIsUUFEMCs2QixDQUE3ajdCLEVBQzZGLFVBQVNraUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZUMsQ0FBZixFQUFpQjtBQUFDLE1BQUkvaUIsSUFBRSxTQUFGQSxDQUFFLENBQVM2aUIsQ0FBVCxFQUFXO0FBQUMsU0FBS2tKLEtBQUwsR0FBV2xKLENBQVgsRUFBYSxLQUFLaU0sUUFBTCxHQUFjLElBQTNCLEVBQWdDLEtBQUtDLE9BQUwsR0FBYSxDQUFDLENBQTlDLEVBQWdELEtBQUs3TCxTQUFMLEdBQWUsRUFBQyx3QkFBdUJOLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsSUFBYSxlQUFhOGpCLEVBQUUrRixRQUFGLENBQVdwc0IsSUFBckMsR0FBMEMsS0FBS3d2QixLQUFMLENBQVcvSSxRQUFYLENBQW9CZ00sUUFBcEIsR0FBNkIsS0FBS3RCLElBQUwsRUFBN0IsR0FBeUMsS0FBS3JVLElBQUwsRUFBbkYsR0FBK0Z1SixFQUFFOWpCLFNBQUYsSUFBYSxlQUFhOGpCLEVBQUUrRixRQUFGLENBQVdwc0IsSUFBckMsSUFBMkMsS0FBS3d2QixLQUFMLENBQVcvSSxRQUFYLENBQW9CZ00sUUFBL0QsSUFBeUUsS0FBS0Msb0JBQUwsRUFBeEs7QUFBb00sT0FBeE4sRUFBeU4sSUFBek4sQ0FBeEIsRUFBdVAsNEJBQTJCck0sRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLEtBQUtpdEIsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQmdNLFFBQWpDLElBQTJDLEtBQUt0QixJQUFMLEVBQTNDO0FBQXVELE9BQTNFLEVBQTRFLElBQTVFLENBQWxSLEVBQW9XLHFCQUFvQjlLLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBV0MsQ0FBWCxFQUFhQyxDQUFiLEVBQWU7QUFBQ0YsVUFBRTlqQixTQUFGLElBQWEsS0FBSzR1QixJQUFMLENBQVU3SyxDQUFWLEVBQVlDLENBQVosQ0FBYjtBQUE0QixPQUFwRCxFQUFxRCxJQUFyRCxDQUF4WCxFQUFtYixxQkFBb0JGLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsSUFBYSxLQUFLdWEsSUFBTCxFQUFiO0FBQXlCLE9BQTdDLEVBQThDLElBQTlDLENBQXZjLEVBQTJmLDBCQUF5QnVKLEVBQUU0QixLQUFGLENBQVEsWUFBVTtBQUFDLGFBQUt1SCxLQUFMLENBQVcvSSxRQUFYLENBQW9Ca00sa0JBQXBCLElBQXdDLEtBQUtuRCxLQUFMLENBQVdsakIsRUFBWCxDQUFjLFVBQWQsQ0FBeEMsSUFBbUUsS0FBSzBHLEtBQUwsRUFBbkU7QUFBZ0YsT0FBbkcsRUFBb0csSUFBcEcsQ0FBcGhCLEVBQThuQiwyQkFBMEJxVCxFQUFFNEIsS0FBRixDQUFRLFlBQVU7QUFBQyxhQUFLdUgsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQmtNLGtCQUFwQixJQUF3QyxLQUFLbkQsS0FBTCxDQUFXbGpCLEVBQVgsQ0FBYyxVQUFkLENBQXhDLElBQW1FLEtBQUs2a0IsSUFBTCxFQUFuRTtBQUErRSxPQUFsRyxFQUFtRyxJQUFuRyxDQUF4cEIsRUFBaXdCLHVCQUFzQjlLLEVBQUU0QixLQUFGLENBQVEsWUFBVTtBQUFDLGFBQUt1SCxLQUFMLENBQVcvSSxRQUFYLENBQW9Ca00sa0JBQXBCLElBQXdDLEtBQUtuRCxLQUFMLENBQVdsakIsRUFBWCxDQUFjLFVBQWQsQ0FBeEMsSUFBbUUsS0FBSzBHLEtBQUwsRUFBbkU7QUFBZ0YsT0FBbkcsRUFBb0csSUFBcEcsQ0FBdnhCLEVBQWk0QixxQkFBb0JxVCxFQUFFNEIsS0FBRixDQUFRLFlBQVU7QUFBQyxhQUFLdUgsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQmtNLGtCQUFwQixJQUF3QyxLQUFLeEIsSUFBTCxFQUF4QztBQUFvRCxPQUF2RSxFQUF3RSxJQUF4RSxDQUFyNUIsRUFBL0QsRUFBbWlDLEtBQUszQixLQUFMLENBQVc3dUIsUUFBWCxDQUFvQm1NLEVBQXBCLENBQXVCLEtBQUs2WixTQUE1QixDQUFuaUMsRUFBMGtDLEtBQUs2SSxLQUFMLENBQVc5YyxPQUFYLEdBQW1CMlQsRUFBRXJhLE1BQUYsQ0FBUyxFQUFULEVBQVl2SSxFQUFFaWpCLFFBQWQsRUFBdUIsS0FBSzhJLEtBQUwsQ0FBVzljLE9BQWxDLENBQTdsQztBQUF3b0MsR0FBMXBDLENBQTJwQ2pQLEVBQUVpakIsUUFBRixHQUFXLEVBQUMrTCxVQUFTLENBQUMsQ0FBWCxFQUFhRyxpQkFBZ0IsR0FBN0IsRUFBaUNELG9CQUFtQixDQUFDLENBQXJELEVBQXVERSxlQUFjLENBQUMsQ0FBdEUsRUFBWCxFQUFvRnB2QixFQUFFa0MsU0FBRixDQUFZd3JCLElBQVosR0FBaUIsVUFBUzlLLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsU0FBS2tNLE9BQUwsR0FBYSxDQUFDLENBQWQsRUFBZ0IsS0FBS2hELEtBQUwsQ0FBV2xqQixFQUFYLENBQWMsVUFBZCxNQUE0QixLQUFLa2pCLEtBQUwsQ0FBVzVELEtBQVgsQ0FBaUIsVUFBakIsR0FBNkIsS0FBSzhHLG9CQUFMLEVBQXpELENBQWhCO0FBQXNHLEdBQXpOLEVBQTBOanZCLEVBQUVrQyxTQUFGLENBQVltdEIsZUFBWixHQUE0QixVQUFTdE0sQ0FBVCxFQUFXL2lCLENBQVgsRUFBYTtBQUFDLFdBQU8sS0FBSzh1QixRQUFMLElBQWVqTSxFQUFFcmYsWUFBRixDQUFlLEtBQUtzckIsUUFBcEIsQ0FBZixFQUE2Q2pNLEVBQUU5aEIsVUFBRixDQUFhNmhCLEVBQUU0QixLQUFGLENBQVEsWUFBVTtBQUFDLFdBQUt1SyxPQUFMLElBQWMsS0FBS2hELEtBQUwsQ0FBV2xqQixFQUFYLENBQWMsTUFBZCxDQUFkLElBQXFDLEtBQUtrakIsS0FBTCxDQUFXbGpCLEVBQVgsQ0FBYyxhQUFkLENBQXJDLElBQW1FaWEsRUFBRXdNLE1BQXJFLElBQTZFLEtBQUt2RCxLQUFMLENBQVc1VixJQUFYLENBQWdCblcsS0FBRyxLQUFLK3JCLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0JvTSxhQUF2QyxDQUE3RTtBQUFtSSxLQUF0SixFQUF1SixJQUF2SixDQUFiLEVBQTBLck0sS0FBRyxLQUFLZ0osS0FBTCxDQUFXL0ksUUFBWCxDQUFvQm1NLGVBQWpNLENBQXBEO0FBQXNRLEdBQTFnQixFQUEyZ0JudkIsRUFBRWtDLFNBQUYsQ0FBWStzQixvQkFBWixHQUFpQyxZQUFVO0FBQUMsU0FBS0gsUUFBTCxHQUFjLEtBQUtPLGVBQUwsRUFBZDtBQUFxQyxHQUE1bEIsRUFBNmxCcnZCLEVBQUVrQyxTQUFGLENBQVltWCxJQUFaLEdBQWlCLFlBQVU7QUFBQyxTQUFLMFMsS0FBTCxDQUFXbGpCLEVBQVgsQ0FBYyxVQUFkLE1BQTRCZ2EsRUFBRXJmLFlBQUYsQ0FBZSxLQUFLc3JCLFFBQXBCLEdBQThCLEtBQUsvQyxLQUFMLENBQVd2RCxLQUFYLENBQWlCLFVBQWpCLENBQTFEO0FBQXdGLEdBQWp0QixFQUFrdEJ4b0IsRUFBRWtDLFNBQUYsQ0FBWXFOLEtBQVosR0FBa0IsWUFBVTtBQUFDLFNBQUt3YyxLQUFMLENBQVdsakIsRUFBWCxDQUFjLFVBQWQsTUFBNEIsS0FBS2ttQixPQUFMLEdBQWEsQ0FBQyxDQUExQztBQUE2QyxHQUE1eEIsRUFBNnhCL3VCLEVBQUVrQyxTQUFGLENBQVlrZSxPQUFaLEdBQW9CLFlBQVU7QUFBQyxRQUFJd0MsQ0FBSixFQUFNQyxDQUFOLENBQVEsS0FBS3hKLElBQUwsR0FBWSxLQUFJdUosQ0FBSixJQUFTLEtBQUtNLFNBQWQ7QUFBd0IsV0FBSzZJLEtBQUwsQ0FBVzd1QixRQUFYLENBQW9Cd00sR0FBcEIsQ0FBd0JrWixDQUF4QixFQUEwQixLQUFLTSxTQUFMLENBQWVOLENBQWYsQ0FBMUI7QUFBeEIsS0FBcUUsS0FBSUMsQ0FBSixJQUFTcmtCLE9BQU8rdEIsbUJBQVAsQ0FBMkIsSUFBM0IsQ0FBVDtBQUEwQyxvQkFBWSxPQUFPLEtBQUsxSixDQUFMLENBQW5CLEtBQTZCLEtBQUtBLENBQUwsSUFBUSxJQUFyQztBQUExQztBQUFxRixHQUExK0IsRUFBMitCRCxFQUFFbmdCLEVBQUYsQ0FBS21wQixXQUFMLENBQWlCQyxXQUFqQixDQUE2QnBILE9BQTdCLENBQXFDdUssUUFBckMsR0FBOENodkIsQ0FBemhDO0FBQTJoQyxDQUF4c0UsQ0FBeXNFd0MsT0FBT3NwQixLQUFQLElBQWN0cEIsT0FBT2tDLE1BQTl0RSxFQUFxdUVsQyxNQUFydUUsRUFBNHVFOUIsUUFBNXVFLENBRDdGLEVBQ20xRSxVQUFTa2lCLENBQVQsRUFBV0MsQ0FBWCxFQUFhQyxDQUFiLEVBQWVDLENBQWYsRUFBaUI7QUFBQztBQUFhLE1BQUkvaUIsSUFBRSxTQUFGQSxDQUFFLENBQVM2aUIsQ0FBVCxFQUFXO0FBQUMsU0FBS2tKLEtBQUwsR0FBV2xKLENBQVgsRUFBYSxLQUFLME0sWUFBTCxHQUFrQixDQUFDLENBQWhDLEVBQWtDLEtBQUtDLE1BQUwsR0FBWSxFQUE5QyxFQUFpRCxLQUFLQyxTQUFMLEdBQWUsRUFBaEUsRUFBbUUsS0FBS0MsVUFBTCxHQUFnQixFQUFuRixFQUFzRixLQUFLeHlCLFFBQUwsR0FBYyxLQUFLNnVCLEtBQUwsQ0FBVzd1QixRQUEvRyxFQUF3SCxLQUFLeXlCLFVBQUwsR0FBZ0IsRUFBQ3haLE1BQUssS0FBSzRWLEtBQUwsQ0FBVzVWLElBQWpCLEVBQXNCa1UsTUFBSyxLQUFLMEIsS0FBTCxDQUFXMUIsSUFBdEMsRUFBMkNELElBQUcsS0FBSzJCLEtBQUwsQ0FBVzNCLEVBQXpELEVBQXhJLEVBQXFNLEtBQUtsSCxTQUFMLEdBQWUsRUFBQyx5QkFBd0JOLEVBQUU0QixLQUFGLENBQVEsVUFBUzNCLENBQVQsRUFBVztBQUFDQSxVQUFFL2pCLFNBQUYsSUFBYSxLQUFLaXRCLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0I0TSxRQUFqQyxJQUEyQyxLQUFLRixVQUFMLENBQWdCcnlCLElBQWhCLENBQXFCLGlCQUFlLEtBQUswdUIsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQjZNLFFBQW5DLEdBQTRDLElBQTVDLEdBQWlEak4sRUFBRUMsRUFBRWlHLE9BQUosRUFBYXJwQixJQUFiLENBQWtCLFlBQWxCLEVBQWdDQyxPQUFoQyxDQUF3QyxZQUF4QyxFQUFzRHJELElBQXRELENBQTJELFVBQTNELENBQWpELEdBQXdILFFBQTdJLENBQTNDO0FBQWtNLE9BQXROLEVBQXVOLElBQXZOLENBQXpCLEVBQXNQLHNCQUFxQnVtQixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0EsVUFBRTlqQixTQUFGLElBQWEsS0FBS2l0QixLQUFMLENBQVcvSSxRQUFYLENBQW9CNE0sUUFBakMsSUFBMkMsS0FBS0YsVUFBTCxDQUFnQm55QixNQUFoQixDQUF1QnFsQixFQUFFamMsUUFBekIsRUFBa0MsQ0FBbEMsRUFBb0MsS0FBSytvQixVQUFMLENBQWdCSSxHQUFoQixFQUFwQyxDQUEzQztBQUFzRyxPQUExSCxFQUEySCxJQUEzSCxDQUEzUSxFQUE0WSx1QkFBc0JsTixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0EsVUFBRTlqQixTQUFGLElBQWEsS0FBS2l0QixLQUFMLENBQVcvSSxRQUFYLENBQW9CNE0sUUFBakMsSUFBMkMsS0FBS0YsVUFBTCxDQUFnQm55QixNQUFoQixDQUF1QnFsQixFQUFFamMsUUFBekIsRUFBa0MsQ0FBbEMsQ0FBM0M7QUFBZ0YsT0FBcEcsRUFBcUcsSUFBckcsQ0FBbGEsRUFBNmdCLHdCQUF1QmljLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsSUFBYSxjQUFZOGpCLEVBQUUrRixRQUFGLENBQVdwc0IsSUFBcEMsSUFBMEMsS0FBS3d6QixJQUFMLEVBQTFDO0FBQXNELE9BQTFFLEVBQTJFLElBQTNFLENBQXBpQixFQUFxbkIsNEJBQTJCbk4sRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLENBQUMsS0FBS3l3QixZQUFuQixLQUFrQyxLQUFLeEQsS0FBTCxDQUFXM3VCLE9BQVgsQ0FBbUIsWUFBbkIsRUFBZ0MsSUFBaEMsRUFBcUMsWUFBckMsR0FBbUQsS0FBS3luQixVQUFMLEVBQW5ELEVBQXFFLEtBQUtrRSxNQUFMLEVBQXJFLEVBQW1GLEtBQUtnSCxJQUFMLEVBQW5GLEVBQStGLEtBQUtSLFlBQUwsR0FBa0IsQ0FBQyxDQUFsSCxFQUFvSCxLQUFLeEQsS0FBTCxDQUFXM3VCLE9BQVgsQ0FBbUIsYUFBbkIsRUFBaUMsSUFBakMsRUFBc0MsWUFBdEMsQ0FBdEo7QUFBMk0sT0FBL04sRUFBZ08sSUFBaE8sQ0FBaHBCLEVBQXMzQiwwQkFBeUJ3bEIsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLEtBQUt5d0IsWUFBbEIsS0FBaUMsS0FBS3hELEtBQUwsQ0FBVzN1QixPQUFYLENBQW1CLFNBQW5CLEVBQTZCLElBQTdCLEVBQWtDLFlBQWxDLEdBQWdELEtBQUsyckIsTUFBTCxFQUFoRCxFQUE4RCxLQUFLZ0gsSUFBTCxFQUE5RCxFQUEwRSxLQUFLaEUsS0FBTCxDQUFXM3VCLE9BQVgsQ0FBbUIsV0FBbkIsRUFBK0IsSUFBL0IsRUFBb0MsWUFBcEMsQ0FBM0c7QUFBOEosT0FBbEwsRUFBbUwsSUFBbkwsQ0FBLzRCLEVBQXBOLEVBQTZ4QyxLQUFLMnVCLEtBQUwsQ0FBVzljLE9BQVgsR0FBbUIyVCxFQUFFcmEsTUFBRixDQUFTLEVBQVQsRUFBWXZJLEVBQUVpakIsUUFBZCxFQUF1QixLQUFLOEksS0FBTCxDQUFXOWMsT0FBbEMsQ0FBaHpDLEVBQTIxQyxLQUFLL1IsUUFBTCxDQUFjbU0sRUFBZCxDQUFpQixLQUFLNlosU0FBdEIsQ0FBMzFDO0FBQTQzQyxHQUE5NEMsQ0FBKzRDbGpCLEVBQUVpakIsUUFBRixHQUFXLEVBQUMrTSxLQUFJLENBQUMsQ0FBTixFQUFRQyxTQUFRLENBQUMsTUFBRCxFQUFRLE1BQVIsQ0FBaEIsRUFBZ0NDLFVBQVMsQ0FBQyxDQUExQyxFQUE0Q0MsWUFBVyxLQUF2RCxFQUE2REMsY0FBYSxDQUFDLENBQTNFLEVBQTZFQyxtQkFBa0IsU0FBL0YsRUFBeUdDLFVBQVMsQ0FBQyxVQUFELEVBQVksVUFBWixDQUFsSCxFQUEwSUMsU0FBUSxDQUFsSixFQUFvSlYsVUFBUyxTQUE3SixFQUF1S1csV0FBVSxVQUFqTCxFQUE0TEMsTUFBSyxDQUFDLENBQWxNLEVBQW9NQyxVQUFTLENBQUMsQ0FBOU0sRUFBZ05kLFVBQVMsQ0FBQyxDQUExTixFQUE0TmUsV0FBVSxDQUFDLENBQXZPLEVBQXlPQyxlQUFjLENBQUMsQ0FBeFAsRUFBWCxFQUFzUTV3QixFQUFFa0MsU0FBRixDQUFZMmlCLFVBQVosR0FBdUIsWUFBVTtBQUFDLFFBQUloQyxDQUFKO0FBQUEsUUFBTUMsSUFBRSxLQUFLaUosS0FBTCxDQUFXL0ksUUFBbkIsQ0FBNEIsS0FBS3lNLFNBQUwsQ0FBZW9CLFNBQWYsR0FBeUIsQ0FBQy9OLEVBQUVzTixZQUFGLEdBQWV4TixFQUFFRSxFQUFFc04sWUFBSixDQUFmLEdBQWlDeE4sRUFBRSxPQUFGLEVBQVc5VSxRQUFYLENBQW9CZ1YsRUFBRXVOLGlCQUF0QixFQUF5Q3h1QixRQUF6QyxDQUFrRCxLQUFLM0UsUUFBdkQsQ0FBbEMsRUFBb0c0USxRQUFwRyxDQUE2RyxVQUE3RyxDQUF6QixFQUFrSixLQUFLMmhCLFNBQUwsQ0FBZXFCLFNBQWYsR0FBeUJsTyxFQUFFLE1BQUlFLEVBQUVxTixVQUFOLEdBQWlCLEdBQW5CLEVBQXdCcmlCLFFBQXhCLENBQWlDZ1YsRUFBRXdOLFFBQUYsQ0FBVyxDQUFYLENBQWpDLEVBQWdEdk8sSUFBaEQsQ0FBcURlLEVBQUVtTixPQUFGLENBQVUsQ0FBVixDQUFyRCxFQUFtRXhZLFNBQW5FLENBQTZFLEtBQUtnWSxTQUFMLENBQWVvQixTQUE1RixFQUF1R3huQixFQUF2RyxDQUEwRyxPQUExRyxFQUFrSHVaLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDLFdBQUt5SCxJQUFMLENBQVV2SCxFQUFFb04sUUFBWjtBQUFzQixLQUExQyxFQUEyQyxJQUEzQyxDQUFsSCxDQUEzSyxFQUErVSxLQUFLVCxTQUFMLENBQWVzQixLQUFmLEdBQXFCbk8sRUFBRSxNQUFJRSxFQUFFcU4sVUFBTixHQUFpQixHQUFuQixFQUF3QnJpQixRQUF4QixDQUFpQ2dWLEVBQUV3TixRQUFGLENBQVcsQ0FBWCxDQUFqQyxFQUFnRHZPLElBQWhELENBQXFEZSxFQUFFbU4sT0FBRixDQUFVLENBQVYsQ0FBckQsRUFBbUVwdUIsUUFBbkUsQ0FBNEUsS0FBSzR0QixTQUFMLENBQWVvQixTQUEzRixFQUFzR3huQixFQUF0RyxDQUF5RyxPQUF6RyxFQUFpSHVaLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDLFdBQUt6TSxJQUFMLENBQVUyTSxFQUFFb04sUUFBWjtBQUFzQixLQUExQyxFQUEyQyxJQUEzQyxDQUFqSCxDQUFwVyxFQUF1Z0JwTixFQUFFOE0sUUFBRixLQUFhLEtBQUtGLFVBQUwsR0FBZ0IsQ0FBQzlNLEVBQUUsT0FBRixFQUFXOVUsUUFBWCxDQUFvQmdWLEVBQUUrTSxRQUF0QixFQUFnQy9YLE1BQWhDLENBQXVDOEssRUFBRSxRQUFGLENBQXZDLEVBQW9EamxCLElBQXBELENBQXlELFdBQXpELENBQUQsQ0FBN0IsQ0FBdmdCLEVBQTZtQixLQUFLOHhCLFNBQUwsQ0FBZXVCLFNBQWYsR0FBeUIsQ0FBQ2xPLEVBQUU4TixhQUFGLEdBQWdCaE8sRUFBRUUsRUFBRThOLGFBQUosQ0FBaEIsR0FBbUNoTyxFQUFFLE9BQUYsRUFBVzlVLFFBQVgsQ0FBb0JnVixFQUFFME4sU0FBdEIsRUFBaUMzdUIsUUFBakMsQ0FBMEMsS0FBSzNFLFFBQS9DLENBQXBDLEVBQThGNFEsUUFBOUYsQ0FBdUcsVUFBdkcsQ0FBdG9CLEVBQXl2QixLQUFLMmhCLFNBQUwsQ0FBZXVCLFNBQWYsQ0FBeUIzbkIsRUFBekIsQ0FBNEIsT0FBNUIsRUFBb0MsS0FBcEMsRUFBMEN1WixFQUFFNEIsS0FBRixDQUFRLFVBQVMzQixDQUFULEVBQVc7QUFBQyxVQUFJRSxJQUFFSCxFQUFFQyxFQUFFdlosTUFBSixFQUFZdEUsTUFBWixHQUFxQjZELEVBQXJCLENBQXdCLEtBQUs0bUIsU0FBTCxDQUFldUIsU0FBdkMsSUFBa0RwTyxFQUFFQyxFQUFFdlosTUFBSixFQUFZNFQsS0FBWixFQUFsRCxHQUFzRTBGLEVBQUVDLEVBQUV2WixNQUFKLEVBQVl0RSxNQUFaLEdBQXFCa1ksS0FBckIsRUFBNUUsQ0FBeUcyRixFQUFFdFosY0FBRixJQUFtQixLQUFLNmdCLEVBQUwsQ0FBUXJILENBQVIsRUFBVUQsRUFBRTZOLFNBQVosQ0FBbkI7QUFBMEMsS0FBdkssRUFBd0ssSUFBeEssQ0FBMUMsQ0FBenZCLENBQWs5QixLQUFJOU4sQ0FBSixJQUFTLEtBQUs4TSxVQUFkO0FBQXlCLFdBQUs1RCxLQUFMLENBQVdsSixDQUFYLElBQWNELEVBQUU0QixLQUFGLENBQVEsS0FBSzNCLENBQUwsQ0FBUixFQUFnQixJQUFoQixDQUFkO0FBQXpCO0FBQTZELEdBQW4xQyxFQUFvMUM3aUIsRUFBRWtDLFNBQUYsQ0FBWWtlLE9BQVosR0FBb0IsWUFBVTtBQUFDLFFBQUl3QyxDQUFKLEVBQU1DLENBQU4sRUFBUUMsQ0FBUixFQUFVQyxDQUFWLENBQVksS0FBSUgsQ0FBSixJQUFTLEtBQUtNLFNBQWQ7QUFBd0IsV0FBS2htQixRQUFMLENBQWN3TSxHQUFkLENBQWtCa1osQ0FBbEIsRUFBb0IsS0FBS00sU0FBTCxDQUFlTixDQUFmLENBQXBCO0FBQXhCLEtBQStELEtBQUlDLENBQUosSUFBUyxLQUFLNE0sU0FBZDtBQUF3QixXQUFLQSxTQUFMLENBQWU1TSxDQUFmLEVBQWtCN0ksTUFBbEI7QUFBeEIsS0FBbUQsS0FBSStJLENBQUosSUFBUyxLQUFLa08sUUFBZDtBQUF1QixXQUFLbEYsS0FBTCxDQUFXaEosQ0FBWCxJQUFjLEtBQUs0TSxVQUFMLENBQWdCNU0sQ0FBaEIsQ0FBZDtBQUF2QixLQUF3RCxLQUFJRCxDQUFKLElBQVN0a0IsT0FBTyt0QixtQkFBUCxDQUEyQixJQUEzQixDQUFUO0FBQTBDLG9CQUFZLE9BQU8sS0FBS3pKLENBQUwsQ0FBbkIsS0FBNkIsS0FBS0EsQ0FBTCxJQUFRLElBQXJDO0FBQTFDO0FBQXFGLEdBQTluRCxFQUErbkQ5aUIsRUFBRWtDLFNBQUYsQ0FBWTZtQixNQUFaLEdBQW1CLFlBQVU7QUFBQyxRQUFJbkcsQ0FBSjtBQUFBLFFBQU1DLENBQU47QUFBQSxRQUFRQyxDQUFSO0FBQUEsUUFBVUMsSUFBRSxLQUFLZ0osS0FBTCxDQUFXNUIsTUFBWCxHQUFvQnRyQixNQUFwQixHQUEyQixDQUF2QztBQUFBLFFBQXlDbUIsSUFBRStpQixJQUFFLEtBQUtnSixLQUFMLENBQVd2ZCxLQUFYLEdBQW1CM1AsTUFBaEU7QUFBQSxRQUF1RTRvQixJQUFFLEtBQUtzRSxLQUFMLENBQVcvRCxPQUFYLENBQW1CLENBQUMsQ0FBcEIsQ0FBekU7QUFBQSxRQUFnR0wsSUFBRSxLQUFLb0UsS0FBTCxDQUFXL0ksUUFBN0c7QUFBQSxRQUFzSDRFLElBQUVELEVBQUU1QyxNQUFGLElBQVU0QyxFQUFFbEMsU0FBWixJQUF1QmtDLEVBQUVpSSxRQUF6QixHQUFrQyxDQUFsQyxHQUFvQ2pJLEVBQUUrSSxRQUFGLElBQVkvSSxFQUFFblosS0FBMUssQ0FBZ0wsSUFBRyxXQUFTbVosRUFBRTRJLE9BQVgsS0FBcUI1SSxFQUFFNEksT0FBRixHQUFVeHhCLEtBQUtrWCxHQUFMLENBQVMwUixFQUFFNEksT0FBWCxFQUFtQjVJLEVBQUVuWixLQUFyQixDQUEvQixHQUE0RG1aLEVBQUU4SSxJQUFGLElBQVEsVUFBUTlJLEVBQUU0SSxPQUFqRixFQUF5RixLQUFJLEtBQUtmLE1BQUwsR0FBWSxFQUFaLEVBQWU1TSxJQUFFRyxDQUFqQixFQUFtQkYsSUFBRSxDQUFyQixFQUF1QkMsSUFBRSxDQUE3QixFQUErQkYsSUFBRTVpQixDQUFqQyxFQUFtQzRpQixHQUFuQyxFQUF1QztBQUFDLFVBQUdDLEtBQUcrRSxDQUFILElBQU0sTUFBSS9FLENBQWIsRUFBZTtBQUFDLFlBQUcsS0FBSzJNLE1BQUwsQ0FBWW55QixJQUFaLENBQWlCLEVBQUNxRyxPQUFNM0UsS0FBS2tYLEdBQUwsQ0FBU3dSLENBQVQsRUFBVzdFLElBQUVHLENBQWIsQ0FBUCxFQUF1Qm5pQixLQUFJZ2lCLElBQUVHLENBQUYsR0FBSTZFLENBQUosR0FBTSxDQUFqQyxFQUFqQixHQUFzRDdvQixLQUFLa1gsR0FBTCxDQUFTd1IsQ0FBVCxFQUFXN0UsSUFBRUcsQ0FBYixNQUFrQjBFLENBQTNFLEVBQTZFLE1BQU01RSxJQUFFLENBQUYsRUFBSSxFQUFFQyxDQUFOO0FBQVEsWUFBRyxLQUFLaUosS0FBTCxDQUFXN0IsT0FBWCxDQUFtQixLQUFLNkIsS0FBTCxDQUFXekUsUUFBWCxDQUFvQjFFLENBQXBCLENBQW5CLENBQUg7QUFBOEM7QUFBQyxHQUF4bUUsRUFBeW1FNWlCLEVBQUVrQyxTQUFGLENBQVk2dEIsSUFBWixHQUFpQixZQUFVO0FBQUMsUUFBSWxOLENBQUo7QUFBQSxRQUFNQyxJQUFFLEtBQUtpSixLQUFMLENBQVcvSSxRQUFuQjtBQUFBLFFBQTRCRCxJQUFFLEtBQUtnSixLQUFMLENBQVd2ZCxLQUFYLEdBQW1CM1AsTUFBbkIsSUFBMkJpa0IsRUFBRXRVLEtBQTNEO0FBQUEsUUFBaUV4TyxJQUFFLEtBQUsrckIsS0FBTCxDQUFXekUsUUFBWCxDQUFvQixLQUFLeUUsS0FBTCxDQUFXNWhCLE9BQVgsRUFBcEIsQ0FBbkU7QUFBQSxRQUE2R3NkLElBQUUzRSxFQUFFZ0MsSUFBRixJQUFRaEMsRUFBRWtDLE1BQXpILENBQWdJLEtBQUt5SyxTQUFMLENBQWVvQixTQUFmLENBQXlCelAsV0FBekIsQ0FBcUMsVUFBckMsRUFBZ0QsQ0FBQzBCLEVBQUVrTixHQUFILElBQVFqTixDQUF4RCxHQUEyREQsRUFBRWtOLEdBQUYsS0FBUSxLQUFLUCxTQUFMLENBQWVxQixTQUFmLENBQXlCMVAsV0FBekIsQ0FBcUMsVUFBckMsRUFBZ0QsQ0FBQ3FHLENBQUQsSUFBSXpuQixLQUFHLEtBQUsrckIsS0FBTCxDQUFXaEUsT0FBWCxDQUFtQixDQUFDLENBQXBCLENBQXZELEdBQStFLEtBQUswSCxTQUFMLENBQWVzQixLQUFmLENBQXFCM1AsV0FBckIsQ0FBaUMsVUFBakMsRUFBNEMsQ0FBQ3FHLENBQUQsSUFBSXpuQixLQUFHLEtBQUsrckIsS0FBTCxDQUFXL0QsT0FBWCxDQUFtQixDQUFDLENBQXBCLENBQW5ELENBQXZGLENBQTNELEVBQThOLEtBQUt5SCxTQUFMLENBQWV1QixTQUFmLENBQXlCNVAsV0FBekIsQ0FBcUMsVUFBckMsRUFBZ0QsQ0FBQzBCLEVBQUUyTixJQUFILElBQVMxTixDQUF6RCxDQUE5TixFQUEwUkQsRUFBRTJOLElBQUYsS0FBUzVOLElBQUUsS0FBSzJNLE1BQUwsQ0FBWTN3QixNQUFaLEdBQW1CLEtBQUs0d0IsU0FBTCxDQUFldUIsU0FBZixDQUF5QmxpQixRQUF6QixHQUFvQ2pRLE1BQXpELEVBQWdFaWtCLEVBQUU4TSxRQUFGLElBQVksTUFBSS9NLENBQWhCLEdBQWtCLEtBQUs0TSxTQUFMLENBQWV1QixTQUFmLENBQXlCalAsSUFBekIsQ0FBOEIsS0FBSzJOLFVBQUwsQ0FBZ0I5YixJQUFoQixDQUFxQixFQUFyQixDQUE5QixDQUFsQixHQUEwRWlQLElBQUUsQ0FBRixHQUFJLEtBQUs0TSxTQUFMLENBQWV1QixTQUFmLENBQXlCbFosTUFBekIsQ0FBZ0MsSUFBSTdWLEtBQUosQ0FBVTRnQixJQUFFLENBQVosRUFBZWpQLElBQWYsQ0FBb0IsS0FBSzhiLFVBQUwsQ0FBZ0IsQ0FBaEIsQ0FBcEIsQ0FBaEMsQ0FBSixHQUE2RTdNLElBQUUsQ0FBRixJQUFLLEtBQUs0TSxTQUFMLENBQWV1QixTQUFmLENBQXlCbGlCLFFBQXpCLEdBQW9DMVAsS0FBcEMsQ0FBMEN5akIsQ0FBMUMsRUFBNkM3SSxNQUE3QyxFQUE1TixFQUFrUixLQUFLeVYsU0FBTCxDQUFldUIsU0FBZixDQUF5QnZ4QixJQUF6QixDQUE4QixTQUE5QixFQUF5Q3NDLFdBQXpDLENBQXFELFFBQXJELENBQWxSLEVBQWlWLEtBQUswdEIsU0FBTCxDQUFldUIsU0FBZixDQUF5QmxpQixRQUF6QixHQUFvQzNGLEVBQXBDLENBQXVDeVosRUFBRThJLE9BQUYsQ0FBVSxLQUFLdmhCLE9BQUwsRUFBVixFQUF5QixLQUFLcWxCLE1BQTlCLENBQXZDLEVBQThFMWhCLFFBQTlFLENBQXVGLFFBQXZGLENBQTFWLENBQTFSO0FBQXN0QixHQUEzOUYsRUFBNDlGOU4sRUFBRWtDLFNBQUYsQ0FBWXFwQixTQUFaLEdBQXNCLFVBQVMxSSxDQUFULEVBQVc7QUFBQyxRQUFJQyxJQUFFLEtBQUtpSixLQUFMLENBQVcvSSxRQUFqQixDQUEwQkgsRUFBRXFPLElBQUYsR0FBTyxFQUFDaFUsT0FBTTBGLEVBQUU4SSxPQUFGLENBQVUsS0FBS3ZoQixPQUFMLEVBQVYsRUFBeUIsS0FBS3FsQixNQUE5QixDQUFQLEVBQTZDckUsT0FBTSxLQUFLcUUsTUFBTCxDQUFZM3dCLE1BQS9ELEVBQXNFaU0sTUFBS2dZLE1BQUlBLEVBQUVpQyxNQUFGLElBQVVqQyxFQUFFMkMsU0FBWixJQUF1QjNDLEVBQUU4TSxRQUF6QixHQUFrQyxDQUFsQyxHQUFvQzlNLEVBQUU0TixRQUFGLElBQVk1TixFQUFFdFUsS0FBdEQsQ0FBM0UsRUFBUDtBQUFnSixHQUF4cUcsRUFBeXFHeE8sRUFBRWtDLFNBQUYsQ0FBWWlJLE9BQVosR0FBb0IsWUFBVTtBQUFDLFFBQUkwWSxJQUFFLEtBQUtrSixLQUFMLENBQVd6RSxRQUFYLENBQW9CLEtBQUt5RSxLQUFMLENBQVc1aEIsT0FBWCxFQUFwQixDQUFOLENBQWdELE9BQU95WSxFQUFFcUcsSUFBRixDQUFPLEtBQUt1RyxNQUFaLEVBQW1CNU0sRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXRSxDQUFYLEVBQWE7QUFBQyxhQUFPRixFQUFFbGYsS0FBRixJQUFTbWYsQ0FBVCxJQUFZRCxFQUFFaGlCLEdBQUYsSUFBT2lpQixDQUExQjtBQUE0QixLQUFsRCxFQUFtRCxJQUFuRCxDQUFuQixFQUE2RWlOLEdBQTdFLEVBQVA7QUFBMEYsR0FBbDFHLEVBQW0xRzl2QixFQUFFa0MsU0FBRixDQUFZaXZCLFdBQVosR0FBd0IsVUFBU3RPLENBQVQsRUFBVztBQUFDLFFBQUlDLENBQUo7QUFBQSxRQUFNQyxDQUFOO0FBQUEsUUFBUS9pQixJQUFFLEtBQUsrckIsS0FBTCxDQUFXL0ksUUFBckIsQ0FBOEIsT0FBTSxVQUFRaGpCLEVBQUV1d0IsT0FBVixJQUFtQnpOLElBQUVGLEVBQUU4SSxPQUFGLENBQVUsS0FBS3ZoQixPQUFMLEVBQVYsRUFBeUIsS0FBS3FsQixNQUE5QixDQUFGLEVBQXdDek0sSUFBRSxLQUFLeU0sTUFBTCxDQUFZM3dCLE1BQXRELEVBQTZEZ2tCLElBQUUsRUFBRUMsQ0FBSixHQUFNLEVBQUVBLENBQXJFLEVBQXVFQSxJQUFFLEtBQUswTSxNQUFMLENBQVksQ0FBQzFNLElBQUVDLENBQUYsR0FBSUEsQ0FBTCxJQUFRQSxDQUFwQixFQUF1QnJmLEtBQW5ILEtBQTJIb2YsSUFBRSxLQUFLaUosS0FBTCxDQUFXekUsUUFBWCxDQUFvQixLQUFLeUUsS0FBTCxDQUFXNWhCLE9BQVgsRUFBcEIsQ0FBRixFQUE0QzRZLElBQUUsS0FBS2dKLEtBQUwsQ0FBV3ZkLEtBQVgsR0FBbUIzUCxNQUFqRSxFQUF3RWdrQixJQUFFQyxLQUFHOWlCLEVBQUV1d0IsT0FBUCxHQUFlek4sS0FBRzlpQixFQUFFdXdCLE9BQXZOLEdBQWdPek4sQ0FBdE87QUFBd08sR0FBN25ILEVBQThuSDlpQixFQUFFa0MsU0FBRixDQUFZaVUsSUFBWixHQUFpQixVQUFTME0sQ0FBVCxFQUFXO0FBQUNELE1BQUU0QixLQUFGLENBQVEsS0FBS21MLFVBQUwsQ0FBZ0J2RixFQUF4QixFQUEyQixLQUFLMkIsS0FBaEMsRUFBdUMsS0FBS29GLFdBQUwsQ0FBaUIsQ0FBQyxDQUFsQixDQUF2QyxFQUE0RHRPLENBQTVEO0FBQStELEdBQTF0SCxFQUEydEg3aUIsRUFBRWtDLFNBQUYsQ0FBWW1vQixJQUFaLEdBQWlCLFVBQVN4SCxDQUFULEVBQVc7QUFBQ0QsTUFBRTRCLEtBQUYsQ0FBUSxLQUFLbUwsVUFBTCxDQUFnQnZGLEVBQXhCLEVBQTJCLEtBQUsyQixLQUFoQyxFQUF1QyxLQUFLb0YsV0FBTCxDQUFpQixDQUFDLENBQWxCLENBQXZDLEVBQTREdE8sQ0FBNUQ7QUFBK0QsR0FBdnpILEVBQXd6SDdpQixFQUFFa0MsU0FBRixDQUFZa29CLEVBQVosR0FBZSxVQUFTdkgsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZTtBQUFDLFFBQUkvaUIsQ0FBSixDQUFNLENBQUMraUIsQ0FBRCxJQUFJLEtBQUt5TSxNQUFMLENBQVkzd0IsTUFBaEIsSUFBd0JtQixJQUFFLEtBQUt3dkIsTUFBTCxDQUFZM3dCLE1BQWQsRUFBcUIrakIsRUFBRTRCLEtBQUYsQ0FBUSxLQUFLbUwsVUFBTCxDQUFnQnZGLEVBQXhCLEVBQTJCLEtBQUsyQixLQUFoQyxFQUF1QyxLQUFLeUQsTUFBTCxDQUFZLENBQUMzTSxJQUFFN2lCLENBQUYsR0FBSUEsQ0FBTCxJQUFRQSxDQUFwQixFQUF1QjBELEtBQTlELEVBQW9Fb2YsQ0FBcEUsQ0FBN0MsSUFBcUhGLEVBQUU0QixLQUFGLENBQVEsS0FBS21MLFVBQUwsQ0FBZ0J2RixFQUF4QixFQUEyQixLQUFLMkIsS0FBaEMsRUFBdUNsSixDQUF2QyxFQUF5Q0MsQ0FBekMsQ0FBckg7QUFBaUssR0FBOS9ILEVBQSsvSEYsRUFBRW5nQixFQUFGLENBQUttcEIsV0FBTCxDQUFpQkMsV0FBakIsQ0FBNkJwSCxPQUE3QixDQUFxQzJNLFVBQXJDLEdBQWdEcHhCLENBQS9pSTtBQUFpakksQ0FBLzlLLENBQWcrS3dDLE9BQU9zcEIsS0FBUCxJQUFjdHBCLE9BQU9rQyxNQUFyL0ssRUFBNC9LbEMsTUFBNS9LLEVBQW1nTDlCLFFBQW5nTCxDQURuMUUsRUFDZzJQLFVBQVNraUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZUMsQ0FBZixFQUFpQjtBQUFDO0FBQWEsTUFBSS9pQixJQUFFLFNBQUZBLENBQUUsQ0FBUzhpQixDQUFULEVBQVc7QUFBQyxTQUFLaUosS0FBTCxHQUFXakosQ0FBWCxFQUFhLEtBQUt1TyxPQUFMLEdBQWEsRUFBMUIsRUFBNkIsS0FBS24wQixRQUFMLEdBQWMsS0FBSzZ1QixLQUFMLENBQVc3dUIsUUFBdEQsRUFBK0QsS0FBS2dtQixTQUFMLEdBQWUsRUFBQyw0QkFBMkJOLEVBQUU0QixLQUFGLENBQVEsVUFBUzFCLENBQVQsRUFBVztBQUFDQSxVQUFFaGtCLFNBQUYsSUFBYSxjQUFZLEtBQUtpdEIsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQjBDLGFBQTdDLElBQTREOUMsRUFBRUMsQ0FBRixFQUFLemxCLE9BQUwsQ0FBYSwyQkFBYixDQUE1RDtBQUFzRyxPQUExSCxFQUEySCxJQUEzSCxDQUE1QixFQUE2Six5QkFBd0J3bEIsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTM0IsQ0FBVCxFQUFXO0FBQUMsWUFBR0EsRUFBRS9qQixTQUFMLEVBQWU7QUFBQyxjQUFJZ2tCLElBQUVGLEVBQUVDLEVBQUVpRyxPQUFKLEVBQWFycEIsSUFBYixDQUFrQixhQUFsQixFQUFpQ0MsT0FBakMsQ0FBeUMsYUFBekMsRUFBd0RyRCxJQUF4RCxDQUE2RCxXQUE3RCxDQUFOLENBQWdGLElBQUcsQ0FBQ3ltQixDQUFKLEVBQU0sT0FBTyxLQUFLdU8sT0FBTCxDQUFhdk8sQ0FBYixJQUFnQkQsRUFBRWlHLE9BQWxCO0FBQTBCO0FBQUMsT0FBNUosRUFBNkosSUFBN0osQ0FBckwsRUFBd1Ysd0JBQXVCbEcsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTMUIsQ0FBVCxFQUFXO0FBQUMsWUFBR0EsRUFBRWhrQixTQUFGLElBQWEsZUFBYWdrQixFQUFFNkYsUUFBRixDQUFXcHNCLElBQXhDLEVBQTZDO0FBQUMsY0FBSXdtQixJQUFFLEtBQUtnSixLQUFMLENBQVd2ZCxLQUFYLENBQWlCLEtBQUt1ZCxLQUFMLENBQVd6RSxRQUFYLENBQW9CLEtBQUt5RSxLQUFMLENBQVc1aEIsT0FBWCxFQUFwQixDQUFqQixDQUFOO0FBQUEsY0FBa0VuSyxJQUFFNGlCLEVBQUUxaUIsR0FBRixDQUFNLEtBQUtteEIsT0FBWCxFQUFtQixVQUFTek8sQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxtQkFBT0QsTUFBSUcsQ0FBSixHQUFNRixDQUFOLEdBQVEsSUFBZjtBQUFvQixXQUFyRCxFQUF1RGpQLElBQXZELEVBQXBFLENBQWtJLElBQUcsQ0FBQzVULENBQUQsSUFBSTZpQixFQUFFeU8sUUFBRixDQUFXQyxJQUFYLENBQWdCbnlCLEtBQWhCLENBQXNCLENBQXRCLE1BQTJCWSxDQUFsQyxFQUFvQyxPQUFPNmlCLEVBQUV5TyxRQUFGLENBQVdDLElBQVgsR0FBZ0J2eEIsQ0FBaEI7QUFBa0I7QUFBQyxPQUFsUSxFQUFtUSxJQUFuUSxDQUEvVyxFQUE5RSxFQUF1c0IsS0FBSytyQixLQUFMLENBQVc5YyxPQUFYLEdBQW1CMlQsRUFBRXJhLE1BQUYsQ0FBUyxFQUFULEVBQVl2SSxFQUFFaWpCLFFBQWQsRUFBdUIsS0FBSzhJLEtBQUwsQ0FBVzljLE9BQWxDLENBQTF0QixFQUFxd0IsS0FBSy9SLFFBQUwsQ0FBY21NLEVBQWQsQ0FBaUIsS0FBSzZaLFNBQXRCLENBQXJ3QixFQUFzeUJOLEVBQUVDLENBQUYsRUFBS3haLEVBQUwsQ0FBUSwyQkFBUixFQUFvQ3VaLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDLFVBQUlFLElBQUVELEVBQUV5TyxRQUFGLENBQVdDLElBQVgsQ0FBZ0JDLFNBQWhCLENBQTBCLENBQTFCLENBQU47QUFBQSxVQUFtQ3h4QixJQUFFLEtBQUsrckIsS0FBTCxDQUFXeEUsTUFBWCxDQUFrQnpZLFFBQWxCLEVBQXJDO0FBQUEsVUFBa0UyWSxJQUFFLEtBQUs0SixPQUFMLENBQWF2TyxDQUFiLEtBQWlCOWlCLEVBQUVrZCxLQUFGLENBQVEsS0FBS21VLE9BQUwsQ0FBYXZPLENBQWIsQ0FBUixDQUFyRixDQUE4RzJFLE1BQUkxRSxDQUFKLElBQU8wRSxNQUFJLEtBQUtzRSxLQUFMLENBQVc1aEIsT0FBWCxFQUFYLElBQWlDLEtBQUs0aEIsS0FBTCxDQUFXM0IsRUFBWCxDQUFjLEtBQUsyQixLQUFMLENBQVd6RSxRQUFYLENBQW9CRyxDQUFwQixDQUFkLEVBQXFDLENBQUMsQ0FBdEMsRUFBd0MsQ0FBQyxDQUF6QyxDQUFqQztBQUE2RSxLQUEvTSxFQUFnTixJQUFoTixDQUFwQyxDQUF0eUI7QUFBaWlDLEdBQW5qQyxDQUFvakN6bkIsRUFBRWlqQixRQUFGLEdBQVcsRUFBQ3dPLGlCQUFnQixDQUFDLENBQWxCLEVBQVgsRUFBZ0N6eEIsRUFBRWtDLFNBQUYsQ0FBWWtlLE9BQVosR0FBb0IsWUFBVTtBQUFDLFFBQUkwQyxDQUFKLEVBQU1DLENBQU4sQ0FBUUgsRUFBRUMsQ0FBRixFQUFLblosR0FBTCxDQUFTLDJCQUFULEVBQXNDLEtBQUlvWixDQUFKLElBQVMsS0FBS0ksU0FBZDtBQUF3QixXQUFLNkksS0FBTCxDQUFXN3VCLFFBQVgsQ0FBb0J3TSxHQUFwQixDQUF3Qm9aLENBQXhCLEVBQTBCLEtBQUtJLFNBQUwsQ0FBZUosQ0FBZixDQUExQjtBQUF4QixLQUFxRSxLQUFJQyxDQUFKLElBQVN2a0IsT0FBTyt0QixtQkFBUCxDQUEyQixJQUEzQixDQUFUO0FBQTBDLG9CQUFZLE9BQU8sS0FBS3hKLENBQUwsQ0FBbkIsS0FBNkIsS0FBS0EsQ0FBTCxJQUFRLElBQXJDO0FBQTFDO0FBQXFGLEdBQXZRLEVBQXdRSCxFQUFFbmdCLEVBQUYsQ0FBS21wQixXQUFMLENBQWlCQyxXQUFqQixDQUE2QnBILE9BQTdCLENBQXFDaU4sSUFBckMsR0FBMEMxeEIsQ0FBbFQ7QUFBb1QsQ0FBdjRDLENBQXc0Q3dDLE9BQU9zcEIsS0FBUCxJQUFjdHBCLE9BQU9rQyxNQUE3NUMsRUFBbzZDbEMsTUFBcDZDLEVBQTI2QzlCLFFBQTM2QyxDQURoMlAsRUFDcXhTLFVBQVNraUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZUMsQ0FBZixFQUFpQjtBQUFDLFdBQVMvaUIsQ0FBVCxDQUFXNmlCLENBQVgsRUFBYUMsQ0FBYixFQUFlO0FBQUMsUUFBSTlpQixJQUFFLENBQUMsQ0FBUDtBQUFBLFFBQVN5bkIsSUFBRTVFLEVBQUU2QixNQUFGLENBQVMsQ0FBVCxFQUFZOWMsV0FBWixLQUEwQmliLEVBQUV6akIsS0FBRixDQUFRLENBQVIsQ0FBckMsQ0FBZ0QsT0FBT3dqQixFQUFFN2tCLElBQUYsQ0FBTyxDQUFDOGtCLElBQUUsR0FBRixHQUFNK0UsRUFBRWhVLElBQUYsQ0FBTzZULElBQUUsR0FBVCxDQUFOLEdBQW9CQSxDQUFyQixFQUF3QjFuQixLQUF4QixDQUE4QixHQUE5QixDQUFQLEVBQTBDLFVBQVM2aUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxVQUFHOEUsRUFBRTlFLENBQUYsTUFBT0UsQ0FBVixFQUFZLE9BQU8vaUIsSUFBRSxDQUFDOGlCLENBQUQsSUFBSUQsQ0FBTixFQUFRLENBQUMsQ0FBaEI7QUFBa0IsS0FBdEYsR0FBd0Y3aUIsQ0FBL0Y7QUFBaUcsWUFBU3luQixDQUFULENBQVc3RSxDQUFYLEVBQWE7QUFBQyxXQUFPNWlCLEVBQUU0aUIsQ0FBRixFQUFJLENBQUMsQ0FBTCxDQUFQO0FBQWUsT0FBSStFLElBQUUvRSxFQUFFLFdBQUYsRUFBZTVYLEdBQWYsQ0FBbUIsQ0FBbkIsRUFBc0JsSyxLQUE1QjtBQUFBLE1BQWtDOG1CLElBQUUsa0JBQWtCN25CLEtBQWxCLENBQXdCLEdBQXhCLENBQXBDO0FBQUEsTUFBaUVSLElBQUUsRUFBQzRlLFlBQVcsRUFBQ3ZkLEtBQUksRUFBQyt3QixrQkFBaUIscUJBQWxCLEVBQXdDQyxlQUFjLGVBQXRELEVBQXNFQyxhQUFZLGdCQUFsRixFQUFtRzFULFlBQVcsZUFBOUcsRUFBTCxFQUFaLEVBQWlKblIsV0FBVSxFQUFDcE0sS0FBSSxFQUFDa3hCLGlCQUFnQixvQkFBakIsRUFBc0NDLGNBQWEsY0FBbkQsRUFBa0VDLFlBQVcsZUFBN0UsRUFBNkZobEIsV0FBVSxjQUF2RyxFQUFMLEVBQTNKLEVBQW5FO0FBQUEsTUFBNFZxZSxJQUFFLEVBQUM0RyxlQUFjLHlCQUFVO0FBQUMsYUFBTSxDQUFDLENBQUNqeUIsRUFBRSxXQUFGLENBQVI7QUFBdUIsS0FBakQsRUFBa0RreUIsaUJBQWdCLDJCQUFVO0FBQUMsYUFBTSxDQUFDLENBQUNseUIsRUFBRSxhQUFGLENBQVI7QUFBeUIsS0FBdEcsRUFBdUdteUIsZ0JBQWUsMEJBQVU7QUFBQyxhQUFNLENBQUMsQ0FBQ255QixFQUFFLFlBQUYsQ0FBUjtBQUF3QixLQUF6SixFQUEwSm95QixlQUFjLHlCQUFVO0FBQUMsYUFBTSxDQUFDLENBQUNweUIsRUFBRSxXQUFGLENBQVI7QUFBdUIsS0FBMU0sRUFBOVYsQ0FBMGlCcXJCLEVBQUU4RyxjQUFGLE9BQXFCdlAsRUFBRTBHLE9BQUYsQ0FBVW5MLFVBQVYsR0FBcUIsSUFBSXpXLE1BQUosQ0FBVytmLEVBQUUsWUFBRixDQUFYLENBQXJCLEVBQWlEN0UsRUFBRTBHLE9BQUYsQ0FBVW5MLFVBQVYsQ0FBcUJ2ZCxHQUFyQixHQUF5QnJCLEVBQUU0ZSxVQUFGLENBQWF2ZCxHQUFiLENBQWlCZ2lCLEVBQUUwRyxPQUFGLENBQVVuTCxVQUEzQixDQUEvRixHQUF1SWtOLEVBQUUrRyxhQUFGLE9BQW9CeFAsRUFBRTBHLE9BQUYsQ0FBVXRjLFNBQVYsR0FBb0IsSUFBSXRGLE1BQUosQ0FBVytmLEVBQUUsV0FBRixDQUFYLENBQXBCLEVBQStDN0UsRUFBRTBHLE9BQUYsQ0FBVXRjLFNBQVYsQ0FBb0JwTSxHQUFwQixHQUF3QnJCLEVBQUV5TixTQUFGLENBQVlwTSxHQUFaLENBQWdCZ2lCLEVBQUUwRyxPQUFGLENBQVV0YyxTQUExQixDQUEzRixDQUF2SSxFQUF3UXFlLEVBQUU0RyxhQUFGLE9BQW9CclAsRUFBRTBHLE9BQUYsQ0FBVUksU0FBVixHQUFvQixJQUFJaGlCLE1BQUosQ0FBVytmLEVBQUUsV0FBRixDQUFYLENBQXBCLEVBQStDN0UsRUFBRTBHLE9BQUYsQ0FBVVEsV0FBVixHQUFzQnVCLEVBQUU2RyxlQUFGLEVBQXpGLENBQXhRO0FBQXNYLENBQWhuQyxDQUFpbkMxdkIsT0FBT3NwQixLQUFQLElBQWN0cEIsT0FBT2tDLE1BQXRvQyxFQUE2b0NsQyxNQUE3b0MsRUFBb3BDOUIsUUFBcHBDLENBRHJ4Uzs7O0FDTEEsSUFBSTJ4QixVQUFVN3ZCLE9BQU84dUIsUUFBUCxDQUFnQmdCLE1BQTlCO0FBQ0EsSUFBSUMsY0FBY0MsU0FBU0QsV0FBM0I7QUFDQTtBQUNBLElBQUdGLFlBQVksdUJBQVosSUFBdUNBLFlBQVksdUJBQXRELEVBQStFO0FBQzdFQSxZQUFVQSxVQUFVLGFBQXBCO0FBQ0QsQ0FGRCxNQUVLO0FBQ0hBLFlBQVU3dkIsT0FBTzh1QixRQUFQLENBQWdCZ0IsTUFBMUI7QUFDRDtDQ1BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztDQ2pJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUM5QkE7O0FBRUU7O0FBRUV4MkIsRUFBRTIyQixPQUFGLENBQVdGLGNBQVksNkJBQXZCLEVBQXNELFVBQVVwMUIsSUFBVixFQUFpQjtBQUNyRXJCLElBQUUsbUJBQUYsRUFBdUJ1TixFQUF2QixDQUEwQixPQUExQixFQUFtQyxZQUFVOztBQUU3QyxRQUFJcXBCLGdCQUFnQjUyQixFQUFFLElBQUYsRUFBUTJRLEdBQVIsRUFBcEI7QUFDQSxRQUFJa21CLFNBQVMsRUFBYjtBQUNBO0FBQ0E7QUFDQSxRQUFJQyxRQUFRLEVBQVo7QUFDQSxRQUFJQyxlQUFlLEVBQW5CO0FBQ0EsUUFBSUMsa0JBQWtCLEVBQXRCO0FBQ0EsUUFBSUMsU0FBUyxFQUFiO0FBQ0EsUUFBSUMsZ0JBQWdCLEVBQXBCO0FBQ0EsUUFBSUMsUUFBUTkxQixLQUFLODFCLEtBQWpCO0FBQ0EsUUFBSUMsc0JBQXNCLEVBQTFCO0FBQ0E7QUFDQSxTQUFLLElBQUkzekIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJMHpCLE1BQU1wMEIsTUFBMUIsRUFBa0NVLEdBQWxDLEVBQXVDO0FBQ3JDcXpCLGNBQVFLLE1BQU0xekIsQ0FBTixFQUFTcXpCLEtBQVQsQ0FBZTcxQixXQUFmLEVBQVI7QUFDQSsxQix3QkFBa0JHLE1BQU0xekIsQ0FBTixFQUFTNHpCLFdBQVQsQ0FBcUJwMkIsV0FBckIsRUFBbEI7QUFDQTgxQixxQkFBZUksTUFBTTF6QixDQUFOLEVBQVM2ekIsa0JBQVQsQ0FBNEIsQ0FBNUIsQ0FBZjtBQUNBSixzQkFBZ0JDLE1BQU0xekIsQ0FBTixFQUFTNnpCLGtCQUF6QjtBQUNBTCxlQUFTRSxNQUFNMXpCLENBQU4sRUFBU3d6QixNQUFULENBQWdCaDJCLFdBQWhCLEVBQVQ7O0FBRUEsV0FBSyxJQUFJOEQsSUFBSSxDQUFiLEVBQWdCQSxJQUFJbXlCLGNBQWNuMEIsTUFBbEMsRUFBMENnQyxHQUExQyxFQUNBO0FBQ0VxeUIsOEJBQXVCRixjQUFjbnlCLENBQWQsRUFBaUI0RCxPQUFqQixDQUF5QixJQUF6QixFQUErQixHQUEvQixFQUFvQzFILFdBQXBDLEVBQXZCO0FBQ0E7QUFDQSxZQUFJLENBQUM2MUIsTUFBTVMsUUFBTixDQUFlWCxjQUFjMzFCLFdBQWQsRUFBZixLQUNEKzFCLGdCQUFnQk8sUUFBaEIsQ0FBeUJYLGNBQWMzMUIsV0FBZCxFQUF6QixDQURDLElBRURtMkIsb0JBQW9CRyxRQUFwQixDQUE2QlgsY0FBYzMxQixXQUFkLEVBQTdCLENBRkMsSUFHRGcyQixPQUFPTSxRQUFQLENBQWdCWCxjQUFjMzFCLFdBQWQsRUFBaEIsQ0FIQSxLQUlBMjFCLGtCQUFrQixHQUpsQixJQUl5QkEsY0FBYzd6QixNQUFkLEdBQXVCLENBSnBELEVBTUE7QUFDRTtBQUNBeTBCLDJCQUFpQkMsU0FBakIsQ0FBMkI1YyxHQUEzQixDQUErQixjQUEvQjtBQUNBZ2MsaUJBQU90MUIsSUFBUCxDQUFZNDFCLE1BQU0xekIsQ0FBTixDQUFaO0FBRUQ7QUFDRDtBQUNBO0FBQ0E7QUFDQSxZQUFHK3pCLGlCQUFpQkUsWUFBakIsR0FBZ0MsRUFBbkMsRUFBc0M7O0FBRW5DRiwyQkFBaUJDLFNBQWpCLENBQTJCdlosTUFBM0IsQ0FBa0MsY0FBbEM7QUFDRjtBQUNEO0FBQ0E7QUFDQTtBQUNEO0FBQ0Y7QUFDRCxRQUFJeVosY0FBYyxFQUFsQjtBQUNBLFFBQUlDLGlCQUFpQixFQUFyQjs7QUFHQSxRQUFJQyxnQkFBZ0JoQixPQUFPL3BCLE1BQVAsQ0FBYyxVQUFTc2lCLElBQVQsRUFBZTBJLEdBQWYsRUFBbUI7QUFDbkQsYUFBT2pCLE9BQU9uMUIsT0FBUCxDQUFlMHRCLElBQWYsS0FBdUIwSSxHQUE5QjtBQUNELEtBRm1CLENBQXBCO0FBR0E7QUFDQSxRQUFJQyxnQkFBZ0IsRUFBcEI7QUFDQTs7QUFFQSxTQUFLLElBQUl4SSxJQUFJLENBQWIsRUFBZ0JBLElBQUlzSSxjQUFjOTBCLE1BQWxDLEVBQTBDd3NCLEdBQTFDLEVBQStDO0FBQzdDO0FBQ0FvSSxvQkFBY0UsY0FBY3RJLENBQWQsRUFBaUJ1SCxLQUEvQjtBQUNBYyx1QkFBaUJDLGNBQWN0SSxDQUFkLEVBQWlCMEgsTUFBbEM7QUFDQWMsdUJBQWlCLDBDQUF3Q0YsY0FBY3RJLENBQWQsRUFBaUIxZixFQUF6RCxHQUE0RCw2QkFBNUQsR0FBMEY4bkIsV0FBMUYsR0FBc0csZ0RBQXRHLEdBQXVKQyxlQUFlanZCLE9BQWYsQ0FBdUIsSUFBdkIsRUFBNkIsR0FBN0IsQ0FBdkosR0FBeUwsZUFBMU07QUFDRDtBQUNEO0FBQ0E2dUIscUJBQWlCUSxTQUFqQixHQUE2QkQsYUFBN0I7QUFDRCxHQXBFQztBQXFFSCxDQXRFQzs7QUF3RUpuekIsU0FBUzRRLGdCQUFULENBQTBCLE9BQTFCLEVBQW1DLFVBQVN0UixDQUFULEVBQVc7QUFDNUM7QUFDQSxNQUFJQSxFQUFFc0osTUFBRixDQUFTaXFCLFNBQVQsQ0FBbUI3YSxRQUFuQixDQUE0QixZQUE1QixDQUFKLEVBQStDO0FBQzdDO0FBQ0EsUUFBSXFiLFdBQVcvekIsRUFBRXNKLE1BQUYsQ0FBUzBxQixhQUFULENBQXVCQyxZQUF2QixDQUFvQyxhQUFwQyxDQUFmO0FBQ0E7QUFDQUMsY0FBVXhwQixLQUFWLEdBQWtCcXBCLFFBQWxCO0FBQ0E7QUFDRDtBQUNGLENBVEQ7OztBQzdFQXJ2QixPQUFPaEUsUUFBUCxFQUFpQm5DLFVBQWpCOzs7QUNBQTtBQUNBekMsRUFBRSxXQUFGLEVBQWV1TixFQUFmLENBQWtCLE9BQWxCLEVBQTJCLFlBQVc7QUFDcEN2TixJQUFFNEUsUUFBRixFQUFZbkMsVUFBWixDQUF1QixTQUF2QixFQUFpQyxPQUFqQztBQUNELENBRkQ7OztBQ0RBLFNBQVM0MUIsTUFBVCxDQUFnQjdzQixLQUFoQixFQUF1QjtBQUNyQjtBQUNBa2tCLE1BQUlwdUIsT0FBSixDQUFZLHNCQUFaO0FBQ0Q7QUFDRCxJQUFHb0YsT0FBT2dvQixVQUFQLElBQXFCLElBQXhCLEVBQTZCO0FBQzNCLE1BQUlnQixNQUFNMXZCLEVBQUUsUUFBRixDQUFWO0FBQ0EwdkIsTUFBSUksV0FBSixDQUFnQjtBQUNkNkUsVUFBTSxLQURRO0FBRWQzSyxnQkFBVztBQUNQLFNBQUU7QUFDQXRYLGVBQU0sQ0FETjtBQUVBd2hCLGFBQUksS0FGSjtBQUdBbEwsY0FBTSxJQUhOO0FBSUFRLHNCQUFjLEVBSmQ7QUFLQW1MLGNBQU07QUFMTixPQURLO0FBUVAsV0FBSTtBQUNGamlCLGVBQU0sQ0FESjtBQUVGd2hCLGFBQUksS0FGRjtBQUdGbEwsY0FBTSxJQUhKO0FBSUZRLHNCQUFjLEVBSlo7QUFLRm1MLGNBQU07QUFMSixPQVJHO0FBZVAsWUFBSztBQUNIamlCLGVBQU0sQ0FESDtBQUVId2hCLGFBQUksS0FGRDtBQUdIbEwsY0FBTSxJQUhIO0FBSUhRLHNCQUFjLEVBSlg7QUFLSG1MLGNBQU0sS0FMSDtBQU1Ickgsa0JBQVUrSztBQU5QO0FBZkU7QUFGRyxHQUFoQjtBQTRCRDs7QUFFRCxJQUFJQyxVQUFVdDRCLEVBQUUsWUFBRixDQUFkO0FBQ0FzNEIsUUFBUXhJLFdBQVIsQ0FBb0I7QUFDbEJwZCxTQUFNLENBRFk7QUFFbEJ3aEIsT0FBSSxLQUZjO0FBR2xCbEwsUUFBTSxJQUhZO0FBSWxCUSxnQkFBYyxFQUpJO0FBS2xCbUwsUUFBTSxLQUxZO0FBTWxCekIsWUFBVSxJQU5ROztBQVFsQmxKLGNBQVc7QUFDUCxPQUFFO0FBQ0F0WCxhQUFNLENBRE47QUFFQXdoQixXQUFJLEtBRko7QUFHQWxMLFlBQU0sSUFITjtBQUlBUSxvQkFBYyxFQUpkO0FBS0FtTCxZQUFNO0FBTE4sS0FESztBQVFQLFNBQUk7QUFDRmppQixhQUFNLENBREo7QUFFRndoQixXQUFJLEtBRkY7QUFHRmxMLFlBQU0sSUFISjtBQUlGUSxvQkFBYyxFQUpaO0FBS0ZtTCxZQUFNO0FBTEosS0FSRztBQWVQLFVBQUs7QUFDSGppQixhQUFNLENBREg7QUFFSHdoQixXQUFJLEtBRkQ7QUFHSGxMLFlBQU0sSUFISDtBQUlIUSxvQkFBYyxFQUpYO0FBS0htTCxZQUFNO0FBQ047QUFORyxLQWZFO0FBdUJQLFVBQUs7QUFDSGppQixhQUFNLENBREg7QUFFSHdoQixXQUFJLEtBRkQ7QUFHSGxMLFlBQU0sSUFISDtBQUlIUSxvQkFBYyxFQUpYO0FBS0htTCxZQUFNO0FBQ047QUFORztBQXZCRTtBQVJPLENBQXBCOztBQThDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQ3pGQTs7O0FDQUEzMEIsRUFBRTRFLFFBQUYsRUFBWTJ6QixLQUFaLENBQWtCLFlBQVk7QUFDMUIsUUFBSUMsU0FBU3g0QixFQUFFLHNEQUFGLENBQWI7O0FBRUF3NEIsV0FBT3YyQixJQUFQLENBQVksWUFBWTtBQUNwQixZQUFJb0MsS0FBS3JFLEVBQUUsSUFBRixDQUFUO0FBQ0FxRSxXQUFHdVgsSUFBSCxDQUFRLDRDQUFSO0FBQ0gsS0FIRDtBQUlILENBUEQ7OztBQ0FBLElBQUk2YyxXQUFXLFNBQVhBLFFBQVcsQ0FBU0MsU0FBVCxFQUFvQkMsUUFBcEIsRUFBOEJDLE1BQTlCLEVBQXNDO0FBQ25ELEtBQUloZCxPQUFPNWIsRUFBRTA0QixTQUFGLENBQVg7QUFDQTE0QixHQUFFMEcsTUFBRixFQUFVbXlCLE1BQVYsQ0FBaUIsWUFBVTtBQUMxQixNQUFJNzRCLEVBQUU0RSxRQUFGLEVBQVltWSxTQUFaLEtBQTBCNmIsTUFBOUIsRUFBc0M7QUFDckNoZCxRQUFLNUosUUFBTCxDQUFjMm1CLFFBQWQ7QUFDQSxHQUZELE1BRU87QUFDTC9jLFFBQUszVixXQUFMLENBQWlCMHlCLFFBQWpCO0FBQ0Q7QUFDRCxFQU5EO0FBT0EsQ0FURjs7QUFXQUYsU0FBUyxxQkFBVCxFQUErQixrQkFBL0IsRUFBbUQsQ0FBbkQ7O0FBRUF6NEIsRUFBRSxPQUFGLEVBQVc4NEIsS0FBWCxDQUFpQixZQUFVO0FBQzFCOTRCLEdBQUUsU0FBRixFQUFhc2xCLFdBQWIsQ0FBeUIsTUFBekI7QUFDQXRsQixHQUFFLE1BQUYsRUFBVXNsQixXQUFWLENBQXNCLGdCQUF0QjtBQUNBO0FBQ0E7QUFDQSxDQUxEOztBQU9BdGxCLEVBQUUsOEJBQUYsRUFBa0M4NEIsS0FBbEMsQ0FBd0MsWUFBVTtBQUNqRDtBQUNBLENBRkQ7O0FBSUE5NEIsRUFBRSw2QkFBRixFQUFpQys0QixTQUFqQyxDQUEyQyxZQUFVO0FBQ3BELzRCLEdBQUUsWUFBRixFQUFnQnNsQixXQUFoQixDQUE0QixnQkFBNUI7QUFDQSxDQUZEOztBQUlBdGxCLEVBQUUsZUFBRixFQUFtQnVOLEVBQW5CLENBQXNCLE9BQXRCLEVBQStCLFlBQVU7QUFDeEN2TixHQUFFLGNBQUYsRUFBa0JnUyxRQUFsQixDQUEyQixpQkFBM0I7QUFDQWhTLEdBQUUsTUFBRixFQUFVZ1MsUUFBVixDQUFtQixnQkFBbkI7QUFDQSxDQUhEOztBQUtBaFMsRUFBRSxtQkFBRixFQUF1QnVOLEVBQXZCLENBQTBCLE9BQTFCLEVBQW1DLFlBQVU7QUFDNUN2TixHQUFFLGNBQUYsRUFBa0JpRyxXQUFsQixDQUE4QixpQkFBOUI7QUFDQWpHLEdBQUUsTUFBRixFQUFVaUcsV0FBVixDQUFzQixnQkFBdEI7QUFDQSxDQUhEOzs7QUNoQ0FqRyxFQUFFMEcsTUFBRixFQUFVb0IsSUFBVixDQUFlLGlDQUFmLEVBQWtELFlBQVk7QUFDM0QsTUFBSWt4QixTQUFTaDVCLEVBQUUsbUJBQUYsQ0FBYjtBQUNBLE1BQUk4M0IsTUFBTWtCLE9BQU9udUIsUUFBUCxFQUFWO0FBQ0EsTUFBSWpCLFNBQVM1SixFQUFFMEcsTUFBRixFQUFVa0QsTUFBVixFQUFiO0FBQ0FBLFdBQVNBLFNBQVNrdUIsSUFBSXh1QixHQUF0QjtBQUNBTSxXQUFTQSxTQUFTb3ZCLE9BQU9wdkIsTUFBUCxFQUFULEdBQTBCLENBQW5DOztBQUVBLFdBQVNxdkIsWUFBVCxHQUF3QjtBQUN0QkQsV0FBT3hxQixHQUFQLENBQVc7QUFDUCxvQkFBYzVFLFNBQVM7QUFEaEIsS0FBWDtBQUdEOztBQUVELE1BQUlBLFNBQVMsQ0FBYixFQUFnQjtBQUNkcXZCO0FBQ0Q7QUFDSCxDQWhCRCIsImZpbGUiOiJmb3VuZGF0aW9uLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIWZ1bmN0aW9uKCQpIHtcblxuXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciBGT1VOREFUSU9OX1ZFUlNJT04gPSAnNi4zLjAnO1xuXG4vLyBHbG9iYWwgRm91bmRhdGlvbiBvYmplY3Rcbi8vIFRoaXMgaXMgYXR0YWNoZWQgdG8gdGhlIHdpbmRvdywgb3IgdXNlZCBhcyBhIG1vZHVsZSBmb3IgQU1EL0Jyb3dzZXJpZnlcbnZhciBGb3VuZGF0aW9uID0ge1xuICB2ZXJzaW9uOiBGT1VOREFUSU9OX1ZFUlNJT04sXG5cbiAgLyoqXG4gICAqIFN0b3JlcyBpbml0aWFsaXplZCBwbHVnaW5zLlxuICAgKi9cbiAgX3BsdWdpbnM6IHt9LFxuXG4gIC8qKlxuICAgKiBTdG9yZXMgZ2VuZXJhdGVkIHVuaXF1ZSBpZHMgZm9yIHBsdWdpbiBpbnN0YW5jZXNcbiAgICovXG4gIF91dWlkczogW10sXG5cbiAgLyoqXG4gICAqIFJldHVybnMgYSBib29sZWFuIGZvciBSVEwgc3VwcG9ydFxuICAgKi9cbiAgcnRsOiBmdW5jdGlvbigpe1xuICAgIHJldHVybiAkKCdodG1sJykuYXR0cignZGlyJykgPT09ICdydGwnO1xuICB9LFxuICAvKipcbiAgICogRGVmaW5lcyBhIEZvdW5kYXRpb24gcGx1Z2luLCBhZGRpbmcgaXQgdG8gdGhlIGBGb3VuZGF0aW9uYCBuYW1lc3BhY2UgYW5kIHRoZSBsaXN0IG9mIHBsdWdpbnMgdG8gaW5pdGlhbGl6ZSB3aGVuIHJlZmxvd2luZy5cbiAgICogQHBhcmFtIHtPYmplY3R9IHBsdWdpbiAtIFRoZSBjb25zdHJ1Y3RvciBvZiB0aGUgcGx1Z2luLlxuICAgKi9cbiAgcGx1Z2luOiBmdW5jdGlvbihwbHVnaW4sIG5hbWUpIHtcbiAgICAvLyBPYmplY3Qga2V5IHRvIHVzZSB3aGVuIGFkZGluZyB0byBnbG9iYWwgRm91bmRhdGlvbiBvYmplY3RcbiAgICAvLyBFeGFtcGxlczogRm91bmRhdGlvbi5SZXZlYWwsIEZvdW5kYXRpb24uT2ZmQ2FudmFzXG4gICAgdmFyIGNsYXNzTmFtZSA9IChuYW1lIHx8IGZ1bmN0aW9uTmFtZShwbHVnaW4pKTtcbiAgICAvLyBPYmplY3Qga2V5IHRvIHVzZSB3aGVuIHN0b3JpbmcgdGhlIHBsdWdpbiwgYWxzbyB1c2VkIHRvIGNyZWF0ZSB0aGUgaWRlbnRpZnlpbmcgZGF0YSBhdHRyaWJ1dGUgZm9yIHRoZSBwbHVnaW5cbiAgICAvLyBFeGFtcGxlczogZGF0YS1yZXZlYWwsIGRhdGEtb2ZmLWNhbnZhc1xuICAgIHZhciBhdHRyTmFtZSAgPSBoeXBoZW5hdGUoY2xhc3NOYW1lKTtcblxuICAgIC8vIEFkZCB0byB0aGUgRm91bmRhdGlvbiBvYmplY3QgYW5kIHRoZSBwbHVnaW5zIGxpc3QgKGZvciByZWZsb3dpbmcpXG4gICAgdGhpcy5fcGx1Z2luc1thdHRyTmFtZV0gPSB0aGlzW2NsYXNzTmFtZV0gPSBwbHVnaW47XG4gIH0sXG4gIC8qKlxuICAgKiBAZnVuY3Rpb25cbiAgICogUG9wdWxhdGVzIHRoZSBfdXVpZHMgYXJyYXkgd2l0aCBwb2ludGVycyB0byBlYWNoIGluZGl2aWR1YWwgcGx1Z2luIGluc3RhbmNlLlxuICAgKiBBZGRzIHRoZSBgemZQbHVnaW5gIGRhdGEtYXR0cmlidXRlIHRvIHByb2dyYW1tYXRpY2FsbHkgY3JlYXRlZCBwbHVnaW5zIHRvIGFsbG93IHVzZSBvZiAkKHNlbGVjdG9yKS5mb3VuZGF0aW9uKG1ldGhvZCkgY2FsbHMuXG4gICAqIEFsc28gZmlyZXMgdGhlIGluaXRpYWxpemF0aW9uIGV2ZW50IGZvciBlYWNoIHBsdWdpbiwgY29uc29saWRhdGluZyByZXBldGl0aXZlIGNvZGUuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBwbHVnaW4gLSBhbiBpbnN0YW5jZSBvZiBhIHBsdWdpbiwgdXN1YWxseSBgdGhpc2AgaW4gY29udGV4dC5cbiAgICogQHBhcmFtIHtTdHJpbmd9IG5hbWUgLSB0aGUgbmFtZSBvZiB0aGUgcGx1Z2luLCBwYXNzZWQgYXMgYSBjYW1lbENhc2VkIHN0cmluZy5cbiAgICogQGZpcmVzIFBsdWdpbiNpbml0XG4gICAqL1xuICByZWdpc3RlclBsdWdpbjogZnVuY3Rpb24ocGx1Z2luLCBuYW1lKXtcbiAgICB2YXIgcGx1Z2luTmFtZSA9IG5hbWUgPyBoeXBoZW5hdGUobmFtZSkgOiBmdW5jdGlvbk5hbWUocGx1Z2luLmNvbnN0cnVjdG9yKS50b0xvd2VyQ2FzZSgpO1xuICAgIHBsdWdpbi51dWlkID0gdGhpcy5HZXRZb0RpZ2l0cyg2LCBwbHVnaW5OYW1lKTtcblxuICAgIGlmKCFwbHVnaW4uJGVsZW1lbnQuYXR0cihgZGF0YS0ke3BsdWdpbk5hbWV9YCkpeyBwbHVnaW4uJGVsZW1lbnQuYXR0cihgZGF0YS0ke3BsdWdpbk5hbWV9YCwgcGx1Z2luLnV1aWQpOyB9XG4gICAgaWYoIXBsdWdpbi4kZWxlbWVudC5kYXRhKCd6ZlBsdWdpbicpKXsgcGx1Z2luLiRlbGVtZW50LmRhdGEoJ3pmUGx1Z2luJywgcGx1Z2luKTsgfVxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIEZpcmVzIHdoZW4gdGhlIHBsdWdpbiBoYXMgaW5pdGlhbGl6ZWQuXG4gICAgICAgICAgICogQGV2ZW50IFBsdWdpbiNpbml0XG4gICAgICAgICAgICovXG4gICAgcGx1Z2luLiRlbGVtZW50LnRyaWdnZXIoYGluaXQuemYuJHtwbHVnaW5OYW1lfWApO1xuXG4gICAgdGhpcy5fdXVpZHMucHVzaChwbHVnaW4udXVpZCk7XG5cbiAgICByZXR1cm47XG4gIH0sXG4gIC8qKlxuICAgKiBAZnVuY3Rpb25cbiAgICogUmVtb3ZlcyB0aGUgcGx1Z2lucyB1dWlkIGZyb20gdGhlIF91dWlkcyBhcnJheS5cbiAgICogUmVtb3ZlcyB0aGUgemZQbHVnaW4gZGF0YSBhdHRyaWJ1dGUsIGFzIHdlbGwgYXMgdGhlIGRhdGEtcGx1Z2luLW5hbWUgYXR0cmlidXRlLlxuICAgKiBBbHNvIGZpcmVzIHRoZSBkZXN0cm95ZWQgZXZlbnQgZm9yIHRoZSBwbHVnaW4sIGNvbnNvbGlkYXRpbmcgcmVwZXRpdGl2ZSBjb2RlLlxuICAgKiBAcGFyYW0ge09iamVjdH0gcGx1Z2luIC0gYW4gaW5zdGFuY2Ugb2YgYSBwbHVnaW4sIHVzdWFsbHkgYHRoaXNgIGluIGNvbnRleHQuXG4gICAqIEBmaXJlcyBQbHVnaW4jZGVzdHJveWVkXG4gICAqL1xuICB1bnJlZ2lzdGVyUGx1Z2luOiBmdW5jdGlvbihwbHVnaW4pe1xuICAgIHZhciBwbHVnaW5OYW1lID0gaHlwaGVuYXRlKGZ1bmN0aW9uTmFtZShwbHVnaW4uJGVsZW1lbnQuZGF0YSgnemZQbHVnaW4nKS5jb25zdHJ1Y3RvcikpO1xuXG4gICAgdGhpcy5fdXVpZHMuc3BsaWNlKHRoaXMuX3V1aWRzLmluZGV4T2YocGx1Z2luLnV1aWQpLCAxKTtcbiAgICBwbHVnaW4uJGVsZW1lbnQucmVtb3ZlQXR0cihgZGF0YS0ke3BsdWdpbk5hbWV9YCkucmVtb3ZlRGF0YSgnemZQbHVnaW4nKVxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIEZpcmVzIHdoZW4gdGhlIHBsdWdpbiBoYXMgYmVlbiBkZXN0cm95ZWQuXG4gICAgICAgICAgICogQGV2ZW50IFBsdWdpbiNkZXN0cm95ZWRcbiAgICAgICAgICAgKi9cbiAgICAgICAgICAudHJpZ2dlcihgZGVzdHJveWVkLnpmLiR7cGx1Z2luTmFtZX1gKTtcbiAgICBmb3IodmFyIHByb3AgaW4gcGx1Z2luKXtcbiAgICAgIHBsdWdpbltwcm9wXSA9IG51bGw7Ly9jbGVhbiB1cCBzY3JpcHQgdG8gcHJlcCBmb3IgZ2FyYmFnZSBjb2xsZWN0aW9uLlxuICAgIH1cbiAgICByZXR1cm47XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBmdW5jdGlvblxuICAgKiBDYXVzZXMgb25lIG9yIG1vcmUgYWN0aXZlIHBsdWdpbnMgdG8gcmUtaW5pdGlhbGl6ZSwgcmVzZXR0aW5nIGV2ZW50IGxpc3RlbmVycywgcmVjYWxjdWxhdGluZyBwb3NpdGlvbnMsIGV0Yy5cbiAgICogQHBhcmFtIHtTdHJpbmd9IHBsdWdpbnMgLSBvcHRpb25hbCBzdHJpbmcgb2YgYW4gaW5kaXZpZHVhbCBwbHVnaW4ga2V5LCBhdHRhaW5lZCBieSBjYWxsaW5nIGAkKGVsZW1lbnQpLmRhdGEoJ3BsdWdpbk5hbWUnKWAsIG9yIHN0cmluZyBvZiBhIHBsdWdpbiBjbGFzcyBpLmUuIGAnZHJvcGRvd24nYFxuICAgKiBAZGVmYXVsdCBJZiBubyBhcmd1bWVudCBpcyBwYXNzZWQsIHJlZmxvdyBhbGwgY3VycmVudGx5IGFjdGl2ZSBwbHVnaW5zLlxuICAgKi9cbiAgIHJlSW5pdDogZnVuY3Rpb24ocGx1Z2lucyl7XG4gICAgIHZhciBpc0pRID0gcGx1Z2lucyBpbnN0YW5jZW9mICQ7XG4gICAgIHRyeXtcbiAgICAgICBpZihpc0pRKXtcbiAgICAgICAgIHBsdWdpbnMuZWFjaChmdW5jdGlvbigpe1xuICAgICAgICAgICAkKHRoaXMpLmRhdGEoJ3pmUGx1Z2luJykuX2luaXQoKTtcbiAgICAgICAgIH0pO1xuICAgICAgIH1lbHNle1xuICAgICAgICAgdmFyIHR5cGUgPSB0eXBlb2YgcGx1Z2lucyxcbiAgICAgICAgIF90aGlzID0gdGhpcyxcbiAgICAgICAgIGZucyA9IHtcbiAgICAgICAgICAgJ29iamVjdCc6IGZ1bmN0aW9uKHBsZ3Mpe1xuICAgICAgICAgICAgIHBsZ3MuZm9yRWFjaChmdW5jdGlvbihwKXtcbiAgICAgICAgICAgICAgIHAgPSBoeXBoZW5hdGUocCk7XG4gICAgICAgICAgICAgICAkKCdbZGF0YS0nKyBwICsnXScpLmZvdW5kYXRpb24oJ19pbml0Jyk7XG4gICAgICAgICAgICAgfSk7XG4gICAgICAgICAgIH0sXG4gICAgICAgICAgICdzdHJpbmcnOiBmdW5jdGlvbigpe1xuICAgICAgICAgICAgIHBsdWdpbnMgPSBoeXBoZW5hdGUocGx1Z2lucyk7XG4gICAgICAgICAgICAgJCgnW2RhdGEtJysgcGx1Z2lucyArJ10nKS5mb3VuZGF0aW9uKCdfaW5pdCcpO1xuICAgICAgICAgICB9LFxuICAgICAgICAgICAndW5kZWZpbmVkJzogZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICB0aGlzWydvYmplY3QnXShPYmplY3Qua2V5cyhfdGhpcy5fcGx1Z2lucykpO1xuICAgICAgICAgICB9XG4gICAgICAgICB9O1xuICAgICAgICAgZm5zW3R5cGVdKHBsdWdpbnMpO1xuICAgICAgIH1cbiAgICAgfWNhdGNoKGVycil7XG4gICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICB9ZmluYWxseXtcbiAgICAgICByZXR1cm4gcGx1Z2lucztcbiAgICAgfVxuICAgfSxcblxuICAvKipcbiAgICogcmV0dXJucyBhIHJhbmRvbSBiYXNlLTM2IHVpZCB3aXRoIG5hbWVzcGFjaW5nXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcGFyYW0ge051bWJlcn0gbGVuZ3RoIC0gbnVtYmVyIG9mIHJhbmRvbSBiYXNlLTM2IGRpZ2l0cyBkZXNpcmVkLiBJbmNyZWFzZSBmb3IgbW9yZSByYW5kb20gc3RyaW5ncy5cbiAgICogQHBhcmFtIHtTdHJpbmd9IG5hbWVzcGFjZSAtIG5hbWUgb2YgcGx1Z2luIHRvIGJlIGluY29ycG9yYXRlZCBpbiB1aWQsIG9wdGlvbmFsLlxuICAgKiBAZGVmYXVsdCB7U3RyaW5nfSAnJyAtIGlmIG5vIHBsdWdpbiBuYW1lIGlzIHByb3ZpZGVkLCBub3RoaW5nIGlzIGFwcGVuZGVkIHRvIHRoZSB1aWQuXG4gICAqIEByZXR1cm5zIHtTdHJpbmd9IC0gdW5pcXVlIGlkXG4gICAqL1xuICBHZXRZb0RpZ2l0czogZnVuY3Rpb24obGVuZ3RoLCBuYW1lc3BhY2Upe1xuICAgIGxlbmd0aCA9IGxlbmd0aCB8fCA2O1xuICAgIHJldHVybiBNYXRoLnJvdW5kKChNYXRoLnBvdygzNiwgbGVuZ3RoICsgMSkgLSBNYXRoLnJhbmRvbSgpICogTWF0aC5wb3coMzYsIGxlbmd0aCkpKS50b1N0cmluZygzNikuc2xpY2UoMSkgKyAobmFtZXNwYWNlID8gYC0ke25hbWVzcGFjZX1gIDogJycpO1xuICB9LFxuICAvKipcbiAgICogSW5pdGlhbGl6ZSBwbHVnaW5zIG9uIGFueSBlbGVtZW50cyB3aXRoaW4gYGVsZW1gIChhbmQgYGVsZW1gIGl0c2VsZikgdGhhdCBhcmVuJ3QgYWxyZWFkeSBpbml0aWFsaXplZC5cbiAgICogQHBhcmFtIHtPYmplY3R9IGVsZW0gLSBqUXVlcnkgb2JqZWN0IGNvbnRhaW5pbmcgdGhlIGVsZW1lbnQgdG8gY2hlY2sgaW5zaWRlLiBBbHNvIGNoZWNrcyB0aGUgZWxlbWVudCBpdHNlbGYsIHVubGVzcyBpdCdzIHRoZSBgZG9jdW1lbnRgIG9iamVjdC5cbiAgICogQHBhcmFtIHtTdHJpbmd8QXJyYXl9IHBsdWdpbnMgLSBBIGxpc3Qgb2YgcGx1Z2lucyB0byBpbml0aWFsaXplLiBMZWF2ZSB0aGlzIG91dCB0byBpbml0aWFsaXplIGV2ZXJ5dGhpbmcuXG4gICAqL1xuICByZWZsb3c6IGZ1bmN0aW9uKGVsZW0sIHBsdWdpbnMpIHtcblxuICAgIC8vIElmIHBsdWdpbnMgaXMgdW5kZWZpbmVkLCBqdXN0IGdyYWIgZXZlcnl0aGluZ1xuICAgIGlmICh0eXBlb2YgcGx1Z2lucyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHBsdWdpbnMgPSBPYmplY3Qua2V5cyh0aGlzLl9wbHVnaW5zKTtcbiAgICB9XG4gICAgLy8gSWYgcGx1Z2lucyBpcyBhIHN0cmluZywgY29udmVydCBpdCB0byBhbiBhcnJheSB3aXRoIG9uZSBpdGVtXG4gICAgZWxzZSBpZiAodHlwZW9mIHBsdWdpbnMgPT09ICdzdHJpbmcnKSB7XG4gICAgICBwbHVnaW5zID0gW3BsdWdpbnNdO1xuICAgIH1cblxuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAvLyBJdGVyYXRlIHRocm91Z2ggZWFjaCBwbHVnaW5cbiAgICAkLmVhY2gocGx1Z2lucywgZnVuY3Rpb24oaSwgbmFtZSkge1xuICAgICAgLy8gR2V0IHRoZSBjdXJyZW50IHBsdWdpblxuICAgICAgdmFyIHBsdWdpbiA9IF90aGlzLl9wbHVnaW5zW25hbWVdO1xuXG4gICAgICAvLyBMb2NhbGl6ZSB0aGUgc2VhcmNoIHRvIGFsbCBlbGVtZW50cyBpbnNpZGUgZWxlbSwgYXMgd2VsbCBhcyBlbGVtIGl0c2VsZiwgdW5sZXNzIGVsZW0gPT09IGRvY3VtZW50XG4gICAgICB2YXIgJGVsZW0gPSAkKGVsZW0pLmZpbmQoJ1tkYXRhLScrbmFtZSsnXScpLmFkZEJhY2soJ1tkYXRhLScrbmFtZSsnXScpO1xuXG4gICAgICAvLyBGb3IgZWFjaCBwbHVnaW4gZm91bmQsIGluaXRpYWxpemUgaXRcbiAgICAgICRlbGVtLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciAkZWwgPSAkKHRoaXMpLFxuICAgICAgICAgICAgb3B0cyA9IHt9O1xuICAgICAgICAvLyBEb24ndCBkb3VibGUtZGlwIG9uIHBsdWdpbnNcbiAgICAgICAgaWYgKCRlbC5kYXRhKCd6ZlBsdWdpbicpKSB7XG4gICAgICAgICAgY29uc29sZS53YXJuKFwiVHJpZWQgdG8gaW5pdGlhbGl6ZSBcIituYW1lK1wiIG9uIGFuIGVsZW1lbnQgdGhhdCBhbHJlYWR5IGhhcyBhIEZvdW5kYXRpb24gcGx1Z2luLlwiKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBpZigkZWwuYXR0cignZGF0YS1vcHRpb25zJykpe1xuICAgICAgICAgIHZhciB0aGluZyA9ICRlbC5hdHRyKCdkYXRhLW9wdGlvbnMnKS5zcGxpdCgnOycpLmZvckVhY2goZnVuY3Rpb24oZSwgaSl7XG4gICAgICAgICAgICB2YXIgb3B0ID0gZS5zcGxpdCgnOicpLm1hcChmdW5jdGlvbihlbCl7IHJldHVybiBlbC50cmltKCk7IH0pO1xuICAgICAgICAgICAgaWYob3B0WzBdKSBvcHRzW29wdFswXV0gPSBwYXJzZVZhbHVlKG9wdFsxXSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5e1xuICAgICAgICAgICRlbC5kYXRhKCd6ZlBsdWdpbicsIG5ldyBwbHVnaW4oJCh0aGlzKSwgb3B0cykpO1xuICAgICAgICB9Y2F0Y2goZXIpe1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXIpO1xuICAgICAgICB9ZmluYWxseXtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICB9LFxuICBnZXRGbk5hbWU6IGZ1bmN0aW9uTmFtZSxcbiAgdHJhbnNpdGlvbmVuZDogZnVuY3Rpb24oJGVsZW0pe1xuICAgIHZhciB0cmFuc2l0aW9ucyA9IHtcbiAgICAgICd0cmFuc2l0aW9uJzogJ3RyYW5zaXRpb25lbmQnLFxuICAgICAgJ1dlYmtpdFRyYW5zaXRpb24nOiAnd2Via2l0VHJhbnNpdGlvbkVuZCcsXG4gICAgICAnTW96VHJhbnNpdGlvbic6ICd0cmFuc2l0aW9uZW5kJyxcbiAgICAgICdPVHJhbnNpdGlvbic6ICdvdHJhbnNpdGlvbmVuZCdcbiAgICB9O1xuICAgIHZhciBlbGVtID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JyksXG4gICAgICAgIGVuZDtcblxuICAgIGZvciAodmFyIHQgaW4gdHJhbnNpdGlvbnMpe1xuICAgICAgaWYgKHR5cGVvZiBlbGVtLnN0eWxlW3RdICE9PSAndW5kZWZpbmVkJyl7XG4gICAgICAgIGVuZCA9IHRyYW5zaXRpb25zW3RdO1xuICAgICAgfVxuICAgIH1cbiAgICBpZihlbmQpe1xuICAgICAgcmV0dXJuIGVuZDtcbiAgICB9ZWxzZXtcbiAgICAgIGVuZCA9IHNldFRpbWVvdXQoZnVuY3Rpb24oKXtcbiAgICAgICAgJGVsZW0udHJpZ2dlckhhbmRsZXIoJ3RyYW5zaXRpb25lbmQnLCBbJGVsZW1dKTtcbiAgICAgIH0sIDEpO1xuICAgICAgcmV0dXJuICd0cmFuc2l0aW9uZW5kJztcbiAgICB9XG4gIH1cbn07XG5cbkZvdW5kYXRpb24udXRpbCA9IHtcbiAgLyoqXG4gICAqIEZ1bmN0aW9uIGZvciBhcHBseWluZyBhIGRlYm91bmNlIGVmZmVjdCB0byBhIGZ1bmN0aW9uIGNhbGwuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBmdW5jIC0gRnVuY3Rpb24gdG8gYmUgY2FsbGVkIGF0IGVuZCBvZiB0aW1lb3V0LlxuICAgKiBAcGFyYW0ge051bWJlcn0gZGVsYXkgLSBUaW1lIGluIG1zIHRvIGRlbGF5IHRoZSBjYWxsIG9mIGBmdW5jYC5cbiAgICogQHJldHVybnMgZnVuY3Rpb25cbiAgICovXG4gIHRocm90dGxlOiBmdW5jdGlvbiAoZnVuYywgZGVsYXkpIHtcbiAgICB2YXIgdGltZXIgPSBudWxsO1xuXG4gICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgIHZhciBjb250ZXh0ID0gdGhpcywgYXJncyA9IGFyZ3VtZW50cztcblxuICAgICAgaWYgKHRpbWVyID09PSBudWxsKSB7XG4gICAgICAgIHRpbWVyID0gc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgZnVuYy5hcHBseShjb250ZXh0LCBhcmdzKTtcbiAgICAgICAgICB0aW1lciA9IG51bGw7XG4gICAgICAgIH0sIGRlbGF5KTtcbiAgICAgIH1cbiAgICB9O1xuICB9XG59O1xuXG4vLyBUT0RPOiBjb25zaWRlciBub3QgbWFraW5nIHRoaXMgYSBqUXVlcnkgZnVuY3Rpb25cbi8vIFRPRE86IG5lZWQgd2F5IHRvIHJlZmxvdyB2cy4gcmUtaW5pdGlhbGl6ZVxuLyoqXG4gKiBUaGUgRm91bmRhdGlvbiBqUXVlcnkgbWV0aG9kLlxuICogQHBhcmFtIHtTdHJpbmd8QXJyYXl9IG1ldGhvZCAtIEFuIGFjdGlvbiB0byBwZXJmb3JtIG9uIHRoZSBjdXJyZW50IGpRdWVyeSBvYmplY3QuXG4gKi9cbnZhciBmb3VuZGF0aW9uID0gZnVuY3Rpb24obWV0aG9kKSB7XG4gIHZhciB0eXBlID0gdHlwZW9mIG1ldGhvZCxcbiAgICAgICRtZXRhID0gJCgnbWV0YS5mb3VuZGF0aW9uLW1xJyksXG4gICAgICAkbm9KUyA9ICQoJy5uby1qcycpO1xuXG4gIGlmKCEkbWV0YS5sZW5ndGgpe1xuICAgICQoJzxtZXRhIGNsYXNzPVwiZm91bmRhdGlvbi1tcVwiPicpLmFwcGVuZFRvKGRvY3VtZW50LmhlYWQpO1xuICB9XG4gIGlmKCRub0pTLmxlbmd0aCl7XG4gICAgJG5vSlMucmVtb3ZlQ2xhc3MoJ25vLWpzJyk7XG4gIH1cblxuICBpZih0eXBlID09PSAndW5kZWZpbmVkJyl7Ly9uZWVkcyB0byBpbml0aWFsaXplIHRoZSBGb3VuZGF0aW9uIG9iamVjdCwgb3IgYW4gaW5kaXZpZHVhbCBwbHVnaW4uXG4gICAgRm91bmRhdGlvbi5NZWRpYVF1ZXJ5Ll9pbml0KCk7XG4gICAgRm91bmRhdGlvbi5yZWZsb3codGhpcyk7XG4gIH1lbHNlIGlmKHR5cGUgPT09ICdzdHJpbmcnKXsvL2FuIGluZGl2aWR1YWwgbWV0aG9kIHRvIGludm9rZSBvbiBhIHBsdWdpbiBvciBncm91cCBvZiBwbHVnaW5zXG4gICAgdmFyIGFyZ3MgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMsIDEpOy8vY29sbGVjdCBhbGwgdGhlIGFyZ3VtZW50cywgaWYgbmVjZXNzYXJ5XG4gICAgdmFyIHBsdWdDbGFzcyA9IHRoaXMuZGF0YSgnemZQbHVnaW4nKTsvL2RldGVybWluZSB0aGUgY2xhc3Mgb2YgcGx1Z2luXG5cbiAgICBpZihwbHVnQ2xhc3MgIT09IHVuZGVmaW5lZCAmJiBwbHVnQ2xhc3NbbWV0aG9kXSAhPT0gdW5kZWZpbmVkKXsvL21ha2Ugc3VyZSBib3RoIHRoZSBjbGFzcyBhbmQgbWV0aG9kIGV4aXN0XG4gICAgICBpZih0aGlzLmxlbmd0aCA9PT0gMSl7Ly9pZiB0aGVyZSdzIG9ubHkgb25lLCBjYWxsIGl0IGRpcmVjdGx5LlxuICAgICAgICAgIHBsdWdDbGFzc1ttZXRob2RdLmFwcGx5KHBsdWdDbGFzcywgYXJncyk7XG4gICAgICB9ZWxzZXtcbiAgICAgICAgdGhpcy5lYWNoKGZ1bmN0aW9uKGksIGVsKXsvL290aGVyd2lzZSBsb29wIHRocm91Z2ggdGhlIGpRdWVyeSBjb2xsZWN0aW9uIGFuZCBpbnZva2UgdGhlIG1ldGhvZCBvbiBlYWNoXG4gICAgICAgICAgcGx1Z0NsYXNzW21ldGhvZF0uYXBwbHkoJChlbCkuZGF0YSgnemZQbHVnaW4nKSwgYXJncyk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1lbHNley8vZXJyb3IgZm9yIG5vIGNsYXNzIG9yIG5vIG1ldGhvZFxuICAgICAgdGhyb3cgbmV3IFJlZmVyZW5jZUVycm9yKFwiV2UncmUgc29ycnksICdcIiArIG1ldGhvZCArIFwiJyBpcyBub3QgYW4gYXZhaWxhYmxlIG1ldGhvZCBmb3IgXCIgKyAocGx1Z0NsYXNzID8gZnVuY3Rpb25OYW1lKHBsdWdDbGFzcykgOiAndGhpcyBlbGVtZW50JykgKyAnLicpO1xuICAgIH1cbiAgfWVsc2V7Ly9lcnJvciBmb3IgaW52YWxpZCBhcmd1bWVudCB0eXBlXG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgV2UncmUgc29ycnksICR7dHlwZX0gaXMgbm90IGEgdmFsaWQgcGFyYW1ldGVyLiBZb3UgbXVzdCB1c2UgYSBzdHJpbmcgcmVwcmVzZW50aW5nIHRoZSBtZXRob2QgeW91IHdpc2ggdG8gaW52b2tlLmApO1xuICB9XG4gIHJldHVybiB0aGlzO1xufTtcblxud2luZG93LkZvdW5kYXRpb24gPSBGb3VuZGF0aW9uO1xuJC5mbi5mb3VuZGF0aW9uID0gZm91bmRhdGlvbjtcblxuLy8gUG9seWZpbGwgZm9yIHJlcXVlc3RBbmltYXRpb25GcmFtZVxuKGZ1bmN0aW9uKCkge1xuICBpZiAoIURhdGUubm93IHx8ICF3aW5kb3cuRGF0ZS5ub3cpXG4gICAgd2luZG93LkRhdGUubm93ID0gRGF0ZS5ub3cgPSBmdW5jdGlvbigpIHsgcmV0dXJuIG5ldyBEYXRlKCkuZ2V0VGltZSgpOyB9O1xuXG4gIHZhciB2ZW5kb3JzID0gWyd3ZWJraXQnLCAnbW96J107XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgdmVuZG9ycy5sZW5ndGggJiYgIXdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWU7ICsraSkge1xuICAgICAgdmFyIHZwID0gdmVuZG9yc1tpXTtcbiAgICAgIHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUgPSB3aW5kb3dbdnArJ1JlcXVlc3RBbmltYXRpb25GcmFtZSddO1xuICAgICAgd2luZG93LmNhbmNlbEFuaW1hdGlvbkZyYW1lID0gKHdpbmRvd1t2cCsnQ2FuY2VsQW5pbWF0aW9uRnJhbWUnXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfHwgd2luZG93W3ZwKydDYW5jZWxSZXF1ZXN0QW5pbWF0aW9uRnJhbWUnXSk7XG4gIH1cbiAgaWYgKC9pUChhZHxob25lfG9kKS4qT1MgNi8udGVzdCh3aW5kb3cubmF2aWdhdG9yLnVzZXJBZ2VudClcbiAgICB8fCAhd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSB8fCAhd2luZG93LmNhbmNlbEFuaW1hdGlvbkZyYW1lKSB7XG4gICAgdmFyIGxhc3RUaW1lID0gMDtcbiAgICB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lID0gZnVuY3Rpb24oY2FsbGJhY2spIHtcbiAgICAgICAgdmFyIG5vdyA9IERhdGUubm93KCk7XG4gICAgICAgIHZhciBuZXh0VGltZSA9IE1hdGgubWF4KGxhc3RUaW1lICsgMTYsIG5vdyk7XG4gICAgICAgIHJldHVybiBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkgeyBjYWxsYmFjayhsYXN0VGltZSA9IG5leHRUaW1lKTsgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmV4dFRpbWUgLSBub3cpO1xuICAgIH07XG4gICAgd2luZG93LmNhbmNlbEFuaW1hdGlvbkZyYW1lID0gY2xlYXJUaW1lb3V0O1xuICB9XG4gIC8qKlxuICAgKiBQb2x5ZmlsbCBmb3IgcGVyZm9ybWFuY2Uubm93LCByZXF1aXJlZCBieSByQUZcbiAgICovXG4gIGlmKCF3aW5kb3cucGVyZm9ybWFuY2UgfHwgIXdpbmRvdy5wZXJmb3JtYW5jZS5ub3cpe1xuICAgIHdpbmRvdy5wZXJmb3JtYW5jZSA9IHtcbiAgICAgIHN0YXJ0OiBEYXRlLm5vdygpLFxuICAgICAgbm93OiBmdW5jdGlvbigpeyByZXR1cm4gRGF0ZS5ub3coKSAtIHRoaXMuc3RhcnQ7IH1cbiAgICB9O1xuICB9XG59KSgpO1xuaWYgKCFGdW5jdGlvbi5wcm90b3R5cGUuYmluZCkge1xuICBGdW5jdGlvbi5wcm90b3R5cGUuYmluZCA9IGZ1bmN0aW9uKG9UaGlzKSB7XG4gICAgaWYgKHR5cGVvZiB0aGlzICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICAvLyBjbG9zZXN0IHRoaW5nIHBvc3NpYmxlIHRvIHRoZSBFQ01BU2NyaXB0IDVcbiAgICAgIC8vIGludGVybmFsIElzQ2FsbGFibGUgZnVuY3Rpb25cbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0Z1bmN0aW9uLnByb3RvdHlwZS5iaW5kIC0gd2hhdCBpcyB0cnlpbmcgdG8gYmUgYm91bmQgaXMgbm90IGNhbGxhYmxlJyk7XG4gICAgfVxuXG4gICAgdmFyIGFBcmdzICAgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMsIDEpLFxuICAgICAgICBmVG9CaW5kID0gdGhpcyxcbiAgICAgICAgZk5PUCAgICA9IGZ1bmN0aW9uKCkge30sXG4gICAgICAgIGZCb3VuZCAgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICByZXR1cm4gZlRvQmluZC5hcHBseSh0aGlzIGluc3RhbmNlb2YgZk5PUFxuICAgICAgICAgICAgICAgICA/IHRoaXNcbiAgICAgICAgICAgICAgICAgOiBvVGhpcyxcbiAgICAgICAgICAgICAgICAgYUFyZ3MuY29uY2F0KEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cykpKTtcbiAgICAgICAgfTtcblxuICAgIGlmICh0aGlzLnByb3RvdHlwZSkge1xuICAgICAgLy8gbmF0aXZlIGZ1bmN0aW9ucyBkb24ndCBoYXZlIGEgcHJvdG90eXBlXG4gICAgICBmTk9QLnByb3RvdHlwZSA9IHRoaXMucHJvdG90eXBlO1xuICAgIH1cbiAgICBmQm91bmQucHJvdG90eXBlID0gbmV3IGZOT1AoKTtcblxuICAgIHJldHVybiBmQm91bmQ7XG4gIH07XG59XG4vLyBQb2x5ZmlsbCB0byBnZXQgdGhlIG5hbWUgb2YgYSBmdW5jdGlvbiBpbiBJRTlcbmZ1bmN0aW9uIGZ1bmN0aW9uTmFtZShmbikge1xuICBpZiAoRnVuY3Rpb24ucHJvdG90eXBlLm5hbWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHZhciBmdW5jTmFtZVJlZ2V4ID0gL2Z1bmN0aW9uXFxzKFteKF17MSx9KVxcKC87XG4gICAgdmFyIHJlc3VsdHMgPSAoZnVuY05hbWVSZWdleCkuZXhlYygoZm4pLnRvU3RyaW5nKCkpO1xuICAgIHJldHVybiAocmVzdWx0cyAmJiByZXN1bHRzLmxlbmd0aCA+IDEpID8gcmVzdWx0c1sxXS50cmltKCkgOiBcIlwiO1xuICB9XG4gIGVsc2UgaWYgKGZuLnByb3RvdHlwZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIGZuLmNvbnN0cnVjdG9yLm5hbWU7XG4gIH1cbiAgZWxzZSB7XG4gICAgcmV0dXJuIGZuLnByb3RvdHlwZS5jb25zdHJ1Y3Rvci5uYW1lO1xuICB9XG59XG5mdW5jdGlvbiBwYXJzZVZhbHVlKHN0cil7XG4gIGlmICgndHJ1ZScgPT09IHN0cikgcmV0dXJuIHRydWU7XG4gIGVsc2UgaWYgKCdmYWxzZScgPT09IHN0cikgcmV0dXJuIGZhbHNlO1xuICBlbHNlIGlmICghaXNOYU4oc3RyICogMSkpIHJldHVybiBwYXJzZUZsb2F0KHN0cik7XG4gIHJldHVybiBzdHI7XG59XG4vLyBDb252ZXJ0IFBhc2NhbENhc2UgdG8ga2ViYWItY2FzZVxuLy8gVGhhbmsgeW91OiBodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vYS84OTU1NTgwXG5mdW5jdGlvbiBoeXBoZW5hdGUoc3RyKSB7XG4gIHJldHVybiBzdHIucmVwbGFjZSgvKFthLXpdKShbQS1aXSkvZywgJyQxLSQyJykudG9Mb3dlckNhc2UoKTtcbn1cblxufShqUXVlcnkpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4hZnVuY3Rpb24oJCkge1xuXG5Gb3VuZGF0aW9uLkJveCA9IHtcbiAgSW1Ob3RUb3VjaGluZ1lvdTogSW1Ob3RUb3VjaGluZ1lvdSxcbiAgR2V0RGltZW5zaW9uczogR2V0RGltZW5zaW9ucyxcbiAgR2V0T2Zmc2V0czogR2V0T2Zmc2V0c1xufVxuXG4vKipcbiAqIENvbXBhcmVzIHRoZSBkaW1lbnNpb25zIG9mIGFuIGVsZW1lbnQgdG8gYSBjb250YWluZXIgYW5kIGRldGVybWluZXMgY29sbGlzaW9uIGV2ZW50cyB3aXRoIGNvbnRhaW5lci5cbiAqIEBmdW5jdGlvblxuICogQHBhcmFtIHtqUXVlcnl9IGVsZW1lbnQgLSBqUXVlcnkgb2JqZWN0IHRvIHRlc3QgZm9yIGNvbGxpc2lvbnMuXG4gKiBAcGFyYW0ge2pRdWVyeX0gcGFyZW50IC0galF1ZXJ5IG9iamVjdCB0byB1c2UgYXMgYm91bmRpbmcgY29udGFpbmVyLlxuICogQHBhcmFtIHtCb29sZWFufSBsck9ubHkgLSBzZXQgdG8gdHJ1ZSB0byBjaGVjayBsZWZ0IGFuZCByaWdodCB2YWx1ZXMgb25seS5cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gdGJPbmx5IC0gc2V0IHRvIHRydWUgdG8gY2hlY2sgdG9wIGFuZCBib3R0b20gdmFsdWVzIG9ubHkuXG4gKiBAZGVmYXVsdCBpZiBubyBwYXJlbnQgb2JqZWN0IHBhc3NlZCwgZGV0ZWN0cyBjb2xsaXNpb25zIHdpdGggYHdpbmRvd2AuXG4gKiBAcmV0dXJucyB7Qm9vbGVhbn0gLSB0cnVlIGlmIGNvbGxpc2lvbiBmcmVlLCBmYWxzZSBpZiBhIGNvbGxpc2lvbiBpbiBhbnkgZGlyZWN0aW9uLlxuICovXG5mdW5jdGlvbiBJbU5vdFRvdWNoaW5nWW91KGVsZW1lbnQsIHBhcmVudCwgbHJPbmx5LCB0Yk9ubHkpIHtcbiAgdmFyIGVsZURpbXMgPSBHZXREaW1lbnNpb25zKGVsZW1lbnQpLFxuICAgICAgdG9wLCBib3R0b20sIGxlZnQsIHJpZ2h0O1xuXG4gIGlmIChwYXJlbnQpIHtcbiAgICB2YXIgcGFyRGltcyA9IEdldERpbWVuc2lvbnMocGFyZW50KTtcblxuICAgIGJvdHRvbSA9IChlbGVEaW1zLm9mZnNldC50b3AgKyBlbGVEaW1zLmhlaWdodCA8PSBwYXJEaW1zLmhlaWdodCArIHBhckRpbXMub2Zmc2V0LnRvcCk7XG4gICAgdG9wICAgID0gKGVsZURpbXMub2Zmc2V0LnRvcCA+PSBwYXJEaW1zLm9mZnNldC50b3ApO1xuICAgIGxlZnQgICA9IChlbGVEaW1zLm9mZnNldC5sZWZ0ID49IHBhckRpbXMub2Zmc2V0LmxlZnQpO1xuICAgIHJpZ2h0ICA9IChlbGVEaW1zLm9mZnNldC5sZWZ0ICsgZWxlRGltcy53aWR0aCA8PSBwYXJEaW1zLndpZHRoICsgcGFyRGltcy5vZmZzZXQubGVmdCk7XG4gIH1cbiAgZWxzZSB7XG4gICAgYm90dG9tID0gKGVsZURpbXMub2Zmc2V0LnRvcCArIGVsZURpbXMuaGVpZ2h0IDw9IGVsZURpbXMud2luZG93RGltcy5oZWlnaHQgKyBlbGVEaW1zLndpbmRvd0RpbXMub2Zmc2V0LnRvcCk7XG4gICAgdG9wICAgID0gKGVsZURpbXMub2Zmc2V0LnRvcCA+PSBlbGVEaW1zLndpbmRvd0RpbXMub2Zmc2V0LnRvcCk7XG4gICAgbGVmdCAgID0gKGVsZURpbXMub2Zmc2V0LmxlZnQgPj0gZWxlRGltcy53aW5kb3dEaW1zLm9mZnNldC5sZWZ0KTtcbiAgICByaWdodCAgPSAoZWxlRGltcy5vZmZzZXQubGVmdCArIGVsZURpbXMud2lkdGggPD0gZWxlRGltcy53aW5kb3dEaW1zLndpZHRoKTtcbiAgfVxuXG4gIHZhciBhbGxEaXJzID0gW2JvdHRvbSwgdG9wLCBsZWZ0LCByaWdodF07XG5cbiAgaWYgKGxyT25seSkge1xuICAgIHJldHVybiBsZWZ0ID09PSByaWdodCA9PT0gdHJ1ZTtcbiAgfVxuXG4gIGlmICh0Yk9ubHkpIHtcbiAgICByZXR1cm4gdG9wID09PSBib3R0b20gPT09IHRydWU7XG4gIH1cblxuICByZXR1cm4gYWxsRGlycy5pbmRleE9mKGZhbHNlKSA9PT0gLTE7XG59O1xuXG4vKipcbiAqIFVzZXMgbmF0aXZlIG1ldGhvZHMgdG8gcmV0dXJuIGFuIG9iamVjdCBvZiBkaW1lbnNpb24gdmFsdWVzLlxuICogQGZ1bmN0aW9uXG4gKiBAcGFyYW0ge2pRdWVyeSB8fCBIVE1MfSBlbGVtZW50IC0galF1ZXJ5IG9iamVjdCBvciBET00gZWxlbWVudCBmb3Igd2hpY2ggdG8gZ2V0IHRoZSBkaW1lbnNpb25zLiBDYW4gYmUgYW55IGVsZW1lbnQgb3RoZXIgdGhhdCBkb2N1bWVudCBvciB3aW5kb3cuXG4gKiBAcmV0dXJucyB7T2JqZWN0fSAtIG5lc3RlZCBvYmplY3Qgb2YgaW50ZWdlciBwaXhlbCB2YWx1ZXNcbiAqIFRPRE8gLSBpZiBlbGVtZW50IGlzIHdpbmRvdywgcmV0dXJuIG9ubHkgdGhvc2UgdmFsdWVzLlxuICovXG5mdW5jdGlvbiBHZXREaW1lbnNpb25zKGVsZW0sIHRlc3Qpe1xuICBlbGVtID0gZWxlbS5sZW5ndGggPyBlbGVtWzBdIDogZWxlbTtcblxuICBpZiAoZWxlbSA9PT0gd2luZG93IHx8IGVsZW0gPT09IGRvY3VtZW50KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiSSdtIHNvcnJ5LCBEYXZlLiBJJ20gYWZyYWlkIEkgY2FuJ3QgZG8gdGhhdC5cIik7XG4gIH1cblxuICB2YXIgcmVjdCA9IGVsZW0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksXG4gICAgICBwYXJSZWN0ID0gZWxlbS5wYXJlbnROb2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgd2luUmVjdCA9IGRvY3VtZW50LmJvZHkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksXG4gICAgICB3aW5ZID0gd2luZG93LnBhZ2VZT2Zmc2V0LFxuICAgICAgd2luWCA9IHdpbmRvdy5wYWdlWE9mZnNldDtcblxuICByZXR1cm4ge1xuICAgIHdpZHRoOiByZWN0LndpZHRoLFxuICAgIGhlaWdodDogcmVjdC5oZWlnaHQsXG4gICAgb2Zmc2V0OiB7XG4gICAgICB0b3A6IHJlY3QudG9wICsgd2luWSxcbiAgICAgIGxlZnQ6IHJlY3QubGVmdCArIHdpblhcbiAgICB9LFxuICAgIHBhcmVudERpbXM6IHtcbiAgICAgIHdpZHRoOiBwYXJSZWN0LndpZHRoLFxuICAgICAgaGVpZ2h0OiBwYXJSZWN0LmhlaWdodCxcbiAgICAgIG9mZnNldDoge1xuICAgICAgICB0b3A6IHBhclJlY3QudG9wICsgd2luWSxcbiAgICAgICAgbGVmdDogcGFyUmVjdC5sZWZ0ICsgd2luWFxuICAgICAgfVxuICAgIH0sXG4gICAgd2luZG93RGltczoge1xuICAgICAgd2lkdGg6IHdpblJlY3Qud2lkdGgsXG4gICAgICBoZWlnaHQ6IHdpblJlY3QuaGVpZ2h0LFxuICAgICAgb2Zmc2V0OiB7XG4gICAgICAgIHRvcDogd2luWSxcbiAgICAgICAgbGVmdDogd2luWFxuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIFJldHVybnMgYW4gb2JqZWN0IG9mIHRvcCBhbmQgbGVmdCBpbnRlZ2VyIHBpeGVsIHZhbHVlcyBmb3IgZHluYW1pY2FsbHkgcmVuZGVyZWQgZWxlbWVudHMsXG4gKiBzdWNoIGFzOiBUb29sdGlwLCBSZXZlYWwsIGFuZCBEcm9wZG93blxuICogQGZ1bmN0aW9uXG4gKiBAcGFyYW0ge2pRdWVyeX0gZWxlbWVudCAtIGpRdWVyeSBvYmplY3QgZm9yIHRoZSBlbGVtZW50IGJlaW5nIHBvc2l0aW9uZWQuXG4gKiBAcGFyYW0ge2pRdWVyeX0gYW5jaG9yIC0galF1ZXJ5IG9iamVjdCBmb3IgdGhlIGVsZW1lbnQncyBhbmNob3IgcG9pbnQuXG4gKiBAcGFyYW0ge1N0cmluZ30gcG9zaXRpb24gLSBhIHN0cmluZyByZWxhdGluZyB0byB0aGUgZGVzaXJlZCBwb3NpdGlvbiBvZiB0aGUgZWxlbWVudCwgcmVsYXRpdmUgdG8gaXQncyBhbmNob3JcbiAqIEBwYXJhbSB7TnVtYmVyfSB2T2Zmc2V0IC0gaW50ZWdlciBwaXhlbCB2YWx1ZSBvZiBkZXNpcmVkIHZlcnRpY2FsIHNlcGFyYXRpb24gYmV0d2VlbiBhbmNob3IgYW5kIGVsZW1lbnQuXG4gKiBAcGFyYW0ge051bWJlcn0gaE9mZnNldCAtIGludGVnZXIgcGl4ZWwgdmFsdWUgb2YgZGVzaXJlZCBob3Jpem9udGFsIHNlcGFyYXRpb24gYmV0d2VlbiBhbmNob3IgYW5kIGVsZW1lbnQuXG4gKiBAcGFyYW0ge0Jvb2xlYW59IGlzT3ZlcmZsb3cgLSBpZiBhIGNvbGxpc2lvbiBldmVudCBpcyBkZXRlY3RlZCwgc2V0cyB0byB0cnVlIHRvIGRlZmF1bHQgdGhlIGVsZW1lbnQgdG8gZnVsbCB3aWR0aCAtIGFueSBkZXNpcmVkIG9mZnNldC5cbiAqIFRPRE8gYWx0ZXIvcmV3cml0ZSB0byB3b3JrIHdpdGggYGVtYCB2YWx1ZXMgYXMgd2VsbC9pbnN0ZWFkIG9mIHBpeGVsc1xuICovXG5mdW5jdGlvbiBHZXRPZmZzZXRzKGVsZW1lbnQsIGFuY2hvciwgcG9zaXRpb24sIHZPZmZzZXQsIGhPZmZzZXQsIGlzT3ZlcmZsb3cpIHtcbiAgdmFyICRlbGVEaW1zID0gR2V0RGltZW5zaW9ucyhlbGVtZW50KSxcbiAgICAgICRhbmNob3JEaW1zID0gYW5jaG9yID8gR2V0RGltZW5zaW9ucyhhbmNob3IpIDogbnVsbDtcblxuICBzd2l0Y2ggKHBvc2l0aW9uKSB7XG4gICAgY2FzZSAndG9wJzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxlZnQ6IChGb3VuZGF0aW9uLnJ0bCgpID8gJGFuY2hvckRpbXMub2Zmc2V0LmxlZnQgLSAkZWxlRGltcy53aWR0aCArICRhbmNob3JEaW1zLndpZHRoIDogJGFuY2hvckRpbXMub2Zmc2V0LmxlZnQpLFxuICAgICAgICB0b3A6ICRhbmNob3JEaW1zLm9mZnNldC50b3AgLSAoJGVsZURpbXMuaGVpZ2h0ICsgdk9mZnNldClcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2xlZnQnOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogJGFuY2hvckRpbXMub2Zmc2V0LmxlZnQgLSAoJGVsZURpbXMud2lkdGggKyBoT2Zmc2V0KSxcbiAgICAgICAgdG9wOiAkYW5jaG9yRGltcy5vZmZzZXQudG9wXG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICBjYXNlICdyaWdodCc6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsZWZ0OiAkYW5jaG9yRGltcy5vZmZzZXQubGVmdCArICRhbmNob3JEaW1zLndpZHRoICsgaE9mZnNldCxcbiAgICAgICAgdG9wOiAkYW5jaG9yRGltcy5vZmZzZXQudG9wXG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICBjYXNlICdjZW50ZXIgdG9wJzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxlZnQ6ICgkYW5jaG9yRGltcy5vZmZzZXQubGVmdCArICgkYW5jaG9yRGltcy53aWR0aCAvIDIpKSAtICgkZWxlRGltcy53aWR0aCAvIDIpLFxuICAgICAgICB0b3A6ICRhbmNob3JEaW1zLm9mZnNldC50b3AgLSAoJGVsZURpbXMuaGVpZ2h0ICsgdk9mZnNldClcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2NlbnRlciBib3R0b20nOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogaXNPdmVyZmxvdyA/IGhPZmZzZXQgOiAoKCRhbmNob3JEaW1zLm9mZnNldC5sZWZ0ICsgKCRhbmNob3JEaW1zLndpZHRoIC8gMikpIC0gKCRlbGVEaW1zLndpZHRoIC8gMikpLFxuICAgICAgICB0b3A6ICRhbmNob3JEaW1zLm9mZnNldC50b3AgKyAkYW5jaG9yRGltcy5oZWlnaHQgKyB2T2Zmc2V0XG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICBjYXNlICdjZW50ZXIgbGVmdCc6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsZWZ0OiAkYW5jaG9yRGltcy5vZmZzZXQubGVmdCAtICgkZWxlRGltcy53aWR0aCArIGhPZmZzZXQpLFxuICAgICAgICB0b3A6ICgkYW5jaG9yRGltcy5vZmZzZXQudG9wICsgKCRhbmNob3JEaW1zLmhlaWdodCAvIDIpKSAtICgkZWxlRGltcy5oZWlnaHQgLyAyKVxuICAgICAgfVxuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnY2VudGVyIHJpZ2h0JzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxlZnQ6ICRhbmNob3JEaW1zLm9mZnNldC5sZWZ0ICsgJGFuY2hvckRpbXMud2lkdGggKyBoT2Zmc2V0ICsgMSxcbiAgICAgICAgdG9wOiAoJGFuY2hvckRpbXMub2Zmc2V0LnRvcCArICgkYW5jaG9yRGltcy5oZWlnaHQgLyAyKSkgLSAoJGVsZURpbXMuaGVpZ2h0IC8gMilcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2NlbnRlcic6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsZWZ0OiAoJGVsZURpbXMud2luZG93RGltcy5vZmZzZXQubGVmdCArICgkZWxlRGltcy53aW5kb3dEaW1zLndpZHRoIC8gMikpIC0gKCRlbGVEaW1zLndpZHRoIC8gMiksXG4gICAgICAgIHRvcDogKCRlbGVEaW1zLndpbmRvd0RpbXMub2Zmc2V0LnRvcCArICgkZWxlRGltcy53aW5kb3dEaW1zLmhlaWdodCAvIDIpKSAtICgkZWxlRGltcy5oZWlnaHQgLyAyKVxuICAgICAgfVxuICAgICAgYnJlYWs7XG4gICAgY2FzZSAncmV2ZWFsJzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxlZnQ6ICgkZWxlRGltcy53aW5kb3dEaW1zLndpZHRoIC0gJGVsZURpbXMud2lkdGgpIC8gMixcbiAgICAgICAgdG9wOiAkZWxlRGltcy53aW5kb3dEaW1zLm9mZnNldC50b3AgKyB2T2Zmc2V0XG4gICAgICB9XG4gICAgY2FzZSAncmV2ZWFsIGZ1bGwnOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogJGVsZURpbXMud2luZG93RGltcy5vZmZzZXQubGVmdCxcbiAgICAgICAgdG9wOiAkZWxlRGltcy53aW5kb3dEaW1zLm9mZnNldC50b3BcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2xlZnQgYm90dG9tJzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxlZnQ6ICRhbmNob3JEaW1zLm9mZnNldC5sZWZ0LFxuICAgICAgICB0b3A6ICRhbmNob3JEaW1zLm9mZnNldC50b3AgKyAkYW5jaG9yRGltcy5oZWlnaHQgKyB2T2Zmc2V0XG4gICAgICB9O1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAncmlnaHQgYm90dG9tJzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxlZnQ6ICRhbmNob3JEaW1zLm9mZnNldC5sZWZ0ICsgJGFuY2hvckRpbXMud2lkdGggKyBoT2Zmc2V0IC0gJGVsZURpbXMud2lkdGgsXG4gICAgICAgIHRvcDogJGFuY2hvckRpbXMub2Zmc2V0LnRvcCArICRhbmNob3JEaW1zLmhlaWdodCArIHZPZmZzZXRcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogKEZvdW5kYXRpb24ucnRsKCkgPyAkYW5jaG9yRGltcy5vZmZzZXQubGVmdCAtICRlbGVEaW1zLndpZHRoICsgJGFuY2hvckRpbXMud2lkdGggOiAkYW5jaG9yRGltcy5vZmZzZXQubGVmdCArIGhPZmZzZXQpLFxuICAgICAgICB0b3A6ICRhbmNob3JEaW1zLm9mZnNldC50b3AgKyAkYW5jaG9yRGltcy5oZWlnaHQgKyB2T2Zmc2V0XG4gICAgICB9XG4gIH1cbn1cblxufShqUXVlcnkpO1xuIiwiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAqXG4gKiBUaGlzIHV0aWwgd2FzIGNyZWF0ZWQgYnkgTWFyaXVzIE9sYmVydHogKlxuICogUGxlYXNlIHRoYW5rIE1hcml1cyBvbiBHaXRIdWIgL293bGJlcnR6ICpcbiAqIG9yIHRoZSB3ZWIgaHR0cDovL3d3dy5tYXJpdXNvbGJlcnR6LmRlLyAqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKlxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuJ3VzZSBzdHJpY3QnO1xuXG4hZnVuY3Rpb24oJCkge1xuXG5jb25zdCBrZXlDb2RlcyA9IHtcbiAgOTogJ1RBQicsXG4gIDEzOiAnRU5URVInLFxuICAyNzogJ0VTQ0FQRScsXG4gIDMyOiAnU1BBQ0UnLFxuICAzNzogJ0FSUk9XX0xFRlQnLFxuICAzODogJ0FSUk9XX1VQJyxcbiAgMzk6ICdBUlJPV19SSUdIVCcsXG4gIDQwOiAnQVJST1dfRE9XTidcbn1cblxudmFyIGNvbW1hbmRzID0ge31cblxudmFyIEtleWJvYXJkID0ge1xuICBrZXlzOiBnZXRLZXlDb2RlcyhrZXlDb2RlcyksXG5cbiAgLyoqXG4gICAqIFBhcnNlcyB0aGUgKGtleWJvYXJkKSBldmVudCBhbmQgcmV0dXJucyBhIFN0cmluZyB0aGF0IHJlcHJlc2VudHMgaXRzIGtleVxuICAgKiBDYW4gYmUgdXNlZCBsaWtlIEZvdW5kYXRpb24ucGFyc2VLZXkoZXZlbnQpID09PSBGb3VuZGF0aW9uLmtleXMuU1BBQ0VcbiAgICogQHBhcmFtIHtFdmVudH0gZXZlbnQgLSB0aGUgZXZlbnQgZ2VuZXJhdGVkIGJ5IHRoZSBldmVudCBoYW5kbGVyXG4gICAqIEByZXR1cm4gU3RyaW5nIGtleSAtIFN0cmluZyB0aGF0IHJlcHJlc2VudHMgdGhlIGtleSBwcmVzc2VkXG4gICAqL1xuICBwYXJzZUtleShldmVudCkge1xuICAgIHZhciBrZXkgPSBrZXlDb2Rlc1tldmVudC53aGljaCB8fCBldmVudC5rZXlDb2RlXSB8fCBTdHJpbmcuZnJvbUNoYXJDb2RlKGV2ZW50LndoaWNoKS50b1VwcGVyQ2FzZSgpO1xuXG4gICAgLy8gUmVtb3ZlIHVuLXByaW50YWJsZSBjaGFyYWN0ZXJzLCBlLmcuIGZvciBgZnJvbUNoYXJDb2RlYCBjYWxscyBmb3IgQ1RSTCBvbmx5IGV2ZW50c1xuICAgIGtleSA9IGtleS5yZXBsYWNlKC9cXFcrLywgJycpO1xuXG4gICAgaWYgKGV2ZW50LnNoaWZ0S2V5KSBrZXkgPSBgU0hJRlRfJHtrZXl9YDtcbiAgICBpZiAoZXZlbnQuY3RybEtleSkga2V5ID0gYENUUkxfJHtrZXl9YDtcbiAgICBpZiAoZXZlbnQuYWx0S2V5KSBrZXkgPSBgQUxUXyR7a2V5fWA7XG5cbiAgICAvLyBSZW1vdmUgdHJhaWxpbmcgdW5kZXJzY29yZSwgaW4gY2FzZSBvbmx5IG1vZGlmaWVycyB3ZXJlIHVzZWQgKGUuZy4gb25seSBgQ1RSTF9BTFRgKVxuICAgIGtleSA9IGtleS5yZXBsYWNlKC9fJC8sICcnKTtcblxuICAgIHJldHVybiBrZXk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEhhbmRsZXMgdGhlIGdpdmVuIChrZXlib2FyZCkgZXZlbnRcbiAgICogQHBhcmFtIHtFdmVudH0gZXZlbnQgLSB0aGUgZXZlbnQgZ2VuZXJhdGVkIGJ5IHRoZSBldmVudCBoYW5kbGVyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjb21wb25lbnQgLSBGb3VuZGF0aW9uIGNvbXBvbmVudCdzIG5hbWUsIGUuZy4gU2xpZGVyIG9yIFJldmVhbFxuICAgKiBAcGFyYW0ge09iamVjdHN9IGZ1bmN0aW9ucyAtIGNvbGxlY3Rpb24gb2YgZnVuY3Rpb25zIHRoYXQgYXJlIHRvIGJlIGV4ZWN1dGVkXG4gICAqL1xuICBoYW5kbGVLZXkoZXZlbnQsIGNvbXBvbmVudCwgZnVuY3Rpb25zKSB7XG4gICAgdmFyIGNvbW1hbmRMaXN0ID0gY29tbWFuZHNbY29tcG9uZW50XSxcbiAgICAgIGtleUNvZGUgPSB0aGlzLnBhcnNlS2V5KGV2ZW50KSxcbiAgICAgIGNtZHMsXG4gICAgICBjb21tYW5kLFxuICAgICAgZm47XG5cbiAgICBpZiAoIWNvbW1hbmRMaXN0KSByZXR1cm4gY29uc29sZS53YXJuKCdDb21wb25lbnQgbm90IGRlZmluZWQhJyk7XG5cbiAgICBpZiAodHlwZW9mIGNvbW1hbmRMaXN0Lmx0ciA9PT0gJ3VuZGVmaW5lZCcpIHsgLy8gdGhpcyBjb21wb25lbnQgZG9lcyBub3QgZGlmZmVyZW50aWF0ZSBiZXR3ZWVuIGx0ciBhbmQgcnRsXG4gICAgICAgIGNtZHMgPSBjb21tYW5kTGlzdDsgLy8gdXNlIHBsYWluIGxpc3RcbiAgICB9IGVsc2UgeyAvLyBtZXJnZSBsdHIgYW5kIHJ0bDogaWYgZG9jdW1lbnQgaXMgcnRsLCBydGwgb3ZlcndyaXRlcyBsdHIgYW5kIHZpY2UgdmVyc2FcbiAgICAgICAgaWYgKEZvdW5kYXRpb24ucnRsKCkpIGNtZHMgPSAkLmV4dGVuZCh7fSwgY29tbWFuZExpc3QubHRyLCBjb21tYW5kTGlzdC5ydGwpO1xuXG4gICAgICAgIGVsc2UgY21kcyA9ICQuZXh0ZW5kKHt9LCBjb21tYW5kTGlzdC5ydGwsIGNvbW1hbmRMaXN0Lmx0cik7XG4gICAgfVxuICAgIGNvbW1hbmQgPSBjbWRzW2tleUNvZGVdO1xuXG4gICAgZm4gPSBmdW5jdGlvbnNbY29tbWFuZF07XG4gICAgaWYgKGZuICYmIHR5cGVvZiBmbiA9PT0gJ2Z1bmN0aW9uJykgeyAvLyBleGVjdXRlIGZ1bmN0aW9uICBpZiBleGlzdHNcbiAgICAgIHZhciByZXR1cm5WYWx1ZSA9IGZuLmFwcGx5KCk7XG4gICAgICBpZiAoZnVuY3Rpb25zLmhhbmRsZWQgfHwgdHlwZW9mIGZ1bmN0aW9ucy5oYW5kbGVkID09PSAnZnVuY3Rpb24nKSB7IC8vIGV4ZWN1dGUgZnVuY3Rpb24gd2hlbiBldmVudCB3YXMgaGFuZGxlZFxuICAgICAgICAgIGZ1bmN0aW9ucy5oYW5kbGVkKHJldHVyblZhbHVlKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGZ1bmN0aW9ucy51bmhhbmRsZWQgfHwgdHlwZW9mIGZ1bmN0aW9ucy51bmhhbmRsZWQgPT09ICdmdW5jdGlvbicpIHsgLy8gZXhlY3V0ZSBmdW5jdGlvbiB3aGVuIGV2ZW50IHdhcyBub3QgaGFuZGxlZFxuICAgICAgICAgIGZ1bmN0aW9ucy51bmhhbmRsZWQoKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIEZpbmRzIGFsbCBmb2N1c2FibGUgZWxlbWVudHMgd2l0aGluIHRoZSBnaXZlbiBgJGVsZW1lbnRgXG4gICAqIEBwYXJhbSB7alF1ZXJ5fSAkZWxlbWVudCAtIGpRdWVyeSBvYmplY3QgdG8gc2VhcmNoIHdpdGhpblxuICAgKiBAcmV0dXJuIHtqUXVlcnl9ICRmb2N1c2FibGUgLSBhbGwgZm9jdXNhYmxlIGVsZW1lbnRzIHdpdGhpbiBgJGVsZW1lbnRgXG4gICAqL1xuICBmaW5kRm9jdXNhYmxlKCRlbGVtZW50KSB7XG4gICAgaWYoISRlbGVtZW50KSB7cmV0dXJuIGZhbHNlOyB9XG4gICAgcmV0dXJuICRlbGVtZW50LmZpbmQoJ2FbaHJlZl0sIGFyZWFbaHJlZl0sIGlucHV0Om5vdChbZGlzYWJsZWRdKSwgc2VsZWN0Om5vdChbZGlzYWJsZWRdKSwgdGV4dGFyZWE6bm90KFtkaXNhYmxlZF0pLCBidXR0b246bm90KFtkaXNhYmxlZF0pLCBpZnJhbWUsIG9iamVjdCwgZW1iZWQsICpbdGFiaW5kZXhdLCAqW2NvbnRlbnRlZGl0YWJsZV0nKS5maWx0ZXIoZnVuY3Rpb24oKSB7XG4gICAgICBpZiAoISQodGhpcykuaXMoJzp2aXNpYmxlJykgfHwgJCh0aGlzKS5hdHRyKCd0YWJpbmRleCcpIDwgMCkgeyByZXR1cm4gZmFsc2U7IH0gLy9vbmx5IGhhdmUgdmlzaWJsZSBlbGVtZW50cyBhbmQgdGhvc2UgdGhhdCBoYXZlIGEgdGFiaW5kZXggZ3JlYXRlciBvciBlcXVhbCAwXG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9KTtcbiAgfSxcblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgY29tcG9uZW50IG5hbWUgbmFtZVxuICAgKiBAcGFyYW0ge09iamVjdH0gY29tcG9uZW50IC0gRm91bmRhdGlvbiBjb21wb25lbnQsIGUuZy4gU2xpZGVyIG9yIFJldmVhbFxuICAgKiBAcmV0dXJuIFN0cmluZyBjb21wb25lbnROYW1lXG4gICAqL1xuXG4gIHJlZ2lzdGVyKGNvbXBvbmVudE5hbWUsIGNtZHMpIHtcbiAgICBjb21tYW5kc1tjb21wb25lbnROYW1lXSA9IGNtZHM7XG4gIH0sICBcblxuICAvKipcbiAgICogVHJhcHMgdGhlIGZvY3VzIGluIHRoZSBnaXZlbiBlbGVtZW50LlxuICAgKiBAcGFyYW0gIHtqUXVlcnl9ICRlbGVtZW50ICBqUXVlcnkgb2JqZWN0IHRvIHRyYXAgdGhlIGZvdWNzIGludG8uXG4gICAqL1xuICB0cmFwRm9jdXMoJGVsZW1lbnQpIHtcbiAgICB2YXIgJGZvY3VzYWJsZSA9IEZvdW5kYXRpb24uS2V5Ym9hcmQuZmluZEZvY3VzYWJsZSgkZWxlbWVudCksXG4gICAgICAgICRmaXJzdEZvY3VzYWJsZSA9ICRmb2N1c2FibGUuZXEoMCksXG4gICAgICAgICRsYXN0Rm9jdXNhYmxlID0gJGZvY3VzYWJsZS5lcSgtMSk7XG5cbiAgICAkZWxlbWVudC5vbigna2V5ZG93bi56Zi50cmFwZm9jdXMnLCBmdW5jdGlvbihldmVudCkge1xuICAgICAgaWYgKGV2ZW50LnRhcmdldCA9PT0gJGxhc3RGb2N1c2FibGVbMF0gJiYgRm91bmRhdGlvbi5LZXlib2FyZC5wYXJzZUtleShldmVudCkgPT09ICdUQUInKSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICRmaXJzdEZvY3VzYWJsZS5mb2N1cygpO1xuICAgICAgfVxuICAgICAgZWxzZSBpZiAoZXZlbnQudGFyZ2V0ID09PSAkZmlyc3RGb2N1c2FibGVbMF0gJiYgRm91bmRhdGlvbi5LZXlib2FyZC5wYXJzZUtleShldmVudCkgPT09ICdTSElGVF9UQUInKSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICRsYXN0Rm9jdXNhYmxlLmZvY3VzKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG4gIC8qKlxuICAgKiBSZWxlYXNlcyB0aGUgdHJhcHBlZCBmb2N1cyBmcm9tIHRoZSBnaXZlbiBlbGVtZW50LlxuICAgKiBAcGFyYW0gIHtqUXVlcnl9ICRlbGVtZW50ICBqUXVlcnkgb2JqZWN0IHRvIHJlbGVhc2UgdGhlIGZvY3VzIGZvci5cbiAgICovXG4gIHJlbGVhc2VGb2N1cygkZWxlbWVudCkge1xuICAgICRlbGVtZW50Lm9mZigna2V5ZG93bi56Zi50cmFwZm9jdXMnKTtcbiAgfVxufVxuXG4vKlxuICogQ29uc3RhbnRzIGZvciBlYXNpZXIgY29tcGFyaW5nLlxuICogQ2FuIGJlIHVzZWQgbGlrZSBGb3VuZGF0aW9uLnBhcnNlS2V5KGV2ZW50KSA9PT0gRm91bmRhdGlvbi5rZXlzLlNQQUNFXG4gKi9cbmZ1bmN0aW9uIGdldEtleUNvZGVzKGtjcykge1xuICB2YXIgayA9IHt9O1xuICBmb3IgKHZhciBrYyBpbiBrY3MpIGtba2NzW2tjXV0gPSBrY3Nba2NdO1xuICByZXR1cm4gaztcbn1cblxuRm91bmRhdGlvbi5LZXlib2FyZCA9IEtleWJvYXJkO1xuXG59KGpRdWVyeSk7XG4iLCIndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbi8vIERlZmF1bHQgc2V0IG9mIG1lZGlhIHF1ZXJpZXNcbmNvbnN0IGRlZmF1bHRRdWVyaWVzID0ge1xuICAnZGVmYXVsdCcgOiAnb25seSBzY3JlZW4nLFxuICBsYW5kc2NhcGUgOiAnb25seSBzY3JlZW4gYW5kIChvcmllbnRhdGlvbjogbGFuZHNjYXBlKScsXG4gIHBvcnRyYWl0IDogJ29ubHkgc2NyZWVuIGFuZCAob3JpZW50YXRpb246IHBvcnRyYWl0KScsXG4gIHJldGluYSA6ICdvbmx5IHNjcmVlbiBhbmQgKC13ZWJraXQtbWluLWRldmljZS1waXhlbC1yYXRpbzogMiksJyArXG4gICAgJ29ubHkgc2NyZWVuIGFuZCAobWluLS1tb3otZGV2aWNlLXBpeGVsLXJhdGlvOiAyKSwnICtcbiAgICAnb25seSBzY3JlZW4gYW5kICgtby1taW4tZGV2aWNlLXBpeGVsLXJhdGlvOiAyLzEpLCcgK1xuICAgICdvbmx5IHNjcmVlbiBhbmQgKG1pbi1kZXZpY2UtcGl4ZWwtcmF0aW86IDIpLCcgK1xuICAgICdvbmx5IHNjcmVlbiBhbmQgKG1pbi1yZXNvbHV0aW9uOiAxOTJkcGkpLCcgK1xuICAgICdvbmx5IHNjcmVlbiBhbmQgKG1pbi1yZXNvbHV0aW9uOiAyZHBweCknXG59O1xuXG52YXIgTWVkaWFRdWVyeSA9IHtcbiAgcXVlcmllczogW10sXG5cbiAgY3VycmVudDogJycsXG5cbiAgLyoqXG4gICAqIEluaXRpYWxpemVzIHRoZSBtZWRpYSBxdWVyeSBoZWxwZXIsIGJ5IGV4dHJhY3RpbmcgdGhlIGJyZWFrcG9pbnQgbGlzdCBmcm9tIHRoZSBDU1MgYW5kIGFjdGl2YXRpbmcgdGhlIGJyZWFrcG9pbnQgd2F0Y2hlci5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfaW5pdCgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIGV4dHJhY3RlZFN0eWxlcyA9ICQoJy5mb3VuZGF0aW9uLW1xJykuY3NzKCdmb250LWZhbWlseScpO1xuICAgIHZhciBuYW1lZFF1ZXJpZXM7XG5cbiAgICBuYW1lZFF1ZXJpZXMgPSBwYXJzZVN0eWxlVG9PYmplY3QoZXh0cmFjdGVkU3R5bGVzKTtcblxuICAgIGZvciAodmFyIGtleSBpbiBuYW1lZFF1ZXJpZXMpIHtcbiAgICAgIGlmKG5hbWVkUXVlcmllcy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICAgIHNlbGYucXVlcmllcy5wdXNoKHtcbiAgICAgICAgICBuYW1lOiBrZXksXG4gICAgICAgICAgdmFsdWU6IGBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogJHtuYW1lZFF1ZXJpZXNba2V5XX0pYFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICB0aGlzLmN1cnJlbnQgPSB0aGlzLl9nZXRDdXJyZW50U2l6ZSgpO1xuXG4gICAgdGhpcy5fd2F0Y2hlcigpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBDaGVja3MgaWYgdGhlIHNjcmVlbiBpcyBhdCBsZWFzdCBhcyB3aWRlIGFzIGEgYnJlYWtwb2ludC5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBzaXplIC0gTmFtZSBvZiB0aGUgYnJlYWtwb2ludCB0byBjaGVjay5cbiAgICogQHJldHVybnMge0Jvb2xlYW59IGB0cnVlYCBpZiB0aGUgYnJlYWtwb2ludCBtYXRjaGVzLCBgZmFsc2VgIGlmIGl0J3Mgc21hbGxlci5cbiAgICovXG4gIGF0TGVhc3Qoc2l6ZSkge1xuICAgIHZhciBxdWVyeSA9IHRoaXMuZ2V0KHNpemUpO1xuXG4gICAgaWYgKHF1ZXJ5KSB7XG4gICAgICByZXR1cm4gd2luZG93Lm1hdGNoTWVkaWEocXVlcnkpLm1hdGNoZXM7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9LFxuXG4gIC8qKlxuICAgKiBDaGVja3MgaWYgdGhlIHNjcmVlbiBtYXRjaGVzIHRvIGEgYnJlYWtwb2ludC5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBzaXplIC0gTmFtZSBvZiB0aGUgYnJlYWtwb2ludCB0byBjaGVjaywgZWl0aGVyICdzbWFsbCBvbmx5JyBvciAnc21hbGwnLiBPbWl0dGluZyAnb25seScgZmFsbHMgYmFjayB0byB1c2luZyBhdExlYXN0KCkgbWV0aG9kLlxuICAgKiBAcmV0dXJucyB7Qm9vbGVhbn0gYHRydWVgIGlmIHRoZSBicmVha3BvaW50IG1hdGNoZXMsIGBmYWxzZWAgaWYgaXQgZG9lcyBub3QuXG4gICAqL1xuICBpcyhzaXplKSB7XG4gICAgc2l6ZSA9IHNpemUudHJpbSgpLnNwbGl0KCcgJyk7XG4gICAgaWYoc2l6ZS5sZW5ndGggPiAxICYmIHNpemVbMV0gPT09ICdvbmx5Jykge1xuICAgICAgaWYoc2l6ZVswXSA9PT0gdGhpcy5fZ2V0Q3VycmVudFNpemUoKSkgcmV0dXJuIHRydWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB0aGlzLmF0TGVhc3Qoc2l6ZVswXSk7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfSxcblxuICAvKipcbiAgICogR2V0cyB0aGUgbWVkaWEgcXVlcnkgb2YgYSBicmVha3BvaW50LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHBhcmFtIHtTdHJpbmd9IHNpemUgLSBOYW1lIG9mIHRoZSBicmVha3BvaW50IHRvIGdldC5cbiAgICogQHJldHVybnMge1N0cmluZ3xudWxsfSAtIFRoZSBtZWRpYSBxdWVyeSBvZiB0aGUgYnJlYWtwb2ludCwgb3IgYG51bGxgIGlmIHRoZSBicmVha3BvaW50IGRvZXNuJ3QgZXhpc3QuXG4gICAqL1xuICBnZXQoc2l6ZSkge1xuICAgIGZvciAodmFyIGkgaW4gdGhpcy5xdWVyaWVzKSB7XG4gICAgICBpZih0aGlzLnF1ZXJpZXMuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgdmFyIHF1ZXJ5ID0gdGhpcy5xdWVyaWVzW2ldO1xuICAgICAgICBpZiAoc2l6ZSA9PT0gcXVlcnkubmFtZSkgcmV0dXJuIHF1ZXJ5LnZhbHVlO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBudWxsO1xuICB9LFxuXG4gIC8qKlxuICAgKiBHZXRzIHRoZSBjdXJyZW50IGJyZWFrcG9pbnQgbmFtZSBieSB0ZXN0aW5nIGV2ZXJ5IGJyZWFrcG9pbnQgYW5kIHJldHVybmluZyB0aGUgbGFzdCBvbmUgdG8gbWF0Y2ggKHRoZSBiaWdnZXN0IG9uZSkuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKiBAcmV0dXJucyB7U3RyaW5nfSBOYW1lIG9mIHRoZSBjdXJyZW50IGJyZWFrcG9pbnQuXG4gICAqL1xuICBfZ2V0Q3VycmVudFNpemUoKSB7XG4gICAgdmFyIG1hdGNoZWQ7XG5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMucXVlcmllcy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIHF1ZXJ5ID0gdGhpcy5xdWVyaWVzW2ldO1xuXG4gICAgICBpZiAod2luZG93Lm1hdGNoTWVkaWEocXVlcnkudmFsdWUpLm1hdGNoZXMpIHtcbiAgICAgICAgbWF0Y2hlZCA9IHF1ZXJ5O1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh0eXBlb2YgbWF0Y2hlZCA9PT0gJ29iamVjdCcpIHtcbiAgICAgIHJldHVybiBtYXRjaGVkLm5hbWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBtYXRjaGVkO1xuICAgIH1cbiAgfSxcblxuICAvKipcbiAgICogQWN0aXZhdGVzIHRoZSBicmVha3BvaW50IHdhdGNoZXIsIHdoaWNoIGZpcmVzIGFuIGV2ZW50IG9uIHRoZSB3aW5kb3cgd2hlbmV2ZXIgdGhlIGJyZWFrcG9pbnQgY2hhbmdlcy5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfd2F0Y2hlcigpIHtcbiAgICAkKHdpbmRvdykub24oJ3Jlc2l6ZS56Zi5tZWRpYXF1ZXJ5JywgKCkgPT4ge1xuICAgICAgdmFyIG5ld1NpemUgPSB0aGlzLl9nZXRDdXJyZW50U2l6ZSgpLCBjdXJyZW50U2l6ZSA9IHRoaXMuY3VycmVudDtcblxuICAgICAgaWYgKG5ld1NpemUgIT09IGN1cnJlbnRTaXplKSB7XG4gICAgICAgIC8vIENoYW5nZSB0aGUgY3VycmVudCBtZWRpYSBxdWVyeVxuICAgICAgICB0aGlzLmN1cnJlbnQgPSBuZXdTaXplO1xuXG4gICAgICAgIC8vIEJyb2FkY2FzdCB0aGUgbWVkaWEgcXVlcnkgY2hhbmdlIG9uIHRoZSB3aW5kb3dcbiAgICAgICAgJCh3aW5kb3cpLnRyaWdnZXIoJ2NoYW5nZWQuemYubWVkaWFxdWVyeScsIFtuZXdTaXplLCBjdXJyZW50U2l6ZV0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG59O1xuXG5Gb3VuZGF0aW9uLk1lZGlhUXVlcnkgPSBNZWRpYVF1ZXJ5O1xuXG4vLyBtYXRjaE1lZGlhKCkgcG9seWZpbGwgLSBUZXN0IGEgQ1NTIG1lZGlhIHR5cGUvcXVlcnkgaW4gSlMuXG4vLyBBdXRob3JzICYgY29weXJpZ2h0IChjKSAyMDEyOiBTY290dCBKZWhsLCBQYXVsIElyaXNoLCBOaWNob2xhcyBaYWthcywgRGF2aWQgS25pZ2h0LiBEdWFsIE1JVC9CU0QgbGljZW5zZVxud2luZG93Lm1hdGNoTWVkaWEgfHwgKHdpbmRvdy5tYXRjaE1lZGlhID0gZnVuY3Rpb24oKSB7XG4gICd1c2Ugc3RyaWN0JztcblxuICAvLyBGb3IgYnJvd3NlcnMgdGhhdCBzdXBwb3J0IG1hdGNoTWVkaXVtIGFwaSBzdWNoIGFzIElFIDkgYW5kIHdlYmtpdFxuICB2YXIgc3R5bGVNZWRpYSA9ICh3aW5kb3cuc3R5bGVNZWRpYSB8fCB3aW5kb3cubWVkaWEpO1xuXG4gIC8vIEZvciB0aG9zZSB0aGF0IGRvbid0IHN1cHBvcnQgbWF0Y2hNZWRpdW1cbiAgaWYgKCFzdHlsZU1lZGlhKSB7XG4gICAgdmFyIHN0eWxlICAgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzdHlsZScpLFxuICAgIHNjcmlwdCAgICAgID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ3NjcmlwdCcpWzBdLFxuICAgIGluZm8gICAgICAgID0gbnVsbDtcblxuICAgIHN0eWxlLnR5cGUgID0gJ3RleHQvY3NzJztcbiAgICBzdHlsZS5pZCAgICA9ICdtYXRjaG1lZGlhanMtdGVzdCc7XG5cbiAgICBzY3JpcHQgJiYgc2NyaXB0LnBhcmVudE5vZGUgJiYgc2NyaXB0LnBhcmVudE5vZGUuaW5zZXJ0QmVmb3JlKHN0eWxlLCBzY3JpcHQpO1xuXG4gICAgLy8gJ3N0eWxlLmN1cnJlbnRTdHlsZScgaXMgdXNlZCBieSBJRSA8PSA4IGFuZCAnd2luZG93LmdldENvbXB1dGVkU3R5bGUnIGZvciBhbGwgb3RoZXIgYnJvd3NlcnNcbiAgICBpbmZvID0gKCdnZXRDb21wdXRlZFN0eWxlJyBpbiB3aW5kb3cpICYmIHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKHN0eWxlLCBudWxsKSB8fCBzdHlsZS5jdXJyZW50U3R5bGU7XG5cbiAgICBzdHlsZU1lZGlhID0ge1xuICAgICAgbWF0Y2hNZWRpdW0obWVkaWEpIHtcbiAgICAgICAgdmFyIHRleHQgPSBgQG1lZGlhICR7bWVkaWF9eyAjbWF0Y2htZWRpYWpzLXRlc3QgeyB3aWR0aDogMXB4OyB9IH1gO1xuXG4gICAgICAgIC8vICdzdHlsZS5zdHlsZVNoZWV0JyBpcyB1c2VkIGJ5IElFIDw9IDggYW5kICdzdHlsZS50ZXh0Q29udGVudCcgZm9yIGFsbCBvdGhlciBicm93c2Vyc1xuICAgICAgICBpZiAoc3R5bGUuc3R5bGVTaGVldCkge1xuICAgICAgICAgIHN0eWxlLnN0eWxlU2hlZXQuY3NzVGV4dCA9IHRleHQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc3R5bGUudGV4dENvbnRlbnQgPSB0ZXh0O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVGVzdCBpZiBtZWRpYSBxdWVyeSBpcyB0cnVlIG9yIGZhbHNlXG4gICAgICAgIHJldHVybiBpbmZvLndpZHRoID09PSAnMXB4JztcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gZnVuY3Rpb24obWVkaWEpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbWF0Y2hlczogc3R5bGVNZWRpYS5tYXRjaE1lZGl1bShtZWRpYSB8fCAnYWxsJyksXG4gICAgICBtZWRpYTogbWVkaWEgfHwgJ2FsbCdcbiAgICB9O1xuICB9XG59KCkpO1xuXG4vLyBUaGFuayB5b3U6IGh0dHBzOi8vZ2l0aHViLmNvbS9zaW5kcmVzb3JodXMvcXVlcnktc3RyaW5nXG5mdW5jdGlvbiBwYXJzZVN0eWxlVG9PYmplY3Qoc3RyKSB7XG4gIHZhciBzdHlsZU9iamVjdCA9IHt9O1xuXG4gIGlmICh0eXBlb2Ygc3RyICE9PSAnc3RyaW5nJykge1xuICAgIHJldHVybiBzdHlsZU9iamVjdDtcbiAgfVxuXG4gIHN0ciA9IHN0ci50cmltKCkuc2xpY2UoMSwgLTEpOyAvLyBicm93c2VycyByZS1xdW90ZSBzdHJpbmcgc3R5bGUgdmFsdWVzXG5cbiAgaWYgKCFzdHIpIHtcbiAgICByZXR1cm4gc3R5bGVPYmplY3Q7XG4gIH1cblxuICBzdHlsZU9iamVjdCA9IHN0ci5zcGxpdCgnJicpLnJlZHVjZShmdW5jdGlvbihyZXQsIHBhcmFtKSB7XG4gICAgdmFyIHBhcnRzID0gcGFyYW0ucmVwbGFjZSgvXFwrL2csICcgJykuc3BsaXQoJz0nKTtcbiAgICB2YXIga2V5ID0gcGFydHNbMF07XG4gICAgdmFyIHZhbCA9IHBhcnRzWzFdO1xuICAgIGtleSA9IGRlY29kZVVSSUNvbXBvbmVudChrZXkpO1xuXG4gICAgLy8gbWlzc2luZyBgPWAgc2hvdWxkIGJlIGBudWxsYDpcbiAgICAvLyBodHRwOi8vdzMub3JnL1RSLzIwMTIvV0QtdXJsLTIwMTIwNTI0LyNjb2xsZWN0LXVybC1wYXJhbWV0ZXJzXG4gICAgdmFsID0gdmFsID09PSB1bmRlZmluZWQgPyBudWxsIDogZGVjb2RlVVJJQ29tcG9uZW50KHZhbCk7XG5cbiAgICBpZiAoIXJldC5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICByZXRba2V5XSA9IHZhbDtcbiAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkocmV0W2tleV0pKSB7XG4gICAgICByZXRba2V5XS5wdXNoKHZhbCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldFtrZXldID0gW3JldFtrZXldLCB2YWxdO1xuICAgIH1cbiAgICByZXR1cm4gcmV0O1xuICB9LCB7fSk7XG5cbiAgcmV0dXJuIHN0eWxlT2JqZWN0O1xufVxuXG5Gb3VuZGF0aW9uLk1lZGlhUXVlcnkgPSBNZWRpYVF1ZXJ5O1xuXG59KGpRdWVyeSk7XG4iLCIndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbi8qKlxuICogTW90aW9uIG1vZHVsZS5cbiAqIEBtb2R1bGUgZm91bmRhdGlvbi5tb3Rpb25cbiAqL1xuXG5jb25zdCBpbml0Q2xhc3NlcyAgID0gWydtdWktZW50ZXInLCAnbXVpLWxlYXZlJ107XG5jb25zdCBhY3RpdmVDbGFzc2VzID0gWydtdWktZW50ZXItYWN0aXZlJywgJ211aS1sZWF2ZS1hY3RpdmUnXTtcblxuY29uc3QgTW90aW9uID0ge1xuICBhbmltYXRlSW46IGZ1bmN0aW9uKGVsZW1lbnQsIGFuaW1hdGlvbiwgY2IpIHtcbiAgICBhbmltYXRlKHRydWUsIGVsZW1lbnQsIGFuaW1hdGlvbiwgY2IpO1xuICB9LFxuXG4gIGFuaW1hdGVPdXQ6IGZ1bmN0aW9uKGVsZW1lbnQsIGFuaW1hdGlvbiwgY2IpIHtcbiAgICBhbmltYXRlKGZhbHNlLCBlbGVtZW50LCBhbmltYXRpb24sIGNiKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBNb3ZlKGR1cmF0aW9uLCBlbGVtLCBmbil7XG4gIHZhciBhbmltLCBwcm9nLCBzdGFydCA9IG51bGw7XG4gIC8vIGNvbnNvbGUubG9nKCdjYWxsZWQnKTtcblxuICBpZiAoZHVyYXRpb24gPT09IDApIHtcbiAgICBmbi5hcHBseShlbGVtKTtcbiAgICBlbGVtLnRyaWdnZXIoJ2ZpbmlzaGVkLnpmLmFuaW1hdGUnLCBbZWxlbV0pLnRyaWdnZXJIYW5kbGVyKCdmaW5pc2hlZC56Zi5hbmltYXRlJywgW2VsZW1dKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBmdW5jdGlvbiBtb3ZlKHRzKXtcbiAgICBpZighc3RhcnQpIHN0YXJ0ID0gdHM7XG4gICAgLy8gY29uc29sZS5sb2coc3RhcnQsIHRzKTtcbiAgICBwcm9nID0gdHMgLSBzdGFydDtcbiAgICBmbi5hcHBseShlbGVtKTtcblxuICAgIGlmKHByb2cgPCBkdXJhdGlvbil7IGFuaW0gPSB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKG1vdmUsIGVsZW0pOyB9XG4gICAgZWxzZXtcbiAgICAgIHdpbmRvdy5jYW5jZWxBbmltYXRpb25GcmFtZShhbmltKTtcbiAgICAgIGVsZW0udHJpZ2dlcignZmluaXNoZWQuemYuYW5pbWF0ZScsIFtlbGVtXSkudHJpZ2dlckhhbmRsZXIoJ2ZpbmlzaGVkLnpmLmFuaW1hdGUnLCBbZWxlbV0pO1xuICAgIH1cbiAgfVxuICBhbmltID0gd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZShtb3ZlKTtcbn1cblxuLyoqXG4gKiBBbmltYXRlcyBhbiBlbGVtZW50IGluIG9yIG91dCB1c2luZyBhIENTUyB0cmFuc2l0aW9uIGNsYXNzLlxuICogQGZ1bmN0aW9uXG4gKiBAcHJpdmF0ZVxuICogQHBhcmFtIHtCb29sZWFufSBpc0luIC0gRGVmaW5lcyBpZiB0aGUgYW5pbWF0aW9uIGlzIGluIG9yIG91dC5cbiAqIEBwYXJhbSB7T2JqZWN0fSBlbGVtZW50IC0galF1ZXJ5IG9yIEhUTUwgb2JqZWN0IHRvIGFuaW1hdGUuXG4gKiBAcGFyYW0ge1N0cmluZ30gYW5pbWF0aW9uIC0gQ1NTIGNsYXNzIHRvIHVzZS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IGNiIC0gQ2FsbGJhY2sgdG8gcnVuIHdoZW4gYW5pbWF0aW9uIGlzIGZpbmlzaGVkLlxuICovXG5mdW5jdGlvbiBhbmltYXRlKGlzSW4sIGVsZW1lbnQsIGFuaW1hdGlvbiwgY2IpIHtcbiAgZWxlbWVudCA9ICQoZWxlbWVudCkuZXEoMCk7XG5cbiAgaWYgKCFlbGVtZW50Lmxlbmd0aCkgcmV0dXJuO1xuXG4gIHZhciBpbml0Q2xhc3MgPSBpc0luID8gaW5pdENsYXNzZXNbMF0gOiBpbml0Q2xhc3Nlc1sxXTtcbiAgdmFyIGFjdGl2ZUNsYXNzID0gaXNJbiA/IGFjdGl2ZUNsYXNzZXNbMF0gOiBhY3RpdmVDbGFzc2VzWzFdO1xuXG4gIC8vIFNldCB1cCB0aGUgYW5pbWF0aW9uXG4gIHJlc2V0KCk7XG5cbiAgZWxlbWVudFxuICAgIC5hZGRDbGFzcyhhbmltYXRpb24pXG4gICAgLmNzcygndHJhbnNpdGlvbicsICdub25lJyk7XG5cbiAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICBlbGVtZW50LmFkZENsYXNzKGluaXRDbGFzcyk7XG4gICAgaWYgKGlzSW4pIGVsZW1lbnQuc2hvdygpO1xuICB9KTtcblxuICAvLyBTdGFydCB0aGUgYW5pbWF0aW9uXG4gIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgZWxlbWVudFswXS5vZmZzZXRXaWR0aDtcbiAgICBlbGVtZW50XG4gICAgICAuY3NzKCd0cmFuc2l0aW9uJywgJycpXG4gICAgICAuYWRkQ2xhc3MoYWN0aXZlQ2xhc3MpO1xuICB9KTtcblxuICAvLyBDbGVhbiB1cCB0aGUgYW5pbWF0aW9uIHdoZW4gaXQgZmluaXNoZXNcbiAgZWxlbWVudC5vbmUoRm91bmRhdGlvbi50cmFuc2l0aW9uZW5kKGVsZW1lbnQpLCBmaW5pc2gpO1xuXG4gIC8vIEhpZGVzIHRoZSBlbGVtZW50IChmb3Igb3V0IGFuaW1hdGlvbnMpLCByZXNldHMgdGhlIGVsZW1lbnQsIGFuZCBydW5zIGEgY2FsbGJhY2tcbiAgZnVuY3Rpb24gZmluaXNoKCkge1xuICAgIGlmICghaXNJbikgZWxlbWVudC5oaWRlKCk7XG4gICAgcmVzZXQoKTtcbiAgICBpZiAoY2IpIGNiLmFwcGx5KGVsZW1lbnQpO1xuICB9XG5cbiAgLy8gUmVzZXRzIHRyYW5zaXRpb25zIGFuZCByZW1vdmVzIG1vdGlvbi1zcGVjaWZpYyBjbGFzc2VzXG4gIGZ1bmN0aW9uIHJlc2V0KCkge1xuICAgIGVsZW1lbnRbMF0uc3R5bGUudHJhbnNpdGlvbkR1cmF0aW9uID0gMDtcbiAgICBlbGVtZW50LnJlbW92ZUNsYXNzKGAke2luaXRDbGFzc30gJHthY3RpdmVDbGFzc30gJHthbmltYXRpb259YCk7XG4gIH1cbn1cblxuRm91bmRhdGlvbi5Nb3ZlID0gTW92ZTtcbkZvdW5kYXRpb24uTW90aW9uID0gTW90aW9uO1xuXG59KGpRdWVyeSk7XG4iLCIndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbmNvbnN0IE5lc3QgPSB7XG4gIEZlYXRoZXIobWVudSwgdHlwZSA9ICd6ZicpIHtcbiAgICBtZW51LmF0dHIoJ3JvbGUnLCAnbWVudWJhcicpO1xuXG4gICAgdmFyIGl0ZW1zID0gbWVudS5maW5kKCdsaScpLmF0dHIoeydyb2xlJzogJ21lbnVpdGVtJ30pLFxuICAgICAgICBzdWJNZW51Q2xhc3MgPSBgaXMtJHt0eXBlfS1zdWJtZW51YCxcbiAgICAgICAgc3ViSXRlbUNsYXNzID0gYCR7c3ViTWVudUNsYXNzfS1pdGVtYCxcbiAgICAgICAgaGFzU3ViQ2xhc3MgPSBgaXMtJHt0eXBlfS1zdWJtZW51LXBhcmVudGA7XG5cbiAgICBpdGVtcy5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgdmFyICRpdGVtID0gJCh0aGlzKSxcbiAgICAgICAgICAkc3ViID0gJGl0ZW0uY2hpbGRyZW4oJ3VsJyk7XG5cbiAgICAgIGlmICgkc3ViLmxlbmd0aCkge1xuICAgICAgICAkaXRlbVxuICAgICAgICAgIC5hZGRDbGFzcyhoYXNTdWJDbGFzcylcbiAgICAgICAgICAuYXR0cih7XG4gICAgICAgICAgICAnYXJpYS1oYXNwb3B1cCc6IHRydWUsXG4gICAgICAgICAgICAnYXJpYS1sYWJlbCc6ICRpdGVtLmNoaWxkcmVuKCdhOmZpcnN0JykudGV4dCgpXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgLy8gTm90ZTogIERyaWxsZG93bnMgYmVoYXZlIGRpZmZlcmVudGx5IGluIGhvdyB0aGV5IGhpZGUsIGFuZCBzbyBuZWVkXG4gICAgICAgICAgLy8gYWRkaXRpb25hbCBhdHRyaWJ1dGVzLiAgV2Ugc2hvdWxkIGxvb2sgaWYgdGhpcyBwb3NzaWJseSBvdmVyLWdlbmVyYWxpemVkXG4gICAgICAgICAgLy8gdXRpbGl0eSAoTmVzdCkgaXMgYXBwcm9wcmlhdGUgd2hlbiB3ZSByZXdvcmsgbWVudXMgaW4gNi40XG4gICAgICAgICAgaWYodHlwZSA9PT0gJ2RyaWxsZG93bicpIHtcbiAgICAgICAgICAgICRpdGVtLmF0dHIoeydhcmlhLWV4cGFuZGVkJzogZmFsc2V9KTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgJHN1YlxuICAgICAgICAgIC5hZGRDbGFzcyhgc3VibWVudSAke3N1Yk1lbnVDbGFzc31gKVxuICAgICAgICAgIC5hdHRyKHtcbiAgICAgICAgICAgICdkYXRhLXN1Ym1lbnUnOiAnJyxcbiAgICAgICAgICAgICdyb2xlJzogJ21lbnUnXG4gICAgICAgICAgfSk7XG4gICAgICAgIGlmKHR5cGUgPT09ICdkcmlsbGRvd24nKSB7XG4gICAgICAgICAgJHN1Yi5hdHRyKHsnYXJpYS1oaWRkZW4nOiB0cnVlfSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKCRpdGVtLnBhcmVudCgnW2RhdGEtc3VibWVudV0nKS5sZW5ndGgpIHtcbiAgICAgICAgJGl0ZW0uYWRkQ2xhc3MoYGlzLXN1Ym1lbnUtaXRlbSAke3N1Ykl0ZW1DbGFzc31gKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHJldHVybjtcbiAgfSxcblxuICBCdXJuKG1lbnUsIHR5cGUpIHtcbiAgICB2YXIgLy9pdGVtcyA9IG1lbnUuZmluZCgnbGknKSxcbiAgICAgICAgc3ViTWVudUNsYXNzID0gYGlzLSR7dHlwZX0tc3VibWVudWAsXG4gICAgICAgIHN1Ykl0ZW1DbGFzcyA9IGAke3N1Yk1lbnVDbGFzc30taXRlbWAsXG4gICAgICAgIGhhc1N1YkNsYXNzID0gYGlzLSR7dHlwZX0tc3VibWVudS1wYXJlbnRgO1xuXG4gICAgbWVudVxuICAgICAgLmZpbmQoJz5saSwgLm1lbnUsIC5tZW51ID4gbGknKVxuICAgICAgLnJlbW92ZUNsYXNzKGAke3N1Yk1lbnVDbGFzc30gJHtzdWJJdGVtQ2xhc3N9ICR7aGFzU3ViQ2xhc3N9IGlzLXN1Ym1lbnUtaXRlbSBzdWJtZW51IGlzLWFjdGl2ZWApXG4gICAgICAucmVtb3ZlQXR0cignZGF0YS1zdWJtZW51JykuY3NzKCdkaXNwbGF5JywgJycpO1xuXG4gICAgLy8gY29uc29sZS5sb2coICAgICAgbWVudS5maW5kKCcuJyArIHN1Yk1lbnVDbGFzcyArICcsIC4nICsgc3ViSXRlbUNsYXNzICsgJywgLmhhcy1zdWJtZW51LCAuaXMtc3VibWVudS1pdGVtLCAuc3VibWVudSwgW2RhdGEtc3VibWVudV0nKVxuICAgIC8vICAgICAgICAgICAucmVtb3ZlQ2xhc3Moc3ViTWVudUNsYXNzICsgJyAnICsgc3ViSXRlbUNsYXNzICsgJyBoYXMtc3VibWVudSBpcy1zdWJtZW51LWl0ZW0gc3VibWVudScpXG4gICAgLy8gICAgICAgICAgIC5yZW1vdmVBdHRyKCdkYXRhLXN1Ym1lbnUnKSk7XG4gICAgLy8gaXRlbXMuZWFjaChmdW5jdGlvbigpe1xuICAgIC8vICAgdmFyICRpdGVtID0gJCh0aGlzKSxcbiAgICAvLyAgICAgICAkc3ViID0gJGl0ZW0uY2hpbGRyZW4oJ3VsJyk7XG4gICAgLy8gICBpZigkaXRlbS5wYXJlbnQoJ1tkYXRhLXN1Ym1lbnVdJykubGVuZ3RoKXtcbiAgICAvLyAgICAgJGl0ZW0ucmVtb3ZlQ2xhc3MoJ2lzLXN1Ym1lbnUtaXRlbSAnICsgc3ViSXRlbUNsYXNzKTtcbiAgICAvLyAgIH1cbiAgICAvLyAgIGlmKCRzdWIubGVuZ3RoKXtcbiAgICAvLyAgICAgJGl0ZW0ucmVtb3ZlQ2xhc3MoJ2hhcy1zdWJtZW51Jyk7XG4gICAgLy8gICAgICRzdWIucmVtb3ZlQ2xhc3MoJ3N1Ym1lbnUgJyArIHN1Yk1lbnVDbGFzcykucmVtb3ZlQXR0cignZGF0YS1zdWJtZW51Jyk7XG4gICAgLy8gICB9XG4gICAgLy8gfSk7XG4gIH1cbn1cblxuRm91bmRhdGlvbi5OZXN0ID0gTmVzdDtcblxufShqUXVlcnkpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4hZnVuY3Rpb24oJCkge1xuXG5mdW5jdGlvbiBUaW1lcihlbGVtLCBvcHRpb25zLCBjYikge1xuICB2YXIgX3RoaXMgPSB0aGlzLFxuICAgICAgZHVyYXRpb24gPSBvcHRpb25zLmR1cmF0aW9uLC8vb3B0aW9ucyBpcyBhbiBvYmplY3QgZm9yIGVhc2lseSBhZGRpbmcgZmVhdHVyZXMgbGF0ZXIuXG4gICAgICBuYW1lU3BhY2UgPSBPYmplY3Qua2V5cyhlbGVtLmRhdGEoKSlbMF0gfHwgJ3RpbWVyJyxcbiAgICAgIHJlbWFpbiA9IC0xLFxuICAgICAgc3RhcnQsXG4gICAgICB0aW1lcjtcblxuICB0aGlzLmlzUGF1c2VkID0gZmFsc2U7XG5cbiAgdGhpcy5yZXN0YXJ0ID0gZnVuY3Rpb24oKSB7XG4gICAgcmVtYWluID0gLTE7XG4gICAgY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICB0aGlzLnN0YXJ0KCk7XG4gIH1cblxuICB0aGlzLnN0YXJ0ID0gZnVuY3Rpb24oKSB7XG4gICAgdGhpcy5pc1BhdXNlZCA9IGZhbHNlO1xuICAgIC8vIGlmKCFlbGVtLmRhdGEoJ3BhdXNlZCcpKXsgcmV0dXJuIGZhbHNlOyB9Ly9tYXliZSBpbXBsZW1lbnQgdGhpcyBzYW5pdHkgY2hlY2sgaWYgdXNlZCBmb3Igb3RoZXIgdGhpbmdzLlxuICAgIGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgcmVtYWluID0gcmVtYWluIDw9IDAgPyBkdXJhdGlvbiA6IHJlbWFpbjtcbiAgICBlbGVtLmRhdGEoJ3BhdXNlZCcsIGZhbHNlKTtcbiAgICBzdGFydCA9IERhdGUubm93KCk7XG4gICAgdGltZXIgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7XG4gICAgICBpZihvcHRpb25zLmluZmluaXRlKXtcbiAgICAgICAgX3RoaXMucmVzdGFydCgpOy8vcmVydW4gdGhlIHRpbWVyLlxuICAgICAgfVxuICAgICAgaWYgKGNiICYmIHR5cGVvZiBjYiA9PT0gJ2Z1bmN0aW9uJykgeyBjYigpOyB9XG4gICAgfSwgcmVtYWluKTtcbiAgICBlbGVtLnRyaWdnZXIoYHRpbWVyc3RhcnQuemYuJHtuYW1lU3BhY2V9YCk7XG4gIH1cblxuICB0aGlzLnBhdXNlID0gZnVuY3Rpb24oKSB7XG4gICAgdGhpcy5pc1BhdXNlZCA9IHRydWU7XG4gICAgLy9pZihlbGVtLmRhdGEoJ3BhdXNlZCcpKXsgcmV0dXJuIGZhbHNlOyB9Ly9tYXliZSBpbXBsZW1lbnQgdGhpcyBzYW5pdHkgY2hlY2sgaWYgdXNlZCBmb3Igb3RoZXIgdGhpbmdzLlxuICAgIGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgZWxlbS5kYXRhKCdwYXVzZWQnLCB0cnVlKTtcbiAgICB2YXIgZW5kID0gRGF0ZS5ub3coKTtcbiAgICByZW1haW4gPSByZW1haW4gLSAoZW5kIC0gc3RhcnQpO1xuICAgIGVsZW0udHJpZ2dlcihgdGltZXJwYXVzZWQuemYuJHtuYW1lU3BhY2V9YCk7XG4gIH1cbn1cblxuLyoqXG4gKiBSdW5zIGEgY2FsbGJhY2sgZnVuY3Rpb24gd2hlbiBpbWFnZXMgYXJlIGZ1bGx5IGxvYWRlZC5cbiAqIEBwYXJhbSB7T2JqZWN0fSBpbWFnZXMgLSBJbWFnZShzKSB0byBjaGVjayBpZiBsb2FkZWQuXG4gKiBAcGFyYW0ge0Z1bmN9IGNhbGxiYWNrIC0gRnVuY3Rpb24gdG8gZXhlY3V0ZSB3aGVuIGltYWdlIGlzIGZ1bGx5IGxvYWRlZC5cbiAqL1xuZnVuY3Rpb24gb25JbWFnZXNMb2FkZWQoaW1hZ2VzLCBjYWxsYmFjayl7XG4gIHZhciBzZWxmID0gdGhpcyxcbiAgICAgIHVubG9hZGVkID0gaW1hZ2VzLmxlbmd0aDtcblxuICBpZiAodW5sb2FkZWQgPT09IDApIHtcbiAgICBjYWxsYmFjaygpO1xuICB9XG5cbiAgaW1hZ2VzLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgLy8gQ2hlY2sgaWYgaW1hZ2UgaXMgbG9hZGVkXG4gICAgaWYgKHRoaXMuY29tcGxldGUgfHwgKHRoaXMucmVhZHlTdGF0ZSA9PT0gNCkgfHwgKHRoaXMucmVhZHlTdGF0ZSA9PT0gJ2NvbXBsZXRlJykpIHtcbiAgICAgIHNpbmdsZUltYWdlTG9hZGVkKCk7XG4gICAgfVxuICAgIC8vIEZvcmNlIGxvYWQgdGhlIGltYWdlXG4gICAgZWxzZSB7XG4gICAgICAvLyBmaXggZm9yIElFLiBTZWUgaHR0cHM6Ly9jc3MtdHJpY2tzLmNvbS9zbmlwcGV0cy9qcXVlcnkvZml4aW5nLWxvYWQtaW4taWUtZm9yLWNhY2hlZC1pbWFnZXMvXG4gICAgICB2YXIgc3JjID0gJCh0aGlzKS5hdHRyKCdzcmMnKTtcbiAgICAgICQodGhpcykuYXR0cignc3JjJywgc3JjICsgJz8nICsgKG5ldyBEYXRlKCkuZ2V0VGltZSgpKSk7XG4gICAgICAkKHRoaXMpLm9uZSgnbG9hZCcsIGZ1bmN0aW9uKCkge1xuICAgICAgICBzaW5nbGVJbWFnZUxvYWRlZCgpO1xuICAgICAgfSk7XG4gICAgfVxuICB9KTtcblxuICBmdW5jdGlvbiBzaW5nbGVJbWFnZUxvYWRlZCgpIHtcbiAgICB1bmxvYWRlZC0tO1xuICAgIGlmICh1bmxvYWRlZCA9PT0gMCkge1xuICAgICAgY2FsbGJhY2soKTtcbiAgICB9XG4gIH1cbn1cblxuRm91bmRhdGlvbi5UaW1lciA9IFRpbWVyO1xuRm91bmRhdGlvbi5vbkltYWdlc0xvYWRlZCA9IG9uSW1hZ2VzTG9hZGVkO1xuXG59KGpRdWVyeSk7XG4iLCIvLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4vLyoqV29yayBpbnNwaXJlZCBieSBtdWx0aXBsZSBqcXVlcnkgc3dpcGUgcGx1Z2lucyoqXG4vLyoqRG9uZSBieSBZb2hhaSBBcmFyYXQgKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4vLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4oZnVuY3Rpb24oJCkge1xuXG4gICQuc3BvdFN3aXBlID0ge1xuICAgIHZlcnNpb246ICcxLjAuMCcsXG4gICAgZW5hYmxlZDogJ29udG91Y2hzdGFydCcgaW4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LFxuICAgIHByZXZlbnREZWZhdWx0OiBmYWxzZSxcbiAgICBtb3ZlVGhyZXNob2xkOiA3NSxcbiAgICB0aW1lVGhyZXNob2xkOiAyMDBcbiAgfTtcblxuICB2YXIgICBzdGFydFBvc1gsXG4gICAgICAgIHN0YXJ0UG9zWSxcbiAgICAgICAgc3RhcnRUaW1lLFxuICAgICAgICBlbGFwc2VkVGltZSxcbiAgICAgICAgaXNNb3ZpbmcgPSBmYWxzZTtcblxuICBmdW5jdGlvbiBvblRvdWNoRW5kKCkge1xuICAgIC8vICBhbGVydCh0aGlzKTtcbiAgICB0aGlzLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3RvdWNobW92ZScsIG9uVG91Y2hNb3ZlKTtcbiAgICB0aGlzLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3RvdWNoZW5kJywgb25Ub3VjaEVuZCk7XG4gICAgaXNNb3ZpbmcgPSBmYWxzZTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uVG91Y2hNb3ZlKGUpIHtcbiAgICBpZiAoJC5zcG90U3dpcGUucHJldmVudERlZmF1bHQpIHsgZS5wcmV2ZW50RGVmYXVsdCgpOyB9XG4gICAgaWYoaXNNb3ZpbmcpIHtcbiAgICAgIHZhciB4ID0gZS50b3VjaGVzWzBdLnBhZ2VYO1xuICAgICAgdmFyIHkgPSBlLnRvdWNoZXNbMF0ucGFnZVk7XG4gICAgICB2YXIgZHggPSBzdGFydFBvc1ggLSB4O1xuICAgICAgdmFyIGR5ID0gc3RhcnRQb3NZIC0geTtcbiAgICAgIHZhciBkaXI7XG4gICAgICBlbGFwc2VkVGltZSA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpIC0gc3RhcnRUaW1lO1xuICAgICAgaWYoTWF0aC5hYnMoZHgpID49ICQuc3BvdFN3aXBlLm1vdmVUaHJlc2hvbGQgJiYgZWxhcHNlZFRpbWUgPD0gJC5zcG90U3dpcGUudGltZVRocmVzaG9sZCkge1xuICAgICAgICBkaXIgPSBkeCA+IDAgPyAnbGVmdCcgOiAncmlnaHQnO1xuICAgICAgfVxuICAgICAgLy8gZWxzZSBpZihNYXRoLmFicyhkeSkgPj0gJC5zcG90U3dpcGUubW92ZVRocmVzaG9sZCAmJiBlbGFwc2VkVGltZSA8PSAkLnNwb3RTd2lwZS50aW1lVGhyZXNob2xkKSB7XG4gICAgICAvLyAgIGRpciA9IGR5ID4gMCA/ICdkb3duJyA6ICd1cCc7XG4gICAgICAvLyB9XG4gICAgICBpZihkaXIpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBvblRvdWNoRW5kLmNhbGwodGhpcyk7XG4gICAgICAgICQodGhpcykudHJpZ2dlcignc3dpcGUnLCBkaXIpLnRyaWdnZXIoYHN3aXBlJHtkaXJ9YCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gb25Ub3VjaFN0YXJ0KGUpIHtcbiAgICBpZiAoZS50b3VjaGVzLmxlbmd0aCA9PSAxKSB7XG4gICAgICBzdGFydFBvc1ggPSBlLnRvdWNoZXNbMF0ucGFnZVg7XG4gICAgICBzdGFydFBvc1kgPSBlLnRvdWNoZXNbMF0ucGFnZVk7XG4gICAgICBpc01vdmluZyA9IHRydWU7XG4gICAgICBzdGFydFRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcbiAgICAgIHRoaXMuYWRkRXZlbnRMaXN0ZW5lcigndG91Y2htb3ZlJywgb25Ub3VjaE1vdmUsIGZhbHNlKTtcbiAgICAgIHRoaXMuYWRkRXZlbnRMaXN0ZW5lcigndG91Y2hlbmQnLCBvblRvdWNoRW5kLCBmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICB0aGlzLmFkZEV2ZW50TGlzdGVuZXIgJiYgdGhpcy5hZGRFdmVudExpc3RlbmVyKCd0b3VjaHN0YXJ0Jywgb25Ub3VjaFN0YXJ0LCBmYWxzZSk7XG4gIH1cblxuICBmdW5jdGlvbiB0ZWFyZG93bigpIHtcbiAgICB0aGlzLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3RvdWNoc3RhcnQnLCBvblRvdWNoU3RhcnQpO1xuICB9XG5cbiAgJC5ldmVudC5zcGVjaWFsLnN3aXBlID0geyBzZXR1cDogaW5pdCB9O1xuXG4gICQuZWFjaChbJ2xlZnQnLCAndXAnLCAnZG93bicsICdyaWdodCddLCBmdW5jdGlvbiAoKSB7XG4gICAgJC5ldmVudC5zcGVjaWFsW2Bzd2lwZSR7dGhpc31gXSA9IHsgc2V0dXA6IGZ1bmN0aW9uKCl7XG4gICAgICAkKHRoaXMpLm9uKCdzd2lwZScsICQubm9vcCk7XG4gICAgfSB9O1xuICB9KTtcbn0pKGpRdWVyeSk7XG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogTWV0aG9kIGZvciBhZGRpbmcgcHN1ZWRvIGRyYWcgZXZlbnRzIHRvIGVsZW1lbnRzICpcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4hZnVuY3Rpb24oJCl7XG4gICQuZm4uYWRkVG91Y2ggPSBmdW5jdGlvbigpe1xuICAgIHRoaXMuZWFjaChmdW5jdGlvbihpLGVsKXtcbiAgICAgICQoZWwpLmJpbmQoJ3RvdWNoc3RhcnQgdG91Y2htb3ZlIHRvdWNoZW5kIHRvdWNoY2FuY2VsJyxmdW5jdGlvbigpe1xuICAgICAgICAvL3dlIHBhc3MgdGhlIG9yaWdpbmFsIGV2ZW50IG9iamVjdCBiZWNhdXNlIHRoZSBqUXVlcnkgZXZlbnRcbiAgICAgICAgLy9vYmplY3QgaXMgbm9ybWFsaXplZCB0byB3M2Mgc3BlY3MgYW5kIGRvZXMgbm90IHByb3ZpZGUgdGhlIFRvdWNoTGlzdFxuICAgICAgICBoYW5kbGVUb3VjaChldmVudCk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIHZhciBoYW5kbGVUb3VjaCA9IGZ1bmN0aW9uKGV2ZW50KXtcbiAgICAgIHZhciB0b3VjaGVzID0gZXZlbnQuY2hhbmdlZFRvdWNoZXMsXG4gICAgICAgICAgZmlyc3QgPSB0b3VjaGVzWzBdLFxuICAgICAgICAgIGV2ZW50VHlwZXMgPSB7XG4gICAgICAgICAgICB0b3VjaHN0YXJ0OiAnbW91c2Vkb3duJyxcbiAgICAgICAgICAgIHRvdWNobW92ZTogJ21vdXNlbW92ZScsXG4gICAgICAgICAgICB0b3VjaGVuZDogJ21vdXNldXAnXG4gICAgICAgICAgfSxcbiAgICAgICAgICB0eXBlID0gZXZlbnRUeXBlc1tldmVudC50eXBlXSxcbiAgICAgICAgICBzaW11bGF0ZWRFdmVudFxuICAgICAgICA7XG5cbiAgICAgIGlmKCdNb3VzZUV2ZW50JyBpbiB3aW5kb3cgJiYgdHlwZW9mIHdpbmRvdy5Nb3VzZUV2ZW50ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHNpbXVsYXRlZEV2ZW50ID0gbmV3IHdpbmRvdy5Nb3VzZUV2ZW50KHR5cGUsIHtcbiAgICAgICAgICAnYnViYmxlcyc6IHRydWUsXG4gICAgICAgICAgJ2NhbmNlbGFibGUnOiB0cnVlLFxuICAgICAgICAgICdzY3JlZW5YJzogZmlyc3Quc2NyZWVuWCxcbiAgICAgICAgICAnc2NyZWVuWSc6IGZpcnN0LnNjcmVlblksXG4gICAgICAgICAgJ2NsaWVudFgnOiBmaXJzdC5jbGllbnRYLFxuICAgICAgICAgICdjbGllbnRZJzogZmlyc3QuY2xpZW50WVxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNpbXVsYXRlZEV2ZW50ID0gZG9jdW1lbnQuY3JlYXRlRXZlbnQoJ01vdXNlRXZlbnQnKTtcbiAgICAgICAgc2ltdWxhdGVkRXZlbnQuaW5pdE1vdXNlRXZlbnQodHlwZSwgdHJ1ZSwgdHJ1ZSwgd2luZG93LCAxLCBmaXJzdC5zY3JlZW5YLCBmaXJzdC5zY3JlZW5ZLCBmaXJzdC5jbGllbnRYLCBmaXJzdC5jbGllbnRZLCBmYWxzZSwgZmFsc2UsIGZhbHNlLCBmYWxzZSwgMC8qbGVmdCovLCBudWxsKTtcbiAgICAgIH1cbiAgICAgIGZpcnN0LnRhcmdldC5kaXNwYXRjaEV2ZW50KHNpbXVsYXRlZEV2ZW50KTtcbiAgICB9O1xuICB9O1xufShqUXVlcnkpO1xuXG5cbi8vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuLy8qKkZyb20gdGhlIGpRdWVyeSBNb2JpbGUgTGlicmFyeSoqXG4vLyoqbmVlZCB0byByZWNyZWF0ZSBmdW5jdGlvbmFsaXR5Kipcbi8vKiphbmQgdHJ5IHRvIGltcHJvdmUgaWYgcG9zc2libGUqKlxuLy8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG5cbi8qIFJlbW92aW5nIHRoZSBqUXVlcnkgZnVuY3Rpb24gKioqKlxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG5cbihmdW5jdGlvbiggJCwgd2luZG93LCB1bmRlZmluZWQgKSB7XG5cblx0dmFyICRkb2N1bWVudCA9ICQoIGRvY3VtZW50ICksXG5cdFx0Ly8gc3VwcG9ydFRvdWNoID0gJC5tb2JpbGUuc3VwcG9ydC50b3VjaCxcblx0XHR0b3VjaFN0YXJ0RXZlbnQgPSAndG91Y2hzdGFydCcvL3N1cHBvcnRUb3VjaCA/IFwidG91Y2hzdGFydFwiIDogXCJtb3VzZWRvd25cIixcblx0XHR0b3VjaFN0b3BFdmVudCA9ICd0b3VjaGVuZCcvL3N1cHBvcnRUb3VjaCA/IFwidG91Y2hlbmRcIiA6IFwibW91c2V1cFwiLFxuXHRcdHRvdWNoTW92ZUV2ZW50ID0gJ3RvdWNobW92ZScvL3N1cHBvcnRUb3VjaCA/IFwidG91Y2htb3ZlXCIgOiBcIm1vdXNlbW92ZVwiO1xuXG5cdC8vIHNldHVwIG5ldyBldmVudCBzaG9ydGN1dHNcblx0JC5lYWNoKCAoIFwidG91Y2hzdGFydCB0b3VjaG1vdmUgdG91Y2hlbmQgXCIgK1xuXHRcdFwic3dpcGUgc3dpcGVsZWZ0IHN3aXBlcmlnaHRcIiApLnNwbGl0KCBcIiBcIiApLCBmdW5jdGlvbiggaSwgbmFtZSApIHtcblxuXHRcdCQuZm5bIG5hbWUgXSA9IGZ1bmN0aW9uKCBmbiApIHtcblx0XHRcdHJldHVybiBmbiA/IHRoaXMuYmluZCggbmFtZSwgZm4gKSA6IHRoaXMudHJpZ2dlciggbmFtZSApO1xuXHRcdH07XG5cblx0XHQvLyBqUXVlcnkgPCAxLjhcblx0XHRpZiAoICQuYXR0ckZuICkge1xuXHRcdFx0JC5hdHRyRm5bIG5hbWUgXSA9IHRydWU7XG5cdFx0fVxuXHR9KTtcblxuXHRmdW5jdGlvbiB0cmlnZ2VyQ3VzdG9tRXZlbnQoIG9iaiwgZXZlbnRUeXBlLCBldmVudCwgYnViYmxlICkge1xuXHRcdHZhciBvcmlnaW5hbFR5cGUgPSBldmVudC50eXBlO1xuXHRcdGV2ZW50LnR5cGUgPSBldmVudFR5cGU7XG5cdFx0aWYgKCBidWJibGUgKSB7XG5cdFx0XHQkLmV2ZW50LnRyaWdnZXIoIGV2ZW50LCB1bmRlZmluZWQsIG9iaiApO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHQkLmV2ZW50LmRpc3BhdGNoLmNhbGwoIG9iaiwgZXZlbnQgKTtcblx0XHR9XG5cdFx0ZXZlbnQudHlwZSA9IG9yaWdpbmFsVHlwZTtcblx0fVxuXG5cdC8vIGFsc28gaGFuZGxlcyB0YXBob2xkXG5cblx0Ly8gQWxzbyBoYW5kbGVzIHN3aXBlbGVmdCwgc3dpcGVyaWdodFxuXHQkLmV2ZW50LnNwZWNpYWwuc3dpcGUgPSB7XG5cblx0XHQvLyBNb3JlIHRoYW4gdGhpcyBob3Jpem9udGFsIGRpc3BsYWNlbWVudCwgYW5kIHdlIHdpbGwgc3VwcHJlc3Mgc2Nyb2xsaW5nLlxuXHRcdHNjcm9sbFN1cHJlc3Npb25UaHJlc2hvbGQ6IDMwLFxuXG5cdFx0Ly8gTW9yZSB0aW1lIHRoYW4gdGhpcywgYW5kIGl0IGlzbid0IGEgc3dpcGUuXG5cdFx0ZHVyYXRpb25UaHJlc2hvbGQ6IDEwMDAsXG5cblx0XHQvLyBTd2lwZSBob3Jpem9udGFsIGRpc3BsYWNlbWVudCBtdXN0IGJlIG1vcmUgdGhhbiB0aGlzLlxuXHRcdGhvcml6b250YWxEaXN0YW5jZVRocmVzaG9sZDogd2luZG93LmRldmljZVBpeGVsUmF0aW8gPj0gMiA/IDE1IDogMzAsXG5cblx0XHQvLyBTd2lwZSB2ZXJ0aWNhbCBkaXNwbGFjZW1lbnQgbXVzdCBiZSBsZXNzIHRoYW4gdGhpcy5cblx0XHR2ZXJ0aWNhbERpc3RhbmNlVGhyZXNob2xkOiB3aW5kb3cuZGV2aWNlUGl4ZWxSYXRpbyA+PSAyID8gMTUgOiAzMCxcblxuXHRcdGdldExvY2F0aW9uOiBmdW5jdGlvbiAoIGV2ZW50ICkge1xuXHRcdFx0dmFyIHdpblBhZ2VYID0gd2luZG93LnBhZ2VYT2Zmc2V0LFxuXHRcdFx0XHR3aW5QYWdlWSA9IHdpbmRvdy5wYWdlWU9mZnNldCxcblx0XHRcdFx0eCA9IGV2ZW50LmNsaWVudFgsXG5cdFx0XHRcdHkgPSBldmVudC5jbGllbnRZO1xuXG5cdFx0XHRpZiAoIGV2ZW50LnBhZ2VZID09PSAwICYmIE1hdGguZmxvb3IoIHkgKSA+IE1hdGguZmxvb3IoIGV2ZW50LnBhZ2VZICkgfHxcblx0XHRcdFx0ZXZlbnQucGFnZVggPT09IDAgJiYgTWF0aC5mbG9vciggeCApID4gTWF0aC5mbG9vciggZXZlbnQucGFnZVggKSApIHtcblxuXHRcdFx0XHQvLyBpT1M0IGNsaWVudFgvY2xpZW50WSBoYXZlIHRoZSB2YWx1ZSB0aGF0IHNob3VsZCBoYXZlIGJlZW5cblx0XHRcdFx0Ly8gaW4gcGFnZVgvcGFnZVkuIFdoaWxlIHBhZ2VYL3BhZ2UvIGhhdmUgdGhlIHZhbHVlIDBcblx0XHRcdFx0eCA9IHggLSB3aW5QYWdlWDtcblx0XHRcdFx0eSA9IHkgLSB3aW5QYWdlWTtcblx0XHRcdH0gZWxzZSBpZiAoIHkgPCAoIGV2ZW50LnBhZ2VZIC0gd2luUGFnZVkpIHx8IHggPCAoIGV2ZW50LnBhZ2VYIC0gd2luUGFnZVggKSApIHtcblxuXHRcdFx0XHQvLyBTb21lIEFuZHJvaWQgYnJvd3NlcnMgaGF2ZSB0b3RhbGx5IGJvZ3VzIHZhbHVlcyBmb3IgY2xpZW50WC9ZXG5cdFx0XHRcdC8vIHdoZW4gc2Nyb2xsaW5nL3pvb21pbmcgYSBwYWdlLiBEZXRlY3RhYmxlIHNpbmNlIGNsaWVudFgvY2xpZW50WVxuXHRcdFx0XHQvLyBzaG91bGQgbmV2ZXIgYmUgc21hbGxlciB0aGFuIHBhZ2VYL3BhZ2VZIG1pbnVzIHBhZ2Ugc2Nyb2xsXG5cdFx0XHRcdHggPSBldmVudC5wYWdlWCAtIHdpblBhZ2VYO1xuXHRcdFx0XHR5ID0gZXZlbnQucGFnZVkgLSB3aW5QYWdlWTtcblx0XHRcdH1cblxuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0eDogeCxcblx0XHRcdFx0eTogeVxuXHRcdFx0fTtcblx0XHR9LFxuXG5cdFx0c3RhcnQ6IGZ1bmN0aW9uKCBldmVudCApIHtcblx0XHRcdHZhciBkYXRhID0gZXZlbnQub3JpZ2luYWxFdmVudC50b3VjaGVzID9cblx0XHRcdFx0XHRldmVudC5vcmlnaW5hbEV2ZW50LnRvdWNoZXNbIDAgXSA6IGV2ZW50LFxuXHRcdFx0XHRsb2NhdGlvbiA9ICQuZXZlbnQuc3BlY2lhbC5zd2lwZS5nZXRMb2NhdGlvbiggZGF0YSApO1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRcdHRpbWU6ICggbmV3IERhdGUoKSApLmdldFRpbWUoKSxcblx0XHRcdFx0XHRcdGNvb3JkczogWyBsb2NhdGlvbi54LCBsb2NhdGlvbi55IF0sXG5cdFx0XHRcdFx0XHRvcmlnaW46ICQoIGV2ZW50LnRhcmdldCApXG5cdFx0XHRcdFx0fTtcblx0XHR9LFxuXG5cdFx0c3RvcDogZnVuY3Rpb24oIGV2ZW50ICkge1xuXHRcdFx0dmFyIGRhdGEgPSBldmVudC5vcmlnaW5hbEV2ZW50LnRvdWNoZXMgP1xuXHRcdFx0XHRcdGV2ZW50Lm9yaWdpbmFsRXZlbnQudG91Y2hlc1sgMCBdIDogZXZlbnQsXG5cdFx0XHRcdGxvY2F0aW9uID0gJC5ldmVudC5zcGVjaWFsLnN3aXBlLmdldExvY2F0aW9uKCBkYXRhICk7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0dGltZTogKCBuZXcgRGF0ZSgpICkuZ2V0VGltZSgpLFxuXHRcdFx0XHRcdFx0Y29vcmRzOiBbIGxvY2F0aW9uLngsIGxvY2F0aW9uLnkgXVxuXHRcdFx0XHRcdH07XG5cdFx0fSxcblxuXHRcdGhhbmRsZVN3aXBlOiBmdW5jdGlvbiggc3RhcnQsIHN0b3AsIHRoaXNPYmplY3QsIG9yaWdUYXJnZXQgKSB7XG5cdFx0XHRpZiAoIHN0b3AudGltZSAtIHN0YXJ0LnRpbWUgPCAkLmV2ZW50LnNwZWNpYWwuc3dpcGUuZHVyYXRpb25UaHJlc2hvbGQgJiZcblx0XHRcdFx0TWF0aC5hYnMoIHN0YXJ0LmNvb3Jkc1sgMCBdIC0gc3RvcC5jb29yZHNbIDAgXSApID4gJC5ldmVudC5zcGVjaWFsLnN3aXBlLmhvcml6b250YWxEaXN0YW5jZVRocmVzaG9sZCAmJlxuXHRcdFx0XHRNYXRoLmFicyggc3RhcnQuY29vcmRzWyAxIF0gLSBzdG9wLmNvb3Jkc1sgMSBdICkgPCAkLmV2ZW50LnNwZWNpYWwuc3dpcGUudmVydGljYWxEaXN0YW5jZVRocmVzaG9sZCApIHtcblx0XHRcdFx0dmFyIGRpcmVjdGlvbiA9IHN0YXJ0LmNvb3Jkc1swXSA+IHN0b3AuY29vcmRzWyAwIF0gPyBcInN3aXBlbGVmdFwiIDogXCJzd2lwZXJpZ2h0XCI7XG5cblx0XHRcdFx0dHJpZ2dlckN1c3RvbUV2ZW50KCB0aGlzT2JqZWN0LCBcInN3aXBlXCIsICQuRXZlbnQoIFwic3dpcGVcIiwgeyB0YXJnZXQ6IG9yaWdUYXJnZXQsIHN3aXBlc3RhcnQ6IHN0YXJ0LCBzd2lwZXN0b3A6IHN0b3AgfSksIHRydWUgKTtcblx0XHRcdFx0dHJpZ2dlckN1c3RvbUV2ZW50KCB0aGlzT2JqZWN0LCBkaXJlY3Rpb24sJC5FdmVudCggZGlyZWN0aW9uLCB7IHRhcmdldDogb3JpZ1RhcmdldCwgc3dpcGVzdGFydDogc3RhcnQsIHN3aXBlc3RvcDogc3RvcCB9ICksIHRydWUgKTtcblx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cblx0XHR9LFxuXG5cdFx0Ly8gVGhpcyBzZXJ2ZXMgYXMgYSBmbGFnIHRvIGVuc3VyZSB0aGF0IGF0IG1vc3Qgb25lIHN3aXBlIGV2ZW50IGV2ZW50IGlzXG5cdFx0Ly8gaW4gd29yayBhdCBhbnkgZ2l2ZW4gdGltZVxuXHRcdGV2ZW50SW5Qcm9ncmVzczogZmFsc2UsXG5cblx0XHRzZXR1cDogZnVuY3Rpb24oKSB7XG5cdFx0XHR2YXIgZXZlbnRzLFxuXHRcdFx0XHR0aGlzT2JqZWN0ID0gdGhpcyxcblx0XHRcdFx0JHRoaXMgPSAkKCB0aGlzT2JqZWN0ICksXG5cdFx0XHRcdGNvbnRleHQgPSB7fTtcblxuXHRcdFx0Ly8gUmV0cmlldmUgdGhlIGV2ZW50cyBkYXRhIGZvciB0aGlzIGVsZW1lbnQgYW5kIGFkZCB0aGUgc3dpcGUgY29udGV4dFxuXHRcdFx0ZXZlbnRzID0gJC5kYXRhKCB0aGlzLCBcIm1vYmlsZS1ldmVudHNcIiApO1xuXHRcdFx0aWYgKCAhZXZlbnRzICkge1xuXHRcdFx0XHRldmVudHMgPSB7IGxlbmd0aDogMCB9O1xuXHRcdFx0XHQkLmRhdGEoIHRoaXMsIFwibW9iaWxlLWV2ZW50c1wiLCBldmVudHMgKTtcblx0XHRcdH1cblx0XHRcdGV2ZW50cy5sZW5ndGgrKztcblx0XHRcdGV2ZW50cy5zd2lwZSA9IGNvbnRleHQ7XG5cblx0XHRcdGNvbnRleHQuc3RhcnQgPSBmdW5jdGlvbiggZXZlbnQgKSB7XG5cblx0XHRcdFx0Ly8gQmFpbCBpZiB3ZSdyZSBhbHJlYWR5IHdvcmtpbmcgb24gYSBzd2lwZSBldmVudFxuXHRcdFx0XHRpZiAoICQuZXZlbnQuc3BlY2lhbC5zd2lwZS5ldmVudEluUHJvZ3Jlc3MgKSB7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHRcdCQuZXZlbnQuc3BlY2lhbC5zd2lwZS5ldmVudEluUHJvZ3Jlc3MgPSB0cnVlO1xuXG5cdFx0XHRcdHZhciBzdG9wLFxuXHRcdFx0XHRcdHN0YXJ0ID0gJC5ldmVudC5zcGVjaWFsLnN3aXBlLnN0YXJ0KCBldmVudCApLFxuXHRcdFx0XHRcdG9yaWdUYXJnZXQgPSBldmVudC50YXJnZXQsXG5cdFx0XHRcdFx0ZW1pdHRlZCA9IGZhbHNlO1xuXG5cdFx0XHRcdGNvbnRleHQubW92ZSA9IGZ1bmN0aW9uKCBldmVudCApIHtcblx0XHRcdFx0XHRpZiAoICFzdGFydCB8fCBldmVudC5pc0RlZmF1bHRQcmV2ZW50ZWQoKSApIHtcblx0XHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRzdG9wID0gJC5ldmVudC5zcGVjaWFsLnN3aXBlLnN0b3AoIGV2ZW50ICk7XG5cdFx0XHRcdFx0aWYgKCAhZW1pdHRlZCApIHtcblx0XHRcdFx0XHRcdGVtaXR0ZWQgPSAkLmV2ZW50LnNwZWNpYWwuc3dpcGUuaGFuZGxlU3dpcGUoIHN0YXJ0LCBzdG9wLCB0aGlzT2JqZWN0LCBvcmlnVGFyZ2V0ICk7XG5cdFx0XHRcdFx0XHRpZiAoIGVtaXR0ZWQgKSB7XG5cblx0XHRcdFx0XHRcdFx0Ly8gUmVzZXQgdGhlIGNvbnRleHQgdG8gbWFrZSB3YXkgZm9yIHRoZSBuZXh0IHN3aXBlIGV2ZW50XG5cdFx0XHRcdFx0XHRcdCQuZXZlbnQuc3BlY2lhbC5zd2lwZS5ldmVudEluUHJvZ3Jlc3MgPSBmYWxzZTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0Ly8gcHJldmVudCBzY3JvbGxpbmdcblx0XHRcdFx0XHRpZiAoIE1hdGguYWJzKCBzdGFydC5jb29yZHNbIDAgXSAtIHN0b3AuY29vcmRzWyAwIF0gKSA+ICQuZXZlbnQuc3BlY2lhbC5zd2lwZS5zY3JvbGxTdXByZXNzaW9uVGhyZXNob2xkICkge1xuXHRcdFx0XHRcdFx0ZXZlbnQucHJldmVudERlZmF1bHQoKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH07XG5cblx0XHRcdFx0Y29udGV4dC5zdG9wID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRcdFx0XHRlbWl0dGVkID0gdHJ1ZTtcblxuXHRcdFx0XHRcdFx0Ly8gUmVzZXQgdGhlIGNvbnRleHQgdG8gbWFrZSB3YXkgZm9yIHRoZSBuZXh0IHN3aXBlIGV2ZW50XG5cdFx0XHRcdFx0XHQkLmV2ZW50LnNwZWNpYWwuc3dpcGUuZXZlbnRJblByb2dyZXNzID0gZmFsc2U7XG5cdFx0XHRcdFx0XHQkZG9jdW1lbnQub2ZmKCB0b3VjaE1vdmVFdmVudCwgY29udGV4dC5tb3ZlICk7XG5cdFx0XHRcdFx0XHRjb250ZXh0Lm1vdmUgPSBudWxsO1xuXHRcdFx0XHR9O1xuXG5cdFx0XHRcdCRkb2N1bWVudC5vbiggdG91Y2hNb3ZlRXZlbnQsIGNvbnRleHQubW92ZSApXG5cdFx0XHRcdFx0Lm9uZSggdG91Y2hTdG9wRXZlbnQsIGNvbnRleHQuc3RvcCApO1xuXHRcdFx0fTtcblx0XHRcdCR0aGlzLm9uKCB0b3VjaFN0YXJ0RXZlbnQsIGNvbnRleHQuc3RhcnQgKTtcblx0XHR9LFxuXG5cdFx0dGVhcmRvd246IGZ1bmN0aW9uKCkge1xuXHRcdFx0dmFyIGV2ZW50cywgY29udGV4dDtcblxuXHRcdFx0ZXZlbnRzID0gJC5kYXRhKCB0aGlzLCBcIm1vYmlsZS1ldmVudHNcIiApO1xuXHRcdFx0aWYgKCBldmVudHMgKSB7XG5cdFx0XHRcdGNvbnRleHQgPSBldmVudHMuc3dpcGU7XG5cdFx0XHRcdGRlbGV0ZSBldmVudHMuc3dpcGU7XG5cdFx0XHRcdGV2ZW50cy5sZW5ndGgtLTtcblx0XHRcdFx0aWYgKCBldmVudHMubGVuZ3RoID09PSAwICkge1xuXHRcdFx0XHRcdCQucmVtb3ZlRGF0YSggdGhpcywgXCJtb2JpbGUtZXZlbnRzXCIgKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHRpZiAoIGNvbnRleHQgKSB7XG5cdFx0XHRcdGlmICggY29udGV4dC5zdGFydCApIHtcblx0XHRcdFx0XHQkKCB0aGlzICkub2ZmKCB0b3VjaFN0YXJ0RXZlbnQsIGNvbnRleHQuc3RhcnQgKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIGNvbnRleHQubW92ZSApIHtcblx0XHRcdFx0XHQkZG9jdW1lbnQub2ZmKCB0b3VjaE1vdmVFdmVudCwgY29udGV4dC5tb3ZlICk7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKCBjb250ZXh0LnN0b3AgKSB7XG5cdFx0XHRcdFx0JGRvY3VtZW50Lm9mZiggdG91Y2hTdG9wRXZlbnQsIGNvbnRleHQuc3RvcCApO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9O1xuXHQkLmVhY2goe1xuXHRcdHN3aXBlbGVmdDogXCJzd2lwZS5sZWZ0XCIsXG5cdFx0c3dpcGVyaWdodDogXCJzd2lwZS5yaWdodFwiXG5cdH0sIGZ1bmN0aW9uKCBldmVudCwgc291cmNlRXZlbnQgKSB7XG5cblx0XHQkLmV2ZW50LnNwZWNpYWxbIGV2ZW50IF0gPSB7XG5cdFx0XHRzZXR1cDogZnVuY3Rpb24oKSB7XG5cdFx0XHRcdCQoIHRoaXMgKS5iaW5kKCBzb3VyY2VFdmVudCwgJC5ub29wICk7XG5cdFx0XHR9LFxuXHRcdFx0dGVhcmRvd246IGZ1bmN0aW9uKCkge1xuXHRcdFx0XHQkKCB0aGlzICkudW5iaW5kKCBzb3VyY2VFdmVudCApO1xuXHRcdFx0fVxuXHRcdH07XG5cdH0pO1xufSkoIGpRdWVyeSwgdGhpcyApO1xuKi9cbiIsIid1c2Ugc3RyaWN0JztcblxuIWZ1bmN0aW9uKCQpIHtcblxuY29uc3QgTXV0YXRpb25PYnNlcnZlciA9IChmdW5jdGlvbiAoKSB7XG4gIHZhciBwcmVmaXhlcyA9IFsnV2ViS2l0JywgJ01veicsICdPJywgJ01zJywgJyddO1xuICBmb3IgKHZhciBpPTA7IGkgPCBwcmVmaXhlcy5sZW5ndGg7IGkrKykge1xuICAgIGlmIChgJHtwcmVmaXhlc1tpXX1NdXRhdGlvbk9ic2VydmVyYCBpbiB3aW5kb3cpIHtcbiAgICAgIHJldHVybiB3aW5kb3dbYCR7cHJlZml4ZXNbaV19TXV0YXRpb25PYnNlcnZlcmBdO1xuICAgIH1cbiAgfVxuICByZXR1cm4gZmFsc2U7XG59KCkpO1xuXG5jb25zdCB0cmlnZ2VycyA9IChlbCwgdHlwZSkgPT4ge1xuICBlbC5kYXRhKHR5cGUpLnNwbGl0KCcgJykuZm9yRWFjaChpZCA9PiB7XG4gICAgJChgIyR7aWR9YClbIHR5cGUgPT09ICdjbG9zZScgPyAndHJpZ2dlcicgOiAndHJpZ2dlckhhbmRsZXInXShgJHt0eXBlfS56Zi50cmlnZ2VyYCwgW2VsXSk7XG4gIH0pO1xufTtcbi8vIEVsZW1lbnRzIHdpdGggW2RhdGEtb3Blbl0gd2lsbCByZXZlYWwgYSBwbHVnaW4gdGhhdCBzdXBwb3J0cyBpdCB3aGVuIGNsaWNrZWQuXG4kKGRvY3VtZW50KS5vbignY2xpY2suemYudHJpZ2dlcicsICdbZGF0YS1vcGVuXScsIGZ1bmN0aW9uKCkge1xuICB0cmlnZ2VycygkKHRoaXMpLCAnb3BlbicpO1xufSk7XG5cbi8vIEVsZW1lbnRzIHdpdGggW2RhdGEtY2xvc2VdIHdpbGwgY2xvc2UgYSBwbHVnaW4gdGhhdCBzdXBwb3J0cyBpdCB3aGVuIGNsaWNrZWQuXG4vLyBJZiB1c2VkIHdpdGhvdXQgYSB2YWx1ZSBvbiBbZGF0YS1jbG9zZV0sIHRoZSBldmVudCB3aWxsIGJ1YmJsZSwgYWxsb3dpbmcgaXQgdG8gY2xvc2UgYSBwYXJlbnQgY29tcG9uZW50LlxuJChkb2N1bWVudCkub24oJ2NsaWNrLnpmLnRyaWdnZXInLCAnW2RhdGEtY2xvc2VdJywgZnVuY3Rpb24oKSB7XG4gIGxldCBpZCA9ICQodGhpcykuZGF0YSgnY2xvc2UnKTtcbiAgaWYgKGlkKSB7XG4gICAgdHJpZ2dlcnMoJCh0aGlzKSwgJ2Nsb3NlJyk7XG4gIH1cbiAgZWxzZSB7XG4gICAgJCh0aGlzKS50cmlnZ2VyKCdjbG9zZS56Zi50cmlnZ2VyJyk7XG4gIH1cbn0pO1xuXG4vLyBFbGVtZW50cyB3aXRoIFtkYXRhLXRvZ2dsZV0gd2lsbCB0b2dnbGUgYSBwbHVnaW4gdGhhdCBzdXBwb3J0cyBpdCB3aGVuIGNsaWNrZWQuXG4kKGRvY3VtZW50KS5vbignY2xpY2suemYudHJpZ2dlcicsICdbZGF0YS10b2dnbGVdJywgZnVuY3Rpb24oKSB7XG4gIGxldCBpZCA9ICQodGhpcykuZGF0YSgndG9nZ2xlJyk7XG4gIGlmIChpZCkge1xuICAgIHRyaWdnZXJzKCQodGhpcyksICd0b2dnbGUnKTtcbiAgfSBlbHNlIHtcbiAgICAkKHRoaXMpLnRyaWdnZXIoJ3RvZ2dsZS56Zi50cmlnZ2VyJyk7XG4gIH1cbn0pO1xuXG4vLyBFbGVtZW50cyB3aXRoIFtkYXRhLWNsb3NhYmxlXSB3aWxsIHJlc3BvbmQgdG8gY2xvc2UuemYudHJpZ2dlciBldmVudHMuXG4kKGRvY3VtZW50KS5vbignY2xvc2UuemYudHJpZ2dlcicsICdbZGF0YS1jbG9zYWJsZV0nLCBmdW5jdGlvbihlKXtcbiAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgbGV0IGFuaW1hdGlvbiA9ICQodGhpcykuZGF0YSgnY2xvc2FibGUnKTtcblxuICBpZihhbmltYXRpb24gIT09ICcnKXtcbiAgICBGb3VuZGF0aW9uLk1vdGlvbi5hbmltYXRlT3V0KCQodGhpcyksIGFuaW1hdGlvbiwgZnVuY3Rpb24oKSB7XG4gICAgICAkKHRoaXMpLnRyaWdnZXIoJ2Nsb3NlZC56ZicpO1xuICAgIH0pO1xuICB9ZWxzZXtcbiAgICAkKHRoaXMpLmZhZGVPdXQoKS50cmlnZ2VyKCdjbG9zZWQuemYnKTtcbiAgfVxufSk7XG5cbiQoZG9jdW1lbnQpLm9uKCdmb2N1cy56Zi50cmlnZ2VyIGJsdXIuemYudHJpZ2dlcicsICdbZGF0YS10b2dnbGUtZm9jdXNdJywgZnVuY3Rpb24oKSB7XG4gIGxldCBpZCA9ICQodGhpcykuZGF0YSgndG9nZ2xlLWZvY3VzJyk7XG4gICQoYCMke2lkfWApLnRyaWdnZXJIYW5kbGVyKCd0b2dnbGUuemYudHJpZ2dlcicsIFskKHRoaXMpXSk7XG59KTtcblxuLyoqXG4qIEZpcmVzIG9uY2UgYWZ0ZXIgYWxsIG90aGVyIHNjcmlwdHMgaGF2ZSBsb2FkZWRcbiogQGZ1bmN0aW9uXG4qIEBwcml2YXRlXG4qL1xuJCh3aW5kb3cpLm9uKCdsb2FkJywgKCkgPT4ge1xuICBjaGVja0xpc3RlbmVycygpO1xufSk7XG5cbmZ1bmN0aW9uIGNoZWNrTGlzdGVuZXJzKCkge1xuICBldmVudHNMaXN0ZW5lcigpO1xuICByZXNpemVMaXN0ZW5lcigpO1xuICBzY3JvbGxMaXN0ZW5lcigpO1xuICBtdXRhdGVMaXN0ZW5lcigpO1xuICBjbG9zZW1lTGlzdGVuZXIoKTtcbn1cblxuLy8qKioqKioqKiBvbmx5IGZpcmVzIHRoaXMgZnVuY3Rpb24gb25jZSBvbiBsb2FkLCBpZiB0aGVyZSdzIHNvbWV0aGluZyB0byB3YXRjaCAqKioqKioqKlxuZnVuY3Rpb24gY2xvc2VtZUxpc3RlbmVyKHBsdWdpbk5hbWUpIHtcbiAgdmFyIHlldGlCb3hlcyA9ICQoJ1tkYXRhLXlldGktYm94XScpLFxuICAgICAgcGx1Z05hbWVzID0gWydkcm9wZG93bicsICd0b29sdGlwJywgJ3JldmVhbCddO1xuXG4gIGlmKHBsdWdpbk5hbWUpe1xuICAgIGlmKHR5cGVvZiBwbHVnaW5OYW1lID09PSAnc3RyaW5nJyl7XG4gICAgICBwbHVnTmFtZXMucHVzaChwbHVnaW5OYW1lKTtcbiAgICB9ZWxzZSBpZih0eXBlb2YgcGx1Z2luTmFtZSA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIHBsdWdpbk5hbWVbMF0gPT09ICdzdHJpbmcnKXtcbiAgICAgIHBsdWdOYW1lcy5jb25jYXQocGx1Z2luTmFtZSk7XG4gICAgfWVsc2V7XG4gICAgICBjb25zb2xlLmVycm9yKCdQbHVnaW4gbmFtZXMgbXVzdCBiZSBzdHJpbmdzJyk7XG4gICAgfVxuICB9XG4gIGlmKHlldGlCb3hlcy5sZW5ndGgpe1xuICAgIGxldCBsaXN0ZW5lcnMgPSBwbHVnTmFtZXMubWFwKChuYW1lKSA9PiB7XG4gICAgICByZXR1cm4gYGNsb3NlbWUuemYuJHtuYW1lfWA7XG4gICAgfSkuam9pbignICcpO1xuXG4gICAgJCh3aW5kb3cpLm9mZihsaXN0ZW5lcnMpLm9uKGxpc3RlbmVycywgZnVuY3Rpb24oZSwgcGx1Z2luSWQpe1xuICAgICAgbGV0IHBsdWdpbiA9IGUubmFtZXNwYWNlLnNwbGl0KCcuJylbMF07XG4gICAgICBsZXQgcGx1Z2lucyA9ICQoYFtkYXRhLSR7cGx1Z2lufV1gKS5ub3QoYFtkYXRhLXlldGktYm94PVwiJHtwbHVnaW5JZH1cIl1gKTtcblxuICAgICAgcGx1Z2lucy5lYWNoKGZ1bmN0aW9uKCl7XG4gICAgICAgIGxldCBfdGhpcyA9ICQodGhpcyk7XG5cbiAgICAgICAgX3RoaXMudHJpZ2dlckhhbmRsZXIoJ2Nsb3NlLnpmLnRyaWdnZXInLCBbX3RoaXNdKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlc2l6ZUxpc3RlbmVyKGRlYm91bmNlKXtcbiAgbGV0IHRpbWVyLFxuICAgICAgJG5vZGVzID0gJCgnW2RhdGEtcmVzaXplXScpO1xuICBpZigkbm9kZXMubGVuZ3RoKXtcbiAgICAkKHdpbmRvdykub2ZmKCdyZXNpemUuemYudHJpZ2dlcicpXG4gICAgLm9uKCdyZXNpemUuemYudHJpZ2dlcicsIGZ1bmN0aW9uKGUpIHtcbiAgICAgIGlmICh0aW1lcikgeyBjbGVhclRpbWVvdXQodGltZXIpOyB9XG5cbiAgICAgIHRpbWVyID0gc2V0VGltZW91dChmdW5jdGlvbigpe1xuXG4gICAgICAgIGlmKCFNdXRhdGlvbk9ic2VydmVyKXsvL2ZhbGxiYWNrIGZvciBJRSA5XG4gICAgICAgICAgJG5vZGVzLmVhY2goZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICQodGhpcykudHJpZ2dlckhhbmRsZXIoJ3Jlc2l6ZW1lLnpmLnRyaWdnZXInKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICAvL3RyaWdnZXIgYWxsIGxpc3RlbmluZyBlbGVtZW50cyBhbmQgc2lnbmFsIGEgcmVzaXplIGV2ZW50XG4gICAgICAgICRub2Rlcy5hdHRyKCdkYXRhLWV2ZW50cycsIFwicmVzaXplXCIpO1xuICAgICAgfSwgZGVib3VuY2UgfHwgMTApOy8vZGVmYXVsdCB0aW1lIHRvIGVtaXQgcmVzaXplIGV2ZW50XG4gICAgfSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gc2Nyb2xsTGlzdGVuZXIoZGVib3VuY2Upe1xuICBsZXQgdGltZXIsXG4gICAgICAkbm9kZXMgPSAkKCdbZGF0YS1zY3JvbGxdJyk7XG4gIGlmKCRub2Rlcy5sZW5ndGgpe1xuICAgICQod2luZG93KS5vZmYoJ3Njcm9sbC56Zi50cmlnZ2VyJylcbiAgICAub24oJ3Njcm9sbC56Zi50cmlnZ2VyJywgZnVuY3Rpb24oZSl7XG4gICAgICBpZih0aW1lcil7IGNsZWFyVGltZW91dCh0aW1lcik7IH1cblxuICAgICAgdGltZXIgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7XG5cbiAgICAgICAgaWYoIU11dGF0aW9uT2JzZXJ2ZXIpey8vZmFsbGJhY2sgZm9yIElFIDlcbiAgICAgICAgICAkbm9kZXMuZWFjaChmdW5jdGlvbigpe1xuICAgICAgICAgICAgJCh0aGlzKS50cmlnZ2VySGFuZGxlcignc2Nyb2xsbWUuemYudHJpZ2dlcicpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIC8vdHJpZ2dlciBhbGwgbGlzdGVuaW5nIGVsZW1lbnRzIGFuZCBzaWduYWwgYSBzY3JvbGwgZXZlbnRcbiAgICAgICAgJG5vZGVzLmF0dHIoJ2RhdGEtZXZlbnRzJywgXCJzY3JvbGxcIik7XG4gICAgICB9LCBkZWJvdW5jZSB8fCAxMCk7Ly9kZWZhdWx0IHRpbWUgdG8gZW1pdCBzY3JvbGwgZXZlbnRcbiAgICB9KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBtdXRhdGVMaXN0ZW5lcihkZWJvdW5jZSkge1xuICAgIGxldCAkbm9kZXMgPSAkKCdbZGF0YS1tdXRhdGVdJyk7XG4gICAgaWYgKCRub2Rlcy5sZW5ndGggJiYgTXV0YXRpb25PYnNlcnZlcil7XG5cdFx0XHQvL3RyaWdnZXIgYWxsIGxpc3RlbmluZyBlbGVtZW50cyBhbmQgc2lnbmFsIGEgbXV0YXRlIGV2ZW50XG4gICAgICAvL25vIElFIDkgb3IgMTBcblx0XHRcdCRub2Rlcy5lYWNoKGZ1bmN0aW9uICgpIHtcblx0XHRcdCAgJCh0aGlzKS50cmlnZ2VySGFuZGxlcignbXV0YXRlbWUuemYudHJpZ2dlcicpO1xuXHRcdFx0fSk7XG4gICAgfVxuIH1cblxuZnVuY3Rpb24gZXZlbnRzTGlzdGVuZXIoKSB7XG4gIGlmKCFNdXRhdGlvbk9ic2VydmVyKXsgcmV0dXJuIGZhbHNlOyB9XG4gIGxldCBub2RlcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ1tkYXRhLXJlc2l6ZV0sIFtkYXRhLXNjcm9sbF0sIFtkYXRhLW11dGF0ZV0nKTtcblxuICAvL2VsZW1lbnQgY2FsbGJhY2tcbiAgdmFyIGxpc3RlbmluZ0VsZW1lbnRzTXV0YXRpb24gPSBmdW5jdGlvbiAobXV0YXRpb25SZWNvcmRzTGlzdCkge1xuICAgICAgdmFyICR0YXJnZXQgPSAkKG11dGF0aW9uUmVjb3Jkc0xpc3RbMF0udGFyZ2V0KTtcblxuXHQgIC8vdHJpZ2dlciB0aGUgZXZlbnQgaGFuZGxlciBmb3IgdGhlIGVsZW1lbnQgZGVwZW5kaW5nIG9uIHR5cGVcbiAgICAgIHN3aXRjaCAobXV0YXRpb25SZWNvcmRzTGlzdFswXS50eXBlKSB7XG5cbiAgICAgICAgY2FzZSBcImF0dHJpYnV0ZXNcIjpcbiAgICAgICAgICBpZiAoJHRhcmdldC5hdHRyKFwiZGF0YS1ldmVudHNcIikgPT09IFwic2Nyb2xsXCIgJiYgbXV0YXRpb25SZWNvcmRzTGlzdFswXS5hdHRyaWJ1dGVOYW1lID09PSBcImRhdGEtZXZlbnRzXCIpIHtcblx0XHQgIFx0JHRhcmdldC50cmlnZ2VySGFuZGxlcignc2Nyb2xsbWUuemYudHJpZ2dlcicsIFskdGFyZ2V0LCB3aW5kb3cucGFnZVlPZmZzZXRdKTtcblx0XHQgIH1cblx0XHQgIGlmICgkdGFyZ2V0LmF0dHIoXCJkYXRhLWV2ZW50c1wiKSA9PT0gXCJyZXNpemVcIiAmJiBtdXRhdGlvblJlY29yZHNMaXN0WzBdLmF0dHJpYnV0ZU5hbWUgPT09IFwiZGF0YS1ldmVudHNcIikge1xuXHRcdCAgXHQkdGFyZ2V0LnRyaWdnZXJIYW5kbGVyKCdyZXNpemVtZS56Zi50cmlnZ2VyJywgWyR0YXJnZXRdKTtcblx0XHQgICB9XG5cdFx0ICBpZiAobXV0YXRpb25SZWNvcmRzTGlzdFswXS5hdHRyaWJ1dGVOYW1lID09PSBcInN0eWxlXCIpIHtcblx0XHRcdCAgJHRhcmdldC5jbG9zZXN0KFwiW2RhdGEtbXV0YXRlXVwiKS5hdHRyKFwiZGF0YS1ldmVudHNcIixcIm11dGF0ZVwiKTtcblx0XHRcdCAgJHRhcmdldC5jbG9zZXN0KFwiW2RhdGEtbXV0YXRlXVwiKS50cmlnZ2VySGFuZGxlcignbXV0YXRlbWUuemYudHJpZ2dlcicsIFskdGFyZ2V0LmNsb3Nlc3QoXCJbZGF0YS1tdXRhdGVdXCIpXSk7XG5cdFx0ICB9XG5cdFx0ICBicmVhaztcblxuICAgICAgICBjYXNlIFwiY2hpbGRMaXN0XCI6XG5cdFx0ICAkdGFyZ2V0LmNsb3Nlc3QoXCJbZGF0YS1tdXRhdGVdXCIpLmF0dHIoXCJkYXRhLWV2ZW50c1wiLFwibXV0YXRlXCIpO1xuXHRcdCAgJHRhcmdldC5jbG9zZXN0KFwiW2RhdGEtbXV0YXRlXVwiKS50cmlnZ2VySGFuZGxlcignbXV0YXRlbWUuemYudHJpZ2dlcicsIFskdGFyZ2V0LmNsb3Nlc3QoXCJbZGF0YS1tdXRhdGVdXCIpXSk7XG4gICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIC8vbm90aGluZ1xuICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAobm9kZXMubGVuZ3RoKSB7XG4gICAgICAvL2ZvciBlYWNoIGVsZW1lbnQgdGhhdCBuZWVkcyB0byBsaXN0ZW4gZm9yIHJlc2l6aW5nLCBzY3JvbGxpbmcsIG9yIG11dGF0aW9uIGFkZCBhIHNpbmdsZSBvYnNlcnZlclxuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPD0gbm9kZXMubGVuZ3RoIC0gMTsgaSsrKSB7XG4gICAgICAgIHZhciBlbGVtZW50T2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcihsaXN0ZW5pbmdFbGVtZW50c011dGF0aW9uKTtcbiAgICAgICAgZWxlbWVudE9ic2VydmVyLm9ic2VydmUobm9kZXNbaV0sIHsgYXR0cmlidXRlczogdHJ1ZSwgY2hpbGRMaXN0OiB0cnVlLCBjaGFyYWN0ZXJEYXRhOiBmYWxzZSwgc3VidHJlZTogdHJ1ZSwgYXR0cmlidXRlRmlsdGVyOiBbXCJkYXRhLWV2ZW50c1wiLCBcInN0eWxlXCJdIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLy8gW1BIXVxuLy8gRm91bmRhdGlvbi5DaGVja1dhdGNoZXJzID0gY2hlY2tXYXRjaGVycztcbkZvdW5kYXRpb24uSUhlYXJZb3UgPSBjaGVja0xpc3RlbmVycztcbi8vIEZvdW5kYXRpb24uSVNlZVlvdSA9IHNjcm9sbExpc3RlbmVyO1xuLy8gRm91bmRhdGlvbi5JRmVlbFlvdSA9IGNsb3NlbWVMaXN0ZW5lcjtcblxufShqUXVlcnkpO1xuXG4vLyBmdW5jdGlvbiBkb21NdXRhdGlvbk9ic2VydmVyKGRlYm91bmNlKSB7XG4vLyAgIC8vICEhISBUaGlzIGlzIGNvbWluZyBzb29uIGFuZCBuZWVkcyBtb3JlIHdvcms7IG5vdCBhY3RpdmUgICEhISAvL1xuLy8gICB2YXIgdGltZXIsXG4vLyAgIG5vZGVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnW2RhdGEtbXV0YXRlXScpO1xuLy8gICAvL1xuLy8gICBpZiAobm9kZXMubGVuZ3RoKSB7XG4vLyAgICAgLy8gdmFyIE11dGF0aW9uT2JzZXJ2ZXIgPSAoZnVuY3Rpb24gKCkge1xuLy8gICAgIC8vICAgdmFyIHByZWZpeGVzID0gWydXZWJLaXQnLCAnTW96JywgJ08nLCAnTXMnLCAnJ107XG4vLyAgICAgLy8gICBmb3IgKHZhciBpPTA7IGkgPCBwcmVmaXhlcy5sZW5ndGg7IGkrKykge1xuLy8gICAgIC8vICAgICBpZiAocHJlZml4ZXNbaV0gKyAnTXV0YXRpb25PYnNlcnZlcicgaW4gd2luZG93KSB7XG4vLyAgICAgLy8gICAgICAgcmV0dXJuIHdpbmRvd1twcmVmaXhlc1tpXSArICdNdXRhdGlvbk9ic2VydmVyJ107XG4vLyAgICAgLy8gICAgIH1cbi8vICAgICAvLyAgIH1cbi8vICAgICAvLyAgIHJldHVybiBmYWxzZTtcbi8vICAgICAvLyB9KCkpO1xuLy9cbi8vXG4vLyAgICAgLy9mb3IgdGhlIGJvZHksIHdlIG5lZWQgdG8gbGlzdGVuIGZvciBhbGwgY2hhbmdlcyBlZmZlY3RpbmcgdGhlIHN0eWxlIGFuZCBjbGFzcyBhdHRyaWJ1dGVzXG4vLyAgICAgdmFyIGJvZHlPYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGJvZHlNdXRhdGlvbik7XG4vLyAgICAgYm9keU9ic2VydmVyLm9ic2VydmUoZG9jdW1lbnQuYm9keSwgeyBhdHRyaWJ1dGVzOiB0cnVlLCBjaGlsZExpc3Q6IHRydWUsIGNoYXJhY3RlckRhdGE6IGZhbHNlLCBzdWJ0cmVlOnRydWUsIGF0dHJpYnV0ZUZpbHRlcjpbXCJzdHlsZVwiLCBcImNsYXNzXCJdfSk7XG4vL1xuLy9cbi8vICAgICAvL2JvZHkgY2FsbGJhY2tcbi8vICAgICBmdW5jdGlvbiBib2R5TXV0YXRpb24obXV0YXRlKSB7XG4vLyAgICAgICAvL3RyaWdnZXIgYWxsIGxpc3RlbmluZyBlbGVtZW50cyBhbmQgc2lnbmFsIGEgbXV0YXRpb24gZXZlbnRcbi8vICAgICAgIGlmICh0aW1lcikgeyBjbGVhclRpbWVvdXQodGltZXIpOyB9XG4vL1xuLy8gICAgICAgdGltZXIgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuLy8gICAgICAgICBib2R5T2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuLy8gICAgICAgICAkKCdbZGF0YS1tdXRhdGVdJykuYXR0cignZGF0YS1ldmVudHMnLFwibXV0YXRlXCIpO1xuLy8gICAgICAgfSwgZGVib3VuY2UgfHwgMTUwKTtcbi8vICAgICB9XG4vLyAgIH1cbi8vIH1cbiIsIid1c2Ugc3RyaWN0JztcblxuIWZ1bmN0aW9uKCQpIHtcblxuLyoqXG4gKiBBY2NvcmRpb25NZW51IG1vZHVsZS5cbiAqIEBtb2R1bGUgZm91bmRhdGlvbi5hY2NvcmRpb25NZW51XG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLmtleWJvYXJkXG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLm1vdGlvblxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC5uZXN0XG4gKi9cblxuY2xhc3MgQWNjb3JkaW9uTWVudSB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IGluc3RhbmNlIG9mIGFuIGFjY29yZGlvbiBtZW51LlxuICAgKiBAY2xhc3NcbiAgICogQGZpcmVzIEFjY29yZGlvbk1lbnUjaW5pdFxuICAgKiBAcGFyYW0ge2pRdWVyeX0gZWxlbWVudCAtIGpRdWVyeSBvYmplY3QgdG8gbWFrZSBpbnRvIGFuIGFjY29yZGlvbiBtZW51LlxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyAtIE92ZXJyaWRlcyB0byB0aGUgZGVmYXVsdCBwbHVnaW4gc2V0dGluZ3MuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihlbGVtZW50LCBvcHRpb25zKSB7XG4gICAgdGhpcy4kZWxlbWVudCA9IGVsZW1lbnQ7XG4gICAgdGhpcy5vcHRpb25zID0gJC5leHRlbmQoe30sIEFjY29yZGlvbk1lbnUuZGVmYXVsdHMsIHRoaXMuJGVsZW1lbnQuZGF0YSgpLCBvcHRpb25zKTtcblxuICAgIEZvdW5kYXRpb24uTmVzdC5GZWF0aGVyKHRoaXMuJGVsZW1lbnQsICdhY2NvcmRpb24nKTtcblxuICAgIHRoaXMuX2luaXQoKTtcblxuICAgIEZvdW5kYXRpb24ucmVnaXN0ZXJQbHVnaW4odGhpcywgJ0FjY29yZGlvbk1lbnUnKTtcbiAgICBGb3VuZGF0aW9uLktleWJvYXJkLnJlZ2lzdGVyKCdBY2NvcmRpb25NZW51Jywge1xuICAgICAgJ0VOVEVSJzogJ3RvZ2dsZScsXG4gICAgICAnU1BBQ0UnOiAndG9nZ2xlJyxcbiAgICAgICdBUlJPV19SSUdIVCc6ICdvcGVuJyxcbiAgICAgICdBUlJPV19VUCc6ICd1cCcsXG4gICAgICAnQVJST1dfRE9XTic6ICdkb3duJyxcbiAgICAgICdBUlJPV19MRUZUJzogJ2Nsb3NlJyxcbiAgICAgICdFU0NBUEUnOiAnY2xvc2VBbGwnXG4gICAgfSk7XG4gIH1cblxuXG5cbiAgLyoqXG4gICAqIEluaXRpYWxpemVzIHRoZSBhY2NvcmRpb24gbWVudSBieSBoaWRpbmcgYWxsIG5lc3RlZCBtZW51cy5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9pbml0KCkge1xuICAgIHRoaXMuJGVsZW1lbnQuZmluZCgnW2RhdGEtc3VibWVudV0nKS5ub3QoJy5pcy1hY3RpdmUnKS5zbGlkZVVwKDApOy8vLmZpbmQoJ2EnKS5jc3MoJ3BhZGRpbmctbGVmdCcsICcxcmVtJyk7XG4gICAgdGhpcy4kZWxlbWVudC5hdHRyKHtcbiAgICAgICdyb2xlJzogJ21lbnUnLFxuICAgICAgJ2FyaWEtbXVsdGlzZWxlY3RhYmxlJzogdGhpcy5vcHRpb25zLm11bHRpT3BlblxuICAgIH0pO1xuXG4gICAgdGhpcy4kbWVudUxpbmtzID0gdGhpcy4kZWxlbWVudC5maW5kKCcuaXMtYWNjb3JkaW9uLXN1Ym1lbnUtcGFyZW50Jyk7XG4gICAgdGhpcy4kbWVudUxpbmtzLmVhY2goZnVuY3Rpb24oKXtcbiAgICAgIHZhciBsaW5rSWQgPSB0aGlzLmlkIHx8IEZvdW5kYXRpb24uR2V0WW9EaWdpdHMoNiwgJ2FjYy1tZW51LWxpbmsnKSxcbiAgICAgICAgICAkZWxlbSA9ICQodGhpcyksXG4gICAgICAgICAgJHN1YiA9ICRlbGVtLmNoaWxkcmVuKCdbZGF0YS1zdWJtZW51XScpLFxuICAgICAgICAgIHN1YklkID0gJHN1YlswXS5pZCB8fCBGb3VuZGF0aW9uLkdldFlvRGlnaXRzKDYsICdhY2MtbWVudScpLFxuICAgICAgICAgIGlzQWN0aXZlID0gJHN1Yi5oYXNDbGFzcygnaXMtYWN0aXZlJyk7XG4gICAgICAkZWxlbS5hdHRyKHtcbiAgICAgICAgJ2FyaWEtY29udHJvbHMnOiBzdWJJZCxcbiAgICAgICAgJ2FyaWEtZXhwYW5kZWQnOiBpc0FjdGl2ZSxcbiAgICAgICAgJ3JvbGUnOiAnbWVudWl0ZW0nLFxuICAgICAgICAnaWQnOiBsaW5rSWRcbiAgICAgIH0pO1xuICAgICAgJHN1Yi5hdHRyKHtcbiAgICAgICAgJ2FyaWEtbGFiZWxsZWRieSc6IGxpbmtJZCxcbiAgICAgICAgJ2FyaWEtaGlkZGVuJzogIWlzQWN0aXZlLFxuICAgICAgICAncm9sZSc6ICdtZW51JyxcbiAgICAgICAgJ2lkJzogc3ViSWRcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIHZhciBpbml0UGFuZXMgPSB0aGlzLiRlbGVtZW50LmZpbmQoJy5pcy1hY3RpdmUnKTtcbiAgICBpZihpbml0UGFuZXMubGVuZ3RoKXtcbiAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICBpbml0UGFuZXMuZWFjaChmdW5jdGlvbigpe1xuICAgICAgICBfdGhpcy5kb3duKCQodGhpcykpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHRoaXMuX2V2ZW50cygpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgZXZlbnQgaGFuZGxlcnMgZm9yIGl0ZW1zIHdpdGhpbiB0aGUgbWVudS5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9ldmVudHMoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIHRoaXMuJGVsZW1lbnQuZmluZCgnbGknKS5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgdmFyICRzdWJtZW51ID0gJCh0aGlzKS5jaGlsZHJlbignW2RhdGEtc3VibWVudV0nKTtcblxuICAgICAgaWYgKCRzdWJtZW51Lmxlbmd0aCkge1xuICAgICAgICAkKHRoaXMpLmNoaWxkcmVuKCdhJykub2ZmKCdjbGljay56Zi5hY2NvcmRpb25NZW51Jykub24oJ2NsaWNrLnpmLmFjY29yZGlvbk1lbnUnLCBmdW5jdGlvbihlKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICAgICAgICAgX3RoaXMudG9nZ2xlKCRzdWJtZW51KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSkub24oJ2tleWRvd24uemYuYWNjb3JkaW9ubWVudScsIGZ1bmN0aW9uKGUpe1xuICAgICAgdmFyICRlbGVtZW50ID0gJCh0aGlzKSxcbiAgICAgICAgICAkZWxlbWVudHMgPSAkZWxlbWVudC5wYXJlbnQoJ3VsJykuY2hpbGRyZW4oJ2xpJyksXG4gICAgICAgICAgJHByZXZFbGVtZW50LFxuICAgICAgICAgICRuZXh0RWxlbWVudCxcbiAgICAgICAgICAkdGFyZ2V0ID0gJGVsZW1lbnQuY2hpbGRyZW4oJ1tkYXRhLXN1Ym1lbnVdJyk7XG5cbiAgICAgICRlbGVtZW50cy5lYWNoKGZ1bmN0aW9uKGkpIHtcbiAgICAgICAgaWYgKCQodGhpcykuaXMoJGVsZW1lbnQpKSB7XG4gICAgICAgICAgJHByZXZFbGVtZW50ID0gJGVsZW1lbnRzLmVxKE1hdGgubWF4KDAsIGktMSkpLmZpbmQoJ2EnKS5maXJzdCgpO1xuICAgICAgICAgICRuZXh0RWxlbWVudCA9ICRlbGVtZW50cy5lcShNYXRoLm1pbihpKzEsICRlbGVtZW50cy5sZW5ndGgtMSkpLmZpbmQoJ2EnKS5maXJzdCgpO1xuXG4gICAgICAgICAgaWYgKCQodGhpcykuY2hpbGRyZW4oJ1tkYXRhLXN1Ym1lbnVdOnZpc2libGUnKS5sZW5ndGgpIHsgLy8gaGFzIG9wZW4gc3ViIG1lbnVcbiAgICAgICAgICAgICRuZXh0RWxlbWVudCA9ICRlbGVtZW50LmZpbmQoJ2xpOmZpcnN0LWNoaWxkJykuZmluZCgnYScpLmZpcnN0KCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICgkKHRoaXMpLmlzKCc6Zmlyc3QtY2hpbGQnKSkgeyAvLyBpcyBmaXJzdCBlbGVtZW50IG9mIHN1YiBtZW51XG4gICAgICAgICAgICAkcHJldkVsZW1lbnQgPSAkZWxlbWVudC5wYXJlbnRzKCdsaScpLmZpcnN0KCkuZmluZCgnYScpLmZpcnN0KCk7XG4gICAgICAgICAgfSBlbHNlIGlmICgkcHJldkVsZW1lbnQucGFyZW50cygnbGknKS5maXJzdCgpLmNoaWxkcmVuKCdbZGF0YS1zdWJtZW51XTp2aXNpYmxlJykubGVuZ3RoKSB7IC8vIGlmIHByZXZpb3VzIGVsZW1lbnQgaGFzIG9wZW4gc3ViIG1lbnVcbiAgICAgICAgICAgICRwcmV2RWxlbWVudCA9ICRwcmV2RWxlbWVudC5wYXJlbnRzKCdsaScpLmZpbmQoJ2xpOmxhc3QtY2hpbGQnKS5maW5kKCdhJykuZmlyc3QoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCQodGhpcykuaXMoJzpsYXN0LWNoaWxkJykpIHsgLy8gaXMgbGFzdCBlbGVtZW50IG9mIHN1YiBtZW51XG4gICAgICAgICAgICAkbmV4dEVsZW1lbnQgPSAkZWxlbWVudC5wYXJlbnRzKCdsaScpLmZpcnN0KCkubmV4dCgnbGknKS5maW5kKCdhJykuZmlyc3QoKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICBGb3VuZGF0aW9uLktleWJvYXJkLmhhbmRsZUtleShlLCAnQWNjb3JkaW9uTWVudScsIHtcbiAgICAgICAgb3BlbjogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgaWYgKCR0YXJnZXQuaXMoJzpoaWRkZW4nKSkge1xuICAgICAgICAgICAgX3RoaXMuZG93bigkdGFyZ2V0KTtcbiAgICAgICAgICAgICR0YXJnZXQuZmluZCgnbGknKS5maXJzdCgpLmZpbmQoJ2EnKS5maXJzdCgpLmZvY3VzKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBjbG9zZTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgaWYgKCR0YXJnZXQubGVuZ3RoICYmICEkdGFyZ2V0LmlzKCc6aGlkZGVuJykpIHsgLy8gY2xvc2UgYWN0aXZlIHN1YiBvZiB0aGlzIGl0ZW1cbiAgICAgICAgICAgIF90aGlzLnVwKCR0YXJnZXQpO1xuICAgICAgICAgIH0gZWxzZSBpZiAoJGVsZW1lbnQucGFyZW50KCdbZGF0YS1zdWJtZW51XScpLmxlbmd0aCkgeyAvLyBjbG9zZSBjdXJyZW50bHkgb3BlbiBzdWJcbiAgICAgICAgICAgIF90aGlzLnVwKCRlbGVtZW50LnBhcmVudCgnW2RhdGEtc3VibWVudV0nKSk7XG4gICAgICAgICAgICAkZWxlbWVudC5wYXJlbnRzKCdsaScpLmZpcnN0KCkuZmluZCgnYScpLmZpcnN0KCkuZm9jdXMoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHVwOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAkcHJldkVsZW1lbnQuZm9jdXMoKTtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSxcbiAgICAgICAgZG93bjogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgJG5leHRFbGVtZW50LmZvY3VzKCk7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH0sXG4gICAgICAgIHRvZ2dsZTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgaWYgKCRlbGVtZW50LmNoaWxkcmVuKCdbZGF0YS1zdWJtZW51XScpLmxlbmd0aCkge1xuICAgICAgICAgICAgX3RoaXMudG9nZ2xlKCRlbGVtZW50LmNoaWxkcmVuKCdbZGF0YS1zdWJtZW51XScpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIGNsb3NlQWxsOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICBfdGhpcy5oaWRlQWxsKCk7XG4gICAgICAgIH0sXG4gICAgICAgIGhhbmRsZWQ6IGZ1bmN0aW9uKHByZXZlbnREZWZhdWx0KSB7XG4gICAgICAgICAgaWYgKHByZXZlbnREZWZhdWx0KSB7XG4gICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pOy8vLmF0dHIoJ3RhYmluZGV4JywgMCk7XG4gIH1cblxuICAvKipcbiAgICogQ2xvc2VzIGFsbCBwYW5lcyBvZiB0aGUgbWVudS5cbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICBoaWRlQWxsKCkge1xuICAgIHRoaXMudXAodGhpcy4kZWxlbWVudC5maW5kKCdbZGF0YS1zdWJtZW51XScpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBPcGVucyBhbGwgcGFuZXMgb2YgdGhlIG1lbnUuXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgc2hvd0FsbCgpIHtcbiAgICB0aGlzLmRvd24odGhpcy4kZWxlbWVudC5maW5kKCdbZGF0YS1zdWJtZW51XScpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUb2dnbGVzIHRoZSBvcGVuL2Nsb3NlIHN0YXRlIG9mIGEgc3VibWVudS5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwYXJhbSB7alF1ZXJ5fSAkdGFyZ2V0IC0gdGhlIHN1Ym1lbnUgdG8gdG9nZ2xlXG4gICAqL1xuICB0b2dnbGUoJHRhcmdldCl7XG4gICAgaWYoISR0YXJnZXQuaXMoJzphbmltYXRlZCcpKSB7XG4gICAgICBpZiAoISR0YXJnZXQuaXMoJzpoaWRkZW4nKSkge1xuICAgICAgICB0aGlzLnVwKCR0YXJnZXQpO1xuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgIHRoaXMuZG93bigkdGFyZ2V0KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogT3BlbnMgdGhlIHN1Yi1tZW51IGRlZmluZWQgYnkgYCR0YXJnZXRgLlxuICAgKiBAcGFyYW0ge2pRdWVyeX0gJHRhcmdldCAtIFN1Yi1tZW51IHRvIG9wZW4uXG4gICAqIEBmaXJlcyBBY2NvcmRpb25NZW51I2Rvd25cbiAgICovXG4gIGRvd24oJHRhcmdldCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICBpZighdGhpcy5vcHRpb25zLm11bHRpT3Blbikge1xuICAgICAgdGhpcy51cCh0aGlzLiRlbGVtZW50LmZpbmQoJy5pcy1hY3RpdmUnKS5ub3QoJHRhcmdldC5wYXJlbnRzVW50aWwodGhpcy4kZWxlbWVudCkuYWRkKCR0YXJnZXQpKSk7XG4gICAgfVxuXG4gICAgJHRhcmdldC5hZGRDbGFzcygnaXMtYWN0aXZlJykuYXR0cih7J2FyaWEtaGlkZGVuJzogZmFsc2V9KVxuICAgICAgLnBhcmVudCgnLmlzLWFjY29yZGlvbi1zdWJtZW51LXBhcmVudCcpLmF0dHIoeydhcmlhLWV4cGFuZGVkJzogdHJ1ZX0pO1xuXG4gICAgICAvL0ZvdW5kYXRpb24uTW92ZSh0aGlzLm9wdGlvbnMuc2xpZGVTcGVlZCwgJHRhcmdldCwgZnVuY3Rpb24oKSB7XG4gICAgICAgICR0YXJnZXQuc2xpZGVEb3duKF90aGlzLm9wdGlvbnMuc2xpZGVTcGVlZCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIEZpcmVzIHdoZW4gdGhlIG1lbnUgaXMgZG9uZSBvcGVuaW5nLlxuICAgICAgICAgICAqIEBldmVudCBBY2NvcmRpb25NZW51I2Rvd25cbiAgICAgICAgICAgKi9cbiAgICAgICAgICBfdGhpcy4kZWxlbWVudC50cmlnZ2VyKCdkb3duLnpmLmFjY29yZGlvbk1lbnUnLCBbJHRhcmdldF0pO1xuICAgICAgICB9KTtcbiAgICAgIC8vfSk7XG4gIH1cblxuICAvKipcbiAgICogQ2xvc2VzIHRoZSBzdWItbWVudSBkZWZpbmVkIGJ5IGAkdGFyZ2V0YC4gQWxsIHN1Yi1tZW51cyBpbnNpZGUgdGhlIHRhcmdldCB3aWxsIGJlIGNsb3NlZCBhcyB3ZWxsLlxuICAgKiBAcGFyYW0ge2pRdWVyeX0gJHRhcmdldCAtIFN1Yi1tZW51IHRvIGNsb3NlLlxuICAgKiBAZmlyZXMgQWNjb3JkaW9uTWVudSN1cFxuICAgKi9cbiAgdXAoJHRhcmdldCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgLy9Gb3VuZGF0aW9uLk1vdmUodGhpcy5vcHRpb25zLnNsaWRlU3BlZWQsICR0YXJnZXQsIGZ1bmN0aW9uKCl7XG4gICAgICAkdGFyZ2V0LnNsaWRlVXAoX3RoaXMub3B0aW9ucy5zbGlkZVNwZWVkLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBGaXJlcyB3aGVuIHRoZSBtZW51IGlzIGRvbmUgY29sbGFwc2luZyB1cC5cbiAgICAgICAgICogQGV2ZW50IEFjY29yZGlvbk1lbnUjdXBcbiAgICAgICAgICovXG4gICAgICAgIF90aGlzLiRlbGVtZW50LnRyaWdnZXIoJ3VwLnpmLmFjY29yZGlvbk1lbnUnLCBbJHRhcmdldF0pO1xuICAgICAgfSk7XG4gICAgLy99KTtcblxuICAgIHZhciAkbWVudXMgPSAkdGFyZ2V0LmZpbmQoJ1tkYXRhLXN1Ym1lbnVdJykuc2xpZGVVcCgwKS5hZGRCYWNrKCkuYXR0cignYXJpYS1oaWRkZW4nLCB0cnVlKTtcblxuICAgICRtZW51cy5wYXJlbnQoJy5pcy1hY2NvcmRpb24tc3VibWVudS1wYXJlbnQnKS5hdHRyKCdhcmlhLWV4cGFuZGVkJywgZmFsc2UpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlc3Ryb3lzIGFuIGluc3RhbmNlIG9mIGFjY29yZGlvbiBtZW51LlxuICAgKiBAZmlyZXMgQWNjb3JkaW9uTWVudSNkZXN0cm95ZWRcbiAgICovXG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy4kZWxlbWVudC5maW5kKCdbZGF0YS1zdWJtZW51XScpLnNsaWRlRG93bigwKS5jc3MoJ2Rpc3BsYXknLCAnJyk7XG4gICAgdGhpcy4kZWxlbWVudC5maW5kKCdhJykub2ZmKCdjbGljay56Zi5hY2NvcmRpb25NZW51Jyk7XG5cbiAgICBGb3VuZGF0aW9uLk5lc3QuQnVybih0aGlzLiRlbGVtZW50LCAnYWNjb3JkaW9uJyk7XG4gICAgRm91bmRhdGlvbi51bnJlZ2lzdGVyUGx1Z2luKHRoaXMpO1xuICB9XG59XG5cbkFjY29yZGlvbk1lbnUuZGVmYXVsdHMgPSB7XG4gIC8qKlxuICAgKiBBbW91bnQgb2YgdGltZSB0byBhbmltYXRlIHRoZSBvcGVuaW5nIG9mIGEgc3VibWVudSBpbiBtcy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAyNTBcbiAgICovXG4gIHNsaWRlU3BlZWQ6IDI1MCxcbiAgLyoqXG4gICAqIEFsbG93IHRoZSBtZW51IHRvIGhhdmUgbXVsdGlwbGUgb3BlbiBwYW5lcy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSB0cnVlXG4gICAqL1xuICBtdWx0aU9wZW46IHRydWVcbn07XG5cbi8vIFdpbmRvdyBleHBvcnRzXG5Gb3VuZGF0aW9uLnBsdWdpbihBY2NvcmRpb25NZW51LCAnQWNjb3JkaW9uTWVudScpO1xuXG59KGpRdWVyeSk7XG4iLCIndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbi8qKlxuICogRHJpbGxkb3duIG1vZHVsZS5cbiAqIEBtb2R1bGUgZm91bmRhdGlvbi5kcmlsbGRvd25cbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwua2V5Ym9hcmRcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwubW90aW9uXG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLm5lc3RcbiAqL1xuXG5jbGFzcyBEcmlsbGRvd24ge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBpbnN0YW5jZSBvZiBhIGRyaWxsZG93biBtZW51LlxuICAgKiBAY2xhc3NcbiAgICogQHBhcmFtIHtqUXVlcnl9IGVsZW1lbnQgLSBqUXVlcnkgb2JqZWN0IHRvIG1ha2UgaW50byBhbiBhY2NvcmRpb24gbWVudS5cbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMgLSBPdmVycmlkZXMgdG8gdGhlIGRlZmF1bHQgcGx1Z2luIHNldHRpbmdzLlxuICAgKi9cbiAgY29uc3RydWN0b3IoZWxlbWVudCwgb3B0aW9ucykge1xuICAgIHRoaXMuJGVsZW1lbnQgPSBlbGVtZW50O1xuICAgIHRoaXMub3B0aW9ucyA9ICQuZXh0ZW5kKHt9LCBEcmlsbGRvd24uZGVmYXVsdHMsIHRoaXMuJGVsZW1lbnQuZGF0YSgpLCBvcHRpb25zKTtcblxuICAgIEZvdW5kYXRpb24uTmVzdC5GZWF0aGVyKHRoaXMuJGVsZW1lbnQsICdkcmlsbGRvd24nKTtcblxuICAgIHRoaXMuX2luaXQoKTtcblxuICAgIEZvdW5kYXRpb24ucmVnaXN0ZXJQbHVnaW4odGhpcywgJ0RyaWxsZG93bicpO1xuICAgIEZvdW5kYXRpb24uS2V5Ym9hcmQucmVnaXN0ZXIoJ0RyaWxsZG93bicsIHtcbiAgICAgICdFTlRFUic6ICdvcGVuJyxcbiAgICAgICdTUEFDRSc6ICdvcGVuJyxcbiAgICAgICdBUlJPV19SSUdIVCc6ICduZXh0JyxcbiAgICAgICdBUlJPV19VUCc6ICd1cCcsXG4gICAgICAnQVJST1dfRE9XTic6ICdkb3duJyxcbiAgICAgICdBUlJPV19MRUZUJzogJ3ByZXZpb3VzJyxcbiAgICAgICdFU0NBUEUnOiAnY2xvc2UnLFxuICAgICAgJ1RBQic6ICdkb3duJyxcbiAgICAgICdTSElGVF9UQUInOiAndXAnXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgdGhlIGRyaWxsZG93biBieSBjcmVhdGluZyBqUXVlcnkgY29sbGVjdGlvbnMgb2YgZWxlbWVudHNcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9pbml0KCkge1xuICAgIHRoaXMuJHN1Ym1lbnVBbmNob3JzID0gdGhpcy4kZWxlbWVudC5maW5kKCdsaS5pcy1kcmlsbGRvd24tc3VibWVudS1wYXJlbnQnKS5jaGlsZHJlbignYScpO1xuICAgIHRoaXMuJHN1Ym1lbnVzID0gdGhpcy4kc3VibWVudUFuY2hvcnMucGFyZW50KCdsaScpLmNoaWxkcmVuKCdbZGF0YS1zdWJtZW51XScpO1xuICAgIHRoaXMuJG1lbnVJdGVtcyA9IHRoaXMuJGVsZW1lbnQuZmluZCgnbGknKS5ub3QoJy5qcy1kcmlsbGRvd24tYmFjaycpLmF0dHIoJ3JvbGUnLCAnbWVudWl0ZW0nKS5maW5kKCdhJyk7XG4gICAgdGhpcy4kZWxlbWVudC5hdHRyKCdkYXRhLW11dGF0ZScsICh0aGlzLiRlbGVtZW50LmF0dHIoJ2RhdGEtZHJpbGxkb3duJykgfHwgRm91bmRhdGlvbi5HZXRZb0RpZ2l0cyg2LCAnZHJpbGxkb3duJykpKTtcblxuICAgIHRoaXMuX3ByZXBhcmVNZW51KCk7XG4gICAgdGhpcy5fcmVnaXN0ZXJFdmVudHMoKTtcblxuICAgIHRoaXMuX2tleWJvYXJkRXZlbnRzKCk7XG4gIH1cblxuICAvKipcbiAgICogcHJlcGFyZXMgZHJpbGxkb3duIG1lbnUgYnkgc2V0dGluZyBhdHRyaWJ1dGVzIHRvIGxpbmtzIGFuZCBlbGVtZW50c1xuICAgKiBzZXRzIGEgbWluIGhlaWdodCB0byBwcmV2ZW50IGNvbnRlbnQganVtcGluZ1xuICAgKiB3cmFwcyB0aGUgZWxlbWVudCBpZiBub3QgYWxyZWFkeSB3cmFwcGVkXG4gICAqIEBwcml2YXRlXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgX3ByZXBhcmVNZW51KCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgLy8gaWYoIXRoaXMub3B0aW9ucy5ob2xkT3Blbil7XG4gICAgLy8gICB0aGlzLl9tZW51TGlua0V2ZW50cygpO1xuICAgIC8vIH1cbiAgICB0aGlzLiRzdWJtZW51QW5jaG9ycy5lYWNoKGZ1bmN0aW9uKCl7XG4gICAgICB2YXIgJGxpbmsgPSAkKHRoaXMpO1xuICAgICAgdmFyICRzdWIgPSAkbGluay5wYXJlbnQoKTtcbiAgICAgIGlmKF90aGlzLm9wdGlvbnMucGFyZW50TGluayl7XG4gICAgICAgICRsaW5rLmNsb25lKCkucHJlcGVuZFRvKCRzdWIuY2hpbGRyZW4oJ1tkYXRhLXN1Ym1lbnVdJykpLndyYXAoJzxsaSBjbGFzcz1cImlzLXN1Ym1lbnUtcGFyZW50LWl0ZW0gaXMtc3VibWVudS1pdGVtIGlzLWRyaWxsZG93bi1zdWJtZW51LWl0ZW1cIiByb2xlPVwibWVudS1pdGVtXCI+PC9saT4nKTtcbiAgICAgIH1cbiAgICAgICRsaW5rLmRhdGEoJ3NhdmVkSHJlZicsICRsaW5rLmF0dHIoJ2hyZWYnKSkucmVtb3ZlQXR0cignaHJlZicpLmF0dHIoJ3RhYmluZGV4JywgMCk7XG4gICAgICAkbGluay5jaGlsZHJlbignW2RhdGEtc3VibWVudV0nKVxuICAgICAgICAgIC5hdHRyKHtcbiAgICAgICAgICAgICdhcmlhLWhpZGRlbic6IHRydWUsXG4gICAgICAgICAgICAndGFiaW5kZXgnOiAwLFxuICAgICAgICAgICAgJ3JvbGUnOiAnbWVudSdcbiAgICAgICAgICB9KTtcbiAgICAgIF90aGlzLl9ldmVudHMoJGxpbmspO1xuICAgIH0pO1xuICAgIHRoaXMuJHN1Ym1lbnVzLmVhY2goZnVuY3Rpb24oKXtcbiAgICAgIHZhciAkbWVudSA9ICQodGhpcyksXG4gICAgICAgICAgJGJhY2sgPSAkbWVudS5maW5kKCcuanMtZHJpbGxkb3duLWJhY2snKTtcbiAgICAgIGlmKCEkYmFjay5sZW5ndGgpe1xuICAgICAgICBzd2l0Y2ggKF90aGlzLm9wdGlvbnMuYmFja0J1dHRvblBvc2l0aW9uKSB7XG4gICAgICAgICAgY2FzZSBcImJvdHRvbVwiOlxuICAgICAgICAgICAgJG1lbnUuYXBwZW5kKF90aGlzLm9wdGlvbnMuYmFja0J1dHRvbik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBjYXNlIFwidG9wXCI6XG4gICAgICAgICAgICAkbWVudS5wcmVwZW5kKF90aGlzLm9wdGlvbnMuYmFja0J1dHRvbik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIlVuc3VwcG9ydGVkIGJhY2tCdXR0b25Qb3NpdGlvbiB2YWx1ZSAnXCIgKyBfdGhpcy5vcHRpb25zLmJhY2tCdXR0b25Qb3NpdGlvbiArIFwiJ1wiKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgX3RoaXMuX2JhY2soJG1lbnUpO1xuICAgIH0pO1xuXG4gICAgaWYoIXRoaXMub3B0aW9ucy5hdXRvSGVpZ2h0KSB7XG4gICAgICB0aGlzLiRzdWJtZW51cy5hZGRDbGFzcygnZHJpbGxkb3duLXN1Ym1lbnUtY292ZXItcHJldmlvdXMnKTtcbiAgICB9XG5cbiAgICBpZighdGhpcy4kZWxlbWVudC5wYXJlbnQoKS5oYXNDbGFzcygnaXMtZHJpbGxkb3duJykpe1xuICAgICAgdGhpcy4kd3JhcHBlciA9ICQodGhpcy5vcHRpb25zLndyYXBwZXIpLmFkZENsYXNzKCdpcy1kcmlsbGRvd24nKTtcbiAgICAgIGlmKHRoaXMub3B0aW9ucy5hbmltYXRlSGVpZ2h0KSB0aGlzLiR3cmFwcGVyLmFkZENsYXNzKCdhbmltYXRlLWhlaWdodCcpO1xuICAgICAgdGhpcy4kd3JhcHBlciA9IHRoaXMuJGVsZW1lbnQud3JhcCh0aGlzLiR3cmFwcGVyKS5wYXJlbnQoKS5jc3ModGhpcy5fZ2V0TWF4RGltcygpKTtcbiAgICB9XG4gIH1cblxuICBfcmVzaXplKCkge1xuICAgIHRoaXMuJHdyYXBwZXIuY3NzKHsnbWF4LXdpZHRoJzogJ25vbmUnLCAnbWluLWhlaWdodCc6ICdub25lJ30pO1xuICAgIC8vIF9nZXRNYXhEaW1zIGhhcyBzaWRlIGVmZmVjdHMgKGJvbykgYnV0IGNhbGxpbmcgaXQgc2hvdWxkIHVwZGF0ZSBhbGwgb3RoZXIgbmVjZXNzYXJ5IGhlaWdodHMgJiB3aWR0aHNcbiAgICB0aGlzLiR3cmFwcGVyLmNzcyh0aGlzLl9nZXRNYXhEaW1zKCkpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgZXZlbnQgaGFuZGxlcnMgdG8gZWxlbWVudHMgaW4gdGhlIG1lbnUuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKiBAcGFyYW0ge2pRdWVyeX0gJGVsZW0gLSB0aGUgY3VycmVudCBtZW51IGl0ZW0gdG8gYWRkIGhhbmRsZXJzIHRvLlxuICAgKi9cbiAgX2V2ZW50cygkZWxlbSkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAkZWxlbS5vZmYoJ2NsaWNrLnpmLmRyaWxsZG93bicpXG4gICAgLm9uKCdjbGljay56Zi5kcmlsbGRvd24nLCBmdW5jdGlvbihlKXtcbiAgICAgIGlmKCQoZS50YXJnZXQpLnBhcmVudHNVbnRpbCgndWwnLCAnbGknKS5oYXNDbGFzcygnaXMtZHJpbGxkb3duLXN1Ym1lbnUtcGFyZW50Jykpe1xuICAgICAgICBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB9XG5cbiAgICAgIC8vIGlmKGUudGFyZ2V0ICE9PSBlLmN1cnJlbnRUYXJnZXQuZmlyc3RFbGVtZW50Q2hpbGQpe1xuICAgICAgLy8gICByZXR1cm4gZmFsc2U7XG4gICAgICAvLyB9XG4gICAgICBfdGhpcy5fc2hvdygkZWxlbS5wYXJlbnQoJ2xpJykpO1xuXG4gICAgICBpZihfdGhpcy5vcHRpb25zLmNsb3NlT25DbGljayl7XG4gICAgICAgIHZhciAkYm9keSA9ICQoJ2JvZHknKTtcbiAgICAgICAgJGJvZHkub2ZmKCcuemYuZHJpbGxkb3duJykub24oJ2NsaWNrLnpmLmRyaWxsZG93bicsIGZ1bmN0aW9uKGUpe1xuICAgICAgICAgIGlmIChlLnRhcmdldCA9PT0gX3RoaXMuJGVsZW1lbnRbMF0gfHwgJC5jb250YWlucyhfdGhpcy4kZWxlbWVudFswXSwgZS50YXJnZXQpKSB7IHJldHVybjsgfVxuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICBfdGhpcy5faGlkZUFsbCgpO1xuICAgICAgICAgICRib2R5Lm9mZignLnpmLmRyaWxsZG93bicpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcblx0ICB0aGlzLiRlbGVtZW50Lm9uKCdtdXRhdGVtZS56Zi50cmlnZ2VyJywgdGhpcy5fcmVzaXplLmJpbmQodGhpcykpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgZXZlbnQgaGFuZGxlcnMgdG8gdGhlIG1lbnUgZWxlbWVudC5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfcmVnaXN0ZXJFdmVudHMoKSB7XG4gICAgaWYodGhpcy5vcHRpb25zLnNjcm9sbFRvcCl7XG4gICAgICB0aGlzLl9iaW5kSGFuZGxlciA9IHRoaXMuX3Njcm9sbFRvcC5iaW5kKHRoaXMpO1xuICAgICAgdGhpcy4kZWxlbWVudC5vbignb3Blbi56Zi5kcmlsbGRvd24gaGlkZS56Zi5kcmlsbGRvd24gY2xvc2VkLnpmLmRyaWxsZG93bicsdGhpcy5fYmluZEhhbmRsZXIpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTY3JvbGwgdG8gVG9wIG9mIEVsZW1lbnQgb3IgZGF0YS1zY3JvbGwtdG9wLWVsZW1lbnRcbiAgICogQGZ1bmN0aW9uXG4gICAqIEBmaXJlcyBEcmlsbGRvd24jc2Nyb2xsbWVcbiAgICovXG4gIF9zY3JvbGxUb3AoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcbiAgICB2YXIgJHNjcm9sbFRvcEVsZW1lbnQgPSBfdGhpcy5vcHRpb25zLnNjcm9sbFRvcEVsZW1lbnQhPScnPyQoX3RoaXMub3B0aW9ucy5zY3JvbGxUb3BFbGVtZW50KTpfdGhpcy4kZWxlbWVudCxcbiAgICAgICAgc2Nyb2xsUG9zID0gcGFyc2VJbnQoJHNjcm9sbFRvcEVsZW1lbnQub2Zmc2V0KCkudG9wK190aGlzLm9wdGlvbnMuc2Nyb2xsVG9wT2Zmc2V0KTtcbiAgICAkKCdodG1sLCBib2R5Jykuc3RvcCh0cnVlKS5hbmltYXRlKHsgc2Nyb2xsVG9wOiBzY3JvbGxQb3MgfSwgX3RoaXMub3B0aW9ucy5hbmltYXRpb25EdXJhdGlvbiwgX3RoaXMub3B0aW9ucy5hbmltYXRpb25FYXNpbmcsZnVuY3Rpb24oKXtcbiAgICAgIC8qKlxuICAgICAgICAqIEZpcmVzIGFmdGVyIHRoZSBtZW51IGhhcyBzY3JvbGxlZFxuICAgICAgICAqIEBldmVudCBEcmlsbGRvd24jc2Nyb2xsbWVcbiAgICAgICAgKi9cbiAgICAgIGlmKHRoaXM9PT0kKCdodG1sJylbMF0pX3RoaXMuJGVsZW1lbnQudHJpZ2dlcignc2Nyb2xsbWUuemYuZHJpbGxkb3duJyk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBrZXlkb3duIGV2ZW50IGxpc3RlbmVyIHRvIGBsaWAncyBpbiB0aGUgbWVudS5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9rZXlib2FyZEV2ZW50cygpIHtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgdGhpcy4kbWVudUl0ZW1zLmFkZCh0aGlzLiRlbGVtZW50LmZpbmQoJy5qcy1kcmlsbGRvd24tYmFjayA+IGEsIC5pcy1zdWJtZW51LXBhcmVudC1pdGVtID4gYScpKS5vbigna2V5ZG93bi56Zi5kcmlsbGRvd24nLCBmdW5jdGlvbihlKXtcbiAgICAgIHZhciAkZWxlbWVudCA9ICQodGhpcyksXG4gICAgICAgICAgJGVsZW1lbnRzID0gJGVsZW1lbnQucGFyZW50KCdsaScpLnBhcmVudCgndWwnKS5jaGlsZHJlbignbGknKS5jaGlsZHJlbignYScpLFxuICAgICAgICAgICRwcmV2RWxlbWVudCxcbiAgICAgICAgICAkbmV4dEVsZW1lbnQ7XG5cbiAgICAgICRlbGVtZW50cy5lYWNoKGZ1bmN0aW9uKGkpIHtcbiAgICAgICAgaWYgKCQodGhpcykuaXMoJGVsZW1lbnQpKSB7XG4gICAgICAgICAgJHByZXZFbGVtZW50ID0gJGVsZW1lbnRzLmVxKE1hdGgubWF4KDAsIGktMSkpO1xuICAgICAgICAgICRuZXh0RWxlbWVudCA9ICRlbGVtZW50cy5lcShNYXRoLm1pbihpKzEsICRlbGVtZW50cy5sZW5ndGgtMSkpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIEZvdW5kYXRpb24uS2V5Ym9hcmQuaGFuZGxlS2V5KGUsICdEcmlsbGRvd24nLCB7XG4gICAgICAgIG5leHQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIGlmICgkZWxlbWVudC5pcyhfdGhpcy4kc3VibWVudUFuY2hvcnMpKSB7XG4gICAgICAgICAgICBfdGhpcy5fc2hvdygkZWxlbWVudC5wYXJlbnQoJ2xpJykpO1xuICAgICAgICAgICAgJGVsZW1lbnQucGFyZW50KCdsaScpLm9uZShGb3VuZGF0aW9uLnRyYW5zaXRpb25lbmQoJGVsZW1lbnQpLCBmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAkZWxlbWVudC5wYXJlbnQoJ2xpJykuZmluZCgndWwgbGkgYScpLmZpbHRlcihfdGhpcy4kbWVudUl0ZW1zKS5maXJzdCgpLmZvY3VzKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgcHJldmlvdXM6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIF90aGlzLl9oaWRlKCRlbGVtZW50LnBhcmVudCgnbGknKS5wYXJlbnQoJ3VsJykpO1xuICAgICAgICAgICRlbGVtZW50LnBhcmVudCgnbGknKS5wYXJlbnQoJ3VsJykub25lKEZvdW5kYXRpb24udHJhbnNpdGlvbmVuZCgkZWxlbWVudCksIGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAkZWxlbWVudC5wYXJlbnQoJ2xpJykucGFyZW50KCd1bCcpLnBhcmVudCgnbGknKS5jaGlsZHJlbignYScpLmZpcnN0KCkuZm9jdXMoKTtcbiAgICAgICAgICAgIH0sIDEpO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9LFxuICAgICAgICB1cDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgJHByZXZFbGVtZW50LmZvY3VzKCk7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH0sXG4gICAgICAgIGRvd246IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICRuZXh0RWxlbWVudC5mb2N1cygpO1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9LFxuICAgICAgICBjbG9zZTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgX3RoaXMuX2JhY2soKTtcbiAgICAgICAgICAvL190aGlzLiRtZW51SXRlbXMuZmlyc3QoKS5mb2N1cygpOyAvLyBmb2N1cyB0byBmaXJzdCBlbGVtZW50XG4gICAgICAgIH0sXG4gICAgICAgIG9wZW46IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIGlmICghJGVsZW1lbnQuaXMoX3RoaXMuJG1lbnVJdGVtcykpIHsgLy8gbm90IG1lbnUgaXRlbSBtZWFucyBiYWNrIGJ1dHRvblxuICAgICAgICAgICAgX3RoaXMuX2hpZGUoJGVsZW1lbnQucGFyZW50KCdsaScpLnBhcmVudCgndWwnKSk7XG4gICAgICAgICAgICAkZWxlbWVudC5wYXJlbnQoJ2xpJykucGFyZW50KCd1bCcpLm9uZShGb3VuZGF0aW9uLnRyYW5zaXRpb25lbmQoJGVsZW1lbnQpLCBmdW5jdGlvbigpe1xuICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICRlbGVtZW50LnBhcmVudCgnbGknKS5wYXJlbnQoJ3VsJykucGFyZW50KCdsaScpLmNoaWxkcmVuKCdhJykuZmlyc3QoKS5mb2N1cygpO1xuICAgICAgICAgICAgICB9LCAxKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfSBlbHNlIGlmICgkZWxlbWVudC5pcyhfdGhpcy4kc3VibWVudUFuY2hvcnMpKSB7XG4gICAgICAgICAgICBfdGhpcy5fc2hvdygkZWxlbWVudC5wYXJlbnQoJ2xpJykpO1xuICAgICAgICAgICAgJGVsZW1lbnQucGFyZW50KCdsaScpLm9uZShGb3VuZGF0aW9uLnRyYW5zaXRpb25lbmQoJGVsZW1lbnQpLCBmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAkZWxlbWVudC5wYXJlbnQoJ2xpJykuZmluZCgndWwgbGkgYScpLmZpbHRlcihfdGhpcy4kbWVudUl0ZW1zKS5maXJzdCgpLmZvY3VzKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgaGFuZGxlZDogZnVuY3Rpb24ocHJldmVudERlZmF1bHQpIHtcbiAgICAgICAgICBpZiAocHJldmVudERlZmF1bHQpIHtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZS5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7IC8vIGVuZCBrZXlib2FyZEFjY2Vzc1xuICB9XG5cbiAgLyoqXG4gICAqIENsb3NlcyBhbGwgb3BlbiBlbGVtZW50cywgYW5kIHJldHVybnMgdG8gcm9vdCBtZW51LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQGZpcmVzIERyaWxsZG93biNjbG9zZWRcbiAgICovXG4gIF9oaWRlQWxsKCkge1xuICAgIHZhciAkZWxlbSA9IHRoaXMuJGVsZW1lbnQuZmluZCgnLmlzLWRyaWxsZG93bi1zdWJtZW51LmlzLWFjdGl2ZScpLmFkZENsYXNzKCdpcy1jbG9zaW5nJyk7XG4gICAgaWYodGhpcy5vcHRpb25zLmF1dG9IZWlnaHQpIHRoaXMuJHdyYXBwZXIuY3NzKHtoZWlnaHQ6JGVsZW0ucGFyZW50KCkuY2xvc2VzdCgndWwnKS5kYXRhKCdjYWxjSGVpZ2h0Jyl9KTtcbiAgICAkZWxlbS5vbmUoRm91bmRhdGlvbi50cmFuc2l0aW9uZW5kKCRlbGVtKSwgZnVuY3Rpb24oZSl7XG4gICAgICAkZWxlbS5yZW1vdmVDbGFzcygnaXMtYWN0aXZlIGlzLWNsb3NpbmcnKTtcbiAgICB9KTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIEZpcmVzIHdoZW4gdGhlIG1lbnUgaXMgZnVsbHkgY2xvc2VkLlxuICAgICAgICAgKiBAZXZlbnQgRHJpbGxkb3duI2Nsb3NlZFxuICAgICAgICAgKi9cbiAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ2Nsb3NlZC56Zi5kcmlsbGRvd24nKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGV2ZW50IGxpc3RlbmVyIGZvciBlYWNoIGBiYWNrYCBidXR0b24sIGFuZCBjbG9zZXMgb3BlbiBtZW51cy5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBmaXJlcyBEcmlsbGRvd24jYmFja1xuICAgKiBAcGFyYW0ge2pRdWVyeX0gJGVsZW0gLSB0aGUgY3VycmVudCBzdWItbWVudSB0byBhZGQgYGJhY2tgIGV2ZW50LlxuICAgKi9cbiAgX2JhY2soJGVsZW0pIHtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICRlbGVtLm9mZignY2xpY2suemYuZHJpbGxkb3duJyk7XG4gICAgJGVsZW0uY2hpbGRyZW4oJy5qcy1kcmlsbGRvd24tYmFjaycpXG4gICAgICAub24oJ2NsaWNrLnpmLmRyaWxsZG93bicsIGZ1bmN0aW9uKGUpe1xuICAgICAgICBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZygnbW91c2V1cCBvbiBiYWNrJyk7XG4gICAgICAgIF90aGlzLl9oaWRlKCRlbGVtKTtcblxuICAgICAgICAvLyBJZiB0aGVyZSBpcyBhIHBhcmVudCBzdWJtZW51LCBjYWxsIHNob3dcbiAgICAgICAgbGV0IHBhcmVudFN1Yk1lbnUgPSAkZWxlbS5wYXJlbnQoJ2xpJykucGFyZW50KCd1bCcpLnBhcmVudCgnbGknKTtcbiAgICAgICAgaWYgKHBhcmVudFN1Yk1lbnUubGVuZ3RoKSB7XG4gICAgICAgICAgX3RoaXMuX3Nob3cocGFyZW50U3ViTWVudSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgZXZlbnQgbGlzdGVuZXIgdG8gbWVudSBpdGVtcyB3L28gc3VibWVudXMgdG8gY2xvc2Ugb3BlbiBtZW51cyBvbiBjbGljay5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfbWVudUxpbmtFdmVudHMoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcbiAgICB0aGlzLiRtZW51SXRlbXMubm90KCcuaXMtZHJpbGxkb3duLXN1Ym1lbnUtcGFyZW50JylcbiAgICAgICAgLm9mZignY2xpY2suemYuZHJpbGxkb3duJylcbiAgICAgICAgLm9uKCdjbGljay56Zi5kcmlsbGRvd24nLCBmdW5jdGlvbihlKXtcbiAgICAgICAgICAvLyBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgIF90aGlzLl9oaWRlQWxsKCk7XG4gICAgICAgICAgfSwgMCk7XG4gICAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBPcGVucyBhIHN1Ym1lbnUuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAZmlyZXMgRHJpbGxkb3duI29wZW5cbiAgICogQHBhcmFtIHtqUXVlcnl9ICRlbGVtIC0gdGhlIGN1cnJlbnQgZWxlbWVudCB3aXRoIGEgc3VibWVudSB0byBvcGVuLCBpLmUuIHRoZSBgbGlgIHRhZy5cbiAgICovXG4gIF9zaG93KCRlbGVtKSB7XG4gICAgaWYodGhpcy5vcHRpb25zLmF1dG9IZWlnaHQpIHRoaXMuJHdyYXBwZXIuY3NzKHtoZWlnaHQ6JGVsZW0uY2hpbGRyZW4oJ1tkYXRhLXN1Ym1lbnVdJykuZGF0YSgnY2FsY0hlaWdodCcpfSk7XG4gICAgJGVsZW0uYXR0cignYXJpYS1leHBhbmRlZCcsIHRydWUpO1xuICAgICRlbGVtLmNoaWxkcmVuKCdbZGF0YS1zdWJtZW51XScpLmFkZENsYXNzKCdpcy1hY3RpdmUnKS5hdHRyKCdhcmlhLWhpZGRlbicsIGZhbHNlKTtcbiAgICAvKipcbiAgICAgKiBGaXJlcyB3aGVuIHRoZSBzdWJtZW51IGhhcyBvcGVuZWQuXG4gICAgICogQGV2ZW50IERyaWxsZG93biNvcGVuXG4gICAgICovXG4gICAgdGhpcy4kZWxlbWVudC50cmlnZ2VyKCdvcGVuLnpmLmRyaWxsZG93bicsIFskZWxlbV0pO1xuICB9O1xuXG4gIC8qKlxuICAgKiBIaWRlcyBhIHN1Ym1lbnVcbiAgICogQGZ1bmN0aW9uXG4gICAqIEBmaXJlcyBEcmlsbGRvd24jaGlkZVxuICAgKiBAcGFyYW0ge2pRdWVyeX0gJGVsZW0gLSB0aGUgY3VycmVudCBzdWItbWVudSB0byBoaWRlLCBpLmUuIHRoZSBgdWxgIHRhZy5cbiAgICovXG4gIF9oaWRlKCRlbGVtKSB7XG4gICAgaWYodGhpcy5vcHRpb25zLmF1dG9IZWlnaHQpIHRoaXMuJHdyYXBwZXIuY3NzKHtoZWlnaHQ6JGVsZW0ucGFyZW50KCkuY2xvc2VzdCgndWwnKS5kYXRhKCdjYWxjSGVpZ2h0Jyl9KTtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICRlbGVtLnBhcmVudCgnbGknKS5hdHRyKCdhcmlhLWV4cGFuZGVkJywgZmFsc2UpO1xuICAgICRlbGVtLmF0dHIoJ2FyaWEtaGlkZGVuJywgdHJ1ZSkuYWRkQ2xhc3MoJ2lzLWNsb3NpbmcnKVxuICAgICRlbGVtLmFkZENsYXNzKCdpcy1jbG9zaW5nJylcbiAgICAgICAgIC5vbmUoRm91bmRhdGlvbi50cmFuc2l0aW9uZW5kKCRlbGVtKSwgZnVuY3Rpb24oKXtcbiAgICAgICAgICAgJGVsZW0ucmVtb3ZlQ2xhc3MoJ2lzLWFjdGl2ZSBpcy1jbG9zaW5nJyk7XG4gICAgICAgICAgICRlbGVtLmJsdXIoKTtcbiAgICAgICAgIH0pO1xuICAgIC8qKlxuICAgICAqIEZpcmVzIHdoZW4gdGhlIHN1Ym1lbnUgaGFzIGNsb3NlZC5cbiAgICAgKiBAZXZlbnQgRHJpbGxkb3duI2hpZGVcbiAgICAgKi9cbiAgICAkZWxlbS50cmlnZ2VyKCdoaWRlLnpmLmRyaWxsZG93bicsIFskZWxlbV0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEl0ZXJhdGVzIHRocm91Z2ggdGhlIG5lc3RlZCBtZW51cyB0byBjYWxjdWxhdGUgdGhlIG1pbi1oZWlnaHQsIGFuZCBtYXgtd2lkdGggZm9yIHRoZSBtZW51LlxuICAgKiBQcmV2ZW50cyBjb250ZW50IGp1bXBpbmcuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2dldE1heERpbXMoKSB7XG4gICAgdmFyICBtYXhIZWlnaHQgPSAwLCByZXN1bHQgPSB7fSwgX3RoaXMgPSB0aGlzO1xuICAgIHRoaXMuJHN1Ym1lbnVzLmFkZCh0aGlzLiRlbGVtZW50KS5lYWNoKGZ1bmN0aW9uKCl7XG4gICAgICB2YXIgbnVtT2ZFbGVtcyA9ICQodGhpcykuY2hpbGRyZW4oJ2xpJykubGVuZ3RoO1xuICAgICAgdmFyIGhlaWdodCA9IEZvdW5kYXRpb24uQm94LkdldERpbWVuc2lvbnModGhpcykuaGVpZ2h0O1xuICAgICAgbWF4SGVpZ2h0ID0gaGVpZ2h0ID4gbWF4SGVpZ2h0ID8gaGVpZ2h0IDogbWF4SGVpZ2h0O1xuICAgICAgaWYoX3RoaXMub3B0aW9ucy5hdXRvSGVpZ2h0KSB7XG4gICAgICAgICQodGhpcykuZGF0YSgnY2FsY0hlaWdodCcsaGVpZ2h0KTtcbiAgICAgICAgaWYgKCEkKHRoaXMpLmhhc0NsYXNzKCdpcy1kcmlsbGRvd24tc3VibWVudScpKSByZXN1bHRbJ2hlaWdodCddID0gaGVpZ2h0O1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgaWYoIXRoaXMub3B0aW9ucy5hdXRvSGVpZ2h0KSByZXN1bHRbJ21pbi1oZWlnaHQnXSA9IGAke21heEhlaWdodH1weGA7XG5cbiAgICByZXN1bHRbJ21heC13aWR0aCddID0gYCR7dGhpcy4kZWxlbWVudFswXS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aH1weGA7XG5cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgLyoqXG4gICAqIERlc3Ryb3lzIHRoZSBEcmlsbGRvd24gTWVudVxuICAgKiBAZnVuY3Rpb25cbiAgICovXG4gIGRlc3Ryb3koKSB7XG4gICAgaWYodGhpcy5vcHRpb25zLnNjcm9sbFRvcCkgdGhpcy4kZWxlbWVudC5vZmYoJy56Zi5kcmlsbGRvd24nLHRoaXMuX2JpbmRIYW5kbGVyKTtcbiAgICB0aGlzLl9oaWRlQWxsKCk7XG5cdCAgdGhpcy4kZWxlbWVudC5vZmYoJ211dGF0ZW1lLnpmLnRyaWdnZXInKTtcbiAgICBGb3VuZGF0aW9uLk5lc3QuQnVybih0aGlzLiRlbGVtZW50LCAnZHJpbGxkb3duJyk7XG4gICAgdGhpcy4kZWxlbWVudC51bndyYXAoKVxuICAgICAgICAgICAgICAgICAuZmluZCgnLmpzLWRyaWxsZG93bi1iYWNrLCAuaXMtc3VibWVudS1wYXJlbnQtaXRlbScpLnJlbW92ZSgpXG4gICAgICAgICAgICAgICAgIC5lbmQoKS5maW5kKCcuaXMtYWN0aXZlLCAuaXMtY2xvc2luZywgLmlzLWRyaWxsZG93bi1zdWJtZW51JykucmVtb3ZlQ2xhc3MoJ2lzLWFjdGl2ZSBpcy1jbG9zaW5nIGlzLWRyaWxsZG93bi1zdWJtZW51JylcbiAgICAgICAgICAgICAgICAgLmVuZCgpLmZpbmQoJ1tkYXRhLXN1Ym1lbnVdJykucmVtb3ZlQXR0cignYXJpYS1oaWRkZW4gdGFiaW5kZXggcm9sZScpO1xuICAgIHRoaXMuJHN1Ym1lbnVBbmNob3JzLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAkKHRoaXMpLm9mZignLnpmLmRyaWxsZG93bicpO1xuICAgIH0pO1xuXG4gICAgdGhpcy4kc3VibWVudXMucmVtb3ZlQ2xhc3MoJ2RyaWxsZG93bi1zdWJtZW51LWNvdmVyLXByZXZpb3VzJyk7XG5cbiAgICB0aGlzLiRlbGVtZW50LmZpbmQoJ2EnKS5lYWNoKGZ1bmN0aW9uKCl7XG4gICAgICB2YXIgJGxpbmsgPSAkKHRoaXMpO1xuICAgICAgJGxpbmsucmVtb3ZlQXR0cigndGFiaW5kZXgnKTtcbiAgICAgIGlmKCRsaW5rLmRhdGEoJ3NhdmVkSHJlZicpKXtcbiAgICAgICAgJGxpbmsuYXR0cignaHJlZicsICRsaW5rLmRhdGEoJ3NhdmVkSHJlZicpKS5yZW1vdmVEYXRhKCdzYXZlZEhyZWYnKTtcbiAgICAgIH1lbHNleyByZXR1cm47IH1cbiAgICB9KTtcbiAgICBGb3VuZGF0aW9uLnVucmVnaXN0ZXJQbHVnaW4odGhpcyk7XG4gIH07XG59XG5cbkRyaWxsZG93bi5kZWZhdWx0cyA9IHtcbiAgLyoqXG4gICAqIE1hcmt1cCB1c2VkIGZvciBKUyBnZW5lcmF0ZWQgYmFjayBidXR0b24uIFByZXBlbmRlZCAgb3IgYXBwZW5kZWQgKHNlZSBiYWNrQnV0dG9uUG9zaXRpb24pIHRvIHN1Ym1lbnUgbGlzdHMgYW5kIGRlbGV0ZWQgb24gYGRlc3Ryb3lgIG1ldGhvZCwgJ2pzLWRyaWxsZG93bi1iYWNrJyBjbGFzcyByZXF1aXJlZC4gUmVtb3ZlIHRoZSBiYWNrc2xhc2ggKGBcXGApIGlmIGNvcHkgYW5kIHBhc3RpbmcuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgJzxcXGxpPjxcXGE+QmFjazxcXC9hPjxcXC9saT4nXG4gICAqL1xuICBiYWNrQnV0dG9uOiAnPGxpIGNsYXNzPVwianMtZHJpbGxkb3duLWJhY2tcIj48YSB0YWJpbmRleD1cIjBcIj5CYWNrPC9hPjwvbGk+JyxcbiAgLyoqXG4gICAqIFBvc2l0aW9uIHRoZSBiYWNrIGJ1dHRvbiBlaXRoZXIgYXQgdGhlIHRvcCBvciBib3R0b20gb2YgZHJpbGxkb3duIHN1Ym1lbnVzLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGJvdHRvbVxuICAgKi9cbiAgYmFja0J1dHRvblBvc2l0aW9uOiAndG9wJyxcbiAgLyoqXG4gICAqIE1hcmt1cCB1c2VkIHRvIHdyYXAgZHJpbGxkb3duIG1lbnUuIFVzZSBhIGNsYXNzIG5hbWUgZm9yIGluZGVwZW5kZW50IHN0eWxpbmc7IHRoZSBKUyBhcHBsaWVkIGNsYXNzOiBgaXMtZHJpbGxkb3duYCBpcyByZXF1aXJlZC4gUmVtb3ZlIHRoZSBiYWNrc2xhc2ggKGBcXGApIGlmIGNvcHkgYW5kIHBhc3RpbmcuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgJzxcXGRpdiBjbGFzcz1cImlzLWRyaWxsZG93blwiPjxcXC9kaXY+J1xuICAgKi9cbiAgd3JhcHBlcjogJzxkaXY+PC9kaXY+JyxcbiAgLyoqXG4gICAqIEFkZHMgdGhlIHBhcmVudCBsaW5rIHRvIHRoZSBzdWJtZW51LlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICBwYXJlbnRMaW5rOiBmYWxzZSxcbiAgLyoqXG4gICAqIEFsbG93IHRoZSBtZW51IHRvIHJldHVybiB0byByb290IGxpc3Qgb24gYm9keSBjbGljay5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBmYWxzZVxuICAgKi9cbiAgY2xvc2VPbkNsaWNrOiBmYWxzZSxcbiAgLyoqXG4gICAqIEFsbG93IHRoZSBtZW51IHRvIGF1dG8gYWRqdXN0IGhlaWdodC5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBmYWxzZVxuICAgKi9cbiAgYXV0b0hlaWdodDogZmFsc2UsXG4gIC8qKlxuICAgKiBBbmltYXRlIHRoZSBhdXRvIGFkanVzdCBoZWlnaHQuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgZmFsc2VcbiAgICovXG4gIGFuaW1hdGVIZWlnaHQ6IGZhbHNlLFxuICAvKipcbiAgICogU2Nyb2xsIHRvIHRoZSB0b3Agb2YgdGhlIG1lbnUgYWZ0ZXIgb3BlbmluZyBhIHN1Ym1lbnUgb3IgbmF2aWdhdGluZyBiYWNrIHVzaW5nIHRoZSBtZW51IGJhY2sgYnV0dG9uXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgZmFsc2VcbiAgICovXG4gIHNjcm9sbFRvcDogZmFsc2UsXG4gIC8qKlxuICAgKiBTdHJpbmcganF1ZXJ5IHNlbGVjdG9yIChmb3IgZXhhbXBsZSAnYm9keScpIG9mIGVsZW1lbnQgdG8gdGFrZSBvZmZzZXQoKS50b3AgZnJvbSwgaWYgZW1wdHkgc3RyaW5nIHRoZSBkcmlsbGRvd24gbWVudSBvZmZzZXQoKS50b3AgaXMgdGFrZW5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnJ1xuICAgKi9cbiAgc2Nyb2xsVG9wRWxlbWVudDogJycsXG4gIC8qKlxuICAgKiBTY3JvbGxUb3Agb2Zmc2V0XG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgMTAwXG4gICAqL1xuICBzY3JvbGxUb3BPZmZzZXQ6IDAsXG4gIC8qKlxuICAgKiBTY3JvbGwgYW5pbWF0aW9uIGR1cmF0aW9uXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgNTAwXG4gICAqL1xuICBhbmltYXRpb25EdXJhdGlvbjogNTAwLFxuICAvKipcbiAgICogU2Nyb2xsIGFuaW1hdGlvbiBlYXNpbmdcbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnc3dpbmcnXG4gICAqL1xuICBhbmltYXRpb25FYXNpbmc6ICdzd2luZydcbiAgLy8gaG9sZE9wZW46IGZhbHNlXG59O1xuXG4vLyBXaW5kb3cgZXhwb3J0c1xuRm91bmRhdGlvbi5wbHVnaW4oRHJpbGxkb3duLCAnRHJpbGxkb3duJyk7XG5cbn0oalF1ZXJ5KTtcbiIsIid1c2Ugc3RyaWN0JztcblxuIWZ1bmN0aW9uKCQpIHtcblxuLyoqXG4gKiBEcm9wZG93biBtb2R1bGUuXG4gKiBAbW9kdWxlIGZvdW5kYXRpb24uZHJvcGRvd25cbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwua2V5Ym9hcmRcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwuYm94XG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLnRyaWdnZXJzXG4gKi9cblxuY2xhc3MgRHJvcGRvd24ge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBpbnN0YW5jZSBvZiBhIGRyb3Bkb3duLlxuICAgKiBAY2xhc3NcbiAgICogQHBhcmFtIHtqUXVlcnl9IGVsZW1lbnQgLSBqUXVlcnkgb2JqZWN0IHRvIG1ha2UgaW50byBhIGRyb3Bkb3duLlxuICAgKiAgICAgICAgT2JqZWN0IHNob3VsZCBiZSBvZiB0aGUgZHJvcGRvd24gcGFuZWwsIHJhdGhlciB0aGFuIGl0cyBhbmNob3IuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zIC0gT3ZlcnJpZGVzIHRvIHRoZSBkZWZhdWx0IHBsdWdpbiBzZXR0aW5ncy5cbiAgICovXG4gIGNvbnN0cnVjdG9yKGVsZW1lbnQsIG9wdGlvbnMpIHtcbiAgICB0aGlzLiRlbGVtZW50ID0gZWxlbWVudDtcbiAgICB0aGlzLm9wdGlvbnMgPSAkLmV4dGVuZCh7fSwgRHJvcGRvd24uZGVmYXVsdHMsIHRoaXMuJGVsZW1lbnQuZGF0YSgpLCBvcHRpb25zKTtcbiAgICB0aGlzLl9pbml0KCk7XG5cbiAgICBGb3VuZGF0aW9uLnJlZ2lzdGVyUGx1Z2luKHRoaXMsICdEcm9wZG93bicpO1xuICAgIEZvdW5kYXRpb24uS2V5Ym9hcmQucmVnaXN0ZXIoJ0Ryb3Bkb3duJywge1xuICAgICAgJ0VOVEVSJzogJ29wZW4nLFxuICAgICAgJ1NQQUNFJzogJ29wZW4nLFxuICAgICAgJ0VTQ0FQRSc6ICdjbG9zZSdcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyB0aGUgcGx1Z2luIGJ5IHNldHRpbmcvY2hlY2tpbmcgb3B0aW9ucyBhbmQgYXR0cmlidXRlcywgYWRkaW5nIGhlbHBlciB2YXJpYWJsZXMsIGFuZCBzYXZpbmcgdGhlIGFuY2hvci5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfaW5pdCgpIHtcbiAgICB2YXIgJGlkID0gdGhpcy4kZWxlbWVudC5hdHRyKCdpZCcpO1xuXG4gICAgdGhpcy4kYW5jaG9yID0gJChgW2RhdGEtdG9nZ2xlPVwiJHskaWR9XCJdYCkubGVuZ3RoID8gJChgW2RhdGEtdG9nZ2xlPVwiJHskaWR9XCJdYCkgOiAkKGBbZGF0YS1vcGVuPVwiJHskaWR9XCJdYCk7XG4gICAgdGhpcy4kYW5jaG9yLmF0dHIoe1xuICAgICAgJ2FyaWEtY29udHJvbHMnOiAkaWQsXG4gICAgICAnZGF0YS1pcy1mb2N1cyc6IGZhbHNlLFxuICAgICAgJ2RhdGEteWV0aS1ib3gnOiAkaWQsXG4gICAgICAnYXJpYS1oYXNwb3B1cCc6IHRydWUsXG4gICAgICAnYXJpYS1leHBhbmRlZCc6IGZhbHNlXG5cbiAgICB9KTtcblxuICAgIGlmKHRoaXMub3B0aW9ucy5wYXJlbnRDbGFzcyl7XG4gICAgICB0aGlzLiRwYXJlbnQgPSB0aGlzLiRlbGVtZW50LnBhcmVudHMoJy4nICsgdGhpcy5vcHRpb25zLnBhcmVudENsYXNzKTtcbiAgICB9ZWxzZXtcbiAgICAgIHRoaXMuJHBhcmVudCA9IG51bGw7XG4gICAgfVxuICAgIHRoaXMub3B0aW9ucy5wb3NpdGlvbkNsYXNzID0gdGhpcy5nZXRQb3NpdGlvbkNsYXNzKCk7XG4gICAgdGhpcy5jb3VudGVyID0gNDtcbiAgICB0aGlzLnVzZWRQb3NpdGlvbnMgPSBbXTtcbiAgICB0aGlzLiRlbGVtZW50LmF0dHIoe1xuICAgICAgJ2FyaWEtaGlkZGVuJzogJ3RydWUnLFxuICAgICAgJ2RhdGEteWV0aS1ib3gnOiAkaWQsXG4gICAgICAnZGF0YS1yZXNpemUnOiAkaWQsXG4gICAgICAnYXJpYS1sYWJlbGxlZGJ5JzogdGhpcy4kYW5jaG9yWzBdLmlkIHx8IEZvdW5kYXRpb24uR2V0WW9EaWdpdHMoNiwgJ2RkLWFuY2hvcicpXG4gICAgfSk7XG4gICAgdGhpcy5fZXZlbnRzKCk7XG4gIH1cblxuICAvKipcbiAgICogSGVscGVyIGZ1bmN0aW9uIHRvIGRldGVybWluZSBjdXJyZW50IG9yaWVudGF0aW9uIG9mIGRyb3Bkb3duIHBhbmUuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcmV0dXJucyB7U3RyaW5nfSBwb3NpdGlvbiAtIHN0cmluZyB2YWx1ZSBvZiBhIHBvc2l0aW9uIGNsYXNzLlxuICAgKi9cbiAgZ2V0UG9zaXRpb25DbGFzcygpIHtcbiAgICB2YXIgdmVydGljYWxQb3NpdGlvbiA9IHRoaXMuJGVsZW1lbnRbMF0uY2xhc3NOYW1lLm1hdGNoKC8odG9wfGxlZnR8cmlnaHR8Ym90dG9tKS9nKTtcbiAgICAgICAgdmVydGljYWxQb3NpdGlvbiA9IHZlcnRpY2FsUG9zaXRpb24gPyB2ZXJ0aWNhbFBvc2l0aW9uWzBdIDogJyc7XG4gICAgdmFyIGhvcml6b250YWxQb3NpdGlvbiA9IC9mbG9hdC0oXFxTKykvLmV4ZWModGhpcy4kYW5jaG9yWzBdLmNsYXNzTmFtZSk7XG4gICAgICAgIGhvcml6b250YWxQb3NpdGlvbiA9IGhvcml6b250YWxQb3NpdGlvbiA/IGhvcml6b250YWxQb3NpdGlvblsxXSA6ICcnO1xuICAgIHZhciBwb3NpdGlvbiA9IGhvcml6b250YWxQb3NpdGlvbiA/IGhvcml6b250YWxQb3NpdGlvbiArICcgJyArIHZlcnRpY2FsUG9zaXRpb24gOiB2ZXJ0aWNhbFBvc2l0aW9uO1xuXG4gICAgcmV0dXJuIHBvc2l0aW9uO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkanVzdHMgdGhlIGRyb3Bkb3duIHBhbmVzIG9yaWVudGF0aW9uIGJ5IGFkZGluZy9yZW1vdmluZyBwb3NpdGlvbmluZyBjbGFzc2VzLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICogQHBhcmFtIHtTdHJpbmd9IHBvc2l0aW9uIC0gcG9zaXRpb24gY2xhc3MgdG8gcmVtb3ZlLlxuICAgKi9cbiAgX3JlcG9zaXRpb24ocG9zaXRpb24pIHtcbiAgICB0aGlzLnVzZWRQb3NpdGlvbnMucHVzaChwb3NpdGlvbiA/IHBvc2l0aW9uIDogJ2JvdHRvbScpO1xuICAgIC8vZGVmYXVsdCwgdHJ5IHN3aXRjaGluZyB0byBvcHBvc2l0ZSBzaWRlXG4gICAgaWYoIXBvc2l0aW9uICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZigndG9wJykgPCAwKSl7XG4gICAgICB0aGlzLiRlbGVtZW50LmFkZENsYXNzKCd0b3AnKTtcbiAgICB9ZWxzZSBpZihwb3NpdGlvbiA9PT0gJ3RvcCcgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdib3R0b20nKSA8IDApKXtcbiAgICAgIHRoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3MocG9zaXRpb24pO1xuICAgIH1lbHNlIGlmKHBvc2l0aW9uID09PSAnbGVmdCcgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdyaWdodCcpIDwgMCkpe1xuICAgICAgdGhpcy4kZWxlbWVudC5yZW1vdmVDbGFzcyhwb3NpdGlvbilcbiAgICAgICAgICAuYWRkQ2xhc3MoJ3JpZ2h0Jyk7XG4gICAgfWVsc2UgaWYocG9zaXRpb24gPT09ICdyaWdodCcgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdsZWZ0JykgPCAwKSl7XG4gICAgICB0aGlzLiRlbGVtZW50LnJlbW92ZUNsYXNzKHBvc2l0aW9uKVxuICAgICAgICAgIC5hZGRDbGFzcygnbGVmdCcpO1xuICAgIH1cblxuICAgIC8vaWYgZGVmYXVsdCBjaGFuZ2UgZGlkbid0IHdvcmssIHRyeSBib3R0b20gb3IgbGVmdCBmaXJzdFxuICAgIGVsc2UgaWYoIXBvc2l0aW9uICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZigndG9wJykgPiAtMSkgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdsZWZ0JykgPCAwKSl7XG4gICAgICB0aGlzLiRlbGVtZW50LmFkZENsYXNzKCdsZWZ0Jyk7XG4gICAgfWVsc2UgaWYocG9zaXRpb24gPT09ICd0b3AnICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZignYm90dG9tJykgPiAtMSkgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdsZWZ0JykgPCAwKSl7XG4gICAgICB0aGlzLiRlbGVtZW50LnJlbW92ZUNsYXNzKHBvc2l0aW9uKVxuICAgICAgICAgIC5hZGRDbGFzcygnbGVmdCcpO1xuICAgIH1lbHNlIGlmKHBvc2l0aW9uID09PSAnbGVmdCcgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdyaWdodCcpID4gLTEpICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZignYm90dG9tJykgPCAwKSl7XG4gICAgICB0aGlzLiRlbGVtZW50LnJlbW92ZUNsYXNzKHBvc2l0aW9uKTtcbiAgICB9ZWxzZSBpZihwb3NpdGlvbiA9PT0gJ3JpZ2h0JyAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2xlZnQnKSA+IC0xKSAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2JvdHRvbScpIDwgMCkpe1xuICAgICAgdGhpcy4kZWxlbWVudC5yZW1vdmVDbGFzcyhwb3NpdGlvbik7XG4gICAgfVxuICAgIC8vaWYgbm90aGluZyBjbGVhcmVkLCBzZXQgdG8gYm90dG9tXG4gICAgZWxzZXtcbiAgICAgIHRoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3MocG9zaXRpb24pO1xuICAgIH1cbiAgICB0aGlzLmNsYXNzQ2hhbmdlZCA9IHRydWU7XG4gICAgdGhpcy5jb3VudGVyLS07XG4gIH1cblxuICAvKipcbiAgICogU2V0cyB0aGUgcG9zaXRpb24gYW5kIG9yaWVudGF0aW9uIG9mIHRoZSBkcm9wZG93biBwYW5lLCBjaGVja3MgZm9yIGNvbGxpc2lvbnMuXG4gICAqIFJlY3Vyc2l2ZWx5IGNhbGxzIGl0c2VsZiBpZiBhIGNvbGxpc2lvbiBpcyBkZXRlY3RlZCwgd2l0aCBhIG5ldyBwb3NpdGlvbiBjbGFzcy5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfc2V0UG9zaXRpb24oKSB7XG4gICAgaWYodGhpcy4kYW5jaG9yLmF0dHIoJ2FyaWEtZXhwYW5kZWQnKSA9PT0gJ2ZhbHNlJyl7IHJldHVybiBmYWxzZTsgfVxuICAgIHZhciBwb3NpdGlvbiA9IHRoaXMuZ2V0UG9zaXRpb25DbGFzcygpLFxuICAgICAgICAkZWxlRGltcyA9IEZvdW5kYXRpb24uQm94LkdldERpbWVuc2lvbnModGhpcy4kZWxlbWVudCksXG4gICAgICAgICRhbmNob3JEaW1zID0gRm91bmRhdGlvbi5Cb3guR2V0RGltZW5zaW9ucyh0aGlzLiRhbmNob3IpLFxuICAgICAgICBfdGhpcyA9IHRoaXMsXG4gICAgICAgIGRpcmVjdGlvbiA9IChwb3NpdGlvbiA9PT0gJ2xlZnQnID8gJ2xlZnQnIDogKChwb3NpdGlvbiA9PT0gJ3JpZ2h0JykgPyAnbGVmdCcgOiAndG9wJykpLFxuICAgICAgICBwYXJhbSA9IChkaXJlY3Rpb24gPT09ICd0b3AnKSA/ICdoZWlnaHQnIDogJ3dpZHRoJyxcbiAgICAgICAgb2Zmc2V0ID0gKHBhcmFtID09PSAnaGVpZ2h0JykgPyB0aGlzLm9wdGlvbnMudk9mZnNldCA6IHRoaXMub3B0aW9ucy5oT2Zmc2V0O1xuXG4gICAgaWYoKCRlbGVEaW1zLndpZHRoID49ICRlbGVEaW1zLndpbmRvd0RpbXMud2lkdGgpIHx8ICghdGhpcy5jb3VudGVyICYmICFGb3VuZGF0aW9uLkJveC5JbU5vdFRvdWNoaW5nWW91KHRoaXMuJGVsZW1lbnQsIHRoaXMuJHBhcmVudCkpKXtcbiAgICAgIHZhciBuZXdXaWR0aCA9ICRlbGVEaW1zLndpbmRvd0RpbXMud2lkdGgsXG4gICAgICAgICAgcGFyZW50SE9mZnNldCA9IDA7XG4gICAgICBpZih0aGlzLiRwYXJlbnQpe1xuICAgICAgICB2YXIgJHBhcmVudERpbXMgPSBGb3VuZGF0aW9uLkJveC5HZXREaW1lbnNpb25zKHRoaXMuJHBhcmVudCksXG4gICAgICAgICAgICBwYXJlbnRIT2Zmc2V0ID0gJHBhcmVudERpbXMub2Zmc2V0LmxlZnQ7XG4gICAgICAgIGlmICgkcGFyZW50RGltcy53aWR0aCA8IG5ld1dpZHRoKXtcbiAgICAgICAgICBuZXdXaWR0aCA9ICRwYXJlbnREaW1zLndpZHRoO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHRoaXMuJGVsZW1lbnQub2Zmc2V0KEZvdW5kYXRpb24uQm94LkdldE9mZnNldHModGhpcy4kZWxlbWVudCwgdGhpcy4kYW5jaG9yLCAnY2VudGVyIGJvdHRvbScsIHRoaXMub3B0aW9ucy52T2Zmc2V0LCB0aGlzLm9wdGlvbnMuaE9mZnNldCArIHBhcmVudEhPZmZzZXQsIHRydWUpKS5jc3Moe1xuICAgICAgICAnd2lkdGgnOiBuZXdXaWR0aCAtICh0aGlzLm9wdGlvbnMuaE9mZnNldCAqIDIpLFxuICAgICAgICAnaGVpZ2h0JzogJ2F1dG8nXG4gICAgICB9KTtcbiAgICAgIHRoaXMuY2xhc3NDaGFuZ2VkID0gdHJ1ZTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICB0aGlzLiRlbGVtZW50Lm9mZnNldChGb3VuZGF0aW9uLkJveC5HZXRPZmZzZXRzKHRoaXMuJGVsZW1lbnQsIHRoaXMuJGFuY2hvciwgcG9zaXRpb24sIHRoaXMub3B0aW9ucy52T2Zmc2V0LCB0aGlzLm9wdGlvbnMuaE9mZnNldCkpO1xuXG4gICAgd2hpbGUoIUZvdW5kYXRpb24uQm94LkltTm90VG91Y2hpbmdZb3UodGhpcy4kZWxlbWVudCwgdGhpcy4kcGFyZW50LCB0cnVlKSAmJiB0aGlzLmNvdW50ZXIpe1xuICAgICAgdGhpcy5fcmVwb3NpdGlvbihwb3NpdGlvbik7XG4gICAgICB0aGlzLl9zZXRQb3NpdGlvbigpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGV2ZW50IGxpc3RlbmVycyB0byB0aGUgZWxlbWVudCB1dGlsaXppbmcgdGhlIHRyaWdnZXJzIHV0aWxpdHkgbGlicmFyeS5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfZXZlbnRzKCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgdGhpcy4kZWxlbWVudC5vbih7XG4gICAgICAnb3Blbi56Zi50cmlnZ2VyJzogdGhpcy5vcGVuLmJpbmQodGhpcyksXG4gICAgICAnY2xvc2UuemYudHJpZ2dlcic6IHRoaXMuY2xvc2UuYmluZCh0aGlzKSxcbiAgICAgICd0b2dnbGUuemYudHJpZ2dlcic6IHRoaXMudG9nZ2xlLmJpbmQodGhpcyksXG4gICAgICAncmVzaXplbWUuemYudHJpZ2dlcic6IHRoaXMuX3NldFBvc2l0aW9uLmJpbmQodGhpcylcbiAgICB9KTtcblxuICAgIGlmKHRoaXMub3B0aW9ucy5ob3Zlcil7XG4gICAgICB0aGlzLiRhbmNob3Iub2ZmKCdtb3VzZWVudGVyLnpmLmRyb3Bkb3duIG1vdXNlbGVhdmUuemYuZHJvcGRvd24nKVxuICAgICAgLm9uKCdtb3VzZWVudGVyLnpmLmRyb3Bkb3duJywgZnVuY3Rpb24oKXtcbiAgICAgICAgdmFyIGJvZHlEYXRhID0gJCgnYm9keScpLmRhdGEoKTtcbiAgICAgICAgaWYodHlwZW9mKGJvZHlEYXRhLndoYXRpbnB1dCkgPT09ICd1bmRlZmluZWQnIHx8IGJvZHlEYXRhLndoYXRpbnB1dCA9PT0gJ21vdXNlJykge1xuICAgICAgICAgIGNsZWFyVGltZW91dChfdGhpcy50aW1lb3V0KTtcbiAgICAgICAgICBfdGhpcy50aW1lb3V0ID0gc2V0VGltZW91dChmdW5jdGlvbigpe1xuICAgICAgICAgICAgX3RoaXMub3BlbigpO1xuICAgICAgICAgICAgX3RoaXMuJGFuY2hvci5kYXRhKCdob3ZlcicsIHRydWUpO1xuICAgICAgICAgIH0sIF90aGlzLm9wdGlvbnMuaG92ZXJEZWxheSk7XG4gICAgICAgIH1cbiAgICAgIH0pLm9uKCdtb3VzZWxlYXZlLnpmLmRyb3Bkb3duJywgZnVuY3Rpb24oKXtcbiAgICAgICAgY2xlYXJUaW1lb3V0KF90aGlzLnRpbWVvdXQpO1xuICAgICAgICBfdGhpcy50aW1lb3V0ID0gc2V0VGltZW91dChmdW5jdGlvbigpe1xuICAgICAgICAgIF90aGlzLmNsb3NlKCk7XG4gICAgICAgICAgX3RoaXMuJGFuY2hvci5kYXRhKCdob3ZlcicsIGZhbHNlKTtcbiAgICAgICAgfSwgX3RoaXMub3B0aW9ucy5ob3ZlckRlbGF5KTtcbiAgICAgIH0pO1xuICAgICAgaWYodGhpcy5vcHRpb25zLmhvdmVyUGFuZSl7XG4gICAgICAgIHRoaXMuJGVsZW1lbnQub2ZmKCdtb3VzZWVudGVyLnpmLmRyb3Bkb3duIG1vdXNlbGVhdmUuemYuZHJvcGRvd24nKVxuICAgICAgICAgICAgLm9uKCdtb3VzZWVudGVyLnpmLmRyb3Bkb3duJywgZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KF90aGlzLnRpbWVvdXQpO1xuICAgICAgICAgICAgfSkub24oJ21vdXNlbGVhdmUuemYuZHJvcGRvd24nLCBmdW5jdGlvbigpe1xuICAgICAgICAgICAgICBjbGVhclRpbWVvdXQoX3RoaXMudGltZW91dCk7XG4gICAgICAgICAgICAgIF90aGlzLnRpbWVvdXQgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgX3RoaXMuY2xvc2UoKTtcbiAgICAgICAgICAgICAgICBfdGhpcy4kYW5jaG9yLmRhdGEoJ2hvdmVyJywgZmFsc2UpO1xuICAgICAgICAgICAgICB9LCBfdGhpcy5vcHRpb25zLmhvdmVyRGVsYXkpO1xuICAgICAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMuJGFuY2hvci5hZGQodGhpcy4kZWxlbWVudCkub24oJ2tleWRvd24uemYuZHJvcGRvd24nLCBmdW5jdGlvbihlKSB7XG5cbiAgICAgIHZhciAkdGFyZ2V0ID0gJCh0aGlzKSxcbiAgICAgICAgdmlzaWJsZUZvY3VzYWJsZUVsZW1lbnRzID0gRm91bmRhdGlvbi5LZXlib2FyZC5maW5kRm9jdXNhYmxlKF90aGlzLiRlbGVtZW50KTtcblxuICAgICAgRm91bmRhdGlvbi5LZXlib2FyZC5oYW5kbGVLZXkoZSwgJ0Ryb3Bkb3duJywge1xuICAgICAgICBvcGVuOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICBpZiAoJHRhcmdldC5pcyhfdGhpcy4kYW5jaG9yKSkge1xuICAgICAgICAgICAgX3RoaXMub3BlbigpO1xuICAgICAgICAgICAgX3RoaXMuJGVsZW1lbnQuYXR0cigndGFiaW5kZXgnLCAtMSkuZm9jdXMoKTtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIGNsb3NlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICBfdGhpcy5jbG9zZSgpO1xuICAgICAgICAgIF90aGlzLiRhbmNob3IuZm9jdXMoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhbiBldmVudCBoYW5kbGVyIHRvIHRoZSBib2R5IHRvIGNsb3NlIGFueSBkcm9wZG93bnMgb24gYSBjbGljay5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfYWRkQm9keUhhbmRsZXIoKSB7XG4gICAgIHZhciAkYm9keSA9ICQoZG9jdW1lbnQuYm9keSkubm90KHRoaXMuJGVsZW1lbnQpLFxuICAgICAgICAgX3RoaXMgPSB0aGlzO1xuICAgICAkYm9keS5vZmYoJ2NsaWNrLnpmLmRyb3Bkb3duJylcbiAgICAgICAgICAub24oJ2NsaWNrLnpmLmRyb3Bkb3duJywgZnVuY3Rpb24oZSl7XG4gICAgICAgICAgICBpZihfdGhpcy4kYW5jaG9yLmlzKGUudGFyZ2V0KSB8fCBfdGhpcy4kYW5jaG9yLmZpbmQoZS50YXJnZXQpLmxlbmd0aCkge1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZihfdGhpcy4kZWxlbWVudC5maW5kKGUudGFyZ2V0KS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3RoaXMuY2xvc2UoKTtcbiAgICAgICAgICAgICRib2R5Lm9mZignY2xpY2suemYuZHJvcGRvd24nKTtcbiAgICAgICAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBPcGVucyB0aGUgZHJvcGRvd24gcGFuZSwgYW5kIGZpcmVzIGEgYnViYmxpbmcgZXZlbnQgdG8gY2xvc2Ugb3RoZXIgZHJvcGRvd25zLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQGZpcmVzIERyb3Bkb3duI2Nsb3NlbWVcbiAgICogQGZpcmVzIERyb3Bkb3duI3Nob3dcbiAgICovXG4gIG9wZW4oKSB7XG4gICAgLy8gdmFyIF90aGlzID0gdGhpcztcbiAgICAvKipcbiAgICAgKiBGaXJlcyB0byBjbG9zZSBvdGhlciBvcGVuIGRyb3Bkb3duc1xuICAgICAqIEBldmVudCBEcm9wZG93biNjbG9zZW1lXG4gICAgICovXG4gICAgdGhpcy4kZWxlbWVudC50cmlnZ2VyKCdjbG9zZW1lLnpmLmRyb3Bkb3duJywgdGhpcy4kZWxlbWVudC5hdHRyKCdpZCcpKTtcbiAgICB0aGlzLiRhbmNob3IuYWRkQ2xhc3MoJ2hvdmVyJylcbiAgICAgICAgLmF0dHIoeydhcmlhLWV4cGFuZGVkJzogdHJ1ZX0pO1xuICAgIC8vIHRoaXMuJGVsZW1lbnQvKi5zaG93KCkqLztcbiAgICB0aGlzLl9zZXRQb3NpdGlvbigpO1xuICAgIHRoaXMuJGVsZW1lbnQuYWRkQ2xhc3MoJ2lzLW9wZW4nKVxuICAgICAgICAuYXR0cih7J2FyaWEtaGlkZGVuJzogZmFsc2V9KTtcblxuICAgIGlmKHRoaXMub3B0aW9ucy5hdXRvRm9jdXMpe1xuICAgICAgdmFyICRmb2N1c2FibGUgPSBGb3VuZGF0aW9uLktleWJvYXJkLmZpbmRGb2N1c2FibGUodGhpcy4kZWxlbWVudCk7XG4gICAgICBpZigkZm9jdXNhYmxlLmxlbmd0aCl7XG4gICAgICAgICRmb2N1c2FibGUuZXEoMCkuZm9jdXMoKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZih0aGlzLm9wdGlvbnMuY2xvc2VPbkNsaWNrKXsgdGhpcy5fYWRkQm9keUhhbmRsZXIoKTsgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy50cmFwRm9jdXMpIHtcbiAgICAgIEZvdW5kYXRpb24uS2V5Ym9hcmQudHJhcEZvY3VzKHRoaXMuJGVsZW1lbnQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZpcmVzIG9uY2UgdGhlIGRyb3Bkb3duIGlzIHZpc2libGUuXG4gICAgICogQGV2ZW50IERyb3Bkb3duI3Nob3dcbiAgICAgKi9cbiAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ3Nob3cuemYuZHJvcGRvd24nLCBbdGhpcy4kZWxlbWVudF0pO1xuICB9XG5cbiAgLyoqXG4gICAqIENsb3NlcyB0aGUgb3BlbiBkcm9wZG93biBwYW5lLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQGZpcmVzIERyb3Bkb3duI2hpZGVcbiAgICovXG4gIGNsb3NlKCkge1xuICAgIGlmKCF0aGlzLiRlbGVtZW50Lmhhc0NsYXNzKCdpcy1vcGVuJykpe1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICB0aGlzLiRlbGVtZW50LnJlbW92ZUNsYXNzKCdpcy1vcGVuJylcbiAgICAgICAgLmF0dHIoeydhcmlhLWhpZGRlbic6IHRydWV9KTtcblxuICAgIHRoaXMuJGFuY2hvci5yZW1vdmVDbGFzcygnaG92ZXInKVxuICAgICAgICAuYXR0cignYXJpYS1leHBhbmRlZCcsIGZhbHNlKTtcblxuICAgIGlmKHRoaXMuY2xhc3NDaGFuZ2VkKXtcbiAgICAgIHZhciBjdXJQb3NpdGlvbkNsYXNzID0gdGhpcy5nZXRQb3NpdGlvbkNsYXNzKCk7XG4gICAgICBpZihjdXJQb3NpdGlvbkNsYXNzKXtcbiAgICAgICAgdGhpcy4kZWxlbWVudC5yZW1vdmVDbGFzcyhjdXJQb3NpdGlvbkNsYXNzKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuJGVsZW1lbnQuYWRkQ2xhc3ModGhpcy5vcHRpb25zLnBvc2l0aW9uQ2xhc3MpXG4gICAgICAgICAgLyouaGlkZSgpKi8uY3NzKHtoZWlnaHQ6ICcnLCB3aWR0aDogJyd9KTtcbiAgICAgIHRoaXMuY2xhc3NDaGFuZ2VkID0gZmFsc2U7XG4gICAgICB0aGlzLmNvdW50ZXIgPSA0O1xuICAgICAgdGhpcy51c2VkUG9zaXRpb25zLmxlbmd0aCA9IDA7XG4gICAgfVxuICAgIHRoaXMuJGVsZW1lbnQudHJpZ2dlcignaGlkZS56Zi5kcm9wZG93bicsIFt0aGlzLiRlbGVtZW50XSk7XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLnRyYXBGb2N1cykge1xuICAgICAgRm91bmRhdGlvbi5LZXlib2FyZC5yZWxlYXNlRm9jdXModGhpcy4kZWxlbWVudCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFRvZ2dsZXMgdGhlIGRyb3Bkb3duIHBhbmUncyB2aXNpYmlsaXR5LlxuICAgKiBAZnVuY3Rpb25cbiAgICovXG4gIHRvZ2dsZSgpIHtcbiAgICBpZih0aGlzLiRlbGVtZW50Lmhhc0NsYXNzKCdpcy1vcGVuJykpe1xuICAgICAgaWYodGhpcy4kYW5jaG9yLmRhdGEoJ2hvdmVyJykpIHJldHVybjtcbiAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICB9ZWxzZXtcbiAgICAgIHRoaXMub3BlbigpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBEZXN0cm95cyB0aGUgZHJvcGRvd24uXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLiRlbGVtZW50Lm9mZignLnpmLnRyaWdnZXInKS5oaWRlKCk7XG4gICAgdGhpcy4kYW5jaG9yLm9mZignLnpmLmRyb3Bkb3duJyk7XG5cbiAgICBGb3VuZGF0aW9uLnVucmVnaXN0ZXJQbHVnaW4odGhpcyk7XG4gIH1cbn1cblxuRHJvcGRvd24uZGVmYXVsdHMgPSB7XG4gIC8qKlxuICAgKiBDbGFzcyB0aGF0IGRlc2lnbmF0ZXMgYm91bmRpbmcgY29udGFpbmVyIG9mIERyb3Bkb3duIChEZWZhdWx0OiB3aW5kb3cpXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgJ2Ryb3Bkb3duLXBhcmVudCdcbiAgICovXG4gIHBhcmVudENsYXNzOiBudWxsLFxuICAvKipcbiAgICogQW1vdW50IG9mIHRpbWUgdG8gZGVsYXkgb3BlbmluZyBhIHN1Ym1lbnUgb24gaG92ZXIgZXZlbnQuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgMjUwXG4gICAqL1xuICBob3ZlckRlbGF5OiAyNTAsXG4gIC8qKlxuICAgKiBBbGxvdyBzdWJtZW51cyB0byBvcGVuIG9uIGhvdmVyIGV2ZW50c1xuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICBob3ZlcjogZmFsc2UsXG4gIC8qKlxuICAgKiBEb24ndCBjbG9zZSBkcm9wZG93biB3aGVuIGhvdmVyaW5nIG92ZXIgZHJvcGRvd24gcGFuZVxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIHRydWVcbiAgICovXG4gIGhvdmVyUGFuZTogZmFsc2UsXG4gIC8qKlxuICAgKiBOdW1iZXIgb2YgcGl4ZWxzIGJldHdlZW4gdGhlIGRyb3Bkb3duIHBhbmUgYW5kIHRoZSB0cmlnZ2VyaW5nIGVsZW1lbnQgb24gb3Blbi5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAxXG4gICAqL1xuICB2T2Zmc2V0OiAxLFxuICAvKipcbiAgICogTnVtYmVyIG9mIHBpeGVscyBiZXR3ZWVuIHRoZSBkcm9wZG93biBwYW5lIGFuZCB0aGUgdHJpZ2dlcmluZyBlbGVtZW50IG9uIG9wZW4uXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgMVxuICAgKi9cbiAgaE9mZnNldDogMSxcbiAgLyoqXG4gICAqIENsYXNzIGFwcGxpZWQgdG8gYWRqdXN0IG9wZW4gcG9zaXRpb24uIEpTIHdpbGwgdGVzdCBhbmQgZmlsbCB0aGlzIGluLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlICd0b3AnXG4gICAqL1xuICBwb3NpdGlvbkNsYXNzOiAnJyxcbiAgLyoqXG4gICAqIEFsbG93IHRoZSBwbHVnaW4gdG8gdHJhcCBmb2N1cyB0byB0aGUgZHJvcGRvd24gcGFuZSBpZiBvcGVuZWQgd2l0aCBrZXlib2FyZCBjb21tYW5kcy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBmYWxzZVxuICAgKi9cbiAgdHJhcEZvY3VzOiBmYWxzZSxcbiAgLyoqXG4gICAqIEFsbG93IHRoZSBwbHVnaW4gdG8gc2V0IGZvY3VzIHRvIHRoZSBmaXJzdCBmb2N1c2FibGUgZWxlbWVudCB3aXRoaW4gdGhlIHBhbmUsIHJlZ2FyZGxlc3Mgb2YgbWV0aG9kIG9mIG9wZW5pbmcuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgdHJ1ZVxuICAgKi9cbiAgYXV0b0ZvY3VzOiBmYWxzZSxcbiAgLyoqXG4gICAqIEFsbG93cyBhIGNsaWNrIG9uIHRoZSBib2R5IHRvIGNsb3NlIHRoZSBkcm9wZG93bi5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBmYWxzZVxuICAgKi9cbiAgY2xvc2VPbkNsaWNrOiBmYWxzZVxufVxuXG4vLyBXaW5kb3cgZXhwb3J0c1xuRm91bmRhdGlvbi5wbHVnaW4oRHJvcGRvd24sICdEcm9wZG93bicpO1xuXG59KGpRdWVyeSk7XG4iLCIndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbi8qKlxuICogRHJvcGRvd25NZW51IG1vZHVsZS5cbiAqIEBtb2R1bGUgZm91bmRhdGlvbi5kcm9wZG93bi1tZW51XG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLmtleWJvYXJkXG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLmJveFxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC5uZXN0XG4gKi9cblxuY2xhc3MgRHJvcGRvd25NZW51IHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgaW5zdGFuY2Ugb2YgRHJvcGRvd25NZW51LlxuICAgKiBAY2xhc3NcbiAgICogQGZpcmVzIERyb3Bkb3duTWVudSNpbml0XG4gICAqIEBwYXJhbSB7alF1ZXJ5fSBlbGVtZW50IC0galF1ZXJ5IG9iamVjdCB0byBtYWtlIGludG8gYSBkcm9wZG93biBtZW51LlxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyAtIE92ZXJyaWRlcyB0byB0aGUgZGVmYXVsdCBwbHVnaW4gc2V0dGluZ3MuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihlbGVtZW50LCBvcHRpb25zKSB7XG4gICAgdGhpcy4kZWxlbWVudCA9IGVsZW1lbnQ7XG4gICAgdGhpcy5vcHRpb25zID0gJC5leHRlbmQoe30sIERyb3Bkb3duTWVudS5kZWZhdWx0cywgdGhpcy4kZWxlbWVudC5kYXRhKCksIG9wdGlvbnMpO1xuXG4gICAgRm91bmRhdGlvbi5OZXN0LkZlYXRoZXIodGhpcy4kZWxlbWVudCwgJ2Ryb3Bkb3duJyk7XG4gICAgdGhpcy5faW5pdCgpO1xuXG4gICAgRm91bmRhdGlvbi5yZWdpc3RlclBsdWdpbih0aGlzLCAnRHJvcGRvd25NZW51Jyk7XG4gICAgRm91bmRhdGlvbi5LZXlib2FyZC5yZWdpc3RlcignRHJvcGRvd25NZW51Jywge1xuICAgICAgJ0VOVEVSJzogJ29wZW4nLFxuICAgICAgJ1NQQUNFJzogJ29wZW4nLFxuICAgICAgJ0FSUk9XX1JJR0hUJzogJ25leHQnLFxuICAgICAgJ0FSUk9XX1VQJzogJ3VwJyxcbiAgICAgICdBUlJPV19ET1dOJzogJ2Rvd24nLFxuICAgICAgJ0FSUk9XX0xFRlQnOiAncHJldmlvdXMnLFxuICAgICAgJ0VTQ0FQRSc6ICdjbG9zZSdcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyB0aGUgcGx1Z2luLCBhbmQgY2FsbHMgX3ByZXBhcmVNZW51XG4gICAqIEBwcml2YXRlXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgX2luaXQoKSB7XG4gICAgdmFyIHN1YnMgPSB0aGlzLiRlbGVtZW50LmZpbmQoJ2xpLmlzLWRyb3Bkb3duLXN1Ym1lbnUtcGFyZW50Jyk7XG4gICAgdGhpcy4kZWxlbWVudC5jaGlsZHJlbignLmlzLWRyb3Bkb3duLXN1Ym1lbnUtcGFyZW50JykuY2hpbGRyZW4oJy5pcy1kcm9wZG93bi1zdWJtZW51JykuYWRkQ2xhc3MoJ2ZpcnN0LXN1YicpO1xuXG4gICAgdGhpcy4kbWVudUl0ZW1zID0gdGhpcy4kZWxlbWVudC5maW5kKCdbcm9sZT1cIm1lbnVpdGVtXCJdJyk7XG4gICAgdGhpcy4kdGFicyA9IHRoaXMuJGVsZW1lbnQuY2hpbGRyZW4oJ1tyb2xlPVwibWVudWl0ZW1cIl0nKTtcbiAgICB0aGlzLiR0YWJzLmZpbmQoJ3VsLmlzLWRyb3Bkb3duLXN1Ym1lbnUnKS5hZGRDbGFzcyh0aGlzLm9wdGlvbnMudmVydGljYWxDbGFzcyk7XG5cbiAgICBpZiAodGhpcy4kZWxlbWVudC5oYXNDbGFzcyh0aGlzLm9wdGlvbnMucmlnaHRDbGFzcykgfHwgdGhpcy5vcHRpb25zLmFsaWdubWVudCA9PT0gJ3JpZ2h0JyB8fCBGb3VuZGF0aW9uLnJ0bCgpIHx8IHRoaXMuJGVsZW1lbnQucGFyZW50cygnLnRvcC1iYXItcmlnaHQnKS5pcygnKicpKSB7XG4gICAgICB0aGlzLm9wdGlvbnMuYWxpZ25tZW50ID0gJ3JpZ2h0JztcbiAgICAgIHN1YnMuYWRkQ2xhc3MoJ29wZW5zLWxlZnQnKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc3Vicy5hZGRDbGFzcygnb3BlbnMtcmlnaHQnKTtcbiAgICB9XG4gICAgdGhpcy5jaGFuZ2VkID0gZmFsc2U7XG4gICAgdGhpcy5fZXZlbnRzKCk7XG4gIH07XG5cbiAgX2lzVmVydGljYWwoKSB7XG4gICAgcmV0dXJuIHRoaXMuJHRhYnMuY3NzKCdkaXNwbGF5JykgPT09ICdibG9jayc7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBldmVudCBsaXN0ZW5lcnMgdG8gZWxlbWVudHMgd2l0aGluIHRoZSBtZW51XG4gICAqIEBwcml2YXRlXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgX2V2ZW50cygpIHtcbiAgICB2YXIgX3RoaXMgPSB0aGlzLFxuICAgICAgICBoYXNUb3VjaCA9ICdvbnRvdWNoc3RhcnQnIGluIHdpbmRvdyB8fCAodHlwZW9mIHdpbmRvdy5vbnRvdWNoc3RhcnQgIT09ICd1bmRlZmluZWQnKSxcbiAgICAgICAgcGFyQ2xhc3MgPSAnaXMtZHJvcGRvd24tc3VibWVudS1wYXJlbnQnO1xuXG4gICAgLy8gdXNlZCBmb3Igb25DbGljayBhbmQgaW4gdGhlIGtleWJvYXJkIGhhbmRsZXJzXG4gICAgdmFyIGhhbmRsZUNsaWNrRm4gPSBmdW5jdGlvbihlKSB7XG4gICAgICB2YXIgJGVsZW0gPSAkKGUudGFyZ2V0KS5wYXJlbnRzVW50aWwoJ3VsJywgYC4ke3BhckNsYXNzfWApLFxuICAgICAgICAgIGhhc1N1YiA9ICRlbGVtLmhhc0NsYXNzKHBhckNsYXNzKSxcbiAgICAgICAgICBoYXNDbGlja2VkID0gJGVsZW0uYXR0cignZGF0YS1pcy1jbGljaycpID09PSAndHJ1ZScsXG4gICAgICAgICAgJHN1YiA9ICRlbGVtLmNoaWxkcmVuKCcuaXMtZHJvcGRvd24tc3VibWVudScpO1xuXG4gICAgICBpZiAoaGFzU3ViKSB7XG4gICAgICAgIGlmIChoYXNDbGlja2VkKSB7XG4gICAgICAgICAgaWYgKCFfdGhpcy5vcHRpb25zLmNsb3NlT25DbGljayB8fCAoIV90aGlzLm9wdGlvbnMuY2xpY2tPcGVuICYmICFoYXNUb3VjaCkgfHwgKF90aGlzLm9wdGlvbnMuZm9yY2VGb2xsb3cgJiYgaGFzVG91Y2gpKSB7IHJldHVybjsgfVxuICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgZS5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIF90aGlzLl9oaWRlKCRlbGVtKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgX3RoaXMuX3Nob3coJHN1Yik7XG4gICAgICAgICAgJGVsZW0uYWRkKCRlbGVtLnBhcmVudHNVbnRpbChfdGhpcy4kZWxlbWVudCwgYC4ke3BhckNsYXNzfWApKS5hdHRyKCdkYXRhLWlzLWNsaWNrJywgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5jbGlja09wZW4gfHwgaGFzVG91Y2gpIHtcbiAgICAgIHRoaXMuJG1lbnVJdGVtcy5vbignY2xpY2suemYuZHJvcGRvd25tZW51IHRvdWNoc3RhcnQuemYuZHJvcGRvd25tZW51JywgaGFuZGxlQ2xpY2tGbik7XG4gICAgfVxuXG4gICAgLy8gSGFuZGxlIExlYWYgZWxlbWVudCBDbGlja3NcbiAgICBpZihfdGhpcy5vcHRpb25zLmNsb3NlT25DbGlja0luc2lkZSl7XG4gICAgICB0aGlzLiRtZW51SXRlbXMub24oJ2NsaWNrLnpmLmRyb3Bkb3dubWVudSB0b3VjaGVuZC56Zi5kcm9wZG93bm1lbnUnLCBmdW5jdGlvbihlKSB7XG4gICAgICAgIHZhciAkZWxlbSA9ICQodGhpcyksXG4gICAgICAgICAgICBoYXNTdWIgPSAkZWxlbS5oYXNDbGFzcyhwYXJDbGFzcyk7XG4gICAgICAgIGlmKCFoYXNTdWIpe1xuICAgICAgICAgIF90aGlzLl9oaWRlKCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGlmICghdGhpcy5vcHRpb25zLmRpc2FibGVIb3Zlcikge1xuICAgICAgdGhpcy4kbWVudUl0ZW1zLm9uKCdtb3VzZWVudGVyLnpmLmRyb3Bkb3dubWVudScsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdmFyICRlbGVtID0gJCh0aGlzKSxcbiAgICAgICAgICAgIGhhc1N1YiA9ICRlbGVtLmhhc0NsYXNzKHBhckNsYXNzKTtcblxuICAgICAgICBpZiAoaGFzU3ViKSB7XG4gICAgICAgICAgY2xlYXJUaW1lb3V0KCRlbGVtLmRhdGEoJ19kZWxheScpKTtcbiAgICAgICAgICAkZWxlbS5kYXRhKCdfZGVsYXknLCBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgX3RoaXMuX3Nob3coJGVsZW0uY2hpbGRyZW4oJy5pcy1kcm9wZG93bi1zdWJtZW51JykpO1xuICAgICAgICAgIH0sIF90aGlzLm9wdGlvbnMuaG92ZXJEZWxheSkpO1xuICAgICAgICB9XG4gICAgICB9KS5vbignbW91c2VsZWF2ZS56Zi5kcm9wZG93bm1lbnUnLCBmdW5jdGlvbihlKSB7XG4gICAgICAgIHZhciAkZWxlbSA9ICQodGhpcyksXG4gICAgICAgICAgICBoYXNTdWIgPSAkZWxlbS5oYXNDbGFzcyhwYXJDbGFzcyk7XG4gICAgICAgIGlmIChoYXNTdWIgJiYgX3RoaXMub3B0aW9ucy5hdXRvY2xvc2UpIHtcbiAgICAgICAgICBpZiAoJGVsZW0uYXR0cignZGF0YS1pcy1jbGljaycpID09PSAndHJ1ZScgJiYgX3RoaXMub3B0aW9ucy5jbGlja09wZW4pIHsgcmV0dXJuIGZhbHNlOyB9XG5cbiAgICAgICAgICBjbGVhclRpbWVvdXQoJGVsZW0uZGF0YSgnX2RlbGF5JykpO1xuICAgICAgICAgICRlbGVtLmRhdGEoJ19kZWxheScsIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBfdGhpcy5faGlkZSgkZWxlbSk7XG4gICAgICAgICAgfSwgX3RoaXMub3B0aW9ucy5jbG9zaW5nVGltZSkpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgdGhpcy4kbWVudUl0ZW1zLm9uKCdrZXlkb3duLnpmLmRyb3Bkb3dubWVudScsIGZ1bmN0aW9uKGUpIHtcbiAgICAgIHZhciAkZWxlbWVudCA9ICQoZS50YXJnZXQpLnBhcmVudHNVbnRpbCgndWwnLCAnW3JvbGU9XCJtZW51aXRlbVwiXScpLFxuICAgICAgICAgIGlzVGFiID0gX3RoaXMuJHRhYnMuaW5kZXgoJGVsZW1lbnQpID4gLTEsXG4gICAgICAgICAgJGVsZW1lbnRzID0gaXNUYWIgPyBfdGhpcy4kdGFicyA6ICRlbGVtZW50LnNpYmxpbmdzKCdsaScpLmFkZCgkZWxlbWVudCksXG4gICAgICAgICAgJHByZXZFbGVtZW50LFxuICAgICAgICAgICRuZXh0RWxlbWVudDtcblxuICAgICAgJGVsZW1lbnRzLmVhY2goZnVuY3Rpb24oaSkge1xuICAgICAgICBpZiAoJCh0aGlzKS5pcygkZWxlbWVudCkpIHtcbiAgICAgICAgICAkcHJldkVsZW1lbnQgPSAkZWxlbWVudHMuZXEoaS0xKTtcbiAgICAgICAgICAkbmV4dEVsZW1lbnQgPSAkZWxlbWVudHMuZXEoaSsxKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICB2YXIgbmV4dFNpYmxpbmcgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKCEkZWxlbWVudC5pcygnOmxhc3QtY2hpbGQnKSkge1xuICAgICAgICAgICRuZXh0RWxlbWVudC5jaGlsZHJlbignYTpmaXJzdCcpLmZvY3VzKCk7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB9XG4gICAgICB9LCBwcmV2U2libGluZyA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAkcHJldkVsZW1lbnQuY2hpbGRyZW4oJ2E6Zmlyc3QnKS5mb2N1cygpO1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB9LCBvcGVuU3ViID0gZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciAkc3ViID0gJGVsZW1lbnQuY2hpbGRyZW4oJ3VsLmlzLWRyb3Bkb3duLXN1Ym1lbnUnKTtcbiAgICAgICAgaWYgKCRzdWIubGVuZ3RoKSB7XG4gICAgICAgICAgX3RoaXMuX3Nob3coJHN1Yik7XG4gICAgICAgICAgJGVsZW1lbnQuZmluZCgnbGkgPiBhOmZpcnN0JykuZm9jdXMoKTtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIH0gZWxzZSB7IHJldHVybjsgfVxuICAgICAgfSwgY2xvc2VTdWIgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgLy9pZiAoJGVsZW1lbnQuaXMoJzpmaXJzdC1jaGlsZCcpKSB7XG4gICAgICAgIHZhciBjbG9zZSA9ICRlbGVtZW50LnBhcmVudCgndWwnKS5wYXJlbnQoJ2xpJyk7XG4gICAgICAgIGNsb3NlLmNoaWxkcmVuKCdhOmZpcnN0JykuZm9jdXMoKTtcbiAgICAgICAgX3RoaXMuX2hpZGUoY2xvc2UpO1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIC8vfVxuICAgICAgfTtcbiAgICAgIHZhciBmdW5jdGlvbnMgPSB7XG4gICAgICAgIG9wZW46IG9wZW5TdWIsXG4gICAgICAgIGNsb3NlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICBfdGhpcy5faGlkZShfdGhpcy4kZWxlbWVudCk7XG4gICAgICAgICAgX3RoaXMuJG1lbnVJdGVtcy5maW5kKCdhOmZpcnN0JykuZm9jdXMoKTsgLy8gZm9jdXMgdG8gZmlyc3QgZWxlbWVudFxuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgfSxcbiAgICAgICAgaGFuZGxlZDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgZS5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgaWYgKGlzVGFiKSB7XG4gICAgICAgIGlmIChfdGhpcy5faXNWZXJ0aWNhbCgpKSB7IC8vIHZlcnRpY2FsIG1lbnVcbiAgICAgICAgICBpZiAoRm91bmRhdGlvbi5ydGwoKSkgeyAvLyByaWdodCBhbGlnbmVkXG4gICAgICAgICAgICAkLmV4dGVuZChmdW5jdGlvbnMsIHtcbiAgICAgICAgICAgICAgZG93bjogbmV4dFNpYmxpbmcsXG4gICAgICAgICAgICAgIHVwOiBwcmV2U2libGluZyxcbiAgICAgICAgICAgICAgbmV4dDogY2xvc2VTdWIsXG4gICAgICAgICAgICAgIHByZXZpb3VzOiBvcGVuU3ViXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9IGVsc2UgeyAvLyBsZWZ0IGFsaWduZWRcbiAgICAgICAgICAgICQuZXh0ZW5kKGZ1bmN0aW9ucywge1xuICAgICAgICAgICAgICBkb3duOiBuZXh0U2libGluZyxcbiAgICAgICAgICAgICAgdXA6IHByZXZTaWJsaW5nLFxuICAgICAgICAgICAgICBuZXh0OiBvcGVuU3ViLFxuICAgICAgICAgICAgICBwcmV2aW91czogY2xvc2VTdWJcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHsgLy8gaG9yaXpvbnRhbCBtZW51XG4gICAgICAgICAgaWYgKEZvdW5kYXRpb24ucnRsKCkpIHsgLy8gcmlnaHQgYWxpZ25lZFxuICAgICAgICAgICAgJC5leHRlbmQoZnVuY3Rpb25zLCB7XG4gICAgICAgICAgICAgIG5leHQ6IHByZXZTaWJsaW5nLFxuICAgICAgICAgICAgICBwcmV2aW91czogbmV4dFNpYmxpbmcsXG4gICAgICAgICAgICAgIGRvd246IG9wZW5TdWIsXG4gICAgICAgICAgICAgIHVwOiBjbG9zZVN1YlxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSBlbHNlIHsgLy8gbGVmdCBhbGlnbmVkXG4gICAgICAgICAgICAkLmV4dGVuZChmdW5jdGlvbnMsIHtcbiAgICAgICAgICAgICAgbmV4dDogbmV4dFNpYmxpbmcsXG4gICAgICAgICAgICAgIHByZXZpb3VzOiBwcmV2U2libGluZyxcbiAgICAgICAgICAgICAgZG93bjogb3BlblN1YixcbiAgICAgICAgICAgICAgdXA6IGNsb3NlU3ViXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7IC8vIG5vdCB0YWJzIC0+IG9uZSBzdWJcbiAgICAgICAgaWYgKEZvdW5kYXRpb24ucnRsKCkpIHsgLy8gcmlnaHQgYWxpZ25lZFxuICAgICAgICAgICQuZXh0ZW5kKGZ1bmN0aW9ucywge1xuICAgICAgICAgICAgbmV4dDogY2xvc2VTdWIsXG4gICAgICAgICAgICBwcmV2aW91czogb3BlblN1YixcbiAgICAgICAgICAgIGRvd246IG5leHRTaWJsaW5nLFxuICAgICAgICAgICAgdXA6IHByZXZTaWJsaW5nXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7IC8vIGxlZnQgYWxpZ25lZFxuICAgICAgICAgICQuZXh0ZW5kKGZ1bmN0aW9ucywge1xuICAgICAgICAgICAgbmV4dDogb3BlblN1YixcbiAgICAgICAgICAgIHByZXZpb3VzOiBjbG9zZVN1YixcbiAgICAgICAgICAgIGRvd246IG5leHRTaWJsaW5nLFxuICAgICAgICAgICAgdXA6IHByZXZTaWJsaW5nXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIEZvdW5kYXRpb24uS2V5Ym9hcmQuaGFuZGxlS2V5KGUsICdEcm9wZG93bk1lbnUnLCBmdW5jdGlvbnMpO1xuXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhbiBldmVudCBoYW5kbGVyIHRvIHRoZSBib2R5IHRvIGNsb3NlIGFueSBkcm9wZG93bnMgb24gYSBjbGljay5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfYWRkQm9keUhhbmRsZXIoKSB7XG4gICAgdmFyICRib2R5ID0gJChkb2N1bWVudC5ib2R5KSxcbiAgICAgICAgX3RoaXMgPSB0aGlzO1xuICAgICRib2R5Lm9mZignbW91c2V1cC56Zi5kcm9wZG93bm1lbnUgdG91Y2hlbmQuemYuZHJvcGRvd25tZW51JylcbiAgICAgICAgIC5vbignbW91c2V1cC56Zi5kcm9wZG93bm1lbnUgdG91Y2hlbmQuemYuZHJvcGRvd25tZW51JywgZnVuY3Rpb24oZSkge1xuICAgICAgICAgICB2YXIgJGxpbmsgPSBfdGhpcy4kZWxlbWVudC5maW5kKGUudGFyZ2V0KTtcbiAgICAgICAgICAgaWYgKCRsaW5rLmxlbmd0aCkgeyByZXR1cm47IH1cblxuICAgICAgICAgICBfdGhpcy5faGlkZSgpO1xuICAgICAgICAgICAkYm9keS5vZmYoJ21vdXNldXAuemYuZHJvcGRvd25tZW51IHRvdWNoZW5kLnpmLmRyb3Bkb3dubWVudScpO1xuICAgICAgICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogT3BlbnMgYSBkcm9wZG93biBwYW5lLCBhbmQgY2hlY2tzIGZvciBjb2xsaXNpb25zIGZpcnN0LlxuICAgKiBAcGFyYW0ge2pRdWVyeX0gJHN1YiAtIHVsIGVsZW1lbnQgdGhhdCBpcyBhIHN1Ym1lbnUgdG8gc2hvd1xuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICogQGZpcmVzIERyb3Bkb3duTWVudSNzaG93XG4gICAqL1xuICBfc2hvdygkc3ViKSB7XG4gICAgdmFyIGlkeCA9IHRoaXMuJHRhYnMuaW5kZXgodGhpcy4kdGFicy5maWx0ZXIoZnVuY3Rpb24oaSwgZWwpIHtcbiAgICAgIHJldHVybiAkKGVsKS5maW5kKCRzdWIpLmxlbmd0aCA+IDA7XG4gICAgfSkpO1xuICAgIHZhciAkc2licyA9ICRzdWIucGFyZW50KCdsaS5pcy1kcm9wZG93bi1zdWJtZW51LXBhcmVudCcpLnNpYmxpbmdzKCdsaS5pcy1kcm9wZG93bi1zdWJtZW51LXBhcmVudCcpO1xuICAgIHRoaXMuX2hpZGUoJHNpYnMsIGlkeCk7XG4gICAgJHN1Yi5jc3MoJ3Zpc2liaWxpdHknLCAnaGlkZGVuJykuYWRkQ2xhc3MoJ2pzLWRyb3Bkb3duLWFjdGl2ZScpXG4gICAgICAgIC5wYXJlbnQoJ2xpLmlzLWRyb3Bkb3duLXN1Ym1lbnUtcGFyZW50JykuYWRkQ2xhc3MoJ2lzLWFjdGl2ZScpO1xuICAgIHZhciBjbGVhciA9IEZvdW5kYXRpb24uQm94LkltTm90VG91Y2hpbmdZb3UoJHN1YiwgbnVsbCwgdHJ1ZSk7XG4gICAgaWYgKCFjbGVhcikge1xuICAgICAgdmFyIG9sZENsYXNzID0gdGhpcy5vcHRpb25zLmFsaWdubWVudCA9PT0gJ2xlZnQnID8gJy1yaWdodCcgOiAnLWxlZnQnLFxuICAgICAgICAgICRwYXJlbnRMaSA9ICRzdWIucGFyZW50KCcuaXMtZHJvcGRvd24tc3VibWVudS1wYXJlbnQnKTtcbiAgICAgICRwYXJlbnRMaS5yZW1vdmVDbGFzcyhgb3BlbnMke29sZENsYXNzfWApLmFkZENsYXNzKGBvcGVucy0ke3RoaXMub3B0aW9ucy5hbGlnbm1lbnR9YCk7XG4gICAgICBjbGVhciA9IEZvdW5kYXRpb24uQm94LkltTm90VG91Y2hpbmdZb3UoJHN1YiwgbnVsbCwgdHJ1ZSk7XG4gICAgICBpZiAoIWNsZWFyKSB7XG4gICAgICAgICRwYXJlbnRMaS5yZW1vdmVDbGFzcyhgb3BlbnMtJHt0aGlzLm9wdGlvbnMuYWxpZ25tZW50fWApLmFkZENsYXNzKCdvcGVucy1pbm5lcicpO1xuICAgICAgfVxuICAgICAgdGhpcy5jaGFuZ2VkID0gdHJ1ZTtcbiAgICB9XG4gICAgJHN1Yi5jc3MoJ3Zpc2liaWxpdHknLCAnJyk7XG4gICAgaWYgKHRoaXMub3B0aW9ucy5jbG9zZU9uQ2xpY2spIHsgdGhpcy5fYWRkQm9keUhhbmRsZXIoKTsgfVxuICAgIC8qKlxuICAgICAqIEZpcmVzIHdoZW4gdGhlIG5ldyBkcm9wZG93biBwYW5lIGlzIHZpc2libGUuXG4gICAgICogQGV2ZW50IERyb3Bkb3duTWVudSNzaG93XG4gICAgICovXG4gICAgdGhpcy4kZWxlbWVudC50cmlnZ2VyKCdzaG93LnpmLmRyb3Bkb3dubWVudScsIFskc3ViXSk7XG4gIH1cblxuICAvKipcbiAgICogSGlkZXMgYSBzaW5nbGUsIGN1cnJlbnRseSBvcGVuIGRyb3Bkb3duIHBhbmUsIGlmIHBhc3NlZCBhIHBhcmFtZXRlciwgb3RoZXJ3aXNlLCBoaWRlcyBldmVyeXRoaW5nLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHBhcmFtIHtqUXVlcnl9ICRlbGVtIC0gZWxlbWVudCB3aXRoIGEgc3VibWVudSB0byBoaWRlXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBpZHggLSBpbmRleCBvZiB0aGUgJHRhYnMgY29sbGVjdGlvbiB0byBoaWRlXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfaGlkZSgkZWxlbSwgaWR4KSB7XG4gICAgdmFyICR0b0Nsb3NlO1xuICAgIGlmICgkZWxlbSAmJiAkZWxlbS5sZW5ndGgpIHtcbiAgICAgICR0b0Nsb3NlID0gJGVsZW07XG4gICAgfSBlbHNlIGlmIChpZHggIT09IHVuZGVmaW5lZCkge1xuICAgICAgJHRvQ2xvc2UgPSB0aGlzLiR0YWJzLm5vdChmdW5jdGlvbihpLCBlbCkge1xuICAgICAgICByZXR1cm4gaSA9PT0gaWR4O1xuICAgICAgfSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgJHRvQ2xvc2UgPSB0aGlzLiRlbGVtZW50O1xuICAgIH1cbiAgICB2YXIgc29tZXRoaW5nVG9DbG9zZSA9ICR0b0Nsb3NlLmhhc0NsYXNzKCdpcy1hY3RpdmUnKSB8fCAkdG9DbG9zZS5maW5kKCcuaXMtYWN0aXZlJykubGVuZ3RoID4gMDtcblxuICAgIGlmIChzb21ldGhpbmdUb0Nsb3NlKSB7XG4gICAgICAkdG9DbG9zZS5maW5kKCdsaS5pcy1hY3RpdmUnKS5hZGQoJHRvQ2xvc2UpLmF0dHIoe1xuICAgICAgICAnZGF0YS1pcy1jbGljayc6IGZhbHNlXG4gICAgICB9KS5yZW1vdmVDbGFzcygnaXMtYWN0aXZlJyk7XG5cbiAgICAgICR0b0Nsb3NlLmZpbmQoJ3VsLmpzLWRyb3Bkb3duLWFjdGl2ZScpLnJlbW92ZUNsYXNzKCdqcy1kcm9wZG93bi1hY3RpdmUnKTtcblxuICAgICAgaWYgKHRoaXMuY2hhbmdlZCB8fCAkdG9DbG9zZS5maW5kKCdvcGVucy1pbm5lcicpLmxlbmd0aCkge1xuICAgICAgICB2YXIgb2xkQ2xhc3MgPSB0aGlzLm9wdGlvbnMuYWxpZ25tZW50ID09PSAnbGVmdCcgPyAncmlnaHQnIDogJ2xlZnQnO1xuICAgICAgICAkdG9DbG9zZS5maW5kKCdsaS5pcy1kcm9wZG93bi1zdWJtZW51LXBhcmVudCcpLmFkZCgkdG9DbG9zZSlcbiAgICAgICAgICAgICAgICAucmVtb3ZlQ2xhc3MoYG9wZW5zLWlubmVyIG9wZW5zLSR7dGhpcy5vcHRpb25zLmFsaWdubWVudH1gKVxuICAgICAgICAgICAgICAgIC5hZGRDbGFzcyhgb3BlbnMtJHtvbGRDbGFzc31gKTtcbiAgICAgICAgdGhpcy5jaGFuZ2VkID0gZmFsc2U7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEZpcmVzIHdoZW4gdGhlIG9wZW4gbWVudXMgYXJlIGNsb3NlZC5cbiAgICAgICAqIEBldmVudCBEcm9wZG93bk1lbnUjaGlkZVxuICAgICAgICovXG4gICAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ2hpZGUuemYuZHJvcGRvd25tZW51JywgWyR0b0Nsb3NlXSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIERlc3Ryb3lzIHRoZSBwbHVnaW4uXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLiRtZW51SXRlbXMub2ZmKCcuemYuZHJvcGRvd25tZW51JykucmVtb3ZlQXR0cignZGF0YS1pcy1jbGljaycpXG4gICAgICAgIC5yZW1vdmVDbGFzcygnaXMtcmlnaHQtYXJyb3cgaXMtbGVmdC1hcnJvdyBpcy1kb3duLWFycm93IG9wZW5zLXJpZ2h0IG9wZW5zLWxlZnQgb3BlbnMtaW5uZXInKTtcbiAgICAkKGRvY3VtZW50LmJvZHkpLm9mZignLnpmLmRyb3Bkb3dubWVudScpO1xuICAgIEZvdW5kYXRpb24uTmVzdC5CdXJuKHRoaXMuJGVsZW1lbnQsICdkcm9wZG93bicpO1xuICAgIEZvdW5kYXRpb24udW5yZWdpc3RlclBsdWdpbih0aGlzKTtcbiAgfVxufVxuXG4vKipcbiAqIERlZmF1bHQgc2V0dGluZ3MgZm9yIHBsdWdpblxuICovXG5Ecm9wZG93bk1lbnUuZGVmYXVsdHMgPSB7XG4gIC8qKlxuICAgKiBEaXNhbGxvd3MgaG92ZXIgZXZlbnRzIGZyb20gb3BlbmluZyBzdWJtZW51c1xuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICBkaXNhYmxlSG92ZXI6IGZhbHNlLFxuICAvKipcbiAgICogQWxsb3cgYSBzdWJtZW51IHRvIGF1dG9tYXRpY2FsbHkgY2xvc2Ugb24gYSBtb3VzZWxlYXZlIGV2ZW50LCBpZiBub3QgY2xpY2tlZCBvcGVuLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIHRydWVcbiAgICovXG4gIGF1dG9jbG9zZTogdHJ1ZSxcbiAgLyoqXG4gICAqIEFtb3VudCBvZiB0aW1lIHRvIGRlbGF5IG9wZW5pbmcgYSBzdWJtZW51IG9uIGhvdmVyIGV2ZW50LlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIDUwXG4gICAqL1xuICBob3ZlckRlbGF5OiA1MCxcbiAgLyoqXG4gICAqIEFsbG93IGEgc3VibWVudSB0byBvcGVuL3JlbWFpbiBvcGVuIG9uIHBhcmVudCBjbGljayBldmVudC4gQWxsb3dzIGN1cnNvciB0byBtb3ZlIGF3YXkgZnJvbSBtZW51LlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIHRydWVcbiAgICovXG4gIGNsaWNrT3BlbjogZmFsc2UsXG4gIC8qKlxuICAgKiBBbW91bnQgb2YgdGltZSB0byBkZWxheSBjbG9zaW5nIGEgc3VibWVudSBvbiBhIG1vdXNlbGVhdmUgZXZlbnQuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgNTAwXG4gICAqL1xuXG4gIGNsb3NpbmdUaW1lOiA1MDAsXG4gIC8qKlxuICAgKiBQb3NpdGlvbiBvZiB0aGUgbWVudSByZWxhdGl2ZSB0byB3aGF0IGRpcmVjdGlvbiB0aGUgc3VibWVudXMgc2hvdWxkIG9wZW4uIEhhbmRsZWQgYnkgSlMuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgJ2xlZnQnXG4gICAqL1xuICBhbGlnbm1lbnQ6ICdsZWZ0JyxcbiAgLyoqXG4gICAqIEFsbG93IGNsaWNrcyBvbiB0aGUgYm9keSB0byBjbG9zZSBhbnkgb3BlbiBzdWJtZW51cy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSB0cnVlXG4gICAqL1xuICBjbG9zZU9uQ2xpY2s6IHRydWUsXG4gIC8qKlxuICAgKiBBbGxvdyBjbGlja3Mgb24gbGVhZiBhbmNob3IgbGlua3MgdG8gY2xvc2UgYW55IG9wZW4gc3VibWVudXMuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgdHJ1ZVxuICAgKi9cbiAgY2xvc2VPbkNsaWNrSW5zaWRlOiB0cnVlLFxuICAvKipcbiAgICogQ2xhc3MgYXBwbGllZCB0byB2ZXJ0aWNhbCBvcmllbnRlZCBtZW51cywgRm91bmRhdGlvbiBkZWZhdWx0IGlzIGB2ZXJ0aWNhbGAuIFVwZGF0ZSB0aGlzIGlmIHVzaW5nIHlvdXIgb3duIGNsYXNzLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlICd2ZXJ0aWNhbCdcbiAgICovXG4gIHZlcnRpY2FsQ2xhc3M6ICd2ZXJ0aWNhbCcsXG4gIC8qKlxuICAgKiBDbGFzcyBhcHBsaWVkIHRvIHJpZ2h0LXNpZGUgb3JpZW50ZWQgbWVudXMsIEZvdW5kYXRpb24gZGVmYXVsdCBpcyBgYWxpZ24tcmlnaHRgLiBVcGRhdGUgdGhpcyBpZiB1c2luZyB5b3VyIG93biBjbGFzcy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnYWxpZ24tcmlnaHQnXG4gICAqL1xuICByaWdodENsYXNzOiAnYWxpZ24tcmlnaHQnLFxuICAvKipcbiAgICogQm9vbGVhbiB0byBmb3JjZSBvdmVyaWRlIHRoZSBjbGlja2luZyBvZiBsaW5rcyB0byBwZXJmb3JtIGRlZmF1bHQgYWN0aW9uLCBvbiBzZWNvbmQgdG91Y2ggZXZlbnQgZm9yIG1vYmlsZS5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBmYWxzZVxuICAgKi9cbiAgZm9yY2VGb2xsb3c6IHRydWVcbn07XG5cbi8vIFdpbmRvdyBleHBvcnRzXG5Gb3VuZGF0aW9uLnBsdWdpbihEcm9wZG93bk1lbnUsICdEcm9wZG93bk1lbnUnKTtcblxufShqUXVlcnkpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4hZnVuY3Rpb24oJCkge1xuXG4vKipcbiAqIE9mZkNhbnZhcyBtb2R1bGUuXG4gKiBAbW9kdWxlIGZvdW5kYXRpb24ub2ZmY2FudmFzXG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLm1lZGlhUXVlcnlcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwudHJpZ2dlcnNcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwubW90aW9uXG4gKi9cblxuY2xhc3MgT2ZmQ2FudmFzIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgaW5zdGFuY2Ugb2YgYW4gb2ZmLWNhbnZhcyB3cmFwcGVyLlxuICAgKiBAY2xhc3NcbiAgICogQGZpcmVzIE9mZkNhbnZhcyNpbml0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSBlbGVtZW50IC0galF1ZXJ5IG9iamVjdCB0byBpbml0aWFsaXplLlxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyAtIE92ZXJyaWRlcyB0byB0aGUgZGVmYXVsdCBwbHVnaW4gc2V0dGluZ3MuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihlbGVtZW50LCBvcHRpb25zKSB7XG4gICAgdGhpcy4kZWxlbWVudCA9IGVsZW1lbnQ7XG4gICAgdGhpcy5vcHRpb25zID0gJC5leHRlbmQoe30sIE9mZkNhbnZhcy5kZWZhdWx0cywgdGhpcy4kZWxlbWVudC5kYXRhKCksIG9wdGlvbnMpO1xuICAgIHRoaXMuJGxhc3RUcmlnZ2VyID0gJCgpO1xuICAgIHRoaXMuJHRyaWdnZXJzID0gJCgpO1xuXG4gICAgdGhpcy5faW5pdCgpO1xuICAgIHRoaXMuX2V2ZW50cygpO1xuXG4gICAgRm91bmRhdGlvbi5yZWdpc3RlclBsdWdpbih0aGlzLCAnT2ZmQ2FudmFzJylcbiAgICBGb3VuZGF0aW9uLktleWJvYXJkLnJlZ2lzdGVyKCdPZmZDYW52YXMnLCB7XG4gICAgICAnRVNDQVBFJzogJ2Nsb3NlJ1xuICAgIH0pO1xuXG4gIH1cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgdGhlIG9mZi1jYW52YXMgd3JhcHBlciBieSBhZGRpbmcgdGhlIGV4aXQgb3ZlcmxheSAoaWYgbmVlZGVkKS5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfaW5pdCgpIHtcbiAgICB2YXIgaWQgPSB0aGlzLiRlbGVtZW50LmF0dHIoJ2lkJyk7XG5cbiAgICB0aGlzLiRlbGVtZW50LmF0dHIoJ2FyaWEtaGlkZGVuJywgJ3RydWUnKTtcblxuICAgIHRoaXMuJGVsZW1lbnQuYWRkQ2xhc3MoYGlzLXRyYW5zaXRpb24tJHt0aGlzLm9wdGlvbnMudHJhbnNpdGlvbn1gKTtcblxuICAgIC8vIEZpbmQgdHJpZ2dlcnMgdGhhdCBhZmZlY3QgdGhpcyBlbGVtZW50IGFuZCBhZGQgYXJpYS1leHBhbmRlZCB0byB0aGVtXG4gICAgdGhpcy4kdHJpZ2dlcnMgPSAkKGRvY3VtZW50KVxuICAgICAgLmZpbmQoJ1tkYXRhLW9wZW49XCInK2lkKydcIl0sIFtkYXRhLWNsb3NlPVwiJytpZCsnXCJdLCBbZGF0YS10b2dnbGU9XCInK2lkKydcIl0nKVxuICAgICAgLmF0dHIoJ2FyaWEtZXhwYW5kZWQnLCAnZmFsc2UnKVxuICAgICAgLmF0dHIoJ2FyaWEtY29udHJvbHMnLCBpZCk7XG5cbiAgICAvLyBBZGQgYW4gb3ZlcmxheSBvdmVyIHRoZSBjb250ZW50IGlmIG5lY2Vzc2FyeVxuICAgIGlmICh0aGlzLm9wdGlvbnMuY29udGVudE92ZXJsYXkgPT09IHRydWUpIHtcbiAgICAgIHZhciBvdmVybGF5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICB2YXIgb3ZlcmxheVBvc2l0aW9uID0gJCh0aGlzLiRlbGVtZW50KS5jc3MoXCJwb3NpdGlvblwiKSA9PT0gJ2ZpeGVkJyA/ICdpcy1vdmVybGF5LWZpeGVkJyA6ICdpcy1vdmVybGF5LWFic29sdXRlJztcbiAgICAgIG92ZXJsYXkuc2V0QXR0cmlidXRlKCdjbGFzcycsICdqcy1vZmYtY2FudmFzLW92ZXJsYXkgJyArIG92ZXJsYXlQb3NpdGlvbik7XG4gICAgICB0aGlzLiRvdmVybGF5ID0gJChvdmVybGF5KTtcbiAgICAgIGlmKG92ZXJsYXlQb3NpdGlvbiA9PT0gJ2lzLW92ZXJsYXktZml4ZWQnKSB7XG4gICAgICAgICQoJ2JvZHknKS5hcHBlbmQodGhpcy4kb3ZlcmxheSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLiRlbGVtZW50LnNpYmxpbmdzKCdbZGF0YS1vZmYtY2FudmFzLWNvbnRlbnRdJykuYXBwZW5kKHRoaXMuJG92ZXJsYXkpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMub3B0aW9ucy5pc1JldmVhbGVkID0gdGhpcy5vcHRpb25zLmlzUmV2ZWFsZWQgfHwgbmV3IFJlZ0V4cCh0aGlzLm9wdGlvbnMucmV2ZWFsQ2xhc3MsICdnJykudGVzdCh0aGlzLiRlbGVtZW50WzBdLmNsYXNzTmFtZSk7XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmlzUmV2ZWFsZWQgPT09IHRydWUpIHtcbiAgICAgIHRoaXMub3B0aW9ucy5yZXZlYWxPbiA9IHRoaXMub3B0aW9ucy5yZXZlYWxPbiB8fCB0aGlzLiRlbGVtZW50WzBdLmNsYXNzTmFtZS5tYXRjaCgvKHJldmVhbC1mb3ItbWVkaXVtfHJldmVhbC1mb3ItbGFyZ2UpL2cpWzBdLnNwbGl0KCctJylbMl07XG4gICAgICB0aGlzLl9zZXRNUUNoZWNrZXIoKTtcbiAgICB9XG4gICAgaWYgKCF0aGlzLm9wdGlvbnMudHJhbnNpdGlvblRpbWUgPT09IHRydWUpIHtcbiAgICAgIHRoaXMub3B0aW9ucy50cmFuc2l0aW9uVGltZSA9IHBhcnNlRmxvYXQod2luZG93LmdldENvbXB1dGVkU3R5bGUoJCgnW2RhdGEtb2ZmLWNhbnZhc10nKVswXSkudHJhbnNpdGlvbkR1cmF0aW9uKSAqIDEwMDA7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgZXZlbnQgaGFuZGxlcnMgdG8gdGhlIG9mZi1jYW52YXMgd3JhcHBlciBhbmQgdGhlIGV4aXQgb3ZlcmxheS5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfZXZlbnRzKCkge1xuICAgIHRoaXMuJGVsZW1lbnQub2ZmKCcuemYudHJpZ2dlciAuemYub2ZmY2FudmFzJykub24oe1xuICAgICAgJ29wZW4uemYudHJpZ2dlcic6IHRoaXMub3Blbi5iaW5kKHRoaXMpLFxuICAgICAgJ2Nsb3NlLnpmLnRyaWdnZXInOiB0aGlzLmNsb3NlLmJpbmQodGhpcyksXG4gICAgICAndG9nZ2xlLnpmLnRyaWdnZXInOiB0aGlzLnRvZ2dsZS5iaW5kKHRoaXMpLFxuICAgICAgJ2tleWRvd24uemYub2ZmY2FudmFzJzogdGhpcy5faGFuZGxlS2V5Ym9hcmQuYmluZCh0aGlzKVxuICAgIH0pO1xuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5jbG9zZU9uQ2xpY2sgPT09IHRydWUpIHtcbiAgICAgIHZhciAkdGFyZ2V0ID0gdGhpcy5vcHRpb25zLmNvbnRlbnRPdmVybGF5ID8gdGhpcy4kb3ZlcmxheSA6ICQoJ1tkYXRhLW9mZi1jYW52YXMtY29udGVudF0nKTtcbiAgICAgICR0YXJnZXQub24oeydjbGljay56Zi5vZmZjYW52YXMnOiB0aGlzLmNsb3NlLmJpbmQodGhpcyl9KTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQXBwbGllcyBldmVudCBsaXN0ZW5lciBmb3IgZWxlbWVudHMgdGhhdCB3aWxsIHJldmVhbCBhdCBjZXJ0YWluIGJyZWFrcG9pbnRzLlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX3NldE1RQ2hlY2tlcigpIHtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgJCh3aW5kb3cpLm9uKCdjaGFuZ2VkLnpmLm1lZGlhcXVlcnknLCBmdW5jdGlvbigpIHtcbiAgICAgIGlmIChGb3VuZGF0aW9uLk1lZGlhUXVlcnkuYXRMZWFzdChfdGhpcy5vcHRpb25zLnJldmVhbE9uKSkge1xuICAgICAgICBfdGhpcy5yZXZlYWwodHJ1ZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBfdGhpcy5yZXZlYWwoZmFsc2UpO1xuICAgICAgfVxuICAgIH0pLm9uZSgnbG9hZC56Zi5vZmZjYW52YXMnLCBmdW5jdGlvbigpIHtcbiAgICAgIGlmIChGb3VuZGF0aW9uLk1lZGlhUXVlcnkuYXRMZWFzdChfdGhpcy5vcHRpb25zLnJldmVhbE9uKSkge1xuICAgICAgICBfdGhpcy5yZXZlYWwodHJ1ZSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogSGFuZGxlcyB0aGUgcmV2ZWFsaW5nL2hpZGluZyB0aGUgb2ZmLWNhbnZhcyBhdCBicmVha3BvaW50cywgbm90IHRoZSBzYW1lIGFzIG9wZW4uXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gaXNSZXZlYWxlZCAtIHRydWUgaWYgZWxlbWVudCBzaG91bGQgYmUgcmV2ZWFsZWQuXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgcmV2ZWFsKGlzUmV2ZWFsZWQpIHtcbiAgICB2YXIgJGNsb3NlciA9IHRoaXMuJGVsZW1lbnQuZmluZCgnW2RhdGEtY2xvc2VdJyk7XG4gICAgaWYgKGlzUmV2ZWFsZWQpIHtcbiAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgIHRoaXMuaXNSZXZlYWxlZCA9IHRydWU7XG4gICAgICB0aGlzLiRlbGVtZW50LmF0dHIoJ2FyaWEtaGlkZGVuJywgJ2ZhbHNlJyk7XG4gICAgICB0aGlzLiRlbGVtZW50Lm9mZignb3Blbi56Zi50cmlnZ2VyIHRvZ2dsZS56Zi50cmlnZ2VyJyk7XG4gICAgICBpZiAoJGNsb3Nlci5sZW5ndGgpIHsgJGNsb3Nlci5oaWRlKCk7IH1cbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5pc1JldmVhbGVkID0gZmFsc2U7XG4gICAgICB0aGlzLiRlbGVtZW50LmF0dHIoJ2FyaWEtaGlkZGVuJywgJ3RydWUnKTtcbiAgICAgIHRoaXMuJGVsZW1lbnQub24oe1xuICAgICAgICAnb3Blbi56Zi50cmlnZ2VyJzogdGhpcy5vcGVuLmJpbmQodGhpcyksXG4gICAgICAgICd0b2dnbGUuemYudHJpZ2dlcic6IHRoaXMudG9nZ2xlLmJpbmQodGhpcylcbiAgICAgIH0pO1xuICAgICAgaWYgKCRjbG9zZXIubGVuZ3RoKSB7XG4gICAgICAgICRjbG9zZXIuc2hvdygpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTdG9wcyBzY3JvbGxpbmcgb2YgdGhlIGJvZHkgd2hlbiBvZmZjYW52YXMgaXMgb3BlbiBvbiBtb2JpbGUgU2FmYXJpIGFuZCBvdGhlciB0cm91Ymxlc29tZSBicm93c2Vycy5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9zdG9wU2Nyb2xsaW5nKGV2ZW50KSB7XG4gIFx0cmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLyoqXG4gICAqIE9wZW5zIHRoZSBvZmYtY2FudmFzIG1lbnUuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcGFyYW0ge09iamVjdH0gZXZlbnQgLSBFdmVudCBvYmplY3QgcGFzc2VkIGZyb20gbGlzdGVuZXIuXG4gICAqIEBwYXJhbSB7alF1ZXJ5fSB0cmlnZ2VyIC0gZWxlbWVudCB0aGF0IHRyaWdnZXJlZCB0aGUgb2ZmLWNhbnZhcyB0byBvcGVuLlxuICAgKiBAZmlyZXMgT2ZmQ2FudmFzI29wZW5lZFxuICAgKi9cbiAgb3BlbihldmVudCwgdHJpZ2dlcikge1xuICAgIGlmICh0aGlzLiRlbGVtZW50Lmhhc0NsYXNzKCdpcy1vcGVuJykgfHwgdGhpcy5pc1JldmVhbGVkKSB7IHJldHVybjsgfVxuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICBpZiAodHJpZ2dlcikge1xuICAgICAgdGhpcy4kbGFzdFRyaWdnZXIgPSB0cmlnZ2VyO1xuICAgIH1cblxuICAgIGlmICh0aGlzLm9wdGlvbnMuZm9yY2VUbyA9PT0gJ3RvcCcpIHtcbiAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCAwKTtcbiAgICB9IGVsc2UgaWYgKHRoaXMub3B0aW9ucy5mb3JjZVRvID09PSAnYm90dG9tJykge1xuICAgICAgd2luZG93LnNjcm9sbFRvKDAsZG9jdW1lbnQuYm9keS5zY3JvbGxIZWlnaHQpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEZpcmVzIHdoZW4gdGhlIG9mZi1jYW52YXMgbWVudSBvcGVucy5cbiAgICAgKiBAZXZlbnQgT2ZmQ2FudmFzI29wZW5lZFxuICAgICAqL1xuICAgIF90aGlzLiRlbGVtZW50LmFkZENsYXNzKCdpcy1vcGVuJylcblxuICAgIHRoaXMuJHRyaWdnZXJzLmF0dHIoJ2FyaWEtZXhwYW5kZWQnLCAndHJ1ZScpO1xuICAgIHRoaXMuJGVsZW1lbnQuYXR0cignYXJpYS1oaWRkZW4nLCAnZmFsc2UnKVxuICAgICAgICAudHJpZ2dlcignb3BlbmVkLnpmLm9mZmNhbnZhcycpO1xuXG4gICAgLy8gSWYgYGNvbnRlbnRTY3JvbGxgIGlzIHNldCB0byBmYWxzZSwgYWRkIGNsYXNzIGFuZCBkaXNhYmxlIHNjcm9sbGluZyBvbiB0b3VjaCBkZXZpY2VzLlxuICAgIGlmICh0aGlzLm9wdGlvbnMuY29udGVudFNjcm9sbCA9PT0gZmFsc2UpIHtcbiAgICAgICQoJ2JvZHknKS5hZGRDbGFzcygnaXMtb2ZmLWNhbnZhcy1vcGVuJykub24oJ3RvdWNobW92ZScsIHRoaXMuX3N0b3BTY3JvbGxpbmcpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLm9wdGlvbnMuY29udGVudE92ZXJsYXkgPT09IHRydWUpIHtcbiAgICAgIHRoaXMuJG92ZXJsYXkuYWRkQ2xhc3MoJ2lzLXZpc2libGUnKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmNsb3NlT25DbGljayA9PT0gdHJ1ZSAmJiB0aGlzLm9wdGlvbnMuY29udGVudE92ZXJsYXkgPT09IHRydWUpIHtcbiAgICAgIHRoaXMuJG92ZXJsYXkuYWRkQ2xhc3MoJ2lzLWNsb3NhYmxlJyk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5hdXRvRm9jdXMgPT09IHRydWUpIHtcbiAgICAgIHRoaXMuJGVsZW1lbnQub25lKEZvdW5kYXRpb24udHJhbnNpdGlvbmVuZCh0aGlzLiRlbGVtZW50KSwgZnVuY3Rpb24oKSB7XG4gICAgICAgIF90aGlzLiRlbGVtZW50LmZpbmQoJ2EsIGJ1dHRvbicpLmVxKDApLmZvY3VzKCk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLnRyYXBGb2N1cyA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy4kZWxlbWVudC5zaWJsaW5ncygnW2RhdGEtb2ZmLWNhbnZhcy1jb250ZW50XScpLmF0dHIoJ3RhYmluZGV4JywgJy0xJyk7XG4gICAgICBGb3VuZGF0aW9uLktleWJvYXJkLnRyYXBGb2N1cyh0aGlzLiRlbGVtZW50KTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQ2xvc2VzIHRoZSBvZmYtY2FudmFzIG1lbnUuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYiAtIG9wdGlvbmFsIGNiIHRvIGZpcmUgYWZ0ZXIgY2xvc3VyZS5cbiAgICogQGZpcmVzIE9mZkNhbnZhcyNjbG9zZWRcbiAgICovXG4gIGNsb3NlKGNiKSB7XG4gICAgaWYgKCF0aGlzLiRlbGVtZW50Lmhhc0NsYXNzKCdpcy1vcGVuJykgfHwgdGhpcy5pc1JldmVhbGVkKSB7IHJldHVybjsgfVxuXG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIF90aGlzLiRlbGVtZW50LnJlbW92ZUNsYXNzKCdpcy1vcGVuJyk7XG5cbiAgICB0aGlzLiRlbGVtZW50LmF0dHIoJ2FyaWEtaGlkZGVuJywgJ3RydWUnKVxuICAgICAgLyoqXG4gICAgICAgKiBGaXJlcyB3aGVuIHRoZSBvZmYtY2FudmFzIG1lbnUgb3BlbnMuXG4gICAgICAgKiBAZXZlbnQgT2ZmQ2FudmFzI2Nsb3NlZFxuICAgICAgICovXG4gICAgICAgIC50cmlnZ2VyKCdjbG9zZWQuemYub2ZmY2FudmFzJyk7XG5cbiAgICAvLyBJZiBgY29udGVudFNjcm9sbGAgaXMgc2V0IHRvIGZhbHNlLCByZW1vdmUgY2xhc3MgYW5kIHJlLWVuYWJsZSBzY3JvbGxpbmcgb24gdG91Y2ggZGV2aWNlcy5cbiAgICBpZiAodGhpcy5vcHRpb25zLmNvbnRlbnRTY3JvbGwgPT09IGZhbHNlKSB7XG4gICAgICAkKCdib2R5JykucmVtb3ZlQ2xhc3MoJ2lzLW9mZi1jYW52YXMtb3BlbicpLm9mZigndG91Y2htb3ZlJywgdGhpcy5fc3RvcFNjcm9sbGluZyk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5jb250ZW50T3ZlcmxheSA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy4kb3ZlcmxheS5yZW1vdmVDbGFzcygnaXMtdmlzaWJsZScpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLm9wdGlvbnMuY2xvc2VPbkNsaWNrID09PSB0cnVlICYmIHRoaXMub3B0aW9ucy5jb250ZW50T3ZlcmxheSA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy4kb3ZlcmxheS5yZW1vdmVDbGFzcygnaXMtY2xvc2FibGUnKTtcbiAgICB9XG5cbiAgICB0aGlzLiR0cmlnZ2Vycy5hdHRyKCdhcmlhLWV4cGFuZGVkJywgJ2ZhbHNlJyk7XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLnRyYXBGb2N1cyA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy4kZWxlbWVudC5zaWJsaW5ncygnW2RhdGEtb2ZmLWNhbnZhcy1jb250ZW50XScpLnJlbW92ZUF0dHIoJ3RhYmluZGV4Jyk7XG4gICAgICBGb3VuZGF0aW9uLktleWJvYXJkLnJlbGVhc2VGb2N1cyh0aGlzLiRlbGVtZW50KTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVG9nZ2xlcyB0aGUgb2ZmLWNhbnZhcyBtZW51IG9wZW4gb3IgY2xvc2VkLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHBhcmFtIHtPYmplY3R9IGV2ZW50IC0gRXZlbnQgb2JqZWN0IHBhc3NlZCBmcm9tIGxpc3RlbmVyLlxuICAgKiBAcGFyYW0ge2pRdWVyeX0gdHJpZ2dlciAtIGVsZW1lbnQgdGhhdCB0cmlnZ2VyZWQgdGhlIG9mZi1jYW52YXMgdG8gb3Blbi5cbiAgICovXG4gIHRvZ2dsZShldmVudCwgdHJpZ2dlcikge1xuICAgIGlmICh0aGlzLiRlbGVtZW50Lmhhc0NsYXNzKCdpcy1vcGVuJykpIHtcbiAgICAgIHRoaXMuY2xvc2UoZXZlbnQsIHRyaWdnZXIpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIHRoaXMub3BlbihldmVudCwgdHJpZ2dlcik7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEhhbmRsZXMga2V5Ym9hcmQgaW5wdXQgd2hlbiBkZXRlY3RlZC4gV2hlbiB0aGUgZXNjYXBlIGtleSBpcyBwcmVzc2VkLCB0aGUgb2ZmLWNhbnZhcyBtZW51IGNsb3NlcywgYW5kIGZvY3VzIGlzIHJlc3RvcmVkIHRvIHRoZSBlbGVtZW50IHRoYXQgb3BlbmVkIHRoZSBtZW51LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9oYW5kbGVLZXlib2FyZChlKSB7XG4gICAgRm91bmRhdGlvbi5LZXlib2FyZC5oYW5kbGVLZXkoZSwgJ09mZkNhbnZhcycsIHtcbiAgICAgIGNsb3NlOiAoKSA9PiB7XG4gICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgdGhpcy4kbGFzdFRyaWdnZXIuZm9jdXMoKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9LFxuICAgICAgaGFuZGxlZDogKCkgPT4ge1xuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogRGVzdHJveXMgdGhlIG9mZmNhbnZhcyBwbHVnaW4uXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLmNsb3NlKCk7XG4gICAgdGhpcy4kZWxlbWVudC5vZmYoJy56Zi50cmlnZ2VyIC56Zi5vZmZjYW52YXMnKTtcbiAgICB0aGlzLiRvdmVybGF5Lm9mZignLnpmLm9mZmNhbnZhcycpO1xuXG4gICAgRm91bmRhdGlvbi51bnJlZ2lzdGVyUGx1Z2luKHRoaXMpO1xuICB9XG59XG5cbk9mZkNhbnZhcy5kZWZhdWx0cyA9IHtcbiAgLyoqXG4gICAqIEFsbG93IHRoZSB1c2VyIHRvIGNsaWNrIG91dHNpZGUgb2YgdGhlIG1lbnUgdG8gY2xvc2UgaXQuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgdHJ1ZVxuICAgKi9cbiAgY2xvc2VPbkNsaWNrOiB0cnVlLFxuXG4gIC8qKlxuICAgKiBBZGRzIGFuIG92ZXJsYXkgb24gdG9wIG9mIGBbZGF0YS1vZmYtY2FudmFzLWNvbnRlbnRdYC5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSB0cnVlXG4gICAqL1xuICBjb250ZW50T3ZlcmxheTogdHJ1ZSxcblxuICAvKipcbiAgICogRW5hYmxlL2Rpc2FibGUgc2Nyb2xsaW5nIG9mIHRoZSBtYWluIGNvbnRlbnQgd2hlbiBhbiBvZmYgY2FudmFzIHBhbmVsIGlzIG9wZW4uXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgdHJ1ZVxuICAgKi9cbiAgY29udGVudFNjcm9sbDogdHJ1ZSxcblxuICAvKipcbiAgICogQW1vdW50IG9mIHRpbWUgaW4gbXMgdGhlIG9wZW4gYW5kIGNsb3NlIHRyYW5zaXRpb24gcmVxdWlyZXMuIElmIG5vbmUgc2VsZWN0ZWQsIHB1bGxzIGZyb20gYm9keSBzdHlsZS5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSA1MDBcbiAgICovXG4gIHRyYW5zaXRpb25UaW1lOiAwLFxuXG4gIC8qKlxuICAgKiBUeXBlIG9mIHRyYW5zaXRpb24gZm9yIHRoZSBvZmZjYW52YXMgbWVudS4gT3B0aW9ucyBhcmUgJ3B1c2gnLCAnZGV0YWNoZWQnIG9yICdzbGlkZScuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgcHVzaFxuICAgKi9cbiAgdHJhbnNpdGlvbjogJ3B1c2gnLFxuXG4gIC8qKlxuICAgKiBGb3JjZSB0aGUgcGFnZSB0byBzY3JvbGwgdG8gdG9wIG9yIGJvdHRvbSBvbiBvcGVuLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIHRvcFxuICAgKi9cbiAgZm9yY2VUbzogbnVsbCxcblxuICAvKipcbiAgICogQWxsb3cgdGhlIG9mZmNhbnZhcyB0byByZW1haW4gb3BlbiBmb3IgY2VydGFpbiBicmVha3BvaW50cy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBmYWxzZVxuICAgKi9cbiAgaXNSZXZlYWxlZDogZmFsc2UsXG5cbiAgLyoqXG4gICAqIEJyZWFrcG9pbnQgYXQgd2hpY2ggdG8gcmV2ZWFsLiBKUyB3aWxsIHVzZSBhIFJlZ0V4cCB0byB0YXJnZXQgc3RhbmRhcmQgY2xhc3NlcywgaWYgY2hhbmdpbmcgY2xhc3NuYW1lcywgcGFzcyB5b3VyIGNsYXNzIHdpdGggdGhlIGByZXZlYWxDbGFzc2Agb3B0aW9uLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIHJldmVhbC1mb3ItbGFyZ2VcbiAgICovXG4gIHJldmVhbE9uOiBudWxsLFxuXG4gIC8qKlxuICAgKiBGb3JjZSBmb2N1cyB0byB0aGUgb2ZmY2FudmFzIG9uIG9wZW4uIElmIHRydWUsIHdpbGwgZm9jdXMgdGhlIG9wZW5pbmcgdHJpZ2dlciBvbiBjbG9zZS5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSB0cnVlXG4gICAqL1xuICBhdXRvRm9jdXM6IHRydWUsXG5cbiAgLyoqXG4gICAqIENsYXNzIHVzZWQgdG8gZm9yY2UgYW4gb2ZmY2FudmFzIHRvIHJlbWFpbiBvcGVuLiBGb3VuZGF0aW9uIGRlZmF1bHRzIGZvciB0aGlzIGFyZSBgcmV2ZWFsLWZvci1sYXJnZWAgJiBgcmV2ZWFsLWZvci1tZWRpdW1gLlxuICAgKiBAb3B0aW9uXG4gICAqIFRPRE8gaW1wcm92ZSB0aGUgcmVnZXggdGVzdGluZyBmb3IgdGhpcy5cbiAgICogQGV4YW1wbGUgcmV2ZWFsLWZvci1sYXJnZVxuICAgKi9cbiAgcmV2ZWFsQ2xhc3M6ICdyZXZlYWwtZm9yLScsXG5cbiAgLyoqXG4gICAqIFRyaWdnZXJzIG9wdGlvbmFsIGZvY3VzIHRyYXBwaW5nIHdoZW4gb3BlbmluZyBhbiBvZmZjYW52YXMuIFNldHMgdGFiaW5kZXggb2YgW2RhdGEtb2ZmLWNhbnZhcy1jb250ZW50XSB0byAtMSBmb3IgYWNjZXNzaWJpbGl0eSBwdXJwb3Nlcy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSB0cnVlXG4gICAqL1xuICB0cmFwRm9jdXM6IGZhbHNlXG59XG5cbi8vIFdpbmRvdyBleHBvcnRzXG5Gb3VuZGF0aW9uLnBsdWdpbihPZmZDYW52YXMsICdPZmZDYW52YXMnKTtcblxufShqUXVlcnkpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4hZnVuY3Rpb24oJCkge1xuXG4vKipcbiAqIFJlc3BvbnNpdmVNZW51IG1vZHVsZS5cbiAqIEBtb2R1bGUgZm91bmRhdGlvbi5yZXNwb25zaXZlTWVudVxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC50cmlnZ2Vyc1xuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC5tZWRpYVF1ZXJ5XG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLmFjY29yZGlvbk1lbnVcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwuZHJpbGxkb3duXG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLmRyb3Bkb3duLW1lbnVcbiAqL1xuXG5jbGFzcyBSZXNwb25zaXZlTWVudSB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IGluc3RhbmNlIG9mIGEgcmVzcG9uc2l2ZSBtZW51LlxuICAgKiBAY2xhc3NcbiAgICogQGZpcmVzIFJlc3BvbnNpdmVNZW51I2luaXRcbiAgICogQHBhcmFtIHtqUXVlcnl9IGVsZW1lbnQgLSBqUXVlcnkgb2JqZWN0IHRvIG1ha2UgaW50byBhIGRyb3Bkb3duIG1lbnUuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zIC0gT3ZlcnJpZGVzIHRvIHRoZSBkZWZhdWx0IHBsdWdpbiBzZXR0aW5ncy5cbiAgICovXG4gIGNvbnN0cnVjdG9yKGVsZW1lbnQsIG9wdGlvbnMpIHtcbiAgICB0aGlzLiRlbGVtZW50ID0gJChlbGVtZW50KTtcbiAgICB0aGlzLnJ1bGVzID0gdGhpcy4kZWxlbWVudC5kYXRhKCdyZXNwb25zaXZlLW1lbnUnKTtcbiAgICB0aGlzLmN1cnJlbnRNcSA9IG51bGw7XG4gICAgdGhpcy5jdXJyZW50UGx1Z2luID0gbnVsbDtcblxuICAgIHRoaXMuX2luaXQoKTtcbiAgICB0aGlzLl9ldmVudHMoKTtcblxuICAgIEZvdW5kYXRpb24ucmVnaXN0ZXJQbHVnaW4odGhpcywgJ1Jlc3BvbnNpdmVNZW51Jyk7XG4gIH1cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgdGhlIE1lbnUgYnkgcGFyc2luZyB0aGUgY2xhc3NlcyBmcm9tIHRoZSAnZGF0YS1SZXNwb25zaXZlTWVudScgYXR0cmlidXRlIG9uIHRoZSBlbGVtZW50LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9pbml0KCkge1xuICAgIC8vIFRoZSBmaXJzdCB0aW1lIGFuIEludGVyY2hhbmdlIHBsdWdpbiBpcyBpbml0aWFsaXplZCwgdGhpcy5ydWxlcyBpcyBjb252ZXJ0ZWQgZnJvbSBhIHN0cmluZyBvZiBcImNsYXNzZXNcIiB0byBhbiBvYmplY3Qgb2YgcnVsZXNcbiAgICBpZiAodHlwZW9mIHRoaXMucnVsZXMgPT09ICdzdHJpbmcnKSB7XG4gICAgICBsZXQgcnVsZXNUcmVlID0ge307XG5cbiAgICAgIC8vIFBhcnNlIHJ1bGVzIGZyb20gXCJjbGFzc2VzXCIgcHVsbGVkIGZyb20gZGF0YSBhdHRyaWJ1dGVcbiAgICAgIGxldCBydWxlcyA9IHRoaXMucnVsZXMuc3BsaXQoJyAnKTtcblxuICAgICAgLy8gSXRlcmF0ZSB0aHJvdWdoIGV2ZXJ5IHJ1bGUgZm91bmRcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcnVsZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgbGV0IHJ1bGUgPSBydWxlc1tpXS5zcGxpdCgnLScpO1xuICAgICAgICBsZXQgcnVsZVNpemUgPSBydWxlLmxlbmd0aCA+IDEgPyBydWxlWzBdIDogJ3NtYWxsJztcbiAgICAgICAgbGV0IHJ1bGVQbHVnaW4gPSBydWxlLmxlbmd0aCA+IDEgPyBydWxlWzFdIDogcnVsZVswXTtcblxuICAgICAgICBpZiAoTWVudVBsdWdpbnNbcnVsZVBsdWdpbl0gIT09IG51bGwpIHtcbiAgICAgICAgICBydWxlc1RyZWVbcnVsZVNpemVdID0gTWVudVBsdWdpbnNbcnVsZVBsdWdpbl07XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgdGhpcy5ydWxlcyA9IHJ1bGVzVHJlZTtcbiAgICB9XG5cbiAgICBpZiAoISQuaXNFbXB0eU9iamVjdCh0aGlzLnJ1bGVzKSkge1xuICAgICAgdGhpcy5fY2hlY2tNZWRpYVF1ZXJpZXMoKTtcbiAgICB9XG4gICAgLy8gQWRkIGRhdGEtbXV0YXRlIHNpbmNlIGNoaWxkcmVuIG1heSBuZWVkIGl0LlxuICAgIHRoaXMuJGVsZW1lbnQuYXR0cignZGF0YS1tdXRhdGUnLCAodGhpcy4kZWxlbWVudC5hdHRyKCdkYXRhLW11dGF0ZScpIHx8IEZvdW5kYXRpb24uR2V0WW9EaWdpdHMoNiwgJ3Jlc3BvbnNpdmUtbWVudScpKSk7XG4gIH1cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgZXZlbnRzIGZvciB0aGUgTWVudS5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfZXZlbnRzKCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAkKHdpbmRvdykub24oJ2NoYW5nZWQuemYubWVkaWFxdWVyeScsIGZ1bmN0aW9uKCkge1xuICAgICAgX3RoaXMuX2NoZWNrTWVkaWFRdWVyaWVzKCk7XG4gICAgfSk7XG4gICAgLy8gJCh3aW5kb3cpLm9uKCdyZXNpemUuemYuUmVzcG9uc2l2ZU1lbnUnLCBmdW5jdGlvbigpIHtcbiAgICAvLyAgIF90aGlzLl9jaGVja01lZGlhUXVlcmllcygpO1xuICAgIC8vIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrcyB0aGUgY3VycmVudCBzY3JlZW4gd2lkdGggYWdhaW5zdCBhdmFpbGFibGUgbWVkaWEgcXVlcmllcy4gSWYgdGhlIG1lZGlhIHF1ZXJ5IGhhcyBjaGFuZ2VkLCBhbmQgdGhlIHBsdWdpbiBuZWVkZWQgaGFzIGNoYW5nZWQsIHRoZSBwbHVnaW5zIHdpbGwgc3dhcCBvdXQuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2NoZWNrTWVkaWFRdWVyaWVzKCkge1xuICAgIHZhciBtYXRjaGVkTXEsIF90aGlzID0gdGhpcztcbiAgICAvLyBJdGVyYXRlIHRocm91Z2ggZWFjaCBydWxlIGFuZCBmaW5kIHRoZSBsYXN0IG1hdGNoaW5nIHJ1bGVcbiAgICAkLmVhY2godGhpcy5ydWxlcywgZnVuY3Rpb24oa2V5KSB7XG4gICAgICBpZiAoRm91bmRhdGlvbi5NZWRpYVF1ZXJ5LmF0TGVhc3Qoa2V5KSkge1xuICAgICAgICBtYXRjaGVkTXEgPSBrZXk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBObyBtYXRjaD8gTm8gZGljZVxuICAgIGlmICghbWF0Y2hlZE1xKSByZXR1cm47XG5cbiAgICAvLyBQbHVnaW4gYWxyZWFkeSBpbml0aWFsaXplZD8gV2UgZ29vZFxuICAgIGlmICh0aGlzLmN1cnJlbnRQbHVnaW4gaW5zdGFuY2VvZiB0aGlzLnJ1bGVzW21hdGNoZWRNcV0ucGx1Z2luKSByZXR1cm47XG5cbiAgICAvLyBSZW1vdmUgZXhpc3RpbmcgcGx1Z2luLXNwZWNpZmljIENTUyBjbGFzc2VzXG4gICAgJC5lYWNoKE1lbnVQbHVnaW5zLCBmdW5jdGlvbihrZXksIHZhbHVlKSB7XG4gICAgICBfdGhpcy4kZWxlbWVudC5yZW1vdmVDbGFzcyh2YWx1ZS5jc3NDbGFzcyk7XG4gICAgfSk7XG5cbiAgICAvLyBBZGQgdGhlIENTUyBjbGFzcyBmb3IgdGhlIG5ldyBwbHVnaW5cbiAgICB0aGlzLiRlbGVtZW50LmFkZENsYXNzKHRoaXMucnVsZXNbbWF0Y2hlZE1xXS5jc3NDbGFzcyk7XG5cbiAgICAvLyBDcmVhdGUgYW4gaW5zdGFuY2Ugb2YgdGhlIG5ldyBwbHVnaW5cbiAgICBpZiAodGhpcy5jdXJyZW50UGx1Z2luKSB0aGlzLmN1cnJlbnRQbHVnaW4uZGVzdHJveSgpO1xuICAgIHRoaXMuY3VycmVudFBsdWdpbiA9IG5ldyB0aGlzLnJ1bGVzW21hdGNoZWRNcV0ucGx1Z2luKHRoaXMuJGVsZW1lbnQsIHt9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXN0cm95cyB0aGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgcGx1Z2luIG9uIHRoaXMgZWxlbWVudCwgYXMgd2VsbCBhcyB0aGUgd2luZG93IHJlc2l6ZSBoYW5kbGVyIHRoYXQgc3dpdGNoZXMgdGhlIHBsdWdpbnMgb3V0LlxuICAgKiBAZnVuY3Rpb25cbiAgICovXG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5jdXJyZW50UGx1Z2luLmRlc3Ryb3koKTtcbiAgICAkKHdpbmRvdykub2ZmKCcuemYuUmVzcG9uc2l2ZU1lbnUnKTtcbiAgICBGb3VuZGF0aW9uLnVucmVnaXN0ZXJQbHVnaW4odGhpcyk7XG4gIH1cbn1cblxuUmVzcG9uc2l2ZU1lbnUuZGVmYXVsdHMgPSB7fTtcblxuLy8gVGhlIHBsdWdpbiBtYXRjaGVzIHRoZSBwbHVnaW4gY2xhc3NlcyB3aXRoIHRoZXNlIHBsdWdpbiBpbnN0YW5jZXMuXG52YXIgTWVudVBsdWdpbnMgPSB7XG4gIGRyb3Bkb3duOiB7XG4gICAgY3NzQ2xhc3M6ICdkcm9wZG93bicsXG4gICAgcGx1Z2luOiBGb3VuZGF0aW9uLl9wbHVnaW5zWydkcm9wZG93bi1tZW51J10gfHwgbnVsbFxuICB9LFxuIGRyaWxsZG93bjoge1xuICAgIGNzc0NsYXNzOiAnZHJpbGxkb3duJyxcbiAgICBwbHVnaW46IEZvdW5kYXRpb24uX3BsdWdpbnNbJ2RyaWxsZG93biddIHx8IG51bGxcbiAgfSxcbiAgYWNjb3JkaW9uOiB7XG4gICAgY3NzQ2xhc3M6ICdhY2NvcmRpb24tbWVudScsXG4gICAgcGx1Z2luOiBGb3VuZGF0aW9uLl9wbHVnaW5zWydhY2NvcmRpb24tbWVudSddIHx8IG51bGxcbiAgfVxufTtcblxuLy8gV2luZG93IGV4cG9ydHNcbkZvdW5kYXRpb24ucGx1Z2luKFJlc3BvbnNpdmVNZW51LCAnUmVzcG9uc2l2ZU1lbnUnKTtcblxufShqUXVlcnkpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4hZnVuY3Rpb24oJCkge1xuXG4vKipcbiAqIFJlc3BvbnNpdmVUb2dnbGUgbW9kdWxlLlxuICogQG1vZHVsZSBmb3VuZGF0aW9uLnJlc3BvbnNpdmVUb2dnbGVcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwubWVkaWFRdWVyeVxuICovXG5cbmNsYXNzIFJlc3BvbnNpdmVUb2dnbGUge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBpbnN0YW5jZSBvZiBUYWIgQmFyLlxuICAgKiBAY2xhc3NcbiAgICogQGZpcmVzIFJlc3BvbnNpdmVUb2dnbGUjaW5pdFxuICAgKiBAcGFyYW0ge2pRdWVyeX0gZWxlbWVudCAtIGpRdWVyeSBvYmplY3QgdG8gYXR0YWNoIHRhYiBiYXIgZnVuY3Rpb25hbGl0eSB0by5cbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMgLSBPdmVycmlkZXMgdG8gdGhlIGRlZmF1bHQgcGx1Z2luIHNldHRpbmdzLlxuICAgKi9cbiAgY29uc3RydWN0b3IoZWxlbWVudCwgb3B0aW9ucykge1xuICAgIHRoaXMuJGVsZW1lbnQgPSAkKGVsZW1lbnQpO1xuICAgIHRoaXMub3B0aW9ucyA9ICQuZXh0ZW5kKHt9LCBSZXNwb25zaXZlVG9nZ2xlLmRlZmF1bHRzLCB0aGlzLiRlbGVtZW50LmRhdGEoKSwgb3B0aW9ucyk7XG5cbiAgICB0aGlzLl9pbml0KCk7XG4gICAgdGhpcy5fZXZlbnRzKCk7XG5cbiAgICBGb3VuZGF0aW9uLnJlZ2lzdGVyUGx1Z2luKHRoaXMsICdSZXNwb25zaXZlVG9nZ2xlJyk7XG4gIH1cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgdGhlIHRhYiBiYXIgYnkgZmluZGluZyB0aGUgdGFyZ2V0IGVsZW1lbnQsIHRvZ2dsaW5nIGVsZW1lbnQsIGFuZCBydW5uaW5nIHVwZGF0ZSgpLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9pbml0KCkge1xuICAgIHZhciB0YXJnZXRJRCA9IHRoaXMuJGVsZW1lbnQuZGF0YSgncmVzcG9uc2l2ZS10b2dnbGUnKTtcbiAgICBpZiAoIXRhcmdldElEKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdZb3VyIHRhYiBiYXIgbmVlZHMgYW4gSUQgb2YgYSBNZW51IGFzIHRoZSB2YWx1ZSBvZiBkYXRhLXRhYi1iYXIuJyk7XG4gICAgfVxuXG4gICAgdGhpcy4kdGFyZ2V0TWVudSA9ICQoYCMke3RhcmdldElEfWApO1xuICAgIHRoaXMuJHRvZ2dsZXIgPSB0aGlzLiRlbGVtZW50LmZpbmQoJ1tkYXRhLXRvZ2dsZV0nKTtcbiAgICB0aGlzLm9wdGlvbnMgPSAkLmV4dGVuZCh7fSwgdGhpcy5vcHRpb25zLCB0aGlzLiR0YXJnZXRNZW51LmRhdGEoKSk7XG5cbiAgICAvLyBJZiB0aGV5IHdlcmUgc2V0LCBwYXJzZSB0aGUgYW5pbWF0aW9uIGNsYXNzZXNcbiAgICBpZih0aGlzLm9wdGlvbnMuYW5pbWF0ZSkge1xuICAgICAgbGV0IGlucHV0ID0gdGhpcy5vcHRpb25zLmFuaW1hdGUuc3BsaXQoJyAnKTtcblxuICAgICAgdGhpcy5hbmltYXRpb25JbiA9IGlucHV0WzBdO1xuICAgICAgdGhpcy5hbmltYXRpb25PdXQgPSBpbnB1dFsxXSB8fCBudWxsO1xuICAgIH1cblxuICAgIHRoaXMuX3VwZGF0ZSgpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgbmVjZXNzYXJ5IGV2ZW50IGhhbmRsZXJzIGZvciB0aGUgdGFiIGJhciB0byB3b3JrLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9ldmVudHMoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIHRoaXMuX3VwZGF0ZU1xSGFuZGxlciA9IHRoaXMuX3VwZGF0ZS5iaW5kKHRoaXMpO1xuXG4gICAgJCh3aW5kb3cpLm9uKCdjaGFuZ2VkLnpmLm1lZGlhcXVlcnknLCB0aGlzLl91cGRhdGVNcUhhbmRsZXIpO1xuXG4gICAgdGhpcy4kdG9nZ2xlci5vbignY2xpY2suemYucmVzcG9uc2l2ZVRvZ2dsZScsIHRoaXMudG9nZ2xlTWVudS5iaW5kKHRoaXMpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVja3MgdGhlIGN1cnJlbnQgbWVkaWEgcXVlcnkgdG8gZGV0ZXJtaW5lIGlmIHRoZSB0YWIgYmFyIHNob3VsZCBiZSB2aXNpYmxlIG9yIGhpZGRlbi5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfdXBkYXRlKCkge1xuICAgIC8vIE1vYmlsZVxuICAgIGlmICghRm91bmRhdGlvbi5NZWRpYVF1ZXJ5LmF0TGVhc3QodGhpcy5vcHRpb25zLmhpZGVGb3IpKSB7XG4gICAgICB0aGlzLiRlbGVtZW50LnNob3coKTtcbiAgICAgIHRoaXMuJHRhcmdldE1lbnUuaGlkZSgpO1xuICAgIH1cblxuICAgIC8vIERlc2t0b3BcbiAgICBlbHNlIHtcbiAgICAgIHRoaXMuJGVsZW1lbnQuaGlkZSgpO1xuICAgICAgdGhpcy4kdGFyZ2V0TWVudS5zaG93KCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFRvZ2dsZXMgdGhlIGVsZW1lbnQgYXR0YWNoZWQgdG8gdGhlIHRhYiBiYXIuIFRoZSB0b2dnbGUgb25seSBoYXBwZW5zIGlmIHRoZSBzY3JlZW4gaXMgc21hbGwgZW5vdWdoIHRvIGFsbG93IGl0LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQGZpcmVzIFJlc3BvbnNpdmVUb2dnbGUjdG9nZ2xlZFxuICAgKi9cbiAgdG9nZ2xlTWVudSgpIHtcbiAgICBpZiAoIUZvdW5kYXRpb24uTWVkaWFRdWVyeS5hdExlYXN0KHRoaXMub3B0aW9ucy5oaWRlRm9yKSkge1xuICAgICAgaWYodGhpcy5vcHRpb25zLmFuaW1hdGUpIHtcbiAgICAgICAgaWYgKHRoaXMuJHRhcmdldE1lbnUuaXMoJzpoaWRkZW4nKSkge1xuICAgICAgICAgIEZvdW5kYXRpb24uTW90aW9uLmFuaW1hdGVJbih0aGlzLiR0YXJnZXRNZW51LCB0aGlzLmFuaW1hdGlvbkluLCAoKSA9PiB7XG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIEZpcmVzIHdoZW4gdGhlIGVsZW1lbnQgYXR0YWNoZWQgdG8gdGhlIHRhYiBiYXIgdG9nZ2xlcy5cbiAgICAgICAgICAgICAqIEBldmVudCBSZXNwb25zaXZlVG9nZ2xlI3RvZ2dsZWRcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgdGhpcy4kZWxlbWVudC50cmlnZ2VyKCd0b2dnbGVkLnpmLnJlc3BvbnNpdmVUb2dnbGUnKTtcbiAgICAgICAgICAgIHRoaXMuJHRhcmdldE1lbnUuZmluZCgnW2RhdGEtbXV0YXRlXScpLnRyaWdnZXJIYW5kbGVyKCdtdXRhdGVtZS56Zi50cmlnZ2VyJyk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgRm91bmRhdGlvbi5Nb3Rpb24uYW5pbWF0ZU91dCh0aGlzLiR0YXJnZXRNZW51LCB0aGlzLmFuaW1hdGlvbk91dCwgKCkgPT4ge1xuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBGaXJlcyB3aGVuIHRoZSBlbGVtZW50IGF0dGFjaGVkIHRvIHRoZSB0YWIgYmFyIHRvZ2dsZXMuXG4gICAgICAgICAgICAgKiBAZXZlbnQgUmVzcG9uc2l2ZVRvZ2dsZSN0b2dnbGVkXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIHRoaXMuJGVsZW1lbnQudHJpZ2dlcigndG9nZ2xlZC56Zi5yZXNwb25zaXZlVG9nZ2xlJyk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICB0aGlzLiR0YXJnZXRNZW51LnRvZ2dsZSgwKTtcbiAgICAgICAgdGhpcy4kdGFyZ2V0TWVudS5maW5kKCdbZGF0YS1tdXRhdGVdJykudHJpZ2dlcignbXV0YXRlbWUuemYudHJpZ2dlcicpO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBGaXJlcyB3aGVuIHRoZSBlbGVtZW50IGF0dGFjaGVkIHRvIHRoZSB0YWIgYmFyIHRvZ2dsZXMuXG4gICAgICAgICAqIEBldmVudCBSZXNwb25zaXZlVG9nZ2xlI3RvZ2dsZWRcbiAgICAgICAgICovXG4gICAgICAgIHRoaXMuJGVsZW1lbnQudHJpZ2dlcigndG9nZ2xlZC56Zi5yZXNwb25zaXZlVG9nZ2xlJyk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy4kZWxlbWVudC5vZmYoJy56Zi5yZXNwb25zaXZlVG9nZ2xlJyk7XG4gICAgdGhpcy4kdG9nZ2xlci5vZmYoJy56Zi5yZXNwb25zaXZlVG9nZ2xlJyk7XG5cbiAgICAkKHdpbmRvdykub2ZmKCdjaGFuZ2VkLnpmLm1lZGlhcXVlcnknLCB0aGlzLl91cGRhdGVNcUhhbmRsZXIpO1xuXG4gICAgRm91bmRhdGlvbi51bnJlZ2lzdGVyUGx1Z2luKHRoaXMpO1xuICB9XG59XG5cblJlc3BvbnNpdmVUb2dnbGUuZGVmYXVsdHMgPSB7XG4gIC8qKlxuICAgKiBUaGUgYnJlYWtwb2ludCBhZnRlciB3aGljaCB0aGUgbWVudSBpcyBhbHdheXMgc2hvd24sIGFuZCB0aGUgdGFiIGJhciBpcyBoaWRkZW4uXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgJ21lZGl1bSdcbiAgICovXG4gIGhpZGVGb3I6ICdtZWRpdW0nLFxuXG4gIC8qKlxuICAgKiBUbyBkZWNpZGUgaWYgdGhlIHRvZ2dsZSBzaG91bGQgYmUgYW5pbWF0ZWQgb3Igbm90LlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICBhbmltYXRlOiBmYWxzZVxufTtcblxuLy8gV2luZG93IGV4cG9ydHNcbkZvdW5kYXRpb24ucGx1Z2luKFJlc3BvbnNpdmVUb2dnbGUsICdSZXNwb25zaXZlVG9nZ2xlJyk7XG5cbn0oalF1ZXJ5KTtcbiIsIid1c2Ugc3RyaWN0JztcblxuIWZ1bmN0aW9uKCQpIHtcblxuLyoqXG4gKiBUb2dnbGVyIG1vZHVsZS5cbiAqIEBtb2R1bGUgZm91bmRhdGlvbi50b2dnbGVyXG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLm1vdGlvblxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC50cmlnZ2Vyc1xuICovXG5cbmNsYXNzIFRvZ2dsZXIge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBpbnN0YW5jZSBvZiBUb2dnbGVyLlxuICAgKiBAY2xhc3NcbiAgICogQGZpcmVzIFRvZ2dsZXIjaW5pdFxuICAgKiBAcGFyYW0ge09iamVjdH0gZWxlbWVudCAtIGpRdWVyeSBvYmplY3QgdG8gYWRkIHRoZSB0cmlnZ2VyIHRvLlxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyAtIE92ZXJyaWRlcyB0byB0aGUgZGVmYXVsdCBwbHVnaW4gc2V0dGluZ3MuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihlbGVtZW50LCBvcHRpb25zKSB7XG4gICAgdGhpcy4kZWxlbWVudCA9IGVsZW1lbnQ7XG4gICAgdGhpcy5vcHRpb25zID0gJC5leHRlbmQoe30sIFRvZ2dsZXIuZGVmYXVsdHMsIGVsZW1lbnQuZGF0YSgpLCBvcHRpb25zKTtcbiAgICB0aGlzLmNsYXNzTmFtZSA9ICcnO1xuXG4gICAgdGhpcy5faW5pdCgpO1xuICAgIHRoaXMuX2V2ZW50cygpO1xuXG4gICAgRm91bmRhdGlvbi5yZWdpc3RlclBsdWdpbih0aGlzLCAnVG9nZ2xlcicpO1xuICB9XG5cbiAgLyoqXG4gICAqIEluaXRpYWxpemVzIHRoZSBUb2dnbGVyIHBsdWdpbiBieSBwYXJzaW5nIHRoZSB0b2dnbGUgY2xhc3MgZnJvbSBkYXRhLXRvZ2dsZXIsIG9yIGFuaW1hdGlvbiBjbGFzc2VzIGZyb20gZGF0YS1hbmltYXRlLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9pbml0KCkge1xuICAgIHZhciBpbnB1dDtcbiAgICAvLyBQYXJzZSBhbmltYXRpb24gY2xhc3NlcyBpZiB0aGV5IHdlcmUgc2V0XG4gICAgaWYgKHRoaXMub3B0aW9ucy5hbmltYXRlKSB7XG4gICAgICBpbnB1dCA9IHRoaXMub3B0aW9ucy5hbmltYXRlLnNwbGl0KCcgJyk7XG5cbiAgICAgIHRoaXMuYW5pbWF0aW9uSW4gPSBpbnB1dFswXTtcbiAgICAgIHRoaXMuYW5pbWF0aW9uT3V0ID0gaW5wdXRbMV0gfHwgbnVsbDtcbiAgICB9XG4gICAgLy8gT3RoZXJ3aXNlLCBwYXJzZSB0b2dnbGUgY2xhc3NcbiAgICBlbHNlIHtcbiAgICAgIGlucHV0ID0gdGhpcy4kZWxlbWVudC5kYXRhKCd0b2dnbGVyJyk7XG4gICAgICAvLyBBbGxvdyBmb3IgYSAuIGF0IHRoZSBiZWdpbm5pbmcgb2YgdGhlIHN0cmluZ1xuICAgICAgdGhpcy5jbGFzc05hbWUgPSBpbnB1dFswXSA9PT0gJy4nID8gaW5wdXQuc2xpY2UoMSkgOiBpbnB1dDtcbiAgICB9XG5cbiAgICAvLyBBZGQgQVJJQSBhdHRyaWJ1dGVzIHRvIHRyaWdnZXJzXG4gICAgdmFyIGlkID0gdGhpcy4kZWxlbWVudFswXS5pZDtcbiAgICAkKGBbZGF0YS1vcGVuPVwiJHtpZH1cIl0sIFtkYXRhLWNsb3NlPVwiJHtpZH1cIl0sIFtkYXRhLXRvZ2dsZT1cIiR7aWR9XCJdYClcbiAgICAgIC5hdHRyKCdhcmlhLWNvbnRyb2xzJywgaWQpO1xuICAgIC8vIElmIHRoZSB0YXJnZXQgaXMgaGlkZGVuLCBhZGQgYXJpYS1oaWRkZW5cbiAgICB0aGlzLiRlbGVtZW50LmF0dHIoJ2FyaWEtZXhwYW5kZWQnLCB0aGlzLiRlbGVtZW50LmlzKCc6aGlkZGVuJykgPyBmYWxzZSA6IHRydWUpO1xuICB9XG5cbiAgLyoqXG4gICAqIEluaXRpYWxpemVzIGV2ZW50cyBmb3IgdGhlIHRvZ2dsZSB0cmlnZ2VyLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9ldmVudHMoKSB7XG4gICAgdGhpcy4kZWxlbWVudC5vZmYoJ3RvZ2dsZS56Zi50cmlnZ2VyJykub24oJ3RvZ2dsZS56Zi50cmlnZ2VyJywgdGhpcy50b2dnbGUuYmluZCh0aGlzKSk7XG4gIH1cblxuICAvKipcbiAgICogVG9nZ2xlcyB0aGUgdGFyZ2V0IGNsYXNzIG9uIHRoZSB0YXJnZXQgZWxlbWVudC4gQW4gZXZlbnQgaXMgZmlyZWQgZnJvbSB0aGUgb3JpZ2luYWwgdHJpZ2dlciBkZXBlbmRpbmcgb24gaWYgdGhlIHJlc3VsdGFudCBzdGF0ZSB3YXMgXCJvblwiIG9yIFwib2ZmXCIuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAZmlyZXMgVG9nZ2xlciNvblxuICAgKiBAZmlyZXMgVG9nZ2xlciNvZmZcbiAgICovXG4gIHRvZ2dsZSgpIHtcbiAgICB0aGlzWyB0aGlzLm9wdGlvbnMuYW5pbWF0ZSA/ICdfdG9nZ2xlQW5pbWF0ZScgOiAnX3RvZ2dsZUNsYXNzJ10oKTtcbiAgfVxuXG4gIF90b2dnbGVDbGFzcygpIHtcbiAgICB0aGlzLiRlbGVtZW50LnRvZ2dsZUNsYXNzKHRoaXMuY2xhc3NOYW1lKTtcblxuICAgIHZhciBpc09uID0gdGhpcy4kZWxlbWVudC5oYXNDbGFzcyh0aGlzLmNsYXNzTmFtZSk7XG4gICAgaWYgKGlzT24pIHtcbiAgICAgIC8qKlxuICAgICAgICogRmlyZXMgaWYgdGhlIHRhcmdldCBlbGVtZW50IGhhcyB0aGUgY2xhc3MgYWZ0ZXIgYSB0b2dnbGUuXG4gICAgICAgKiBAZXZlbnQgVG9nZ2xlciNvblxuICAgICAgICovXG4gICAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ29uLnpmLnRvZ2dsZXInKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAvKipcbiAgICAgICAqIEZpcmVzIGlmIHRoZSB0YXJnZXQgZWxlbWVudCBkb2VzIG5vdCBoYXZlIHRoZSBjbGFzcyBhZnRlciBhIHRvZ2dsZS5cbiAgICAgICAqIEBldmVudCBUb2dnbGVyI29mZlxuICAgICAgICovXG4gICAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ29mZi56Zi50b2dnbGVyJyk7XG4gICAgfVxuXG4gICAgdGhpcy5fdXBkYXRlQVJJQShpc09uKTtcbiAgICB0aGlzLiRlbGVtZW50LmZpbmQoJ1tkYXRhLW11dGF0ZV0nKS50cmlnZ2VyKCdtdXRhdGVtZS56Zi50cmlnZ2VyJyk7XG4gIH1cblxuICBfdG9nZ2xlQW5pbWF0ZSgpIHtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgaWYgKHRoaXMuJGVsZW1lbnQuaXMoJzpoaWRkZW4nKSkge1xuICAgICAgRm91bmRhdGlvbi5Nb3Rpb24uYW5pbWF0ZUluKHRoaXMuJGVsZW1lbnQsIHRoaXMuYW5pbWF0aW9uSW4sIGZ1bmN0aW9uKCkge1xuICAgICAgICBfdGhpcy5fdXBkYXRlQVJJQSh0cnVlKTtcbiAgICAgICAgdGhpcy50cmlnZ2VyKCdvbi56Zi50b2dnbGVyJyk7XG4gICAgICAgIHRoaXMuZmluZCgnW2RhdGEtbXV0YXRlXScpLnRyaWdnZXIoJ211dGF0ZW1lLnpmLnRyaWdnZXInKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIEZvdW5kYXRpb24uTW90aW9uLmFuaW1hdGVPdXQodGhpcy4kZWxlbWVudCwgdGhpcy5hbmltYXRpb25PdXQsIGZ1bmN0aW9uKCkge1xuICAgICAgICBfdGhpcy5fdXBkYXRlQVJJQShmYWxzZSk7XG4gICAgICAgIHRoaXMudHJpZ2dlcignb2ZmLnpmLnRvZ2dsZXInKTtcbiAgICAgICAgdGhpcy5maW5kKCdbZGF0YS1tdXRhdGVdJykudHJpZ2dlcignbXV0YXRlbWUuemYudHJpZ2dlcicpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgX3VwZGF0ZUFSSUEoaXNPbikge1xuICAgIHRoaXMuJGVsZW1lbnQuYXR0cignYXJpYS1leHBhbmRlZCcsIGlzT24gPyB0cnVlIDogZmFsc2UpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlc3Ryb3lzIHRoZSBpbnN0YW5jZSBvZiBUb2dnbGVyIG9uIHRoZSBlbGVtZW50LlxuICAgKiBAZnVuY3Rpb25cbiAgICovXG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy4kZWxlbWVudC5vZmYoJy56Zi50b2dnbGVyJyk7XG4gICAgRm91bmRhdGlvbi51bnJlZ2lzdGVyUGx1Z2luKHRoaXMpO1xuICB9XG59XG5cblRvZ2dsZXIuZGVmYXVsdHMgPSB7XG4gIC8qKlxuICAgKiBUZWxscyB0aGUgcGx1Z2luIGlmIHRoZSBlbGVtZW50IHNob3VsZCBhbmltYXRlZCB3aGVuIHRvZ2dsZWQuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgZmFsc2VcbiAgICovXG4gIGFuaW1hdGU6IGZhbHNlXG59O1xuXG4vLyBXaW5kb3cgZXhwb3J0c1xuRm91bmRhdGlvbi5wbHVnaW4oVG9nZ2xlciwgJ1RvZ2dsZXInKTtcblxufShqUXVlcnkpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4hZnVuY3Rpb24oJCkge1xuXG4vKipcbiAqIFRvb2x0aXAgbW9kdWxlLlxuICogQG1vZHVsZSBmb3VuZGF0aW9uLnRvb2x0aXBcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwuYm94XG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLm1lZGlhUXVlcnlcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwudHJpZ2dlcnNcbiAqL1xuXG5jbGFzcyBUb29sdGlwIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgaW5zdGFuY2Ugb2YgYSBUb29sdGlwLlxuICAgKiBAY2xhc3NcbiAgICogQGZpcmVzIFRvb2x0aXAjaW5pdFxuICAgKiBAcGFyYW0ge2pRdWVyeX0gZWxlbWVudCAtIGpRdWVyeSBvYmplY3QgdG8gYXR0YWNoIGEgdG9vbHRpcCB0by5cbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMgLSBvYmplY3QgdG8gZXh0ZW5kIHRoZSBkZWZhdWx0IGNvbmZpZ3VyYXRpb24uXG4gICAqL1xuICBjb25zdHJ1Y3RvcihlbGVtZW50LCBvcHRpb25zKSB7XG4gICAgdGhpcy4kZWxlbWVudCA9IGVsZW1lbnQ7XG4gICAgdGhpcy5vcHRpb25zID0gJC5leHRlbmQoe30sIFRvb2x0aXAuZGVmYXVsdHMsIHRoaXMuJGVsZW1lbnQuZGF0YSgpLCBvcHRpb25zKTtcblxuICAgIHRoaXMuaXNBY3RpdmUgPSBmYWxzZTtcbiAgICB0aGlzLmlzQ2xpY2sgPSBmYWxzZTtcbiAgICB0aGlzLl9pbml0KCk7XG5cbiAgICBGb3VuZGF0aW9uLnJlZ2lzdGVyUGx1Z2luKHRoaXMsICdUb29sdGlwJyk7XG4gIH1cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgdGhlIHRvb2x0aXAgYnkgc2V0dGluZyB0aGUgY3JlYXRpbmcgdGhlIHRpcCBlbGVtZW50LCBhZGRpbmcgaXQncyB0ZXh0LCBzZXR0aW5nIHByaXZhdGUgdmFyaWFibGVzIGFuZCBzZXR0aW5nIGF0dHJpYnV0ZXMgb24gdGhlIGFuY2hvci5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9pbml0KCkge1xuICAgIHZhciBlbGVtSWQgPSB0aGlzLiRlbGVtZW50LmF0dHIoJ2FyaWEtZGVzY3JpYmVkYnknKSB8fCBGb3VuZGF0aW9uLkdldFlvRGlnaXRzKDYsICd0b29sdGlwJyk7XG5cbiAgICB0aGlzLm9wdGlvbnMucG9zaXRpb25DbGFzcyA9IHRoaXMub3B0aW9ucy5wb3NpdGlvbkNsYXNzIHx8IHRoaXMuX2dldFBvc2l0aW9uQ2xhc3ModGhpcy4kZWxlbWVudCk7XG4gICAgdGhpcy5vcHRpb25zLnRpcFRleHQgPSB0aGlzLm9wdGlvbnMudGlwVGV4dCB8fCB0aGlzLiRlbGVtZW50LmF0dHIoJ3RpdGxlJyk7XG4gICAgdGhpcy50ZW1wbGF0ZSA9IHRoaXMub3B0aW9ucy50ZW1wbGF0ZSA/ICQodGhpcy5vcHRpb25zLnRlbXBsYXRlKSA6IHRoaXMuX2J1aWxkVGVtcGxhdGUoZWxlbUlkKTtcblxuICAgIGlmICh0aGlzLm9wdGlvbnMuYWxsb3dIdG1sKSB7XG4gICAgICB0aGlzLnRlbXBsYXRlLmFwcGVuZFRvKGRvY3VtZW50LmJvZHkpXG4gICAgICAgIC5odG1sKHRoaXMub3B0aW9ucy50aXBUZXh0KVxuICAgICAgICAuaGlkZSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnRlbXBsYXRlLmFwcGVuZFRvKGRvY3VtZW50LmJvZHkpXG4gICAgICAgIC50ZXh0KHRoaXMub3B0aW9ucy50aXBUZXh0KVxuICAgICAgICAuaGlkZSgpO1xuICAgIH1cblxuICAgIHRoaXMuJGVsZW1lbnQuYXR0cih7XG4gICAgICAndGl0bGUnOiAnJyxcbiAgICAgICdhcmlhLWRlc2NyaWJlZGJ5JzogZWxlbUlkLFxuICAgICAgJ2RhdGEteWV0aS1ib3gnOiBlbGVtSWQsXG4gICAgICAnZGF0YS10b2dnbGUnOiBlbGVtSWQsXG4gICAgICAnZGF0YS1yZXNpemUnOiBlbGVtSWRcbiAgICB9KS5hZGRDbGFzcyh0aGlzLm9wdGlvbnMudHJpZ2dlckNsYXNzKTtcblxuICAgIC8vaGVscGVyIHZhcmlhYmxlcyB0byB0cmFjayBtb3ZlbWVudCBvbiBjb2xsaXNpb25zXG4gICAgdGhpcy51c2VkUG9zaXRpb25zID0gW107XG4gICAgdGhpcy5jb3VudGVyID0gNDtcbiAgICB0aGlzLmNsYXNzQ2hhbmdlZCA9IGZhbHNlO1xuXG4gICAgdGhpcy5fZXZlbnRzKCk7XG4gIH1cblxuICAvKipcbiAgICogR3JhYnMgdGhlIGN1cnJlbnQgcG9zaXRpb25pbmcgY2xhc3MsIGlmIHByZXNlbnQsIGFuZCByZXR1cm5zIHRoZSB2YWx1ZSBvciBhbiBlbXB0eSBzdHJpbmcuXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfZ2V0UG9zaXRpb25DbGFzcyhlbGVtZW50KSB7XG4gICAgaWYgKCFlbGVtZW50KSB7IHJldHVybiAnJzsgfVxuICAgIC8vIHZhciBwb3NpdGlvbiA9IGVsZW1lbnQuYXR0cignY2xhc3MnKS5tYXRjaCgvdG9wfGxlZnR8cmlnaHQvZyk7XG4gICAgdmFyIHBvc2l0aW9uID0gZWxlbWVudFswXS5jbGFzc05hbWUubWF0Y2goL1xcYih0b3B8bGVmdHxyaWdodClcXGIvZyk7XG4gICAgICAgIHBvc2l0aW9uID0gcG9zaXRpb24gPyBwb3NpdGlvblswXSA6ICcnO1xuICAgIHJldHVybiBwb3NpdGlvbjtcbiAgfTtcbiAgLyoqXG4gICAqIGJ1aWxkcyB0aGUgdG9vbHRpcCBlbGVtZW50LCBhZGRzIGF0dHJpYnV0ZXMsIGFuZCByZXR1cm5zIHRoZSB0ZW1wbGF0ZS5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9idWlsZFRlbXBsYXRlKGlkKSB7XG4gICAgdmFyIHRlbXBsYXRlQ2xhc3NlcyA9IChgJHt0aGlzLm9wdGlvbnMudG9vbHRpcENsYXNzfSAke3RoaXMub3B0aW9ucy5wb3NpdGlvbkNsYXNzfSAke3RoaXMub3B0aW9ucy50ZW1wbGF0ZUNsYXNzZXN9YCkudHJpbSgpO1xuICAgIHZhciAkdGVtcGxhdGUgPSAgJCgnPGRpdj48L2Rpdj4nKS5hZGRDbGFzcyh0ZW1wbGF0ZUNsYXNzZXMpLmF0dHIoe1xuICAgICAgJ3JvbGUnOiAndG9vbHRpcCcsXG4gICAgICAnYXJpYS1oaWRkZW4nOiB0cnVlLFxuICAgICAgJ2RhdGEtaXMtYWN0aXZlJzogZmFsc2UsXG4gICAgICAnZGF0YS1pcy1mb2N1cyc6IGZhbHNlLFxuICAgICAgJ2lkJzogaWRcbiAgICB9KTtcbiAgICByZXR1cm4gJHRlbXBsYXRlO1xuICB9XG5cbiAgLyoqXG4gICAqIEZ1bmN0aW9uIHRoYXQgZ2V0cyBjYWxsZWQgaWYgYSBjb2xsaXNpb24gZXZlbnQgaXMgZGV0ZWN0ZWQuXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBwb3NpdGlvbiAtIHBvc2l0aW9uaW5nIGNsYXNzIHRvIHRyeVxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX3JlcG9zaXRpb24ocG9zaXRpb24pIHtcbiAgICB0aGlzLnVzZWRQb3NpdGlvbnMucHVzaChwb3NpdGlvbiA/IHBvc2l0aW9uIDogJ2JvdHRvbScpO1xuXG4gICAgLy9kZWZhdWx0LCB0cnkgc3dpdGNoaW5nIHRvIG9wcG9zaXRlIHNpZGVcbiAgICBpZiAoIXBvc2l0aW9uICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZigndG9wJykgPCAwKSkge1xuICAgICAgdGhpcy50ZW1wbGF0ZS5hZGRDbGFzcygndG9wJyk7XG4gICAgfSBlbHNlIGlmIChwb3NpdGlvbiA9PT0gJ3RvcCcgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdib3R0b20nKSA8IDApKSB7XG4gICAgICB0aGlzLnRlbXBsYXRlLnJlbW92ZUNsYXNzKHBvc2l0aW9uKTtcbiAgICB9IGVsc2UgaWYgKHBvc2l0aW9uID09PSAnbGVmdCcgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdyaWdodCcpIDwgMCkpIHtcbiAgICAgIHRoaXMudGVtcGxhdGUucmVtb3ZlQ2xhc3MocG9zaXRpb24pXG4gICAgICAgICAgLmFkZENsYXNzKCdyaWdodCcpO1xuICAgIH0gZWxzZSBpZiAocG9zaXRpb24gPT09ICdyaWdodCcgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdsZWZ0JykgPCAwKSkge1xuICAgICAgdGhpcy50ZW1wbGF0ZS5yZW1vdmVDbGFzcyhwb3NpdGlvbilcbiAgICAgICAgICAuYWRkQ2xhc3MoJ2xlZnQnKTtcbiAgICB9XG5cbiAgICAvL2lmIGRlZmF1bHQgY2hhbmdlIGRpZG4ndCB3b3JrLCB0cnkgYm90dG9tIG9yIGxlZnQgZmlyc3RcbiAgICBlbHNlIGlmICghcG9zaXRpb24gJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCd0b3AnKSA+IC0xKSAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2xlZnQnKSA8IDApKSB7XG4gICAgICB0aGlzLnRlbXBsYXRlLmFkZENsYXNzKCdsZWZ0Jyk7XG4gICAgfSBlbHNlIGlmIChwb3NpdGlvbiA9PT0gJ3RvcCcgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdib3R0b20nKSA+IC0xKSAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2xlZnQnKSA8IDApKSB7XG4gICAgICB0aGlzLnRlbXBsYXRlLnJlbW92ZUNsYXNzKHBvc2l0aW9uKVxuICAgICAgICAgIC5hZGRDbGFzcygnbGVmdCcpO1xuICAgIH0gZWxzZSBpZiAocG9zaXRpb24gPT09ICdsZWZ0JyAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ3JpZ2h0JykgPiAtMSkgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdib3R0b20nKSA8IDApKSB7XG4gICAgICB0aGlzLnRlbXBsYXRlLnJlbW92ZUNsYXNzKHBvc2l0aW9uKTtcbiAgICB9IGVsc2UgaWYgKHBvc2l0aW9uID09PSAncmlnaHQnICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZignbGVmdCcpID4gLTEpICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZignYm90dG9tJykgPCAwKSkge1xuICAgICAgdGhpcy50ZW1wbGF0ZS5yZW1vdmVDbGFzcyhwb3NpdGlvbik7XG4gICAgfVxuICAgIC8vaWYgbm90aGluZyBjbGVhcmVkLCBzZXQgdG8gYm90dG9tXG4gICAgZWxzZSB7XG4gICAgICB0aGlzLnRlbXBsYXRlLnJlbW92ZUNsYXNzKHBvc2l0aW9uKTtcbiAgICB9XG4gICAgdGhpcy5jbGFzc0NoYW5nZWQgPSB0cnVlO1xuICAgIHRoaXMuY291bnRlci0tO1xuICB9XG5cbiAgLyoqXG4gICAqIHNldHMgdGhlIHBvc2l0aW9uIGNsYXNzIG9mIGFuIGVsZW1lbnQgYW5kIHJlY3Vyc2l2ZWx5IGNhbGxzIGl0c2VsZiB1bnRpbCB0aGVyZSBhcmUgbm8gbW9yZSBwb3NzaWJsZSBwb3NpdGlvbnMgdG8gYXR0ZW1wdCwgb3IgdGhlIHRvb2x0aXAgZWxlbWVudCBpcyBubyBsb25nZXIgY29sbGlkaW5nLlxuICAgKiBpZiB0aGUgdG9vbHRpcCBpcyBsYXJnZXIgdGhhbiB0aGUgc2NyZWVuIHdpZHRoLCBkZWZhdWx0IHRvIGZ1bGwgd2lkdGggLSBhbnkgdXNlciBzZWxlY3RlZCBtYXJnaW5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9zZXRQb3NpdGlvbigpIHtcbiAgICB2YXIgcG9zaXRpb24gPSB0aGlzLl9nZXRQb3NpdGlvbkNsYXNzKHRoaXMudGVtcGxhdGUpLFxuICAgICAgICAkdGlwRGltcyA9IEZvdW5kYXRpb24uQm94LkdldERpbWVuc2lvbnModGhpcy50ZW1wbGF0ZSksXG4gICAgICAgICRhbmNob3JEaW1zID0gRm91bmRhdGlvbi5Cb3guR2V0RGltZW5zaW9ucyh0aGlzLiRlbGVtZW50KSxcbiAgICAgICAgZGlyZWN0aW9uID0gKHBvc2l0aW9uID09PSAnbGVmdCcgPyAnbGVmdCcgOiAoKHBvc2l0aW9uID09PSAncmlnaHQnKSA/ICdsZWZ0JyA6ICd0b3AnKSksXG4gICAgICAgIHBhcmFtID0gKGRpcmVjdGlvbiA9PT0gJ3RvcCcpID8gJ2hlaWdodCcgOiAnd2lkdGgnLFxuICAgICAgICBvZmZzZXQgPSAocGFyYW0gPT09ICdoZWlnaHQnKSA/IHRoaXMub3B0aW9ucy52T2Zmc2V0IDogdGhpcy5vcHRpb25zLmhPZmZzZXQsXG4gICAgICAgIF90aGlzID0gdGhpcztcblxuICAgIGlmICgoJHRpcERpbXMud2lkdGggPj0gJHRpcERpbXMud2luZG93RGltcy53aWR0aCkgfHwgKCF0aGlzLmNvdW50ZXIgJiYgIUZvdW5kYXRpb24uQm94LkltTm90VG91Y2hpbmdZb3UodGhpcy50ZW1wbGF0ZSkpKSB7XG4gICAgICB0aGlzLnRlbXBsYXRlLm9mZnNldChGb3VuZGF0aW9uLkJveC5HZXRPZmZzZXRzKHRoaXMudGVtcGxhdGUsIHRoaXMuJGVsZW1lbnQsICdjZW50ZXIgYm90dG9tJywgdGhpcy5vcHRpb25zLnZPZmZzZXQsIHRoaXMub3B0aW9ucy5oT2Zmc2V0LCB0cnVlKSkuY3NzKHtcbiAgICAgIC8vIHRoaXMuJGVsZW1lbnQub2Zmc2V0KEZvdW5kYXRpb24uR2V0T2Zmc2V0cyh0aGlzLnRlbXBsYXRlLCB0aGlzLiRlbGVtZW50LCAnY2VudGVyIGJvdHRvbScsIHRoaXMub3B0aW9ucy52T2Zmc2V0LCB0aGlzLm9wdGlvbnMuaE9mZnNldCwgdHJ1ZSkpLmNzcyh7XG4gICAgICAgICd3aWR0aCc6ICRhbmNob3JEaW1zLndpbmRvd0RpbXMud2lkdGggLSAodGhpcy5vcHRpb25zLmhPZmZzZXQgKiAyKSxcbiAgICAgICAgJ2hlaWdodCc6ICdhdXRvJ1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgdGhpcy50ZW1wbGF0ZS5vZmZzZXQoRm91bmRhdGlvbi5Cb3guR2V0T2Zmc2V0cyh0aGlzLnRlbXBsYXRlLCB0aGlzLiRlbGVtZW50LCdjZW50ZXIgJyArIChwb3NpdGlvbiB8fCAnYm90dG9tJyksIHRoaXMub3B0aW9ucy52T2Zmc2V0LCB0aGlzLm9wdGlvbnMuaE9mZnNldCkpO1xuXG4gICAgd2hpbGUoIUZvdW5kYXRpb24uQm94LkltTm90VG91Y2hpbmdZb3UodGhpcy50ZW1wbGF0ZSkgJiYgdGhpcy5jb3VudGVyKSB7XG4gICAgICB0aGlzLl9yZXBvc2l0aW9uKHBvc2l0aW9uKTtcbiAgICAgIHRoaXMuX3NldFBvc2l0aW9uKCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIHJldmVhbHMgdGhlIHRvb2x0aXAsIGFuZCBmaXJlcyBhbiBldmVudCB0byBjbG9zZSBhbnkgb3RoZXIgb3BlbiB0b29sdGlwcyBvbiB0aGUgcGFnZVxuICAgKiBAZmlyZXMgVG9vbHRpcCNjbG9zZW1lXG4gICAqIEBmaXJlcyBUb29sdGlwI3Nob3dcbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICBzaG93KCkge1xuICAgIGlmICh0aGlzLm9wdGlvbnMuc2hvd09uICE9PSAnYWxsJyAmJiAhRm91bmRhdGlvbi5NZWRpYVF1ZXJ5LmlzKHRoaXMub3B0aW9ucy5zaG93T24pKSB7XG4gICAgICAvLyBjb25zb2xlLmVycm9yKCdUaGUgc2NyZWVuIGlzIHRvbyBzbWFsbCB0byBkaXNwbGF5IHRoaXMgdG9vbHRpcCcpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgdGhpcy50ZW1wbGF0ZS5jc3MoJ3Zpc2liaWxpdHknLCAnaGlkZGVuJykuc2hvdygpO1xuICAgIHRoaXMuX3NldFBvc2l0aW9uKCk7XG5cbiAgICAvKipcbiAgICAgKiBGaXJlcyB0byBjbG9zZSBhbGwgb3RoZXIgb3BlbiB0b29sdGlwcyBvbiB0aGUgcGFnZVxuICAgICAqIEBldmVudCBDbG9zZW1lI3Rvb2x0aXBcbiAgICAgKi9cbiAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ2Nsb3NlbWUuemYudG9vbHRpcCcsIHRoaXMudGVtcGxhdGUuYXR0cignaWQnKSk7XG5cblxuICAgIHRoaXMudGVtcGxhdGUuYXR0cih7XG4gICAgICAnZGF0YS1pcy1hY3RpdmUnOiB0cnVlLFxuICAgICAgJ2FyaWEtaGlkZGVuJzogZmFsc2VcbiAgICB9KTtcbiAgICBfdGhpcy5pc0FjdGl2ZSA9IHRydWU7XG4gICAgLy8gY29uc29sZS5sb2codGhpcy50ZW1wbGF0ZSk7XG4gICAgdGhpcy50ZW1wbGF0ZS5zdG9wKCkuaGlkZSgpLmNzcygndmlzaWJpbGl0eScsICcnKS5mYWRlSW4odGhpcy5vcHRpb25zLmZhZGVJbkR1cmF0aW9uLCBmdW5jdGlvbigpIHtcbiAgICAgIC8vbWF5YmUgZG8gc3R1ZmY/XG4gICAgfSk7XG4gICAgLyoqXG4gICAgICogRmlyZXMgd2hlbiB0aGUgdG9vbHRpcCBpcyBzaG93blxuICAgICAqIEBldmVudCBUb29sdGlwI3Nob3dcbiAgICAgKi9cbiAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ3Nob3cuemYudG9vbHRpcCcpO1xuICB9XG5cbiAgLyoqXG4gICAqIEhpZGVzIHRoZSBjdXJyZW50IHRvb2x0aXAsIGFuZCByZXNldHMgdGhlIHBvc2l0aW9uaW5nIGNsYXNzIGlmIGl0IHdhcyBjaGFuZ2VkIGR1ZSB0byBjb2xsaXNpb25cbiAgICogQGZpcmVzIFRvb2x0aXAjaGlkZVxuICAgKiBAZnVuY3Rpb25cbiAgICovXG4gIGhpZGUoKSB7XG4gICAgLy8gY29uc29sZS5sb2coJ2hpZGluZycsIHRoaXMuJGVsZW1lbnQuZGF0YSgneWV0aS1ib3gnKSk7XG4gICAgdmFyIF90aGlzID0gdGhpcztcbiAgICB0aGlzLnRlbXBsYXRlLnN0b3AoKS5hdHRyKHtcbiAgICAgICdhcmlhLWhpZGRlbic6IHRydWUsXG4gICAgICAnZGF0YS1pcy1hY3RpdmUnOiBmYWxzZVxuICAgIH0pLmZhZGVPdXQodGhpcy5vcHRpb25zLmZhZGVPdXREdXJhdGlvbiwgZnVuY3Rpb24oKSB7XG4gICAgICBfdGhpcy5pc0FjdGl2ZSA9IGZhbHNlO1xuICAgICAgX3RoaXMuaXNDbGljayA9IGZhbHNlO1xuICAgICAgaWYgKF90aGlzLmNsYXNzQ2hhbmdlZCkge1xuICAgICAgICBfdGhpcy50ZW1wbGF0ZVxuICAgICAgICAgICAgIC5yZW1vdmVDbGFzcyhfdGhpcy5fZ2V0UG9zaXRpb25DbGFzcyhfdGhpcy50ZW1wbGF0ZSkpXG4gICAgICAgICAgICAgLmFkZENsYXNzKF90aGlzLm9wdGlvbnMucG9zaXRpb25DbGFzcyk7XG5cbiAgICAgICBfdGhpcy51c2VkUG9zaXRpb25zID0gW107XG4gICAgICAgX3RoaXMuY291bnRlciA9IDQ7XG4gICAgICAgX3RoaXMuY2xhc3NDaGFuZ2VkID0gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG4gICAgLyoqXG4gICAgICogZmlyZXMgd2hlbiB0aGUgdG9vbHRpcCBpcyBoaWRkZW5cbiAgICAgKiBAZXZlbnQgVG9vbHRpcCNoaWRlXG4gICAgICovXG4gICAgdGhpcy4kZWxlbWVudC50cmlnZ2VyKCdoaWRlLnpmLnRvb2x0aXAnKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBhZGRzIGV2ZW50IGxpc3RlbmVycyBmb3IgdGhlIHRvb2x0aXAgYW5kIGl0cyBhbmNob3JcbiAgICogVE9ETyBjb21iaW5lIHNvbWUgb2YgdGhlIGxpc3RlbmVycyBsaWtlIGZvY3VzIGFuZCBtb3VzZWVudGVyLCBldGMuXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfZXZlbnRzKCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgdmFyICR0ZW1wbGF0ZSA9IHRoaXMudGVtcGxhdGU7XG4gICAgdmFyIGlzRm9jdXMgPSBmYWxzZTtcblxuICAgIGlmICghdGhpcy5vcHRpb25zLmRpc2FibGVIb3Zlcikge1xuXG4gICAgICB0aGlzLiRlbGVtZW50XG4gICAgICAub24oJ21vdXNlZW50ZXIuemYudG9vbHRpcCcsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgaWYgKCFfdGhpcy5pc0FjdGl2ZSkge1xuICAgICAgICAgIF90aGlzLnRpbWVvdXQgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgX3RoaXMuc2hvdygpO1xuICAgICAgICAgIH0sIF90aGlzLm9wdGlvbnMuaG92ZXJEZWxheSk7XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICAub24oJ21vdXNlbGVhdmUuemYudG9vbHRpcCcsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KF90aGlzLnRpbWVvdXQpO1xuICAgICAgICBpZiAoIWlzRm9jdXMgfHwgKF90aGlzLmlzQ2xpY2sgJiYgIV90aGlzLm9wdGlvbnMuY2xpY2tPcGVuKSkge1xuICAgICAgICAgIF90aGlzLmhpZGUoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5jbGlja09wZW4pIHtcbiAgICAgIHRoaXMuJGVsZW1lbnQub24oJ21vdXNlZG93bi56Zi50b29sdGlwJywgZnVuY3Rpb24oZSkge1xuICAgICAgICBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICAgICAgICBpZiAoX3RoaXMuaXNDbGljaykge1xuICAgICAgICAgIC8vX3RoaXMuaGlkZSgpO1xuICAgICAgICAgIC8vIF90aGlzLmlzQ2xpY2sgPSBmYWxzZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBfdGhpcy5pc0NsaWNrID0gdHJ1ZTtcbiAgICAgICAgICBpZiAoKF90aGlzLm9wdGlvbnMuZGlzYWJsZUhvdmVyIHx8ICFfdGhpcy4kZWxlbWVudC5hdHRyKCd0YWJpbmRleCcpKSAmJiAhX3RoaXMuaXNBY3RpdmUpIHtcbiAgICAgICAgICAgIF90aGlzLnNob3coKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLiRlbGVtZW50Lm9uKCdtb3VzZWRvd24uemYudG9vbHRpcCcsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgZS5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKTtcbiAgICAgICAgX3RoaXMuaXNDbGljayA9IHRydWU7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBpZiAoIXRoaXMub3B0aW9ucy5kaXNhYmxlRm9yVG91Y2gpIHtcbiAgICAgIHRoaXMuJGVsZW1lbnRcbiAgICAgIC5vbigndGFwLnpmLnRvb2x0aXAgdG91Y2hlbmQuemYudG9vbHRpcCcsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgX3RoaXMuaXNBY3RpdmUgPyBfdGhpcy5oaWRlKCkgOiBfdGhpcy5zaG93KCk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICB0aGlzLiRlbGVtZW50Lm9uKHtcbiAgICAgIC8vICd0b2dnbGUuemYudHJpZ2dlcic6IHRoaXMudG9nZ2xlLmJpbmQodGhpcyksXG4gICAgICAvLyAnY2xvc2UuemYudHJpZ2dlcic6IHRoaXMuaGlkZS5iaW5kKHRoaXMpXG4gICAgICAnY2xvc2UuemYudHJpZ2dlcic6IHRoaXMuaGlkZS5iaW5kKHRoaXMpXG4gICAgfSk7XG5cbiAgICB0aGlzLiRlbGVtZW50XG4gICAgICAub24oJ2ZvY3VzLnpmLnRvb2x0aXAnLCBmdW5jdGlvbihlKSB7XG4gICAgICAgIGlzRm9jdXMgPSB0cnVlO1xuICAgICAgICBpZiAoX3RoaXMuaXNDbGljaykge1xuICAgICAgICAgIC8vIElmIHdlJ3JlIG5vdCBzaG93aW5nIG9wZW4gb24gY2xpY2tzLCB3ZSBuZWVkIHRvIHByZXRlbmQgYSBjbGljay1sYXVuY2hlZCBmb2N1cyBpc24ndFxuICAgICAgICAgIC8vIGEgcmVhbCBmb2N1cywgb3RoZXJ3aXNlIG9uIGhvdmVyIGFuZCBjb21lIGJhY2sgd2UgZ2V0IGJhZCBiZWhhdmlvclxuICAgICAgICAgIGlmKCFfdGhpcy5vcHRpb25zLmNsaWNrT3BlbikgeyBpc0ZvY3VzID0gZmFsc2U7IH1cbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgX3RoaXMuc2hvdygpO1xuICAgICAgICB9XG4gICAgICB9KVxuXG4gICAgICAub24oJ2ZvY3Vzb3V0LnpmLnRvb2x0aXAnLCBmdW5jdGlvbihlKSB7XG4gICAgICAgIGlzRm9jdXMgPSBmYWxzZTtcbiAgICAgICAgX3RoaXMuaXNDbGljayA9IGZhbHNlO1xuICAgICAgICBfdGhpcy5oaWRlKCk7XG4gICAgICB9KVxuXG4gICAgICAub24oJ3Jlc2l6ZW1lLnpmLnRyaWdnZXInLCBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKF90aGlzLmlzQWN0aXZlKSB7XG4gICAgICAgICAgX3RoaXMuX3NldFBvc2l0aW9uKCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIGFkZHMgYSB0b2dnbGUgbWV0aG9kLCBpbiBhZGRpdGlvbiB0byB0aGUgc3RhdGljIHNob3coKSAmIGhpZGUoKSBmdW5jdGlvbnNcbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICB0b2dnbGUoKSB7XG4gICAgaWYgKHRoaXMuaXNBY3RpdmUpIHtcbiAgICAgIHRoaXMuaGlkZSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnNob3coKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRGVzdHJveXMgYW4gaW5zdGFuY2Ugb2YgdG9vbHRpcCwgcmVtb3ZlcyB0ZW1wbGF0ZSBlbGVtZW50IGZyb20gdGhlIHZpZXcuXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLiRlbGVtZW50LmF0dHIoJ3RpdGxlJywgdGhpcy50ZW1wbGF0ZS50ZXh0KCkpXG4gICAgICAgICAgICAgICAgIC5vZmYoJy56Zi50cmlnZ2VyIC56Zi50b29sdGlwJylcbiAgICAgICAgICAgICAgICAgLnJlbW92ZUNsYXNzKCdoYXMtdGlwIHRvcCByaWdodCBsZWZ0JylcbiAgICAgICAgICAgICAgICAgLnJlbW92ZUF0dHIoJ2FyaWEtZGVzY3JpYmVkYnkgYXJpYS1oYXNwb3B1cCBkYXRhLWRpc2FibGUtaG92ZXIgZGF0YS1yZXNpemUgZGF0YS10b2dnbGUgZGF0YS10b29sdGlwIGRhdGEteWV0aS1ib3gnKTtcblxuICAgIHRoaXMudGVtcGxhdGUucmVtb3ZlKCk7XG5cbiAgICBGb3VuZGF0aW9uLnVucmVnaXN0ZXJQbHVnaW4odGhpcyk7XG4gIH1cbn1cblxuVG9vbHRpcC5kZWZhdWx0cyA9IHtcbiAgZGlzYWJsZUZvclRvdWNoOiBmYWxzZSxcbiAgLyoqXG4gICAqIFRpbWUsIGluIG1zLCBiZWZvcmUgYSB0b29sdGlwIHNob3VsZCBvcGVuIG9uIGhvdmVyLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIDIwMFxuICAgKi9cbiAgaG92ZXJEZWxheTogMjAwLFxuICAvKipcbiAgICogVGltZSwgaW4gbXMsIGEgdG9vbHRpcCBzaG91bGQgdGFrZSB0byBmYWRlIGludG8gdmlldy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAxNTBcbiAgICovXG4gIGZhZGVJbkR1cmF0aW9uOiAxNTAsXG4gIC8qKlxuICAgKiBUaW1lLCBpbiBtcywgYSB0b29sdGlwIHNob3VsZCB0YWtlIHRvIGZhZGUgb3V0IG9mIHZpZXcuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgMTUwXG4gICAqL1xuICBmYWRlT3V0RHVyYXRpb246IDE1MCxcbiAgLyoqXG4gICAqIERpc2FibGVzIGhvdmVyIGV2ZW50cyBmcm9tIG9wZW5pbmcgdGhlIHRvb2x0aXAgaWYgc2V0IHRvIHRydWVcbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBmYWxzZVxuICAgKi9cbiAgZGlzYWJsZUhvdmVyOiBmYWxzZSxcbiAgLyoqXG4gICAqIE9wdGlvbmFsIGFkZHRpb25hbCBjbGFzc2VzIHRvIGFwcGx5IHRvIHRoZSB0b29sdGlwIHRlbXBsYXRlIG9uIGluaXQuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgJ215LWNvb2wtdGlwLWNsYXNzJ1xuICAgKi9cbiAgdGVtcGxhdGVDbGFzc2VzOiAnJyxcbiAgLyoqXG4gICAqIE5vbi1vcHRpb25hbCBjbGFzcyBhZGRlZCB0byB0b29sdGlwIHRlbXBsYXRlcy4gRm91bmRhdGlvbiBkZWZhdWx0IGlzICd0b29sdGlwJy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAndG9vbHRpcCdcbiAgICovXG4gIHRvb2x0aXBDbGFzczogJ3Rvb2x0aXAnLFxuICAvKipcbiAgICogQ2xhc3MgYXBwbGllZCB0byB0aGUgdG9vbHRpcCBhbmNob3IgZWxlbWVudC5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnaGFzLXRpcCdcbiAgICovXG4gIHRyaWdnZXJDbGFzczogJ2hhcy10aXAnLFxuICAvKipcbiAgICogTWluaW11bSBicmVha3BvaW50IHNpemUgYXQgd2hpY2ggdG8gb3BlbiB0aGUgdG9vbHRpcC5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnc21hbGwnXG4gICAqL1xuICBzaG93T246ICdzbWFsbCcsXG4gIC8qKlxuICAgKiBDdXN0b20gdGVtcGxhdGUgdG8gYmUgdXNlZCB0byBnZW5lcmF0ZSBtYXJrdXAgZm9yIHRvb2x0aXAuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgJyZsdDtkaXYgY2xhc3M9XCJ0b29sdGlwXCImZ3Q7Jmx0Oy9kaXYmZ3Q7J1xuICAgKi9cbiAgdGVtcGxhdGU6ICcnLFxuICAvKipcbiAgICogVGV4dCBkaXNwbGF5ZWQgaW4gdGhlIHRvb2x0aXAgdGVtcGxhdGUgb24gb3Blbi5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnU29tZSBjb29sIHNwYWNlIGZhY3QgaGVyZS4nXG4gICAqL1xuICB0aXBUZXh0OiAnJyxcbiAgdG91Y2hDbG9zZVRleHQ6ICdUYXAgdG8gY2xvc2UuJyxcbiAgLyoqXG4gICAqIEFsbG93cyB0aGUgdG9vbHRpcCB0byByZW1haW4gb3BlbiBpZiB0cmlnZ2VyZWQgd2l0aCBhIGNsaWNrIG9yIHRvdWNoIGV2ZW50LlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIHRydWVcbiAgICovXG4gIGNsaWNrT3BlbjogdHJ1ZSxcbiAgLyoqXG4gICAqIEFkZGl0aW9uYWwgcG9zaXRpb25pbmcgY2xhc3Nlcywgc2V0IGJ5IHRoZSBKU1xuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlICd0b3AnXG4gICAqL1xuICBwb3NpdGlvbkNsYXNzOiAnJyxcbiAgLyoqXG4gICAqIERpc3RhbmNlLCBpbiBwaXhlbHMsIHRoZSB0ZW1wbGF0ZSBzaG91bGQgcHVzaCBhd2F5IGZyb20gdGhlIGFuY2hvciBvbiB0aGUgWSBheGlzLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIDEwXG4gICAqL1xuICB2T2Zmc2V0OiAxMCxcbiAgLyoqXG4gICAqIERpc3RhbmNlLCBpbiBwaXhlbHMsIHRoZSB0ZW1wbGF0ZSBzaG91bGQgcHVzaCBhd2F5IGZyb20gdGhlIGFuY2hvciBvbiB0aGUgWCBheGlzLCBpZiBhbGlnbmVkIHRvIGEgc2lkZS5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAxMlxuICAgKi9cbiAgaE9mZnNldDogMTIsXG4gICAgLyoqXG4gICAqIEFsbG93IEhUTUwgaW4gdG9vbHRpcC4gV2FybmluZzogSWYgeW91IGFyZSBsb2FkaW5nIHVzZXItZ2VuZXJhdGVkIGNvbnRlbnQgaW50byB0b29sdGlwcyxcbiAgICogYWxsb3dpbmcgSFRNTCBtYXkgb3BlbiB5b3Vyc2VsZiB1cCB0byBYU1MgYXR0YWNrcy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBmYWxzZVxuICAgKi9cbiAgYWxsb3dIdG1sOiBmYWxzZVxufTtcblxuLyoqXG4gKiBUT0RPIHV0aWxpemUgcmVzaXplIGV2ZW50IHRyaWdnZXJcbiAqL1xuXG4vLyBXaW5kb3cgZXhwb3J0c1xuRm91bmRhdGlvbi5wbHVnaW4oVG9vbHRpcCwgJ1Rvb2x0aXAnKTtcblxufShqUXVlcnkpO1xuIiwiLyoqXG4gKiBPd2wgQ2Fyb3VzZWwgdjIuMi4xXG4gKiBDb3B5cmlnaHQgMjAxMy0yMDE3IERhdmlkIERldXRzY2hcbiAqIExpY2Vuc2VkIHVuZGVyICAoKVxuICovXG4hZnVuY3Rpb24oYSxiLGMsZCl7ZnVuY3Rpb24gZShiLGMpe3RoaXMuc2V0dGluZ3M9bnVsbCx0aGlzLm9wdGlvbnM9YS5leHRlbmQoe30sZS5EZWZhdWx0cyxjKSx0aGlzLiRlbGVtZW50PWEoYiksdGhpcy5faGFuZGxlcnM9e30sdGhpcy5fcGx1Z2lucz17fSx0aGlzLl9zdXByZXNzPXt9LHRoaXMuX2N1cnJlbnQ9bnVsbCx0aGlzLl9zcGVlZD1udWxsLHRoaXMuX2Nvb3JkaW5hdGVzPVtdLHRoaXMuX2JyZWFrcG9pbnQ9bnVsbCx0aGlzLl93aWR0aD1udWxsLHRoaXMuX2l0ZW1zPVtdLHRoaXMuX2Nsb25lcz1bXSx0aGlzLl9tZXJnZXJzPVtdLHRoaXMuX3dpZHRocz1bXSx0aGlzLl9pbnZhbGlkYXRlZD17fSx0aGlzLl9waXBlPVtdLHRoaXMuX2RyYWc9e3RpbWU6bnVsbCx0YXJnZXQ6bnVsbCxwb2ludGVyOm51bGwsc3RhZ2U6e3N0YXJ0Om51bGwsY3VycmVudDpudWxsfSxkaXJlY3Rpb246bnVsbH0sdGhpcy5fc3RhdGVzPXtjdXJyZW50Ont9LHRhZ3M6e2luaXRpYWxpemluZzpbXCJidXN5XCJdLGFuaW1hdGluZzpbXCJidXN5XCJdLGRyYWdnaW5nOltcImludGVyYWN0aW5nXCJdfX0sYS5lYWNoKFtcIm9uUmVzaXplXCIsXCJvblRocm90dGxlZFJlc2l6ZVwiXSxhLnByb3h5KGZ1bmN0aW9uKGIsYyl7dGhpcy5faGFuZGxlcnNbY109YS5wcm94eSh0aGlzW2NdLHRoaXMpfSx0aGlzKSksYS5lYWNoKGUuUGx1Z2lucyxhLnByb3h5KGZ1bmN0aW9uKGEsYil7dGhpcy5fcGx1Z2luc1thLmNoYXJBdCgwKS50b0xvd2VyQ2FzZSgpK2Euc2xpY2UoMSldPW5ldyBiKHRoaXMpfSx0aGlzKSksYS5lYWNoKGUuV29ya2VycyxhLnByb3h5KGZ1bmN0aW9uKGIsYyl7dGhpcy5fcGlwZS5wdXNoKHtmaWx0ZXI6Yy5maWx0ZXIscnVuOmEucHJveHkoYy5ydW4sdGhpcyl9KX0sdGhpcykpLHRoaXMuc2V0dXAoKSx0aGlzLmluaXRpYWxpemUoKX1lLkRlZmF1bHRzPXtpdGVtczozLGxvb3A6ITEsY2VudGVyOiExLHJld2luZDohMSxtb3VzZURyYWc6ITAsdG91Y2hEcmFnOiEwLHB1bGxEcmFnOiEwLGZyZWVEcmFnOiExLG1hcmdpbjowLHN0YWdlUGFkZGluZzowLG1lcmdlOiExLG1lcmdlRml0OiEwLGF1dG9XaWR0aDohMSxzdGFydFBvc2l0aW9uOjAscnRsOiExLHNtYXJ0U3BlZWQ6MjUwLGZsdWlkU3BlZWQ6ITEsZHJhZ0VuZFNwZWVkOiExLHJlc3BvbnNpdmU6e30scmVzcG9uc2l2ZVJlZnJlc2hSYXRlOjIwMCxyZXNwb25zaXZlQmFzZUVsZW1lbnQ6YixmYWxsYmFja0Vhc2luZzpcInN3aW5nXCIsaW5mbzohMSxuZXN0ZWRJdGVtU2VsZWN0b3I6ITEsaXRlbUVsZW1lbnQ6XCJkaXZcIixzdGFnZUVsZW1lbnQ6XCJkaXZcIixyZWZyZXNoQ2xhc3M6XCJvd2wtcmVmcmVzaFwiLGxvYWRlZENsYXNzOlwib3dsLWxvYWRlZFwiLGxvYWRpbmdDbGFzczpcIm93bC1sb2FkaW5nXCIscnRsQ2xhc3M6XCJvd2wtcnRsXCIscmVzcG9uc2l2ZUNsYXNzOlwib3dsLXJlc3BvbnNpdmVcIixkcmFnQ2xhc3M6XCJvd2wtZHJhZ1wiLGl0ZW1DbGFzczpcIm93bC1pdGVtXCIsc3RhZ2VDbGFzczpcIm93bC1zdGFnZVwiLHN0YWdlT3V0ZXJDbGFzczpcIm93bC1zdGFnZS1vdXRlclwiLGdyYWJDbGFzczpcIm93bC1ncmFiXCJ9LGUuV2lkdGg9e0RlZmF1bHQ6XCJkZWZhdWx0XCIsSW5uZXI6XCJpbm5lclwiLE91dGVyOlwib3V0ZXJcIn0sZS5UeXBlPXtFdmVudDpcImV2ZW50XCIsU3RhdGU6XCJzdGF0ZVwifSxlLlBsdWdpbnM9e30sZS5Xb3JrZXJzPVt7ZmlsdGVyOltcIndpZHRoXCIsXCJzZXR0aW5nc1wiXSxydW46ZnVuY3Rpb24oKXt0aGlzLl93aWR0aD10aGlzLiRlbGVtZW50LndpZHRoKCl9fSx7ZmlsdGVyOltcIndpZHRoXCIsXCJpdGVtc1wiLFwic2V0dGluZ3NcIl0scnVuOmZ1bmN0aW9uKGEpe2EuY3VycmVudD10aGlzLl9pdGVtcyYmdGhpcy5faXRlbXNbdGhpcy5yZWxhdGl2ZSh0aGlzLl9jdXJyZW50KV19fSx7ZmlsdGVyOltcIml0ZW1zXCIsXCJzZXR0aW5nc1wiXSxydW46ZnVuY3Rpb24oKXt0aGlzLiRzdGFnZS5jaGlsZHJlbihcIi5jbG9uZWRcIikucmVtb3ZlKCl9fSx7ZmlsdGVyOltcIndpZHRoXCIsXCJpdGVtc1wiLFwic2V0dGluZ3NcIl0scnVuOmZ1bmN0aW9uKGEpe3ZhciBiPXRoaXMuc2V0dGluZ3MubWFyZ2lufHxcIlwiLGM9IXRoaXMuc2V0dGluZ3MuYXV0b1dpZHRoLGQ9dGhpcy5zZXR0aW5ncy5ydGwsZT17d2lkdGg6XCJhdXRvXCIsXCJtYXJnaW4tbGVmdFwiOmQ/YjpcIlwiLFwibWFyZ2luLXJpZ2h0XCI6ZD9cIlwiOmJ9OyFjJiZ0aGlzLiRzdGFnZS5jaGlsZHJlbigpLmNzcyhlKSxhLmNzcz1lfX0se2ZpbHRlcjpbXCJ3aWR0aFwiLFwiaXRlbXNcIixcInNldHRpbmdzXCJdLHJ1bjpmdW5jdGlvbihhKXt2YXIgYj0odGhpcy53aWR0aCgpL3RoaXMuc2V0dGluZ3MuaXRlbXMpLnRvRml4ZWQoMyktdGhpcy5zZXR0aW5ncy5tYXJnaW4sYz1udWxsLGQ9dGhpcy5faXRlbXMubGVuZ3RoLGU9IXRoaXMuc2V0dGluZ3MuYXV0b1dpZHRoLGY9W107Zm9yKGEuaXRlbXM9e21lcmdlOiExLHdpZHRoOmJ9O2QtLTspYz10aGlzLl9tZXJnZXJzW2RdLGM9dGhpcy5zZXR0aW5ncy5tZXJnZUZpdCYmTWF0aC5taW4oYyx0aGlzLnNldHRpbmdzLml0ZW1zKXx8YyxhLml0ZW1zLm1lcmdlPWM+MXx8YS5pdGVtcy5tZXJnZSxmW2RdPWU/YipjOnRoaXMuX2l0ZW1zW2RdLndpZHRoKCk7dGhpcy5fd2lkdGhzPWZ9fSx7ZmlsdGVyOltcIml0ZW1zXCIsXCJzZXR0aW5nc1wiXSxydW46ZnVuY3Rpb24oKXt2YXIgYj1bXSxjPXRoaXMuX2l0ZW1zLGQ9dGhpcy5zZXR0aW5ncyxlPU1hdGgubWF4KDIqZC5pdGVtcyw0KSxmPTIqTWF0aC5jZWlsKGMubGVuZ3RoLzIpLGc9ZC5sb29wJiZjLmxlbmd0aD9kLnJld2luZD9lOk1hdGgubWF4KGUsZik6MCxoPVwiXCIsaT1cIlwiO2ZvcihnLz0yO2ctLTspYi5wdXNoKHRoaXMubm9ybWFsaXplKGIubGVuZ3RoLzIsITApKSxoKz1jW2JbYi5sZW5ndGgtMV1dWzBdLm91dGVySFRNTCxiLnB1c2godGhpcy5ub3JtYWxpemUoYy5sZW5ndGgtMS0oYi5sZW5ndGgtMSkvMiwhMCkpLGk9Y1tiW2IubGVuZ3RoLTFdXVswXS5vdXRlckhUTUwraTt0aGlzLl9jbG9uZXM9YixhKGgpLmFkZENsYXNzKFwiY2xvbmVkXCIpLmFwcGVuZFRvKHRoaXMuJHN0YWdlKSxhKGkpLmFkZENsYXNzKFwiY2xvbmVkXCIpLnByZXBlbmRUbyh0aGlzLiRzdGFnZSl9fSx7ZmlsdGVyOltcIndpZHRoXCIsXCJpdGVtc1wiLFwic2V0dGluZ3NcIl0scnVuOmZ1bmN0aW9uKCl7Zm9yKHZhciBhPXRoaXMuc2V0dGluZ3MucnRsPzE6LTEsYj10aGlzLl9jbG9uZXMubGVuZ3RoK3RoaXMuX2l0ZW1zLmxlbmd0aCxjPS0xLGQ9MCxlPTAsZj1bXTsrK2M8YjspZD1mW2MtMV18fDAsZT10aGlzLl93aWR0aHNbdGhpcy5yZWxhdGl2ZShjKV0rdGhpcy5zZXR0aW5ncy5tYXJnaW4sZi5wdXNoKGQrZSphKTt0aGlzLl9jb29yZGluYXRlcz1mfX0se2ZpbHRlcjpbXCJ3aWR0aFwiLFwiaXRlbXNcIixcInNldHRpbmdzXCJdLHJ1bjpmdW5jdGlvbigpe3ZhciBhPXRoaXMuc2V0dGluZ3Muc3RhZ2VQYWRkaW5nLGI9dGhpcy5fY29vcmRpbmF0ZXMsYz17d2lkdGg6TWF0aC5jZWlsKE1hdGguYWJzKGJbYi5sZW5ndGgtMV0pKSsyKmEsXCJwYWRkaW5nLWxlZnRcIjphfHxcIlwiLFwicGFkZGluZy1yaWdodFwiOmF8fFwiXCJ9O3RoaXMuJHN0YWdlLmNzcyhjKX19LHtmaWx0ZXI6W1wid2lkdGhcIixcIml0ZW1zXCIsXCJzZXR0aW5nc1wiXSxydW46ZnVuY3Rpb24oYSl7dmFyIGI9dGhpcy5fY29vcmRpbmF0ZXMubGVuZ3RoLGM9IXRoaXMuc2V0dGluZ3MuYXV0b1dpZHRoLGQ9dGhpcy4kc3RhZ2UuY2hpbGRyZW4oKTtpZihjJiZhLml0ZW1zLm1lcmdlKWZvcig7Yi0tOylhLmNzcy53aWR0aD10aGlzLl93aWR0aHNbdGhpcy5yZWxhdGl2ZShiKV0sZC5lcShiKS5jc3MoYS5jc3MpO2Vsc2UgYyYmKGEuY3NzLndpZHRoPWEuaXRlbXMud2lkdGgsZC5jc3MoYS5jc3MpKX19LHtmaWx0ZXI6W1wiaXRlbXNcIl0scnVuOmZ1bmN0aW9uKCl7dGhpcy5fY29vcmRpbmF0ZXMubGVuZ3RoPDEmJnRoaXMuJHN0YWdlLnJlbW92ZUF0dHIoXCJzdHlsZVwiKX19LHtmaWx0ZXI6W1wid2lkdGhcIixcIml0ZW1zXCIsXCJzZXR0aW5nc1wiXSxydW46ZnVuY3Rpb24oYSl7YS5jdXJyZW50PWEuY3VycmVudD90aGlzLiRzdGFnZS5jaGlsZHJlbigpLmluZGV4KGEuY3VycmVudCk6MCxhLmN1cnJlbnQ9TWF0aC5tYXgodGhpcy5taW5pbXVtKCksTWF0aC5taW4odGhpcy5tYXhpbXVtKCksYS5jdXJyZW50KSksdGhpcy5yZXNldChhLmN1cnJlbnQpfX0se2ZpbHRlcjpbXCJwb3NpdGlvblwiXSxydW46ZnVuY3Rpb24oKXt0aGlzLmFuaW1hdGUodGhpcy5jb29yZGluYXRlcyh0aGlzLl9jdXJyZW50KSl9fSx7ZmlsdGVyOltcIndpZHRoXCIsXCJwb3NpdGlvblwiLFwiaXRlbXNcIixcInNldHRpbmdzXCJdLHJ1bjpmdW5jdGlvbigpe3ZhciBhLGIsYyxkLGU9dGhpcy5zZXR0aW5ncy5ydGw/MTotMSxmPTIqdGhpcy5zZXR0aW5ncy5zdGFnZVBhZGRpbmcsZz10aGlzLmNvb3JkaW5hdGVzKHRoaXMuY3VycmVudCgpKStmLGg9Zyt0aGlzLndpZHRoKCkqZSxpPVtdO2ZvcihjPTAsZD10aGlzLl9jb29yZGluYXRlcy5sZW5ndGg7YzxkO2MrKylhPXRoaXMuX2Nvb3JkaW5hdGVzW2MtMV18fDAsYj1NYXRoLmFicyh0aGlzLl9jb29yZGluYXRlc1tjXSkrZiplLCh0aGlzLm9wKGEsXCI8PVwiLGcpJiZ0aGlzLm9wKGEsXCI+XCIsaCl8fHRoaXMub3AoYixcIjxcIixnKSYmdGhpcy5vcChiLFwiPlwiLGgpKSYmaS5wdXNoKGMpO3RoaXMuJHN0YWdlLmNoaWxkcmVuKFwiLmFjdGl2ZVwiKS5yZW1vdmVDbGFzcyhcImFjdGl2ZVwiKSx0aGlzLiRzdGFnZS5jaGlsZHJlbihcIjplcShcIitpLmpvaW4oXCIpLCA6ZXEoXCIpK1wiKVwiKS5hZGRDbGFzcyhcImFjdGl2ZVwiKSx0aGlzLnNldHRpbmdzLmNlbnRlciYmKHRoaXMuJHN0YWdlLmNoaWxkcmVuKFwiLmNlbnRlclwiKS5yZW1vdmVDbGFzcyhcImNlbnRlclwiKSx0aGlzLiRzdGFnZS5jaGlsZHJlbigpLmVxKHRoaXMuY3VycmVudCgpKS5hZGRDbGFzcyhcImNlbnRlclwiKSl9fV0sZS5wcm90b3R5cGUuaW5pdGlhbGl6ZT1mdW5jdGlvbigpe2lmKHRoaXMuZW50ZXIoXCJpbml0aWFsaXppbmdcIiksdGhpcy50cmlnZ2VyKFwiaW5pdGlhbGl6ZVwiKSx0aGlzLiRlbGVtZW50LnRvZ2dsZUNsYXNzKHRoaXMuc2V0dGluZ3MucnRsQ2xhc3MsdGhpcy5zZXR0aW5ncy5ydGwpLHRoaXMuc2V0dGluZ3MuYXV0b1dpZHRoJiYhdGhpcy5pcyhcInByZS1sb2FkaW5nXCIpKXt2YXIgYixjLGU7Yj10aGlzLiRlbGVtZW50LmZpbmQoXCJpbWdcIiksYz10aGlzLnNldHRpbmdzLm5lc3RlZEl0ZW1TZWxlY3Rvcj9cIi5cIit0aGlzLnNldHRpbmdzLm5lc3RlZEl0ZW1TZWxlY3RvcjpkLGU9dGhpcy4kZWxlbWVudC5jaGlsZHJlbihjKS53aWR0aCgpLGIubGVuZ3RoJiZlPD0wJiZ0aGlzLnByZWxvYWRBdXRvV2lkdGhJbWFnZXMoYil9dGhpcy4kZWxlbWVudC5hZGRDbGFzcyh0aGlzLm9wdGlvbnMubG9hZGluZ0NsYXNzKSx0aGlzLiRzdGFnZT1hKFwiPFwiK3RoaXMuc2V0dGluZ3Muc3RhZ2VFbGVtZW50KycgY2xhc3M9XCInK3RoaXMuc2V0dGluZ3Muc3RhZ2VDbGFzcysnXCIvPicpLndyYXAoJzxkaXYgY2xhc3M9XCInK3RoaXMuc2V0dGluZ3Muc3RhZ2VPdXRlckNsYXNzKydcIi8+JyksdGhpcy4kZWxlbWVudC5hcHBlbmQodGhpcy4kc3RhZ2UucGFyZW50KCkpLHRoaXMucmVwbGFjZSh0aGlzLiRlbGVtZW50LmNoaWxkcmVuKCkubm90KHRoaXMuJHN0YWdlLnBhcmVudCgpKSksdGhpcy4kZWxlbWVudC5pcyhcIjp2aXNpYmxlXCIpP3RoaXMucmVmcmVzaCgpOnRoaXMuaW52YWxpZGF0ZShcIndpZHRoXCIpLHRoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3ModGhpcy5vcHRpb25zLmxvYWRpbmdDbGFzcykuYWRkQ2xhc3ModGhpcy5vcHRpb25zLmxvYWRlZENsYXNzKSx0aGlzLnJlZ2lzdGVyRXZlbnRIYW5kbGVycygpLHRoaXMubGVhdmUoXCJpbml0aWFsaXppbmdcIiksdGhpcy50cmlnZ2VyKFwiaW5pdGlhbGl6ZWRcIil9LGUucHJvdG90eXBlLnNldHVwPWZ1bmN0aW9uKCl7dmFyIGI9dGhpcy52aWV3cG9ydCgpLGM9dGhpcy5vcHRpb25zLnJlc3BvbnNpdmUsZD0tMSxlPW51bGw7Yz8oYS5lYWNoKGMsZnVuY3Rpb24oYSl7YTw9YiYmYT5kJiYoZD1OdW1iZXIoYSkpfSksZT1hLmV4dGVuZCh7fSx0aGlzLm9wdGlvbnMsY1tkXSksXCJmdW5jdGlvblwiPT10eXBlb2YgZS5zdGFnZVBhZGRpbmcmJihlLnN0YWdlUGFkZGluZz1lLnN0YWdlUGFkZGluZygpKSxkZWxldGUgZS5yZXNwb25zaXZlLGUucmVzcG9uc2l2ZUNsYXNzJiZ0aGlzLiRlbGVtZW50LmF0dHIoXCJjbGFzc1wiLHRoaXMuJGVsZW1lbnQuYXR0cihcImNsYXNzXCIpLnJlcGxhY2UobmV3IFJlZ0V4cChcIihcIit0aGlzLm9wdGlvbnMucmVzcG9uc2l2ZUNsYXNzK1wiLSlcXFxcUytcXFxcc1wiLFwiZ1wiKSxcIiQxXCIrZCkpKTplPWEuZXh0ZW5kKHt9LHRoaXMub3B0aW9ucyksdGhpcy50cmlnZ2VyKFwiY2hhbmdlXCIse3Byb3BlcnR5OntuYW1lOlwic2V0dGluZ3NcIix2YWx1ZTplfX0pLHRoaXMuX2JyZWFrcG9pbnQ9ZCx0aGlzLnNldHRpbmdzPWUsdGhpcy5pbnZhbGlkYXRlKFwic2V0dGluZ3NcIiksdGhpcy50cmlnZ2VyKFwiY2hhbmdlZFwiLHtwcm9wZXJ0eTp7bmFtZTpcInNldHRpbmdzXCIsdmFsdWU6dGhpcy5zZXR0aW5nc319KX0sZS5wcm90b3R5cGUub3B0aW9uc0xvZ2ljPWZ1bmN0aW9uKCl7dGhpcy5zZXR0aW5ncy5hdXRvV2lkdGgmJih0aGlzLnNldHRpbmdzLnN0YWdlUGFkZGluZz0hMSx0aGlzLnNldHRpbmdzLm1lcmdlPSExKX0sZS5wcm90b3R5cGUucHJlcGFyZT1mdW5jdGlvbihiKXt2YXIgYz10aGlzLnRyaWdnZXIoXCJwcmVwYXJlXCIse2NvbnRlbnQ6Yn0pO3JldHVybiBjLmRhdGF8fChjLmRhdGE9YShcIjxcIit0aGlzLnNldHRpbmdzLml0ZW1FbGVtZW50K1wiLz5cIikuYWRkQ2xhc3ModGhpcy5vcHRpb25zLml0ZW1DbGFzcykuYXBwZW5kKGIpKSx0aGlzLnRyaWdnZXIoXCJwcmVwYXJlZFwiLHtjb250ZW50OmMuZGF0YX0pLGMuZGF0YX0sZS5wcm90b3R5cGUudXBkYXRlPWZ1bmN0aW9uKCl7Zm9yKHZhciBiPTAsYz10aGlzLl9waXBlLmxlbmd0aCxkPWEucHJveHkoZnVuY3Rpb24oYSl7cmV0dXJuIHRoaXNbYV19LHRoaXMuX2ludmFsaWRhdGVkKSxlPXt9O2I8YzspKHRoaXMuX2ludmFsaWRhdGVkLmFsbHx8YS5ncmVwKHRoaXMuX3BpcGVbYl0uZmlsdGVyLGQpLmxlbmd0aD4wKSYmdGhpcy5fcGlwZVtiXS5ydW4oZSksYisrO3RoaXMuX2ludmFsaWRhdGVkPXt9LCF0aGlzLmlzKFwidmFsaWRcIikmJnRoaXMuZW50ZXIoXCJ2YWxpZFwiKX0sZS5wcm90b3R5cGUud2lkdGg9ZnVuY3Rpb24oYSl7c3dpdGNoKGE9YXx8ZS5XaWR0aC5EZWZhdWx0KXtjYXNlIGUuV2lkdGguSW5uZXI6Y2FzZSBlLldpZHRoLk91dGVyOnJldHVybiB0aGlzLl93aWR0aDtkZWZhdWx0OnJldHVybiB0aGlzLl93aWR0aC0yKnRoaXMuc2V0dGluZ3Muc3RhZ2VQYWRkaW5nK3RoaXMuc2V0dGluZ3MubWFyZ2lufX0sZS5wcm90b3R5cGUucmVmcmVzaD1mdW5jdGlvbigpe3RoaXMuZW50ZXIoXCJyZWZyZXNoaW5nXCIpLHRoaXMudHJpZ2dlcihcInJlZnJlc2hcIiksdGhpcy5zZXR1cCgpLHRoaXMub3B0aW9uc0xvZ2ljKCksdGhpcy4kZWxlbWVudC5hZGRDbGFzcyh0aGlzLm9wdGlvbnMucmVmcmVzaENsYXNzKSx0aGlzLnVwZGF0ZSgpLHRoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3ModGhpcy5vcHRpb25zLnJlZnJlc2hDbGFzcyksdGhpcy5sZWF2ZShcInJlZnJlc2hpbmdcIiksdGhpcy50cmlnZ2VyKFwicmVmcmVzaGVkXCIpfSxlLnByb3RvdHlwZS5vblRocm90dGxlZFJlc2l6ZT1mdW5jdGlvbigpe2IuY2xlYXJUaW1lb3V0KHRoaXMucmVzaXplVGltZXIpLHRoaXMucmVzaXplVGltZXI9Yi5zZXRUaW1lb3V0KHRoaXMuX2hhbmRsZXJzLm9uUmVzaXplLHRoaXMuc2V0dGluZ3MucmVzcG9uc2l2ZVJlZnJlc2hSYXRlKX0sZS5wcm90b3R5cGUub25SZXNpemU9ZnVuY3Rpb24oKXtyZXR1cm4hIXRoaXMuX2l0ZW1zLmxlbmd0aCYmKHRoaXMuX3dpZHRoIT09dGhpcy4kZWxlbWVudC53aWR0aCgpJiYoISF0aGlzLiRlbGVtZW50LmlzKFwiOnZpc2libGVcIikmJih0aGlzLmVudGVyKFwicmVzaXppbmdcIiksdGhpcy50cmlnZ2VyKFwicmVzaXplXCIpLmlzRGVmYXVsdFByZXZlbnRlZCgpPyh0aGlzLmxlYXZlKFwicmVzaXppbmdcIiksITEpOih0aGlzLmludmFsaWRhdGUoXCJ3aWR0aFwiKSx0aGlzLnJlZnJlc2goKSx0aGlzLmxlYXZlKFwicmVzaXppbmdcIiksdm9pZCB0aGlzLnRyaWdnZXIoXCJyZXNpemVkXCIpKSkpKX0sZS5wcm90b3R5cGUucmVnaXN0ZXJFdmVudEhhbmRsZXJzPWZ1bmN0aW9uKCl7YS5zdXBwb3J0LnRyYW5zaXRpb24mJnRoaXMuJHN0YWdlLm9uKGEuc3VwcG9ydC50cmFuc2l0aW9uLmVuZCtcIi5vd2wuY29yZVwiLGEucHJveHkodGhpcy5vblRyYW5zaXRpb25FbmQsdGhpcykpLHRoaXMuc2V0dGluZ3MucmVzcG9uc2l2ZSE9PSExJiZ0aGlzLm9uKGIsXCJyZXNpemVcIix0aGlzLl9oYW5kbGVycy5vblRocm90dGxlZFJlc2l6ZSksdGhpcy5zZXR0aW5ncy5tb3VzZURyYWcmJih0aGlzLiRlbGVtZW50LmFkZENsYXNzKHRoaXMub3B0aW9ucy5kcmFnQ2xhc3MpLHRoaXMuJHN0YWdlLm9uKFwibW91c2Vkb3duLm93bC5jb3JlXCIsYS5wcm94eSh0aGlzLm9uRHJhZ1N0YXJ0LHRoaXMpKSx0aGlzLiRzdGFnZS5vbihcImRyYWdzdGFydC5vd2wuY29yZSBzZWxlY3RzdGFydC5vd2wuY29yZVwiLGZ1bmN0aW9uKCl7cmV0dXJuITF9KSksdGhpcy5zZXR0aW5ncy50b3VjaERyYWcmJih0aGlzLiRzdGFnZS5vbihcInRvdWNoc3RhcnQub3dsLmNvcmVcIixhLnByb3h5KHRoaXMub25EcmFnU3RhcnQsdGhpcykpLHRoaXMuJHN0YWdlLm9uKFwidG91Y2hjYW5jZWwub3dsLmNvcmVcIixhLnByb3h5KHRoaXMub25EcmFnRW5kLHRoaXMpKSl9LGUucHJvdG90eXBlLm9uRHJhZ1N0YXJ0PWZ1bmN0aW9uKGIpe3ZhciBkPW51bGw7MyE9PWIud2hpY2gmJihhLnN1cHBvcnQudHJhbnNmb3JtPyhkPXRoaXMuJHN0YWdlLmNzcyhcInRyYW5zZm9ybVwiKS5yZXBsYWNlKC8uKlxcKHxcXCl8IC9nLFwiXCIpLnNwbGl0KFwiLFwiKSxkPXt4OmRbMTY9PT1kLmxlbmd0aD8xMjo0XSx5OmRbMTY9PT1kLmxlbmd0aD8xMzo1XX0pOihkPXRoaXMuJHN0YWdlLnBvc2l0aW9uKCksZD17eDp0aGlzLnNldHRpbmdzLnJ0bD9kLmxlZnQrdGhpcy4kc3RhZ2Uud2lkdGgoKS10aGlzLndpZHRoKCkrdGhpcy5zZXR0aW5ncy5tYXJnaW46ZC5sZWZ0LHk6ZC50b3B9KSx0aGlzLmlzKFwiYW5pbWF0aW5nXCIpJiYoYS5zdXBwb3J0LnRyYW5zZm9ybT90aGlzLmFuaW1hdGUoZC54KTp0aGlzLiRzdGFnZS5zdG9wKCksdGhpcy5pbnZhbGlkYXRlKFwicG9zaXRpb25cIikpLHRoaXMuJGVsZW1lbnQudG9nZ2xlQ2xhc3ModGhpcy5vcHRpb25zLmdyYWJDbGFzcyxcIm1vdXNlZG93blwiPT09Yi50eXBlKSx0aGlzLnNwZWVkKDApLHRoaXMuX2RyYWcudGltZT0obmV3IERhdGUpLmdldFRpbWUoKSx0aGlzLl9kcmFnLnRhcmdldD1hKGIudGFyZ2V0KSx0aGlzLl9kcmFnLnN0YWdlLnN0YXJ0PWQsdGhpcy5fZHJhZy5zdGFnZS5jdXJyZW50PWQsdGhpcy5fZHJhZy5wb2ludGVyPXRoaXMucG9pbnRlcihiKSxhKGMpLm9uKFwibW91c2V1cC5vd2wuY29yZSB0b3VjaGVuZC5vd2wuY29yZVwiLGEucHJveHkodGhpcy5vbkRyYWdFbmQsdGhpcykpLGEoYykub25lKFwibW91c2Vtb3ZlLm93bC5jb3JlIHRvdWNobW92ZS5vd2wuY29yZVwiLGEucHJveHkoZnVuY3Rpb24oYil7dmFyIGQ9dGhpcy5kaWZmZXJlbmNlKHRoaXMuX2RyYWcucG9pbnRlcix0aGlzLnBvaW50ZXIoYikpO2EoYykub24oXCJtb3VzZW1vdmUub3dsLmNvcmUgdG91Y2htb3ZlLm93bC5jb3JlXCIsYS5wcm94eSh0aGlzLm9uRHJhZ01vdmUsdGhpcykpLE1hdGguYWJzKGQueCk8TWF0aC5hYnMoZC55KSYmdGhpcy5pcyhcInZhbGlkXCIpfHwoYi5wcmV2ZW50RGVmYXVsdCgpLHRoaXMuZW50ZXIoXCJkcmFnZ2luZ1wiKSx0aGlzLnRyaWdnZXIoXCJkcmFnXCIpKX0sdGhpcykpKX0sZS5wcm90b3R5cGUub25EcmFnTW92ZT1mdW5jdGlvbihhKXt2YXIgYj1udWxsLGM9bnVsbCxkPW51bGwsZT10aGlzLmRpZmZlcmVuY2UodGhpcy5fZHJhZy5wb2ludGVyLHRoaXMucG9pbnRlcihhKSksZj10aGlzLmRpZmZlcmVuY2UodGhpcy5fZHJhZy5zdGFnZS5zdGFydCxlKTt0aGlzLmlzKFwiZHJhZ2dpbmdcIikmJihhLnByZXZlbnREZWZhdWx0KCksdGhpcy5zZXR0aW5ncy5sb29wPyhiPXRoaXMuY29vcmRpbmF0ZXModGhpcy5taW5pbXVtKCkpLGM9dGhpcy5jb29yZGluYXRlcyh0aGlzLm1heGltdW0oKSsxKS1iLGYueD0oKGYueC1iKSVjK2MpJWMrYik6KGI9dGhpcy5zZXR0aW5ncy5ydGw/dGhpcy5jb29yZGluYXRlcyh0aGlzLm1heGltdW0oKSk6dGhpcy5jb29yZGluYXRlcyh0aGlzLm1pbmltdW0oKSksYz10aGlzLnNldHRpbmdzLnJ0bD90aGlzLmNvb3JkaW5hdGVzKHRoaXMubWluaW11bSgpKTp0aGlzLmNvb3JkaW5hdGVzKHRoaXMubWF4aW11bSgpKSxkPXRoaXMuc2V0dGluZ3MucHVsbERyYWc/LTEqZS54LzU6MCxmLng9TWF0aC5tYXgoTWF0aC5taW4oZi54LGIrZCksYytkKSksdGhpcy5fZHJhZy5zdGFnZS5jdXJyZW50PWYsdGhpcy5hbmltYXRlKGYueCkpfSxlLnByb3RvdHlwZS5vbkRyYWdFbmQ9ZnVuY3Rpb24oYil7dmFyIGQ9dGhpcy5kaWZmZXJlbmNlKHRoaXMuX2RyYWcucG9pbnRlcix0aGlzLnBvaW50ZXIoYikpLGU9dGhpcy5fZHJhZy5zdGFnZS5jdXJyZW50LGY9ZC54PjBedGhpcy5zZXR0aW5ncy5ydGw/XCJsZWZ0XCI6XCJyaWdodFwiO2EoYykub2ZmKFwiLm93bC5jb3JlXCIpLHRoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3ModGhpcy5vcHRpb25zLmdyYWJDbGFzcyksKDAhPT1kLngmJnRoaXMuaXMoXCJkcmFnZ2luZ1wiKXx8IXRoaXMuaXMoXCJ2YWxpZFwiKSkmJih0aGlzLnNwZWVkKHRoaXMuc2V0dGluZ3MuZHJhZ0VuZFNwZWVkfHx0aGlzLnNldHRpbmdzLnNtYXJ0U3BlZWQpLHRoaXMuY3VycmVudCh0aGlzLmNsb3Nlc3QoZS54LDAhPT1kLng/Zjp0aGlzLl9kcmFnLmRpcmVjdGlvbikpLHRoaXMuaW52YWxpZGF0ZShcInBvc2l0aW9uXCIpLHRoaXMudXBkYXRlKCksdGhpcy5fZHJhZy5kaXJlY3Rpb249ZiwoTWF0aC5hYnMoZC54KT4zfHwobmV3IERhdGUpLmdldFRpbWUoKS10aGlzLl9kcmFnLnRpbWU+MzAwKSYmdGhpcy5fZHJhZy50YXJnZXQub25lKFwiY2xpY2sub3dsLmNvcmVcIixmdW5jdGlvbigpe3JldHVybiExfSkpLHRoaXMuaXMoXCJkcmFnZ2luZ1wiKSYmKHRoaXMubGVhdmUoXCJkcmFnZ2luZ1wiKSx0aGlzLnRyaWdnZXIoXCJkcmFnZ2VkXCIpKX0sZS5wcm90b3R5cGUuY2xvc2VzdD1mdW5jdGlvbihiLGMpe3ZhciBkPS0xLGU9MzAsZj10aGlzLndpZHRoKCksZz10aGlzLmNvb3JkaW5hdGVzKCk7cmV0dXJuIHRoaXMuc2V0dGluZ3MuZnJlZURyYWd8fGEuZWFjaChnLGEucHJveHkoZnVuY3Rpb24oYSxoKXtyZXR1cm5cImxlZnRcIj09PWMmJmI+aC1lJiZiPGgrZT9kPWE6XCJyaWdodFwiPT09YyYmYj5oLWYtZSYmYjxoLWYrZT9kPWErMTp0aGlzLm9wKGIsXCI8XCIsaCkmJnRoaXMub3AoYixcIj5cIixnW2ErMV18fGgtZikmJihkPVwibGVmdFwiPT09Yz9hKzE6YSksZD09PS0xfSx0aGlzKSksdGhpcy5zZXR0aW5ncy5sb29wfHwodGhpcy5vcChiLFwiPlwiLGdbdGhpcy5taW5pbXVtKCldKT9kPWI9dGhpcy5taW5pbXVtKCk6dGhpcy5vcChiLFwiPFwiLGdbdGhpcy5tYXhpbXVtKCldKSYmKGQ9Yj10aGlzLm1heGltdW0oKSkpLGR9LGUucHJvdG90eXBlLmFuaW1hdGU9ZnVuY3Rpb24oYil7dmFyIGM9dGhpcy5zcGVlZCgpPjA7dGhpcy5pcyhcImFuaW1hdGluZ1wiKSYmdGhpcy5vblRyYW5zaXRpb25FbmQoKSxjJiYodGhpcy5lbnRlcihcImFuaW1hdGluZ1wiKSx0aGlzLnRyaWdnZXIoXCJ0cmFuc2xhdGVcIikpLGEuc3VwcG9ydC50cmFuc2Zvcm0zZCYmYS5zdXBwb3J0LnRyYW5zaXRpb24/dGhpcy4kc3RhZ2UuY3NzKHt0cmFuc2Zvcm06XCJ0cmFuc2xhdGUzZChcIitiK1wicHgsMHB4LDBweClcIix0cmFuc2l0aW9uOnRoaXMuc3BlZWQoKS8xZTMrXCJzXCJ9KTpjP3RoaXMuJHN0YWdlLmFuaW1hdGUoe2xlZnQ6YitcInB4XCJ9LHRoaXMuc3BlZWQoKSx0aGlzLnNldHRpbmdzLmZhbGxiYWNrRWFzaW5nLGEucHJveHkodGhpcy5vblRyYW5zaXRpb25FbmQsdGhpcykpOnRoaXMuJHN0YWdlLmNzcyh7bGVmdDpiK1wicHhcIn0pfSxlLnByb3RvdHlwZS5pcz1mdW5jdGlvbihhKXtyZXR1cm4gdGhpcy5fc3RhdGVzLmN1cnJlbnRbYV0mJnRoaXMuX3N0YXRlcy5jdXJyZW50W2FdPjB9LGUucHJvdG90eXBlLmN1cnJlbnQ9ZnVuY3Rpb24oYSl7aWYoYT09PWQpcmV0dXJuIHRoaXMuX2N1cnJlbnQ7aWYoMD09PXRoaXMuX2l0ZW1zLmxlbmd0aClyZXR1cm4gZDtpZihhPXRoaXMubm9ybWFsaXplKGEpLHRoaXMuX2N1cnJlbnQhPT1hKXt2YXIgYj10aGlzLnRyaWdnZXIoXCJjaGFuZ2VcIix7cHJvcGVydHk6e25hbWU6XCJwb3NpdGlvblwiLHZhbHVlOmF9fSk7Yi5kYXRhIT09ZCYmKGE9dGhpcy5ub3JtYWxpemUoYi5kYXRhKSksdGhpcy5fY3VycmVudD1hLHRoaXMuaW52YWxpZGF0ZShcInBvc2l0aW9uXCIpLHRoaXMudHJpZ2dlcihcImNoYW5nZWRcIix7cHJvcGVydHk6e25hbWU6XCJwb3NpdGlvblwiLHZhbHVlOnRoaXMuX2N1cnJlbnR9fSl9cmV0dXJuIHRoaXMuX2N1cnJlbnR9LGUucHJvdG90eXBlLmludmFsaWRhdGU9ZnVuY3Rpb24oYil7cmV0dXJuXCJzdHJpbmdcIj09PWEudHlwZShiKSYmKHRoaXMuX2ludmFsaWRhdGVkW2JdPSEwLHRoaXMuaXMoXCJ2YWxpZFwiKSYmdGhpcy5sZWF2ZShcInZhbGlkXCIpKSxhLm1hcCh0aGlzLl9pbnZhbGlkYXRlZCxmdW5jdGlvbihhLGIpe3JldHVybiBifSl9LGUucHJvdG90eXBlLnJlc2V0PWZ1bmN0aW9uKGEpe2E9dGhpcy5ub3JtYWxpemUoYSksYSE9PWQmJih0aGlzLl9zcGVlZD0wLHRoaXMuX2N1cnJlbnQ9YSx0aGlzLnN1cHByZXNzKFtcInRyYW5zbGF0ZVwiLFwidHJhbnNsYXRlZFwiXSksdGhpcy5hbmltYXRlKHRoaXMuY29vcmRpbmF0ZXMoYSkpLHRoaXMucmVsZWFzZShbXCJ0cmFuc2xhdGVcIixcInRyYW5zbGF0ZWRcIl0pKX0sZS5wcm90b3R5cGUubm9ybWFsaXplPWZ1bmN0aW9uKGEsYil7dmFyIGM9dGhpcy5faXRlbXMubGVuZ3RoLGU9Yj8wOnRoaXMuX2Nsb25lcy5sZW5ndGg7cmV0dXJuIXRoaXMuaXNOdW1lcmljKGEpfHxjPDE/YT1kOihhPDB8fGE+PWMrZSkmJihhPSgoYS1lLzIpJWMrYyklYytlLzIpLGF9LGUucHJvdG90eXBlLnJlbGF0aXZlPWZ1bmN0aW9uKGEpe3JldHVybiBhLT10aGlzLl9jbG9uZXMubGVuZ3RoLzIsdGhpcy5ub3JtYWxpemUoYSwhMCl9LGUucHJvdG90eXBlLm1heGltdW09ZnVuY3Rpb24oYSl7dmFyIGIsYyxkLGU9dGhpcy5zZXR0aW5ncyxmPXRoaXMuX2Nvb3JkaW5hdGVzLmxlbmd0aDtpZihlLmxvb3ApZj10aGlzLl9jbG9uZXMubGVuZ3RoLzIrdGhpcy5faXRlbXMubGVuZ3RoLTE7ZWxzZSBpZihlLmF1dG9XaWR0aHx8ZS5tZXJnZSl7Zm9yKGI9dGhpcy5faXRlbXMubGVuZ3RoLGM9dGhpcy5faXRlbXNbLS1iXS53aWR0aCgpLGQ9dGhpcy4kZWxlbWVudC53aWR0aCgpO2ItLSYmKGMrPXRoaXMuX2l0ZW1zW2JdLndpZHRoKCkrdGhpcy5zZXR0aW5ncy5tYXJnaW4sIShjPmQpKTspO2Y9YisxfWVsc2UgZj1lLmNlbnRlcj90aGlzLl9pdGVtcy5sZW5ndGgtMTp0aGlzLl9pdGVtcy5sZW5ndGgtZS5pdGVtcztyZXR1cm4gYSYmKGYtPXRoaXMuX2Nsb25lcy5sZW5ndGgvMiksTWF0aC5tYXgoZiwwKX0sZS5wcm90b3R5cGUubWluaW11bT1mdW5jdGlvbihhKXtyZXR1cm4gYT8wOnRoaXMuX2Nsb25lcy5sZW5ndGgvMn0sZS5wcm90b3R5cGUuaXRlbXM9ZnVuY3Rpb24oYSl7cmV0dXJuIGE9PT1kP3RoaXMuX2l0ZW1zLnNsaWNlKCk6KGE9dGhpcy5ub3JtYWxpemUoYSwhMCksdGhpcy5faXRlbXNbYV0pfSxlLnByb3RvdHlwZS5tZXJnZXJzPWZ1bmN0aW9uKGEpe3JldHVybiBhPT09ZD90aGlzLl9tZXJnZXJzLnNsaWNlKCk6KGE9dGhpcy5ub3JtYWxpemUoYSwhMCksdGhpcy5fbWVyZ2Vyc1thXSl9LGUucHJvdG90eXBlLmNsb25lcz1mdW5jdGlvbihiKXt2YXIgYz10aGlzLl9jbG9uZXMubGVuZ3RoLzIsZT1jK3RoaXMuX2l0ZW1zLmxlbmd0aCxmPWZ1bmN0aW9uKGEpe3JldHVybiBhJTI9PT0wP2UrYS8yOmMtKGErMSkvMn07cmV0dXJuIGI9PT1kP2EubWFwKHRoaXMuX2Nsb25lcyxmdW5jdGlvbihhLGIpe3JldHVybiBmKGIpfSk6YS5tYXAodGhpcy5fY2xvbmVzLGZ1bmN0aW9uKGEsYyl7cmV0dXJuIGE9PT1iP2YoYyk6bnVsbH0pfSxlLnByb3RvdHlwZS5zcGVlZD1mdW5jdGlvbihhKXtyZXR1cm4gYSE9PWQmJih0aGlzLl9zcGVlZD1hKSx0aGlzLl9zcGVlZH0sZS5wcm90b3R5cGUuY29vcmRpbmF0ZXM9ZnVuY3Rpb24oYil7dmFyIGMsZT0xLGY9Yi0xO3JldHVybiBiPT09ZD9hLm1hcCh0aGlzLl9jb29yZGluYXRlcyxhLnByb3h5KGZ1bmN0aW9uKGEsYil7cmV0dXJuIHRoaXMuY29vcmRpbmF0ZXMoYil9LHRoaXMpKToodGhpcy5zZXR0aW5ncy5jZW50ZXI/KHRoaXMuc2V0dGluZ3MucnRsJiYoZT0tMSxmPWIrMSksYz10aGlzLl9jb29yZGluYXRlc1tiXSxjKz0odGhpcy53aWR0aCgpLWMrKHRoaXMuX2Nvb3JkaW5hdGVzW2ZdfHwwKSkvMiplKTpjPXRoaXMuX2Nvb3JkaW5hdGVzW2ZdfHwwLGM9TWF0aC5jZWlsKGMpKX0sZS5wcm90b3R5cGUuZHVyYXRpb249ZnVuY3Rpb24oYSxiLGMpe3JldHVybiAwPT09Yz8wOk1hdGgubWluKE1hdGgubWF4KE1hdGguYWJzKGItYSksMSksNikqTWF0aC5hYnMoY3x8dGhpcy5zZXR0aW5ncy5zbWFydFNwZWVkKX0sZS5wcm90b3R5cGUudG89ZnVuY3Rpb24oYSxiKXt2YXIgYz10aGlzLmN1cnJlbnQoKSxkPW51bGwsZT1hLXRoaXMucmVsYXRpdmUoYyksZj0oZT4wKS0oZTwwKSxnPXRoaXMuX2l0ZW1zLmxlbmd0aCxoPXRoaXMubWluaW11bSgpLGk9dGhpcy5tYXhpbXVtKCk7dGhpcy5zZXR0aW5ncy5sb29wPyghdGhpcy5zZXR0aW5ncy5yZXdpbmQmJk1hdGguYWJzKGUpPmcvMiYmKGUrPWYqLTEqZyksYT1jK2UsZD0oKGEtaCklZytnKSVnK2gsZCE9PWEmJmQtZTw9aSYmZC1lPjAmJihjPWQtZSxhPWQsdGhpcy5yZXNldChjKSkpOnRoaXMuc2V0dGluZ3MucmV3aW5kPyhpKz0xLGE9KGElaStpKSVpKTphPU1hdGgubWF4KGgsTWF0aC5taW4oaSxhKSksdGhpcy5zcGVlZCh0aGlzLmR1cmF0aW9uKGMsYSxiKSksdGhpcy5jdXJyZW50KGEpLHRoaXMuJGVsZW1lbnQuaXMoXCI6dmlzaWJsZVwiKSYmdGhpcy51cGRhdGUoKX0sZS5wcm90b3R5cGUubmV4dD1mdW5jdGlvbihhKXthPWF8fCExLHRoaXMudG8odGhpcy5yZWxhdGl2ZSh0aGlzLmN1cnJlbnQoKSkrMSxhKX0sZS5wcm90b3R5cGUucHJldj1mdW5jdGlvbihhKXthPWF8fCExLHRoaXMudG8odGhpcy5yZWxhdGl2ZSh0aGlzLmN1cnJlbnQoKSktMSxhKX0sZS5wcm90b3R5cGUub25UcmFuc2l0aW9uRW5kPWZ1bmN0aW9uKGEpe2lmKGEhPT1kJiYoYS5zdG9wUHJvcGFnYXRpb24oKSwoYS50YXJnZXR8fGEuc3JjRWxlbWVudHx8YS5vcmlnaW5hbFRhcmdldCkhPT10aGlzLiRzdGFnZS5nZXQoMCkpKXJldHVybiExO3RoaXMubGVhdmUoXCJhbmltYXRpbmdcIiksdGhpcy50cmlnZ2VyKFwidHJhbnNsYXRlZFwiKX0sZS5wcm90b3R5cGUudmlld3BvcnQ9ZnVuY3Rpb24oKXt2YXIgZDtyZXR1cm4gdGhpcy5vcHRpb25zLnJlc3BvbnNpdmVCYXNlRWxlbWVudCE9PWI/ZD1hKHRoaXMub3B0aW9ucy5yZXNwb25zaXZlQmFzZUVsZW1lbnQpLndpZHRoKCk6Yi5pbm5lcldpZHRoP2Q9Yi5pbm5lcldpZHRoOmMuZG9jdW1lbnRFbGVtZW50JiZjLmRvY3VtZW50RWxlbWVudC5jbGllbnRXaWR0aD9kPWMuZG9jdW1lbnRFbGVtZW50LmNsaWVudFdpZHRoOmNvbnNvbGUud2FybihcIkNhbiBub3QgZGV0ZWN0IHZpZXdwb3J0IHdpZHRoLlwiKSxkfSxlLnByb3RvdHlwZS5yZXBsYWNlPWZ1bmN0aW9uKGIpe3RoaXMuJHN0YWdlLmVtcHR5KCksdGhpcy5faXRlbXM9W10sYiYmKGI9YiBpbnN0YW5jZW9mIGpRdWVyeT9iOmEoYikpLHRoaXMuc2V0dGluZ3MubmVzdGVkSXRlbVNlbGVjdG9yJiYoYj1iLmZpbmQoXCIuXCIrdGhpcy5zZXR0aW5ncy5uZXN0ZWRJdGVtU2VsZWN0b3IpKSxiLmZpbHRlcihmdW5jdGlvbigpe3JldHVybiAxPT09dGhpcy5ub2RlVHlwZX0pLmVhY2goYS5wcm94eShmdW5jdGlvbihhLGIpe2I9dGhpcy5wcmVwYXJlKGIpLHRoaXMuJHN0YWdlLmFwcGVuZChiKSx0aGlzLl9pdGVtcy5wdXNoKGIpLHRoaXMuX21lcmdlcnMucHVzaCgxKmIuZmluZChcIltkYXRhLW1lcmdlXVwiKS5hZGRCYWNrKFwiW2RhdGEtbWVyZ2VdXCIpLmF0dHIoXCJkYXRhLW1lcmdlXCIpfHwxKX0sdGhpcykpLHRoaXMucmVzZXQodGhpcy5pc051bWVyaWModGhpcy5zZXR0aW5ncy5zdGFydFBvc2l0aW9uKT90aGlzLnNldHRpbmdzLnN0YXJ0UG9zaXRpb246MCksdGhpcy5pbnZhbGlkYXRlKFwiaXRlbXNcIil9LGUucHJvdG90eXBlLmFkZD1mdW5jdGlvbihiLGMpe3ZhciBlPXRoaXMucmVsYXRpdmUodGhpcy5fY3VycmVudCk7Yz1jPT09ZD90aGlzLl9pdGVtcy5sZW5ndGg6dGhpcy5ub3JtYWxpemUoYywhMCksYj1iIGluc3RhbmNlb2YgalF1ZXJ5P2I6YShiKSx0aGlzLnRyaWdnZXIoXCJhZGRcIix7Y29udGVudDpiLHBvc2l0aW9uOmN9KSxiPXRoaXMucHJlcGFyZShiKSwwPT09dGhpcy5faXRlbXMubGVuZ3RofHxjPT09dGhpcy5faXRlbXMubGVuZ3RoPygwPT09dGhpcy5faXRlbXMubGVuZ3RoJiZ0aGlzLiRzdGFnZS5hcHBlbmQoYiksMCE9PXRoaXMuX2l0ZW1zLmxlbmd0aCYmdGhpcy5faXRlbXNbYy0xXS5hZnRlcihiKSx0aGlzLl9pdGVtcy5wdXNoKGIpLHRoaXMuX21lcmdlcnMucHVzaCgxKmIuZmluZChcIltkYXRhLW1lcmdlXVwiKS5hZGRCYWNrKFwiW2RhdGEtbWVyZ2VdXCIpLmF0dHIoXCJkYXRhLW1lcmdlXCIpfHwxKSk6KHRoaXMuX2l0ZW1zW2NdLmJlZm9yZShiKSx0aGlzLl9pdGVtcy5zcGxpY2UoYywwLGIpLHRoaXMuX21lcmdlcnMuc3BsaWNlKGMsMCwxKmIuZmluZChcIltkYXRhLW1lcmdlXVwiKS5hZGRCYWNrKFwiW2RhdGEtbWVyZ2VdXCIpLmF0dHIoXCJkYXRhLW1lcmdlXCIpfHwxKSksdGhpcy5faXRlbXNbZV0mJnRoaXMucmVzZXQodGhpcy5faXRlbXNbZV0uaW5kZXgoKSksdGhpcy5pbnZhbGlkYXRlKFwiaXRlbXNcIiksdGhpcy50cmlnZ2VyKFwiYWRkZWRcIix7Y29udGVudDpiLHBvc2l0aW9uOmN9KX0sZS5wcm90b3R5cGUucmVtb3ZlPWZ1bmN0aW9uKGEpe2E9dGhpcy5ub3JtYWxpemUoYSwhMCksYSE9PWQmJih0aGlzLnRyaWdnZXIoXCJyZW1vdmVcIix7Y29udGVudDp0aGlzLl9pdGVtc1thXSxwb3NpdGlvbjphfSksdGhpcy5faXRlbXNbYV0ucmVtb3ZlKCksdGhpcy5faXRlbXMuc3BsaWNlKGEsMSksdGhpcy5fbWVyZ2Vycy5zcGxpY2UoYSwxKSx0aGlzLmludmFsaWRhdGUoXCJpdGVtc1wiKSx0aGlzLnRyaWdnZXIoXCJyZW1vdmVkXCIse2NvbnRlbnQ6bnVsbCxwb3NpdGlvbjphfSkpfSxlLnByb3RvdHlwZS5wcmVsb2FkQXV0b1dpZHRoSW1hZ2VzPWZ1bmN0aW9uKGIpe2IuZWFjaChhLnByb3h5KGZ1bmN0aW9uKGIsYyl7dGhpcy5lbnRlcihcInByZS1sb2FkaW5nXCIpLGM9YShjKSxhKG5ldyBJbWFnZSkub25lKFwibG9hZFwiLGEucHJveHkoZnVuY3Rpb24oYSl7Yy5hdHRyKFwic3JjXCIsYS50YXJnZXQuc3JjKSxjLmNzcyhcIm9wYWNpdHlcIiwxKSx0aGlzLmxlYXZlKFwicHJlLWxvYWRpbmdcIiksIXRoaXMuaXMoXCJwcmUtbG9hZGluZ1wiKSYmIXRoaXMuaXMoXCJpbml0aWFsaXppbmdcIikmJnRoaXMucmVmcmVzaCgpfSx0aGlzKSkuYXR0cihcInNyY1wiLGMuYXR0cihcInNyY1wiKXx8Yy5hdHRyKFwiZGF0YS1zcmNcIil8fGMuYXR0cihcImRhdGEtc3JjLXJldGluYVwiKSl9LHRoaXMpKX0sZS5wcm90b3R5cGUuZGVzdHJveT1mdW5jdGlvbigpe3RoaXMuJGVsZW1lbnQub2ZmKFwiLm93bC5jb3JlXCIpLHRoaXMuJHN0YWdlLm9mZihcIi5vd2wuY29yZVwiKSxhKGMpLm9mZihcIi5vd2wuY29yZVwiKSx0aGlzLnNldHRpbmdzLnJlc3BvbnNpdmUhPT0hMSYmKGIuY2xlYXJUaW1lb3V0KHRoaXMucmVzaXplVGltZXIpLHRoaXMub2ZmKGIsXCJyZXNpemVcIix0aGlzLl9oYW5kbGVycy5vblRocm90dGxlZFJlc2l6ZSkpO2Zvcih2YXIgZCBpbiB0aGlzLl9wbHVnaW5zKXRoaXMuX3BsdWdpbnNbZF0uZGVzdHJveSgpO3RoaXMuJHN0YWdlLmNoaWxkcmVuKFwiLmNsb25lZFwiKS5yZW1vdmUoKSx0aGlzLiRzdGFnZS51bndyYXAoKSx0aGlzLiRzdGFnZS5jaGlsZHJlbigpLmNvbnRlbnRzKCkudW53cmFwKCksdGhpcy4kc3RhZ2UuY2hpbGRyZW4oKS51bndyYXAoKSx0aGlzLiRlbGVtZW50LnJlbW92ZUNsYXNzKHRoaXMub3B0aW9ucy5yZWZyZXNoQ2xhc3MpLnJlbW92ZUNsYXNzKHRoaXMub3B0aW9ucy5sb2FkaW5nQ2xhc3MpLnJlbW92ZUNsYXNzKHRoaXMub3B0aW9ucy5sb2FkZWRDbGFzcykucmVtb3ZlQ2xhc3ModGhpcy5vcHRpb25zLnJ0bENsYXNzKS5yZW1vdmVDbGFzcyh0aGlzLm9wdGlvbnMuZHJhZ0NsYXNzKS5yZW1vdmVDbGFzcyh0aGlzLm9wdGlvbnMuZ3JhYkNsYXNzKS5hdHRyKFwiY2xhc3NcIix0aGlzLiRlbGVtZW50LmF0dHIoXCJjbGFzc1wiKS5yZXBsYWNlKG5ldyBSZWdFeHAodGhpcy5vcHRpb25zLnJlc3BvbnNpdmVDbGFzcytcIi1cXFxcUytcXFxcc1wiLFwiZ1wiKSxcIlwiKSkucmVtb3ZlRGF0YShcIm93bC5jYXJvdXNlbFwiKX0sZS5wcm90b3R5cGUub3A9ZnVuY3Rpb24oYSxiLGMpe3ZhciBkPXRoaXMuc2V0dGluZ3MucnRsO3N3aXRjaChiKXtjYXNlXCI8XCI6cmV0dXJuIGQ/YT5jOmE8YztjYXNlXCI+XCI6cmV0dXJuIGQ/YTxjOmE+YztjYXNlXCI+PVwiOnJldHVybiBkP2E8PWM6YT49YztjYXNlXCI8PVwiOnJldHVybiBkP2E+PWM6YTw9Y319LGUucHJvdG90eXBlLm9uPWZ1bmN0aW9uKGEsYixjLGQpe2EuYWRkRXZlbnRMaXN0ZW5lcj9hLmFkZEV2ZW50TGlzdGVuZXIoYixjLGQpOmEuYXR0YWNoRXZlbnQmJmEuYXR0YWNoRXZlbnQoXCJvblwiK2IsYyl9LGUucHJvdG90eXBlLm9mZj1mdW5jdGlvbihhLGIsYyxkKXthLnJlbW92ZUV2ZW50TGlzdGVuZXI/YS5yZW1vdmVFdmVudExpc3RlbmVyKGIsYyxkKTphLmRldGFjaEV2ZW50JiZhLmRldGFjaEV2ZW50KFwib25cIitiLGMpfSxlLnByb3RvdHlwZS50cmlnZ2VyPWZ1bmN0aW9uKGIsYyxkLGYsZyl7dmFyIGg9e2l0ZW06e2NvdW50OnRoaXMuX2l0ZW1zLmxlbmd0aCxpbmRleDp0aGlzLmN1cnJlbnQoKX19LGk9YS5jYW1lbENhc2UoYS5ncmVwKFtcIm9uXCIsYixkXSxmdW5jdGlvbihhKXtyZXR1cm4gYX0pLmpvaW4oXCItXCIpLnRvTG93ZXJDYXNlKCkpLGo9YS5FdmVudChbYixcIm93bFwiLGR8fFwiY2Fyb3VzZWxcIl0uam9pbihcIi5cIikudG9Mb3dlckNhc2UoKSxhLmV4dGVuZCh7cmVsYXRlZFRhcmdldDp0aGlzfSxoLGMpKTtyZXR1cm4gdGhpcy5fc3VwcmVzc1tiXXx8KGEuZWFjaCh0aGlzLl9wbHVnaW5zLGZ1bmN0aW9uKGEsYil7Yi5vblRyaWdnZXImJmIub25UcmlnZ2VyKGopfSksdGhpcy5yZWdpc3Rlcih7dHlwZTplLlR5cGUuRXZlbnQsbmFtZTpifSksdGhpcy4kZWxlbWVudC50cmlnZ2VyKGopLHRoaXMuc2V0dGluZ3MmJlwiZnVuY3Rpb25cIj09dHlwZW9mIHRoaXMuc2V0dGluZ3NbaV0mJnRoaXMuc2V0dGluZ3NbaV0uY2FsbCh0aGlzLGopKSxqfSxlLnByb3RvdHlwZS5lbnRlcj1mdW5jdGlvbihiKXthLmVhY2goW2JdLmNvbmNhdCh0aGlzLl9zdGF0ZXMudGFnc1tiXXx8W10pLGEucHJveHkoZnVuY3Rpb24oYSxiKXt0aGlzLl9zdGF0ZXMuY3VycmVudFtiXT09PWQmJih0aGlzLl9zdGF0ZXMuY3VycmVudFtiXT0wKSx0aGlzLl9zdGF0ZXMuY3VycmVudFtiXSsrfSx0aGlzKSl9LGUucHJvdG90eXBlLmxlYXZlPWZ1bmN0aW9uKGIpe2EuZWFjaChbYl0uY29uY2F0KHRoaXMuX3N0YXRlcy50YWdzW2JdfHxbXSksYS5wcm94eShmdW5jdGlvbihhLGIpe3RoaXMuX3N0YXRlcy5jdXJyZW50W2JdLS19LHRoaXMpKX0sZS5wcm90b3R5cGUucmVnaXN0ZXI9ZnVuY3Rpb24oYil7aWYoYi50eXBlPT09ZS5UeXBlLkV2ZW50KXtpZihhLmV2ZW50LnNwZWNpYWxbYi5uYW1lXXx8KGEuZXZlbnQuc3BlY2lhbFtiLm5hbWVdPXt9KSwhYS5ldmVudC5zcGVjaWFsW2IubmFtZV0ub3dsKXt2YXIgYz1hLmV2ZW50LnNwZWNpYWxbYi5uYW1lXS5fZGVmYXVsdDthLmV2ZW50LnNwZWNpYWxbYi5uYW1lXS5fZGVmYXVsdD1mdW5jdGlvbihhKXtyZXR1cm4hY3x8IWMuYXBwbHl8fGEubmFtZXNwYWNlJiZhLm5hbWVzcGFjZS5pbmRleE9mKFwib3dsXCIpIT09LTE/YS5uYW1lc3BhY2UmJmEubmFtZXNwYWNlLmluZGV4T2YoXCJvd2xcIik+LTE6Yy5hcHBseSh0aGlzLGFyZ3VtZW50cyl9LGEuZXZlbnQuc3BlY2lhbFtiLm5hbWVdLm93bD0hMH19ZWxzZSBiLnR5cGU9PT1lLlR5cGUuU3RhdGUmJih0aGlzLl9zdGF0ZXMudGFnc1tiLm5hbWVdP3RoaXMuX3N0YXRlcy50YWdzW2IubmFtZV09dGhpcy5fc3RhdGVzLnRhZ3NbYi5uYW1lXS5jb25jYXQoYi50YWdzKTp0aGlzLl9zdGF0ZXMudGFnc1tiLm5hbWVdPWIudGFncyx0aGlzLl9zdGF0ZXMudGFnc1tiLm5hbWVdPWEuZ3JlcCh0aGlzLl9zdGF0ZXMudGFnc1tiLm5hbWVdLGEucHJveHkoZnVuY3Rpb24oYyxkKXtyZXR1cm4gYS5pbkFycmF5KGMsdGhpcy5fc3RhdGVzLnRhZ3NbYi5uYW1lXSk9PT1kfSx0aGlzKSkpfSxlLnByb3RvdHlwZS5zdXBwcmVzcz1mdW5jdGlvbihiKXthLmVhY2goYixhLnByb3h5KGZ1bmN0aW9uKGEsYil7dGhpcy5fc3VwcmVzc1tiXT0hMH0sdGhpcykpfSxlLnByb3RvdHlwZS5yZWxlYXNlPWZ1bmN0aW9uKGIpe2EuZWFjaChiLGEucHJveHkoZnVuY3Rpb24oYSxiKXtkZWxldGUgdGhpcy5fc3VwcmVzc1tiXX0sdGhpcykpfSxlLnByb3RvdHlwZS5wb2ludGVyPWZ1bmN0aW9uKGEpe3ZhciBjPXt4Om51bGwseTpudWxsfTtyZXR1cm4gYT1hLm9yaWdpbmFsRXZlbnR8fGF8fGIuZXZlbnQsYT1hLnRvdWNoZXMmJmEudG91Y2hlcy5sZW5ndGg/YS50b3VjaGVzWzBdOmEuY2hhbmdlZFRvdWNoZXMmJmEuY2hhbmdlZFRvdWNoZXMubGVuZ3RoP2EuY2hhbmdlZFRvdWNoZXNbMF06YSxhLnBhZ2VYPyhjLng9YS5wYWdlWCxjLnk9YS5wYWdlWSk6KGMueD1hLmNsaWVudFgsYy55PWEuY2xpZW50WSksY30sZS5wcm90b3R5cGUuaXNOdW1lcmljPWZ1bmN0aW9uKGEpe3JldHVybiFpc05hTihwYXJzZUZsb2F0KGEpKX0sZS5wcm90b3R5cGUuZGlmZmVyZW5jZT1mdW5jdGlvbihhLGIpe3JldHVybnt4OmEueC1iLngseTphLnktYi55fX0sYS5mbi5vd2xDYXJvdXNlbD1mdW5jdGlvbihiKXt2YXIgYz1BcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMsMSk7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe3ZhciBkPWEodGhpcyksZj1kLmRhdGEoXCJvd2wuY2Fyb3VzZWxcIik7Znx8KGY9bmV3IGUodGhpcyxcIm9iamVjdFwiPT10eXBlb2YgYiYmYiksZC5kYXRhKFwib3dsLmNhcm91c2VsXCIsZiksYS5lYWNoKFtcIm5leHRcIixcInByZXZcIixcInRvXCIsXCJkZXN0cm95XCIsXCJyZWZyZXNoXCIsXCJyZXBsYWNlXCIsXCJhZGRcIixcInJlbW92ZVwiXSxmdW5jdGlvbihiLGMpe2YucmVnaXN0ZXIoe3R5cGU6ZS5UeXBlLkV2ZW50LG5hbWU6Y30pLGYuJGVsZW1lbnQub24oYytcIi5vd2wuY2Fyb3VzZWwuY29yZVwiLGEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJmEucmVsYXRlZFRhcmdldCE9PXRoaXMmJih0aGlzLnN1cHByZXNzKFtjXSksZltjXS5hcHBseSh0aGlzLFtdLnNsaWNlLmNhbGwoYXJndW1lbnRzLDEpKSx0aGlzLnJlbGVhc2UoW2NdKSl9LGYpKX0pKSxcInN0cmluZ1wiPT10eXBlb2YgYiYmXCJfXCIhPT1iLmNoYXJBdCgwKSYmZltiXS5hcHBseShmLGMpfSl9LGEuZm4ub3dsQ2Fyb3VzZWwuQ29uc3RydWN0b3I9ZX0od2luZG93LlplcHRvfHx3aW5kb3cualF1ZXJ5LHdpbmRvdyxkb2N1bWVudCksZnVuY3Rpb24oYSxiLGMsZCl7dmFyIGU9ZnVuY3Rpb24oYil7dGhpcy5fY29yZT1iLHRoaXMuX2ludGVydmFsPW51bGwsdGhpcy5fdmlzaWJsZT1udWxsLHRoaXMuX2hhbmRsZXJzPXtcImluaXRpYWxpemVkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJnRoaXMuX2NvcmUuc2V0dGluZ3MuYXV0b1JlZnJlc2gmJnRoaXMud2F0Y2goKX0sdGhpcyl9LHRoaXMuX2NvcmUub3B0aW9ucz1hLmV4dGVuZCh7fSxlLkRlZmF1bHRzLHRoaXMuX2NvcmUub3B0aW9ucyksdGhpcy5fY29yZS4kZWxlbWVudC5vbih0aGlzLl9oYW5kbGVycyl9O2UuRGVmYXVsdHM9e2F1dG9SZWZyZXNoOiEwLGF1dG9SZWZyZXNoSW50ZXJ2YWw6NTAwfSxlLnByb3RvdHlwZS53YXRjaD1mdW5jdGlvbigpe3RoaXMuX2ludGVydmFsfHwodGhpcy5fdmlzaWJsZT10aGlzLl9jb3JlLiRlbGVtZW50LmlzKFwiOnZpc2libGVcIiksdGhpcy5faW50ZXJ2YWw9Yi5zZXRJbnRlcnZhbChhLnByb3h5KHRoaXMucmVmcmVzaCx0aGlzKSx0aGlzLl9jb3JlLnNldHRpbmdzLmF1dG9SZWZyZXNoSW50ZXJ2YWwpKX0sZS5wcm90b3R5cGUucmVmcmVzaD1mdW5jdGlvbigpe3RoaXMuX2NvcmUuJGVsZW1lbnQuaXMoXCI6dmlzaWJsZVwiKSE9PXRoaXMuX3Zpc2libGUmJih0aGlzLl92aXNpYmxlPSF0aGlzLl92aXNpYmxlLHRoaXMuX2NvcmUuJGVsZW1lbnQudG9nZ2xlQ2xhc3MoXCJvd2wtaGlkZGVuXCIsIXRoaXMuX3Zpc2libGUpLHRoaXMuX3Zpc2libGUmJnRoaXMuX2NvcmUuaW52YWxpZGF0ZShcIndpZHRoXCIpJiZ0aGlzLl9jb3JlLnJlZnJlc2goKSl9LGUucHJvdG90eXBlLmRlc3Ryb3k9ZnVuY3Rpb24oKXt2YXIgYSxjO2IuY2xlYXJJbnRlcnZhbCh0aGlzLl9pbnRlcnZhbCk7Zm9yKGEgaW4gdGhpcy5faGFuZGxlcnMpdGhpcy5fY29yZS4kZWxlbWVudC5vZmYoYSx0aGlzLl9oYW5kbGVyc1thXSk7Zm9yKGMgaW4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGhpcykpXCJmdW5jdGlvblwiIT10eXBlb2YgdGhpc1tjXSYmKHRoaXNbY109bnVsbCl9LGEuZm4ub3dsQ2Fyb3VzZWwuQ29uc3RydWN0b3IuUGx1Z2lucy5BdXRvUmVmcmVzaD1lfSh3aW5kb3cuWmVwdG98fHdpbmRvdy5qUXVlcnksd2luZG93LGRvY3VtZW50KSxmdW5jdGlvbihhLGIsYyxkKXt2YXIgZT1mdW5jdGlvbihiKXt0aGlzLl9jb3JlPWIsdGhpcy5fbG9hZGVkPVtdLHRoaXMuX2hhbmRsZXJzPXtcImluaXRpYWxpemVkLm93bC5jYXJvdXNlbCBjaGFuZ2Uub3dsLmNhcm91c2VsIHJlc2l6ZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihiKXtpZihiLm5hbWVzcGFjZSYmdGhpcy5fY29yZS5zZXR0aW5ncyYmdGhpcy5fY29yZS5zZXR0aW5ncy5sYXp5TG9hZCYmKGIucHJvcGVydHkmJlwicG9zaXRpb25cIj09Yi5wcm9wZXJ0eS5uYW1lfHxcImluaXRpYWxpemVkXCI9PWIudHlwZSkpZm9yKHZhciBjPXRoaXMuX2NvcmUuc2V0dGluZ3MsZT1jLmNlbnRlciYmTWF0aC5jZWlsKGMuaXRlbXMvMil8fGMuaXRlbXMsZj1jLmNlbnRlciYmZSotMXx8MCxnPShiLnByb3BlcnR5JiZiLnByb3BlcnR5LnZhbHVlIT09ZD9iLnByb3BlcnR5LnZhbHVlOnRoaXMuX2NvcmUuY3VycmVudCgpKStmLGg9dGhpcy5fY29yZS5jbG9uZXMoKS5sZW5ndGgsaT1hLnByb3h5KGZ1bmN0aW9uKGEsYil7dGhpcy5sb2FkKGIpfSx0aGlzKTtmKys8ZTspdGhpcy5sb2FkKGgvMit0aGlzLl9jb3JlLnJlbGF0aXZlKGcpKSxoJiZhLmVhY2godGhpcy5fY29yZS5jbG9uZXModGhpcy5fY29yZS5yZWxhdGl2ZShnKSksaSksZysrfSx0aGlzKX0sdGhpcy5fY29yZS5vcHRpb25zPWEuZXh0ZW5kKHt9LGUuRGVmYXVsdHMsdGhpcy5fY29yZS5vcHRpb25zKSx0aGlzLl9jb3JlLiRlbGVtZW50Lm9uKHRoaXMuX2hhbmRsZXJzKX07ZS5EZWZhdWx0cz17bGF6eUxvYWQ6ITF9LGUucHJvdG90eXBlLmxvYWQ9ZnVuY3Rpb24oYyl7dmFyIGQ9dGhpcy5fY29yZS4kc3RhZ2UuY2hpbGRyZW4oKS5lcShjKSxlPWQmJmQuZmluZChcIi5vd2wtbGF6eVwiKTshZXx8YS5pbkFycmF5KGQuZ2V0KDApLHRoaXMuX2xvYWRlZCk+LTF8fChlLmVhY2goYS5wcm94eShmdW5jdGlvbihjLGQpe3ZhciBlLGY9YShkKSxnPWIuZGV2aWNlUGl4ZWxSYXRpbz4xJiZmLmF0dHIoXCJkYXRhLXNyYy1yZXRpbmFcIil8fGYuYXR0cihcImRhdGEtc3JjXCIpO3RoaXMuX2NvcmUudHJpZ2dlcihcImxvYWRcIix7ZWxlbWVudDpmLHVybDpnfSxcImxhenlcIiksZi5pcyhcImltZ1wiKT9mLm9uZShcImxvYWQub3dsLmxhenlcIixhLnByb3h5KGZ1bmN0aW9uKCl7Zi5jc3MoXCJvcGFjaXR5XCIsMSksdGhpcy5fY29yZS50cmlnZ2VyKFwibG9hZGVkXCIse2VsZW1lbnQ6Zix1cmw6Z30sXCJsYXp5XCIpfSx0aGlzKSkuYXR0cihcInNyY1wiLGcpOihlPW5ldyBJbWFnZSxlLm9ubG9hZD1hLnByb3h5KGZ1bmN0aW9uKCl7Zi5jc3Moe1wiYmFja2dyb3VuZC1pbWFnZVwiOid1cmwoXCInK2crJ1wiKScsb3BhY2l0eTpcIjFcIn0pLHRoaXMuX2NvcmUudHJpZ2dlcihcImxvYWRlZFwiLHtlbGVtZW50OmYsdXJsOmd9LFwibGF6eVwiKX0sdGhpcyksZS5zcmM9Zyl9LHRoaXMpKSx0aGlzLl9sb2FkZWQucHVzaChkLmdldCgwKSkpfSxlLnByb3RvdHlwZS5kZXN0cm95PWZ1bmN0aW9uKCl7dmFyIGEsYjtmb3IoYSBpbiB0aGlzLmhhbmRsZXJzKXRoaXMuX2NvcmUuJGVsZW1lbnQub2ZmKGEsdGhpcy5oYW5kbGVyc1thXSk7Zm9yKGIgaW4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGhpcykpXCJmdW5jdGlvblwiIT10eXBlb2YgdGhpc1tiXSYmKHRoaXNbYl09bnVsbCl9LGEuZm4ub3dsQ2Fyb3VzZWwuQ29uc3RydWN0b3IuUGx1Z2lucy5MYXp5PWV9KHdpbmRvdy5aZXB0b3x8d2luZG93LmpRdWVyeSx3aW5kb3csZG9jdW1lbnQpLGZ1bmN0aW9uKGEsYixjLGQpe3ZhciBlPWZ1bmN0aW9uKGIpe3RoaXMuX2NvcmU9Yix0aGlzLl9oYW5kbGVycz17XCJpbml0aWFsaXplZC5vd2wuY2Fyb3VzZWwgcmVmcmVzaGVkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJnRoaXMuX2NvcmUuc2V0dGluZ3MuYXV0b0hlaWdodCYmdGhpcy51cGRhdGUoKX0sdGhpcyksXCJjaGFuZ2VkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJnRoaXMuX2NvcmUuc2V0dGluZ3MuYXV0b0hlaWdodCYmXCJwb3NpdGlvblwiPT1hLnByb3BlcnR5Lm5hbWUmJnRoaXMudXBkYXRlKCl9LHRoaXMpLFwibG9hZGVkLm93bC5sYXp5XCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmdGhpcy5fY29yZS5zZXR0aW5ncy5hdXRvSGVpZ2h0JiZhLmVsZW1lbnQuY2xvc2VzdChcIi5cIit0aGlzLl9jb3JlLnNldHRpbmdzLml0ZW1DbGFzcykuaW5kZXgoKT09PXRoaXMuX2NvcmUuY3VycmVudCgpJiZ0aGlzLnVwZGF0ZSgpfSx0aGlzKX0sdGhpcy5fY29yZS5vcHRpb25zPWEuZXh0ZW5kKHt9LGUuRGVmYXVsdHMsdGhpcy5fY29yZS5vcHRpb25zKSx0aGlzLl9jb3JlLiRlbGVtZW50Lm9uKHRoaXMuX2hhbmRsZXJzKX07ZS5EZWZhdWx0cz17YXV0b0hlaWdodDohMSxhdXRvSGVpZ2h0Q2xhc3M6XCJvd2wtaGVpZ2h0XCJ9LGUucHJvdG90eXBlLnVwZGF0ZT1mdW5jdGlvbigpe3ZhciBiPXRoaXMuX2NvcmUuX2N1cnJlbnQsYz1iK3RoaXMuX2NvcmUuc2V0dGluZ3MuaXRlbXMsZD10aGlzLl9jb3JlLiRzdGFnZS5jaGlsZHJlbigpLnRvQXJyYXkoKS5zbGljZShiLGMpLGU9W10sZj0wO2EuZWFjaChkLGZ1bmN0aW9uKGIsYyl7ZS5wdXNoKGEoYykuaGVpZ2h0KCkpfSksZj1NYXRoLm1heC5hcHBseShudWxsLGUpLHRoaXMuX2NvcmUuJHN0YWdlLnBhcmVudCgpLmhlaWdodChmKS5hZGRDbGFzcyh0aGlzLl9jb3JlLnNldHRpbmdzLmF1dG9IZWlnaHRDbGFzcyl9LGUucHJvdG90eXBlLmRlc3Ryb3k9ZnVuY3Rpb24oKXt2YXIgYSxiO2ZvcihhIGluIHRoaXMuX2hhbmRsZXJzKXRoaXMuX2NvcmUuJGVsZW1lbnQub2ZmKGEsdGhpcy5faGFuZGxlcnNbYV0pO2ZvcihiIGluIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHRoaXMpKVwiZnVuY3Rpb25cIiE9dHlwZW9mIHRoaXNbYl0mJih0aGlzW2JdPW51bGwpfSxhLmZuLm93bENhcm91c2VsLkNvbnN0cnVjdG9yLlBsdWdpbnMuQXV0b0hlaWdodD1lfSh3aW5kb3cuWmVwdG98fHdpbmRvdy5qUXVlcnksd2luZG93LGRvY3VtZW50KSxmdW5jdGlvbihhLGIsYyxkKXt2YXIgZT1mdW5jdGlvbihiKXt0aGlzLl9jb3JlPWIsdGhpcy5fdmlkZW9zPXt9LHRoaXMuX3BsYXlpbmc9bnVsbCx0aGlzLl9oYW5kbGVycz17XCJpbml0aWFsaXplZC5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiZ0aGlzLl9jb3JlLnJlZ2lzdGVyKHt0eXBlOlwic3RhdGVcIixuYW1lOlwicGxheWluZ1wiLHRhZ3M6W1wiaW50ZXJhY3RpbmdcIl19KX0sdGhpcyksXCJyZXNpemUub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmdGhpcy5fY29yZS5zZXR0aW5ncy52aWRlbyYmdGhpcy5pc0luRnVsbFNjcmVlbigpJiZhLnByZXZlbnREZWZhdWx0KCl9LHRoaXMpLFwicmVmcmVzaGVkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJnRoaXMuX2NvcmUuaXMoXCJyZXNpemluZ1wiKSYmdGhpcy5fY29yZS4kc3RhZ2UuZmluZChcIi5jbG9uZWQgLm93bC12aWRlby1mcmFtZVwiKS5yZW1vdmUoKX0sdGhpcyksXCJjaGFuZ2VkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJlwicG9zaXRpb25cIj09PWEucHJvcGVydHkubmFtZSYmdGhpcy5fcGxheWluZyYmdGhpcy5zdG9wKCl9LHRoaXMpLFwicHJlcGFyZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihiKXtpZihiLm5hbWVzcGFjZSl7dmFyIGM9YShiLmNvbnRlbnQpLmZpbmQoXCIub3dsLXZpZGVvXCIpO2MubGVuZ3RoJiYoYy5jc3MoXCJkaXNwbGF5XCIsXCJub25lXCIpLHRoaXMuZmV0Y2goYyxhKGIuY29udGVudCkpKX19LHRoaXMpfSx0aGlzLl9jb3JlLm9wdGlvbnM9YS5leHRlbmQoe30sZS5EZWZhdWx0cyx0aGlzLl9jb3JlLm9wdGlvbnMpLHRoaXMuX2NvcmUuJGVsZW1lbnQub24odGhpcy5faGFuZGxlcnMpLHRoaXMuX2NvcmUuJGVsZW1lbnQub24oXCJjbGljay5vd2wudmlkZW9cIixcIi5vd2wtdmlkZW8tcGxheS1pY29uXCIsYS5wcm94eShmdW5jdGlvbihhKXt0aGlzLnBsYXkoYSl9LHRoaXMpKX07ZS5EZWZhdWx0cz17dmlkZW86ITEsdmlkZW9IZWlnaHQ6ITEsdmlkZW9XaWR0aDohMX0sZS5wcm90b3R5cGUuZmV0Y2g9ZnVuY3Rpb24oYSxiKXt2YXIgYz1mdW5jdGlvbigpe3JldHVybiBhLmF0dHIoXCJkYXRhLXZpbWVvLWlkXCIpP1widmltZW9cIjphLmF0dHIoXCJkYXRhLXZ6YWFyLWlkXCIpP1widnphYXJcIjpcInlvdXR1YmVcIn0oKSxkPWEuYXR0cihcImRhdGEtdmltZW8taWRcIil8fGEuYXR0cihcImRhdGEteW91dHViZS1pZFwiKXx8YS5hdHRyKFwiZGF0YS12emFhci1pZFwiKSxlPWEuYXR0cihcImRhdGEtd2lkdGhcIil8fHRoaXMuX2NvcmUuc2V0dGluZ3MudmlkZW9XaWR0aCxmPWEuYXR0cihcImRhdGEtaGVpZ2h0XCIpfHx0aGlzLl9jb3JlLnNldHRpbmdzLnZpZGVvSGVpZ2h0LGc9YS5hdHRyKFwiaHJlZlwiKTtpZighZyl0aHJvdyBuZXcgRXJyb3IoXCJNaXNzaW5nIHZpZGVvIFVSTC5cIik7aWYoZD1nLm1hdGNoKC8oaHR0cDp8aHR0cHM6fClcXC9cXC8ocGxheWVyLnx3d3cufGFwcC4pPyh2aW1lb1xcLmNvbXx5b3V0dShiZVxcLmNvbXxcXC5iZXxiZVxcLmdvb2dsZWFwaXNcXC5jb20pfHZ6YWFyXFwuY29tKVxcLyh2aWRlb1xcL3x2aWRlb3NcXC98ZW1iZWRcXC98Y2hhbm5lbHNcXC8uK1xcL3xncm91cHNcXC8uK1xcL3x3YXRjaFxcP3Y9fHZcXC8pPyhbQS1aYS16MC05Ll8lLV0qKShcXCZcXFMrKT8vKSxkWzNdLmluZGV4T2YoXCJ5b3V0dVwiKT4tMSljPVwieW91dHViZVwiO2Vsc2UgaWYoZFszXS5pbmRleE9mKFwidmltZW9cIik+LTEpYz1cInZpbWVvXCI7ZWxzZXtpZighKGRbM10uaW5kZXhPZihcInZ6YWFyXCIpPi0xKSl0aHJvdyBuZXcgRXJyb3IoXCJWaWRlbyBVUkwgbm90IHN1cHBvcnRlZC5cIik7Yz1cInZ6YWFyXCJ9ZD1kWzZdLHRoaXMuX3ZpZGVvc1tnXT17dHlwZTpjLGlkOmQsd2lkdGg6ZSxoZWlnaHQ6Zn0sYi5hdHRyKFwiZGF0YS12aWRlb1wiLGcpLHRoaXMudGh1bWJuYWlsKGEsdGhpcy5fdmlkZW9zW2ddKX0sZS5wcm90b3R5cGUudGh1bWJuYWlsPWZ1bmN0aW9uKGIsYyl7dmFyIGQsZSxmLGc9Yy53aWR0aCYmYy5oZWlnaHQ/J3N0eWxlPVwid2lkdGg6JytjLndpZHRoK1wicHg7aGVpZ2h0OlwiK2MuaGVpZ2h0KydweDtcIic6XCJcIixoPWIuZmluZChcImltZ1wiKSxpPVwic3JjXCIsaj1cIlwiLGs9dGhpcy5fY29yZS5zZXR0aW5ncyxsPWZ1bmN0aW9uKGEpe2U9JzxkaXYgY2xhc3M9XCJvd2wtdmlkZW8tcGxheS1pY29uXCI+PC9kaXY+JyxkPWsubGF6eUxvYWQ/JzxkaXYgY2xhc3M9XCJvd2wtdmlkZW8tdG4gJytqKydcIiAnK2krJz1cIicrYSsnXCI+PC9kaXY+JzonPGRpdiBjbGFzcz1cIm93bC12aWRlby10blwiIHN0eWxlPVwib3BhY2l0eToxO2JhY2tncm91bmQtaW1hZ2U6dXJsKCcrYSsnKVwiPjwvZGl2PicsYi5hZnRlcihkKSxiLmFmdGVyKGUpfTtpZihiLndyYXAoJzxkaXYgY2xhc3M9XCJvd2wtdmlkZW8td3JhcHBlclwiJytnK1wiPjwvZGl2PlwiKSx0aGlzLl9jb3JlLnNldHRpbmdzLmxhenlMb2FkJiYoaT1cImRhdGEtc3JjXCIsaj1cIm93bC1sYXp5XCIpLGgubGVuZ3RoKXJldHVybiBsKGguYXR0cihpKSksaC5yZW1vdmUoKSwhMTtcInlvdXR1YmVcIj09PWMudHlwZT8oZj1cIi8vaW1nLnlvdXR1YmUuY29tL3ZpL1wiK2MuaWQrXCIvaHFkZWZhdWx0LmpwZ1wiLGwoZikpOlwidmltZW9cIj09PWMudHlwZT9hLmFqYXgoe3R5cGU6XCJHRVRcIix1cmw6XCIvL3ZpbWVvLmNvbS9hcGkvdjIvdmlkZW8vXCIrYy5pZCtcIi5qc29uXCIsanNvbnA6XCJjYWxsYmFja1wiLGRhdGFUeXBlOlwianNvbnBcIixzdWNjZXNzOmZ1bmN0aW9uKGEpe2Y9YVswXS50aHVtYm5haWxfbGFyZ2UsbChmKX19KTpcInZ6YWFyXCI9PT1jLnR5cGUmJmEuYWpheCh7dHlwZTpcIkdFVFwiLHVybDpcIi8vdnphYXIuY29tL2FwaS92aWRlb3MvXCIrYy5pZCtcIi5qc29uXCIsanNvbnA6XCJjYWxsYmFja1wiLGRhdGFUeXBlOlwianNvbnBcIixzdWNjZXNzOmZ1bmN0aW9uKGEpe2Y9YS5mcmFtZWdyYWJfdXJsLGwoZil9fSl9LGUucHJvdG90eXBlLnN0b3A9ZnVuY3Rpb24oKXt0aGlzLl9jb3JlLnRyaWdnZXIoXCJzdG9wXCIsbnVsbCxcInZpZGVvXCIpLHRoaXMuX3BsYXlpbmcuZmluZChcIi5vd2wtdmlkZW8tZnJhbWVcIikucmVtb3ZlKCksdGhpcy5fcGxheWluZy5yZW1vdmVDbGFzcyhcIm93bC12aWRlby1wbGF5aW5nXCIpLHRoaXMuX3BsYXlpbmc9bnVsbCx0aGlzLl9jb3JlLmxlYXZlKFwicGxheWluZ1wiKSx0aGlzLl9jb3JlLnRyaWdnZXIoXCJzdG9wcGVkXCIsbnVsbCxcInZpZGVvXCIpfSxlLnByb3RvdHlwZS5wbGF5PWZ1bmN0aW9uKGIpe3ZhciBjLGQ9YShiLnRhcmdldCksZT1kLmNsb3Nlc3QoXCIuXCIrdGhpcy5fY29yZS5zZXR0aW5ncy5pdGVtQ2xhc3MpLGY9dGhpcy5fdmlkZW9zW2UuYXR0cihcImRhdGEtdmlkZW9cIildLGc9Zi53aWR0aHx8XCIxMDAlXCIsaD1mLmhlaWdodHx8dGhpcy5fY29yZS4kc3RhZ2UuaGVpZ2h0KCk7dGhpcy5fcGxheWluZ3x8KHRoaXMuX2NvcmUuZW50ZXIoXCJwbGF5aW5nXCIpLHRoaXMuX2NvcmUudHJpZ2dlcihcInBsYXlcIixudWxsLFwidmlkZW9cIiksZT10aGlzLl9jb3JlLml0ZW1zKHRoaXMuX2NvcmUucmVsYXRpdmUoZS5pbmRleCgpKSksdGhpcy5fY29yZS5yZXNldChlLmluZGV4KCkpLFwieW91dHViZVwiPT09Zi50eXBlP2M9JzxpZnJhbWUgd2lkdGg9XCInK2crJ1wiIGhlaWdodD1cIicraCsnXCIgc3JjPVwiLy93d3cueW91dHViZS5jb20vZW1iZWQvJytmLmlkK1wiP2F1dG9wbGF5PTEmcmVsPTAmdj1cIitmLmlkKydcIiBmcmFtZWJvcmRlcj1cIjBcIiBhbGxvd2Z1bGxzY3JlZW4+PC9pZnJhbWU+JzpcInZpbWVvXCI9PT1mLnR5cGU/Yz0nPGlmcmFtZSBzcmM9XCIvL3BsYXllci52aW1lby5jb20vdmlkZW8vJytmLmlkKyc/YXV0b3BsYXk9MVwiIHdpZHRoPVwiJytnKydcIiBoZWlnaHQ9XCInK2grJ1wiIGZyYW1lYm9yZGVyPVwiMFwiIHdlYmtpdGFsbG93ZnVsbHNjcmVlbiBtb3phbGxvd2Z1bGxzY3JlZW4gYWxsb3dmdWxsc2NyZWVuPjwvaWZyYW1lPic6XCJ2emFhclwiPT09Zi50eXBlJiYoYz0nPGlmcmFtZSBmcmFtZWJvcmRlcj1cIjBcImhlaWdodD1cIicraCsnXCJ3aWR0aD1cIicrZysnXCIgYWxsb3dmdWxsc2NyZWVuIG1vemFsbG93ZnVsbHNjcmVlbiB3ZWJraXRBbGxvd0Z1bGxTY3JlZW4gc3JjPVwiLy92aWV3LnZ6YWFyLmNvbS8nK2YuaWQrJy9wbGF5ZXI/YXV0b3BsYXk9dHJ1ZVwiPjwvaWZyYW1lPicpLGEoJzxkaXYgY2xhc3M9XCJvd2wtdmlkZW8tZnJhbWVcIj4nK2MrXCI8L2Rpdj5cIikuaW5zZXJ0QWZ0ZXIoZS5maW5kKFwiLm93bC12aWRlb1wiKSksdGhpcy5fcGxheWluZz1lLmFkZENsYXNzKFwib3dsLXZpZGVvLXBsYXlpbmdcIikpfSxlLnByb3RvdHlwZS5pc0luRnVsbFNjcmVlbj1mdW5jdGlvbigpe3ZhciBiPWMuZnVsbHNjcmVlbkVsZW1lbnR8fGMubW96RnVsbFNjcmVlbkVsZW1lbnR8fGMud2Via2l0RnVsbHNjcmVlbkVsZW1lbnQ7cmV0dXJuIGImJmEoYikucGFyZW50KCkuaGFzQ2xhc3MoXCJvd2wtdmlkZW8tZnJhbWVcIil9LGUucHJvdG90eXBlLmRlc3Ryb3k9ZnVuY3Rpb24oKXt2YXIgYSxiO3RoaXMuX2NvcmUuJGVsZW1lbnQub2ZmKFwiY2xpY2sub3dsLnZpZGVvXCIpO2ZvcihhIGluIHRoaXMuX2hhbmRsZXJzKXRoaXMuX2NvcmUuJGVsZW1lbnQub2ZmKGEsdGhpcy5faGFuZGxlcnNbYV0pO2ZvcihiIGluIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHRoaXMpKVwiZnVuY3Rpb25cIiE9dHlwZW9mIHRoaXNbYl0mJih0aGlzW2JdPW51bGwpfSxhLmZuLm93bENhcm91c2VsLkNvbnN0cnVjdG9yLlBsdWdpbnMuVmlkZW89ZX0od2luZG93LlplcHRvfHx3aW5kb3cualF1ZXJ5LHdpbmRvdyxkb2N1bWVudCksZnVuY3Rpb24oYSxiLGMsZCl7dmFyIGU9ZnVuY3Rpb24oYil7dGhpcy5jb3JlPWIsdGhpcy5jb3JlLm9wdGlvbnM9YS5leHRlbmQoe30sZS5EZWZhdWx0cyx0aGlzLmNvcmUub3B0aW9ucyksdGhpcy5zd2FwcGluZz0hMCx0aGlzLnByZXZpb3VzPWQsdGhpcy5uZXh0PWQsdGhpcy5oYW5kbGVycz17XCJjaGFuZ2Uub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmXCJwb3NpdGlvblwiPT1hLnByb3BlcnR5Lm5hbWUmJih0aGlzLnByZXZpb3VzPXRoaXMuY29yZS5jdXJyZW50KCksdGhpcy5uZXh0PWEucHJvcGVydHkudmFsdWUpfSx0aGlzKSxcImRyYWcub3dsLmNhcm91c2VsIGRyYWdnZWQub3dsLmNhcm91c2VsIHRyYW5zbGF0ZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmKHRoaXMuc3dhcHBpbmc9XCJ0cmFuc2xhdGVkXCI9PWEudHlwZSl9LHRoaXMpLFwidHJhbnNsYXRlLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJnRoaXMuc3dhcHBpbmcmJih0aGlzLmNvcmUub3B0aW9ucy5hbmltYXRlT3V0fHx0aGlzLmNvcmUub3B0aW9ucy5hbmltYXRlSW4pJiZ0aGlzLnN3YXAoKX0sdGhpcyl9LHRoaXMuY29yZS4kZWxlbWVudC5vbih0aGlzLmhhbmRsZXJzKX07ZS5EZWZhdWx0cz17YW5pbWF0ZU91dDohMSxhbmltYXRlSW46ITF9LGUucHJvdG90eXBlLnN3YXA9ZnVuY3Rpb24oKXtpZigxPT09dGhpcy5jb3JlLnNldHRpbmdzLml0ZW1zJiZhLnN1cHBvcnQuYW5pbWF0aW9uJiZhLnN1cHBvcnQudHJhbnNpdGlvbil7dGhpcy5jb3JlLnNwZWVkKDApO3ZhciBiLGM9YS5wcm94eSh0aGlzLmNsZWFyLHRoaXMpLGQ9dGhpcy5jb3JlLiRzdGFnZS5jaGlsZHJlbigpLmVxKHRoaXMucHJldmlvdXMpLGU9dGhpcy5jb3JlLiRzdGFnZS5jaGlsZHJlbigpLmVxKHRoaXMubmV4dCksZj10aGlzLmNvcmUuc2V0dGluZ3MuYW5pbWF0ZUluLGc9dGhpcy5jb3JlLnNldHRpbmdzLmFuaW1hdGVPdXQ7dGhpcy5jb3JlLmN1cnJlbnQoKSE9PXRoaXMucHJldmlvdXMmJihnJiYoYj10aGlzLmNvcmUuY29vcmRpbmF0ZXModGhpcy5wcmV2aW91cyktdGhpcy5jb3JlLmNvb3JkaW5hdGVzKHRoaXMubmV4dCksZC5vbmUoYS5zdXBwb3J0LmFuaW1hdGlvbi5lbmQsYykuY3NzKHtsZWZ0OmIrXCJweFwifSkuYWRkQ2xhc3MoXCJhbmltYXRlZCBvd2wtYW5pbWF0ZWQtb3V0XCIpLmFkZENsYXNzKGcpKSxmJiZlLm9uZShhLnN1cHBvcnQuYW5pbWF0aW9uLmVuZCxjKS5hZGRDbGFzcyhcImFuaW1hdGVkIG93bC1hbmltYXRlZC1pblwiKS5hZGRDbGFzcyhmKSl9fSxlLnByb3RvdHlwZS5jbGVhcj1mdW5jdGlvbihiKXthKGIudGFyZ2V0KS5jc3Moe2xlZnQ6XCJcIn0pLnJlbW92ZUNsYXNzKFwiYW5pbWF0ZWQgb3dsLWFuaW1hdGVkLW91dCBvd2wtYW5pbWF0ZWQtaW5cIikucmVtb3ZlQ2xhc3ModGhpcy5jb3JlLnNldHRpbmdzLmFuaW1hdGVJbikucmVtb3ZlQ2xhc3ModGhpcy5jb3JlLnNldHRpbmdzLmFuaW1hdGVPdXQpLHRoaXMuY29yZS5vblRyYW5zaXRpb25FbmQoKX0sZS5wcm90b3R5cGUuZGVzdHJveT1mdW5jdGlvbigpe3ZhciBhLGI7Zm9yKGEgaW4gdGhpcy5oYW5kbGVycyl0aGlzLmNvcmUuJGVsZW1lbnQub2ZmKGEsdGhpcy5oYW5kbGVyc1thXSk7Zm9yKGIgaW4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGhpcykpXCJmdW5jdGlvblwiIT10eXBlb2YgdGhpc1tiXSYmKHRoaXNbYl09bnVsbCl9LFxuYS5mbi5vd2xDYXJvdXNlbC5Db25zdHJ1Y3Rvci5QbHVnaW5zLkFuaW1hdGU9ZX0od2luZG93LlplcHRvfHx3aW5kb3cualF1ZXJ5LHdpbmRvdyxkb2N1bWVudCksZnVuY3Rpb24oYSxiLGMsZCl7dmFyIGU9ZnVuY3Rpb24oYil7dGhpcy5fY29yZT1iLHRoaXMuX3RpbWVvdXQ9bnVsbCx0aGlzLl9wYXVzZWQ9ITEsdGhpcy5faGFuZGxlcnM9e1wiY2hhbmdlZC5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiZcInNldHRpbmdzXCI9PT1hLnByb3BlcnR5Lm5hbWU/dGhpcy5fY29yZS5zZXR0aW5ncy5hdXRvcGxheT90aGlzLnBsYXkoKTp0aGlzLnN0b3AoKTphLm5hbWVzcGFjZSYmXCJwb3NpdGlvblwiPT09YS5wcm9wZXJ0eS5uYW1lJiZ0aGlzLl9jb3JlLnNldHRpbmdzLmF1dG9wbGF5JiZ0aGlzLl9zZXRBdXRvUGxheUludGVydmFsKCl9LHRoaXMpLFwiaW5pdGlhbGl6ZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmdGhpcy5fY29yZS5zZXR0aW5ncy5hdXRvcGxheSYmdGhpcy5wbGF5KCl9LHRoaXMpLFwicGxheS5vd2wuYXV0b3BsYXlcIjphLnByb3h5KGZ1bmN0aW9uKGEsYixjKXthLm5hbWVzcGFjZSYmdGhpcy5wbGF5KGIsYyl9LHRoaXMpLFwic3RvcC5vd2wuYXV0b3BsYXlcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiZ0aGlzLnN0b3AoKX0sdGhpcyksXCJtb3VzZW92ZXIub3dsLmF1dG9wbGF5XCI6YS5wcm94eShmdW5jdGlvbigpe3RoaXMuX2NvcmUuc2V0dGluZ3MuYXV0b3BsYXlIb3ZlclBhdXNlJiZ0aGlzLl9jb3JlLmlzKFwicm90YXRpbmdcIikmJnRoaXMucGF1c2UoKX0sdGhpcyksXCJtb3VzZWxlYXZlLm93bC5hdXRvcGxheVwiOmEucHJveHkoZnVuY3Rpb24oKXt0aGlzLl9jb3JlLnNldHRpbmdzLmF1dG9wbGF5SG92ZXJQYXVzZSYmdGhpcy5fY29yZS5pcyhcInJvdGF0aW5nXCIpJiZ0aGlzLnBsYXkoKX0sdGhpcyksXCJ0b3VjaHN0YXJ0Lm93bC5jb3JlXCI6YS5wcm94eShmdW5jdGlvbigpe3RoaXMuX2NvcmUuc2V0dGluZ3MuYXV0b3BsYXlIb3ZlclBhdXNlJiZ0aGlzLl9jb3JlLmlzKFwicm90YXRpbmdcIikmJnRoaXMucGF1c2UoKX0sdGhpcyksXCJ0b3VjaGVuZC5vd2wuY29yZVwiOmEucHJveHkoZnVuY3Rpb24oKXt0aGlzLl9jb3JlLnNldHRpbmdzLmF1dG9wbGF5SG92ZXJQYXVzZSYmdGhpcy5wbGF5KCl9LHRoaXMpfSx0aGlzLl9jb3JlLiRlbGVtZW50Lm9uKHRoaXMuX2hhbmRsZXJzKSx0aGlzLl9jb3JlLm9wdGlvbnM9YS5leHRlbmQoe30sZS5EZWZhdWx0cyx0aGlzLl9jb3JlLm9wdGlvbnMpfTtlLkRlZmF1bHRzPXthdXRvcGxheTohMSxhdXRvcGxheVRpbWVvdXQ6NWUzLGF1dG9wbGF5SG92ZXJQYXVzZTohMSxhdXRvcGxheVNwZWVkOiExfSxlLnByb3RvdHlwZS5wbGF5PWZ1bmN0aW9uKGEsYil7dGhpcy5fcGF1c2VkPSExLHRoaXMuX2NvcmUuaXMoXCJyb3RhdGluZ1wiKXx8KHRoaXMuX2NvcmUuZW50ZXIoXCJyb3RhdGluZ1wiKSx0aGlzLl9zZXRBdXRvUGxheUludGVydmFsKCkpfSxlLnByb3RvdHlwZS5fZ2V0TmV4dFRpbWVvdXQ9ZnVuY3Rpb24oZCxlKXtyZXR1cm4gdGhpcy5fdGltZW91dCYmYi5jbGVhclRpbWVvdXQodGhpcy5fdGltZW91dCksYi5zZXRUaW1lb3V0KGEucHJveHkoZnVuY3Rpb24oKXt0aGlzLl9wYXVzZWR8fHRoaXMuX2NvcmUuaXMoXCJidXN5XCIpfHx0aGlzLl9jb3JlLmlzKFwiaW50ZXJhY3RpbmdcIil8fGMuaGlkZGVufHx0aGlzLl9jb3JlLm5leHQoZXx8dGhpcy5fY29yZS5zZXR0aW5ncy5hdXRvcGxheVNwZWVkKX0sdGhpcyksZHx8dGhpcy5fY29yZS5zZXR0aW5ncy5hdXRvcGxheVRpbWVvdXQpfSxlLnByb3RvdHlwZS5fc2V0QXV0b1BsYXlJbnRlcnZhbD1mdW5jdGlvbigpe3RoaXMuX3RpbWVvdXQ9dGhpcy5fZ2V0TmV4dFRpbWVvdXQoKX0sZS5wcm90b3R5cGUuc3RvcD1mdW5jdGlvbigpe3RoaXMuX2NvcmUuaXMoXCJyb3RhdGluZ1wiKSYmKGIuY2xlYXJUaW1lb3V0KHRoaXMuX3RpbWVvdXQpLHRoaXMuX2NvcmUubGVhdmUoXCJyb3RhdGluZ1wiKSl9LGUucHJvdG90eXBlLnBhdXNlPWZ1bmN0aW9uKCl7dGhpcy5fY29yZS5pcyhcInJvdGF0aW5nXCIpJiYodGhpcy5fcGF1c2VkPSEwKX0sZS5wcm90b3R5cGUuZGVzdHJveT1mdW5jdGlvbigpe3ZhciBhLGI7dGhpcy5zdG9wKCk7Zm9yKGEgaW4gdGhpcy5faGFuZGxlcnMpdGhpcy5fY29yZS4kZWxlbWVudC5vZmYoYSx0aGlzLl9oYW5kbGVyc1thXSk7Zm9yKGIgaW4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGhpcykpXCJmdW5jdGlvblwiIT10eXBlb2YgdGhpc1tiXSYmKHRoaXNbYl09bnVsbCl9LGEuZm4ub3dsQ2Fyb3VzZWwuQ29uc3RydWN0b3IuUGx1Z2lucy5hdXRvcGxheT1lfSh3aW5kb3cuWmVwdG98fHdpbmRvdy5qUXVlcnksd2luZG93LGRvY3VtZW50KSxmdW5jdGlvbihhLGIsYyxkKXtcInVzZSBzdHJpY3RcIjt2YXIgZT1mdW5jdGlvbihiKXt0aGlzLl9jb3JlPWIsdGhpcy5faW5pdGlhbGl6ZWQ9ITEsdGhpcy5fcGFnZXM9W10sdGhpcy5fY29udHJvbHM9e30sdGhpcy5fdGVtcGxhdGVzPVtdLHRoaXMuJGVsZW1lbnQ9dGhpcy5fY29yZS4kZWxlbWVudCx0aGlzLl9vdmVycmlkZXM9e25leHQ6dGhpcy5fY29yZS5uZXh0LHByZXY6dGhpcy5fY29yZS5wcmV2LHRvOnRoaXMuX2NvcmUudG99LHRoaXMuX2hhbmRsZXJzPXtcInByZXBhcmVkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYil7Yi5uYW1lc3BhY2UmJnRoaXMuX2NvcmUuc2V0dGluZ3MuZG90c0RhdGEmJnRoaXMuX3RlbXBsYXRlcy5wdXNoKCc8ZGl2IGNsYXNzPVwiJyt0aGlzLl9jb3JlLnNldHRpbmdzLmRvdENsYXNzKydcIj4nK2EoYi5jb250ZW50KS5maW5kKFwiW2RhdGEtZG90XVwiKS5hZGRCYWNrKFwiW2RhdGEtZG90XVwiKS5hdHRyKFwiZGF0YS1kb3RcIikrXCI8L2Rpdj5cIil9LHRoaXMpLFwiYWRkZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmdGhpcy5fY29yZS5zZXR0aW5ncy5kb3RzRGF0YSYmdGhpcy5fdGVtcGxhdGVzLnNwbGljZShhLnBvc2l0aW9uLDAsdGhpcy5fdGVtcGxhdGVzLnBvcCgpKX0sdGhpcyksXCJyZW1vdmUub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmdGhpcy5fY29yZS5zZXR0aW5ncy5kb3RzRGF0YSYmdGhpcy5fdGVtcGxhdGVzLnNwbGljZShhLnBvc2l0aW9uLDEpfSx0aGlzKSxcImNoYW5nZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmXCJwb3NpdGlvblwiPT1hLnByb3BlcnR5Lm5hbWUmJnRoaXMuZHJhdygpfSx0aGlzKSxcImluaXRpYWxpemVkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJiF0aGlzLl9pbml0aWFsaXplZCYmKHRoaXMuX2NvcmUudHJpZ2dlcihcImluaXRpYWxpemVcIixudWxsLFwibmF2aWdhdGlvblwiKSx0aGlzLmluaXRpYWxpemUoKSx0aGlzLnVwZGF0ZSgpLHRoaXMuZHJhdygpLHRoaXMuX2luaXRpYWxpemVkPSEwLHRoaXMuX2NvcmUudHJpZ2dlcihcImluaXRpYWxpemVkXCIsbnVsbCxcIm5hdmlnYXRpb25cIikpfSx0aGlzKSxcInJlZnJlc2hlZC5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiZ0aGlzLl9pbml0aWFsaXplZCYmKHRoaXMuX2NvcmUudHJpZ2dlcihcInJlZnJlc2hcIixudWxsLFwibmF2aWdhdGlvblwiKSx0aGlzLnVwZGF0ZSgpLHRoaXMuZHJhdygpLHRoaXMuX2NvcmUudHJpZ2dlcihcInJlZnJlc2hlZFwiLG51bGwsXCJuYXZpZ2F0aW9uXCIpKX0sdGhpcyl9LHRoaXMuX2NvcmUub3B0aW9ucz1hLmV4dGVuZCh7fSxlLkRlZmF1bHRzLHRoaXMuX2NvcmUub3B0aW9ucyksdGhpcy4kZWxlbWVudC5vbih0aGlzLl9oYW5kbGVycyl9O2UuRGVmYXVsdHM9e25hdjohMSxuYXZUZXh0OltcInByZXZcIixcIm5leHRcIl0sbmF2U3BlZWQ6ITEsbmF2RWxlbWVudDpcImRpdlwiLG5hdkNvbnRhaW5lcjohMSxuYXZDb250YWluZXJDbGFzczpcIm93bC1uYXZcIixuYXZDbGFzczpbXCJvd2wtcHJldlwiLFwib3dsLW5leHRcIl0sc2xpZGVCeToxLGRvdENsYXNzOlwib3dsLWRvdFwiLGRvdHNDbGFzczpcIm93bC1kb3RzXCIsZG90czohMCxkb3RzRWFjaDohMSxkb3RzRGF0YTohMSxkb3RzU3BlZWQ6ITEsZG90c0NvbnRhaW5lcjohMX0sZS5wcm90b3R5cGUuaW5pdGlhbGl6ZT1mdW5jdGlvbigpe3ZhciBiLGM9dGhpcy5fY29yZS5zZXR0aW5nczt0aGlzLl9jb250cm9scy4kcmVsYXRpdmU9KGMubmF2Q29udGFpbmVyP2EoYy5uYXZDb250YWluZXIpOmEoXCI8ZGl2PlwiKS5hZGRDbGFzcyhjLm5hdkNvbnRhaW5lckNsYXNzKS5hcHBlbmRUbyh0aGlzLiRlbGVtZW50KSkuYWRkQ2xhc3MoXCJkaXNhYmxlZFwiKSx0aGlzLl9jb250cm9scy4kcHJldmlvdXM9YShcIjxcIitjLm5hdkVsZW1lbnQrXCI+XCIpLmFkZENsYXNzKGMubmF2Q2xhc3NbMF0pLmh0bWwoYy5uYXZUZXh0WzBdKS5wcmVwZW5kVG8odGhpcy5fY29udHJvbHMuJHJlbGF0aXZlKS5vbihcImNsaWNrXCIsYS5wcm94eShmdW5jdGlvbihhKXt0aGlzLnByZXYoYy5uYXZTcGVlZCl9LHRoaXMpKSx0aGlzLl9jb250cm9scy4kbmV4dD1hKFwiPFwiK2MubmF2RWxlbWVudCtcIj5cIikuYWRkQ2xhc3MoYy5uYXZDbGFzc1sxXSkuaHRtbChjLm5hdlRleHRbMV0pLmFwcGVuZFRvKHRoaXMuX2NvbnRyb2xzLiRyZWxhdGl2ZSkub24oXCJjbGlja1wiLGEucHJveHkoZnVuY3Rpb24oYSl7dGhpcy5uZXh0KGMubmF2U3BlZWQpfSx0aGlzKSksYy5kb3RzRGF0YXx8KHRoaXMuX3RlbXBsYXRlcz1bYShcIjxkaXY+XCIpLmFkZENsYXNzKGMuZG90Q2xhc3MpLmFwcGVuZChhKFwiPHNwYW4+XCIpKS5wcm9wKFwib3V0ZXJIVE1MXCIpXSksdGhpcy5fY29udHJvbHMuJGFic29sdXRlPShjLmRvdHNDb250YWluZXI/YShjLmRvdHNDb250YWluZXIpOmEoXCI8ZGl2PlwiKS5hZGRDbGFzcyhjLmRvdHNDbGFzcykuYXBwZW5kVG8odGhpcy4kZWxlbWVudCkpLmFkZENsYXNzKFwiZGlzYWJsZWRcIiksdGhpcy5fY29udHJvbHMuJGFic29sdXRlLm9uKFwiY2xpY2tcIixcImRpdlwiLGEucHJveHkoZnVuY3Rpb24oYil7dmFyIGQ9YShiLnRhcmdldCkucGFyZW50KCkuaXModGhpcy5fY29udHJvbHMuJGFic29sdXRlKT9hKGIudGFyZ2V0KS5pbmRleCgpOmEoYi50YXJnZXQpLnBhcmVudCgpLmluZGV4KCk7Yi5wcmV2ZW50RGVmYXVsdCgpLHRoaXMudG8oZCxjLmRvdHNTcGVlZCl9LHRoaXMpKTtmb3IoYiBpbiB0aGlzLl9vdmVycmlkZXMpdGhpcy5fY29yZVtiXT1hLnByb3h5KHRoaXNbYl0sdGhpcyl9LGUucHJvdG90eXBlLmRlc3Ryb3k9ZnVuY3Rpb24oKXt2YXIgYSxiLGMsZDtmb3IoYSBpbiB0aGlzLl9oYW5kbGVycyl0aGlzLiRlbGVtZW50Lm9mZihhLHRoaXMuX2hhbmRsZXJzW2FdKTtmb3IoYiBpbiB0aGlzLl9jb250cm9scyl0aGlzLl9jb250cm9sc1tiXS5yZW1vdmUoKTtmb3IoZCBpbiB0aGlzLm92ZXJpZGVzKXRoaXMuX2NvcmVbZF09dGhpcy5fb3ZlcnJpZGVzW2RdO2ZvcihjIGluIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHRoaXMpKVwiZnVuY3Rpb25cIiE9dHlwZW9mIHRoaXNbY10mJih0aGlzW2NdPW51bGwpfSxlLnByb3RvdHlwZS51cGRhdGU9ZnVuY3Rpb24oKXt2YXIgYSxiLGMsZD10aGlzLl9jb3JlLmNsb25lcygpLmxlbmd0aC8yLGU9ZCt0aGlzLl9jb3JlLml0ZW1zKCkubGVuZ3RoLGY9dGhpcy5fY29yZS5tYXhpbXVtKCEwKSxnPXRoaXMuX2NvcmUuc2V0dGluZ3MsaD1nLmNlbnRlcnx8Zy5hdXRvV2lkdGh8fGcuZG90c0RhdGE/MTpnLmRvdHNFYWNofHxnLml0ZW1zO2lmKFwicGFnZVwiIT09Zy5zbGlkZUJ5JiYoZy5zbGlkZUJ5PU1hdGgubWluKGcuc2xpZGVCeSxnLml0ZW1zKSksZy5kb3RzfHxcInBhZ2VcIj09Zy5zbGlkZUJ5KWZvcih0aGlzLl9wYWdlcz1bXSxhPWQsYj0wLGM9MDthPGU7YSsrKXtpZihiPj1ofHwwPT09Yil7aWYodGhpcy5fcGFnZXMucHVzaCh7c3RhcnQ6TWF0aC5taW4oZixhLWQpLGVuZDphLWQraC0xfSksTWF0aC5taW4oZixhLWQpPT09ZilicmVhaztiPTAsKytjfWIrPXRoaXMuX2NvcmUubWVyZ2Vycyh0aGlzLl9jb3JlLnJlbGF0aXZlKGEpKX19LGUucHJvdG90eXBlLmRyYXc9ZnVuY3Rpb24oKXt2YXIgYixjPXRoaXMuX2NvcmUuc2V0dGluZ3MsZD10aGlzLl9jb3JlLml0ZW1zKCkubGVuZ3RoPD1jLml0ZW1zLGU9dGhpcy5fY29yZS5yZWxhdGl2ZSh0aGlzLl9jb3JlLmN1cnJlbnQoKSksZj1jLmxvb3B8fGMucmV3aW5kO3RoaXMuX2NvbnRyb2xzLiRyZWxhdGl2ZS50b2dnbGVDbGFzcyhcImRpc2FibGVkXCIsIWMubmF2fHxkKSxjLm5hdiYmKHRoaXMuX2NvbnRyb2xzLiRwcmV2aW91cy50b2dnbGVDbGFzcyhcImRpc2FibGVkXCIsIWYmJmU8PXRoaXMuX2NvcmUubWluaW11bSghMCkpLHRoaXMuX2NvbnRyb2xzLiRuZXh0LnRvZ2dsZUNsYXNzKFwiZGlzYWJsZWRcIiwhZiYmZT49dGhpcy5fY29yZS5tYXhpbXVtKCEwKSkpLHRoaXMuX2NvbnRyb2xzLiRhYnNvbHV0ZS50b2dnbGVDbGFzcyhcImRpc2FibGVkXCIsIWMuZG90c3x8ZCksYy5kb3RzJiYoYj10aGlzLl9wYWdlcy5sZW5ndGgtdGhpcy5fY29udHJvbHMuJGFic29sdXRlLmNoaWxkcmVuKCkubGVuZ3RoLGMuZG90c0RhdGEmJjAhPT1iP3RoaXMuX2NvbnRyb2xzLiRhYnNvbHV0ZS5odG1sKHRoaXMuX3RlbXBsYXRlcy5qb2luKFwiXCIpKTpiPjA/dGhpcy5fY29udHJvbHMuJGFic29sdXRlLmFwcGVuZChuZXcgQXJyYXkoYisxKS5qb2luKHRoaXMuX3RlbXBsYXRlc1swXSkpOmI8MCYmdGhpcy5fY29udHJvbHMuJGFic29sdXRlLmNoaWxkcmVuKCkuc2xpY2UoYikucmVtb3ZlKCksdGhpcy5fY29udHJvbHMuJGFic29sdXRlLmZpbmQoXCIuYWN0aXZlXCIpLnJlbW92ZUNsYXNzKFwiYWN0aXZlXCIpLHRoaXMuX2NvbnRyb2xzLiRhYnNvbHV0ZS5jaGlsZHJlbigpLmVxKGEuaW5BcnJheSh0aGlzLmN1cnJlbnQoKSx0aGlzLl9wYWdlcykpLmFkZENsYXNzKFwiYWN0aXZlXCIpKX0sZS5wcm90b3R5cGUub25UcmlnZ2VyPWZ1bmN0aW9uKGIpe3ZhciBjPXRoaXMuX2NvcmUuc2V0dGluZ3M7Yi5wYWdlPXtpbmRleDphLmluQXJyYXkodGhpcy5jdXJyZW50KCksdGhpcy5fcGFnZXMpLGNvdW50OnRoaXMuX3BhZ2VzLmxlbmd0aCxzaXplOmMmJihjLmNlbnRlcnx8Yy5hdXRvV2lkdGh8fGMuZG90c0RhdGE/MTpjLmRvdHNFYWNofHxjLml0ZW1zKX19LGUucHJvdG90eXBlLmN1cnJlbnQ9ZnVuY3Rpb24oKXt2YXIgYj10aGlzLl9jb3JlLnJlbGF0aXZlKHRoaXMuX2NvcmUuY3VycmVudCgpKTtyZXR1cm4gYS5ncmVwKHRoaXMuX3BhZ2VzLGEucHJveHkoZnVuY3Rpb24oYSxjKXtyZXR1cm4gYS5zdGFydDw9YiYmYS5lbmQ+PWJ9LHRoaXMpKS5wb3AoKX0sZS5wcm90b3R5cGUuZ2V0UG9zaXRpb249ZnVuY3Rpb24oYil7dmFyIGMsZCxlPXRoaXMuX2NvcmUuc2V0dGluZ3M7cmV0dXJuXCJwYWdlXCI9PWUuc2xpZGVCeT8oYz1hLmluQXJyYXkodGhpcy5jdXJyZW50KCksdGhpcy5fcGFnZXMpLGQ9dGhpcy5fcGFnZXMubGVuZ3RoLGI/KytjOi0tYyxjPXRoaXMuX3BhZ2VzWyhjJWQrZCklZF0uc3RhcnQpOihjPXRoaXMuX2NvcmUucmVsYXRpdmUodGhpcy5fY29yZS5jdXJyZW50KCkpLGQ9dGhpcy5fY29yZS5pdGVtcygpLmxlbmd0aCxiP2MrPWUuc2xpZGVCeTpjLT1lLnNsaWRlQnkpLGN9LGUucHJvdG90eXBlLm5leHQ9ZnVuY3Rpb24oYil7YS5wcm94eSh0aGlzLl9vdmVycmlkZXMudG8sdGhpcy5fY29yZSkodGhpcy5nZXRQb3NpdGlvbighMCksYil9LGUucHJvdG90eXBlLnByZXY9ZnVuY3Rpb24oYil7YS5wcm94eSh0aGlzLl9vdmVycmlkZXMudG8sdGhpcy5fY29yZSkodGhpcy5nZXRQb3NpdGlvbighMSksYil9LGUucHJvdG90eXBlLnRvPWZ1bmN0aW9uKGIsYyxkKXt2YXIgZTshZCYmdGhpcy5fcGFnZXMubGVuZ3RoPyhlPXRoaXMuX3BhZ2VzLmxlbmd0aCxhLnByb3h5KHRoaXMuX292ZXJyaWRlcy50byx0aGlzLl9jb3JlKSh0aGlzLl9wYWdlc1soYiVlK2UpJWVdLnN0YXJ0LGMpKTphLnByb3h5KHRoaXMuX292ZXJyaWRlcy50byx0aGlzLl9jb3JlKShiLGMpfSxhLmZuLm93bENhcm91c2VsLkNvbnN0cnVjdG9yLlBsdWdpbnMuTmF2aWdhdGlvbj1lfSh3aW5kb3cuWmVwdG98fHdpbmRvdy5qUXVlcnksd2luZG93LGRvY3VtZW50KSxmdW5jdGlvbihhLGIsYyxkKXtcInVzZSBzdHJpY3RcIjt2YXIgZT1mdW5jdGlvbihjKXt0aGlzLl9jb3JlPWMsdGhpcy5faGFzaGVzPXt9LHRoaXMuJGVsZW1lbnQ9dGhpcy5fY29yZS4kZWxlbWVudCx0aGlzLl9oYW5kbGVycz17XCJpbml0aWFsaXplZC5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGMpe2MubmFtZXNwYWNlJiZcIlVSTEhhc2hcIj09PXRoaXMuX2NvcmUuc2V0dGluZ3Muc3RhcnRQb3NpdGlvbiYmYShiKS50cmlnZ2VyKFwiaGFzaGNoYW5nZS5vd2wubmF2aWdhdGlvblwiKX0sdGhpcyksXCJwcmVwYXJlZC5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGIpe2lmKGIubmFtZXNwYWNlKXt2YXIgYz1hKGIuY29udGVudCkuZmluZChcIltkYXRhLWhhc2hdXCIpLmFkZEJhY2soXCJbZGF0YS1oYXNoXVwiKS5hdHRyKFwiZGF0YS1oYXNoXCIpO2lmKCFjKXJldHVybjt0aGlzLl9oYXNoZXNbY109Yi5jb250ZW50fX0sdGhpcyksXCJjaGFuZ2VkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYyl7aWYoYy5uYW1lc3BhY2UmJlwicG9zaXRpb25cIj09PWMucHJvcGVydHkubmFtZSl7dmFyIGQ9dGhpcy5fY29yZS5pdGVtcyh0aGlzLl9jb3JlLnJlbGF0aXZlKHRoaXMuX2NvcmUuY3VycmVudCgpKSksZT1hLm1hcCh0aGlzLl9oYXNoZXMsZnVuY3Rpb24oYSxiKXtyZXR1cm4gYT09PWQ/YjpudWxsfSkuam9pbigpO2lmKCFlfHxiLmxvY2F0aW9uLmhhc2guc2xpY2UoMSk9PT1lKXJldHVybjtiLmxvY2F0aW9uLmhhc2g9ZX19LHRoaXMpfSx0aGlzLl9jb3JlLm9wdGlvbnM9YS5leHRlbmQoe30sZS5EZWZhdWx0cyx0aGlzLl9jb3JlLm9wdGlvbnMpLHRoaXMuJGVsZW1lbnQub24odGhpcy5faGFuZGxlcnMpLGEoYikub24oXCJoYXNoY2hhbmdlLm93bC5uYXZpZ2F0aW9uXCIsYS5wcm94eShmdW5jdGlvbihhKXt2YXIgYz1iLmxvY2F0aW9uLmhhc2guc3Vic3RyaW5nKDEpLGU9dGhpcy5fY29yZS4kc3RhZ2UuY2hpbGRyZW4oKSxmPXRoaXMuX2hhc2hlc1tjXSYmZS5pbmRleCh0aGlzLl9oYXNoZXNbY10pO2YhPT1kJiZmIT09dGhpcy5fY29yZS5jdXJyZW50KCkmJnRoaXMuX2NvcmUudG8odGhpcy5fY29yZS5yZWxhdGl2ZShmKSwhMSwhMCl9LHRoaXMpKX07ZS5EZWZhdWx0cz17VVJMaGFzaExpc3RlbmVyOiExfSxlLnByb3RvdHlwZS5kZXN0cm95PWZ1bmN0aW9uKCl7dmFyIGMsZDthKGIpLm9mZihcImhhc2hjaGFuZ2Uub3dsLm5hdmlnYXRpb25cIik7Zm9yKGMgaW4gdGhpcy5faGFuZGxlcnMpdGhpcy5fY29yZS4kZWxlbWVudC5vZmYoYyx0aGlzLl9oYW5kbGVyc1tjXSk7Zm9yKGQgaW4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGhpcykpXCJmdW5jdGlvblwiIT10eXBlb2YgdGhpc1tkXSYmKHRoaXNbZF09bnVsbCl9LGEuZm4ub3dsQ2Fyb3VzZWwuQ29uc3RydWN0b3IuUGx1Z2lucy5IYXNoPWV9KHdpbmRvdy5aZXB0b3x8d2luZG93LmpRdWVyeSx3aW5kb3csZG9jdW1lbnQpLGZ1bmN0aW9uKGEsYixjLGQpe2Z1bmN0aW9uIGUoYixjKXt2YXIgZT0hMSxmPWIuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkrYi5zbGljZSgxKTtyZXR1cm4gYS5lYWNoKChiK1wiIFwiK2guam9pbihmK1wiIFwiKStmKS5zcGxpdChcIiBcIiksZnVuY3Rpb24oYSxiKXtpZihnW2JdIT09ZClyZXR1cm4gZT0hY3x8YiwhMX0pLGV9ZnVuY3Rpb24gZihhKXtyZXR1cm4gZShhLCEwKX12YXIgZz1hKFwiPHN1cHBvcnQ+XCIpLmdldCgwKS5zdHlsZSxoPVwiV2Via2l0IE1veiBPIG1zXCIuc3BsaXQoXCIgXCIpLGk9e3RyYW5zaXRpb246e2VuZDp7V2Via2l0VHJhbnNpdGlvbjpcIndlYmtpdFRyYW5zaXRpb25FbmRcIixNb3pUcmFuc2l0aW9uOlwidHJhbnNpdGlvbmVuZFwiLE9UcmFuc2l0aW9uOlwib1RyYW5zaXRpb25FbmRcIix0cmFuc2l0aW9uOlwidHJhbnNpdGlvbmVuZFwifX0sYW5pbWF0aW9uOntlbmQ6e1dlYmtpdEFuaW1hdGlvbjpcIndlYmtpdEFuaW1hdGlvbkVuZFwiLE1vekFuaW1hdGlvbjpcImFuaW1hdGlvbmVuZFwiLE9BbmltYXRpb246XCJvQW5pbWF0aW9uRW5kXCIsYW5pbWF0aW9uOlwiYW5pbWF0aW9uZW5kXCJ9fX0saj17Y3NzdHJhbnNmb3JtczpmdW5jdGlvbigpe3JldHVybiEhZShcInRyYW5zZm9ybVwiKX0sY3NzdHJhbnNmb3JtczNkOmZ1bmN0aW9uKCl7cmV0dXJuISFlKFwicGVyc3BlY3RpdmVcIil9LGNzc3RyYW5zaXRpb25zOmZ1bmN0aW9uKCl7cmV0dXJuISFlKFwidHJhbnNpdGlvblwiKX0sY3NzYW5pbWF0aW9uczpmdW5jdGlvbigpe3JldHVybiEhZShcImFuaW1hdGlvblwiKX19O2ouY3NzdHJhbnNpdGlvbnMoKSYmKGEuc3VwcG9ydC50cmFuc2l0aW9uPW5ldyBTdHJpbmcoZihcInRyYW5zaXRpb25cIikpLGEuc3VwcG9ydC50cmFuc2l0aW9uLmVuZD1pLnRyYW5zaXRpb24uZW5kW2Euc3VwcG9ydC50cmFuc2l0aW9uXSksai5jc3NhbmltYXRpb25zKCkmJihhLnN1cHBvcnQuYW5pbWF0aW9uPW5ldyBTdHJpbmcoZihcImFuaW1hdGlvblwiKSksYS5zdXBwb3J0LmFuaW1hdGlvbi5lbmQ9aS5hbmltYXRpb24uZW5kW2Euc3VwcG9ydC5hbmltYXRpb25dKSxqLmNzc3RyYW5zZm9ybXMoKSYmKGEuc3VwcG9ydC50cmFuc2Zvcm09bmV3IFN0cmluZyhmKFwidHJhbnNmb3JtXCIpKSxhLnN1cHBvcnQudHJhbnNmb3JtM2Q9ai5jc3N0cmFuc2Zvcm1zM2QoKSl9KHdpbmRvdy5aZXB0b3x8d2luZG93LmpRdWVyeSx3aW5kb3csZG9jdW1lbnQpOyIsInZhciByb290VXJsID0gd2luZG93LmxvY2F0aW9uLm9yaWdpbjtcbnZhciB0ZW1wbGF0ZVVybCA9IHRoZW1lVXJsLnRlbXBsYXRlVXJsO1xuLy8gY29uc29sZS5sb2codGVtcGxhdGVVcmwpO1xuaWYocm9vdFVybCA9PT0gXCJodHRwOi8vbG9jYWxob3N0OjMwMDBcIiB8fCByb290VXJsID09PSBcImh0dHA6Ly9sb2NhbGhvc3Q6ODg4OFwiKSB7XG4gIHJvb3RVcmwgPSByb290VXJsICsgXCIvd2VzdHRvdXJzL1wiO1xufWVsc2V7XG4gIHJvb3RVcmwgPSB3aW5kb3cubG9jYXRpb24ub3JpZ2luO1xufVxuIiwiLy8gLy9cbi8vIHZhciByb290VXJsID0gd2luZG93LmxvY2F0aW9uLm9yaWdpbjtcbi8vIGlmKHJvb3RVcmwgPT09IFwiaHR0cDovL2xvY2FsaG9zdDozMDAwXCIgfHwgcm9vdFVybCA9PT0gXCJodHRwOi8vbG9jYWxob3N0Ojg4ODhcIikge1xuLy8gICByb290VXJsID0gcm9vdFVybCArIFwiL3dlc3R0b3Vycy9cIjtcbi8vIH1lbHNle1xuLy8gICByb290VXJsID0gXCJ0ZXN0XCIrd2luZG93LmxvY2F0aW9uLm9yaWdpbjtcbi8vIH1cbi8vXG4vLyB2YXIgY2F0ZWdvcmllcyA9IHJvb3RVcmwrXCIvd3AtanNvbi93cC92Mi9jYXRlZ29yaWVzP3Blcl9wYWdlPTUwXCI7XG4vLyB2YXIgYmlrZVRvdXJzSHR0cCA9IHJvb3RVcmwrXCIvd3AtanNvbi93cC92Mi90b3VyX3Bvc3RfdHlwZT9wZXJfcGFnZT01MFwiO1xuLy8gdmFyIGN1c3RvbVRlc3QgPSByb290VXJsK1wiL3dwLWpzb24vd3AvdjIvY3VzdG9tX2FwaVwiO1xuLy8gdmFyIG1lZGlhID0gcm9vdFVybCtcIi93cC1qc29uL3dwL3YyL21lZGlhP3Blcl9wYWdlPTUwXCI7XG4vL1xuLy8gY29uc29sZS5sb2cocm9vdFVybCk7XG4vLyB2YXIgY2F0ZWdvcnkgPSBbXTtcbi8vXG4vLyBmdW5jdGlvbiBzaHVmZmxlIChhcnJheSkge1xuLy8gICB2YXIgaSA9IDA7XG4vLyAgIHZhciBqID0gMDtcbi8vICAgdmFyIHRlbXAgPSBudWxsO1xuLy9cbi8vICAgZm9yIChpID0gYXJyYXkubGVuZ3RoIC0gMTsgaSA+IDA7IGkgLT0gMSkge1xuLy8gICAgIGogPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAoaSArIDEpKTtcbi8vICAgICB0ZW1wID0gYXJyYXlbaV07XG4vLyAgICAgYXJyYXlbaV0gPSBhcnJheVtqXTtcbi8vICAgICBhcnJheVtqXSA9IHRlbXA7XG4vLyAgIH1cbi8vIH1cbi8vICQuZ2V0SlNPTihjYXRlZ29yaWVzLCBmdW5jdGlvbihyZXN1bHQpe1xuLy8gY2F0ZWdvcnkgPSByZXN1bHQ7XG4vLyAvLyBjb25zb2xlLmxvZyhjYXRlZ29yeSk7XG4vLyB9KTtcbi8vXG4vLyB2YXIgbWVkaWFPYmogPVtdO1xuLy8gJC5nZXRKU09OKG1lZGlhLCBmdW5jdGlvbihyZXN1bHQpe1xuLy8gbWVkaWFPYmogPSByZXN1bHQ7XG4vLyB9KTtcbi8vIC8vIEpTT05nZXR0ZXIgaXMgYSB3YXkgZm9yIG11bHRpcGxlIGN1c3RvbSBwb3N0IGNhbGxzIGZyb20gdGhlIHdwIHJlc3Rcbi8vIHZhciBKU09OZ2V0dGVyID0gZnVuY3Rpb24oaHR0cCwgcmVzdWx0bmFtZSl7XG4vLyAgICQuZ2V0SlNPTihodHRwLCBmdW5jdGlvbihyZXN1bHRuYW1lKXtcbi8vICAgICB2YXIgcG9wdWxhciA9IFtdO1xuLy8gICAgIHZhciBzbWFsbENhcmRzID0gW107XG4vLyAgICAgJC5lYWNoKHJlc3VsdG5hbWUsIGZ1bmN0aW9uKGksIGZpZWxkKXtcbi8vICAgICAgIGlmIChmaWVsZC5hY2YuaXNfcG9wdWxhcikge1xuLy8gICAgICAgICBwb3B1bGFyLnB1c2goZmllbGQpO1xuLy8gICAgICAgfVxuLy8gICAgICAgc21hbGxDYXJkcy5wdXNoKGZpZWxkKTtcbi8vICAgICAgIC8vICBjb25zb2xlLmxvZyhmaWVsZCk7XG4vL1xuLy8gICAgICB2YXIgb3B0aW9uID0gXCI8b3B0aW9uIHZhbHVlPSdcIitmaWVsZC50aXRsZS5yZW5kZXJlZCtcIiBcIitmaWVsZC5hY2YuYWN0aXZldHkrXCInPjxwPlwiK2ZpZWxkLnRpdGxlLnJlbmRlcmVkK1wiPC9wPiAgIDxwPlwiK2ZpZWxkLmFjZi5hY3RpdmV0eStcIjwvcD48L29wdGlvbj5cIjtcbi8vXG4vLyAgICAgICQoJyNhY3Rpdml0aWVzLXNlYXJjaCcpLmFwcGVuZChvcHRpb24pO1xuLy9cbi8vICAgICAgfSk7XG4vL1xuLy8gICAgIHNodWZmbGUocG9wdWxhcik7XG4vLyAgICAgICAkLmVhY2gocG9wdWxhciwgZnVuY3Rpb24oaSwgcG9wdWxhcil7XG4vLyAgICAgICB2YXIgYWN0aXZldHkgPSBwb3B1bGFyLmFjZi5hY3RpdmV0eS50b0xvd2VyQ2FzZSgpO1xuLy8gICAgICAgdmFyIHNlYXNvbiA9IHBvcHVsYXIuYWNmLnNlYXNvbi50b0xvd2VyQ2FzZSgpO1xuLy8gICAgICAgdmFyIGNhcmRJY29uID0gYWN0aXZldHk7XG4vLyAgICAgICBpZiAoY2FyZEljb24gPT0gXCJhbmltYWwgbGlmZVwiKSB7XG4vLyAgICAgICAgY2FyZEljb24gPSBcImFuaW1hbC1saWZlXCI7XG4vLyAgICAgICB9XG4vLyAgICAgICAvLyAgY29uc29sZS5sb2coJ3BvcCcpO1xuLy8gICAgICAgdmFyIGljb25DbGFzcyA9IGFjdGl2ZXR5O1xuLy9cbi8vICAgICAgIGZ1bmN0aW9uIGdldFdvcmRzKHBhcmFtZXRlcikge1xuLy8gICAgICAgICAgIHJldHVybiBwYXJhbWV0ZXIuc3BsaXQoL1xccysvKS5zbGljZSgwLDQpLmpvaW4oXCIgXCIpK1wiLi5cIjtcbi8vICAgICAgIH1cbi8vICAgICAgIHZhciBsYXJnZUNhcmRIZWFkaW5nID0gcG9wdWxhci50aXRsZS5yZW5kZXJlZDtcbi8vXG4vLyAgICAgICBnZXRXb3JkcyhsYXJnZUNhcmRIZWFkaW5nKTtcbi8vXG4vLyAgICAgICB2YXIgU3RyaXBwZWRTdHJpbmdCaWcgPSBwb3B1bGFyLmV4Y2VycHQucmVuZGVyZWQucmVwbGFjZSgvKDwoW14+XSspPikvaWcsXCJcIik7XG4vLyAgICAgICB2YXIgc2hvcnRlclRleHRCaWcgPSBTdHJpcHBlZFN0cmluZ0JpZy5zdWJzdHIoMCwgMTEyKSArIFwiLi4uXCI7XG4vL1xuLy8gICAgICAgdmFyIGJpZ0NhcmQgPSBcIjxkaXYgaWQ9JycgY2xhc3M9J2NhcmQtbGFyZ2UnIHJvbGU9J2FydGljbGUnPjxhIGhyZWY9J1wiK3BvcHVsYXIubGluaytcIic+PGRpdiBjbGFzcz0naW1hZ2UnIHN0eWxlPSdiYWNrZ3JvdW5kLWltYWdlOnVybChcIitwb3B1bGFyLmFjZi5pbmZvX2ltZy5zaXplcy5sYXJnZStcIik7Jz48aW1nIHNyYz0nJyBhbHQ9JycvPjwvZGl2PjxkaXYgY2xhc3M9J2ljb24nIHN0eWxlPSdiYWNrZ3JvdW5kLWltYWdlOnVybChcIityb290VXJsK1wiL3dwLWNvbnRlbnQvdGhlbWVzL2ZvdW5kYXRpb25QcmVzc0dpdC9hc3NldHMvaW1hZ2VzL2ljb25zL2NhdEljb25zL1wiK2NhcmRJY29uK1wiLnN2Zyk7JyA+PC9kaXY+PHAgY2xhc3M9J2NhdC1zdHJpbmcnPiBcIithY3RpdmV0eStcIiAvIFwiK3NlYXNvbitcIiA8L3A+PGhlYWRlciBjbGFzcz0nY2FyZC1jb250ZW50IGFydGljbGUtaGVhZGVyJz48aDIgY2xhc3M9J2VudHJ5LXRpdGxlIHNpbmdsZS10aXRsZScgaXRlbXByb3A9J2hlYWRsaW5lJz5cIitwb3B1bGFyLnRpdGxlLnJlbmRlcmVkK1wiPC9oMj48cD5cIitzaG9ydGVyVGV4dEJpZytcIjwvcD48L2hlYWRlcj48YnV0dG9uIHR5cGU9J2J1dHRvbicgY2xhc3M9J3JlYWRNb3JlQnRuJz5SZWFkIG1vcmU8L2J1dHRvbj48L2E+PC9kaXY+XCI7XG4vL1xuLy8gICAgICAgaWYgKHBvcHVsYXIuYWNmLmlzX3BvcHVsYXIpIHtcbi8vICAgICAgICAgJChcIiNiaWctY2FyZHNcIikuYXBwZW5kKGJpZ0NhcmQpO1xuLy8gICAgICAgfVxuLy9cbi8vICAgICAgIHJldHVybiBpIDwgMTtcbi8vICAgICAgfSk7XG4vLyAgICAgICBzaHVmZmxlKHNtYWxsQ2FyZHMpO1xuLy8gICAgICAgJC5lYWNoKHNtYWxsQ2FyZHMsIGZ1bmN0aW9uKGksIGNhcmQpe1xuLy8gICAgICAgICB2YXIgYWN0aXZldHkgPSBjYXJkLmFjZi5hY3RpdmV0eS50b0xvd2VyQ2FzZSgpO1xuLy8gICAgICAgICB2YXIgc2Vhc29uID0gY2FyZC5hY2Yuc2Vhc29uLnRvTG93ZXJDYXNlKCk7XG4vLyAgICAgICAgIHZhciBjYXJkSWNvbiA9IGFjdGl2ZXR5O1xuLy8gICAgICAgICBpZiAoY2FyZEljb24gPT0gXCJhbmltYWwgbGlmZVwiKSB7XG4vLyAgICAgICAgICBjYXJkSWNvbiA9IFwiYW5pbWFsLWxpZmVcIjtcbi8vICAgICAgICAgfVxuLy8gICAgICAgICB2YXIgaWNvbkNsYXNzID0gYWN0aXZldHk7XG4vL1xuLy8gICAgICAgICB2YXIgc21hbGxlckgyO1xuLy8gICAgICAgICAvLyAgaWYgKGNhcmQudGl0bGUucmVuZGVyZWQubGVuZ3RoID4gMjEpIHtcbi8vICAgICAgICAgLy8gICAgIHNtYWxsZXJIMiA9ICdzbWFsbGVySDInO1xuLy8gICAgICAgICAvLyAgfWVsc2V7XG4vLyAgICAgICAgIC8vICAgIHNtYWxsZXJIMiA9ICcnO1xuLy8gICAgICAgICAvLyAgfVxuLy8gICAgICAgICBmdW5jdGlvbiBnZXRXb3JkcyhwYXJhbWV0ZXIsIG51bVdvcmRzKSB7XG4vLyAgICAgICAgICAgcmV0dXJuIHBhcmFtZXRlci5zcGxpdCgvXFxzKy8pLnNsaWNlKDAsbnVtV29yZHMpLmpvaW4oXCIgXCIpK1wiLi5cIjtcbi8vICAgICAgICAgfVxuLy9cbi8vICAgICAgICAgdmFyIGNhcmRIZWFkaW5nID0gY2FyZC50aXRsZS5yZW5kZXJlZDtcbi8vICAgICAgICAgdmFyIGluRmV3ZXJXb3JkcyA9IGNhcmQuZXhjZXJwdC5yZW5kZXJlZDtcbi8vICAgICAgICAgZ2V0V29yZHMoY2FyZEhlYWRpbmcsIDMpO1xuLy9cbi8vICAgICAgICAgdmFyIFN0cmlwcGVkU3RyaW5nID0gY2FyZC5leGNlcnB0LnJlbmRlcmVkLnJlcGxhY2UoLyg8KFtePl0rKT4pL2lnLFwiXCIpO1xuLy8gICAgICAgICB2YXIgc2hvcnRlclRleHQgPSBTdHJpcHBlZFN0cmluZy5zdWJzdHIoMCwgNDgpICsgXCIuLi5cIjtcbi8vXG4vLyAgICAgICAgIHZhciBzbWFsbENhcmQgPSBcIjxkaXYgY2xhc3M9J3NtYWxsLTEyIG1lZGl1bS02IGxhcmdlLTQgeGxhcmdlLTMgY2FyZC1jb250YWluZXIgaGlkZGVuJz48ZGl2ICBjbGFzcz0nY2FyZCcgcm9sZT0nYXJ0aWNsZScgPjxhIGhyZWY9J1wiK2NhcmQubGluaytcIic+PGRpdiBjbGFzcz0naW1hZ2UnIHN0eWxlPSdiYWNrZ3JvdW5kLWltYWdlOnVybChcIitjYXJkLmFjZi5pbmZvX2ltZy5zaXplcy5tZWRpdW0rXCIpOyc+PGltZyBzcmM9JycgYWx0PScnIC8+PC9kaXY+PGRpdiBjbGFzcz0naWNvbiBpY29uLVwiK2ljb25DbGFzcytcIicgc3R5bGU9J2JhY2tncm91bmQtaW1hZ2U6dXJsKFwiK3Jvb3RVcmwrXCIvd3AtY29udGVudC90aGVtZXMvZm91bmRhdGlvblByZXNzR2l0L2Fzc2V0cy9pbWFnZXMvaWNvbnMvY2F0SWNvbnMvXCIrY2FyZEljb24rXCIuc3ZnKTsnID48L2Rpdj48cCBjbGFzcz0nY2F0LXN0cmluZyc+IFwiK2FjdGl2ZXR5K1wiIC8gXCIrc2Vhc29uK1wiIDwvcD48aGVhZGVyIGNsYXNzPSdjYXJkLWNvbnRlbnQgYXJ0aWNsZS1oZWFkZXInPjxoMiBjbGFzcz0nZW50cnktdGl0bGUgc2luZ2xlLXRpdGxlIFwiK3NtYWxsZXJIMitcIicgaXRlbXByb3A9J2hlYWRsaW5lJz5cIitnZXRXb3JkcyhjYXJkSGVhZGluZywgMykrXCI8L2gyPjxwPlwiK3Nob3J0ZXJUZXh0K1wiPC9wPjwvaGVhZGVyPjxidXR0b24gdHlwZT0nYnV0dG9uJyBjbGFzcz0nYm9va0J0bic+Qm9vazwvYnV0dG9uPjwvYT48L2Rpdj48L2Rpdj5cIjtcbi8vXG4vL1xuLy8gICAgICAgICBpZighcG9wdWxhci5hY2YuaXNfcG9wdWxhcilcbi8vICAgICAgICAge1xuLy8gICAgICAgICAgICQoXCIjY2FyZHNcIikuYXBwZW5kKHNtYWxsQ2FyZCk7XG4vLyAgICAgICAgIH1cbi8vICAgICAgIH0pO1xuLy8gICB9KTtcbi8vIH07XG4vLyAvLyBzZXRUaW1lb3V0KFwiSlNPTmdldHRlcihiaWtlVG91cnNIdHRwLCAnYmlrZU9iamVjdCcpXCIsMjAwKTtcbi8vIEpTT05nZXR0ZXIoYmlrZVRvdXJzSHR0cCwgJ2Jpa2VPYmplY3QnKTtcbi8vIGZ1bmN0aW9uIGxvYWRNb3JlKCl7XG4vLyAgICAgICAgICQoXCIjY2FyZHMgLmhpZGRlblwiKS5zbGljZSgwLDQpLnJlbW92ZUNsYXNzKFwiaGlkZGVuXCIpO1xuLy8gICAgIH1cbi8vIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7IGxvYWRNb3JlKCk7IH0sIDE1MDApO1xuLy8gJChcIi5zaG93LW1vcmVcIikub24oXCJjbGlja1wiLGxvYWRNb3JlKTtcbi8vXG4vLyAvLyBKU09OZ2V0dGVyKGN1c3RvbVRlc3QsICd0ZXN0Jyk7XG4iLCIvLyBmdW5jdGlvbiBhcGlDYWxsKHBhdGgsIGRhdGEpe1xuLy8gICBqUXVlcnkucG9zdChwYXRoLCBkYXRhLCBmdW5jdGlvbihyZXMpe1xuLy8gICAgIC8vIGNvbnNvbGUubG9nKHJlcyk7XG4vLyAgICAgdmFyIGpQb3N0UmVzID0gSlNPTi5wYXJzZShyZXMpO1xuLy8gICAgIGNvbnNvbGUubG9nKGpQb3N0UmVzKTtcbi8vICAgfSk7XG4vLyB9XG4vL1xuLy8gdmFyIGVsQm9keSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2JvZHknKTtcbi8vXG4vLyBpZihlbEJvZHkuY2xhc3NMaXN0LmNvbnRhaW5zKCdzaW5nbGUtdG91cl9wb3N0X3R5cGUnKSkge1xuLy8gICB2YXIgcG9zdCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2FydGljbGUnKTtcbi8vICAgdmFyIHBvc3RJZCA9IHBvc3QuZ2V0QXR0cmlidXRlKCdkYXRhLXRvdXJpZCcpO1xuLy8gICB2YXIgcG9zdERhdGEgPSB7XCJkYXRhXCI6IHBvc3RJZH07XG4vLyAgIC8vIGNvbnNvbGUuZGlyKHBvc3RJZCk7XG4vLyAgIGFwaUNhbGwocm9vdFVybCsnd3AtY29udGVudC90aGVtZXMvZm91bmRhdGlvblByZXNzR2l0L2xpYnJhcnkvYXBpL2NhbGwtYnktaWQucGhwJywgcG9zdERhdGEpO1xuLy8gfVxuXG4vLyBmdW5jdGlvbiBzZW5kQ2FyZElkKCl7XG4vLyAgIC8vIGNvbnNvbGUubG9nKCd4Jyk7XG4vLyAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZnVuY3Rpb24oZSl7XG4vLyAgICAgLy8gY29uc29sZS5sb2coZS50YXJnZXQpO1xuLy8gICAgIGlmKGUudGFyZ2V0LmNsYXNzTGlzdC5jb250YWlucygnYnRuQ2FyZCcpKSB7XG4vLyAgICAgICB2YXIgc0dldFRvdXJJZCA9IGUudGFyZ2V0LmdldEF0dHJpYnV0ZSgnZGF0YS10cmlwaWQnKTtcbi8vICAgICAgIHZhciBqU2VuZFRvdXJJRCA9IHtcImRhdGFcIjpzR2V0VG91cklkfTtcbi8vICAgICAgIGFwaUNhbGwocm9vdFVybCsnd3AtY29udGVudC90aGVtZXMvZm91bmRhdGlvblByZXNzR2l0L2xpYnJhcnkvYXBpL2NhbGwtYnktaWQucGhwJywgalNlbmRUb3VySUQpO1xuLy8gICAgICAgLy8gY29uc29sZS5sb2coZ2V0VG91cklkKTtcbi8vICAgICB9XG4vLyAgIH0pO1xuLy8gfVxuLy9cbi8vIHNlbmRDYXJkSWQoKTtcbiIsIlxuLy8gY29uc29sZS5sb2cocm9vdFVybCk7XG5cbiAgLy8gY29uc29sZS5sb2coc1NlYXJjaFN0cmluZyk7XG5cbiAgICAkLmdldEpTT04oIHRlbXBsYXRlVXJsK1wiL2xpYnJhcnkvZGV0YWlsZWR0cmlwcy5qc29uXCIsIGZ1bmN0aW9uKCBkYXRhICkge1xuICAgICAgJCgnI2FjdGl2aXRpZXNTZWFyY2gnKS5vbigna2V5dXAnLCBmdW5jdGlvbigpe1xuXG4gICAgICB2YXIgc1NlYXJjaFN0cmluZyA9ICQodGhpcykudmFsKCk7XG4gICAgICB2YXIgYUl0ZW1zID0gW107XG4gICAgICAvLyBjb25zb2xlLmxvZyh0eXBlb2Ygc1NlYXJjaFN0cmluZyk7XG4gICAgICAvLyBzUmVzdWx0c0Ryb3Bkb3duLmlubmVySFRNTCA9IFwiXCI7XG4gICAgICB2YXIgdGl0bGUgPSAnJztcbiAgICAgIHZhciBtYWluQWN0aXZldHkgPSBcIlwiO1xuICAgICAgdmFyIHRyaXBEZXNjcmlwdGlvbiA9IFwiXCI7XG4gICAgICB2YXIgc2Vhc29uID0gXCJcIjtcbiAgICAgIHZhciBhbGxBY3RpdmV0aWVzID0gW107XG4gICAgICB2YXIgdHJpcHMgPSBkYXRhLnRyaXBzO1xuICAgICAgdmFyIGFsbEFjdGl2VG9Mb3dlckNhc2UgPSBcIlwiO1xuICAgICAgLy8gY29uc29sZS5sb2codHJpcHMpO1xuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0cmlwcy5sZW5ndGg7IGkrKykge1xuICAgICAgICB0aXRsZSA9IHRyaXBzW2ldLnRpdGxlLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIHRyaXBEZXNjcmlwdGlvbiA9IHRyaXBzW2ldLmRlc2NyaXB0aW9uLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIG1haW5BY3RpdmV0eSA9IHRyaXBzW2ldLmFjdGl2aXR5Q2F0ZWdvcmllc1swXTtcbiAgICAgICAgYWxsQWN0aXZldGllcyA9IHRyaXBzW2ldLmFjdGl2aXR5Q2F0ZWdvcmllcztcbiAgICAgICAgc2Vhc29uID0gdHJpcHNbaV0uc2Vhc29uLnRvTG93ZXJDYXNlKCk7XG5cbiAgICAgICAgZm9yICh2YXIgdCA9IDA7IHQgPCBhbGxBY3RpdmV0aWVzLmxlbmd0aDsgdCsrKVxuICAgICAgICB7XG4gICAgICAgICAgYWxsQWN0aXZUb0xvd2VyQ2FzZSA9ICBhbGxBY3RpdmV0aWVzW3RdLnJlcGxhY2UoL18vZywgXCIgXCIpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgLy8gY29uc29sZS5sb2coYWxsQWN0aXZUb0xvd2VyQ2FzZSk7XG4gICAgICAgICAgaWYoICh0aXRsZS5pbmNsdWRlcyhzU2VhcmNoU3RyaW5nLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICAgICAgICAgIHRyaXBEZXNjcmlwdGlvbi5pbmNsdWRlcyhzU2VhcmNoU3RyaW5nLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICAgICAgICAgIGFsbEFjdGl2VG9Mb3dlckNhc2UuaW5jbHVkZXMoc1NlYXJjaFN0cmluZy50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgICAgICAgICBzZWFzb24uaW5jbHVkZXMoc1NlYXJjaFN0cmluZy50b0xvd2VyQ2FzZSgpKSkmJlxuICAgICAgICAgICAgICBzU2VhcmNoU3RyaW5nICE9PSBcIiBcIiAmJiBzU2VhcmNoU3RyaW5nLmxlbmd0aCA+IDBcbiAgICAgICAgICAgIClcbiAgICAgICAgICB7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyh0cmlwc1tpXSk7XG4gICAgICAgICAgICBzUmVzdWx0c0Ryb3Bkb3duLmNsYXNzTGlzdC5hZGQoJ3NlYXJjaEFjdGl2ZScpO1xuICAgICAgICAgICAgYUl0ZW1zLnB1c2godHJpcHNbaV0pO1xuXG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIGVsc2Uge1xuICAgICAgICAgIC8vICAgICBzUmVzdWx0c0Ryb3Bkb3duLmNsYXNzTGlzdC5yZW1vdmUoJ3NlYXJjaEFjdGl2ZScpO1xuICAgICAgICAgIC8vIH1cbiAgICAgICAgICBpZihzUmVzdWx0c0Ryb3Bkb3duLm9mZnNldEhlaWdodCA+IDIxKXtcblxuICAgICAgICAgICAgIHNSZXN1bHRzRHJvcGRvd24uY2xhc3NMaXN0LnJlbW92ZSgnc2VhcmNoQWN0aXZlJyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIGVsc2Uge1xuICAgICAgICAgIC8vICAgc1Jlc3VsdHNEcm9wZG93bi5jbGFzc0xpc3QuYWRkKCdzZWFyY2hBY3RpdmUnKTtcbiAgICAgICAgICAvLyB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHZhciByZXN1bHRUaXRsZSA9ICcnO1xuICAgICAgdmFyIHJlc3VsdEFjdGl2ZXR5ID0gJyc7XG5cblxuICAgICAgdmFyIGZpbHRlcmVkQXJyYXkgPSBhSXRlbXMuZmlsdGVyKGZ1bmN0aW9uKGl0ZW0sIHBvcyl7XG4gICAgICAgIHJldHVybiBhSXRlbXMuaW5kZXhPZihpdGVtKT09IHBvcztcbiAgICAgIH0pO1xuICAgICAgLy8gY29uc29sZS5sb2coYUl0ZW1zKTtcbiAgICAgIHZhciBzUmVzdWx0UmVuZGVyID0gXCJcIjtcbiAgICAgIC8vIGNvbnNvbGUubG9nKGZpbHRlcmVkQXJyYXkpO1xuXG4gICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGZpbHRlcmVkQXJyYXkubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2coZmlsdGVyZWRBcnJheVtqXS50aXRsZSk7XG4gICAgICAgIHJlc3VsdFRpdGxlID0gZmlsdGVyZWRBcnJheVtqXS50aXRsZTtcbiAgICAgICAgcmVzdWx0QWN0aXZldHkgPSBmaWx0ZXJlZEFycmF5W2pdLnNlYXNvbjtcbiAgICAgICAgc1Jlc3VsdFJlbmRlciArPSAnPGRpdiBjbGFzcz1cInJlc3VsdEl0ZW1cIiBkYXRhLXRyaXBpZD1cIicrZmlsdGVyZWRBcnJheVtqXS5pZCsnXCI+PHNwYW4gY2xhc3M9XCJzU2VhcmNoVmFsXCI+JytyZXN1bHRUaXRsZSsnPC9zcGFuPjxzcGFuIGNsYXNzPVwicmVzdWx0X3NlYXNvbiBzU2VhcmNoVmFsXCI+JytyZXN1bHRBY3RpdmV0eS5yZXBsYWNlKC9fL2csIFwiIFwiKSsnPC9zcGFuPjwvZGl2Pic7XG4gICAgICB9XG4gICAgICAvLyBjb25zb2xlLmxvZyhzUmVzdWx0UmVuZGVyKTtcbiAgICAgIHNSZXN1bHRzRHJvcGRvd24uaW5uZXJIVE1MID0gc1Jlc3VsdFJlbmRlcjtcbiAgICB9KTtcbiAgfSk7XG5cbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZnVuY3Rpb24oZSl7XG4gIC8vIGNvbnNvbGUubG9nKGUudGFyZ2V0KTtcbiAgaWYgKGUudGFyZ2V0LmNsYXNzTGlzdC5jb250YWlucygnc1NlYXJjaFZhbCcpKSB7XG4gICAgLy8gY29uc29sZS5sb2coJ3gnKTtcbiAgICB2YXIgcGFyZW50SUQgPSBlLnRhcmdldC5wYXJlbnRFbGVtZW50LmdldEF0dHJpYnV0ZSgnZGF0YS10cmlwaWQnKTtcbiAgICAvLyAkKCcjYWN0aXZpdGllc1NlYXJjaCcpLnZhbCgpID0gcGFyZW50SUQ7XG4gICAgd2lkZ2V0X2lkLnZhbHVlID0gcGFyZW50SUQ7XG4gICAgLy8gY29uc29sZS5sb2cocGFyZW50SUQpO1xuICB9XG59KTtcbiIsImpRdWVyeShkb2N1bWVudCkuZm91bmRhdGlvbigpO1xuIiwiLy8gSm95cmlkZSBkZW1vXG4kKCcjc3RhcnQtanInKS5vbignY2xpY2snLCBmdW5jdGlvbigpIHtcbiAgJChkb2N1bWVudCkuZm91bmRhdGlvbignam95cmlkZScsJ3N0YXJ0Jyk7XG59KTsiLCJmdW5jdGlvbiByZXNpemUoZXZlbnQpIHtcbiAgLy8gY29uc29sZS5sb2coZXZlbnQpO1xuICBvd2wudHJpZ2dlcignZGVzdHJveS5vd2wuY2Fyb3VzZWwnKTtcbn1cbmlmKHdpbmRvdy5pbm5lcldpZHRoIDw9IDEwMjQpe1xuICB2YXIgb3dsID0gJCgnI2NhcmRzJyk7XG4gIG93bC5vd2xDYXJvdXNlbCh7XG4gICAgZG90czogZmFsc2UsXG4gICAgcmVzcG9uc2l2ZTp7XG4gICAgICAgIDA6e1xuICAgICAgICAgIGl0ZW1zOjEsXG4gICAgICAgICAgbmF2OmZhbHNlLFxuICAgICAgICAgIGxvb3A6IHRydWUsXG4gICAgICAgICAgc3RhZ2VQYWRkaW5nOiAzMCxcbiAgICAgICAgICBkb3RzOiBmYWxzZVxuICAgICAgICB9LFxuICAgICAgICA2NDA6e1xuICAgICAgICAgIGl0ZW1zOjIsXG4gICAgICAgICAgbmF2OmZhbHNlLFxuICAgICAgICAgIGxvb3A6IHRydWUsXG4gICAgICAgICAgc3RhZ2VQYWRkaW5nOiAxMCxcbiAgICAgICAgICBkb3RzOiBmYWxzZVxuICAgICAgICB9LFxuICAgICAgICAxMDI0OntcbiAgICAgICAgICBpdGVtczoyLFxuICAgICAgICAgIG5hdjpmYWxzZSxcbiAgICAgICAgICBsb29wOiB0cnVlLFxuICAgICAgICAgIHN0YWdlUGFkZGluZzogMzUsXG4gICAgICAgICAgZG90czogZmFsc2UsXG4gICAgICAgICAgb25SZXNpemU6IHJlc2l6ZVxuICAgICAgICB9XG4gICAgIH1cbiAgIH0pO1xuXG59XG5cbnZhciBwb3N0T3dsID0gJCgnI2NhcmRzUG9zdCcpO1xucG9zdE93bC5vd2xDYXJvdXNlbCh7XG4gIGl0ZW1zOjEsXG4gIG5hdjpmYWxzZSxcbiAgbG9vcDogdHJ1ZSxcbiAgc3RhZ2VQYWRkaW5nOiAxMCxcbiAgZG90czogZmFsc2UsXG4gIGF1dG9wbGF5OiB0cnVlLFxuXG4gIHJlc3BvbnNpdmU6e1xuICAgICAgMDp7XG4gICAgICAgIGl0ZW1zOjEsXG4gICAgICAgIG5hdjpmYWxzZSxcbiAgICAgICAgbG9vcDogdHJ1ZSxcbiAgICAgICAgc3RhZ2VQYWRkaW5nOiAzMCxcbiAgICAgICAgZG90czogZmFsc2VcbiAgICAgIH0sXG4gICAgICA2NDA6e1xuICAgICAgICBpdGVtczoyLFxuICAgICAgICBuYXY6ZmFsc2UsXG4gICAgICAgIGxvb3A6IHRydWUsXG4gICAgICAgIHN0YWdlUGFkZGluZzogOTAsXG4gICAgICAgIGRvdHM6IGZhbHNlXG4gICAgICB9LFxuICAgICAgMTAyNDp7XG4gICAgICAgIGl0ZW1zOjMsXG4gICAgICAgIG5hdjpmYWxzZSxcbiAgICAgICAgbG9vcDogdHJ1ZSxcbiAgICAgICAgc3RhZ2VQYWRkaW5nOiAxMCxcbiAgICAgICAgZG90czogZmFsc2VcbiAgICAgICAgLy8gb25SZXNpemU6IHJlc2l6ZVxuICAgICAgfSxcbiAgICAgIDEyMDA6e1xuICAgICAgICBpdGVtczo0LFxuICAgICAgICBuYXY6ZmFsc2UsXG4gICAgICAgIGxvb3A6IHRydWUsXG4gICAgICAgIHN0YWdlUGFkZGluZzogMTAsXG4gICAgICAgIGRvdHM6IGZhbHNlXG4gICAgICAgIC8vIG9uUmVzaXplOiByZXNpemVcbiAgICAgIH1cbiAgICB9XG59KTtcblxuXG5cblxuXG4vLyAkKHdpbmRvdykucmVzaXplKGZ1bmN0aW9uKCl7XG4vLyAgIGNvbnNvbGUubG9nKCd4Jyk7XG4vLyAgIGlmKHdpbmRvdy5pbm5lcldpZHRoIDw9IDEwMjQpIHtcbi8vICAgICAgb3dsLnRyaWdnZXIoJ2Rlc3Ryb3kub3dsLmNhcm91c2VsJyk7XG4vLyAgIH1cbi8vXG4vLyB9KVxuIiwiIiwiJChkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24gKCkge1xuICAgIHZhciB2aWRlb3MgPSAkKCdpZnJhbWVbc3JjKj1cInZpbWVvLmNvbVwiXSwgaWZyYW1lW3NyYyo9XCJ5b3V0dWJlLmNvbVwiXScpO1xuXG4gICAgdmlkZW9zLmVhY2goZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgZWwgPSAkKHRoaXMpO1xuICAgICAgICBlbC53cmFwKCc8ZGl2IGNsYXNzPVwicmVzcG9uc2l2ZS1lbWJlZCB3aWRlc2NyZWVuXCIvPicpO1xuICAgIH0pO1xufSk7XG4iLCJ2YXIgb25TY3JvbGwgPSBmdW5jdGlvbihjb250YWluZXIsIHRoZWNsYXNzLCBhbW91bnQpIHtcblx0XHR2YXIgd3JhcCA9ICQoY29udGFpbmVyKTtcblx0XHQkKHdpbmRvdykuc2Nyb2xsKGZ1bmN0aW9uKCl7XG5cdFx0XHRpZiAoJChkb2N1bWVudCkuc2Nyb2xsVG9wKCkgPiBhbW91bnQpIHtcblx0XHRcdFx0d3JhcC5hZGRDbGFzcyh0aGVjbGFzcyk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0ICB3cmFwLnJlbW92ZUNsYXNzKHRoZWNsYXNzKTtcblx0XHRcdH1cblx0XHR9KTtcblx0fTtcblxub25TY3JvbGwoJy5tYWluLW5hdi1jb250YWluZXInLCdzZXQtbmF2LXBvc2l0aW9uJywgMSApO1xuXG4kKCcuY2FsbCcpLmNsaWNrKGZ1bmN0aW9uKCl7XG5cdCQoJy5idXJnZXInKS50b2dnbGVDbGFzcygndGhleCcpO1xuXHQkKCdib2R5JykudG9nZ2xlQ2xhc3MoJ3N0b3Atc2Nyb2xsaW5nJyk7XG5cdC8vICQoJyNvZmZDYW52YXMnKS50b2dnbGVDbGFzcygncG9zaXRpb24tbGVmdCcpO1xuXHQvLyAgJChkb2N1bWVudCkuZm91bmRhdGlvbigpO1xufSk7XG5cbiQoJy5pcy1hY2NvcmRpb24tc3VibWVudS1wYXJlbnQnKS5jbGljayhmdW5jdGlvbigpe1xuXHQvLyAkKCdib2R5JykudG9nZ2xlQ2xhc3MoJ3N0b3Atc2Nyb2xsaW5nJyk7XG59KTtcblxuJCgnLmlzLWRyb3Bkb3duLXN1Ym1lbnUtcGFyZW50JykubW91c2VvdmVyKGZ1bmN0aW9uKCl7XG5cdCQoJy5maXJzdC1zdWInKS50b2dnbGVDbGFzcygnbWVudS1hbmltYXRpb24nKTtcbn0pO1xuXG4kKCcuZmlsdGVyYnV0dG9uJykub24oJ2NsaWNrJywgZnVuY3Rpb24oKXtcblx0JCgnI25hdkFjdGl2ZXR5JykuYWRkQ2xhc3MoJ3Nob3dOYXZBY3RpdmV0eScpO1xuXHQkKCdib2R5JykuYWRkQ2xhc3MoJ3N0b3Atc2Nyb2xsaW5nJyk7XG59KTtcblxuJCgnI2Nsb3NlQWN0aXZldHlOYXYnKS5vbignY2xpY2snLCBmdW5jdGlvbigpe1xuXHQkKCcjbmF2QWN0aXZldHknKS5yZW1vdmVDbGFzcygnc2hvd05hdkFjdGl2ZXR5Jyk7XG5cdCQoJ2JvZHknKS5yZW1vdmVDbGFzcygnc3RvcC1zY3JvbGxpbmcnKTtcbn0pO1xuIiwiXG4kKHdpbmRvdykuYmluZCgnIGxvYWQgcmVzaXplIG9yaWVudGF0aW9uQ2hhbmdlICcsIGZ1bmN0aW9uICgpIHtcbiAgIHZhciBmb290ZXIgPSAkKFwiI2Zvb3Rlci1jb250YWluZXJcIik7XG4gICB2YXIgcG9zID0gZm9vdGVyLnBvc2l0aW9uKCk7XG4gICB2YXIgaGVpZ2h0ID0gJCh3aW5kb3cpLmhlaWdodCgpO1xuICAgaGVpZ2h0ID0gaGVpZ2h0IC0gcG9zLnRvcDtcbiAgIGhlaWdodCA9IGhlaWdodCAtIGZvb3Rlci5oZWlnaHQoKSAtMTtcblxuICAgZnVuY3Rpb24gc3RpY2t5Rm9vdGVyKCkge1xuICAgICBmb290ZXIuY3NzKHtcbiAgICAgICAgICdtYXJnaW4tdG9wJzogaGVpZ2h0ICsgJ3B4J1xuICAgICB9KTtcbiAgIH1cblxuICAgaWYgKGhlaWdodCA+IDApIHtcbiAgICAgc3RpY2t5Rm9vdGVyKCk7XG4gICB9XG59KTtcbiJdfQ==
