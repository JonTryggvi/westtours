 <section class="fw chapter-parent">
   <div class="row align-center small-12 medium-12 large-6 chapter-red">
     <div class="small-8">
       <h2><?php the_title(); ?></h2>
       <p>
         <?php the_content('',); ?>
       </p>

     </div>
     <button class="chapter">Read More</button>
   </div>

   <div class="small-12 medium-12 large-6 chapter-red-img">

   </div>
   <div class="row align-center small-12 medium-12 large-6 chapter-blue">
     <div class="small-8">
       <h2>Can I rent a bike?</h2>
       <p>
         Etiam arcu lacus, congue in suscipit vel, egestas nec purus. Suspendisse volutpat, magna vitae facilisis fringilla, augue augue congue dui, et viverra leo augue quis risus. Duis mollis odio malesuada est vestibulum, ut tempor dolor commodo. Nulla facilisi. Sed eu massa quis massa rutrum hendrerit.
       </p>

     </div>
     <button class="chapter-blbtn">Read More</button>
   </div>
   <div class="small-12 medium-12 large-6 chapter-blue-img">

   </div>

 </section>
