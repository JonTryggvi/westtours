
// console.log(rootUrl);

  // console.log(sSearchString);

    $.getJSON( templateUrl+"/library/detailedtrips.json", function( data ) {
      $('#activitiesSearch').on('keyup', function(){

      var sSearchString = $(this).val();
      var aItems = [];
      // console.log(typeof sSearchString);
      // sResultsDropdown.innerHTML = "";
      var title = '';
      var mainActivety = "";
      var tripDescription = "";
      var season = "";
      var allActiveties = [];
      var trips = data.trips;
      var allActivToLowerCase = "";
      // console.log(trips);
      for (var i = 0; i < trips.length; i++) {
        title = trips[i].title.toLowerCase();
        tripDescription = trips[i].description.toLowerCase();
        mainActivety = trips[i].activityCategories[0];
        allActiveties = trips[i].activityCategories;
        season = trips[i].season.toLowerCase();

        for (var t = 0; t < allActiveties.length; t++)
        {
          allActivToLowerCase =  allActiveties[t].replace(/_/g, " ").toLowerCase();
          // console.log(allActivToLowerCase);
          if( (title.includes(sSearchString.toLowerCase()) ||
              tripDescription.includes(sSearchString.toLowerCase()) ||
              allActivToLowerCase.includes(sSearchString.toLowerCase()) ||
              season.includes(sSearchString.toLowerCase()))&&
              sSearchString !== " " && sSearchString.length > 0
            )
          {
            // console.log(trips[i]);
            sResultsDropdown.classList.add('searchActive');
            aItems.push(trips[i]);

          }
          // else {
          //     sResultsDropdown.classList.remove('searchActive');
          // }
          if(sResultsDropdown.offsetHeight > 21){

             sResultsDropdown.classList.remove('searchActive');
          }
          // else {
          //   sResultsDropdown.classList.add('searchActive');
          // }
        }
      }
      var resultTitle = '';
      var resultActivety = '';


      var filteredArray = aItems.filter(function(item, pos){
        return aItems.indexOf(item)== pos;
      });
      // console.log(aItems);
      var sResultRender = "";
      // console.log(filteredArray);

      for (var j = 0; j < filteredArray.length; j++) {
        // console.log(filteredArray[j].title);
        resultTitle = filteredArray[j].title;
        resultActivety = filteredArray[j].season;
        sResultRender += '<div class="resultItem" data-tripid="'+filteredArray[j].id+'"><span class="sSearchVal">'+resultTitle+'</span><span class="result_season sSearchVal">'+resultActivety.replace(/_/g, " ")+'</span></div>';
      }
      // console.log(sResultRender);
      sResultsDropdown.innerHTML = sResultRender;
    });
  });

document.addEventListener('click', function(e){
  // console.log(e.target);
  if (e.target.classList.contains('sSearchVal')) {
    // console.log('x');
    var parentID = e.target.parentElement.getAttribute('data-tripid');
    // $('#activitiesSearch').val() = parentID;
    widget_id.value = parentID;
    // console.log(parentID);
  }
});
