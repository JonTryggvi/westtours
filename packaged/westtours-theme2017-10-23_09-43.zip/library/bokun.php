<?php
  require_once("../../../../wp-load.php");
  $clientKey = 'xoGmSisjCTZoR';
  $clientSecret = 'PDMQ68FuYTryonXMDZIIjZgKdLRTgHaDvn9DrYyC9QXxo1yz';

  function callToAPI($apiPath){
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => $apiPath,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
    ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    if ($err) {
      echo "cURL Error #:" . $err;
    } else {
      return json_decode($response);
    }
  }
  function callToOauthAPI($apiPath){
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => $apiPath,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
    ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    if ($err) {
      echo "cURL Error #:" . $err;
    } else {
      return json_decode($response);
    }
  }
  function getBokunTrips($date, $apiKey, $signature, $path, $JSON){
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://api.bokun.is".$path,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => $JSON,
      CURLOPT_HTTPHEADER => array(
        "X-Bokun-Date: ".$date,
        "X-Bokun-AccessKey:".$apiKey,
        "X-Bokun-Signature:" . $signature,
        "content-type: application/json",
      ),
    ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    if ($err) {
      echo "cURL Error #:" . $err;
    } else {
      $jResponse = json_decode($response);
      return $jResponse;
    }
  }
  function getBokunDetailedTrips($date, $apiKey, $signature, $path){
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://api.bokun.is".$path,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
      CURLOPT_HTTPHEADER => array(
        "X-Bokun-Date: ".$date,
        "X-Bokun-AccessKey:".$apiKey,
        "X-Bokun-Signature:" . $signature,
        "content-type: application/json",
      ),
    ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    if ($err) {
      echo "cURL Error #:" . $err;
    } else {
      $jResponse = $response;
      return $jResponse;
    }
  }
  function generateSignature($postType, $APIendPoint){
    $timeZone = date_default_timezone_set("UTC");
    $dateTime = new DateTime('now');
    $timeStamp = $dateTime->format('Y-m-d H:i:s');
    // var_dump($timeStamp);
   // alt access key 702a0a41c1c041bfbdbc7be42edfe347
    $accessKey = "702a0a41c1c041bfbdbc7be42edfe347";
    $secretKey = "1577c56a0f484ce2bcc2fce6da6ad66f";
    $httpMethod = $postType;
    $apiPath = "/activity.json/".$APIendPoint;
    $concatKey = $timeStamp.$accessKey.$httpMethod.$apiPath;
    // var_dump($concatKey);
    $rawOutput = hash_hmac;
    $hashMack = hash_hmac('SHA1', $concatKey, $secretKey, $rawOutput=true);
    // var_dump($hashMack);
    $base64 = base64_encode($hashMack);
    // var_dump($base64);

    return [$timeStamp, $accessKey, $base64, $apiPath];
  }

  $getSignObjects = generateSignature("POST", "search");
  // var_dump($getSignObjects)
  $jObj = array();
  $emptyJSON = json_encode($jObj, JSON_FORCE_OBJECT);

  // var_dump($emptyJSON);

  if ($_GET['run']=='update') {
    $phpAPIdata = getBokunTrips($getSignObjects[0], $getSignObjects[1], $getSignObjects[2], $getSignObjects[3], $emptyJSON);
    $phpAPIdataItem = $phpAPIdata->items;
    $jasonAPIdata = json_encode($phpAPIdata);
    $saDetailedTours = array();

    for ($i=0; $i < count($phpAPIdataItem) ; $i++) {
      $phpAPIdataItemId = $phpAPIdataItem[$i]->id;
      // var_dump($phpAPIdataItemId);
      $getSigninObjectsdetailed = generateSignature("GET", $phpAPIdataItemId);
      $saDetailedTours[] = json_decode(getBokunDetailedTrips($getSigninObjectsdetailed[0], $getSigninObjectsdetailed[1], $getSigninObjectsdetailed[2], $getSigninObjectsdetailed[3]));
    }

    $aDetailedTours->trips = $saDetailedTours;
    //  file_put_contents('westtours.json', $jasonAPIdata);
    file_put_contents('detailedtrips.json',  json_encode($aDetailedTours));
  }



  $rootUrl = get_stylesheet_directory_uri();
  var_dump($rootUrl);
  $root = (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/';
  $themeDir = get_bloginfo('template_directory');
  var_dump($themeDir);
  var_dump($root);
  $localJSONTours = callToAPI($rootUrl.'/library/detailedtrips.json');
  $wpTours = callToAPI($themeDir.'/wp-json/wp/v2/tour_post_type?per_page=100');
  // var_dump($wpTours);

  if (isset($_GET['updatetours']) && $_GET['updatetours']=='update' )
  {
    $tours = $localJSONTours->trips;
    foreach ($wpTours as $wpKey => $wpValue) {
      $a_bokun_id[] = $wpValue->acf->bokun_id;
    }
    // var_dump($tours);
    foreach ($tours as $key => $value) {
      // var_dump($value->externalId);
      $tripExternalId[] = $value->externalId;
    }
      // var_dump(array_diff($aWp_bokun_id,$tripExternalId));

    $arrRes = array_diff($tripExternalId, $a_bokun_id);
    // var_dump($arrRes);
    foreach ($tripExternalId as $key => $val) {
      // var_dump($val);
      foreach ($arrRes as $Reskey => $Resvalue)
      {
        if(!empty($arrRes) && $key == $Reskey)
        {
          // var_dump($Reskey);
          $tripPostArr = array(
            'post_title' => $tours[$key]->title,
            'post_content' => $tours[$key]->description,
            'post_status' => 'publish',
            'post_type' => 'tour_post_type'
          );
          // Insert the post into the database
          $post_id = wp_insert_post($tripPostArr);
          // var_dump($tripPostArr);
          $sStartMonth = $tours[$key]->seasonalOpeningHours[0]->startMonth;
          $sStartDay = $tours[$key]->seasonalOpeningHours[0]->startDay;
          $sEndMonth = $tours[$key]->seasonalOpeningHours[0]->endMonth;
          $sEndDay = $tours[$key]->seasonalOpeningHours[0]->endDay;
          $sYear = date_create('now')->format('Y');
          $sMonth = date_create('now')->format('m');
          $sDay = date_create('now')->format('d');
          $seasonStart = strtotime($sYear.'-'.$sStartMonth.'-'.$sStartDay);
          $sSeasonStartFormated = date("Y-m-d", $seasonStart);
          // var_dump($sSeasonStartFormated);
          //
          $monthname = date('F', mktime(0, 0, 0, $sEndMonth, 10));
          // var_dump(strtotime(''.$sEndDay.' '. $monthname));
          if($seasonStart > strtotime(''.$sEndDay.' '. $monthname))
          {
            $sNextYear = strtotime(date("Y", mktime()) . " + 365 day");
            $sYearPlus = date('Y', $sNextYear);
          } else {
            $sYearPlus = $sYear;
          }
          // var_dump($sYearPlus);

          $seasonEnd = strtotime($sYearPlus.'-'.$sEndMonth.'-'.$sEndDay);
          $sSeasonEndFormated = date("Y-m-d", $seasonEnd);
          $seasonLength = $seasonEnd - $seasonStart;
          // var_dump($seasonLength/60/60/24);
          $seasonLengthDays = $seasonLength/60/60/24;

          if ($seasonLengthDays > 270 ) {
            $season =  'All year';
          }elseif($seasonLengthDays <= 91 && $sStartMonth == 11){
            $season = 'Winter';
          }elseif($seasonLengthDays <= 91 && $sStartMonth == 9){
            $season = 'Fall';
          }elseif($seasonLengthDays <= 91 && $sStartMonth == 6){
            $season = 'Summer';
          }elseif($seasonLengthDays <= 91 && $sStartMonth == 3){
            $season = 'Spring';
          }
          $getTheJson = file_get_contents('detailedtrips.json');
          $decodeTheJson = json_decode($getTheJson);
          $decodeTheJson->trips[$key]->season = $season;
          $encodeTheJson = json_encode($decodeTheJson);

          file_put_contents('detailedtrips.json', $encodeTheJson);

         $departueHoureRaw = $tours[$key]->startTimes[0]->hour;
         $departureMinuteRaw = $tours[$key]->startTimes[0]->minute;
         $sDepartureHoure = sprintf("%02d", $departueHoureRaw);
         $sDepartureMinute = sprintf("%02d", $departureMinuteRaw);
         $sDepartue = $sDepartureHoure. ':'. $sDepartureMinute;
         $duration = $tours[$key]->startTimes[0]->duration;
         $included = $tours[$key]->included;
         $TourCapasity = $tours[$key]->passCapacity;
         $tourPrice = $tours[$key]->nextDefaultPrice;
         $location = $tours[$key]->startPoints[0]->address->geoPoint;
         $address = $tours[$key]->startPoints[0]->address->city;
         $lat = $tours[$key]->startPoints[0]->address->geoPoint->latitude;
         $lng = $tours[$key]->startPoints[0]->address->geoPoint->longitude;
         $address = array("address" => $address, "lat" => $lat, "lng" => $lng, "zoom" => 14);

        //  var_dump($location);

          update_field('bokun_int_id', $tours[$key]->id, $post_id);
          update_field('bokun_id', $tours[$key]->externalId, $post_id);
          update_field('bokun_img', $tours[$key]->keyPhoto->originalUrl, $post_id);
          update_field('departure', $sDepartue, $post_id);
          update_field('duration', $duration, $post_id);
          update_field('included', $included, $post_id);
          update_field('max_customers', $TourCapasity, $post_id);
          update_field('season', $season, $post_id);
          update_field('seaseason-start', $sSeasonStartFormated, $post_id);
          update_field('season-end', $sSeasonEndFormated, $post_id);
          update_field('activety', $tours[$key]->activityCategories, $post_id);
          update_field('cost_per_adult', $tourPrice, $post_id);
          update_field('location', $address, $post_id);
        }
      }
    }
  }

 ?>
