
$('#from').dateRange(
{
   selected: function(dates)
   {
      var from = dates[0];
      var to = dates[1];
      //do something special
   }
})
