
// console.log(rootUrl);

  // console.log(sSearchString);

$.getJSON( templateUrl+"/library/detailedtrips.json", function( data ) {
  $('#activitiesSearch').on('keyup', function(){

    var sSearchString = $(this).val();
    var aItems = [];
    // console.log(typeof sSearchString);

    var title = '';
    var mainActivety = "";
    var tripDescription = "";
    var season = "";
    var allActiveties = [];
    var trips = data.trips;
    var allActivToLowerCase = "";
    // console.log(trips);
    for (var i = 0; i < trips.length; i++) {
      title = trips[i].title.toLowerCase();
      tripDescription = trips[i].description.toLowerCase();
      mainActivety = trips[i].activityCategories[0];
      allActiveties = trips[i].activityCategories;
      season = trips[i].season.toLowerCase();
      var filteredArray = [];
      sResultsDropdown.innerHTML = "";

      var searchResaults =  title.includes(sSearchString.toLowerCase()) ||
          tripDescription.includes(sSearchString.toLowerCase()) ||
          // allActivToLowerCase.includes(sSearchString.toLowerCase()) ||
          season.includes(sSearchString.toLowerCase());

      if( searchResaults && !sSearchString.length < 1 )
      {
        // console.log(trips[i]);
        sResultsDropdown.classList.add('searchActive');
        aItems.push(trips[i]);
        filteredArray = aItems.filter(function(item, pos){
          return aItems.indexOf(item) == pos;
        });

        var resultTitle = '';
        var resultActivety = '';
        var sResultRender = "";
        // console.log(filteredArray);
        for (var j = 0; j < filteredArray.length; j++) {
          // console.log(filteredArray[j].title);
          resultTitle = filteredArray[j].title;
          resultActivety = filteredArray[j].season;
          sResultRender += '<div class="resultItem" data-tripid="'+filteredArray[j].id+'"><span class="sSearchVal result_title">'+resultTitle+'</span><span class="result_season sSearchVal">'+resultActivety.replace(/_/g, " ")+'</span></div>';
        }
        sResultsDropdown.innerHTML = sResultRender;

      }
      else {
        console.log(sSearchString.length);
        sResultsDropdown.classList.remove('searchActive');
        sResultsDropdown.innerHTML = '';
      }


      // for (var t = 0; t < allActiveties.length; t++)
      // {
      //    allActivToLowerCase =  allActiveties[t].replace(/_/g, " ").toLowerCase();
      //   // console.log(allActivToLowerCase);
      //   // console.log(sSearchString);
      //   // console.log(title);
      //
      //   // else {
      //   //     sResultsDropdown.classList.remove('searchActive');
      //   // }
      //   if(sResultsDropdown.offsetHeight > 21){
      //
      //     //  sResultsDropdown.classList.remove('searchActive');
      //   }
      //   // else {
      //   //   sResultsDropdown.classList.add('searchActive');
      //   // }
      // }
    }

    // console.log(sResultRender);


    // filteredArray = [];
    console.log(filteredArray);
  });
});

function isDescendant(parent, child) {
  var node = child.parentNode;
  while (node != null) {
    if (node == parent) {
      return true;
    }
    node = node.parentNode;
  }
  return false;
}
var iCount = 0;
document.addEventListener('click', function(e){
  var searchValue='';
  var searchValueId = '';
  if(e.target.classList.contains('resultItem')){
    // console.dir(e.target.children[0].innerHTML);
    searchValue = e.target.children[0].innerHTML;
    activitiesSearch.value = searchValue;
    sResultsDropdown.classList.remove('searchActive');

  }
  if(e.target.classList.contains('result_season')){
    // console.dir(e.target.previousElementSibling.innerHTML);
    searchValue = e.target.previousElementSibling.innerHTML;
    // console.log(searchValueId);
    activitiesSearch.value = searchValue;
    sResultsDropdown.classList.remove('searchActive');
  }
  if(e.target.classList.contains('result_title')){
    // console.dir(e.target.previousElementSibling.innerHTML);
    searchValue = e.target.innerHTML;
    activitiesSearch.value = searchValue;
    sResultsDropdown.classList.remove('searchActive');
  }
  // console.log(e.target);
  if (e.target.classList.contains('sSearchVal')) {
    // console.log('x');
    var parentID = e.target.parentElement.getAttribute('data-tripid');
    // $('#activitiesSearch').val() = parentID;
    widget_id.value = parentID;
    // console.log(parentID);
  }
  // var counterContainer = document.querySelectorAll('.counterContainer');
  if (e.target.id == 'counter') {
    // console.log(counterContainer);
      counterContainer.classList.add('scaleUp');
  }
  if(e.target.classList.contains('btnCloseCount') ) {
    counterContainer.classList.remove('scaleUp');
  }

 // console.log(isDescendant(counterContainer, e.target));
  var btnCounterCount = document.querySelector('#counter');
  if(btnCounterCount)
  {
    var isClickInide = btnCounterCount.contains(e.target) || isDescendant(counterContainer, e.target);
    if (!isClickInide && counterContainer.classList.contains('scaleUp')){
     counterContainer.classList.toggle('scaleUp');
    }
  }
  var inputCount = "";
  if(e.target.classList.contains('btnPlus')) {
    inputCount = e.target.parentNode.parentNode.children[0].children[0];
    iCount = Number(inputCount.value) +1;
    if( Number(inputCount.value) < 5) {
      inputCount.value = iCount;
    }

  }
  if(e.target.classList.contains('btnMinus')) {
    inputCount = e.target.parentNode.parentNode.children[0].children[0];
    iCount = Number(inputCount.value) -1;
    if(Number(inputCount.value) > 0 ) {
      inputCount.value = iCount;
    }
  }
});

$('#showFilteredTrip').click(function(){
  $.post(templateUrl+"/library/bokun.php?checktrip=true", $( "#fpFilter" ).serialize(), function(data){
    console.log(data);
  });
})
