'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

!function ($) {

  "use strict";

  var FOUNDATION_VERSION = '6.3.0';

  // Global Foundation object
  // This is attached to the window, or used as a module for AMD/Browserify
  var Foundation = {
    version: FOUNDATION_VERSION,

    /**
     * Stores initialized plugins.
     */
    _plugins: {},

    /**
     * Stores generated unique ids for plugin instances
     */
    _uuids: [],

    /**
     * Returns a boolean for RTL support
     */
    rtl: function rtl() {
      return $('html').attr('dir') === 'rtl';
    },
    /**
     * Defines a Foundation plugin, adding it to the `Foundation` namespace and the list of plugins to initialize when reflowing.
     * @param {Object} plugin - The constructor of the plugin.
     */
    plugin: function plugin(_plugin, name) {
      // Object key to use when adding to global Foundation object
      // Examples: Foundation.Reveal, Foundation.OffCanvas
      var className = name || functionName(_plugin);
      // Object key to use when storing the plugin, also used to create the identifying data attribute for the plugin
      // Examples: data-reveal, data-off-canvas
      var attrName = hyphenate(className);

      // Add to the Foundation object and the plugins list (for reflowing)
      this._plugins[attrName] = this[className] = _plugin;
    },
    /**
     * @function
     * Populates the _uuids array with pointers to each individual plugin instance.
     * Adds the `zfPlugin` data-attribute to programmatically created plugins to allow use of $(selector).foundation(method) calls.
     * Also fires the initialization event for each plugin, consolidating repetitive code.
     * @param {Object} plugin - an instance of a plugin, usually `this` in context.
     * @param {String} name - the name of the plugin, passed as a camelCased string.
     * @fires Plugin#init
     */
    registerPlugin: function registerPlugin(plugin, name) {
      var pluginName = name ? hyphenate(name) : functionName(plugin.constructor).toLowerCase();
      plugin.uuid = this.GetYoDigits(6, pluginName);

      if (!plugin.$element.attr('data-' + pluginName)) {
        plugin.$element.attr('data-' + pluginName, plugin.uuid);
      }
      if (!plugin.$element.data('zfPlugin')) {
        plugin.$element.data('zfPlugin', plugin);
      }
      /**
       * Fires when the plugin has initialized.
       * @event Plugin#init
       */
      plugin.$element.trigger('init.zf.' + pluginName);

      this._uuids.push(plugin.uuid);

      return;
    },
    /**
     * @function
     * Removes the plugins uuid from the _uuids array.
     * Removes the zfPlugin data attribute, as well as the data-plugin-name attribute.
     * Also fires the destroyed event for the plugin, consolidating repetitive code.
     * @param {Object} plugin - an instance of a plugin, usually `this` in context.
     * @fires Plugin#destroyed
     */
    unregisterPlugin: function unregisterPlugin(plugin) {
      var pluginName = hyphenate(functionName(plugin.$element.data('zfPlugin').constructor));

      this._uuids.splice(this._uuids.indexOf(plugin.uuid), 1);
      plugin.$element.removeAttr('data-' + pluginName).removeData('zfPlugin')
      /**
       * Fires when the plugin has been destroyed.
       * @event Plugin#destroyed
       */
      .trigger('destroyed.zf.' + pluginName);
      for (var prop in plugin) {
        plugin[prop] = null; //clean up script to prep for garbage collection.
      }
      return;
    },

    /**
     * @function
     * Causes one or more active plugins to re-initialize, resetting event listeners, recalculating positions, etc.
     * @param {String} plugins - optional string of an individual plugin key, attained by calling `$(element).data('pluginName')`, or string of a plugin class i.e. `'dropdown'`
     * @default If no argument is passed, reflow all currently active plugins.
     */
    reInit: function reInit(plugins) {
      var isJQ = plugins instanceof $;
      try {
        if (isJQ) {
          plugins.each(function () {
            $(this).data('zfPlugin')._init();
          });
        } else {
          var type = typeof plugins === 'undefined' ? 'undefined' : _typeof(plugins),
              _this = this,
              fns = {
            'object': function object(plgs) {
              plgs.forEach(function (p) {
                p = hyphenate(p);
                $('[data-' + p + ']').foundation('_init');
              });
            },
            'string': function string() {
              plugins = hyphenate(plugins);
              $('[data-' + plugins + ']').foundation('_init');
            },
            'undefined': function undefined() {
              this['object'](Object.keys(_this._plugins));
            }
          };
          fns[type](plugins);
        }
      } catch (err) {
        console.error(err);
      } finally {
        return plugins;
      }
    },

    /**
     * returns a random base-36 uid with namespacing
     * @function
     * @param {Number} length - number of random base-36 digits desired. Increase for more random strings.
     * @param {String} namespace - name of plugin to be incorporated in uid, optional.
     * @default {String} '' - if no plugin name is provided, nothing is appended to the uid.
     * @returns {String} - unique id
     */
    GetYoDigits: function GetYoDigits(length, namespace) {
      length = length || 6;
      return Math.round(Math.pow(36, length + 1) - Math.random() * Math.pow(36, length)).toString(36).slice(1) + (namespace ? '-' + namespace : '');
    },
    /**
     * Initialize plugins on any elements within `elem` (and `elem` itself) that aren't already initialized.
     * @param {Object} elem - jQuery object containing the element to check inside. Also checks the element itself, unless it's the `document` object.
     * @param {String|Array} plugins - A list of plugins to initialize. Leave this out to initialize everything.
     */
    reflow: function reflow(elem, plugins) {

      // If plugins is undefined, just grab everything
      if (typeof plugins === 'undefined') {
        plugins = Object.keys(this._plugins);
      }
      // If plugins is a string, convert it to an array with one item
      else if (typeof plugins === 'string') {
          plugins = [plugins];
        }

      var _this = this;

      // Iterate through each plugin
      $.each(plugins, function (i, name) {
        // Get the current plugin
        var plugin = _this._plugins[name];

        // Localize the search to all elements inside elem, as well as elem itself, unless elem === document
        var $elem = $(elem).find('[data-' + name + ']').addBack('[data-' + name + ']');

        // For each plugin found, initialize it
        $elem.each(function () {
          var $el = $(this),
              opts = {};
          // Don't double-dip on plugins
          if ($el.data('zfPlugin')) {
            console.warn("Tried to initialize " + name + " on an element that already has a Foundation plugin.");
            return;
          }

          if ($el.attr('data-options')) {
            var thing = $el.attr('data-options').split(';').forEach(function (e, i) {
              var opt = e.split(':').map(function (el) {
                return el.trim();
              });
              if (opt[0]) opts[opt[0]] = parseValue(opt[1]);
            });
          }
          try {
            $el.data('zfPlugin', new plugin($(this), opts));
          } catch (er) {
            console.error(er);
          } finally {
            return;
          }
        });
      });
    },
    getFnName: functionName,
    transitionend: function transitionend($elem) {
      var transitions = {
        'transition': 'transitionend',
        'WebkitTransition': 'webkitTransitionEnd',
        'MozTransition': 'transitionend',
        'OTransition': 'otransitionend'
      };
      var elem = document.createElement('div'),
          end;

      for (var t in transitions) {
        if (typeof elem.style[t] !== 'undefined') {
          end = transitions[t];
        }
      }
      if (end) {
        return end;
      } else {
        end = setTimeout(function () {
          $elem.triggerHandler('transitionend', [$elem]);
        }, 1);
        return 'transitionend';
      }
    }
  };

  Foundation.util = {
    /**
     * Function for applying a debounce effect to a function call.
     * @function
     * @param {Function} func - Function to be called at end of timeout.
     * @param {Number} delay - Time in ms to delay the call of `func`.
     * @returns function
     */
    throttle: function throttle(func, delay) {
      var timer = null;

      return function () {
        var context = this,
            args = arguments;

        if (timer === null) {
          timer = setTimeout(function () {
            func.apply(context, args);
            timer = null;
          }, delay);
        }
      };
    }
  };

  // TODO: consider not making this a jQuery function
  // TODO: need way to reflow vs. re-initialize
  /**
   * The Foundation jQuery method.
   * @param {String|Array} method - An action to perform on the current jQuery object.
   */
  var foundation = function foundation(method) {
    var type = typeof method === 'undefined' ? 'undefined' : _typeof(method),
        $meta = $('meta.foundation-mq'),
        $noJS = $('.no-js');

    if (!$meta.length) {
      $('<meta class="foundation-mq">').appendTo(document.head);
    }
    if ($noJS.length) {
      $noJS.removeClass('no-js');
    }

    if (type === 'undefined') {
      //needs to initialize the Foundation object, or an individual plugin.
      Foundation.MediaQuery._init();
      Foundation.reflow(this);
    } else if (type === 'string') {
      //an individual method to invoke on a plugin or group of plugins
      var args = Array.prototype.slice.call(arguments, 1); //collect all the arguments, if necessary
      var plugClass = this.data('zfPlugin'); //determine the class of plugin

      if (plugClass !== undefined && plugClass[method] !== undefined) {
        //make sure both the class and method exist
        if (this.length === 1) {
          //if there's only one, call it directly.
          plugClass[method].apply(plugClass, args);
        } else {
          this.each(function (i, el) {
            //otherwise loop through the jQuery collection and invoke the method on each
            plugClass[method].apply($(el).data('zfPlugin'), args);
          });
        }
      } else {
        //error for no class or no method
        throw new ReferenceError("We're sorry, '" + method + "' is not an available method for " + (plugClass ? functionName(plugClass) : 'this element') + '.');
      }
    } else {
      //error for invalid argument type
      throw new TypeError('We\'re sorry, ' + type + ' is not a valid parameter. You must use a string representing the method you wish to invoke.');
    }
    return this;
  };

  window.Foundation = Foundation;
  $.fn.foundation = foundation;

  // Polyfill for requestAnimationFrame
  (function () {
    if (!Date.now || !window.Date.now) window.Date.now = Date.now = function () {
      return new Date().getTime();
    };

    var vendors = ['webkit', 'moz'];
    for (var i = 0; i < vendors.length && !window.requestAnimationFrame; ++i) {
      var vp = vendors[i];
      window.requestAnimationFrame = window[vp + 'RequestAnimationFrame'];
      window.cancelAnimationFrame = window[vp + 'CancelAnimationFrame'] || window[vp + 'CancelRequestAnimationFrame'];
    }
    if (/iP(ad|hone|od).*OS 6/.test(window.navigator.userAgent) || !window.requestAnimationFrame || !window.cancelAnimationFrame) {
      var lastTime = 0;
      window.requestAnimationFrame = function (callback) {
        var now = Date.now();
        var nextTime = Math.max(lastTime + 16, now);
        return setTimeout(function () {
          callback(lastTime = nextTime);
        }, nextTime - now);
      };
      window.cancelAnimationFrame = clearTimeout;
    }
    /**
     * Polyfill for performance.now, required by rAF
     */
    if (!window.performance || !window.performance.now) {
      window.performance = {
        start: Date.now(),
        now: function now() {
          return Date.now() - this.start;
        }
      };
    }
  })();
  if (!Function.prototype.bind) {
    Function.prototype.bind = function (oThis) {
      if (typeof this !== 'function') {
        // closest thing possible to the ECMAScript 5
        // internal IsCallable function
        throw new TypeError('Function.prototype.bind - what is trying to be bound is not callable');
      }

      var aArgs = Array.prototype.slice.call(arguments, 1),
          fToBind = this,
          fNOP = function fNOP() {},
          fBound = function fBound() {
        return fToBind.apply(this instanceof fNOP ? this : oThis, aArgs.concat(Array.prototype.slice.call(arguments)));
      };

      if (this.prototype) {
        // native functions don't have a prototype
        fNOP.prototype = this.prototype;
      }
      fBound.prototype = new fNOP();

      return fBound;
    };
  }
  // Polyfill to get the name of a function in IE9
  function functionName(fn) {
    if (Function.prototype.name === undefined) {
      var funcNameRegex = /function\s([^(]{1,})\(/;
      var results = funcNameRegex.exec(fn.toString());
      return results && results.length > 1 ? results[1].trim() : "";
    } else if (fn.prototype === undefined) {
      return fn.constructor.name;
    } else {
      return fn.prototype.constructor.name;
    }
  }
  function parseValue(str) {
    if ('true' === str) return true;else if ('false' === str) return false;else if (!isNaN(str * 1)) return parseFloat(str);
    return str;
  }
  // Convert PascalCase to kebab-case
  // Thank you: http://stackoverflow.com/a/8955580
  function hyphenate(str) {
    return str.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
  }
}(jQuery);
;'use strict';

!function ($) {

  Foundation.Box = {
    ImNotTouchingYou: ImNotTouchingYou,
    GetDimensions: GetDimensions,
    GetOffsets: GetOffsets

    /**
     * Compares the dimensions of an element to a container and determines collision events with container.
     * @function
     * @param {jQuery} element - jQuery object to test for collisions.
     * @param {jQuery} parent - jQuery object to use as bounding container.
     * @param {Boolean} lrOnly - set to true to check left and right values only.
     * @param {Boolean} tbOnly - set to true to check top and bottom values only.
     * @default if no parent object passed, detects collisions with `window`.
     * @returns {Boolean} - true if collision free, false if a collision in any direction.
     */
  };function ImNotTouchingYou(element, parent, lrOnly, tbOnly) {
    var eleDims = GetDimensions(element),
        top,
        bottom,
        left,
        right;

    if (parent) {
      var parDims = GetDimensions(parent);

      bottom = eleDims.offset.top + eleDims.height <= parDims.height + parDims.offset.top;
      top = eleDims.offset.top >= parDims.offset.top;
      left = eleDims.offset.left >= parDims.offset.left;
      right = eleDims.offset.left + eleDims.width <= parDims.width + parDims.offset.left;
    } else {
      bottom = eleDims.offset.top + eleDims.height <= eleDims.windowDims.height + eleDims.windowDims.offset.top;
      top = eleDims.offset.top >= eleDims.windowDims.offset.top;
      left = eleDims.offset.left >= eleDims.windowDims.offset.left;
      right = eleDims.offset.left + eleDims.width <= eleDims.windowDims.width;
    }

    var allDirs = [bottom, top, left, right];

    if (lrOnly) {
      return left === right === true;
    }

    if (tbOnly) {
      return top === bottom === true;
    }

    return allDirs.indexOf(false) === -1;
  };

  /**
   * Uses native methods to return an object of dimension values.
   * @function
   * @param {jQuery || HTML} element - jQuery object or DOM element for which to get the dimensions. Can be any element other that document or window.
   * @returns {Object} - nested object of integer pixel values
   * TODO - if element is window, return only those values.
   */
  function GetDimensions(elem, test) {
    elem = elem.length ? elem[0] : elem;

    if (elem === window || elem === document) {
      throw new Error("I'm sorry, Dave. I'm afraid I can't do that.");
    }

    var rect = elem.getBoundingClientRect(),
        parRect = elem.parentNode.getBoundingClientRect(),
        winRect = document.body.getBoundingClientRect(),
        winY = window.pageYOffset,
        winX = window.pageXOffset;

    return {
      width: rect.width,
      height: rect.height,
      offset: {
        top: rect.top + winY,
        left: rect.left + winX
      },
      parentDims: {
        width: parRect.width,
        height: parRect.height,
        offset: {
          top: parRect.top + winY,
          left: parRect.left + winX
        }
      },
      windowDims: {
        width: winRect.width,
        height: winRect.height,
        offset: {
          top: winY,
          left: winX
        }
      }
    };
  }

  /**
   * Returns an object of top and left integer pixel values for dynamically rendered elements,
   * such as: Tooltip, Reveal, and Dropdown
   * @function
   * @param {jQuery} element - jQuery object for the element being positioned.
   * @param {jQuery} anchor - jQuery object for the element's anchor point.
   * @param {String} position - a string relating to the desired position of the element, relative to it's anchor
   * @param {Number} vOffset - integer pixel value of desired vertical separation between anchor and element.
   * @param {Number} hOffset - integer pixel value of desired horizontal separation between anchor and element.
   * @param {Boolean} isOverflow - if a collision event is detected, sets to true to default the element to full width - any desired offset.
   * TODO alter/rewrite to work with `em` values as well/instead of pixels
   */
  function GetOffsets(element, anchor, position, vOffset, hOffset, isOverflow) {
    var $eleDims = GetDimensions(element),
        $anchorDims = anchor ? GetDimensions(anchor) : null;

    switch (position) {
      case 'top':
        return {
          left: Foundation.rtl() ? $anchorDims.offset.left - $eleDims.width + $anchorDims.width : $anchorDims.offset.left,
          top: $anchorDims.offset.top - ($eleDims.height + vOffset)
        };
        break;
      case 'left':
        return {
          left: $anchorDims.offset.left - ($eleDims.width + hOffset),
          top: $anchorDims.offset.top
        };
        break;
      case 'right':
        return {
          left: $anchorDims.offset.left + $anchorDims.width + hOffset,
          top: $anchorDims.offset.top
        };
        break;
      case 'center top':
        return {
          left: $anchorDims.offset.left + $anchorDims.width / 2 - $eleDims.width / 2,
          top: $anchorDims.offset.top - ($eleDims.height + vOffset)
        };
        break;
      case 'center bottom':
        return {
          left: isOverflow ? hOffset : $anchorDims.offset.left + $anchorDims.width / 2 - $eleDims.width / 2,
          top: $anchorDims.offset.top + $anchorDims.height + vOffset
        };
        break;
      case 'center left':
        return {
          left: $anchorDims.offset.left - ($eleDims.width + hOffset),
          top: $anchorDims.offset.top + $anchorDims.height / 2 - $eleDims.height / 2
        };
        break;
      case 'center right':
        return {
          left: $anchorDims.offset.left + $anchorDims.width + hOffset + 1,
          top: $anchorDims.offset.top + $anchorDims.height / 2 - $eleDims.height / 2
        };
        break;
      case 'center':
        return {
          left: $eleDims.windowDims.offset.left + $eleDims.windowDims.width / 2 - $eleDims.width / 2,
          top: $eleDims.windowDims.offset.top + $eleDims.windowDims.height / 2 - $eleDims.height / 2
        };
        break;
      case 'reveal':
        return {
          left: ($eleDims.windowDims.width - $eleDims.width) / 2,
          top: $eleDims.windowDims.offset.top + vOffset
        };
      case 'reveal full':
        return {
          left: $eleDims.windowDims.offset.left,
          top: $eleDims.windowDims.offset.top
        };
        break;
      case 'left bottom':
        return {
          left: $anchorDims.offset.left,
          top: $anchorDims.offset.top + $anchorDims.height + vOffset
        };
        break;
      case 'right bottom':
        return {
          left: $anchorDims.offset.left + $anchorDims.width + hOffset - $eleDims.width,
          top: $anchorDims.offset.top + $anchorDims.height + vOffset
        };
        break;
      default:
        return {
          left: Foundation.rtl() ? $anchorDims.offset.left - $eleDims.width + $anchorDims.width : $anchorDims.offset.left + hOffset,
          top: $anchorDims.offset.top + $anchorDims.height + vOffset
        };
    }
  }
}(jQuery);
;/*******************************************
 *                                         *
 * This util was created by Marius Olbertz *
 * Please thank Marius on GitHub /owlbertz *
 * or the web http://www.mariusolbertz.de/ *
 *                                         *
 ******************************************/

'use strict';

!function ($) {

  var keyCodes = {
    9: 'TAB',
    13: 'ENTER',
    27: 'ESCAPE',
    32: 'SPACE',
    37: 'ARROW_LEFT',
    38: 'ARROW_UP',
    39: 'ARROW_RIGHT',
    40: 'ARROW_DOWN'
  };

  var commands = {};

  var Keyboard = {
    keys: getKeyCodes(keyCodes),

    /**
     * Parses the (keyboard) event and returns a String that represents its key
     * Can be used like Foundation.parseKey(event) === Foundation.keys.SPACE
     * @param {Event} event - the event generated by the event handler
     * @return String key - String that represents the key pressed
     */
    parseKey: function parseKey(event) {
      var key = keyCodes[event.which || event.keyCode] || String.fromCharCode(event.which).toUpperCase();

      // Remove un-printable characters, e.g. for `fromCharCode` calls for CTRL only events
      key = key.replace(/\W+/, '');

      if (event.shiftKey) key = 'SHIFT_' + key;
      if (event.ctrlKey) key = 'CTRL_' + key;
      if (event.altKey) key = 'ALT_' + key;

      // Remove trailing underscore, in case only modifiers were used (e.g. only `CTRL_ALT`)
      key = key.replace(/_$/, '');

      return key;
    },


    /**
     * Handles the given (keyboard) event
     * @param {Event} event - the event generated by the event handler
     * @param {String} component - Foundation component's name, e.g. Slider or Reveal
     * @param {Objects} functions - collection of functions that are to be executed
     */
    handleKey: function handleKey(event, component, functions) {
      var commandList = commands[component],
          keyCode = this.parseKey(event),
          cmds,
          command,
          fn;

      if (!commandList) return console.warn('Component not defined!');

      if (typeof commandList.ltr === 'undefined') {
        // this component does not differentiate between ltr and rtl
        cmds = commandList; // use plain list
      } else {
        // merge ltr and rtl: if document is rtl, rtl overwrites ltr and vice versa
        if (Foundation.rtl()) cmds = $.extend({}, commandList.ltr, commandList.rtl);else cmds = $.extend({}, commandList.rtl, commandList.ltr);
      }
      command = cmds[keyCode];

      fn = functions[command];
      if (fn && typeof fn === 'function') {
        // execute function  if exists
        var returnValue = fn.apply();
        if (functions.handled || typeof functions.handled === 'function') {
          // execute function when event was handled
          functions.handled(returnValue);
        }
      } else {
        if (functions.unhandled || typeof functions.unhandled === 'function') {
          // execute function when event was not handled
          functions.unhandled();
        }
      }
    },


    /**
     * Finds all focusable elements within the given `$element`
     * @param {jQuery} $element - jQuery object to search within
     * @return {jQuery} $focusable - all focusable elements within `$element`
     */
    findFocusable: function findFocusable($element) {
      if (!$element) {
        return false;
      }
      return $element.find('a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, *[tabindex], *[contenteditable]').filter(function () {
        if (!$(this).is(':visible') || $(this).attr('tabindex') < 0) {
          return false;
        } //only have visible elements and those that have a tabindex greater or equal 0
        return true;
      });
    },


    /**
     * Returns the component name name
     * @param {Object} component - Foundation component, e.g. Slider or Reveal
     * @return String componentName
     */

    register: function register(componentName, cmds) {
      commands[componentName] = cmds;
    },


    /**
     * Traps the focus in the given element.
     * @param  {jQuery} $element  jQuery object to trap the foucs into.
     */
    trapFocus: function trapFocus($element) {
      var $focusable = Foundation.Keyboard.findFocusable($element),
          $firstFocusable = $focusable.eq(0),
          $lastFocusable = $focusable.eq(-1);

      $element.on('keydown.zf.trapfocus', function (event) {
        if (event.target === $lastFocusable[0] && Foundation.Keyboard.parseKey(event) === 'TAB') {
          event.preventDefault();
          $firstFocusable.focus();
        } else if (event.target === $firstFocusable[0] && Foundation.Keyboard.parseKey(event) === 'SHIFT_TAB') {
          event.preventDefault();
          $lastFocusable.focus();
        }
      });
    },

    /**
     * Releases the trapped focus from the given element.
     * @param  {jQuery} $element  jQuery object to release the focus for.
     */
    releaseFocus: function releaseFocus($element) {
      $element.off('keydown.zf.trapfocus');
    }
  };

  /*
   * Constants for easier comparing.
   * Can be used like Foundation.parseKey(event) === Foundation.keys.SPACE
   */
  function getKeyCodes(kcs) {
    var k = {};
    for (var kc in kcs) {
      k[kcs[kc]] = kcs[kc];
    }return k;
  }

  Foundation.Keyboard = Keyboard;
}(jQuery);
;'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

!function ($) {

  // Default set of media queries
  var defaultQueries = {
    'default': 'only screen',
    landscape: 'only screen and (orientation: landscape)',
    portrait: 'only screen and (orientation: portrait)',
    retina: 'only screen and (-webkit-min-device-pixel-ratio: 2),' + 'only screen and (min--moz-device-pixel-ratio: 2),' + 'only screen and (-o-min-device-pixel-ratio: 2/1),' + 'only screen and (min-device-pixel-ratio: 2),' + 'only screen and (min-resolution: 192dpi),' + 'only screen and (min-resolution: 2dppx)'
  };

  var MediaQuery = {
    queries: [],

    current: '',

    /**
     * Initializes the media query helper, by extracting the breakpoint list from the CSS and activating the breakpoint watcher.
     * @function
     * @private
     */
    _init: function _init() {
      var self = this;
      var extractedStyles = $('.foundation-mq').css('font-family');
      var namedQueries;

      namedQueries = parseStyleToObject(extractedStyles);

      for (var key in namedQueries) {
        if (namedQueries.hasOwnProperty(key)) {
          self.queries.push({
            name: key,
            value: 'only screen and (min-width: ' + namedQueries[key] + ')'
          });
        }
      }

      this.current = this._getCurrentSize();

      this._watcher();
    },


    /**
     * Checks if the screen is at least as wide as a breakpoint.
     * @function
     * @param {String} size - Name of the breakpoint to check.
     * @returns {Boolean} `true` if the breakpoint matches, `false` if it's smaller.
     */
    atLeast: function atLeast(size) {
      var query = this.get(size);

      if (query) {
        return window.matchMedia(query).matches;
      }

      return false;
    },


    /**
     * Checks if the screen matches to a breakpoint.
     * @function
     * @param {String} size - Name of the breakpoint to check, either 'small only' or 'small'. Omitting 'only' falls back to using atLeast() method.
     * @returns {Boolean} `true` if the breakpoint matches, `false` if it does not.
     */
    is: function is(size) {
      size = size.trim().split(' ');
      if (size.length > 1 && size[1] === 'only') {
        if (size[0] === this._getCurrentSize()) return true;
      } else {
        return this.atLeast(size[0]);
      }
      return false;
    },


    /**
     * Gets the media query of a breakpoint.
     * @function
     * @param {String} size - Name of the breakpoint to get.
     * @returns {String|null} - The media query of the breakpoint, or `null` if the breakpoint doesn't exist.
     */
    get: function get(size) {
      for (var i in this.queries) {
        if (this.queries.hasOwnProperty(i)) {
          var query = this.queries[i];
          if (size === query.name) return query.value;
        }
      }

      return null;
    },


    /**
     * Gets the current breakpoint name by testing every breakpoint and returning the last one to match (the biggest one).
     * @function
     * @private
     * @returns {String} Name of the current breakpoint.
     */
    _getCurrentSize: function _getCurrentSize() {
      var matched;

      for (var i = 0; i < this.queries.length; i++) {
        var query = this.queries[i];

        if (window.matchMedia(query.value).matches) {
          matched = query;
        }
      }

      if ((typeof matched === 'undefined' ? 'undefined' : _typeof(matched)) === 'object') {
        return matched.name;
      } else {
        return matched;
      }
    },


    /**
     * Activates the breakpoint watcher, which fires an event on the window whenever the breakpoint changes.
     * @function
     * @private
     */
    _watcher: function _watcher() {
      var _this = this;

      $(window).on('resize.zf.mediaquery', function () {
        var newSize = _this._getCurrentSize(),
            currentSize = _this.current;

        if (newSize !== currentSize) {
          // Change the current media query
          _this.current = newSize;

          // Broadcast the media query change on the window
          $(window).trigger('changed.zf.mediaquery', [newSize, currentSize]);
        }
      });
    }
  };

  Foundation.MediaQuery = MediaQuery;

  // matchMedia() polyfill - Test a CSS media type/query in JS.
  // Authors & copyright (c) 2012: Scott Jehl, Paul Irish, Nicholas Zakas, David Knight. Dual MIT/BSD license
  window.matchMedia || (window.matchMedia = function () {
    'use strict';

    // For browsers that support matchMedium api such as IE 9 and webkit

    var styleMedia = window.styleMedia || window.media;

    // For those that don't support matchMedium
    if (!styleMedia) {
      var style = document.createElement('style'),
          script = document.getElementsByTagName('script')[0],
          info = null;

      style.type = 'text/css';
      style.id = 'matchmediajs-test';

      script && script.parentNode && script.parentNode.insertBefore(style, script);

      // 'style.currentStyle' is used by IE <= 8 and 'window.getComputedStyle' for all other browsers
      info = 'getComputedStyle' in window && window.getComputedStyle(style, null) || style.currentStyle;

      styleMedia = {
        matchMedium: function matchMedium(media) {
          var text = '@media ' + media + '{ #matchmediajs-test { width: 1px; } }';

          // 'style.styleSheet' is used by IE <= 8 and 'style.textContent' for all other browsers
          if (style.styleSheet) {
            style.styleSheet.cssText = text;
          } else {
            style.textContent = text;
          }

          // Test if media query is true or false
          return info.width === '1px';
        }
      };
    }

    return function (media) {
      return {
        matches: styleMedia.matchMedium(media || 'all'),
        media: media || 'all'
      };
    };
  }());

  // Thank you: https://github.com/sindresorhus/query-string
  function parseStyleToObject(str) {
    var styleObject = {};

    if (typeof str !== 'string') {
      return styleObject;
    }

    str = str.trim().slice(1, -1); // browsers re-quote string style values

    if (!str) {
      return styleObject;
    }

    styleObject = str.split('&').reduce(function (ret, param) {
      var parts = param.replace(/\+/g, ' ').split('=');
      var key = parts[0];
      var val = parts[1];
      key = decodeURIComponent(key);

      // missing `=` should be `null`:
      // http://w3.org/TR/2012/WD-url-20120524/#collect-url-parameters
      val = val === undefined ? null : decodeURIComponent(val);

      if (!ret.hasOwnProperty(key)) {
        ret[key] = val;
      } else if (Array.isArray(ret[key])) {
        ret[key].push(val);
      } else {
        ret[key] = [ret[key], val];
      }
      return ret;
    }, {});

    return styleObject;
  }

  Foundation.MediaQuery = MediaQuery;
}(jQuery);
;'use strict';

!function ($) {

  /**
   * Motion module.
   * @module foundation.motion
   */

  var initClasses = ['mui-enter', 'mui-leave'];
  var activeClasses = ['mui-enter-active', 'mui-leave-active'];

  var Motion = {
    animateIn: function animateIn(element, animation, cb) {
      animate(true, element, animation, cb);
    },

    animateOut: function animateOut(element, animation, cb) {
      animate(false, element, animation, cb);
    }
  };

  function Move(duration, elem, fn) {
    var anim,
        prog,
        start = null;
    // console.log('called');

    if (duration === 0) {
      fn.apply(elem);
      elem.trigger('finished.zf.animate', [elem]).triggerHandler('finished.zf.animate', [elem]);
      return;
    }

    function move(ts) {
      if (!start) start = ts;
      // console.log(start, ts);
      prog = ts - start;
      fn.apply(elem);

      if (prog < duration) {
        anim = window.requestAnimationFrame(move, elem);
      } else {
        window.cancelAnimationFrame(anim);
        elem.trigger('finished.zf.animate', [elem]).triggerHandler('finished.zf.animate', [elem]);
      }
    }
    anim = window.requestAnimationFrame(move);
  }

  /**
   * Animates an element in or out using a CSS transition class.
   * @function
   * @private
   * @param {Boolean} isIn - Defines if the animation is in or out.
   * @param {Object} element - jQuery or HTML object to animate.
   * @param {String} animation - CSS class to use.
   * @param {Function} cb - Callback to run when animation is finished.
   */
  function animate(isIn, element, animation, cb) {
    element = $(element).eq(0);

    if (!element.length) return;

    var initClass = isIn ? initClasses[0] : initClasses[1];
    var activeClass = isIn ? activeClasses[0] : activeClasses[1];

    // Set up the animation
    reset();

    element.addClass(animation).css('transition', 'none');

    requestAnimationFrame(function () {
      element.addClass(initClass);
      if (isIn) element.show();
    });

    // Start the animation
    requestAnimationFrame(function () {
      element[0].offsetWidth;
      element.css('transition', '').addClass(activeClass);
    });

    // Clean up the animation when it finishes
    element.one(Foundation.transitionend(element), finish);

    // Hides the element (for out animations), resets the element, and runs a callback
    function finish() {
      if (!isIn) element.hide();
      reset();
      if (cb) cb.apply(element);
    }

    // Resets transitions and removes motion-specific classes
    function reset() {
      element[0].style.transitionDuration = 0;
      element.removeClass(initClass + ' ' + activeClass + ' ' + animation);
    }
  }

  Foundation.Move = Move;
  Foundation.Motion = Motion;
}(jQuery);
;'use strict';

!function ($) {

  var Nest = {
    Feather: function Feather(menu) {
      var type = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'zf';

      menu.attr('role', 'menubar');

      var items = menu.find('li').attr({ 'role': 'menuitem' }),
          subMenuClass = 'is-' + type + '-submenu',
          subItemClass = subMenuClass + '-item',
          hasSubClass = 'is-' + type + '-submenu-parent';

      items.each(function () {
        var $item = $(this),
            $sub = $item.children('ul');

        if ($sub.length) {
          $item.addClass(hasSubClass).attr({
            'aria-haspopup': true,
            'aria-label': $item.children('a:first').text()
          });
          // Note:  Drilldowns behave differently in how they hide, and so need
          // additional attributes.  We should look if this possibly over-generalized
          // utility (Nest) is appropriate when we rework menus in 6.4
          if (type === 'drilldown') {
            $item.attr({ 'aria-expanded': false });
          }

          $sub.addClass('submenu ' + subMenuClass).attr({
            'data-submenu': '',
            'role': 'menu'
          });
          if (type === 'drilldown') {
            $sub.attr({ 'aria-hidden': true });
          }
        }

        if ($item.parent('[data-submenu]').length) {
          $item.addClass('is-submenu-item ' + subItemClass);
        }
      });

      return;
    },
    Burn: function Burn(menu, type) {
      var //items = menu.find('li'),
      subMenuClass = 'is-' + type + '-submenu',
          subItemClass = subMenuClass + '-item',
          hasSubClass = 'is-' + type + '-submenu-parent';

      menu.find('>li, .menu, .menu > li').removeClass(subMenuClass + ' ' + subItemClass + ' ' + hasSubClass + ' is-submenu-item submenu is-active').removeAttr('data-submenu').css('display', '');

      // console.log(      menu.find('.' + subMenuClass + ', .' + subItemClass + ', .has-submenu, .is-submenu-item, .submenu, [data-submenu]')
      //           .removeClass(subMenuClass + ' ' + subItemClass + ' has-submenu is-submenu-item submenu')
      //           .removeAttr('data-submenu'));
      // items.each(function(){
      //   var $item = $(this),
      //       $sub = $item.children('ul');
      //   if($item.parent('[data-submenu]').length){
      //     $item.removeClass('is-submenu-item ' + subItemClass);
      //   }
      //   if($sub.length){
      //     $item.removeClass('has-submenu');
      //     $sub.removeClass('submenu ' + subMenuClass).removeAttr('data-submenu');
      //   }
      // });
    }
  };

  Foundation.Nest = Nest;
}(jQuery);
;'use strict';

!function ($) {

  function Timer(elem, options, cb) {
    var _this = this,
        duration = options.duration,
        //options is an object for easily adding features later.
    nameSpace = Object.keys(elem.data())[0] || 'timer',
        remain = -1,
        start,
        timer;

    this.isPaused = false;

    this.restart = function () {
      remain = -1;
      clearTimeout(timer);
      this.start();
    };

    this.start = function () {
      this.isPaused = false;
      // if(!elem.data('paused')){ return false; }//maybe implement this sanity check if used for other things.
      clearTimeout(timer);
      remain = remain <= 0 ? duration : remain;
      elem.data('paused', false);
      start = Date.now();
      timer = setTimeout(function () {
        if (options.infinite) {
          _this.restart(); //rerun the timer.
        }
        if (cb && typeof cb === 'function') {
          cb();
        }
      }, remain);
      elem.trigger('timerstart.zf.' + nameSpace);
    };

    this.pause = function () {
      this.isPaused = true;
      //if(elem.data('paused')){ return false; }//maybe implement this sanity check if used for other things.
      clearTimeout(timer);
      elem.data('paused', true);
      var end = Date.now();
      remain = remain - (end - start);
      elem.trigger('timerpaused.zf.' + nameSpace);
    };
  }

  /**
   * Runs a callback function when images are fully loaded.
   * @param {Object} images - Image(s) to check if loaded.
   * @param {Func} callback - Function to execute when image is fully loaded.
   */
  function onImagesLoaded(images, callback) {
    var self = this,
        unloaded = images.length;

    if (unloaded === 0) {
      callback();
    }

    images.each(function () {
      // Check if image is loaded
      if (this.complete || this.readyState === 4 || this.readyState === 'complete') {
        singleImageLoaded();
      }
      // Force load the image
      else {
          // fix for IE. See https://css-tricks.com/snippets/jquery/fixing-load-in-ie-for-cached-images/
          var src = $(this).attr('src');
          $(this).attr('src', src + '?' + new Date().getTime());
          $(this).one('load', function () {
            singleImageLoaded();
          });
        }
    });

    function singleImageLoaded() {
      unloaded--;
      if (unloaded === 0) {
        callback();
      }
    }
  }

  Foundation.Timer = Timer;
  Foundation.onImagesLoaded = onImagesLoaded;
}(jQuery);
;'use strict';

//**************************************************
//**Work inspired by multiple jquery swipe plugins**
//**Done by Yohai Ararat ***************************
//**************************************************
(function ($) {

	$.spotSwipe = {
		version: '1.0.0',
		enabled: 'ontouchstart' in document.documentElement,
		preventDefault: false,
		moveThreshold: 75,
		timeThreshold: 200
	};

	var startPosX,
	    startPosY,
	    startTime,
	    elapsedTime,
	    isMoving = false;

	function onTouchEnd() {
		//  alert(this);
		this.removeEventListener('touchmove', onTouchMove);
		this.removeEventListener('touchend', onTouchEnd);
		isMoving = false;
	}

	function onTouchMove(e) {
		if ($.spotSwipe.preventDefault) {
			e.preventDefault();
		}
		if (isMoving) {
			var x = e.touches[0].pageX;
			var y = e.touches[0].pageY;
			var dx = startPosX - x;
			var dy = startPosY - y;
			var dir;
			elapsedTime = new Date().getTime() - startTime;
			if (Math.abs(dx) >= $.spotSwipe.moveThreshold && elapsedTime <= $.spotSwipe.timeThreshold) {
				dir = dx > 0 ? 'left' : 'right';
			}
			// else if(Math.abs(dy) >= $.spotSwipe.moveThreshold && elapsedTime <= $.spotSwipe.timeThreshold) {
			//   dir = dy > 0 ? 'down' : 'up';
			// }
			if (dir) {
				e.preventDefault();
				onTouchEnd.call(this);
				$(this).trigger('swipe', dir).trigger('swipe' + dir);
			}
		}
	}

	function onTouchStart(e) {
		if (e.touches.length == 1) {
			startPosX = e.touches[0].pageX;
			startPosY = e.touches[0].pageY;
			isMoving = true;
			startTime = new Date().getTime();
			this.addEventListener('touchmove', onTouchMove, false);
			this.addEventListener('touchend', onTouchEnd, false);
		}
	}

	function init() {
		this.addEventListener && this.addEventListener('touchstart', onTouchStart, false);
	}

	function teardown() {
		this.removeEventListener('touchstart', onTouchStart);
	}

	$.event.special.swipe = { setup: init };

	$.each(['left', 'up', 'down', 'right'], function () {
		$.event.special['swipe' + this] = { setup: function setup() {
				$(this).on('swipe', $.noop);
			} };
	});
})(jQuery);
/****************************************************
 * Method for adding psuedo drag events to elements *
 ***************************************************/
!function ($) {
	$.fn.addTouch = function () {
		this.each(function (i, el) {
			$(el).bind('touchstart touchmove touchend touchcancel', function () {
				//we pass the original event object because the jQuery event
				//object is normalized to w3c specs and does not provide the TouchList
				handleTouch(event);
			});
		});

		var handleTouch = function handleTouch(event) {
			var touches = event.changedTouches,
			    first = touches[0],
			    eventTypes = {
				touchstart: 'mousedown',
				touchmove: 'mousemove',
				touchend: 'mouseup'
			},
			    type = eventTypes[event.type],
			    simulatedEvent;

			if ('MouseEvent' in window && typeof window.MouseEvent === 'function') {
				simulatedEvent = new window.MouseEvent(type, {
					'bubbles': true,
					'cancelable': true,
					'screenX': first.screenX,
					'screenY': first.screenY,
					'clientX': first.clientX,
					'clientY': first.clientY
				});
			} else {
				simulatedEvent = document.createEvent('MouseEvent');
				simulatedEvent.initMouseEvent(type, true, true, window, 1, first.screenX, first.screenY, first.clientX, first.clientY, false, false, false, false, 0 /*left*/, null);
			}
			first.target.dispatchEvent(simulatedEvent);
		};
	};
}(jQuery);

//**********************************
//**From the jQuery Mobile Library**
//**need to recreate functionality**
//**and try to improve if possible**
//**********************************

/* Removing the jQuery function ****
************************************

(function( $, window, undefined ) {

	var $document = $( document ),
		// supportTouch = $.mobile.support.touch,
		touchStartEvent = 'touchstart'//supportTouch ? "touchstart" : "mousedown",
		touchStopEvent = 'touchend'//supportTouch ? "touchend" : "mouseup",
		touchMoveEvent = 'touchmove'//supportTouch ? "touchmove" : "mousemove";

	// setup new event shortcuts
	$.each( ( "touchstart touchmove touchend " +
		"swipe swipeleft swiperight" ).split( " " ), function( i, name ) {

		$.fn[ name ] = function( fn ) {
			return fn ? this.bind( name, fn ) : this.trigger( name );
		};

		// jQuery < 1.8
		if ( $.attrFn ) {
			$.attrFn[ name ] = true;
		}
	});

	function triggerCustomEvent( obj, eventType, event, bubble ) {
		var originalType = event.type;
		event.type = eventType;
		if ( bubble ) {
			$.event.trigger( event, undefined, obj );
		} else {
			$.event.dispatch.call( obj, event );
		}
		event.type = originalType;
	}

	// also handles taphold

	// Also handles swipeleft, swiperight
	$.event.special.swipe = {

		// More than this horizontal displacement, and we will suppress scrolling.
		scrollSupressionThreshold: 30,

		// More time than this, and it isn't a swipe.
		durationThreshold: 1000,

		// Swipe horizontal displacement must be more than this.
		horizontalDistanceThreshold: window.devicePixelRatio >= 2 ? 15 : 30,

		// Swipe vertical displacement must be less than this.
		verticalDistanceThreshold: window.devicePixelRatio >= 2 ? 15 : 30,

		getLocation: function ( event ) {
			var winPageX = window.pageXOffset,
				winPageY = window.pageYOffset,
				x = event.clientX,
				y = event.clientY;

			if ( event.pageY === 0 && Math.floor( y ) > Math.floor( event.pageY ) ||
				event.pageX === 0 && Math.floor( x ) > Math.floor( event.pageX ) ) {

				// iOS4 clientX/clientY have the value that should have been
				// in pageX/pageY. While pageX/page/ have the value 0
				x = x - winPageX;
				y = y - winPageY;
			} else if ( y < ( event.pageY - winPageY) || x < ( event.pageX - winPageX ) ) {

				// Some Android browsers have totally bogus values for clientX/Y
				// when scrolling/zooming a page. Detectable since clientX/clientY
				// should never be smaller than pageX/pageY minus page scroll
				x = event.pageX - winPageX;
				y = event.pageY - winPageY;
			}

			return {
				x: x,
				y: y
			};
		},

		start: function( event ) {
			var data = event.originalEvent.touches ?
					event.originalEvent.touches[ 0 ] : event,
				location = $.event.special.swipe.getLocation( data );
			return {
						time: ( new Date() ).getTime(),
						coords: [ location.x, location.y ],
						origin: $( event.target )
					};
		},

		stop: function( event ) {
			var data = event.originalEvent.touches ?
					event.originalEvent.touches[ 0 ] : event,
				location = $.event.special.swipe.getLocation( data );
			return {
						time: ( new Date() ).getTime(),
						coords: [ location.x, location.y ]
					};
		},

		handleSwipe: function( start, stop, thisObject, origTarget ) {
			if ( stop.time - start.time < $.event.special.swipe.durationThreshold &&
				Math.abs( start.coords[ 0 ] - stop.coords[ 0 ] ) > $.event.special.swipe.horizontalDistanceThreshold &&
				Math.abs( start.coords[ 1 ] - stop.coords[ 1 ] ) < $.event.special.swipe.verticalDistanceThreshold ) {
				var direction = start.coords[0] > stop.coords[ 0 ] ? "swipeleft" : "swiperight";

				triggerCustomEvent( thisObject, "swipe", $.Event( "swipe", { target: origTarget, swipestart: start, swipestop: stop }), true );
				triggerCustomEvent( thisObject, direction,$.Event( direction, { target: origTarget, swipestart: start, swipestop: stop } ), true );
				return true;
			}
			return false;

		},

		// This serves as a flag to ensure that at most one swipe event event is
		// in work at any given time
		eventInProgress: false,

		setup: function() {
			var events,
				thisObject = this,
				$this = $( thisObject ),
				context = {};

			// Retrieve the events data for this element and add the swipe context
			events = $.data( this, "mobile-events" );
			if ( !events ) {
				events = { length: 0 };
				$.data( this, "mobile-events", events );
			}
			events.length++;
			events.swipe = context;

			context.start = function( event ) {

				// Bail if we're already working on a swipe event
				if ( $.event.special.swipe.eventInProgress ) {
					return;
				}
				$.event.special.swipe.eventInProgress = true;

				var stop,
					start = $.event.special.swipe.start( event ),
					origTarget = event.target,
					emitted = false;

				context.move = function( event ) {
					if ( !start || event.isDefaultPrevented() ) {
						return;
					}

					stop = $.event.special.swipe.stop( event );
					if ( !emitted ) {
						emitted = $.event.special.swipe.handleSwipe( start, stop, thisObject, origTarget );
						if ( emitted ) {

							// Reset the context to make way for the next swipe event
							$.event.special.swipe.eventInProgress = false;
						}
					}
					// prevent scrolling
					if ( Math.abs( start.coords[ 0 ] - stop.coords[ 0 ] ) > $.event.special.swipe.scrollSupressionThreshold ) {
						event.preventDefault();
					}
				};

				context.stop = function() {
						emitted = true;

						// Reset the context to make way for the next swipe event
						$.event.special.swipe.eventInProgress = false;
						$document.off( touchMoveEvent, context.move );
						context.move = null;
				};

				$document.on( touchMoveEvent, context.move )
					.one( touchStopEvent, context.stop );
			};
			$this.on( touchStartEvent, context.start );
		},

		teardown: function() {
			var events, context;

			events = $.data( this, "mobile-events" );
			if ( events ) {
				context = events.swipe;
				delete events.swipe;
				events.length--;
				if ( events.length === 0 ) {
					$.removeData( this, "mobile-events" );
				}
			}

			if ( context ) {
				if ( context.start ) {
					$( this ).off( touchStartEvent, context.start );
				}
				if ( context.move ) {
					$document.off( touchMoveEvent, context.move );
				}
				if ( context.stop ) {
					$document.off( touchStopEvent, context.stop );
				}
			}
		}
	};
	$.each({
		swipeleft: "swipe.left",
		swiperight: "swipe.right"
	}, function( event, sourceEvent ) {

		$.event.special[ event ] = {
			setup: function() {
				$( this ).bind( sourceEvent, $.noop );
			},
			teardown: function() {
				$( this ).unbind( sourceEvent );
			}
		};
	});
})( jQuery, this );
*/
;'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

!function ($) {

  var MutationObserver = function () {
    var prefixes = ['WebKit', 'Moz', 'O', 'Ms', ''];
    for (var i = 0; i < prefixes.length; i++) {
      if (prefixes[i] + 'MutationObserver' in window) {
        return window[prefixes[i] + 'MutationObserver'];
      }
    }
    return false;
  }();

  var triggers = function triggers(el, type) {
    el.data(type).split(' ').forEach(function (id) {
      $('#' + id)[type === 'close' ? 'trigger' : 'triggerHandler'](type + '.zf.trigger', [el]);
    });
  };
  // Elements with [data-open] will reveal a plugin that supports it when clicked.
  $(document).on('click.zf.trigger', '[data-open]', function () {
    triggers($(this), 'open');
  });

  // Elements with [data-close] will close a plugin that supports it when clicked.
  // If used without a value on [data-close], the event will bubble, allowing it to close a parent component.
  $(document).on('click.zf.trigger', '[data-close]', function () {
    var id = $(this).data('close');
    if (id) {
      triggers($(this), 'close');
    } else {
      $(this).trigger('close.zf.trigger');
    }
  });

  // Elements with [data-toggle] will toggle a plugin that supports it when clicked.
  $(document).on('click.zf.trigger', '[data-toggle]', function () {
    var id = $(this).data('toggle');
    if (id) {
      triggers($(this), 'toggle');
    } else {
      $(this).trigger('toggle.zf.trigger');
    }
  });

  // Elements with [data-closable] will respond to close.zf.trigger events.
  $(document).on('close.zf.trigger', '[data-closable]', function (e) {
    e.stopPropagation();
    var animation = $(this).data('closable');

    if (animation !== '') {
      Foundation.Motion.animateOut($(this), animation, function () {
        $(this).trigger('closed.zf');
      });
    } else {
      $(this).fadeOut().trigger('closed.zf');
    }
  });

  $(document).on('focus.zf.trigger blur.zf.trigger', '[data-toggle-focus]', function () {
    var id = $(this).data('toggle-focus');
    $('#' + id).triggerHandler('toggle.zf.trigger', [$(this)]);
  });

  /**
  * Fires once after all other scripts have loaded
  * @function
  * @private
  */
  $(window).on('load', function () {
    checkListeners();
  });

  function checkListeners() {
    eventsListener();
    resizeListener();
    scrollListener();
    mutateListener();
    closemeListener();
  }

  //******** only fires this function once on load, if there's something to watch ********
  function closemeListener(pluginName) {
    var yetiBoxes = $('[data-yeti-box]'),
        plugNames = ['dropdown', 'tooltip', 'reveal'];

    if (pluginName) {
      if (typeof pluginName === 'string') {
        plugNames.push(pluginName);
      } else if ((typeof pluginName === 'undefined' ? 'undefined' : _typeof(pluginName)) === 'object' && typeof pluginName[0] === 'string') {
        plugNames.concat(pluginName);
      } else {
        console.error('Plugin names must be strings');
      }
    }
    if (yetiBoxes.length) {
      var listeners = plugNames.map(function (name) {
        return 'closeme.zf.' + name;
      }).join(' ');

      $(window).off(listeners).on(listeners, function (e, pluginId) {
        var plugin = e.namespace.split('.')[0];
        var plugins = $('[data-' + plugin + ']').not('[data-yeti-box="' + pluginId + '"]');

        plugins.each(function () {
          var _this = $(this);

          _this.triggerHandler('close.zf.trigger', [_this]);
        });
      });
    }
  }

  function resizeListener(debounce) {
    var timer = void 0,
        $nodes = $('[data-resize]');
    if ($nodes.length) {
      $(window).off('resize.zf.trigger').on('resize.zf.trigger', function (e) {
        if (timer) {
          clearTimeout(timer);
        }

        timer = setTimeout(function () {

          if (!MutationObserver) {
            //fallback for IE 9
            $nodes.each(function () {
              $(this).triggerHandler('resizeme.zf.trigger');
            });
          }
          //trigger all listening elements and signal a resize event
          $nodes.attr('data-events', "resize");
        }, debounce || 10); //default time to emit resize event
      });
    }
  }

  function scrollListener(debounce) {
    var timer = void 0,
        $nodes = $('[data-scroll]');
    if ($nodes.length) {
      $(window).off('scroll.zf.trigger').on('scroll.zf.trigger', function (e) {
        if (timer) {
          clearTimeout(timer);
        }

        timer = setTimeout(function () {

          if (!MutationObserver) {
            //fallback for IE 9
            $nodes.each(function () {
              $(this).triggerHandler('scrollme.zf.trigger');
            });
          }
          //trigger all listening elements and signal a scroll event
          $nodes.attr('data-events', "scroll");
        }, debounce || 10); //default time to emit scroll event
      });
    }
  }

  function mutateListener(debounce) {
    var $nodes = $('[data-mutate]');
    if ($nodes.length && MutationObserver) {
      //trigger all listening elements and signal a mutate event
      //no IE 9 or 10
      $nodes.each(function () {
        $(this).triggerHandler('mutateme.zf.trigger');
      });
    }
  }

  function eventsListener() {
    if (!MutationObserver) {
      return false;
    }
    var nodes = document.querySelectorAll('[data-resize], [data-scroll], [data-mutate]');

    //element callback
    var listeningElementsMutation = function listeningElementsMutation(mutationRecordsList) {
      var $target = $(mutationRecordsList[0].target);

      //trigger the event handler for the element depending on type
      switch (mutationRecordsList[0].type) {

        case "attributes":
          if ($target.attr("data-events") === "scroll" && mutationRecordsList[0].attributeName === "data-events") {
            $target.triggerHandler('scrollme.zf.trigger', [$target, window.pageYOffset]);
          }
          if ($target.attr("data-events") === "resize" && mutationRecordsList[0].attributeName === "data-events") {
            $target.triggerHandler('resizeme.zf.trigger', [$target]);
          }
          if (mutationRecordsList[0].attributeName === "style") {
            $target.closest("[data-mutate]").attr("data-events", "mutate");
            $target.closest("[data-mutate]").triggerHandler('mutateme.zf.trigger', [$target.closest("[data-mutate]")]);
          }
          break;

        case "childList":
          $target.closest("[data-mutate]").attr("data-events", "mutate");
          $target.closest("[data-mutate]").triggerHandler('mutateme.zf.trigger', [$target.closest("[data-mutate]")]);
          break;

        default:
          return false;
        //nothing
      }
    };

    if (nodes.length) {
      //for each element that needs to listen for resizing, scrolling, or mutation add a single observer
      for (var i = 0; i <= nodes.length - 1; i++) {
        var elementObserver = new MutationObserver(listeningElementsMutation);
        elementObserver.observe(nodes[i], { attributes: true, childList: true, characterData: false, subtree: true, attributeFilter: ["data-events", "style"] });
      }
    }
  }

  // ------------------------------------

  // [PH]
  // Foundation.CheckWatchers = checkWatchers;
  Foundation.IHearYou = checkListeners;
  // Foundation.ISeeYou = scrollListener;
  // Foundation.IFeelYou = closemeListener;
}(jQuery);

// function domMutationObserver(debounce) {
//   // !!! This is coming soon and needs more work; not active  !!! //
//   var timer,
//   nodes = document.querySelectorAll('[data-mutate]');
//   //
//   if (nodes.length) {
//     // var MutationObserver = (function () {
//     //   var prefixes = ['WebKit', 'Moz', 'O', 'Ms', ''];
//     //   for (var i=0; i < prefixes.length; i++) {
//     //     if (prefixes[i] + 'MutationObserver' in window) {
//     //       return window[prefixes[i] + 'MutationObserver'];
//     //     }
//     //   }
//     //   return false;
//     // }());
//
//
//     //for the body, we need to listen for all changes effecting the style and class attributes
//     var bodyObserver = new MutationObserver(bodyMutation);
//     bodyObserver.observe(document.body, { attributes: true, childList: true, characterData: false, subtree:true, attributeFilter:["style", "class"]});
//
//
//     //body callback
//     function bodyMutation(mutate) {
//       //trigger all listening elements and signal a mutation event
//       if (timer) { clearTimeout(timer); }
//
//       timer = setTimeout(function() {
//         bodyObserver.disconnect();
//         $('[data-mutate]').attr('data-events',"mutate");
//       }, debounce || 150);
//     }
//   }
// }
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * AccordionMenu module.
   * @module foundation.accordionMenu
   * @requires foundation.util.keyboard
   * @requires foundation.util.motion
   * @requires foundation.util.nest
   */

  var AccordionMenu = function () {
    /**
     * Creates a new instance of an accordion menu.
     * @class
     * @fires AccordionMenu#init
     * @param {jQuery} element - jQuery object to make into an accordion menu.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function AccordionMenu(element, options) {
      _classCallCheck(this, AccordionMenu);

      this.$element = element;
      this.options = $.extend({}, AccordionMenu.defaults, this.$element.data(), options);

      Foundation.Nest.Feather(this.$element, 'accordion');

      this._init();

      Foundation.registerPlugin(this, 'AccordionMenu');
      Foundation.Keyboard.register('AccordionMenu', {
        'ENTER': 'toggle',
        'SPACE': 'toggle',
        'ARROW_RIGHT': 'open',
        'ARROW_UP': 'up',
        'ARROW_DOWN': 'down',
        'ARROW_LEFT': 'close',
        'ESCAPE': 'closeAll'
      });
    }

    /**
     * Initializes the accordion menu by hiding all nested menus.
     * @private
     */


    _createClass(AccordionMenu, [{
      key: '_init',
      value: function _init() {
        this.$element.find('[data-submenu]').not('.is-active').slideUp(0); //.find('a').css('padding-left', '1rem');
        this.$element.attr({
          'role': 'menu',
          'aria-multiselectable': this.options.multiOpen
        });

        this.$menuLinks = this.$element.find('.is-accordion-submenu-parent');
        this.$menuLinks.each(function () {
          var linkId = this.id || Foundation.GetYoDigits(6, 'acc-menu-link'),
              $elem = $(this),
              $sub = $elem.children('[data-submenu]'),
              subId = $sub[0].id || Foundation.GetYoDigits(6, 'acc-menu'),
              isActive = $sub.hasClass('is-active');
          $elem.attr({
            'aria-controls': subId,
            'aria-expanded': isActive,
            'role': 'menuitem',
            'id': linkId
          });
          $sub.attr({
            'aria-labelledby': linkId,
            'aria-hidden': !isActive,
            'role': 'menu',
            'id': subId
          });
        });
        var initPanes = this.$element.find('.is-active');
        if (initPanes.length) {
          var _this = this;
          initPanes.each(function () {
            _this.down($(this));
          });
        }
        this._events();
      }

      /**
       * Adds event handlers for items within the menu.
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this;

        this.$element.find('li').each(function () {
          var $submenu = $(this).children('[data-submenu]');

          if ($submenu.length) {
            $(this).children('a').off('click.zf.accordionMenu').on('click.zf.accordionMenu', function (e) {
              e.preventDefault();

              _this.toggle($submenu);
            });
          }
        }).on('keydown.zf.accordionmenu', function (e) {
          var $element = $(this),
              $elements = $element.parent('ul').children('li'),
              $prevElement,
              $nextElement,
              $target = $element.children('[data-submenu]');

          $elements.each(function (i) {
            if ($(this).is($element)) {
              $prevElement = $elements.eq(Math.max(0, i - 1)).find('a').first();
              $nextElement = $elements.eq(Math.min(i + 1, $elements.length - 1)).find('a').first();

              if ($(this).children('[data-submenu]:visible').length) {
                // has open sub menu
                $nextElement = $element.find('li:first-child').find('a').first();
              }
              if ($(this).is(':first-child')) {
                // is first element of sub menu
                $prevElement = $element.parents('li').first().find('a').first();
              } else if ($prevElement.parents('li').first().children('[data-submenu]:visible').length) {
                // if previous element has open sub menu
                $prevElement = $prevElement.parents('li').find('li:last-child').find('a').first();
              }
              if ($(this).is(':last-child')) {
                // is last element of sub menu
                $nextElement = $element.parents('li').first().next('li').find('a').first();
              }

              return;
            }
          });

          Foundation.Keyboard.handleKey(e, 'AccordionMenu', {
            open: function open() {
              if ($target.is(':hidden')) {
                _this.down($target);
                $target.find('li').first().find('a').first().focus();
              }
            },
            close: function close() {
              if ($target.length && !$target.is(':hidden')) {
                // close active sub of this item
                _this.up($target);
              } else if ($element.parent('[data-submenu]').length) {
                // close currently open sub
                _this.up($element.parent('[data-submenu]'));
                $element.parents('li').first().find('a').first().focus();
              }
            },
            up: function up() {
              $prevElement.focus();
              return true;
            },
            down: function down() {
              $nextElement.focus();
              return true;
            },
            toggle: function toggle() {
              if ($element.children('[data-submenu]').length) {
                _this.toggle($element.children('[data-submenu]'));
              }
            },
            closeAll: function closeAll() {
              _this.hideAll();
            },
            handled: function handled(preventDefault) {
              if (preventDefault) {
                e.preventDefault();
              }
              e.stopImmediatePropagation();
            }
          });
        }); //.attr('tabindex', 0);
      }

      /**
       * Closes all panes of the menu.
       * @function
       */

    }, {
      key: 'hideAll',
      value: function hideAll() {
        this.up(this.$element.find('[data-submenu]'));
      }

      /**
       * Opens all panes of the menu.
       * @function
       */

    }, {
      key: 'showAll',
      value: function showAll() {
        this.down(this.$element.find('[data-submenu]'));
      }

      /**
       * Toggles the open/close state of a submenu.
       * @function
       * @param {jQuery} $target - the submenu to toggle
       */

    }, {
      key: 'toggle',
      value: function toggle($target) {
        if (!$target.is(':animated')) {
          if (!$target.is(':hidden')) {
            this.up($target);
          } else {
            this.down($target);
          }
        }
      }

      /**
       * Opens the sub-menu defined by `$target`.
       * @param {jQuery} $target - Sub-menu to open.
       * @fires AccordionMenu#down
       */

    }, {
      key: 'down',
      value: function down($target) {
        var _this = this;

        if (!this.options.multiOpen) {
          this.up(this.$element.find('.is-active').not($target.parentsUntil(this.$element).add($target)));
        }

        $target.addClass('is-active').attr({ 'aria-hidden': false }).parent('.is-accordion-submenu-parent').attr({ 'aria-expanded': true });

        //Foundation.Move(this.options.slideSpeed, $target, function() {
        $target.slideDown(_this.options.slideSpeed, function () {
          /**
           * Fires when the menu is done opening.
           * @event AccordionMenu#down
           */
          _this.$element.trigger('down.zf.accordionMenu', [$target]);
        });
        //});
      }

      /**
       * Closes the sub-menu defined by `$target`. All sub-menus inside the target will be closed as well.
       * @param {jQuery} $target - Sub-menu to close.
       * @fires AccordionMenu#up
       */

    }, {
      key: 'up',
      value: function up($target) {
        var _this = this;
        //Foundation.Move(this.options.slideSpeed, $target, function(){
        $target.slideUp(_this.options.slideSpeed, function () {
          /**
           * Fires when the menu is done collapsing up.
           * @event AccordionMenu#up
           */
          _this.$element.trigger('up.zf.accordionMenu', [$target]);
        });
        //});

        var $menus = $target.find('[data-submenu]').slideUp(0).addBack().attr('aria-hidden', true);

        $menus.parent('.is-accordion-submenu-parent').attr('aria-expanded', false);
      }

      /**
       * Destroys an instance of accordion menu.
       * @fires AccordionMenu#destroyed
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.$element.find('[data-submenu]').slideDown(0).css('display', '');
        this.$element.find('a').off('click.zf.accordionMenu');

        Foundation.Nest.Burn(this.$element, 'accordion');
        Foundation.unregisterPlugin(this);
      }
    }]);

    return AccordionMenu;
  }();

  AccordionMenu.defaults = {
    /**
     * Amount of time to animate the opening of a submenu in ms.
     * @option
     * @example 250
     */
    slideSpeed: 250,
    /**
     * Allow the menu to have multiple open panes.
     * @option
     * @example true
     */
    multiOpen: true
  };

  // Window exports
  Foundation.plugin(AccordionMenu, 'AccordionMenu');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * Drilldown module.
   * @module foundation.drilldown
   * @requires foundation.util.keyboard
   * @requires foundation.util.motion
   * @requires foundation.util.nest
   */

  var Drilldown = function () {
    /**
     * Creates a new instance of a drilldown menu.
     * @class
     * @param {jQuery} element - jQuery object to make into an accordion menu.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function Drilldown(element, options) {
      _classCallCheck(this, Drilldown);

      this.$element = element;
      this.options = $.extend({}, Drilldown.defaults, this.$element.data(), options);

      Foundation.Nest.Feather(this.$element, 'drilldown');

      this._init();

      Foundation.registerPlugin(this, 'Drilldown');
      Foundation.Keyboard.register('Drilldown', {
        'ENTER': 'open',
        'SPACE': 'open',
        'ARROW_RIGHT': 'next',
        'ARROW_UP': 'up',
        'ARROW_DOWN': 'down',
        'ARROW_LEFT': 'previous',
        'ESCAPE': 'close',
        'TAB': 'down',
        'SHIFT_TAB': 'up'
      });
    }

    /**
     * Initializes the drilldown by creating jQuery collections of elements
     * @private
     */


    _createClass(Drilldown, [{
      key: '_init',
      value: function _init() {
        this.$submenuAnchors = this.$element.find('li.is-drilldown-submenu-parent').children('a');
        this.$submenus = this.$submenuAnchors.parent('li').children('[data-submenu]');
        this.$menuItems = this.$element.find('li').not('.js-drilldown-back').attr('role', 'menuitem').find('a');
        this.$element.attr('data-mutate', this.$element.attr('data-drilldown') || Foundation.GetYoDigits(6, 'drilldown'));

        this._prepareMenu();
        this._registerEvents();

        this._keyboardEvents();
      }

      /**
       * prepares drilldown menu by setting attributes to links and elements
       * sets a min height to prevent content jumping
       * wraps the element if not already wrapped
       * @private
       * @function
       */

    }, {
      key: '_prepareMenu',
      value: function _prepareMenu() {
        var _this = this;
        // if(!this.options.holdOpen){
        //   this._menuLinkEvents();
        // }
        this.$submenuAnchors.each(function () {
          var $link = $(this);
          var $sub = $link.parent();
          if (_this.options.parentLink) {
            $link.clone().prependTo($sub.children('[data-submenu]')).wrap('<li class="is-submenu-parent-item is-submenu-item is-drilldown-submenu-item" role="menu-item"></li>');
          }
          $link.data('savedHref', $link.attr('href')).removeAttr('href').attr('tabindex', 0);
          $link.children('[data-submenu]').attr({
            'aria-hidden': true,
            'tabindex': 0,
            'role': 'menu'
          });
          _this._events($link);
        });
        this.$submenus.each(function () {
          var $menu = $(this),
              $back = $menu.find('.js-drilldown-back');
          if (!$back.length) {
            switch (_this.options.backButtonPosition) {
              case "bottom":
                $menu.append(_this.options.backButton);
                break;
              case "top":
                $menu.prepend(_this.options.backButton);
                break;
              default:
                console.error("Unsupported backButtonPosition value '" + _this.options.backButtonPosition + "'");
            }
          }
          _this._back($menu);
        });

        if (!this.options.autoHeight) {
          this.$submenus.addClass('drilldown-submenu-cover-previous');
        }

        if (!this.$element.parent().hasClass('is-drilldown')) {
          this.$wrapper = $(this.options.wrapper).addClass('is-drilldown');
          if (this.options.animateHeight) this.$wrapper.addClass('animate-height');
          this.$wrapper = this.$element.wrap(this.$wrapper).parent().css(this._getMaxDims());
        }
      }
    }, {
      key: '_resize',
      value: function _resize() {
        this.$wrapper.css({ 'max-width': 'none', 'min-height': 'none' });
        // _getMaxDims has side effects (boo) but calling it should update all other necessary heights & widths
        this.$wrapper.css(this._getMaxDims());
      }

      /**
       * Adds event handlers to elements in the menu.
       * @function
       * @private
       * @param {jQuery} $elem - the current menu item to add handlers to.
       */

    }, {
      key: '_events',
      value: function _events($elem) {
        var _this = this;

        $elem.off('click.zf.drilldown').on('click.zf.drilldown', function (e) {
          if ($(e.target).parentsUntil('ul', 'li').hasClass('is-drilldown-submenu-parent')) {
            e.stopImmediatePropagation();
            e.preventDefault();
          }

          // if(e.target !== e.currentTarget.firstElementChild){
          //   return false;
          // }
          _this._show($elem.parent('li'));

          if (_this.options.closeOnClick) {
            var $body = $('body');
            $body.off('.zf.drilldown').on('click.zf.drilldown', function (e) {
              if (e.target === _this.$element[0] || $.contains(_this.$element[0], e.target)) {
                return;
              }
              e.preventDefault();
              _this._hideAll();
              $body.off('.zf.drilldown');
            });
          }
        });
        this.$element.on('mutateme.zf.trigger', this._resize.bind(this));
      }

      /**
       * Adds event handlers to the menu element.
       * @function
       * @private
       */

    }, {
      key: '_registerEvents',
      value: function _registerEvents() {
        if (this.options.scrollTop) {
          this._bindHandler = this._scrollTop.bind(this);
          this.$element.on('open.zf.drilldown hide.zf.drilldown closed.zf.drilldown', this._bindHandler);
        }
      }

      /**
       * Scroll to Top of Element or data-scroll-top-element
       * @function
       * @fires Drilldown#scrollme
       */

    }, {
      key: '_scrollTop',
      value: function _scrollTop() {
        var _this = this;
        var $scrollTopElement = _this.options.scrollTopElement != '' ? $(_this.options.scrollTopElement) : _this.$element,
            scrollPos = parseInt($scrollTopElement.offset().top + _this.options.scrollTopOffset);
        $('html, body').stop(true).animate({ scrollTop: scrollPos }, _this.options.animationDuration, _this.options.animationEasing, function () {
          /**
            * Fires after the menu has scrolled
            * @event Drilldown#scrollme
            */
          if (this === $('html')[0]) _this.$element.trigger('scrollme.zf.drilldown');
        });
      }

      /**
       * Adds keydown event listener to `li`'s in the menu.
       * @private
       */

    }, {
      key: '_keyboardEvents',
      value: function _keyboardEvents() {
        var _this = this;

        this.$menuItems.add(this.$element.find('.js-drilldown-back > a, .is-submenu-parent-item > a')).on('keydown.zf.drilldown', function (e) {
          var $element = $(this),
              $elements = $element.parent('li').parent('ul').children('li').children('a'),
              $prevElement,
              $nextElement;

          $elements.each(function (i) {
            if ($(this).is($element)) {
              $prevElement = $elements.eq(Math.max(0, i - 1));
              $nextElement = $elements.eq(Math.min(i + 1, $elements.length - 1));
              return;
            }
          });

          Foundation.Keyboard.handleKey(e, 'Drilldown', {
            next: function next() {
              if ($element.is(_this.$submenuAnchors)) {
                _this._show($element.parent('li'));
                $element.parent('li').one(Foundation.transitionend($element), function () {
                  $element.parent('li').find('ul li a').filter(_this.$menuItems).first().focus();
                });
                return true;
              }
            },
            previous: function previous() {
              _this._hide($element.parent('li').parent('ul'));
              $element.parent('li').parent('ul').one(Foundation.transitionend($element), function () {
                setTimeout(function () {
                  $element.parent('li').parent('ul').parent('li').children('a').first().focus();
                }, 1);
              });
              return true;
            },
            up: function up() {
              $prevElement.focus();
              return true;
            },
            down: function down() {
              $nextElement.focus();
              return true;
            },
            close: function close() {
              _this._back();
              //_this.$menuItems.first().focus(); // focus to first element
            },
            open: function open() {
              if (!$element.is(_this.$menuItems)) {
                // not menu item means back button
                _this._hide($element.parent('li').parent('ul'));
                $element.parent('li').parent('ul').one(Foundation.transitionend($element), function () {
                  setTimeout(function () {
                    $element.parent('li').parent('ul').parent('li').children('a').first().focus();
                  }, 1);
                });
                return true;
              } else if ($element.is(_this.$submenuAnchors)) {
                _this._show($element.parent('li'));
                $element.parent('li').one(Foundation.transitionend($element), function () {
                  $element.parent('li').find('ul li a').filter(_this.$menuItems).first().focus();
                });
                return true;
              }
            },
            handled: function handled(preventDefault) {
              if (preventDefault) {
                e.preventDefault();
              }
              e.stopImmediatePropagation();
            }
          });
        }); // end keyboardAccess
      }

      /**
       * Closes all open elements, and returns to root menu.
       * @function
       * @fires Drilldown#closed
       */

    }, {
      key: '_hideAll',
      value: function _hideAll() {
        var $elem = this.$element.find('.is-drilldown-submenu.is-active').addClass('is-closing');
        if (this.options.autoHeight) this.$wrapper.css({ height: $elem.parent().closest('ul').data('calcHeight') });
        $elem.one(Foundation.transitionend($elem), function (e) {
          $elem.removeClass('is-active is-closing');
        });
        /**
         * Fires when the menu is fully closed.
         * @event Drilldown#closed
         */
        this.$element.trigger('closed.zf.drilldown');
      }

      /**
       * Adds event listener for each `back` button, and closes open menus.
       * @function
       * @fires Drilldown#back
       * @param {jQuery} $elem - the current sub-menu to add `back` event.
       */

    }, {
      key: '_back',
      value: function _back($elem) {
        var _this = this;
        $elem.off('click.zf.drilldown');
        $elem.children('.js-drilldown-back').on('click.zf.drilldown', function (e) {
          e.stopImmediatePropagation();
          // console.log('mouseup on back');
          _this._hide($elem);

          // If there is a parent submenu, call show
          var parentSubMenu = $elem.parent('li').parent('ul').parent('li');
          if (parentSubMenu.length) {
            _this._show(parentSubMenu);
          }
        });
      }

      /**
       * Adds event listener to menu items w/o submenus to close open menus on click.
       * @function
       * @private
       */

    }, {
      key: '_menuLinkEvents',
      value: function _menuLinkEvents() {
        var _this = this;
        this.$menuItems.not('.is-drilldown-submenu-parent').off('click.zf.drilldown').on('click.zf.drilldown', function (e) {
          // e.stopImmediatePropagation();
          setTimeout(function () {
            _this._hideAll();
          }, 0);
        });
      }

      /**
       * Opens a submenu.
       * @function
       * @fires Drilldown#open
       * @param {jQuery} $elem - the current element with a submenu to open, i.e. the `li` tag.
       */

    }, {
      key: '_show',
      value: function _show($elem) {
        if (this.options.autoHeight) this.$wrapper.css({ height: $elem.children('[data-submenu]').data('calcHeight') });
        $elem.attr('aria-expanded', true);
        $elem.children('[data-submenu]').addClass('is-active').attr('aria-hidden', false);
        /**
         * Fires when the submenu has opened.
         * @event Drilldown#open
         */
        this.$element.trigger('open.zf.drilldown', [$elem]);
      }
    }, {
      key: '_hide',


      /**
       * Hides a submenu
       * @function
       * @fires Drilldown#hide
       * @param {jQuery} $elem - the current sub-menu to hide, i.e. the `ul` tag.
       */
      value: function _hide($elem) {
        if (this.options.autoHeight) this.$wrapper.css({ height: $elem.parent().closest('ul').data('calcHeight') });
        var _this = this;
        $elem.parent('li').attr('aria-expanded', false);
        $elem.attr('aria-hidden', true).addClass('is-closing');
        $elem.addClass('is-closing').one(Foundation.transitionend($elem), function () {
          $elem.removeClass('is-active is-closing');
          $elem.blur();
        });
        /**
         * Fires when the submenu has closed.
         * @event Drilldown#hide
         */
        $elem.trigger('hide.zf.drilldown', [$elem]);
      }

      /**
       * Iterates through the nested menus to calculate the min-height, and max-width for the menu.
       * Prevents content jumping.
       * @function
       * @private
       */

    }, {
      key: '_getMaxDims',
      value: function _getMaxDims() {
        var maxHeight = 0,
            result = {},
            _this = this;
        this.$submenus.add(this.$element).each(function () {
          var numOfElems = $(this).children('li').length;
          var height = Foundation.Box.GetDimensions(this).height;
          maxHeight = height > maxHeight ? height : maxHeight;
          if (_this.options.autoHeight) {
            $(this).data('calcHeight', height);
            if (!$(this).hasClass('is-drilldown-submenu')) result['height'] = height;
          }
        });

        if (!this.options.autoHeight) result['min-height'] = maxHeight + 'px';

        result['max-width'] = this.$element[0].getBoundingClientRect().width + 'px';

        return result;
      }

      /**
       * Destroys the Drilldown Menu
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        if (this.options.scrollTop) this.$element.off('.zf.drilldown', this._bindHandler);
        this._hideAll();
        this.$element.off('mutateme.zf.trigger');
        Foundation.Nest.Burn(this.$element, 'drilldown');
        this.$element.unwrap().find('.js-drilldown-back, .is-submenu-parent-item').remove().end().find('.is-active, .is-closing, .is-drilldown-submenu').removeClass('is-active is-closing is-drilldown-submenu').end().find('[data-submenu]').removeAttr('aria-hidden tabindex role');
        this.$submenuAnchors.each(function () {
          $(this).off('.zf.drilldown');
        });

        this.$submenus.removeClass('drilldown-submenu-cover-previous');

        this.$element.find('a').each(function () {
          var $link = $(this);
          $link.removeAttr('tabindex');
          if ($link.data('savedHref')) {
            $link.attr('href', $link.data('savedHref')).removeData('savedHref');
          } else {
            return;
          }
        });
        Foundation.unregisterPlugin(this);
      }
    }]);

    return Drilldown;
  }();

  Drilldown.defaults = {
    /**
     * Markup used for JS generated back button. Prepended  or appended (see backButtonPosition) to submenu lists and deleted on `destroy` method, 'js-drilldown-back' class required. Remove the backslash (`\`) if copy and pasting.
     * @option
     * @example '<\li><\a>Back<\/a><\/li>'
     */
    backButton: '<li class="js-drilldown-back"><a tabindex="0">Back</a></li>',
    /**
     * Position the back button either at the top or bottom of drilldown submenus.
     * @option
     * @example bottom
     */
    backButtonPosition: 'top',
    /**
     * Markup used to wrap drilldown menu. Use a class name for independent styling; the JS applied class: `is-drilldown` is required. Remove the backslash (`\`) if copy and pasting.
     * @option
     * @example '<\div class="is-drilldown"><\/div>'
     */
    wrapper: '<div></div>',
    /**
     * Adds the parent link to the submenu.
     * @option
     * @example false
     */
    parentLink: false,
    /**
     * Allow the menu to return to root list on body click.
     * @option
     * @example false
     */
    closeOnClick: false,
    /**
     * Allow the menu to auto adjust height.
     * @option
     * @example false
     */
    autoHeight: false,
    /**
     * Animate the auto adjust height.
     * @option
     * @example false
     */
    animateHeight: false,
    /**
     * Scroll to the top of the menu after opening a submenu or navigating back using the menu back button
     * @option
     * @example false
     */
    scrollTop: false,
    /**
     * String jquery selector (for example 'body') of element to take offset().top from, if empty string the drilldown menu offset().top is taken
     * @option
     * @example ''
     */
    scrollTopElement: '',
    /**
     * ScrollTop offset
     * @option
     * @example 100
     */
    scrollTopOffset: 0,
    /**
     * Scroll animation duration
     * @option
     * @example 500
     */
    animationDuration: 500,
    /**
     * Scroll animation easing
     * @option
     * @example 'swing'
     */
    animationEasing: 'swing'
    // holdOpen: false
  };

  // Window exports
  Foundation.plugin(Drilldown, 'Drilldown');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * Dropdown module.
   * @module foundation.dropdown
   * @requires foundation.util.keyboard
   * @requires foundation.util.box
   * @requires foundation.util.triggers
   */

  var Dropdown = function () {
    /**
     * Creates a new instance of a dropdown.
     * @class
     * @param {jQuery} element - jQuery object to make into a dropdown.
     *        Object should be of the dropdown panel, rather than its anchor.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function Dropdown(element, options) {
      _classCallCheck(this, Dropdown);

      this.$element = element;
      this.options = $.extend({}, Dropdown.defaults, this.$element.data(), options);
      this._init();

      Foundation.registerPlugin(this, 'Dropdown');
      Foundation.Keyboard.register('Dropdown', {
        'ENTER': 'open',
        'SPACE': 'open',
        'ESCAPE': 'close'
      });
    }

    /**
     * Initializes the plugin by setting/checking options and attributes, adding helper variables, and saving the anchor.
     * @function
     * @private
     */


    _createClass(Dropdown, [{
      key: '_init',
      value: function _init() {
        var $id = this.$element.attr('id');

        this.$anchor = $('[data-toggle="' + $id + '"]').length ? $('[data-toggle="' + $id + '"]') : $('[data-open="' + $id + '"]');
        this.$anchor.attr({
          'aria-controls': $id,
          'data-is-focus': false,
          'data-yeti-box': $id,
          'aria-haspopup': true,
          'aria-expanded': false

        });

        if (this.options.parentClass) {
          this.$parent = this.$element.parents('.' + this.options.parentClass);
        } else {
          this.$parent = null;
        }
        this.options.positionClass = this.getPositionClass();
        this.counter = 4;
        this.usedPositions = [];
        this.$element.attr({
          'aria-hidden': 'true',
          'data-yeti-box': $id,
          'data-resize': $id,
          'aria-labelledby': this.$anchor[0].id || Foundation.GetYoDigits(6, 'dd-anchor')
        });
        this._events();
      }

      /**
       * Helper function to determine current orientation of dropdown pane.
       * @function
       * @returns {String} position - string value of a position class.
       */

    }, {
      key: 'getPositionClass',
      value: function getPositionClass() {
        var verticalPosition = this.$element[0].className.match(/(top|left|right|bottom)/g);
        verticalPosition = verticalPosition ? verticalPosition[0] : '';
        var horizontalPosition = /float-(\S+)/.exec(this.$anchor[0].className);
        horizontalPosition = horizontalPosition ? horizontalPosition[1] : '';
        var position = horizontalPosition ? horizontalPosition + ' ' + verticalPosition : verticalPosition;

        return position;
      }

      /**
       * Adjusts the dropdown panes orientation by adding/removing positioning classes.
       * @function
       * @private
       * @param {String} position - position class to remove.
       */

    }, {
      key: '_reposition',
      value: function _reposition(position) {
        this.usedPositions.push(position ? position : 'bottom');
        //default, try switching to opposite side
        if (!position && this.usedPositions.indexOf('top') < 0) {
          this.$element.addClass('top');
        } else if (position === 'top' && this.usedPositions.indexOf('bottom') < 0) {
          this.$element.removeClass(position);
        } else if (position === 'left' && this.usedPositions.indexOf('right') < 0) {
          this.$element.removeClass(position).addClass('right');
        } else if (position === 'right' && this.usedPositions.indexOf('left') < 0) {
          this.$element.removeClass(position).addClass('left');
        }

        //if default change didn't work, try bottom or left first
        else if (!position && this.usedPositions.indexOf('top') > -1 && this.usedPositions.indexOf('left') < 0) {
            this.$element.addClass('left');
          } else if (position === 'top' && this.usedPositions.indexOf('bottom') > -1 && this.usedPositions.indexOf('left') < 0) {
            this.$element.removeClass(position).addClass('left');
          } else if (position === 'left' && this.usedPositions.indexOf('right') > -1 && this.usedPositions.indexOf('bottom') < 0) {
            this.$element.removeClass(position);
          } else if (position === 'right' && this.usedPositions.indexOf('left') > -1 && this.usedPositions.indexOf('bottom') < 0) {
            this.$element.removeClass(position);
          }
          //if nothing cleared, set to bottom
          else {
              this.$element.removeClass(position);
            }
        this.classChanged = true;
        this.counter--;
      }

      /**
       * Sets the position and orientation of the dropdown pane, checks for collisions.
       * Recursively calls itself if a collision is detected, with a new position class.
       * @function
       * @private
       */

    }, {
      key: '_setPosition',
      value: function _setPosition() {
        if (this.$anchor.attr('aria-expanded') === 'false') {
          return false;
        }
        var position = this.getPositionClass(),
            $eleDims = Foundation.Box.GetDimensions(this.$element),
            $anchorDims = Foundation.Box.GetDimensions(this.$anchor),
            _this = this,
            direction = position === 'left' ? 'left' : position === 'right' ? 'left' : 'top',
            param = direction === 'top' ? 'height' : 'width',
            offset = param === 'height' ? this.options.vOffset : this.options.hOffset;

        if ($eleDims.width >= $eleDims.windowDims.width || !this.counter && !Foundation.Box.ImNotTouchingYou(this.$element, this.$parent)) {
          var newWidth = $eleDims.windowDims.width,
              parentHOffset = 0;
          if (this.$parent) {
            var $parentDims = Foundation.Box.GetDimensions(this.$parent),
                parentHOffset = $parentDims.offset.left;
            if ($parentDims.width < newWidth) {
              newWidth = $parentDims.width;
            }
          }

          this.$element.offset(Foundation.Box.GetOffsets(this.$element, this.$anchor, 'center bottom', this.options.vOffset, this.options.hOffset + parentHOffset, true)).css({
            'width': newWidth - this.options.hOffset * 2,
            'height': 'auto'
          });
          this.classChanged = true;
          return false;
        }

        this.$element.offset(Foundation.Box.GetOffsets(this.$element, this.$anchor, position, this.options.vOffset, this.options.hOffset));

        while (!Foundation.Box.ImNotTouchingYou(this.$element, this.$parent, true) && this.counter) {
          this._reposition(position);
          this._setPosition();
        }
      }

      /**
       * Adds event listeners to the element utilizing the triggers utility library.
       * @function
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this;
        this.$element.on({
          'open.zf.trigger': this.open.bind(this),
          'close.zf.trigger': this.close.bind(this),
          'toggle.zf.trigger': this.toggle.bind(this),
          'resizeme.zf.trigger': this._setPosition.bind(this)
        });

        if (this.options.hover) {
          this.$anchor.off('mouseenter.zf.dropdown mouseleave.zf.dropdown').on('mouseenter.zf.dropdown', function () {
            var bodyData = $('body').data();
            if (typeof bodyData.whatinput === 'undefined' || bodyData.whatinput === 'mouse') {
              clearTimeout(_this.timeout);
              _this.timeout = setTimeout(function () {
                _this.open();
                _this.$anchor.data('hover', true);
              }, _this.options.hoverDelay);
            }
          }).on('mouseleave.zf.dropdown', function () {
            clearTimeout(_this.timeout);
            _this.timeout = setTimeout(function () {
              _this.close();
              _this.$anchor.data('hover', false);
            }, _this.options.hoverDelay);
          });
          if (this.options.hoverPane) {
            this.$element.off('mouseenter.zf.dropdown mouseleave.zf.dropdown').on('mouseenter.zf.dropdown', function () {
              clearTimeout(_this.timeout);
            }).on('mouseleave.zf.dropdown', function () {
              clearTimeout(_this.timeout);
              _this.timeout = setTimeout(function () {
                _this.close();
                _this.$anchor.data('hover', false);
              }, _this.options.hoverDelay);
            });
          }
        }
        this.$anchor.add(this.$element).on('keydown.zf.dropdown', function (e) {

          var $target = $(this),
              visibleFocusableElements = Foundation.Keyboard.findFocusable(_this.$element);

          Foundation.Keyboard.handleKey(e, 'Dropdown', {
            open: function open() {
              if ($target.is(_this.$anchor)) {
                _this.open();
                _this.$element.attr('tabindex', -1).focus();
                e.preventDefault();
              }
            },
            close: function close() {
              _this.close();
              _this.$anchor.focus();
            }
          });
        });
      }

      /**
       * Adds an event handler to the body to close any dropdowns on a click.
       * @function
       * @private
       */

    }, {
      key: '_addBodyHandler',
      value: function _addBodyHandler() {
        var $body = $(document.body).not(this.$element),
            _this = this;
        $body.off('click.zf.dropdown').on('click.zf.dropdown', function (e) {
          if (_this.$anchor.is(e.target) || _this.$anchor.find(e.target).length) {
            return;
          }
          if (_this.$element.find(e.target).length) {
            return;
          }
          _this.close();
          $body.off('click.zf.dropdown');
        });
      }

      /**
       * Opens the dropdown pane, and fires a bubbling event to close other dropdowns.
       * @function
       * @fires Dropdown#closeme
       * @fires Dropdown#show
       */

    }, {
      key: 'open',
      value: function open() {
        // var _this = this;
        /**
         * Fires to close other open dropdowns
         * @event Dropdown#closeme
         */
        this.$element.trigger('closeme.zf.dropdown', this.$element.attr('id'));
        this.$anchor.addClass('hover').attr({ 'aria-expanded': true });
        // this.$element/*.show()*/;
        this._setPosition();
        this.$element.addClass('is-open').attr({ 'aria-hidden': false });

        if (this.options.autoFocus) {
          var $focusable = Foundation.Keyboard.findFocusable(this.$element);
          if ($focusable.length) {
            $focusable.eq(0).focus();
          }
        }

        if (this.options.closeOnClick) {
          this._addBodyHandler();
        }

        if (this.options.trapFocus) {
          Foundation.Keyboard.trapFocus(this.$element);
        }

        /**
         * Fires once the dropdown is visible.
         * @event Dropdown#show
         */
        this.$element.trigger('show.zf.dropdown', [this.$element]);
      }

      /**
       * Closes the open dropdown pane.
       * @function
       * @fires Dropdown#hide
       */

    }, {
      key: 'close',
      value: function close() {
        if (!this.$element.hasClass('is-open')) {
          return false;
        }
        this.$element.removeClass('is-open').attr({ 'aria-hidden': true });

        this.$anchor.removeClass('hover').attr('aria-expanded', false);

        if (this.classChanged) {
          var curPositionClass = this.getPositionClass();
          if (curPositionClass) {
            this.$element.removeClass(curPositionClass);
          }
          this.$element.addClass(this.options.positionClass)
          /*.hide()*/.css({ height: '', width: '' });
          this.classChanged = false;
          this.counter = 4;
          this.usedPositions.length = 0;
        }
        this.$element.trigger('hide.zf.dropdown', [this.$element]);

        if (this.options.trapFocus) {
          Foundation.Keyboard.releaseFocus(this.$element);
        }
      }

      /**
       * Toggles the dropdown pane's visibility.
       * @function
       */

    }, {
      key: 'toggle',
      value: function toggle() {
        if (this.$element.hasClass('is-open')) {
          if (this.$anchor.data('hover')) return;
          this.close();
        } else {
          this.open();
        }
      }

      /**
       * Destroys the dropdown.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.$element.off('.zf.trigger').hide();
        this.$anchor.off('.zf.dropdown');

        Foundation.unregisterPlugin(this);
      }
    }]);

    return Dropdown;
  }();

  Dropdown.defaults = {
    /**
     * Class that designates bounding container of Dropdown (Default: window)
     * @option
     * @example 'dropdown-parent'
     */
    parentClass: null,
    /**
     * Amount of time to delay opening a submenu on hover event.
     * @option
     * @example 250
     */
    hoverDelay: 250,
    /**
     * Allow submenus to open on hover events
     * @option
     * @example false
     */
    hover: false,
    /**
     * Don't close dropdown when hovering over dropdown pane
     * @option
     * @example true
     */
    hoverPane: false,
    /**
     * Number of pixels between the dropdown pane and the triggering element on open.
     * @option
     * @example 1
     */
    vOffset: 1,
    /**
     * Number of pixels between the dropdown pane and the triggering element on open.
     * @option
     * @example 1
     */
    hOffset: 1,
    /**
     * Class applied to adjust open position. JS will test and fill this in.
     * @option
     * @example 'top'
     */
    positionClass: '',
    /**
     * Allow the plugin to trap focus to the dropdown pane if opened with keyboard commands.
     * @option
     * @example false
     */
    trapFocus: false,
    /**
     * Allow the plugin to set focus to the first focusable element within the pane, regardless of method of opening.
     * @option
     * @example true
     */
    autoFocus: false,
    /**
     * Allows a click on the body to close the dropdown.
     * @option
     * @example false
     */
    closeOnClick: false

    // Window exports
  };Foundation.plugin(Dropdown, 'Dropdown');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * DropdownMenu module.
   * @module foundation.dropdown-menu
   * @requires foundation.util.keyboard
   * @requires foundation.util.box
   * @requires foundation.util.nest
   */

  var DropdownMenu = function () {
    /**
     * Creates a new instance of DropdownMenu.
     * @class
     * @fires DropdownMenu#init
     * @param {jQuery} element - jQuery object to make into a dropdown menu.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function DropdownMenu(element, options) {
      _classCallCheck(this, DropdownMenu);

      this.$element = element;
      this.options = $.extend({}, DropdownMenu.defaults, this.$element.data(), options);

      Foundation.Nest.Feather(this.$element, 'dropdown');
      this._init();

      Foundation.registerPlugin(this, 'DropdownMenu');
      Foundation.Keyboard.register('DropdownMenu', {
        'ENTER': 'open',
        'SPACE': 'open',
        'ARROW_RIGHT': 'next',
        'ARROW_UP': 'up',
        'ARROW_DOWN': 'down',
        'ARROW_LEFT': 'previous',
        'ESCAPE': 'close'
      });
    }

    /**
     * Initializes the plugin, and calls _prepareMenu
     * @private
     * @function
     */


    _createClass(DropdownMenu, [{
      key: '_init',
      value: function _init() {
        var subs = this.$element.find('li.is-dropdown-submenu-parent');
        this.$element.children('.is-dropdown-submenu-parent').children('.is-dropdown-submenu').addClass('first-sub');

        this.$menuItems = this.$element.find('[role="menuitem"]');
        this.$tabs = this.$element.children('[role="menuitem"]');
        this.$tabs.find('ul.is-dropdown-submenu').addClass(this.options.verticalClass);

        if (this.$element.hasClass(this.options.rightClass) || this.options.alignment === 'right' || Foundation.rtl() || this.$element.parents('.top-bar-right').is('*')) {
          this.options.alignment = 'right';
          subs.addClass('opens-left');
        } else {
          subs.addClass('opens-right');
        }
        this.changed = false;
        this._events();
      }
    }, {
      key: '_isVertical',
      value: function _isVertical() {
        return this.$tabs.css('display') === 'block';
      }

      /**
       * Adds event listeners to elements within the menu
       * @private
       * @function
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this,
            hasTouch = 'ontouchstart' in window || typeof window.ontouchstart !== 'undefined',
            parClass = 'is-dropdown-submenu-parent';

        // used for onClick and in the keyboard handlers
        var handleClickFn = function handleClickFn(e) {
          var $elem = $(e.target).parentsUntil('ul', '.' + parClass),
              hasSub = $elem.hasClass(parClass),
              hasClicked = $elem.attr('data-is-click') === 'true',
              $sub = $elem.children('.is-dropdown-submenu');

          if (hasSub) {
            if (hasClicked) {
              if (!_this.options.closeOnClick || !_this.options.clickOpen && !hasTouch || _this.options.forceFollow && hasTouch) {
                return;
              } else {
                e.stopImmediatePropagation();
                e.preventDefault();
                _this._hide($elem);
              }
            } else {
              e.preventDefault();
              e.stopImmediatePropagation();
              _this._show($sub);
              $elem.add($elem.parentsUntil(_this.$element, '.' + parClass)).attr('data-is-click', true);
            }
          }
        };

        if (this.options.clickOpen || hasTouch) {
          this.$menuItems.on('click.zf.dropdownmenu touchstart.zf.dropdownmenu', handleClickFn);
        }

        // Handle Leaf element Clicks
        if (_this.options.closeOnClickInside) {
          this.$menuItems.on('click.zf.dropdownmenu touchend.zf.dropdownmenu', function (e) {
            var $elem = $(this),
                hasSub = $elem.hasClass(parClass);
            if (!hasSub) {
              _this._hide();
            }
          });
        }

        if (!this.options.disableHover) {
          this.$menuItems.on('mouseenter.zf.dropdownmenu', function (e) {
            var $elem = $(this),
                hasSub = $elem.hasClass(parClass);

            if (hasSub) {
              clearTimeout($elem.data('_delay'));
              $elem.data('_delay', setTimeout(function () {
                _this._show($elem.children('.is-dropdown-submenu'));
              }, _this.options.hoverDelay));
            }
          }).on('mouseleave.zf.dropdownmenu', function (e) {
            var $elem = $(this),
                hasSub = $elem.hasClass(parClass);
            if (hasSub && _this.options.autoclose) {
              if ($elem.attr('data-is-click') === 'true' && _this.options.clickOpen) {
                return false;
              }

              clearTimeout($elem.data('_delay'));
              $elem.data('_delay', setTimeout(function () {
                _this._hide($elem);
              }, _this.options.closingTime));
            }
          });
        }
        this.$menuItems.on('keydown.zf.dropdownmenu', function (e) {
          var $element = $(e.target).parentsUntil('ul', '[role="menuitem"]'),
              isTab = _this.$tabs.index($element) > -1,
              $elements = isTab ? _this.$tabs : $element.siblings('li').add($element),
              $prevElement,
              $nextElement;

          $elements.each(function (i) {
            if ($(this).is($element)) {
              $prevElement = $elements.eq(i - 1);
              $nextElement = $elements.eq(i + 1);
              return;
            }
          });

          var nextSibling = function nextSibling() {
            if (!$element.is(':last-child')) {
              $nextElement.children('a:first').focus();
              e.preventDefault();
            }
          },
              prevSibling = function prevSibling() {
            $prevElement.children('a:first').focus();
            e.preventDefault();
          },
              openSub = function openSub() {
            var $sub = $element.children('ul.is-dropdown-submenu');
            if ($sub.length) {
              _this._show($sub);
              $element.find('li > a:first').focus();
              e.preventDefault();
            } else {
              return;
            }
          },
              closeSub = function closeSub() {
            //if ($element.is(':first-child')) {
            var close = $element.parent('ul').parent('li');
            close.children('a:first').focus();
            _this._hide(close);
            e.preventDefault();
            //}
          };
          var functions = {
            open: openSub,
            close: function close() {
              _this._hide(_this.$element);
              _this.$menuItems.find('a:first').focus(); // focus to first element
              e.preventDefault();
            },
            handled: function handled() {
              e.stopImmediatePropagation();
            }
          };

          if (isTab) {
            if (_this._isVertical()) {
              // vertical menu
              if (Foundation.rtl()) {
                // right aligned
                $.extend(functions, {
                  down: nextSibling,
                  up: prevSibling,
                  next: closeSub,
                  previous: openSub
                });
              } else {
                // left aligned
                $.extend(functions, {
                  down: nextSibling,
                  up: prevSibling,
                  next: openSub,
                  previous: closeSub
                });
              }
            } else {
              // horizontal menu
              if (Foundation.rtl()) {
                // right aligned
                $.extend(functions, {
                  next: prevSibling,
                  previous: nextSibling,
                  down: openSub,
                  up: closeSub
                });
              } else {
                // left aligned
                $.extend(functions, {
                  next: nextSibling,
                  previous: prevSibling,
                  down: openSub,
                  up: closeSub
                });
              }
            }
          } else {
            // not tabs -> one sub
            if (Foundation.rtl()) {
              // right aligned
              $.extend(functions, {
                next: closeSub,
                previous: openSub,
                down: nextSibling,
                up: prevSibling
              });
            } else {
              // left aligned
              $.extend(functions, {
                next: openSub,
                previous: closeSub,
                down: nextSibling,
                up: prevSibling
              });
            }
          }
          Foundation.Keyboard.handleKey(e, 'DropdownMenu', functions);
        });
      }

      /**
       * Adds an event handler to the body to close any dropdowns on a click.
       * @function
       * @private
       */

    }, {
      key: '_addBodyHandler',
      value: function _addBodyHandler() {
        var $body = $(document.body),
            _this = this;
        $body.off('mouseup.zf.dropdownmenu touchend.zf.dropdownmenu').on('mouseup.zf.dropdownmenu touchend.zf.dropdownmenu', function (e) {
          var $link = _this.$element.find(e.target);
          if ($link.length) {
            return;
          }

          _this._hide();
          $body.off('mouseup.zf.dropdownmenu touchend.zf.dropdownmenu');
        });
      }

      /**
       * Opens a dropdown pane, and checks for collisions first.
       * @param {jQuery} $sub - ul element that is a submenu to show
       * @function
       * @private
       * @fires DropdownMenu#show
       */

    }, {
      key: '_show',
      value: function _show($sub) {
        var idx = this.$tabs.index(this.$tabs.filter(function (i, el) {
          return $(el).find($sub).length > 0;
        }));
        var $sibs = $sub.parent('li.is-dropdown-submenu-parent').siblings('li.is-dropdown-submenu-parent');
        this._hide($sibs, idx);
        $sub.css('visibility', 'hidden').addClass('js-dropdown-active').parent('li.is-dropdown-submenu-parent').addClass('is-active');
        var clear = Foundation.Box.ImNotTouchingYou($sub, null, true);
        if (!clear) {
          var oldClass = this.options.alignment === 'left' ? '-right' : '-left',
              $parentLi = $sub.parent('.is-dropdown-submenu-parent');
          $parentLi.removeClass('opens' + oldClass).addClass('opens-' + this.options.alignment);
          clear = Foundation.Box.ImNotTouchingYou($sub, null, true);
          if (!clear) {
            $parentLi.removeClass('opens-' + this.options.alignment).addClass('opens-inner');
          }
          this.changed = true;
        }
        $sub.css('visibility', '');
        if (this.options.closeOnClick) {
          this._addBodyHandler();
        }
        /**
         * Fires when the new dropdown pane is visible.
         * @event DropdownMenu#show
         */
        this.$element.trigger('show.zf.dropdownmenu', [$sub]);
      }

      /**
       * Hides a single, currently open dropdown pane, if passed a parameter, otherwise, hides everything.
       * @function
       * @param {jQuery} $elem - element with a submenu to hide
       * @param {Number} idx - index of the $tabs collection to hide
       * @private
       */

    }, {
      key: '_hide',
      value: function _hide($elem, idx) {
        var $toClose;
        if ($elem && $elem.length) {
          $toClose = $elem;
        } else if (idx !== undefined) {
          $toClose = this.$tabs.not(function (i, el) {
            return i === idx;
          });
        } else {
          $toClose = this.$element;
        }
        var somethingToClose = $toClose.hasClass('is-active') || $toClose.find('.is-active').length > 0;

        if (somethingToClose) {
          $toClose.find('li.is-active').add($toClose).attr({
            'data-is-click': false
          }).removeClass('is-active');

          $toClose.find('ul.js-dropdown-active').removeClass('js-dropdown-active');

          if (this.changed || $toClose.find('opens-inner').length) {
            var oldClass = this.options.alignment === 'left' ? 'right' : 'left';
            $toClose.find('li.is-dropdown-submenu-parent').add($toClose).removeClass('opens-inner opens-' + this.options.alignment).addClass('opens-' + oldClass);
            this.changed = false;
          }
          /**
           * Fires when the open menus are closed.
           * @event DropdownMenu#hide
           */
          this.$element.trigger('hide.zf.dropdownmenu', [$toClose]);
        }
      }

      /**
       * Destroys the plugin.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.$menuItems.off('.zf.dropdownmenu').removeAttr('data-is-click').removeClass('is-right-arrow is-left-arrow is-down-arrow opens-right opens-left opens-inner');
        $(document.body).off('.zf.dropdownmenu');
        Foundation.Nest.Burn(this.$element, 'dropdown');
        Foundation.unregisterPlugin(this);
      }
    }]);

    return DropdownMenu;
  }();

  /**
   * Default settings for plugin
   */


  DropdownMenu.defaults = {
    /**
     * Disallows hover events from opening submenus
     * @option
     * @example false
     */
    disableHover: false,
    /**
     * Allow a submenu to automatically close on a mouseleave event, if not clicked open.
     * @option
     * @example true
     */
    autoclose: true,
    /**
     * Amount of time to delay opening a submenu on hover event.
     * @option
     * @example 50
     */
    hoverDelay: 50,
    /**
     * Allow a submenu to open/remain open on parent click event. Allows cursor to move away from menu.
     * @option
     * @example true
     */
    clickOpen: false,
    /**
     * Amount of time to delay closing a submenu on a mouseleave event.
     * @option
     * @example 500
     */

    closingTime: 500,
    /**
     * Position of the menu relative to what direction the submenus should open. Handled by JS.
     * @option
     * @example 'left'
     */
    alignment: 'left',
    /**
     * Allow clicks on the body to close any open submenus.
     * @option
     * @example true
     */
    closeOnClick: true,
    /**
     * Allow clicks on leaf anchor links to close any open submenus.
     * @option
     * @example true
     */
    closeOnClickInside: true,
    /**
     * Class applied to vertical oriented menus, Foundation default is `vertical`. Update this if using your own class.
     * @option
     * @example 'vertical'
     */
    verticalClass: 'vertical',
    /**
     * Class applied to right-side oriented menus, Foundation default is `align-right`. Update this if using your own class.
     * @option
     * @example 'align-right'
     */
    rightClass: 'align-right',
    /**
     * Boolean to force overide the clicking of links to perform default action, on second touch event for mobile.
     * @option
     * @example false
     */
    forceFollow: true
  };

  // Window exports
  Foundation.plugin(DropdownMenu, 'DropdownMenu');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * OffCanvas module.
   * @module foundation.offcanvas
   * @requires foundation.util.mediaQuery
   * @requires foundation.util.triggers
   * @requires foundation.util.motion
   */

  var OffCanvas = function () {
    /**
     * Creates a new instance of an off-canvas wrapper.
     * @class
     * @fires OffCanvas#init
     * @param {Object} element - jQuery object to initialize.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function OffCanvas(element, options) {
      _classCallCheck(this, OffCanvas);

      this.$element = element;
      this.options = $.extend({}, OffCanvas.defaults, this.$element.data(), options);
      this.$lastTrigger = $();
      this.$triggers = $();

      this._init();
      this._events();

      Foundation.registerPlugin(this, 'OffCanvas');
      Foundation.Keyboard.register('OffCanvas', {
        'ESCAPE': 'close'
      });
    }

    /**
     * Initializes the off-canvas wrapper by adding the exit overlay (if needed).
     * @function
     * @private
     */


    _createClass(OffCanvas, [{
      key: '_init',
      value: function _init() {
        var id = this.$element.attr('id');

        this.$element.attr('aria-hidden', 'true');

        this.$element.addClass('is-transition-' + this.options.transition);

        // Find triggers that affect this element and add aria-expanded to them
        this.$triggers = $(document).find('[data-open="' + id + '"], [data-close="' + id + '"], [data-toggle="' + id + '"]').attr('aria-expanded', 'false').attr('aria-controls', id);

        // Add an overlay over the content if necessary
        if (this.options.contentOverlay === true) {
          var overlay = document.createElement('div');
          var overlayPosition = $(this.$element).css("position") === 'fixed' ? 'is-overlay-fixed' : 'is-overlay-absolute';
          overlay.setAttribute('class', 'js-off-canvas-overlay ' + overlayPosition);
          this.$overlay = $(overlay);
          if (overlayPosition === 'is-overlay-fixed') {
            $('body').append(this.$overlay);
          } else {
            this.$element.siblings('[data-off-canvas-content]').append(this.$overlay);
          }
        }

        this.options.isRevealed = this.options.isRevealed || new RegExp(this.options.revealClass, 'g').test(this.$element[0].className);

        if (this.options.isRevealed === true) {
          this.options.revealOn = this.options.revealOn || this.$element[0].className.match(/(reveal-for-medium|reveal-for-large)/g)[0].split('-')[2];
          this._setMQChecker();
        }
        if (!this.options.transitionTime === true) {
          this.options.transitionTime = parseFloat(window.getComputedStyle($('[data-off-canvas]')[0]).transitionDuration) * 1000;
        }
      }

      /**
       * Adds event handlers to the off-canvas wrapper and the exit overlay.
       * @function
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        this.$element.off('.zf.trigger .zf.offcanvas').on({
          'open.zf.trigger': this.open.bind(this),
          'close.zf.trigger': this.close.bind(this),
          'toggle.zf.trigger': this.toggle.bind(this),
          'keydown.zf.offcanvas': this._handleKeyboard.bind(this)
        });

        if (this.options.closeOnClick === true) {
          var $target = this.options.contentOverlay ? this.$overlay : $('[data-off-canvas-content]');
          $target.on({ 'click.zf.offcanvas': this.close.bind(this) });
        }
      }

      /**
       * Applies event listener for elements that will reveal at certain breakpoints.
       * @private
       */

    }, {
      key: '_setMQChecker',
      value: function _setMQChecker() {
        var _this = this;

        $(window).on('changed.zf.mediaquery', function () {
          if (Foundation.MediaQuery.atLeast(_this.options.revealOn)) {
            _this.reveal(true);
          } else {
            _this.reveal(false);
          }
        }).one('load.zf.offcanvas', function () {
          if (Foundation.MediaQuery.atLeast(_this.options.revealOn)) {
            _this.reveal(true);
          }
        });
      }

      /**
       * Handles the revealing/hiding the off-canvas at breakpoints, not the same as open.
       * @param {Boolean} isRevealed - true if element should be revealed.
       * @function
       */

    }, {
      key: 'reveal',
      value: function reveal(isRevealed) {
        var $closer = this.$element.find('[data-close]');
        if (isRevealed) {
          this.close();
          this.isRevealed = true;
          this.$element.attr('aria-hidden', 'false');
          this.$element.off('open.zf.trigger toggle.zf.trigger');
          if ($closer.length) {
            $closer.hide();
          }
        } else {
          this.isRevealed = false;
          this.$element.attr('aria-hidden', 'true');
          this.$element.on({
            'open.zf.trigger': this.open.bind(this),
            'toggle.zf.trigger': this.toggle.bind(this)
          });
          if ($closer.length) {
            $closer.show();
          }
        }
      }

      /**
       * Stops scrolling of the body when offcanvas is open on mobile Safari and other troublesome browsers.
       * @private
       */

    }, {
      key: '_stopScrolling',
      value: function _stopScrolling(event) {
        return false;
      }

      /**
       * Opens the off-canvas menu.
       * @function
       * @param {Object} event - Event object passed from listener.
       * @param {jQuery} trigger - element that triggered the off-canvas to open.
       * @fires OffCanvas#opened
       */

    }, {
      key: 'open',
      value: function open(event, trigger) {
        if (this.$element.hasClass('is-open') || this.isRevealed) {
          return;
        }
        var _this = this;

        if (trigger) {
          this.$lastTrigger = trigger;
        }

        if (this.options.forceTo === 'top') {
          window.scrollTo(0, 0);
        } else if (this.options.forceTo === 'bottom') {
          window.scrollTo(0, document.body.scrollHeight);
        }

        /**
         * Fires when the off-canvas menu opens.
         * @event OffCanvas#opened
         */
        _this.$element.addClass('is-open');

        this.$triggers.attr('aria-expanded', 'true');
        this.$element.attr('aria-hidden', 'false').trigger('opened.zf.offcanvas');

        // If `contentScroll` is set to false, add class and disable scrolling on touch devices.
        if (this.options.contentScroll === false) {
          $('body').addClass('is-off-canvas-open').on('touchmove', this._stopScrolling);
        }

        if (this.options.contentOverlay === true) {
          this.$overlay.addClass('is-visible');
        }

        if (this.options.closeOnClick === true && this.options.contentOverlay === true) {
          this.$overlay.addClass('is-closable');
        }

        if (this.options.autoFocus === true) {
          this.$element.one(Foundation.transitionend(this.$element), function () {
            _this.$element.find('a, button').eq(0).focus();
          });
        }

        if (this.options.trapFocus === true) {
          this.$element.siblings('[data-off-canvas-content]').attr('tabindex', '-1');
          Foundation.Keyboard.trapFocus(this.$element);
        }
      }

      /**
       * Closes the off-canvas menu.
       * @function
       * @param {Function} cb - optional cb to fire after closure.
       * @fires OffCanvas#closed
       */

    }, {
      key: 'close',
      value: function close(cb) {
        if (!this.$element.hasClass('is-open') || this.isRevealed) {
          return;
        }

        var _this = this;

        _this.$element.removeClass('is-open');

        this.$element.attr('aria-hidden', 'true')
        /**
         * Fires when the off-canvas menu opens.
         * @event OffCanvas#closed
         */
        .trigger('closed.zf.offcanvas');

        // If `contentScroll` is set to false, remove class and re-enable scrolling on touch devices.
        if (this.options.contentScroll === false) {
          $('body').removeClass('is-off-canvas-open').off('touchmove', this._stopScrolling);
        }

        if (this.options.contentOverlay === true) {
          this.$overlay.removeClass('is-visible');
        }

        if (this.options.closeOnClick === true && this.options.contentOverlay === true) {
          this.$overlay.removeClass('is-closable');
        }

        this.$triggers.attr('aria-expanded', 'false');

        if (this.options.trapFocus === true) {
          this.$element.siblings('[data-off-canvas-content]').removeAttr('tabindex');
          Foundation.Keyboard.releaseFocus(this.$element);
        }
      }

      /**
       * Toggles the off-canvas menu open or closed.
       * @function
       * @param {Object} event - Event object passed from listener.
       * @param {jQuery} trigger - element that triggered the off-canvas to open.
       */

    }, {
      key: 'toggle',
      value: function toggle(event, trigger) {
        if (this.$element.hasClass('is-open')) {
          this.close(event, trigger);
        } else {
          this.open(event, trigger);
        }
      }

      /**
       * Handles keyboard input when detected. When the escape key is pressed, the off-canvas menu closes, and focus is restored to the element that opened the menu.
       * @function
       * @private
       */

    }, {
      key: '_handleKeyboard',
      value: function _handleKeyboard(e) {
        var _this2 = this;

        Foundation.Keyboard.handleKey(e, 'OffCanvas', {
          close: function close() {
            _this2.close();
            _this2.$lastTrigger.focus();
            return true;
          },
          handled: function handled() {
            e.stopPropagation();
            e.preventDefault();
          }
        });
      }

      /**
       * Destroys the offcanvas plugin.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.close();
        this.$element.off('.zf.trigger .zf.offcanvas');
        this.$overlay.off('.zf.offcanvas');

        Foundation.unregisterPlugin(this);
      }
    }]);

    return OffCanvas;
  }();

  OffCanvas.defaults = {
    /**
     * Allow the user to click outside of the menu to close it.
     * @option
     * @example true
     */
    closeOnClick: true,

    /**
     * Adds an overlay on top of `[data-off-canvas-content]`.
     * @option
     * @example true
     */
    contentOverlay: true,

    /**
     * Enable/disable scrolling of the main content when an off canvas panel is open.
     * @option
     * @example true
     */
    contentScroll: true,

    /**
     * Amount of time in ms the open and close transition requires. If none selected, pulls from body style.
     * @option
     * @example 500
     */
    transitionTime: 0,

    /**
     * Type of transition for the offcanvas menu. Options are 'push', 'detached' or 'slide'.
     * @option
     * @example push
     */
    transition: 'push',

    /**
     * Force the page to scroll to top or bottom on open.
     * @option
     * @example top
     */
    forceTo: null,

    /**
     * Allow the offcanvas to remain open for certain breakpoints.
     * @option
     * @example false
     */
    isRevealed: false,

    /**
     * Breakpoint at which to reveal. JS will use a RegExp to target standard classes, if changing classnames, pass your class with the `revealClass` option.
     * @option
     * @example reveal-for-large
     */
    revealOn: null,

    /**
     * Force focus to the offcanvas on open. If true, will focus the opening trigger on close.
     * @option
     * @example true
     */
    autoFocus: true,

    /**
     * Class used to force an offcanvas to remain open. Foundation defaults for this are `reveal-for-large` & `reveal-for-medium`.
     * @option
     * TODO improve the regex testing for this.
     * @example reveal-for-large
     */
    revealClass: 'reveal-for-',

    /**
     * Triggers optional focus trapping when opening an offcanvas. Sets tabindex of [data-off-canvas-content] to -1 for accessibility purposes.
     * @option
     * @example true
     */
    trapFocus: false

    // Window exports
  };Foundation.plugin(OffCanvas, 'OffCanvas');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * ResponsiveMenu module.
   * @module foundation.responsiveMenu
   * @requires foundation.util.triggers
   * @requires foundation.util.mediaQuery
   * @requires foundation.util.accordionMenu
   * @requires foundation.util.drilldown
   * @requires foundation.util.dropdown-menu
   */

  var ResponsiveMenu = function () {
    /**
     * Creates a new instance of a responsive menu.
     * @class
     * @fires ResponsiveMenu#init
     * @param {jQuery} element - jQuery object to make into a dropdown menu.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function ResponsiveMenu(element, options) {
      _classCallCheck(this, ResponsiveMenu);

      this.$element = $(element);
      this.rules = this.$element.data('responsive-menu');
      this.currentMq = null;
      this.currentPlugin = null;

      this._init();
      this._events();

      Foundation.registerPlugin(this, 'ResponsiveMenu');
    }

    /**
     * Initializes the Menu by parsing the classes from the 'data-ResponsiveMenu' attribute on the element.
     * @function
     * @private
     */


    _createClass(ResponsiveMenu, [{
      key: '_init',
      value: function _init() {
        // The first time an Interchange plugin is initialized, this.rules is converted from a string of "classes" to an object of rules
        if (typeof this.rules === 'string') {
          var rulesTree = {};

          // Parse rules from "classes" pulled from data attribute
          var rules = this.rules.split(' ');

          // Iterate through every rule found
          for (var i = 0; i < rules.length; i++) {
            var rule = rules[i].split('-');
            var ruleSize = rule.length > 1 ? rule[0] : 'small';
            var rulePlugin = rule.length > 1 ? rule[1] : rule[0];

            if (MenuPlugins[rulePlugin] !== null) {
              rulesTree[ruleSize] = MenuPlugins[rulePlugin];
            }
          }

          this.rules = rulesTree;
        }

        if (!$.isEmptyObject(this.rules)) {
          this._checkMediaQueries();
        }
        // Add data-mutate since children may need it.
        this.$element.attr('data-mutate', this.$element.attr('data-mutate') || Foundation.GetYoDigits(6, 'responsive-menu'));
      }

      /**
       * Initializes events for the Menu.
       * @function
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this;

        $(window).on('changed.zf.mediaquery', function () {
          _this._checkMediaQueries();
        });
        // $(window).on('resize.zf.ResponsiveMenu', function() {
        //   _this._checkMediaQueries();
        // });
      }

      /**
       * Checks the current screen width against available media queries. If the media query has changed, and the plugin needed has changed, the plugins will swap out.
       * @function
       * @private
       */

    }, {
      key: '_checkMediaQueries',
      value: function _checkMediaQueries() {
        var matchedMq,
            _this = this;
        // Iterate through each rule and find the last matching rule
        $.each(this.rules, function (key) {
          if (Foundation.MediaQuery.atLeast(key)) {
            matchedMq = key;
          }
        });

        // No match? No dice
        if (!matchedMq) return;

        // Plugin already initialized? We good
        if (this.currentPlugin instanceof this.rules[matchedMq].plugin) return;

        // Remove existing plugin-specific CSS classes
        $.each(MenuPlugins, function (key, value) {
          _this.$element.removeClass(value.cssClass);
        });

        // Add the CSS class for the new plugin
        this.$element.addClass(this.rules[matchedMq].cssClass);

        // Create an instance of the new plugin
        if (this.currentPlugin) this.currentPlugin.destroy();
        this.currentPlugin = new this.rules[matchedMq].plugin(this.$element, {});
      }

      /**
       * Destroys the instance of the current plugin on this element, as well as the window resize handler that switches the plugins out.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.currentPlugin.destroy();
        $(window).off('.zf.ResponsiveMenu');
        Foundation.unregisterPlugin(this);
      }
    }]);

    return ResponsiveMenu;
  }();

  ResponsiveMenu.defaults = {};

  // The plugin matches the plugin classes with these plugin instances.
  var MenuPlugins = {
    dropdown: {
      cssClass: 'dropdown',
      plugin: Foundation._plugins['dropdown-menu'] || null
    },
    drilldown: {
      cssClass: 'drilldown',
      plugin: Foundation._plugins['drilldown'] || null
    },
    accordion: {
      cssClass: 'accordion-menu',
      plugin: Foundation._plugins['accordion-menu'] || null
    }
  };

  // Window exports
  Foundation.plugin(ResponsiveMenu, 'ResponsiveMenu');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * ResponsiveToggle module.
   * @module foundation.responsiveToggle
   * @requires foundation.util.mediaQuery
   */

  var ResponsiveToggle = function () {
    /**
     * Creates a new instance of Tab Bar.
     * @class
     * @fires ResponsiveToggle#init
     * @param {jQuery} element - jQuery object to attach tab bar functionality to.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function ResponsiveToggle(element, options) {
      _classCallCheck(this, ResponsiveToggle);

      this.$element = $(element);
      this.options = $.extend({}, ResponsiveToggle.defaults, this.$element.data(), options);

      this._init();
      this._events();

      Foundation.registerPlugin(this, 'ResponsiveToggle');
    }

    /**
     * Initializes the tab bar by finding the target element, toggling element, and running update().
     * @function
     * @private
     */


    _createClass(ResponsiveToggle, [{
      key: '_init',
      value: function _init() {
        var targetID = this.$element.data('responsive-toggle');
        if (!targetID) {
          console.error('Your tab bar needs an ID of a Menu as the value of data-tab-bar.');
        }

        this.$targetMenu = $('#' + targetID);
        this.$toggler = this.$element.find('[data-toggle]');
        this.options = $.extend({}, this.options, this.$targetMenu.data());

        // If they were set, parse the animation classes
        if (this.options.animate) {
          var input = this.options.animate.split(' ');

          this.animationIn = input[0];
          this.animationOut = input[1] || null;
        }

        this._update();
      }

      /**
       * Adds necessary event handlers for the tab bar to work.
       * @function
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this;

        this._updateMqHandler = this._update.bind(this);

        $(window).on('changed.zf.mediaquery', this._updateMqHandler);

        this.$toggler.on('click.zf.responsiveToggle', this.toggleMenu.bind(this));
      }

      /**
       * Checks the current media query to determine if the tab bar should be visible or hidden.
       * @function
       * @private
       */

    }, {
      key: '_update',
      value: function _update() {
        // Mobile
        if (!Foundation.MediaQuery.atLeast(this.options.hideFor)) {
          this.$element.show();
          this.$targetMenu.hide();
        }

        // Desktop
        else {
            this.$element.hide();
            this.$targetMenu.show();
          }
      }

      /**
       * Toggles the element attached to the tab bar. The toggle only happens if the screen is small enough to allow it.
       * @function
       * @fires ResponsiveToggle#toggled
       */

    }, {
      key: 'toggleMenu',
      value: function toggleMenu() {
        var _this2 = this;

        if (!Foundation.MediaQuery.atLeast(this.options.hideFor)) {
          if (this.options.animate) {
            if (this.$targetMenu.is(':hidden')) {
              Foundation.Motion.animateIn(this.$targetMenu, this.animationIn, function () {
                /**
                 * Fires when the element attached to the tab bar toggles.
                 * @event ResponsiveToggle#toggled
                 */
                _this2.$element.trigger('toggled.zf.responsiveToggle');
                _this2.$targetMenu.find('[data-mutate]').triggerHandler('mutateme.zf.trigger');
              });
            } else {
              Foundation.Motion.animateOut(this.$targetMenu, this.animationOut, function () {
                /**
                 * Fires when the element attached to the tab bar toggles.
                 * @event ResponsiveToggle#toggled
                 */
                _this2.$element.trigger('toggled.zf.responsiveToggle');
              });
            }
          } else {
            this.$targetMenu.toggle(0);
            this.$targetMenu.find('[data-mutate]').trigger('mutateme.zf.trigger');

            /**
             * Fires when the element attached to the tab bar toggles.
             * @event ResponsiveToggle#toggled
             */
            this.$element.trigger('toggled.zf.responsiveToggle');
          }
        }
      }
    }, {
      key: 'destroy',
      value: function destroy() {
        this.$element.off('.zf.responsiveToggle');
        this.$toggler.off('.zf.responsiveToggle');

        $(window).off('changed.zf.mediaquery', this._updateMqHandler);

        Foundation.unregisterPlugin(this);
      }
    }]);

    return ResponsiveToggle;
  }();

  ResponsiveToggle.defaults = {
    /**
     * The breakpoint after which the menu is always shown, and the tab bar is hidden.
     * @option
     * @example 'medium'
     */
    hideFor: 'medium',

    /**
     * To decide if the toggle should be animated or not.
     * @option
     * @example false
     */
    animate: false
  };

  // Window exports
  Foundation.plugin(ResponsiveToggle, 'ResponsiveToggle');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * Toggler module.
   * @module foundation.toggler
   * @requires foundation.util.motion
   * @requires foundation.util.triggers
   */

  var Toggler = function () {
    /**
     * Creates a new instance of Toggler.
     * @class
     * @fires Toggler#init
     * @param {Object} element - jQuery object to add the trigger to.
     * @param {Object} options - Overrides to the default plugin settings.
     */
    function Toggler(element, options) {
      _classCallCheck(this, Toggler);

      this.$element = element;
      this.options = $.extend({}, Toggler.defaults, element.data(), options);
      this.className = '';

      this._init();
      this._events();

      Foundation.registerPlugin(this, 'Toggler');
    }

    /**
     * Initializes the Toggler plugin by parsing the toggle class from data-toggler, or animation classes from data-animate.
     * @function
     * @private
     */


    _createClass(Toggler, [{
      key: '_init',
      value: function _init() {
        var input;
        // Parse animation classes if they were set
        if (this.options.animate) {
          input = this.options.animate.split(' ');

          this.animationIn = input[0];
          this.animationOut = input[1] || null;
        }
        // Otherwise, parse toggle class
        else {
            input = this.$element.data('toggler');
            // Allow for a . at the beginning of the string
            this.className = input[0] === '.' ? input.slice(1) : input;
          }

        // Add ARIA attributes to triggers
        var id = this.$element[0].id;
        $('[data-open="' + id + '"], [data-close="' + id + '"], [data-toggle="' + id + '"]').attr('aria-controls', id);
        // If the target is hidden, add aria-hidden
        this.$element.attr('aria-expanded', this.$element.is(':hidden') ? false : true);
      }

      /**
       * Initializes events for the toggle trigger.
       * @function
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        this.$element.off('toggle.zf.trigger').on('toggle.zf.trigger', this.toggle.bind(this));
      }

      /**
       * Toggles the target class on the target element. An event is fired from the original trigger depending on if the resultant state was "on" or "off".
       * @function
       * @fires Toggler#on
       * @fires Toggler#off
       */

    }, {
      key: 'toggle',
      value: function toggle() {
        this[this.options.animate ? '_toggleAnimate' : '_toggleClass']();
      }
    }, {
      key: '_toggleClass',
      value: function _toggleClass() {
        this.$element.toggleClass(this.className);

        var isOn = this.$element.hasClass(this.className);
        if (isOn) {
          /**
           * Fires if the target element has the class after a toggle.
           * @event Toggler#on
           */
          this.$element.trigger('on.zf.toggler');
        } else {
          /**
           * Fires if the target element does not have the class after a toggle.
           * @event Toggler#off
           */
          this.$element.trigger('off.zf.toggler');
        }

        this._updateARIA(isOn);
        this.$element.find('[data-mutate]').trigger('mutateme.zf.trigger');
      }
    }, {
      key: '_toggleAnimate',
      value: function _toggleAnimate() {
        var _this = this;

        if (this.$element.is(':hidden')) {
          Foundation.Motion.animateIn(this.$element, this.animationIn, function () {
            _this._updateARIA(true);
            this.trigger('on.zf.toggler');
            this.find('[data-mutate]').trigger('mutateme.zf.trigger');
          });
        } else {
          Foundation.Motion.animateOut(this.$element, this.animationOut, function () {
            _this._updateARIA(false);
            this.trigger('off.zf.toggler');
            this.find('[data-mutate]').trigger('mutateme.zf.trigger');
          });
        }
      }
    }, {
      key: '_updateARIA',
      value: function _updateARIA(isOn) {
        this.$element.attr('aria-expanded', isOn ? true : false);
      }

      /**
       * Destroys the instance of Toggler on the element.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.$element.off('.zf.toggler');
        Foundation.unregisterPlugin(this);
      }
    }]);

    return Toggler;
  }();

  Toggler.defaults = {
    /**
     * Tells the plugin if the element should animated when toggled.
     * @option
     * @example false
     */
    animate: false
  };

  // Window exports
  Foundation.plugin(Toggler, 'Toggler');
}(jQuery);
;'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

!function ($) {

  /**
   * Tooltip module.
   * @module foundation.tooltip
   * @requires foundation.util.box
   * @requires foundation.util.mediaQuery
   * @requires foundation.util.triggers
   */

  var Tooltip = function () {
    /**
     * Creates a new instance of a Tooltip.
     * @class
     * @fires Tooltip#init
     * @param {jQuery} element - jQuery object to attach a tooltip to.
     * @param {Object} options - object to extend the default configuration.
     */
    function Tooltip(element, options) {
      _classCallCheck(this, Tooltip);

      this.$element = element;
      this.options = $.extend({}, Tooltip.defaults, this.$element.data(), options);

      this.isActive = false;
      this.isClick = false;
      this._init();

      Foundation.registerPlugin(this, 'Tooltip');
    }

    /**
     * Initializes the tooltip by setting the creating the tip element, adding it's text, setting private variables and setting attributes on the anchor.
     * @private
     */


    _createClass(Tooltip, [{
      key: '_init',
      value: function _init() {
        var elemId = this.$element.attr('aria-describedby') || Foundation.GetYoDigits(6, 'tooltip');

        this.options.positionClass = this.options.positionClass || this._getPositionClass(this.$element);
        this.options.tipText = this.options.tipText || this.$element.attr('title');
        this.template = this.options.template ? $(this.options.template) : this._buildTemplate(elemId);

        if (this.options.allowHtml) {
          this.template.appendTo(document.body).html(this.options.tipText).hide();
        } else {
          this.template.appendTo(document.body).text(this.options.tipText).hide();
        }

        this.$element.attr({
          'title': '',
          'aria-describedby': elemId,
          'data-yeti-box': elemId,
          'data-toggle': elemId,
          'data-resize': elemId
        }).addClass(this.options.triggerClass);

        //helper variables to track movement on collisions
        this.usedPositions = [];
        this.counter = 4;
        this.classChanged = false;

        this._events();
      }

      /**
       * Grabs the current positioning class, if present, and returns the value or an empty string.
       * @private
       */

    }, {
      key: '_getPositionClass',
      value: function _getPositionClass(element) {
        if (!element) {
          return '';
        }
        // var position = element.attr('class').match(/top|left|right/g);
        var position = element[0].className.match(/\b(top|left|right)\b/g);
        position = position ? position[0] : '';
        return position;
      }
    }, {
      key: '_buildTemplate',

      /**
       * builds the tooltip element, adds attributes, and returns the template.
       * @private
       */
      value: function _buildTemplate(id) {
        var templateClasses = (this.options.tooltipClass + ' ' + this.options.positionClass + ' ' + this.options.templateClasses).trim();
        var $template = $('<div></div>').addClass(templateClasses).attr({
          'role': 'tooltip',
          'aria-hidden': true,
          'data-is-active': false,
          'data-is-focus': false,
          'id': id
        });
        return $template;
      }

      /**
       * Function that gets called if a collision event is detected.
       * @param {String} position - positioning class to try
       * @private
       */

    }, {
      key: '_reposition',
      value: function _reposition(position) {
        this.usedPositions.push(position ? position : 'bottom');

        //default, try switching to opposite side
        if (!position && this.usedPositions.indexOf('top') < 0) {
          this.template.addClass('top');
        } else if (position === 'top' && this.usedPositions.indexOf('bottom') < 0) {
          this.template.removeClass(position);
        } else if (position === 'left' && this.usedPositions.indexOf('right') < 0) {
          this.template.removeClass(position).addClass('right');
        } else if (position === 'right' && this.usedPositions.indexOf('left') < 0) {
          this.template.removeClass(position).addClass('left');
        }

        //if default change didn't work, try bottom or left first
        else if (!position && this.usedPositions.indexOf('top') > -1 && this.usedPositions.indexOf('left') < 0) {
            this.template.addClass('left');
          } else if (position === 'top' && this.usedPositions.indexOf('bottom') > -1 && this.usedPositions.indexOf('left') < 0) {
            this.template.removeClass(position).addClass('left');
          } else if (position === 'left' && this.usedPositions.indexOf('right') > -1 && this.usedPositions.indexOf('bottom') < 0) {
            this.template.removeClass(position);
          } else if (position === 'right' && this.usedPositions.indexOf('left') > -1 && this.usedPositions.indexOf('bottom') < 0) {
            this.template.removeClass(position);
          }
          //if nothing cleared, set to bottom
          else {
              this.template.removeClass(position);
            }
        this.classChanged = true;
        this.counter--;
      }

      /**
       * sets the position class of an element and recursively calls itself until there are no more possible positions to attempt, or the tooltip element is no longer colliding.
       * if the tooltip is larger than the screen width, default to full width - any user selected margin
       * @private
       */

    }, {
      key: '_setPosition',
      value: function _setPosition() {
        var position = this._getPositionClass(this.template),
            $tipDims = Foundation.Box.GetDimensions(this.template),
            $anchorDims = Foundation.Box.GetDimensions(this.$element),
            direction = position === 'left' ? 'left' : position === 'right' ? 'left' : 'top',
            param = direction === 'top' ? 'height' : 'width',
            offset = param === 'height' ? this.options.vOffset : this.options.hOffset,
            _this = this;

        if ($tipDims.width >= $tipDims.windowDims.width || !this.counter && !Foundation.Box.ImNotTouchingYou(this.template)) {
          this.template.offset(Foundation.Box.GetOffsets(this.template, this.$element, 'center bottom', this.options.vOffset, this.options.hOffset, true)).css({
            // this.$element.offset(Foundation.GetOffsets(this.template, this.$element, 'center bottom', this.options.vOffset, this.options.hOffset, true)).css({
            'width': $anchorDims.windowDims.width - this.options.hOffset * 2,
            'height': 'auto'
          });
          return false;
        }

        this.template.offset(Foundation.Box.GetOffsets(this.template, this.$element, 'center ' + (position || 'bottom'), this.options.vOffset, this.options.hOffset));

        while (!Foundation.Box.ImNotTouchingYou(this.template) && this.counter) {
          this._reposition(position);
          this._setPosition();
        }
      }

      /**
       * reveals the tooltip, and fires an event to close any other open tooltips on the page
       * @fires Tooltip#closeme
       * @fires Tooltip#show
       * @function
       */

    }, {
      key: 'show',
      value: function show() {
        if (this.options.showOn !== 'all' && !Foundation.MediaQuery.is(this.options.showOn)) {
          // console.error('The screen is too small to display this tooltip');
          return false;
        }

        var _this = this;
        this.template.css('visibility', 'hidden').show();
        this._setPosition();

        /**
         * Fires to close all other open tooltips on the page
         * @event Closeme#tooltip
         */
        this.$element.trigger('closeme.zf.tooltip', this.template.attr('id'));

        this.template.attr({
          'data-is-active': true,
          'aria-hidden': false
        });
        _this.isActive = true;
        // console.log(this.template);
        this.template.stop().hide().css('visibility', '').fadeIn(this.options.fadeInDuration, function () {
          //maybe do stuff?
        });
        /**
         * Fires when the tooltip is shown
         * @event Tooltip#show
         */
        this.$element.trigger('show.zf.tooltip');
      }

      /**
       * Hides the current tooltip, and resets the positioning class if it was changed due to collision
       * @fires Tooltip#hide
       * @function
       */

    }, {
      key: 'hide',
      value: function hide() {
        // console.log('hiding', this.$element.data('yeti-box'));
        var _this = this;
        this.template.stop().attr({
          'aria-hidden': true,
          'data-is-active': false
        }).fadeOut(this.options.fadeOutDuration, function () {
          _this.isActive = false;
          _this.isClick = false;
          if (_this.classChanged) {
            _this.template.removeClass(_this._getPositionClass(_this.template)).addClass(_this.options.positionClass);

            _this.usedPositions = [];
            _this.counter = 4;
            _this.classChanged = false;
          }
        });
        /**
         * fires when the tooltip is hidden
         * @event Tooltip#hide
         */
        this.$element.trigger('hide.zf.tooltip');
      }

      /**
       * adds event listeners for the tooltip and its anchor
       * TODO combine some of the listeners like focus and mouseenter, etc.
       * @private
       */

    }, {
      key: '_events',
      value: function _events() {
        var _this = this;
        var $template = this.template;
        var isFocus = false;

        if (!this.options.disableHover) {

          this.$element.on('mouseenter.zf.tooltip', function (e) {
            if (!_this.isActive) {
              _this.timeout = setTimeout(function () {
                _this.show();
              }, _this.options.hoverDelay);
            }
          }).on('mouseleave.zf.tooltip', function (e) {
            clearTimeout(_this.timeout);
            if (!isFocus || _this.isClick && !_this.options.clickOpen) {
              _this.hide();
            }
          });
        }

        if (this.options.clickOpen) {
          this.$element.on('mousedown.zf.tooltip', function (e) {
            e.stopImmediatePropagation();
            if (_this.isClick) {
              //_this.hide();
              // _this.isClick = false;
            } else {
              _this.isClick = true;
              if ((_this.options.disableHover || !_this.$element.attr('tabindex')) && !_this.isActive) {
                _this.show();
              }
            }
          });
        } else {
          this.$element.on('mousedown.zf.tooltip', function (e) {
            e.stopImmediatePropagation();
            _this.isClick = true;
          });
        }

        if (!this.options.disableForTouch) {
          this.$element.on('tap.zf.tooltip touchend.zf.tooltip', function (e) {
            _this.isActive ? _this.hide() : _this.show();
          });
        }

        this.$element.on({
          // 'toggle.zf.trigger': this.toggle.bind(this),
          // 'close.zf.trigger': this.hide.bind(this)
          'close.zf.trigger': this.hide.bind(this)
        });

        this.$element.on('focus.zf.tooltip', function (e) {
          isFocus = true;
          if (_this.isClick) {
            // If we're not showing open on clicks, we need to pretend a click-launched focus isn't
            // a real focus, otherwise on hover and come back we get bad behavior
            if (!_this.options.clickOpen) {
              isFocus = false;
            }
            return false;
          } else {
            _this.show();
          }
        }).on('focusout.zf.tooltip', function (e) {
          isFocus = false;
          _this.isClick = false;
          _this.hide();
        }).on('resizeme.zf.trigger', function () {
          if (_this.isActive) {
            _this._setPosition();
          }
        });
      }

      /**
       * adds a toggle method, in addition to the static show() & hide() functions
       * @function
       */

    }, {
      key: 'toggle',
      value: function toggle() {
        if (this.isActive) {
          this.hide();
        } else {
          this.show();
        }
      }

      /**
       * Destroys an instance of tooltip, removes template element from the view.
       * @function
       */

    }, {
      key: 'destroy',
      value: function destroy() {
        this.$element.attr('title', this.template.text()).off('.zf.trigger .zf.tooltip').removeClass('has-tip top right left').removeAttr('aria-describedby aria-haspopup data-disable-hover data-resize data-toggle data-tooltip data-yeti-box');

        this.template.remove();

        Foundation.unregisterPlugin(this);
      }
    }]);

    return Tooltip;
  }();

  Tooltip.defaults = {
    disableForTouch: false,
    /**
     * Time, in ms, before a tooltip should open on hover.
     * @option
     * @example 200
     */
    hoverDelay: 200,
    /**
     * Time, in ms, a tooltip should take to fade into view.
     * @option
     * @example 150
     */
    fadeInDuration: 150,
    /**
     * Time, in ms, a tooltip should take to fade out of view.
     * @option
     * @example 150
     */
    fadeOutDuration: 150,
    /**
     * Disables hover events from opening the tooltip if set to true
     * @option
     * @example false
     */
    disableHover: false,
    /**
     * Optional addtional classes to apply to the tooltip template on init.
     * @option
     * @example 'my-cool-tip-class'
     */
    templateClasses: '',
    /**
     * Non-optional class added to tooltip templates. Foundation default is 'tooltip'.
     * @option
     * @example 'tooltip'
     */
    tooltipClass: 'tooltip',
    /**
     * Class applied to the tooltip anchor element.
     * @option
     * @example 'has-tip'
     */
    triggerClass: 'has-tip',
    /**
     * Minimum breakpoint size at which to open the tooltip.
     * @option
     * @example 'small'
     */
    showOn: 'small',
    /**
     * Custom template to be used to generate markup for tooltip.
     * @option
     * @example '&lt;div class="tooltip"&gt;&lt;/div&gt;'
     */
    template: '',
    /**
     * Text displayed in the tooltip template on open.
     * @option
     * @example 'Some cool space fact here.'
     */
    tipText: '',
    touchCloseText: 'Tap to close.',
    /**
     * Allows the tooltip to remain open if triggered with a click or touch event.
     * @option
     * @example true
     */
    clickOpen: true,
    /**
     * Additional positioning classes, set by the JS
     * @option
     * @example 'top'
     */
    positionClass: '',
    /**
     * Distance, in pixels, the template should push away from the anchor on the Y axis.
     * @option
     * @example 10
     */
    vOffset: 10,
    /**
     * Distance, in pixels, the template should push away from the anchor on the X axis, if aligned to a side.
     * @option
     * @example 12
     */
    hOffset: 12,
    /**
    * Allow HTML in tooltip. Warning: If you are loading user-generated content into tooltips,
    * allowing HTML may open yourself up to XSS attacks.
    * @option
    * @example false
    */
    allowHtml: false
  };

  /**
   * TODO utilize resize event trigger
   */

  // Window exports
  Foundation.plugin(Tooltip, 'Tooltip');
}(jQuery);
;"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/**
 * Owl Carousel v2.2.1
 * Copyright 2013-2017 David Deutsch
 * Licensed under  ()
 */
!function (a, b, c, d) {
  function e(b, c) {
    this.settings = null, this.options = a.extend({}, e.Defaults, c), this.$element = a(b), this._handlers = {}, this._plugins = {}, this._supress = {}, this._current = null, this._speed = null, this._coordinates = [], this._breakpoint = null, this._width = null, this._items = [], this._clones = [], this._mergers = [], this._widths = [], this._invalidated = {}, this._pipe = [], this._drag = { time: null, target: null, pointer: null, stage: { start: null, current: null }, direction: null }, this._states = { current: {}, tags: { initializing: ["busy"], animating: ["busy"], dragging: ["interacting"] } }, a.each(["onResize", "onThrottledResize"], a.proxy(function (b, c) {
      this._handlers[c] = a.proxy(this[c], this);
    }, this)), a.each(e.Plugins, a.proxy(function (a, b) {
      this._plugins[a.charAt(0).toLowerCase() + a.slice(1)] = new b(this);
    }, this)), a.each(e.Workers, a.proxy(function (b, c) {
      this._pipe.push({ filter: c.filter, run: a.proxy(c.run, this) });
    }, this)), this.setup(), this.initialize();
  }e.Defaults = { items: 3, loop: !1, center: !1, rewind: !1, mouseDrag: !0, touchDrag: !0, pullDrag: !0, freeDrag: !1, margin: 0, stagePadding: 0, merge: !1, mergeFit: !0, autoWidth: !1, startPosition: 0, rtl: !1, smartSpeed: 250, fluidSpeed: !1, dragEndSpeed: !1, responsive: {}, responsiveRefreshRate: 200, responsiveBaseElement: b, fallbackEasing: "swing", info: !1, nestedItemSelector: !1, itemElement: "div", stageElement: "div", refreshClass: "owl-refresh", loadedClass: "owl-loaded", loadingClass: "owl-loading", rtlClass: "owl-rtl", responsiveClass: "owl-responsive", dragClass: "owl-drag", itemClass: "owl-item", stageClass: "owl-stage", stageOuterClass: "owl-stage-outer", grabClass: "owl-grab" }, e.Width = { Default: "default", Inner: "inner", Outer: "outer" }, e.Type = { Event: "event", State: "state" }, e.Plugins = {}, e.Workers = [{ filter: ["width", "settings"], run: function run() {
      this._width = this.$element.width();
    } }, { filter: ["width", "items", "settings"], run: function run(a) {
      a.current = this._items && this._items[this.relative(this._current)];
    } }, { filter: ["items", "settings"], run: function run() {
      this.$stage.children(".cloned").remove();
    } }, { filter: ["width", "items", "settings"], run: function run(a) {
      var b = this.settings.margin || "",
          c = !this.settings.autoWidth,
          d = this.settings.rtl,
          e = { width: "auto", "margin-left": d ? b : "", "margin-right": d ? "" : b };!c && this.$stage.children().css(e), a.css = e;
    } }, { filter: ["width", "items", "settings"], run: function run(a) {
      var b = (this.width() / this.settings.items).toFixed(3) - this.settings.margin,
          c = null,
          d = this._items.length,
          e = !this.settings.autoWidth,
          f = [];for (a.items = { merge: !1, width: b }; d--;) {
        c = this._mergers[d], c = this.settings.mergeFit && Math.min(c, this.settings.items) || c, a.items.merge = c > 1 || a.items.merge, f[d] = e ? b * c : this._items[d].width();
      }this._widths = f;
    } }, { filter: ["items", "settings"], run: function run() {
      var b = [],
          c = this._items,
          d = this.settings,
          e = Math.max(2 * d.items, 4),
          f = 2 * Math.ceil(c.length / 2),
          g = d.loop && c.length ? d.rewind ? e : Math.max(e, f) : 0,
          h = "",
          i = "";for (g /= 2; g--;) {
        b.push(this.normalize(b.length / 2, !0)), h += c[b[b.length - 1]][0].outerHTML, b.push(this.normalize(c.length - 1 - (b.length - 1) / 2, !0)), i = c[b[b.length - 1]][0].outerHTML + i;
      }this._clones = b, a(h).addClass("cloned").appendTo(this.$stage), a(i).addClass("cloned").prependTo(this.$stage);
    } }, { filter: ["width", "items", "settings"], run: function run() {
      for (var a = this.settings.rtl ? 1 : -1, b = this._clones.length + this._items.length, c = -1, d = 0, e = 0, f = []; ++c < b;) {
        d = f[c - 1] || 0, e = this._widths[this.relative(c)] + this.settings.margin, f.push(d + e * a);
      }this._coordinates = f;
    } }, { filter: ["width", "items", "settings"], run: function run() {
      var a = this.settings.stagePadding,
          b = this._coordinates,
          c = { width: Math.ceil(Math.abs(b[b.length - 1])) + 2 * a, "padding-left": a || "", "padding-right": a || "" };this.$stage.css(c);
    } }, { filter: ["width", "items", "settings"], run: function run(a) {
      var b = this._coordinates.length,
          c = !this.settings.autoWidth,
          d = this.$stage.children();if (c && a.items.merge) for (; b--;) {
        a.css.width = this._widths[this.relative(b)], d.eq(b).css(a.css);
      } else c && (a.css.width = a.items.width, d.css(a.css));
    } }, { filter: ["items"], run: function run() {
      this._coordinates.length < 1 && this.$stage.removeAttr("style");
    } }, { filter: ["width", "items", "settings"], run: function run(a) {
      a.current = a.current ? this.$stage.children().index(a.current) : 0, a.current = Math.max(this.minimum(), Math.min(this.maximum(), a.current)), this.reset(a.current);
    } }, { filter: ["position"], run: function run() {
      this.animate(this.coordinates(this._current));
    } }, { filter: ["width", "position", "items", "settings"], run: function run() {
      var a,
          b,
          c,
          d,
          e = this.settings.rtl ? 1 : -1,
          f = 2 * this.settings.stagePadding,
          g = this.coordinates(this.current()) + f,
          h = g + this.width() * e,
          i = [];for (c = 0, d = this._coordinates.length; c < d; c++) {
        a = this._coordinates[c - 1] || 0, b = Math.abs(this._coordinates[c]) + f * e, (this.op(a, "<=", g) && this.op(a, ">", h) || this.op(b, "<", g) && this.op(b, ">", h)) && i.push(c);
      }this.$stage.children(".active").removeClass("active"), this.$stage.children(":eq(" + i.join("), :eq(") + ")").addClass("active"), this.settings.center && (this.$stage.children(".center").removeClass("center"), this.$stage.children().eq(this.current()).addClass("center"));
    } }], e.prototype.initialize = function () {
    if (this.enter("initializing"), this.trigger("initialize"), this.$element.toggleClass(this.settings.rtlClass, this.settings.rtl), this.settings.autoWidth && !this.is("pre-loading")) {
      var b, c, e;b = this.$element.find("img"), c = this.settings.nestedItemSelector ? "." + this.settings.nestedItemSelector : d, e = this.$element.children(c).width(), b.length && e <= 0 && this.preloadAutoWidthImages(b);
    }this.$element.addClass(this.options.loadingClass), this.$stage = a("<" + this.settings.stageElement + ' class="' + this.settings.stageClass + '"/>').wrap('<div class="' + this.settings.stageOuterClass + '"/>'), this.$element.append(this.$stage.parent()), this.replace(this.$element.children().not(this.$stage.parent())), this.$element.is(":visible") ? this.refresh() : this.invalidate("width"), this.$element.removeClass(this.options.loadingClass).addClass(this.options.loadedClass), this.registerEventHandlers(), this.leave("initializing"), this.trigger("initialized");
  }, e.prototype.setup = function () {
    var b = this.viewport(),
        c = this.options.responsive,
        d = -1,
        e = null;c ? (a.each(c, function (a) {
      a <= b && a > d && (d = Number(a));
    }), e = a.extend({}, this.options, c[d]), "function" == typeof e.stagePadding && (e.stagePadding = e.stagePadding()), delete e.responsive, e.responsiveClass && this.$element.attr("class", this.$element.attr("class").replace(new RegExp("(" + this.options.responsiveClass + "-)\\S+\\s", "g"), "$1" + d))) : e = a.extend({}, this.options), this.trigger("change", { property: { name: "settings", value: e } }), this._breakpoint = d, this.settings = e, this.invalidate("settings"), this.trigger("changed", { property: { name: "settings", value: this.settings } });
  }, e.prototype.optionsLogic = function () {
    this.settings.autoWidth && (this.settings.stagePadding = !1, this.settings.merge = !1);
  }, e.prototype.prepare = function (b) {
    var c = this.trigger("prepare", { content: b });return c.data || (c.data = a("<" + this.settings.itemElement + "/>").addClass(this.options.itemClass).append(b)), this.trigger("prepared", { content: c.data }), c.data;
  }, e.prototype.update = function () {
    for (var b = 0, c = this._pipe.length, d = a.proxy(function (a) {
      return this[a];
    }, this._invalidated), e = {}; b < c;) {
      (this._invalidated.all || a.grep(this._pipe[b].filter, d).length > 0) && this._pipe[b].run(e), b++;
    }this._invalidated = {}, !this.is("valid") && this.enter("valid");
  }, e.prototype.width = function (a) {
    switch (a = a || e.Width.Default) {case e.Width.Inner:case e.Width.Outer:
        return this._width;default:
        return this._width - 2 * this.settings.stagePadding + this.settings.margin;}
  }, e.prototype.refresh = function () {
    this.enter("refreshing"), this.trigger("refresh"), this.setup(), this.optionsLogic(), this.$element.addClass(this.options.refreshClass), this.update(), this.$element.removeClass(this.options.refreshClass), this.leave("refreshing"), this.trigger("refreshed");
  }, e.prototype.onThrottledResize = function () {
    b.clearTimeout(this.resizeTimer), this.resizeTimer = b.setTimeout(this._handlers.onResize, this.settings.responsiveRefreshRate);
  }, e.prototype.onResize = function () {
    return !!this._items.length && this._width !== this.$element.width() && !!this.$element.is(":visible") && (this.enter("resizing"), this.trigger("resize").isDefaultPrevented() ? (this.leave("resizing"), !1) : (this.invalidate("width"), this.refresh(), this.leave("resizing"), void this.trigger("resized")));
  }, e.prototype.registerEventHandlers = function () {
    a.support.transition && this.$stage.on(a.support.transition.end + ".owl.core", a.proxy(this.onTransitionEnd, this)), this.settings.responsive !== !1 && this.on(b, "resize", this._handlers.onThrottledResize), this.settings.mouseDrag && (this.$element.addClass(this.options.dragClass), this.$stage.on("mousedown.owl.core", a.proxy(this.onDragStart, this)), this.$stage.on("dragstart.owl.core selectstart.owl.core", function () {
      return !1;
    })), this.settings.touchDrag && (this.$stage.on("touchstart.owl.core", a.proxy(this.onDragStart, this)), this.$stage.on("touchcancel.owl.core", a.proxy(this.onDragEnd, this)));
  }, e.prototype.onDragStart = function (b) {
    var d = null;3 !== b.which && (a.support.transform ? (d = this.$stage.css("transform").replace(/.*\(|\)| /g, "").split(","), d = { x: d[16 === d.length ? 12 : 4], y: d[16 === d.length ? 13 : 5] }) : (d = this.$stage.position(), d = { x: this.settings.rtl ? d.left + this.$stage.width() - this.width() + this.settings.margin : d.left, y: d.top }), this.is("animating") && (a.support.transform ? this.animate(d.x) : this.$stage.stop(), this.invalidate("position")), this.$element.toggleClass(this.options.grabClass, "mousedown" === b.type), this.speed(0), this._drag.time = new Date().getTime(), this._drag.target = a(b.target), this._drag.stage.start = d, this._drag.stage.current = d, this._drag.pointer = this.pointer(b), a(c).on("mouseup.owl.core touchend.owl.core", a.proxy(this.onDragEnd, this)), a(c).one("mousemove.owl.core touchmove.owl.core", a.proxy(function (b) {
      var d = this.difference(this._drag.pointer, this.pointer(b));a(c).on("mousemove.owl.core touchmove.owl.core", a.proxy(this.onDragMove, this)), Math.abs(d.x) < Math.abs(d.y) && this.is("valid") || (b.preventDefault(), this.enter("dragging"), this.trigger("drag"));
    }, this)));
  }, e.prototype.onDragMove = function (a) {
    var b = null,
        c = null,
        d = null,
        e = this.difference(this._drag.pointer, this.pointer(a)),
        f = this.difference(this._drag.stage.start, e);this.is("dragging") && (a.preventDefault(), this.settings.loop ? (b = this.coordinates(this.minimum()), c = this.coordinates(this.maximum() + 1) - b, f.x = ((f.x - b) % c + c) % c + b) : (b = this.settings.rtl ? this.coordinates(this.maximum()) : this.coordinates(this.minimum()), c = this.settings.rtl ? this.coordinates(this.minimum()) : this.coordinates(this.maximum()), d = this.settings.pullDrag ? -1 * e.x / 5 : 0, f.x = Math.max(Math.min(f.x, b + d), c + d)), this._drag.stage.current = f, this.animate(f.x));
  }, e.prototype.onDragEnd = function (b) {
    var d = this.difference(this._drag.pointer, this.pointer(b)),
        e = this._drag.stage.current,
        f = d.x > 0 ^ this.settings.rtl ? "left" : "right";a(c).off(".owl.core"), this.$element.removeClass(this.options.grabClass), (0 !== d.x && this.is("dragging") || !this.is("valid")) && (this.speed(this.settings.dragEndSpeed || this.settings.smartSpeed), this.current(this.closest(e.x, 0 !== d.x ? f : this._drag.direction)), this.invalidate("position"), this.update(), this._drag.direction = f, (Math.abs(d.x) > 3 || new Date().getTime() - this._drag.time > 300) && this._drag.target.one("click.owl.core", function () {
      return !1;
    })), this.is("dragging") && (this.leave("dragging"), this.trigger("dragged"));
  }, e.prototype.closest = function (b, c) {
    var d = -1,
        e = 30,
        f = this.width(),
        g = this.coordinates();return this.settings.freeDrag || a.each(g, a.proxy(function (a, h) {
      return "left" === c && b > h - e && b < h + e ? d = a : "right" === c && b > h - f - e && b < h - f + e ? d = a + 1 : this.op(b, "<", h) && this.op(b, ">", g[a + 1] || h - f) && (d = "left" === c ? a + 1 : a), d === -1;
    }, this)), this.settings.loop || (this.op(b, ">", g[this.minimum()]) ? d = b = this.minimum() : this.op(b, "<", g[this.maximum()]) && (d = b = this.maximum())), d;
  }, e.prototype.animate = function (b) {
    var c = this.speed() > 0;this.is("animating") && this.onTransitionEnd(), c && (this.enter("animating"), this.trigger("translate")), a.support.transform3d && a.support.transition ? this.$stage.css({ transform: "translate3d(" + b + "px,0px,0px)", transition: this.speed() / 1e3 + "s" }) : c ? this.$stage.animate({ left: b + "px" }, this.speed(), this.settings.fallbackEasing, a.proxy(this.onTransitionEnd, this)) : this.$stage.css({ left: b + "px" });
  }, e.prototype.is = function (a) {
    return this._states.current[a] && this._states.current[a] > 0;
  }, e.prototype.current = function (a) {
    if (a === d) return this._current;if (0 === this._items.length) return d;if (a = this.normalize(a), this._current !== a) {
      var b = this.trigger("change", { property: { name: "position", value: a } });b.data !== d && (a = this.normalize(b.data)), this._current = a, this.invalidate("position"), this.trigger("changed", { property: { name: "position", value: this._current } });
    }return this._current;
  }, e.prototype.invalidate = function (b) {
    return "string" === a.type(b) && (this._invalidated[b] = !0, this.is("valid") && this.leave("valid")), a.map(this._invalidated, function (a, b) {
      return b;
    });
  }, e.prototype.reset = function (a) {
    a = this.normalize(a), a !== d && (this._speed = 0, this._current = a, this.suppress(["translate", "translated"]), this.animate(this.coordinates(a)), this.release(["translate", "translated"]));
  }, e.prototype.normalize = function (a, b) {
    var c = this._items.length,
        e = b ? 0 : this._clones.length;return !this.isNumeric(a) || c < 1 ? a = d : (a < 0 || a >= c + e) && (a = ((a - e / 2) % c + c) % c + e / 2), a;
  }, e.prototype.relative = function (a) {
    return a -= this._clones.length / 2, this.normalize(a, !0);
  }, e.prototype.maximum = function (a) {
    var b,
        c,
        d,
        e = this.settings,
        f = this._coordinates.length;if (e.loop) f = this._clones.length / 2 + this._items.length - 1;else if (e.autoWidth || e.merge) {
      for (b = this._items.length, c = this._items[--b].width(), d = this.$element.width(); b-- && (c += this._items[b].width() + this.settings.margin, !(c > d));) {}f = b + 1;
    } else f = e.center ? this._items.length - 1 : this._items.length - e.items;return a && (f -= this._clones.length / 2), Math.max(f, 0);
  }, e.prototype.minimum = function (a) {
    return a ? 0 : this._clones.length / 2;
  }, e.prototype.items = function (a) {
    return a === d ? this._items.slice() : (a = this.normalize(a, !0), this._items[a]);
  }, e.prototype.mergers = function (a) {
    return a === d ? this._mergers.slice() : (a = this.normalize(a, !0), this._mergers[a]);
  }, e.prototype.clones = function (b) {
    var c = this._clones.length / 2,
        e = c + this._items.length,
        f = function f(a) {
      return a % 2 === 0 ? e + a / 2 : c - (a + 1) / 2;
    };return b === d ? a.map(this._clones, function (a, b) {
      return f(b);
    }) : a.map(this._clones, function (a, c) {
      return a === b ? f(c) : null;
    });
  }, e.prototype.speed = function (a) {
    return a !== d && (this._speed = a), this._speed;
  }, e.prototype.coordinates = function (b) {
    var c,
        e = 1,
        f = b - 1;return b === d ? a.map(this._coordinates, a.proxy(function (a, b) {
      return this.coordinates(b);
    }, this)) : (this.settings.center ? (this.settings.rtl && (e = -1, f = b + 1), c = this._coordinates[b], c += (this.width() - c + (this._coordinates[f] || 0)) / 2 * e) : c = this._coordinates[f] || 0, c = Math.ceil(c));
  }, e.prototype.duration = function (a, b, c) {
    return 0 === c ? 0 : Math.min(Math.max(Math.abs(b - a), 1), 6) * Math.abs(c || this.settings.smartSpeed);
  }, e.prototype.to = function (a, b) {
    var c = this.current(),
        d = null,
        e = a - this.relative(c),
        f = (e > 0) - (e < 0),
        g = this._items.length,
        h = this.minimum(),
        i = this.maximum();this.settings.loop ? (!this.settings.rewind && Math.abs(e) > g / 2 && (e += f * -1 * g), a = c + e, d = ((a - h) % g + g) % g + h, d !== a && d - e <= i && d - e > 0 && (c = d - e, a = d, this.reset(c))) : this.settings.rewind ? (i += 1, a = (a % i + i) % i) : a = Math.max(h, Math.min(i, a)), this.speed(this.duration(c, a, b)), this.current(a), this.$element.is(":visible") && this.update();
  }, e.prototype.next = function (a) {
    a = a || !1, this.to(this.relative(this.current()) + 1, a);
  }, e.prototype.prev = function (a) {
    a = a || !1, this.to(this.relative(this.current()) - 1, a);
  }, e.prototype.onTransitionEnd = function (a) {
    if (a !== d && (a.stopPropagation(), (a.target || a.srcElement || a.originalTarget) !== this.$stage.get(0))) return !1;this.leave("animating"), this.trigger("translated");
  }, e.prototype.viewport = function () {
    var d;return this.options.responsiveBaseElement !== b ? d = a(this.options.responsiveBaseElement).width() : b.innerWidth ? d = b.innerWidth : c.documentElement && c.documentElement.clientWidth ? d = c.documentElement.clientWidth : console.warn("Can not detect viewport width."), d;
  }, e.prototype.replace = function (b) {
    this.$stage.empty(), this._items = [], b && (b = b instanceof jQuery ? b : a(b)), this.settings.nestedItemSelector && (b = b.find("." + this.settings.nestedItemSelector)), b.filter(function () {
      return 1 === this.nodeType;
    }).each(a.proxy(function (a, b) {
      b = this.prepare(b), this.$stage.append(b), this._items.push(b), this._mergers.push(1 * b.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1);
    }, this)), this.reset(this.isNumeric(this.settings.startPosition) ? this.settings.startPosition : 0), this.invalidate("items");
  }, e.prototype.add = function (b, c) {
    var e = this.relative(this._current);c = c === d ? this._items.length : this.normalize(c, !0), b = b instanceof jQuery ? b : a(b), this.trigger("add", { content: b, position: c }), b = this.prepare(b), 0 === this._items.length || c === this._items.length ? (0 === this._items.length && this.$stage.append(b), 0 !== this._items.length && this._items[c - 1].after(b), this._items.push(b), this._mergers.push(1 * b.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1)) : (this._items[c].before(b), this._items.splice(c, 0, b), this._mergers.splice(c, 0, 1 * b.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1)), this._items[e] && this.reset(this._items[e].index()), this.invalidate("items"), this.trigger("added", { content: b, position: c });
  }, e.prototype.remove = function (a) {
    a = this.normalize(a, !0), a !== d && (this.trigger("remove", { content: this._items[a], position: a }), this._items[a].remove(), this._items.splice(a, 1), this._mergers.splice(a, 1), this.invalidate("items"), this.trigger("removed", { content: null, position: a }));
  }, e.prototype.preloadAutoWidthImages = function (b) {
    b.each(a.proxy(function (b, c) {
      this.enter("pre-loading"), c = a(c), a(new Image()).one("load", a.proxy(function (a) {
        c.attr("src", a.target.src), c.css("opacity", 1), this.leave("pre-loading"), !this.is("pre-loading") && !this.is("initializing") && this.refresh();
      }, this)).attr("src", c.attr("src") || c.attr("data-src") || c.attr("data-src-retina"));
    }, this));
  }, e.prototype.destroy = function () {
    this.$element.off(".owl.core"), this.$stage.off(".owl.core"), a(c).off(".owl.core"), this.settings.responsive !== !1 && (b.clearTimeout(this.resizeTimer), this.off(b, "resize", this._handlers.onThrottledResize));for (var d in this._plugins) {
      this._plugins[d].destroy();
    }this.$stage.children(".cloned").remove(), this.$stage.unwrap(), this.$stage.children().contents().unwrap(), this.$stage.children().unwrap(), this.$element.removeClass(this.options.refreshClass).removeClass(this.options.loadingClass).removeClass(this.options.loadedClass).removeClass(this.options.rtlClass).removeClass(this.options.dragClass).removeClass(this.options.grabClass).attr("class", this.$element.attr("class").replace(new RegExp(this.options.responsiveClass + "-\\S+\\s", "g"), "")).removeData("owl.carousel");
  }, e.prototype.op = function (a, b, c) {
    var d = this.settings.rtl;switch (b) {case "<":
        return d ? a > c : a < c;case ">":
        return d ? a < c : a > c;case ">=":
        return d ? a <= c : a >= c;case "<=":
        return d ? a >= c : a <= c;}
  }, e.prototype.on = function (a, b, c, d) {
    a.addEventListener ? a.addEventListener(b, c, d) : a.attachEvent && a.attachEvent("on" + b, c);
  }, e.prototype.off = function (a, b, c, d) {
    a.removeEventListener ? a.removeEventListener(b, c, d) : a.detachEvent && a.detachEvent("on" + b, c);
  }, e.prototype.trigger = function (b, c, d, f, g) {
    var h = { item: { count: this._items.length, index: this.current() } },
        i = a.camelCase(a.grep(["on", b, d], function (a) {
      return a;
    }).join("-").toLowerCase()),
        j = a.Event([b, "owl", d || "carousel"].join(".").toLowerCase(), a.extend({ relatedTarget: this }, h, c));return this._supress[b] || (a.each(this._plugins, function (a, b) {
      b.onTrigger && b.onTrigger(j);
    }), this.register({ type: e.Type.Event, name: b }), this.$element.trigger(j), this.settings && "function" == typeof this.settings[i] && this.settings[i].call(this, j)), j;
  }, e.prototype.enter = function (b) {
    a.each([b].concat(this._states.tags[b] || []), a.proxy(function (a, b) {
      this._states.current[b] === d && (this._states.current[b] = 0), this._states.current[b]++;
    }, this));
  }, e.prototype.leave = function (b) {
    a.each([b].concat(this._states.tags[b] || []), a.proxy(function (a, b) {
      this._states.current[b]--;
    }, this));
  }, e.prototype.register = function (b) {
    if (b.type === e.Type.Event) {
      if (a.event.special[b.name] || (a.event.special[b.name] = {}), !a.event.special[b.name].owl) {
        var c = a.event.special[b.name]._default;a.event.special[b.name]._default = function (a) {
          return !c || !c.apply || a.namespace && a.namespace.indexOf("owl") !== -1 ? a.namespace && a.namespace.indexOf("owl") > -1 : c.apply(this, arguments);
        }, a.event.special[b.name].owl = !0;
      }
    } else b.type === e.Type.State && (this._states.tags[b.name] ? this._states.tags[b.name] = this._states.tags[b.name].concat(b.tags) : this._states.tags[b.name] = b.tags, this._states.tags[b.name] = a.grep(this._states.tags[b.name], a.proxy(function (c, d) {
      return a.inArray(c, this._states.tags[b.name]) === d;
    }, this)));
  }, e.prototype.suppress = function (b) {
    a.each(b, a.proxy(function (a, b) {
      this._supress[b] = !0;
    }, this));
  }, e.prototype.release = function (b) {
    a.each(b, a.proxy(function (a, b) {
      delete this._supress[b];
    }, this));
  }, e.prototype.pointer = function (a) {
    var c = { x: null, y: null };return a = a.originalEvent || a || b.event, a = a.touches && a.touches.length ? a.touches[0] : a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : a, a.pageX ? (c.x = a.pageX, c.y = a.pageY) : (c.x = a.clientX, c.y = a.clientY), c;
  }, e.prototype.isNumeric = function (a) {
    return !isNaN(parseFloat(a));
  }, e.prototype.difference = function (a, b) {
    return { x: a.x - b.x, y: a.y - b.y };
  }, a.fn.owlCarousel = function (b) {
    var c = Array.prototype.slice.call(arguments, 1);return this.each(function () {
      var d = a(this),
          f = d.data("owl.carousel");f || (f = new e(this, "object" == (typeof b === "undefined" ? "undefined" : _typeof(b)) && b), d.data("owl.carousel", f), a.each(["next", "prev", "to", "destroy", "refresh", "replace", "add", "remove"], function (b, c) {
        f.register({ type: e.Type.Event, name: c }), f.$element.on(c + ".owl.carousel.core", a.proxy(function (a) {
          a.namespace && a.relatedTarget !== this && (this.suppress([c]), f[c].apply(this, [].slice.call(arguments, 1)), this.release([c]));
        }, f));
      })), "string" == typeof b && "_" !== b.charAt(0) && f[b].apply(f, c);
    });
  }, a.fn.owlCarousel.Constructor = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this._core = b, this._interval = null, this._visible = null, this._handlers = { "initialized.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.autoRefresh && this.watch();
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers);
  };e.Defaults = { autoRefresh: !0, autoRefreshInterval: 500 }, e.prototype.watch = function () {
    this._interval || (this._visible = this._core.$element.is(":visible"), this._interval = b.setInterval(a.proxy(this.refresh, this), this._core.settings.autoRefreshInterval));
  }, e.prototype.refresh = function () {
    this._core.$element.is(":visible") !== this._visible && (this._visible = !this._visible, this._core.$element.toggleClass("owl-hidden", !this._visible), this._visible && this._core.invalidate("width") && this._core.refresh());
  }, e.prototype.destroy = function () {
    var a, c;b.clearInterval(this._interval);for (a in this._handlers) {
      this._core.$element.off(a, this._handlers[a]);
    }for (c in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[c] && (this[c] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.AutoRefresh = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this._core = b, this._loaded = [], this._handlers = { "initialized.owl.carousel change.owl.carousel resized.owl.carousel": a.proxy(function (b) {
        if (b.namespace && this._core.settings && this._core.settings.lazyLoad && (b.property && "position" == b.property.name || "initialized" == b.type)) for (var c = this._core.settings, e = c.center && Math.ceil(c.items / 2) || c.items, f = c.center && e * -1 || 0, g = (b.property && b.property.value !== d ? b.property.value : this._core.current()) + f, h = this._core.clones().length, i = a.proxy(function (a, b) {
          this.load(b);
        }, this); f++ < e;) {
          this.load(h / 2 + this._core.relative(g)), h && a.each(this._core.clones(this._core.relative(g)), i), g++;
        }
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers);
  };e.Defaults = { lazyLoad: !1 }, e.prototype.load = function (c) {
    var d = this._core.$stage.children().eq(c),
        e = d && d.find(".owl-lazy");!e || a.inArray(d.get(0), this._loaded) > -1 || (e.each(a.proxy(function (c, d) {
      var e,
          f = a(d),
          g = b.devicePixelRatio > 1 && f.attr("data-src-retina") || f.attr("data-src");this._core.trigger("load", { element: f, url: g }, "lazy"), f.is("img") ? f.one("load.owl.lazy", a.proxy(function () {
        f.css("opacity", 1), this._core.trigger("loaded", { element: f, url: g }, "lazy");
      }, this)).attr("src", g) : (e = new Image(), e.onload = a.proxy(function () {
        f.css({ "background-image": 'url("' + g + '")', opacity: "1" }), this._core.trigger("loaded", { element: f, url: g }, "lazy");
      }, this), e.src = g);
    }, this)), this._loaded.push(d.get(0)));
  }, e.prototype.destroy = function () {
    var a, b;for (a in this.handlers) {
      this._core.$element.off(a, this.handlers[a]);
    }for (b in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[b] && (this[b] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.Lazy = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this._core = b, this._handlers = { "initialized.owl.carousel refreshed.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.autoHeight && this.update();
      }, this), "changed.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.autoHeight && "position" == a.property.name && this.update();
      }, this), "loaded.owl.lazy": a.proxy(function (a) {
        a.namespace && this._core.settings.autoHeight && a.element.closest("." + this._core.settings.itemClass).index() === this._core.current() && this.update();
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers);
  };e.Defaults = { autoHeight: !1, autoHeightClass: "owl-height" }, e.prototype.update = function () {
    var b = this._core._current,
        c = b + this._core.settings.items,
        d = this._core.$stage.children().toArray().slice(b, c),
        e = [],
        f = 0;a.each(d, function (b, c) {
      e.push(a(c).height());
    }), f = Math.max.apply(null, e), this._core.$stage.parent().height(f).addClass(this._core.settings.autoHeightClass);
  }, e.prototype.destroy = function () {
    var a, b;for (a in this._handlers) {
      this._core.$element.off(a, this._handlers[a]);
    }for (b in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[b] && (this[b] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.AutoHeight = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this._core = b, this._videos = {}, this._playing = null, this._handlers = { "initialized.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.register({ type: "state", name: "playing", tags: ["interacting"] });
      }, this), "resize.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.video && this.isInFullScreen() && a.preventDefault();
      }, this), "refreshed.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.is("resizing") && this._core.$stage.find(".cloned .owl-video-frame").remove();
      }, this), "changed.owl.carousel": a.proxy(function (a) {
        a.namespace && "position" === a.property.name && this._playing && this.stop();
      }, this), "prepared.owl.carousel": a.proxy(function (b) {
        if (b.namespace) {
          var c = a(b.content).find(".owl-video");c.length && (c.css("display", "none"), this.fetch(c, a(b.content)));
        }
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers), this._core.$element.on("click.owl.video", ".owl-video-play-icon", a.proxy(function (a) {
      this.play(a);
    }, this));
  };e.Defaults = { video: !1, videoHeight: !1, videoWidth: !1 }, e.prototype.fetch = function (a, b) {
    var c = function () {
      return a.attr("data-vimeo-id") ? "vimeo" : a.attr("data-vzaar-id") ? "vzaar" : "youtube";
    }(),
        d = a.attr("data-vimeo-id") || a.attr("data-youtube-id") || a.attr("data-vzaar-id"),
        e = a.attr("data-width") || this._core.settings.videoWidth,
        f = a.attr("data-height") || this._core.settings.videoHeight,
        g = a.attr("href");if (!g) throw new Error("Missing video URL.");if (d = g.match(/(http:|https:|)\/\/(player.|www.|app.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com)|vzaar\.com)\/(video\/|videos\/|embed\/|channels\/.+\/|groups\/.+\/|watch\?v=|v\/)?([A-Za-z0-9._%-]*)(\&\S+)?/), d[3].indexOf("youtu") > -1) c = "youtube";else if (d[3].indexOf("vimeo") > -1) c = "vimeo";else {
      if (!(d[3].indexOf("vzaar") > -1)) throw new Error("Video URL not supported.");c = "vzaar";
    }d = d[6], this._videos[g] = { type: c, id: d, width: e, height: f }, b.attr("data-video", g), this.thumbnail(a, this._videos[g]);
  }, e.prototype.thumbnail = function (b, c) {
    var d,
        e,
        f,
        g = c.width && c.height ? 'style="width:' + c.width + "px;height:" + c.height + 'px;"' : "",
        h = b.find("img"),
        i = "src",
        j = "",
        k = this._core.settings,
        l = function l(a) {
      e = '<div class="owl-video-play-icon"></div>', d = k.lazyLoad ? '<div class="owl-video-tn ' + j + '" ' + i + '="' + a + '"></div>' : '<div class="owl-video-tn" style="opacity:1;background-image:url(' + a + ')"></div>', b.after(d), b.after(e);
    };if (b.wrap('<div class="owl-video-wrapper"' + g + "></div>"), this._core.settings.lazyLoad && (i = "data-src", j = "owl-lazy"), h.length) return l(h.attr(i)), h.remove(), !1;"youtube" === c.type ? (f = "//img.youtube.com/vi/" + c.id + "/hqdefault.jpg", l(f)) : "vimeo" === c.type ? a.ajax({ type: "GET", url: "//vimeo.com/api/v2/video/" + c.id + ".json", jsonp: "callback", dataType: "jsonp", success: function success(a) {
        f = a[0].thumbnail_large, l(f);
      } }) : "vzaar" === c.type && a.ajax({ type: "GET", url: "//vzaar.com/api/videos/" + c.id + ".json", jsonp: "callback", dataType: "jsonp", success: function success(a) {
        f = a.framegrab_url, l(f);
      } });
  }, e.prototype.stop = function () {
    this._core.trigger("stop", null, "video"), this._playing.find(".owl-video-frame").remove(), this._playing.removeClass("owl-video-playing"), this._playing = null, this._core.leave("playing"), this._core.trigger("stopped", null, "video");
  }, e.prototype.play = function (b) {
    var c,
        d = a(b.target),
        e = d.closest("." + this._core.settings.itemClass),
        f = this._videos[e.attr("data-video")],
        g = f.width || "100%",
        h = f.height || this._core.$stage.height();this._playing || (this._core.enter("playing"), this._core.trigger("play", null, "video"), e = this._core.items(this._core.relative(e.index())), this._core.reset(e.index()), "youtube" === f.type ? c = '<iframe width="' + g + '" height="' + h + '" src="//www.youtube.com/embed/' + f.id + "?autoplay=1&rel=0&v=" + f.id + '" frameborder="0" allowfullscreen></iframe>' : "vimeo" === f.type ? c = '<iframe src="//player.vimeo.com/video/' + f.id + '?autoplay=1" width="' + g + '" height="' + h + '" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>' : "vzaar" === f.type && (c = '<iframe frameborder="0"height="' + h + '"width="' + g + '" allowfullscreen mozallowfullscreen webkitAllowFullScreen src="//view.vzaar.com/' + f.id + '/player?autoplay=true"></iframe>'), a('<div class="owl-video-frame">' + c + "</div>").insertAfter(e.find(".owl-video")), this._playing = e.addClass("owl-video-playing"));
  }, e.prototype.isInFullScreen = function () {
    var b = c.fullscreenElement || c.mozFullScreenElement || c.webkitFullscreenElement;return b && a(b).parent().hasClass("owl-video-frame");
  }, e.prototype.destroy = function () {
    var a, b;this._core.$element.off("click.owl.video");for (a in this._handlers) {
      this._core.$element.off(a, this._handlers[a]);
    }for (b in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[b] && (this[b] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.Video = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this.core = b, this.core.options = a.extend({}, e.Defaults, this.core.options), this.swapping = !0, this.previous = d, this.next = d, this.handlers = { "change.owl.carousel": a.proxy(function (a) {
        a.namespace && "position" == a.property.name && (this.previous = this.core.current(), this.next = a.property.value);
      }, this), "drag.owl.carousel dragged.owl.carousel translated.owl.carousel": a.proxy(function (a) {
        a.namespace && (this.swapping = "translated" == a.type);
      }, this), "translate.owl.carousel": a.proxy(function (a) {
        a.namespace && this.swapping && (this.core.options.animateOut || this.core.options.animateIn) && this.swap();
      }, this) }, this.core.$element.on(this.handlers);
  };e.Defaults = { animateOut: !1, animateIn: !1 }, e.prototype.swap = function () {
    if (1 === this.core.settings.items && a.support.animation && a.support.transition) {
      this.core.speed(0);var b,
          c = a.proxy(this.clear, this),
          d = this.core.$stage.children().eq(this.previous),
          e = this.core.$stage.children().eq(this.next),
          f = this.core.settings.animateIn,
          g = this.core.settings.animateOut;this.core.current() !== this.previous && (g && (b = this.core.coordinates(this.previous) - this.core.coordinates(this.next), d.one(a.support.animation.end, c).css({ left: b + "px" }).addClass("animated owl-animated-out").addClass(g)), f && e.one(a.support.animation.end, c).addClass("animated owl-animated-in").addClass(f));
    }
  }, e.prototype.clear = function (b) {
    a(b.target).css({ left: "" }).removeClass("animated owl-animated-out owl-animated-in").removeClass(this.core.settings.animateIn).removeClass(this.core.settings.animateOut), this.core.onTransitionEnd();
  }, e.prototype.destroy = function () {
    var a, b;for (a in this.handlers) {
      this.core.$element.off(a, this.handlers[a]);
    }for (b in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[b] && (this[b] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.Animate = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  var e = function e(b) {
    this._core = b, this._timeout = null, this._paused = !1, this._handlers = { "changed.owl.carousel": a.proxy(function (a) {
        a.namespace && "settings" === a.property.name ? this._core.settings.autoplay ? this.play() : this.stop() : a.namespace && "position" === a.property.name && this._core.settings.autoplay && this._setAutoPlayInterval();
      }, this), "initialized.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.autoplay && this.play();
      }, this), "play.owl.autoplay": a.proxy(function (a, b, c) {
        a.namespace && this.play(b, c);
      }, this), "stop.owl.autoplay": a.proxy(function (a) {
        a.namespace && this.stop();
      }, this), "mouseover.owl.autoplay": a.proxy(function () {
        this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.pause();
      }, this), "mouseleave.owl.autoplay": a.proxy(function () {
        this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.play();
      }, this), "touchstart.owl.core": a.proxy(function () {
        this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.pause();
      }, this), "touchend.owl.core": a.proxy(function () {
        this._core.settings.autoplayHoverPause && this.play();
      }, this) }, this._core.$element.on(this._handlers), this._core.options = a.extend({}, e.Defaults, this._core.options);
  };e.Defaults = { autoplay: !1, autoplayTimeout: 5e3, autoplayHoverPause: !1, autoplaySpeed: !1 }, e.prototype.play = function (a, b) {
    this._paused = !1, this._core.is("rotating") || (this._core.enter("rotating"), this._setAutoPlayInterval());
  }, e.prototype._getNextTimeout = function (d, e) {
    return this._timeout && b.clearTimeout(this._timeout), b.setTimeout(a.proxy(function () {
      this._paused || this._core.is("busy") || this._core.is("interacting") || c.hidden || this._core.next(e || this._core.settings.autoplaySpeed);
    }, this), d || this._core.settings.autoplayTimeout);
  }, e.prototype._setAutoPlayInterval = function () {
    this._timeout = this._getNextTimeout();
  }, e.prototype.stop = function () {
    this._core.is("rotating") && (b.clearTimeout(this._timeout), this._core.leave("rotating"));
  }, e.prototype.pause = function () {
    this._core.is("rotating") && (this._paused = !0);
  }, e.prototype.destroy = function () {
    var a, b;this.stop();for (a in this._handlers) {
      this._core.$element.off(a, this._handlers[a]);
    }for (b in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[b] && (this[b] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.autoplay = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  "use strict";
  var e = function e(b) {
    this._core = b, this._initialized = !1, this._pages = [], this._controls = {}, this._templates = [], this.$element = this._core.$element, this._overrides = { next: this._core.next, prev: this._core.prev, to: this._core.to }, this._handlers = { "prepared.owl.carousel": a.proxy(function (b) {
        b.namespace && this._core.settings.dotsData && this._templates.push('<div class="' + this._core.settings.dotClass + '">' + a(b.content).find("[data-dot]").addBack("[data-dot]").attr("data-dot") + "</div>");
      }, this), "added.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.dotsData && this._templates.splice(a.position, 0, this._templates.pop());
      }, this), "remove.owl.carousel": a.proxy(function (a) {
        a.namespace && this._core.settings.dotsData && this._templates.splice(a.position, 1);
      }, this), "changed.owl.carousel": a.proxy(function (a) {
        a.namespace && "position" == a.property.name && this.draw();
      }, this), "initialized.owl.carousel": a.proxy(function (a) {
        a.namespace && !this._initialized && (this._core.trigger("initialize", null, "navigation"), this.initialize(), this.update(), this.draw(), this._initialized = !0, this._core.trigger("initialized", null, "navigation"));
      }, this), "refreshed.owl.carousel": a.proxy(function (a) {
        a.namespace && this._initialized && (this._core.trigger("refresh", null, "navigation"), this.update(), this.draw(), this._core.trigger("refreshed", null, "navigation"));
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this.$element.on(this._handlers);
  };e.Defaults = { nav: !1, navText: ["prev", "next"], navSpeed: !1, navElement: "div", navContainer: !1, navContainerClass: "owl-nav", navClass: ["owl-prev", "owl-next"], slideBy: 1, dotClass: "owl-dot", dotsClass: "owl-dots", dots: !0, dotsEach: !1, dotsData: !1, dotsSpeed: !1, dotsContainer: !1 }, e.prototype.initialize = function () {
    var b,
        c = this._core.settings;this._controls.$relative = (c.navContainer ? a(c.navContainer) : a("<div>").addClass(c.navContainerClass).appendTo(this.$element)).addClass("disabled"), this._controls.$previous = a("<" + c.navElement + ">").addClass(c.navClass[0]).html(c.navText[0]).prependTo(this._controls.$relative).on("click", a.proxy(function (a) {
      this.prev(c.navSpeed);
    }, this)), this._controls.$next = a("<" + c.navElement + ">").addClass(c.navClass[1]).html(c.navText[1]).appendTo(this._controls.$relative).on("click", a.proxy(function (a) {
      this.next(c.navSpeed);
    }, this)), c.dotsData || (this._templates = [a("<div>").addClass(c.dotClass).append(a("<span>")).prop("outerHTML")]), this._controls.$absolute = (c.dotsContainer ? a(c.dotsContainer) : a("<div>").addClass(c.dotsClass).appendTo(this.$element)).addClass("disabled"), this._controls.$absolute.on("click", "div", a.proxy(function (b) {
      var d = a(b.target).parent().is(this._controls.$absolute) ? a(b.target).index() : a(b.target).parent().index();b.preventDefault(), this.to(d, c.dotsSpeed);
    }, this));for (b in this._overrides) {
      this._core[b] = a.proxy(this[b], this);
    }
  }, e.prototype.destroy = function () {
    var a, b, c, d;for (a in this._handlers) {
      this.$element.off(a, this._handlers[a]);
    }for (b in this._controls) {
      this._controls[b].remove();
    }for (d in this.overides) {
      this._core[d] = this._overrides[d];
    }for (c in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[c] && (this[c] = null);
    }
  }, e.prototype.update = function () {
    var a,
        b,
        c,
        d = this._core.clones().length / 2,
        e = d + this._core.items().length,
        f = this._core.maximum(!0),
        g = this._core.settings,
        h = g.center || g.autoWidth || g.dotsData ? 1 : g.dotsEach || g.items;if ("page" !== g.slideBy && (g.slideBy = Math.min(g.slideBy, g.items)), g.dots || "page" == g.slideBy) for (this._pages = [], a = d, b = 0, c = 0; a < e; a++) {
      if (b >= h || 0 === b) {
        if (this._pages.push({ start: Math.min(f, a - d), end: a - d + h - 1 }), Math.min(f, a - d) === f) break;b = 0, ++c;
      }b += this._core.mergers(this._core.relative(a));
    }
  }, e.prototype.draw = function () {
    var b,
        c = this._core.settings,
        d = this._core.items().length <= c.items,
        e = this._core.relative(this._core.current()),
        f = c.loop || c.rewind;this._controls.$relative.toggleClass("disabled", !c.nav || d), c.nav && (this._controls.$previous.toggleClass("disabled", !f && e <= this._core.minimum(!0)), this._controls.$next.toggleClass("disabled", !f && e >= this._core.maximum(!0))), this._controls.$absolute.toggleClass("disabled", !c.dots || d), c.dots && (b = this._pages.length - this._controls.$absolute.children().length, c.dotsData && 0 !== b ? this._controls.$absolute.html(this._templates.join("")) : b > 0 ? this._controls.$absolute.append(new Array(b + 1).join(this._templates[0])) : b < 0 && this._controls.$absolute.children().slice(b).remove(), this._controls.$absolute.find(".active").removeClass("active"), this._controls.$absolute.children().eq(a.inArray(this.current(), this._pages)).addClass("active"));
  }, e.prototype.onTrigger = function (b) {
    var c = this._core.settings;b.page = { index: a.inArray(this.current(), this._pages), count: this._pages.length, size: c && (c.center || c.autoWidth || c.dotsData ? 1 : c.dotsEach || c.items) };
  }, e.prototype.current = function () {
    var b = this._core.relative(this._core.current());return a.grep(this._pages, a.proxy(function (a, c) {
      return a.start <= b && a.end >= b;
    }, this)).pop();
  }, e.prototype.getPosition = function (b) {
    var c,
        d,
        e = this._core.settings;return "page" == e.slideBy ? (c = a.inArray(this.current(), this._pages), d = this._pages.length, b ? ++c : --c, c = this._pages[(c % d + d) % d].start) : (c = this._core.relative(this._core.current()), d = this._core.items().length, b ? c += e.slideBy : c -= e.slideBy), c;
  }, e.prototype.next = function (b) {
    a.proxy(this._overrides.to, this._core)(this.getPosition(!0), b);
  }, e.prototype.prev = function (b) {
    a.proxy(this._overrides.to, this._core)(this.getPosition(!1), b);
  }, e.prototype.to = function (b, c, d) {
    var e;!d && this._pages.length ? (e = this._pages.length, a.proxy(this._overrides.to, this._core)(this._pages[(b % e + e) % e].start, c)) : a.proxy(this._overrides.to, this._core)(b, c);
  }, a.fn.owlCarousel.Constructor.Plugins.Navigation = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  "use strict";
  var e = function e(c) {
    this._core = c, this._hashes = {}, this.$element = this._core.$element, this._handlers = { "initialized.owl.carousel": a.proxy(function (c) {
        c.namespace && "URLHash" === this._core.settings.startPosition && a(b).trigger("hashchange.owl.navigation");
      }, this), "prepared.owl.carousel": a.proxy(function (b) {
        if (b.namespace) {
          var c = a(b.content).find("[data-hash]").addBack("[data-hash]").attr("data-hash");if (!c) return;this._hashes[c] = b.content;
        }
      }, this), "changed.owl.carousel": a.proxy(function (c) {
        if (c.namespace && "position" === c.property.name) {
          var d = this._core.items(this._core.relative(this._core.current())),
              e = a.map(this._hashes, function (a, b) {
            return a === d ? b : null;
          }).join();if (!e || b.location.hash.slice(1) === e) return;b.location.hash = e;
        }
      }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this.$element.on(this._handlers), a(b).on("hashchange.owl.navigation", a.proxy(function (a) {
      var c = b.location.hash.substring(1),
          e = this._core.$stage.children(),
          f = this._hashes[c] && e.index(this._hashes[c]);f !== d && f !== this._core.current() && this._core.to(this._core.relative(f), !1, !0);
    }, this));
  };e.Defaults = { URLhashListener: !1 }, e.prototype.destroy = function () {
    var c, d;a(b).off("hashchange.owl.navigation");for (c in this._handlers) {
      this._core.$element.off(c, this._handlers[c]);
    }for (d in Object.getOwnPropertyNames(this)) {
      "function" != typeof this[d] && (this[d] = null);
    }
  }, a.fn.owlCarousel.Constructor.Plugins.Hash = e;
}(window.Zepto || window.jQuery, window, document), function (a, b, c, d) {
  function e(b, c) {
    var e = !1,
        f = b.charAt(0).toUpperCase() + b.slice(1);return a.each((b + " " + h.join(f + " ") + f).split(" "), function (a, b) {
      if (g[b] !== d) return e = !c || b, !1;
    }), e;
  }function f(a) {
    return e(a, !0);
  }var g = a("<support>").get(0).style,
      h = "Webkit Moz O ms".split(" "),
      i = { transition: { end: { WebkitTransition: "webkitTransitionEnd", MozTransition: "transitionend", OTransition: "oTransitionEnd", transition: "transitionend" } }, animation: { end: { WebkitAnimation: "webkitAnimationEnd", MozAnimation: "animationend", OAnimation: "oAnimationEnd", animation: "animationend" } } },
      j = { csstransforms: function csstransforms() {
      return !!e("transform");
    }, csstransforms3d: function csstransforms3d() {
      return !!e("perspective");
    }, csstransitions: function csstransitions() {
      return !!e("transition");
    }, cssanimations: function cssanimations() {
      return !!e("animation");
    } };j.csstransitions() && (a.support.transition = new String(f("transition")), a.support.transition.end = i.transition.end[a.support.transition]), j.cssanimations() && (a.support.animation = new String(f("animation")), a.support.animation.end = i.animation.end[a.support.animation]), j.csstransforms() && (a.support.transform = new String(f("transform")), a.support.transform3d = j.csstransforms3d());
}(window.Zepto || window.jQuery, window, document);
;"use strict";

var rootUrl = window.location.origin;
var templateUrl = themeUrl.templateUrl;
// console.log(templateUrl);
if (rootUrl === "http://localhost:3000" || rootUrl === "http://localhost:8888") {
  rootUrl = rootUrl + "/westtours/";
} else {
  rootUrl = window.location.origin;
}
;// //
// var rootUrl = window.location.origin;
// if(rootUrl === "http://localhost:3000" || rootUrl === "http://localhost:8888") {
//   rootUrl = rootUrl + "/westtours/";
// }else{
//   rootUrl = "test"+window.location.origin;
// }
//
// var categories = rootUrl+"/wp-json/wp/v2/categories?per_page=50";
// var bikeToursHttp = rootUrl+"/wp-json/wp/v2/tour_post_type?per_page=50";
// var customTest = rootUrl+"/wp-json/wp/v2/custom_api";
// var media = rootUrl+"/wp-json/wp/v2/media?per_page=50";
//
// console.log(rootUrl);
// var category = [];
//
// function shuffle (array) {
//   var i = 0;
//   var j = 0;
//   var temp = null;
//
//   for (i = array.length - 1; i > 0; i -= 1) {
//     j = Math.floor(Math.random() * (i + 1));
//     temp = array[i];
//     array[i] = array[j];
//     array[j] = temp;
//   }
// }
// $.getJSON(categories, function(result){
// category = result;
// // console.log(category);
// });
//
// var mediaObj =[];
// $.getJSON(media, function(result){
// mediaObj = result;
// });
// // JSONgetter is a way for multiple custom post calls from the wp rest
// var JSONgetter = function(http, resultname){
//   $.getJSON(http, function(resultname){
//     var popular = [];
//     var smallCards = [];
//     $.each(resultname, function(i, field){
//       if (field.acf.is_popular) {
//         popular.push(field);
//       }
//       smallCards.push(field);
//       //  console.log(field);
//
//      var option = "<option value='"+field.title.rendered+" "+field.acf.activety+"'><p>"+field.title.rendered+"</p>   <p>"+field.acf.activety+"</p></option>";
//
//      $('#activities-search').append(option);
//
//      });
//
//     shuffle(popular);
//       $.each(popular, function(i, popular){
//       var activety = popular.acf.activety.toLowerCase();
//       var season = popular.acf.season.toLowerCase();
//       var cardIcon = activety;
//       if (cardIcon == "animal life") {
//        cardIcon = "animal-life";
//       }
//       //  console.log('pop');
//       var iconClass = activety;
//
//       function getWords(parameter) {
//           return parameter.split(/\s+/).slice(0,4).join(" ")+"..";
//       }
//       var largeCardHeading = popular.title.rendered;
//
//       getWords(largeCardHeading);
//
//       var StrippedStringBig = popular.excerpt.rendered.replace(/(<([^>]+)>)/ig,"");
//       var shorterTextBig = StrippedStringBig.substr(0, 112) + "...";
//
//       var bigCard = "<div id='' class='card-large' role='article'><a href='"+popular.link+"'><div class='image' style='background-image:url("+popular.acf.info_img.sizes.large+");'><img src='' alt=''/></div><div class='icon' style='background-image:url("+rootUrl+"/wp-content/themes/foundationPressGit/assets/images/icons/catIcons/"+cardIcon+".svg);' ></div><p class='cat-string'> "+activety+" / "+season+" </p><header class='card-content article-header'><h2 class='entry-title single-title' itemprop='headline'>"+popular.title.rendered+"</h2><p>"+shorterTextBig+"</p></header><button type='button' class='readMoreBtn'>Read more</button></a></div>";
//
//       if (popular.acf.is_popular) {
//         $("#big-cards").append(bigCard);
//       }
//
//       return i < 1;
//      });
//       shuffle(smallCards);
//       $.each(smallCards, function(i, card){
//         var activety = card.acf.activety.toLowerCase();
//         var season = card.acf.season.toLowerCase();
//         var cardIcon = activety;
//         if (cardIcon == "animal life") {
//          cardIcon = "animal-life";
//         }
//         var iconClass = activety;
//
//         var smallerH2;
//         //  if (card.title.rendered.length > 21) {
//         //     smallerH2 = 'smallerH2';
//         //  }else{
//         //    smallerH2 = '';
//         //  }
//         function getWords(parameter, numWords) {
//           return parameter.split(/\s+/).slice(0,numWords).join(" ")+"..";
//         }
//
//         var cardHeading = card.title.rendered;
//         var inFewerWords = card.excerpt.rendered;
//         getWords(cardHeading, 3);
//
//         var StrippedString = card.excerpt.rendered.replace(/(<([^>]+)>)/ig,"");
//         var shorterText = StrippedString.substr(0, 48) + "...";
//
//         var smallCard = "<div class='small-12 medium-6 large-4 xlarge-3 card-container hidden'><div  class='card' role='article' ><a href='"+card.link+"'><div class='image' style='background-image:url("+card.acf.info_img.sizes.medium+");'><img src='' alt='' /></div><div class='icon icon-"+iconClass+"' style='background-image:url("+rootUrl+"/wp-content/themes/foundationPressGit/assets/images/icons/catIcons/"+cardIcon+".svg);' ></div><p class='cat-string'> "+activety+" / "+season+" </p><header class='card-content article-header'><h2 class='entry-title single-title "+smallerH2+"' itemprop='headline'>"+getWords(cardHeading, 3)+"</h2><p>"+shorterText+"</p></header><button type='button' class='bookBtn'>Book</button></a></div></div>";
//
//
//         if(!popular.acf.is_popular)
//         {
//           $("#cards").append(smallCard);
//         }
//       });
//   });
// };
// // setTimeout("JSONgetter(bikeToursHttp, 'bikeObject')",200);
// JSONgetter(bikeToursHttp, 'bikeObject');
// function loadMore(){
//         $("#cards .hidden").slice(0,4).removeClass("hidden");
//     }
// setTimeout(function() { loadMore(); }, 1500);
// $(".show-more").on("click",loadMore);
//
// // JSONgetter(customTest, 'test');
"use strict";
;// function apiCall(path, data){
//   jQuery.post(path, data, function(res){
//     // console.log(res);
//     var jPostRes = JSON.parse(res);
//     console.log(jPostRes);
//   });
// }
//
// var elBody = document.querySelector('body');
//
// if(elBody.classList.contains('single-tour_post_type')) {
//   var post = document.querySelector('article');
//   var postId = post.getAttribute('data-tourid');
//   var postData = {"data": postId};
//   // console.dir(postId);
//   apiCall(rootUrl+'wp-content/themes/foundationPressGit/library/api/call-by-id.php', postData);
// }

// function sendCardId(){
//   // console.log('x');
//   document.addEventListener('click', function(e){
//     // console.log(e.target);
//     if(e.target.classList.contains('btnCard')) {
//       var sGetTourId = e.target.getAttribute('data-tripid');
//       var jSendTourID = {"data":sGetTourId};
//       apiCall(rootUrl+'wp-content/themes/foundationPressGit/library/api/call-by-id.php', jSendTourID);
//       // console.log(getTourId);
//     }
//   });
// }
//
// sendCardId();
"use strict";
;'use strict';

$('#from').dateRange({
   selected: function selected(dates) {
      var from = dates[0];
      var to = dates[1];
      //do something special
   }
});
;'use strict';

// console.log(rootUrl);

// console.log(sSearchString);

$.getJSON(templateUrl + "/library/detailedtrips.json", function (data) {
  $('#activitiesSearch').on('keyup', function () {

    var sSearchString = $(this).val();
    var aItems = [];
    // console.log(typeof sSearchString);

    var title = '';
    var mainActivety = "";
    var tripDescription = "";
    var season = "";
    var allActiveties = [];
    var trips = data.trips;
    var allActivToLowerCase = "";
    // console.log(trips);
    for (var i = 0; i < trips.length; i++) {
      title = trips[i].title.toLowerCase();
      tripDescription = trips[i].description.toLowerCase();
      mainActivety = trips[i].activityCategories[0];
      allActiveties = trips[i].activityCategories;
      season = trips[i].season.toLowerCase();
      var filteredArray = [];
      sResultsDropdown.innerHTML = "";

      var searchResaults = title.includes(sSearchString.toLowerCase()) || tripDescription.includes(sSearchString.toLowerCase()) ||
      // allActivToLowerCase.includes(sSearchString.toLowerCase()) ||
      season.includes(sSearchString.toLowerCase());

      if (searchResaults && !sSearchString.length < 1) {
        // console.log(trips[i]);
        sResultsDropdown.classList.add('searchActive');
        aItems.push(trips[i]);
        filteredArray = aItems.filter(function (item, pos) {
          return aItems.indexOf(item) == pos;
        });

        var resultTitle = '';
        var resultActivety = '';
        var sResultRender = "";
        // console.log(filteredArray);
        for (var j = 0; j < filteredArray.length; j++) {
          // console.log(filteredArray[j].title);
          resultTitle = filteredArray[j].title;
          resultActivety = filteredArray[j].season;
          sResultRender += '<div class="resultItem" data-tripid="' + filteredArray[j].id + '"><span class="sSearchVal result_title">' + resultTitle + '</span><span class="result_season sSearchVal">' + resultActivety.replace(/_/g, " ") + '</span></div>';
        }
        sResultsDropdown.innerHTML = sResultRender;
      } else {
        console.log(sSearchString.length);
        sResultsDropdown.classList.remove('searchActive');
        sResultsDropdown.innerHTML = '';
      }

      // for (var t = 0; t < allActiveties.length; t++)
      // {
      //    allActivToLowerCase =  allActiveties[t].replace(/_/g, " ").toLowerCase();
      //   // console.log(allActivToLowerCase);
      //   // console.log(sSearchString);
      //   // console.log(title);
      //
      //   // else {
      //   //     sResultsDropdown.classList.remove('searchActive');
      //   // }
      //   if(sResultsDropdown.offsetHeight > 21){
      //
      //     //  sResultsDropdown.classList.remove('searchActive');
      //   }
      //   // else {
      //   //   sResultsDropdown.classList.add('searchActive');
      //   // }
      // }
    }

    // console.log(sResultRender);


    // filteredArray = [];
    console.log(filteredArray);
  });
});

function isDescendant(parent, child) {
  var node = child.parentNode;
  while (node != null) {
    if (node == parent) {
      return true;
    }
    node = node.parentNode;
  }
  return false;
}
var iCount = 0;
document.addEventListener('click', function (e) {
  var searchValue = '';
  var searchValueId = '';
  if (e.target.classList.contains('resultItem')) {
    // console.dir(e.target.children[0].innerHTML);
    searchValue = e.target.children[0].innerHTML;
    activitiesSearch.value = searchValue;
    sResultsDropdown.classList.remove('searchActive');
  }
  if (e.target.classList.contains('result_season')) {
    // console.dir(e.target.previousElementSibling.innerHTML);
    searchValue = e.target.previousElementSibling.innerHTML;
    // console.log(searchValueId);
    activitiesSearch.value = searchValue;
    sResultsDropdown.classList.remove('searchActive');
  }
  if (e.target.classList.contains('result_title')) {
    // console.dir(e.target.previousElementSibling.innerHTML);
    searchValue = e.target.innerHTML;
    activitiesSearch.value = searchValue;
    sResultsDropdown.classList.remove('searchActive');
  }
  // console.log(e.target);
  if (e.target.classList.contains('sSearchVal')) {
    // console.log('x');
    var parentID = e.target.parentElement.getAttribute('data-tripid');
    // $('#activitiesSearch').val() = parentID;
    widget_id.value = parentID;
    // console.log(parentID);
  }
  // var counterContainer = document.querySelectorAll('.counterContainer');
  if (e.target.id == 'counter') {
    // console.log(counterContainer);
    counterContainer.classList.add('scaleUp');
  }
  if (e.target.classList.contains('btnCloseCount')) {
    counterContainer.classList.remove('scaleUp');
  }

  // console.log(isDescendant(counterContainer, e.target));
  var btnCounterCount = document.querySelector('#counter');
  if (btnCounterCount) {
    var isClickInide = btnCounterCount.contains(e.target) || isDescendant(counterContainer, e.target);
    if (!isClickInide && counterContainer.classList.contains('scaleUp')) {
      counterContainer.classList.toggle('scaleUp');
    }
  }
  var inputCount = "";
  if (e.target.classList.contains('btnPlus')) {
    inputCount = e.target.parentNode.parentNode.children[0].children[0];
    iCount = Number(inputCount.value) + 1;
    if (Number(inputCount.value) < 5) {
      inputCount.value = iCount;
    }
  }
  if (e.target.classList.contains('btnMinus')) {
    inputCount = e.target.parentNode.parentNode.children[0].children[0];
    iCount = Number(inputCount.value) - 1;
    if (Number(inputCount.value) > 0) {
      inputCount.value = iCount;
    }
  }
});

$('#showFilteredTrip').click(function () {
  $.post(templateUrl + "/library/bokun.php?checktrip=true", $("#fpFilter").serialize(), function (data) {
    console.log(data);
  });
});
;"use strict";

jQuery(document).foundation();
;'use strict';

// Joyride demo
$('#start-jr').on('click', function () {
  $(document).foundation('joyride', 'start');
});
;'use strict';

function resize(event) {
  // console.log(event);
  owl.trigger('destroy.owl.carousel');
}
if (window.innerWidth <= 1024) {
  var owl = $('#cards');
  owl.owlCarousel({
    dots: false,
    responsive: {
      0: {
        items: 1,
        nav: false,
        loop: true,
        stagePadding: 30,
        dots: false
      },
      640: {
        items: 2,
        nav: false,
        loop: true,
        stagePadding: 10,
        dots: false
      },
      1024: {
        items: 2,
        nav: false,
        loop: true,
        stagePadding: 35,
        dots: false,
        onResize: resize
      }
    }
  });
}

var postOwl = $('#cardsPost');
postOwl.owlCarousel({
  items: 1,
  nav: false,
  loop: true,
  stagePadding: 10,
  dots: false,
  autoplay: true,

  responsive: {
    0: {
      items: 1,
      nav: false,
      loop: true,
      stagePadding: 30,
      dots: false
    },
    640: {
      items: 2,
      nav: false,
      loop: true,
      stagePadding: 90,
      dots: false
    },
    1024: {
      items: 3,
      nav: false,
      loop: true,
      stagePadding: 10,
      dots: false
      // onResize: resize
    },
    1200: {
      items: 4,
      nav: false,
      loop: true,
      stagePadding: 10,
      dots: false
      // onResize: resize
    }
  }
});

// $(window).resize(function(){
//   console.log('x');
//   if(window.innerWidth <= 1024) {
//      owl.trigger('destroy.owl.carousel');
//   }
//
// })
;"use strict";
;'use strict';

$(document).ready(function () {
    var videos = $('iframe[src*="vimeo.com"], iframe[src*="youtube.com"]');

    videos.each(function () {
        var el = $(this);
        el.wrap('<div class="responsive-embed widescreen"/>');
    });
});
;'use strict';

var onScroll = function onScroll(container, theclass, amount) {
	var wrap = $(container);
	$(window).scroll(function () {
		if ($(document).scrollTop() > amount) {
			wrap.addClass(theclass);
		} else {
			wrap.removeClass(theclass);
		}
	});
};

onScroll('.main-nav-container', 'set-nav-position', 1);

$('.call').click(function () {
	$('.burger').toggleClass('thex');
	$('body').toggleClass('stop-scrolling');
	// $('#offCanvas').toggleClass('position-left');
	//  $(document).foundation();
});

$('.is-accordion-submenu-parent').click(function () {
	// $('body').toggleClass('stop-scrolling');
});

$('.is-dropdown-submenu-parent').mouseover(function () {
	$('.first-sub').toggleClass('menu-animation');
});

$('.filterbutton').on('click', function () {
	$('#navActivety').addClass('showNavActivety');
	$('body').addClass('stop-scrolling');
});

$('#closeActivetyNav').on('click', function () {
	$('#navActivety').removeClass('showNavActivety');
	$('body').removeClass('stop-scrolling');
});
;'use strict';

$(window).bind(' load resize orientationChange ', function () {
  var footer = $("#footer-container");
  var pos = footer.position();
  var height = $(window).height();
  height = height - pos.top;
  height = height - footer.height() - 1;

  function stickyFooter() {
    footer.css({
      'margin-top': height + 'px'
    });
  }

  if (height > 0) {
    stickyFooter();
  }
});
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvdW5kYXRpb24uY29yZS5qcyIsImZvdW5kYXRpb24udXRpbC5ib3guanMiLCJmb3VuZGF0aW9uLnV0aWwua2V5Ym9hcmQuanMiLCJmb3VuZGF0aW9uLnV0aWwubWVkaWFRdWVyeS5qcyIsImZvdW5kYXRpb24udXRpbC5tb3Rpb24uanMiLCJmb3VuZGF0aW9uLnV0aWwubmVzdC5qcyIsImZvdW5kYXRpb24udXRpbC50aW1lckFuZEltYWdlTG9hZGVyLmpzIiwiZm91bmRhdGlvbi51dGlsLnRvdWNoLmpzIiwiZm91bmRhdGlvbi51dGlsLnRyaWdnZXJzLmpzIiwiZm91bmRhdGlvbi5hY2NvcmRpb25NZW51LmpzIiwiZm91bmRhdGlvbi5kcmlsbGRvd24uanMiLCJmb3VuZGF0aW9uLmRyb3Bkb3duLmpzIiwiZm91bmRhdGlvbi5kcm9wZG93bk1lbnUuanMiLCJmb3VuZGF0aW9uLm9mZmNhbnZhcy5qcyIsImZvdW5kYXRpb24ucmVzcG9uc2l2ZU1lbnUuanMiLCJmb3VuZGF0aW9uLnJlc3BvbnNpdmVUb2dnbGUuanMiLCJmb3VuZGF0aW9uLnRvZ2dsZXIuanMiLCJmb3VuZGF0aW9uLnRvb2x0aXAuanMiLCJvd2wuY2Fyb3VzZWwubWluLmpzIiwicm9vdHVybC5qcyIsImFwaS5qcyIsImJva3VuLWFwaS5qcyIsImRhdGUuanMiLCJmaWx0ZXIuanMiLCJpbml0LWZvdW5kYXRpb24uanMiLCJqb3lyaWRlLWRlbW8uanMiLCJteS1zbGljay5qcyIsIm9mZkNhbnZhcy5qcyIsInJlc3BvbnNpdmUtdmlkZW8uanMiLCJzY3JpcHRzLmpzIiwic3RpY2t5Zm9vdGVyLmpzIl0sIm5hbWVzIjpbIiQiLCJGT1VOREFUSU9OX1ZFUlNJT04iLCJGb3VuZGF0aW9uIiwidmVyc2lvbiIsIl9wbHVnaW5zIiwiX3V1aWRzIiwicnRsIiwiYXR0ciIsInBsdWdpbiIsIm5hbWUiLCJjbGFzc05hbWUiLCJmdW5jdGlvbk5hbWUiLCJhdHRyTmFtZSIsImh5cGhlbmF0ZSIsInJlZ2lzdGVyUGx1Z2luIiwicGx1Z2luTmFtZSIsImNvbnN0cnVjdG9yIiwidG9Mb3dlckNhc2UiLCJ1dWlkIiwiR2V0WW9EaWdpdHMiLCIkZWxlbWVudCIsImRhdGEiLCJ0cmlnZ2VyIiwicHVzaCIsInVucmVnaXN0ZXJQbHVnaW4iLCJzcGxpY2UiLCJpbmRleE9mIiwicmVtb3ZlQXR0ciIsInJlbW92ZURhdGEiLCJwcm9wIiwicmVJbml0IiwicGx1Z2lucyIsImlzSlEiLCJlYWNoIiwiX2luaXQiLCJ0eXBlIiwiX3RoaXMiLCJmbnMiLCJwbGdzIiwiZm9yRWFjaCIsInAiLCJmb3VuZGF0aW9uIiwiT2JqZWN0Iiwia2V5cyIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImxlbmd0aCIsIm5hbWVzcGFjZSIsIk1hdGgiLCJyb3VuZCIsInBvdyIsInJhbmRvbSIsInRvU3RyaW5nIiwic2xpY2UiLCJyZWZsb3ciLCJlbGVtIiwiaSIsIiRlbGVtIiwiZmluZCIsImFkZEJhY2siLCIkZWwiLCJvcHRzIiwid2FybiIsInRoaW5nIiwic3BsaXQiLCJlIiwib3B0IiwibWFwIiwiZWwiLCJ0cmltIiwicGFyc2VWYWx1ZSIsImVyIiwiZ2V0Rm5OYW1lIiwidHJhbnNpdGlvbmVuZCIsInRyYW5zaXRpb25zIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiZW5kIiwidCIsInN0eWxlIiwic2V0VGltZW91dCIsInRyaWdnZXJIYW5kbGVyIiwidXRpbCIsInRocm90dGxlIiwiZnVuYyIsImRlbGF5IiwidGltZXIiLCJjb250ZXh0IiwiYXJncyIsImFyZ3VtZW50cyIsImFwcGx5IiwibWV0aG9kIiwiJG1ldGEiLCIkbm9KUyIsImFwcGVuZFRvIiwiaGVhZCIsInJlbW92ZUNsYXNzIiwiTWVkaWFRdWVyeSIsIkFycmF5IiwicHJvdG90eXBlIiwiY2FsbCIsInBsdWdDbGFzcyIsInVuZGVmaW5lZCIsIlJlZmVyZW5jZUVycm9yIiwiVHlwZUVycm9yIiwid2luZG93IiwiZm4iLCJEYXRlIiwibm93IiwiZ2V0VGltZSIsInZlbmRvcnMiLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJ2cCIsImNhbmNlbEFuaW1hdGlvbkZyYW1lIiwidGVzdCIsIm5hdmlnYXRvciIsInVzZXJBZ2VudCIsImxhc3RUaW1lIiwiY2FsbGJhY2siLCJuZXh0VGltZSIsIm1heCIsImNsZWFyVGltZW91dCIsInBlcmZvcm1hbmNlIiwic3RhcnQiLCJGdW5jdGlvbiIsImJpbmQiLCJvVGhpcyIsImFBcmdzIiwiZlRvQmluZCIsImZOT1AiLCJmQm91bmQiLCJjb25jYXQiLCJmdW5jTmFtZVJlZ2V4IiwicmVzdWx0cyIsImV4ZWMiLCJzdHIiLCJpc05hTiIsInBhcnNlRmxvYXQiLCJyZXBsYWNlIiwialF1ZXJ5IiwiQm94IiwiSW1Ob3RUb3VjaGluZ1lvdSIsIkdldERpbWVuc2lvbnMiLCJHZXRPZmZzZXRzIiwiZWxlbWVudCIsInBhcmVudCIsImxyT25seSIsInRiT25seSIsImVsZURpbXMiLCJ0b3AiLCJib3R0b20iLCJsZWZ0IiwicmlnaHQiLCJwYXJEaW1zIiwib2Zmc2V0IiwiaGVpZ2h0Iiwid2lkdGgiLCJ3aW5kb3dEaW1zIiwiYWxsRGlycyIsIkVycm9yIiwicmVjdCIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsInBhclJlY3QiLCJwYXJlbnROb2RlIiwid2luUmVjdCIsImJvZHkiLCJ3aW5ZIiwicGFnZVlPZmZzZXQiLCJ3aW5YIiwicGFnZVhPZmZzZXQiLCJwYXJlbnREaW1zIiwiYW5jaG9yIiwicG9zaXRpb24iLCJ2T2Zmc2V0IiwiaE9mZnNldCIsImlzT3ZlcmZsb3ciLCIkZWxlRGltcyIsIiRhbmNob3JEaW1zIiwia2V5Q29kZXMiLCJjb21tYW5kcyIsIktleWJvYXJkIiwiZ2V0S2V5Q29kZXMiLCJwYXJzZUtleSIsImV2ZW50Iiwia2V5Iiwid2hpY2giLCJrZXlDb2RlIiwiU3RyaW5nIiwiZnJvbUNoYXJDb2RlIiwidG9VcHBlckNhc2UiLCJzaGlmdEtleSIsImN0cmxLZXkiLCJhbHRLZXkiLCJoYW5kbGVLZXkiLCJjb21wb25lbnQiLCJmdW5jdGlvbnMiLCJjb21tYW5kTGlzdCIsImNtZHMiLCJjb21tYW5kIiwibHRyIiwiZXh0ZW5kIiwicmV0dXJuVmFsdWUiLCJoYW5kbGVkIiwidW5oYW5kbGVkIiwiZmluZEZvY3VzYWJsZSIsImZpbHRlciIsImlzIiwicmVnaXN0ZXIiLCJjb21wb25lbnROYW1lIiwidHJhcEZvY3VzIiwiJGZvY3VzYWJsZSIsIiRmaXJzdEZvY3VzYWJsZSIsImVxIiwiJGxhc3RGb2N1c2FibGUiLCJvbiIsInRhcmdldCIsInByZXZlbnREZWZhdWx0IiwiZm9jdXMiLCJyZWxlYXNlRm9jdXMiLCJvZmYiLCJrY3MiLCJrIiwia2MiLCJkZWZhdWx0UXVlcmllcyIsImxhbmRzY2FwZSIsInBvcnRyYWl0IiwicmV0aW5hIiwicXVlcmllcyIsImN1cnJlbnQiLCJzZWxmIiwiZXh0cmFjdGVkU3R5bGVzIiwiY3NzIiwibmFtZWRRdWVyaWVzIiwicGFyc2VTdHlsZVRvT2JqZWN0IiwiaGFzT3duUHJvcGVydHkiLCJ2YWx1ZSIsIl9nZXRDdXJyZW50U2l6ZSIsIl93YXRjaGVyIiwiYXRMZWFzdCIsInNpemUiLCJxdWVyeSIsImdldCIsIm1hdGNoTWVkaWEiLCJtYXRjaGVzIiwibWF0Y2hlZCIsIm5ld1NpemUiLCJjdXJyZW50U2l6ZSIsInN0eWxlTWVkaWEiLCJtZWRpYSIsInNjcmlwdCIsImdldEVsZW1lbnRzQnlUYWdOYW1lIiwiaW5mbyIsImlkIiwiaW5zZXJ0QmVmb3JlIiwiZ2V0Q29tcHV0ZWRTdHlsZSIsImN1cnJlbnRTdHlsZSIsIm1hdGNoTWVkaXVtIiwidGV4dCIsInN0eWxlU2hlZXQiLCJjc3NUZXh0IiwidGV4dENvbnRlbnQiLCJzdHlsZU9iamVjdCIsInJlZHVjZSIsInJldCIsInBhcmFtIiwicGFydHMiLCJ2YWwiLCJkZWNvZGVVUklDb21wb25lbnQiLCJpc0FycmF5IiwiaW5pdENsYXNzZXMiLCJhY3RpdmVDbGFzc2VzIiwiTW90aW9uIiwiYW5pbWF0ZUluIiwiYW5pbWF0aW9uIiwiY2IiLCJhbmltYXRlIiwiYW5pbWF0ZU91dCIsIk1vdmUiLCJkdXJhdGlvbiIsImFuaW0iLCJwcm9nIiwibW92ZSIsInRzIiwiaXNJbiIsImluaXRDbGFzcyIsImFjdGl2ZUNsYXNzIiwicmVzZXQiLCJhZGRDbGFzcyIsInNob3ciLCJvZmZzZXRXaWR0aCIsIm9uZSIsImZpbmlzaCIsImhpZGUiLCJ0cmFuc2l0aW9uRHVyYXRpb24iLCJOZXN0IiwiRmVhdGhlciIsIm1lbnUiLCJpdGVtcyIsInN1Yk1lbnVDbGFzcyIsInN1Ykl0ZW1DbGFzcyIsImhhc1N1YkNsYXNzIiwiJGl0ZW0iLCIkc3ViIiwiY2hpbGRyZW4iLCJCdXJuIiwiVGltZXIiLCJvcHRpb25zIiwibmFtZVNwYWNlIiwicmVtYWluIiwiaXNQYXVzZWQiLCJyZXN0YXJ0IiwiaW5maW5pdGUiLCJwYXVzZSIsIm9uSW1hZ2VzTG9hZGVkIiwiaW1hZ2VzIiwidW5sb2FkZWQiLCJjb21wbGV0ZSIsInJlYWR5U3RhdGUiLCJzaW5nbGVJbWFnZUxvYWRlZCIsInNyYyIsInNwb3RTd2lwZSIsImVuYWJsZWQiLCJkb2N1bWVudEVsZW1lbnQiLCJtb3ZlVGhyZXNob2xkIiwidGltZVRocmVzaG9sZCIsInN0YXJ0UG9zWCIsInN0YXJ0UG9zWSIsInN0YXJ0VGltZSIsImVsYXBzZWRUaW1lIiwiaXNNb3ZpbmciLCJvblRvdWNoRW5kIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIm9uVG91Y2hNb3ZlIiwieCIsInRvdWNoZXMiLCJwYWdlWCIsInkiLCJwYWdlWSIsImR4IiwiZHkiLCJkaXIiLCJhYnMiLCJvblRvdWNoU3RhcnQiLCJhZGRFdmVudExpc3RlbmVyIiwiaW5pdCIsInRlYXJkb3duIiwic3BlY2lhbCIsInN3aXBlIiwic2V0dXAiLCJub29wIiwiYWRkVG91Y2giLCJoYW5kbGVUb3VjaCIsImNoYW5nZWRUb3VjaGVzIiwiZmlyc3QiLCJldmVudFR5cGVzIiwidG91Y2hzdGFydCIsInRvdWNobW92ZSIsInRvdWNoZW5kIiwic2ltdWxhdGVkRXZlbnQiLCJNb3VzZUV2ZW50Iiwic2NyZWVuWCIsInNjcmVlblkiLCJjbGllbnRYIiwiY2xpZW50WSIsImNyZWF0ZUV2ZW50IiwiaW5pdE1vdXNlRXZlbnQiLCJkaXNwYXRjaEV2ZW50IiwiTXV0YXRpb25PYnNlcnZlciIsInByZWZpeGVzIiwidHJpZ2dlcnMiLCJzdG9wUHJvcGFnYXRpb24iLCJmYWRlT3V0IiwiY2hlY2tMaXN0ZW5lcnMiLCJldmVudHNMaXN0ZW5lciIsInJlc2l6ZUxpc3RlbmVyIiwic2Nyb2xsTGlzdGVuZXIiLCJtdXRhdGVMaXN0ZW5lciIsImNsb3NlbWVMaXN0ZW5lciIsInlldGlCb3hlcyIsInBsdWdOYW1lcyIsImxpc3RlbmVycyIsImpvaW4iLCJwbHVnaW5JZCIsIm5vdCIsImRlYm91bmNlIiwiJG5vZGVzIiwibm9kZXMiLCJxdWVyeVNlbGVjdG9yQWxsIiwibGlzdGVuaW5nRWxlbWVudHNNdXRhdGlvbiIsIm11dGF0aW9uUmVjb3Jkc0xpc3QiLCIkdGFyZ2V0IiwiYXR0cmlidXRlTmFtZSIsImNsb3Nlc3QiLCJlbGVtZW50T2JzZXJ2ZXIiLCJvYnNlcnZlIiwiYXR0cmlidXRlcyIsImNoaWxkTGlzdCIsImNoYXJhY3RlckRhdGEiLCJzdWJ0cmVlIiwiYXR0cmlidXRlRmlsdGVyIiwiSUhlYXJZb3UiLCJBY2NvcmRpb25NZW51IiwiZGVmYXVsdHMiLCJzbGlkZVVwIiwibXVsdGlPcGVuIiwiJG1lbnVMaW5rcyIsImxpbmtJZCIsInN1YklkIiwiaXNBY3RpdmUiLCJoYXNDbGFzcyIsImluaXRQYW5lcyIsImRvd24iLCJfZXZlbnRzIiwiJHN1Ym1lbnUiLCJ0b2dnbGUiLCIkZWxlbWVudHMiLCIkcHJldkVsZW1lbnQiLCIkbmV4dEVsZW1lbnQiLCJtaW4iLCJwYXJlbnRzIiwibmV4dCIsIm9wZW4iLCJjbG9zZSIsInVwIiwiY2xvc2VBbGwiLCJoaWRlQWxsIiwic3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uIiwicGFyZW50c1VudGlsIiwiYWRkIiwic2xpZGVEb3duIiwic2xpZGVTcGVlZCIsIiRtZW51cyIsIkRyaWxsZG93biIsIiRzdWJtZW51QW5jaG9ycyIsIiRzdWJtZW51cyIsIiRtZW51SXRlbXMiLCJfcHJlcGFyZU1lbnUiLCJfcmVnaXN0ZXJFdmVudHMiLCJfa2V5Ym9hcmRFdmVudHMiLCIkbGluayIsInBhcmVudExpbmsiLCJjbG9uZSIsInByZXBlbmRUbyIsIndyYXAiLCIkbWVudSIsIiRiYWNrIiwiYmFja0J1dHRvblBvc2l0aW9uIiwiYXBwZW5kIiwiYmFja0J1dHRvbiIsInByZXBlbmQiLCJfYmFjayIsImF1dG9IZWlnaHQiLCIkd3JhcHBlciIsIndyYXBwZXIiLCJhbmltYXRlSGVpZ2h0IiwiX2dldE1heERpbXMiLCJfc2hvdyIsImNsb3NlT25DbGljayIsIiRib2R5IiwiY29udGFpbnMiLCJfaGlkZUFsbCIsIl9yZXNpemUiLCJzY3JvbGxUb3AiLCJfYmluZEhhbmRsZXIiLCJfc2Nyb2xsVG9wIiwiJHNjcm9sbFRvcEVsZW1lbnQiLCJzY3JvbGxUb3BFbGVtZW50Iiwic2Nyb2xsUG9zIiwicGFyc2VJbnQiLCJzY3JvbGxUb3BPZmZzZXQiLCJzdG9wIiwiYW5pbWF0aW9uRHVyYXRpb24iLCJhbmltYXRpb25FYXNpbmciLCJwcmV2aW91cyIsIl9oaWRlIiwicGFyZW50U3ViTWVudSIsImJsdXIiLCJtYXhIZWlnaHQiLCJyZXN1bHQiLCJudW1PZkVsZW1zIiwidW53cmFwIiwicmVtb3ZlIiwiRHJvcGRvd24iLCIkaWQiLCIkYW5jaG9yIiwicGFyZW50Q2xhc3MiLCIkcGFyZW50IiwicG9zaXRpb25DbGFzcyIsImdldFBvc2l0aW9uQ2xhc3MiLCJjb3VudGVyIiwidXNlZFBvc2l0aW9ucyIsInZlcnRpY2FsUG9zaXRpb24iLCJtYXRjaCIsImhvcml6b250YWxQb3NpdGlvbiIsImNsYXNzQ2hhbmdlZCIsImRpcmVjdGlvbiIsIm5ld1dpZHRoIiwicGFyZW50SE9mZnNldCIsIiRwYXJlbnREaW1zIiwiX3JlcG9zaXRpb24iLCJfc2V0UG9zaXRpb24iLCJob3ZlciIsImJvZHlEYXRhIiwid2hhdGlucHV0IiwidGltZW91dCIsImhvdmVyRGVsYXkiLCJob3ZlclBhbmUiLCJ2aXNpYmxlRm9jdXNhYmxlRWxlbWVudHMiLCJhdXRvRm9jdXMiLCJfYWRkQm9keUhhbmRsZXIiLCJjdXJQb3NpdGlvbkNsYXNzIiwiRHJvcGRvd25NZW51Iiwic3VicyIsIiR0YWJzIiwidmVydGljYWxDbGFzcyIsInJpZ2h0Q2xhc3MiLCJhbGlnbm1lbnQiLCJjaGFuZ2VkIiwiaGFzVG91Y2giLCJvbnRvdWNoc3RhcnQiLCJwYXJDbGFzcyIsImhhbmRsZUNsaWNrRm4iLCJoYXNTdWIiLCJoYXNDbGlja2VkIiwiY2xpY2tPcGVuIiwiZm9yY2VGb2xsb3ciLCJjbG9zZU9uQ2xpY2tJbnNpZGUiLCJkaXNhYmxlSG92ZXIiLCJhdXRvY2xvc2UiLCJjbG9zaW5nVGltZSIsImlzVGFiIiwiaW5kZXgiLCJzaWJsaW5ncyIsIm5leHRTaWJsaW5nIiwicHJldlNpYmxpbmciLCJvcGVuU3ViIiwiY2xvc2VTdWIiLCJfaXNWZXJ0aWNhbCIsImlkeCIsIiRzaWJzIiwiY2xlYXIiLCJvbGRDbGFzcyIsIiRwYXJlbnRMaSIsIiR0b0Nsb3NlIiwic29tZXRoaW5nVG9DbG9zZSIsIk9mZkNhbnZhcyIsIiRsYXN0VHJpZ2dlciIsIiR0cmlnZ2VycyIsInRyYW5zaXRpb24iLCJjb250ZW50T3ZlcmxheSIsIm92ZXJsYXkiLCJvdmVybGF5UG9zaXRpb24iLCJzZXRBdHRyaWJ1dGUiLCIkb3ZlcmxheSIsImlzUmV2ZWFsZWQiLCJSZWdFeHAiLCJyZXZlYWxDbGFzcyIsInJldmVhbE9uIiwiX3NldE1RQ2hlY2tlciIsInRyYW5zaXRpb25UaW1lIiwiX2hhbmRsZUtleWJvYXJkIiwicmV2ZWFsIiwiJGNsb3NlciIsImZvcmNlVG8iLCJzY3JvbGxUbyIsInNjcm9sbEhlaWdodCIsImNvbnRlbnRTY3JvbGwiLCJfc3RvcFNjcm9sbGluZyIsIlJlc3BvbnNpdmVNZW51IiwicnVsZXMiLCJjdXJyZW50TXEiLCJjdXJyZW50UGx1Z2luIiwicnVsZXNUcmVlIiwicnVsZSIsInJ1bGVTaXplIiwicnVsZVBsdWdpbiIsIk1lbnVQbHVnaW5zIiwiaXNFbXB0eU9iamVjdCIsIl9jaGVja01lZGlhUXVlcmllcyIsIm1hdGNoZWRNcSIsImNzc0NsYXNzIiwiZGVzdHJveSIsImRyb3Bkb3duIiwiZHJpbGxkb3duIiwiYWNjb3JkaW9uIiwiUmVzcG9uc2l2ZVRvZ2dsZSIsInRhcmdldElEIiwiJHRhcmdldE1lbnUiLCIkdG9nZ2xlciIsImlucHV0IiwiYW5pbWF0aW9uSW4iLCJhbmltYXRpb25PdXQiLCJfdXBkYXRlIiwiX3VwZGF0ZU1xSGFuZGxlciIsInRvZ2dsZU1lbnUiLCJoaWRlRm9yIiwiVG9nZ2xlciIsInRvZ2dsZUNsYXNzIiwiaXNPbiIsIl91cGRhdGVBUklBIiwiVG9vbHRpcCIsImlzQ2xpY2siLCJlbGVtSWQiLCJfZ2V0UG9zaXRpb25DbGFzcyIsInRpcFRleHQiLCJ0ZW1wbGF0ZSIsIl9idWlsZFRlbXBsYXRlIiwiYWxsb3dIdG1sIiwiaHRtbCIsInRyaWdnZXJDbGFzcyIsInRlbXBsYXRlQ2xhc3NlcyIsInRvb2x0aXBDbGFzcyIsIiR0ZW1wbGF0ZSIsIiR0aXBEaW1zIiwic2hvd09uIiwiZmFkZUluIiwiZmFkZUluRHVyYXRpb24iLCJmYWRlT3V0RHVyYXRpb24iLCJpc0ZvY3VzIiwiZGlzYWJsZUZvclRvdWNoIiwidG91Y2hDbG9zZVRleHQiLCJhIiwiYiIsImMiLCJkIiwic2V0dGluZ3MiLCJEZWZhdWx0cyIsIl9oYW5kbGVycyIsIl9zdXByZXNzIiwiX2N1cnJlbnQiLCJfc3BlZWQiLCJfY29vcmRpbmF0ZXMiLCJfYnJlYWtwb2ludCIsIl93aWR0aCIsIl9pdGVtcyIsIl9jbG9uZXMiLCJfbWVyZ2VycyIsIl93aWR0aHMiLCJfaW52YWxpZGF0ZWQiLCJfcGlwZSIsIl9kcmFnIiwidGltZSIsInBvaW50ZXIiLCJzdGFnZSIsIl9zdGF0ZXMiLCJ0YWdzIiwiaW5pdGlhbGl6aW5nIiwiYW5pbWF0aW5nIiwiZHJhZ2dpbmciLCJwcm94eSIsIlBsdWdpbnMiLCJjaGFyQXQiLCJXb3JrZXJzIiwicnVuIiwiaW5pdGlhbGl6ZSIsImxvb3AiLCJjZW50ZXIiLCJyZXdpbmQiLCJtb3VzZURyYWciLCJ0b3VjaERyYWciLCJwdWxsRHJhZyIsImZyZWVEcmFnIiwibWFyZ2luIiwic3RhZ2VQYWRkaW5nIiwibWVyZ2UiLCJtZXJnZUZpdCIsImF1dG9XaWR0aCIsInN0YXJ0UG9zaXRpb24iLCJzbWFydFNwZWVkIiwiZmx1aWRTcGVlZCIsImRyYWdFbmRTcGVlZCIsInJlc3BvbnNpdmUiLCJyZXNwb25zaXZlUmVmcmVzaFJhdGUiLCJyZXNwb25zaXZlQmFzZUVsZW1lbnQiLCJmYWxsYmFja0Vhc2luZyIsIm5lc3RlZEl0ZW1TZWxlY3RvciIsIml0ZW1FbGVtZW50Iiwic3RhZ2VFbGVtZW50IiwicmVmcmVzaENsYXNzIiwibG9hZGVkQ2xhc3MiLCJsb2FkaW5nQ2xhc3MiLCJydGxDbGFzcyIsInJlc3BvbnNpdmVDbGFzcyIsImRyYWdDbGFzcyIsIml0ZW1DbGFzcyIsInN0YWdlQ2xhc3MiLCJzdGFnZU91dGVyQ2xhc3MiLCJncmFiQ2xhc3MiLCJXaWR0aCIsIkRlZmF1bHQiLCJJbm5lciIsIk91dGVyIiwiVHlwZSIsIkV2ZW50IiwiU3RhdGUiLCJyZWxhdGl2ZSIsIiRzdGFnZSIsInRvRml4ZWQiLCJmIiwiY2VpbCIsImciLCJoIiwibm9ybWFsaXplIiwib3V0ZXJIVE1MIiwibWluaW11bSIsIm1heGltdW0iLCJjb29yZGluYXRlcyIsIm9wIiwiZW50ZXIiLCJwcmVsb2FkQXV0b1dpZHRoSW1hZ2VzIiwicmVmcmVzaCIsImludmFsaWRhdGUiLCJyZWdpc3RlckV2ZW50SGFuZGxlcnMiLCJsZWF2ZSIsInZpZXdwb3J0IiwiTnVtYmVyIiwicHJvcGVydHkiLCJvcHRpb25zTG9naWMiLCJwcmVwYXJlIiwiY29udGVudCIsInVwZGF0ZSIsImFsbCIsImdyZXAiLCJvblRocm90dGxlZFJlc2l6ZSIsInJlc2l6ZVRpbWVyIiwib25SZXNpemUiLCJpc0RlZmF1bHRQcmV2ZW50ZWQiLCJzdXBwb3J0Iiwib25UcmFuc2l0aW9uRW5kIiwib25EcmFnU3RhcnQiLCJvbkRyYWdFbmQiLCJ0cmFuc2Zvcm0iLCJzcGVlZCIsImRpZmZlcmVuY2UiLCJvbkRyYWdNb3ZlIiwidHJhbnNmb3JtM2QiLCJzdXBwcmVzcyIsInJlbGVhc2UiLCJpc051bWVyaWMiLCJtZXJnZXJzIiwiY2xvbmVzIiwidG8iLCJwcmV2Iiwic3JjRWxlbWVudCIsIm9yaWdpbmFsVGFyZ2V0IiwiaW5uZXJXaWR0aCIsImNsaWVudFdpZHRoIiwiZW1wdHkiLCJub2RlVHlwZSIsImFmdGVyIiwiYmVmb3JlIiwiSW1hZ2UiLCJjb250ZW50cyIsImF0dGFjaEV2ZW50IiwiZGV0YWNoRXZlbnQiLCJpdGVtIiwiY291bnQiLCJjYW1lbENhc2UiLCJqIiwicmVsYXRlZFRhcmdldCIsIm9uVHJpZ2dlciIsIm93bCIsIl9kZWZhdWx0IiwiaW5BcnJheSIsIm9yaWdpbmFsRXZlbnQiLCJvd2xDYXJvdXNlbCIsIkNvbnN0cnVjdG9yIiwiWmVwdG8iLCJfY29yZSIsIl9pbnRlcnZhbCIsIl92aXNpYmxlIiwiYXV0b1JlZnJlc2giLCJ3YXRjaCIsImF1dG9SZWZyZXNoSW50ZXJ2YWwiLCJzZXRJbnRlcnZhbCIsImNsZWFySW50ZXJ2YWwiLCJnZXRPd25Qcm9wZXJ0eU5hbWVzIiwiQXV0b1JlZnJlc2giLCJfbG9hZGVkIiwibGF6eUxvYWQiLCJsb2FkIiwiZGV2aWNlUGl4ZWxSYXRpbyIsInVybCIsIm9ubG9hZCIsIm9wYWNpdHkiLCJoYW5kbGVycyIsIkxhenkiLCJhdXRvSGVpZ2h0Q2xhc3MiLCJ0b0FycmF5IiwiQXV0b0hlaWdodCIsIl92aWRlb3MiLCJfcGxheWluZyIsInZpZGVvIiwiaXNJbkZ1bGxTY3JlZW4iLCJmZXRjaCIsInBsYXkiLCJ2aWRlb0hlaWdodCIsInZpZGVvV2lkdGgiLCJ0aHVtYm5haWwiLCJsIiwiYWpheCIsImpzb25wIiwiZGF0YVR5cGUiLCJzdWNjZXNzIiwidGh1bWJuYWlsX2xhcmdlIiwiZnJhbWVncmFiX3VybCIsImluc2VydEFmdGVyIiwiZnVsbHNjcmVlbkVsZW1lbnQiLCJtb3pGdWxsU2NyZWVuRWxlbWVudCIsIndlYmtpdEZ1bGxzY3JlZW5FbGVtZW50IiwiVmlkZW8iLCJjb3JlIiwic3dhcHBpbmciLCJzd2FwIiwiQW5pbWF0ZSIsIl90aW1lb3V0IiwiX3BhdXNlZCIsImF1dG9wbGF5IiwiX3NldEF1dG9QbGF5SW50ZXJ2YWwiLCJhdXRvcGxheUhvdmVyUGF1c2UiLCJhdXRvcGxheVRpbWVvdXQiLCJhdXRvcGxheVNwZWVkIiwiX2dldE5leHRUaW1lb3V0IiwiaGlkZGVuIiwiX2luaXRpYWxpemVkIiwiX3BhZ2VzIiwiX2NvbnRyb2xzIiwiX3RlbXBsYXRlcyIsIl9vdmVycmlkZXMiLCJkb3RzRGF0YSIsImRvdENsYXNzIiwicG9wIiwiZHJhdyIsIm5hdiIsIm5hdlRleHQiLCJuYXZTcGVlZCIsIm5hdkVsZW1lbnQiLCJuYXZDb250YWluZXIiLCJuYXZDb250YWluZXJDbGFzcyIsIm5hdkNsYXNzIiwic2xpZGVCeSIsImRvdHNDbGFzcyIsImRvdHMiLCJkb3RzRWFjaCIsImRvdHNTcGVlZCIsImRvdHNDb250YWluZXIiLCIkcmVsYXRpdmUiLCIkcHJldmlvdXMiLCIkbmV4dCIsIiRhYnNvbHV0ZSIsIm92ZXJpZGVzIiwicGFnZSIsImdldFBvc2l0aW9uIiwiTmF2aWdhdGlvbiIsIl9oYXNoZXMiLCJsb2NhdGlvbiIsImhhc2giLCJzdWJzdHJpbmciLCJVUkxoYXNoTGlzdGVuZXIiLCJIYXNoIiwiV2Via2l0VHJhbnNpdGlvbiIsIk1velRyYW5zaXRpb24iLCJPVHJhbnNpdGlvbiIsIldlYmtpdEFuaW1hdGlvbiIsIk1vekFuaW1hdGlvbiIsIk9BbmltYXRpb24iLCJjc3N0cmFuc2Zvcm1zIiwiY3NzdHJhbnNmb3JtczNkIiwiY3NzdHJhbnNpdGlvbnMiLCJjc3NhbmltYXRpb25zIiwicm9vdFVybCIsIm9yaWdpbiIsInRlbXBsYXRlVXJsIiwidGhlbWVVcmwiLCJkYXRlUmFuZ2UiLCJzZWxlY3RlZCIsImRhdGVzIiwiZnJvbSIsImdldEpTT04iLCJzU2VhcmNoU3RyaW5nIiwiYUl0ZW1zIiwidGl0bGUiLCJtYWluQWN0aXZldHkiLCJ0cmlwRGVzY3JpcHRpb24iLCJzZWFzb24iLCJhbGxBY3RpdmV0aWVzIiwidHJpcHMiLCJhbGxBY3RpdlRvTG93ZXJDYXNlIiwiZGVzY3JpcHRpb24iLCJhY3Rpdml0eUNhdGVnb3JpZXMiLCJmaWx0ZXJlZEFycmF5Iiwic1Jlc3VsdHNEcm9wZG93biIsImlubmVySFRNTCIsInNlYXJjaFJlc2F1bHRzIiwiaW5jbHVkZXMiLCJjbGFzc0xpc3QiLCJwb3MiLCJyZXN1bHRUaXRsZSIsInJlc3VsdEFjdGl2ZXR5Iiwic1Jlc3VsdFJlbmRlciIsImxvZyIsImlzRGVzY2VuZGFudCIsImNoaWxkIiwibm9kZSIsImlDb3VudCIsInNlYXJjaFZhbHVlIiwic2VhcmNoVmFsdWVJZCIsImFjdGl2aXRpZXNTZWFyY2giLCJwcmV2aW91c0VsZW1lbnRTaWJsaW5nIiwicGFyZW50SUQiLCJwYXJlbnRFbGVtZW50IiwiZ2V0QXR0cmlidXRlIiwid2lkZ2V0X2lkIiwiY291bnRlckNvbnRhaW5lciIsImJ0bkNvdW50ZXJDb3VudCIsInF1ZXJ5U2VsZWN0b3IiLCJpc0NsaWNrSW5pZGUiLCJpbnB1dENvdW50IiwiY2xpY2siLCJwb3N0Iiwic2VyaWFsaXplIiwicmVzaXplIiwicG9zdE93bCIsInJlYWR5IiwidmlkZW9zIiwib25TY3JvbGwiLCJjb250YWluZXIiLCJ0aGVjbGFzcyIsImFtb3VudCIsInNjcm9sbCIsIm1vdXNlb3ZlciIsImZvb3RlciIsInN0aWNreUZvb3RlciJdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLENBQUMsVUFBU0EsQ0FBVCxFQUFZOztBQUViOztBQUVBLE1BQUlDLHFCQUFxQixPQUF6Qjs7QUFFQTtBQUNBO0FBQ0EsTUFBSUMsYUFBYTtBQUNmQyxhQUFTRixrQkFETTs7QUFHZjs7O0FBR0FHLGNBQVUsRUFOSzs7QUFRZjs7O0FBR0FDLFlBQVEsRUFYTzs7QUFhZjs7O0FBR0FDLFNBQUssZUFBVTtBQUNiLGFBQU9OLEVBQUUsTUFBRixFQUFVTyxJQUFWLENBQWUsS0FBZixNQUEwQixLQUFqQztBQUNELEtBbEJjO0FBbUJmOzs7O0FBSUFDLFlBQVEsZ0JBQVNBLE9BQVQsRUFBaUJDLElBQWpCLEVBQXVCO0FBQzdCO0FBQ0E7QUFDQSxVQUFJQyxZQUFhRCxRQUFRRSxhQUFhSCxPQUFiLENBQXpCO0FBQ0E7QUFDQTtBQUNBLFVBQUlJLFdBQVlDLFVBQVVILFNBQVYsQ0FBaEI7O0FBRUE7QUFDQSxXQUFLTixRQUFMLENBQWNRLFFBQWQsSUFBMEIsS0FBS0YsU0FBTCxJQUFrQkYsT0FBNUM7QUFDRCxLQWpDYztBQWtDZjs7Ozs7Ozs7O0FBU0FNLG9CQUFnQix3QkFBU04sTUFBVCxFQUFpQkMsSUFBakIsRUFBc0I7QUFDcEMsVUFBSU0sYUFBYU4sT0FBT0ksVUFBVUosSUFBVixDQUFQLEdBQXlCRSxhQUFhSCxPQUFPUSxXQUFwQixFQUFpQ0MsV0FBakMsRUFBMUM7QUFDQVQsYUFBT1UsSUFBUCxHQUFjLEtBQUtDLFdBQUwsQ0FBaUIsQ0FBakIsRUFBb0JKLFVBQXBCLENBQWQ7O0FBRUEsVUFBRyxDQUFDUCxPQUFPWSxRQUFQLENBQWdCYixJQUFoQixXQUE2QlEsVUFBN0IsQ0FBSixFQUErQztBQUFFUCxlQUFPWSxRQUFQLENBQWdCYixJQUFoQixXQUE2QlEsVUFBN0IsRUFBMkNQLE9BQU9VLElBQWxEO0FBQTBEO0FBQzNHLFVBQUcsQ0FBQ1YsT0FBT1ksUUFBUCxDQUFnQkMsSUFBaEIsQ0FBcUIsVUFBckIsQ0FBSixFQUFxQztBQUFFYixlQUFPWSxRQUFQLENBQWdCQyxJQUFoQixDQUFxQixVQUFyQixFQUFpQ2IsTUFBakM7QUFBMkM7QUFDNUU7Ozs7QUFJTkEsYUFBT1ksUUFBUCxDQUFnQkUsT0FBaEIsY0FBbUNQLFVBQW5DOztBQUVBLFdBQUtWLE1BQUwsQ0FBWWtCLElBQVosQ0FBaUJmLE9BQU9VLElBQXhCOztBQUVBO0FBQ0QsS0ExRGM7QUEyRGY7Ozs7Ozs7O0FBUUFNLHNCQUFrQiwwQkFBU2hCLE1BQVQsRUFBZ0I7QUFDaEMsVUFBSU8sYUFBYUYsVUFBVUYsYUFBYUgsT0FBT1ksUUFBUCxDQUFnQkMsSUFBaEIsQ0FBcUIsVUFBckIsRUFBaUNMLFdBQTlDLENBQVYsQ0FBakI7O0FBRUEsV0FBS1gsTUFBTCxDQUFZb0IsTUFBWixDQUFtQixLQUFLcEIsTUFBTCxDQUFZcUIsT0FBWixDQUFvQmxCLE9BQU9VLElBQTNCLENBQW5CLEVBQXFELENBQXJEO0FBQ0FWLGFBQU9ZLFFBQVAsQ0FBZ0JPLFVBQWhCLFdBQW1DWixVQUFuQyxFQUFpRGEsVUFBakQsQ0FBNEQsVUFBNUQ7QUFDTTs7OztBQUROLE9BS09OLE9BTFAsbUJBSytCUCxVQUwvQjtBQU1BLFdBQUksSUFBSWMsSUFBUixJQUFnQnJCLE1BQWhCLEVBQXVCO0FBQ3JCQSxlQUFPcUIsSUFBUCxJQUFlLElBQWYsQ0FEcUIsQ0FDRDtBQUNyQjtBQUNEO0FBQ0QsS0FqRmM7O0FBbUZmOzs7Ozs7QUFNQ0MsWUFBUSxnQkFBU0MsT0FBVCxFQUFpQjtBQUN2QixVQUFJQyxPQUFPRCxtQkFBbUIvQixDQUE5QjtBQUNBLFVBQUc7QUFDRCxZQUFHZ0MsSUFBSCxFQUFRO0FBQ05ELGtCQUFRRSxJQUFSLENBQWEsWUFBVTtBQUNyQmpDLGNBQUUsSUFBRixFQUFRcUIsSUFBUixDQUFhLFVBQWIsRUFBeUJhLEtBQXpCO0FBQ0QsV0FGRDtBQUdELFNBSkQsTUFJSztBQUNILGNBQUlDLGNBQWNKLE9BQWQseUNBQWNBLE9BQWQsQ0FBSjtBQUFBLGNBQ0FLLFFBQVEsSUFEUjtBQUFBLGNBRUFDLE1BQU07QUFDSixzQkFBVSxnQkFBU0MsSUFBVCxFQUFjO0FBQ3RCQSxtQkFBS0MsT0FBTCxDQUFhLFVBQVNDLENBQVQsRUFBVztBQUN0QkEsb0JBQUkzQixVQUFVMkIsQ0FBVixDQUFKO0FBQ0F4QyxrQkFBRSxXQUFVd0MsQ0FBVixHQUFhLEdBQWYsRUFBb0JDLFVBQXBCLENBQStCLE9BQS9CO0FBQ0QsZUFIRDtBQUlELGFBTkc7QUFPSixzQkFBVSxrQkFBVTtBQUNsQlYsd0JBQVVsQixVQUFVa0IsT0FBVixDQUFWO0FBQ0EvQixnQkFBRSxXQUFVK0IsT0FBVixHQUFtQixHQUFyQixFQUEwQlUsVUFBMUIsQ0FBcUMsT0FBckM7QUFDRCxhQVZHO0FBV0oseUJBQWEscUJBQVU7QUFDckIsbUJBQUssUUFBTCxFQUFlQyxPQUFPQyxJQUFQLENBQVlQLE1BQU1oQyxRQUFsQixDQUFmO0FBQ0Q7QUFiRyxXQUZOO0FBaUJBaUMsY0FBSUYsSUFBSixFQUFVSixPQUFWO0FBQ0Q7QUFDRixPQXpCRCxDQXlCQyxPQUFNYSxHQUFOLEVBQVU7QUFDVEMsZ0JBQVFDLEtBQVIsQ0FBY0YsR0FBZDtBQUNELE9BM0JELFNBMkJRO0FBQ04sZUFBT2IsT0FBUDtBQUNEO0FBQ0YsS0F6SGE7O0FBMkhmOzs7Ozs7OztBQVFBWixpQkFBYSxxQkFBUzRCLE1BQVQsRUFBaUJDLFNBQWpCLEVBQTJCO0FBQ3RDRCxlQUFTQSxVQUFVLENBQW5CO0FBQ0EsYUFBT0UsS0FBS0MsS0FBTCxDQUFZRCxLQUFLRSxHQUFMLENBQVMsRUFBVCxFQUFhSixTQUFTLENBQXRCLElBQTJCRSxLQUFLRyxNQUFMLEtBQWdCSCxLQUFLRSxHQUFMLENBQVMsRUFBVCxFQUFhSixNQUFiLENBQXZELEVBQThFTSxRQUE5RSxDQUF1RixFQUF2RixFQUEyRkMsS0FBM0YsQ0FBaUcsQ0FBakcsS0FBdUdOLGtCQUFnQkEsU0FBaEIsR0FBOEIsRUFBckksQ0FBUDtBQUNELEtBdEljO0FBdUlmOzs7OztBQUtBTyxZQUFRLGdCQUFTQyxJQUFULEVBQWV6QixPQUFmLEVBQXdCOztBQUU5QjtBQUNBLFVBQUksT0FBT0EsT0FBUCxLQUFtQixXQUF2QixFQUFvQztBQUNsQ0Esa0JBQVVXLE9BQU9DLElBQVAsQ0FBWSxLQUFLdkMsUUFBakIsQ0FBVjtBQUNEO0FBQ0Q7QUFIQSxXQUlLLElBQUksT0FBTzJCLE9BQVAsS0FBbUIsUUFBdkIsRUFBaUM7QUFDcENBLG9CQUFVLENBQUNBLE9BQUQsQ0FBVjtBQUNEOztBQUVELFVBQUlLLFFBQVEsSUFBWjs7QUFFQTtBQUNBcEMsUUFBRWlDLElBQUYsQ0FBT0YsT0FBUCxFQUFnQixVQUFTMEIsQ0FBVCxFQUFZaEQsSUFBWixFQUFrQjtBQUNoQztBQUNBLFlBQUlELFNBQVM0QixNQUFNaEMsUUFBTixDQUFlSyxJQUFmLENBQWI7O0FBRUE7QUFDQSxZQUFJaUQsUUFBUTFELEVBQUV3RCxJQUFGLEVBQVFHLElBQVIsQ0FBYSxXQUFTbEQsSUFBVCxHQUFjLEdBQTNCLEVBQWdDbUQsT0FBaEMsQ0FBd0MsV0FBU25ELElBQVQsR0FBYyxHQUF0RCxDQUFaOztBQUVBO0FBQ0FpRCxjQUFNekIsSUFBTixDQUFXLFlBQVc7QUFDcEIsY0FBSTRCLE1BQU03RCxFQUFFLElBQUYsQ0FBVjtBQUFBLGNBQ0k4RCxPQUFPLEVBRFg7QUFFQTtBQUNBLGNBQUlELElBQUl4QyxJQUFKLENBQVMsVUFBVCxDQUFKLEVBQTBCO0FBQ3hCd0Isb0JBQVFrQixJQUFSLENBQWEseUJBQXVCdEQsSUFBdkIsR0FBNEIsc0RBQXpDO0FBQ0E7QUFDRDs7QUFFRCxjQUFHb0QsSUFBSXRELElBQUosQ0FBUyxjQUFULENBQUgsRUFBNEI7QUFDMUIsZ0JBQUl5RCxRQUFRSCxJQUFJdEQsSUFBSixDQUFTLGNBQVQsRUFBeUIwRCxLQUF6QixDQUErQixHQUEvQixFQUFvQzFCLE9BQXBDLENBQTRDLFVBQVMyQixDQUFULEVBQVlULENBQVosRUFBYztBQUNwRSxrQkFBSVUsTUFBTUQsRUFBRUQsS0FBRixDQUFRLEdBQVIsRUFBYUcsR0FBYixDQUFpQixVQUFTQyxFQUFULEVBQVk7QUFBRSx1QkFBT0EsR0FBR0MsSUFBSCxFQUFQO0FBQW1CLGVBQWxELENBQVY7QUFDQSxrQkFBR0gsSUFBSSxDQUFKLENBQUgsRUFBV0wsS0FBS0ssSUFBSSxDQUFKLENBQUwsSUFBZUksV0FBV0osSUFBSSxDQUFKLENBQVgsQ0FBZjtBQUNaLGFBSFcsQ0FBWjtBQUlEO0FBQ0QsY0FBRztBQUNETixnQkFBSXhDLElBQUosQ0FBUyxVQUFULEVBQXFCLElBQUliLE1BQUosQ0FBV1IsRUFBRSxJQUFGLENBQVgsRUFBb0I4RCxJQUFwQixDQUFyQjtBQUNELFdBRkQsQ0FFQyxPQUFNVSxFQUFOLEVBQVM7QUFDUjNCLG9CQUFRQyxLQUFSLENBQWMwQixFQUFkO0FBQ0QsV0FKRCxTQUlRO0FBQ047QUFDRDtBQUNGLFNBdEJEO0FBdUJELE9BL0JEO0FBZ0NELEtBMUxjO0FBMkxmQyxlQUFXOUQsWUEzTEk7QUE0TGYrRCxtQkFBZSx1QkFBU2hCLEtBQVQsRUFBZTtBQUM1QixVQUFJaUIsY0FBYztBQUNoQixzQkFBYyxlQURFO0FBRWhCLDRCQUFvQixxQkFGSjtBQUdoQix5QkFBaUIsZUFIRDtBQUloQix1QkFBZTtBQUpDLE9BQWxCO0FBTUEsVUFBSW5CLE9BQU9vQixTQUFTQyxhQUFULENBQXVCLEtBQXZCLENBQVg7QUFBQSxVQUNJQyxHQURKOztBQUdBLFdBQUssSUFBSUMsQ0FBVCxJQUFjSixXQUFkLEVBQTBCO0FBQ3hCLFlBQUksT0FBT25CLEtBQUt3QixLQUFMLENBQVdELENBQVgsQ0FBUCxLQUF5QixXQUE3QixFQUF5QztBQUN2Q0QsZ0JBQU1ILFlBQVlJLENBQVosQ0FBTjtBQUNEO0FBQ0Y7QUFDRCxVQUFHRCxHQUFILEVBQU87QUFDTCxlQUFPQSxHQUFQO0FBQ0QsT0FGRCxNQUVLO0FBQ0hBLGNBQU1HLFdBQVcsWUFBVTtBQUN6QnZCLGdCQUFNd0IsY0FBTixDQUFxQixlQUFyQixFQUFzQyxDQUFDeEIsS0FBRCxDQUF0QztBQUNELFNBRkssRUFFSCxDQUZHLENBQU47QUFHQSxlQUFPLGVBQVA7QUFDRDtBQUNGO0FBbk5jLEdBQWpCOztBQXNOQXhELGFBQVdpRixJQUFYLEdBQWtCO0FBQ2hCOzs7Ozs7O0FBT0FDLGNBQVUsa0JBQVVDLElBQVYsRUFBZ0JDLEtBQWhCLEVBQXVCO0FBQy9CLFVBQUlDLFFBQVEsSUFBWjs7QUFFQSxhQUFPLFlBQVk7QUFDakIsWUFBSUMsVUFBVSxJQUFkO0FBQUEsWUFBb0JDLE9BQU9DLFNBQTNCOztBQUVBLFlBQUlILFVBQVUsSUFBZCxFQUFvQjtBQUNsQkEsa0JBQVFOLFdBQVcsWUFBWTtBQUM3QkksaUJBQUtNLEtBQUwsQ0FBV0gsT0FBWCxFQUFvQkMsSUFBcEI7QUFDQUYsb0JBQVEsSUFBUjtBQUNELFdBSE8sRUFHTEQsS0FISyxDQUFSO0FBSUQ7QUFDRixPQVREO0FBVUQ7QUFyQmUsR0FBbEI7O0FBd0JBO0FBQ0E7QUFDQTs7OztBQUlBLE1BQUk3QyxhQUFhLFNBQWJBLFVBQWEsQ0FBU21ELE1BQVQsRUFBaUI7QUFDaEMsUUFBSXpELGNBQWN5RCxNQUFkLHlDQUFjQSxNQUFkLENBQUo7QUFBQSxRQUNJQyxRQUFRN0YsRUFBRSxvQkFBRixDQURaO0FBQUEsUUFFSThGLFFBQVE5RixFQUFFLFFBQUYsQ0FGWjs7QUFJQSxRQUFHLENBQUM2RixNQUFNOUMsTUFBVixFQUFpQjtBQUNmL0MsUUFBRSw4QkFBRixFQUFrQytGLFFBQWxDLENBQTJDbkIsU0FBU29CLElBQXBEO0FBQ0Q7QUFDRCxRQUFHRixNQUFNL0MsTUFBVCxFQUFnQjtBQUNkK0MsWUFBTUcsV0FBTixDQUFrQixPQUFsQjtBQUNEOztBQUVELFFBQUc5RCxTQUFTLFdBQVosRUFBd0I7QUFBQztBQUN2QmpDLGlCQUFXZ0csVUFBWCxDQUFzQmhFLEtBQXRCO0FBQ0FoQyxpQkFBV3FELE1BQVgsQ0FBa0IsSUFBbEI7QUFDRCxLQUhELE1BR00sSUFBR3BCLFNBQVMsUUFBWixFQUFxQjtBQUFDO0FBQzFCLFVBQUlzRCxPQUFPVSxNQUFNQyxTQUFOLENBQWdCOUMsS0FBaEIsQ0FBc0IrQyxJQUF0QixDQUEyQlgsU0FBM0IsRUFBc0MsQ0FBdEMsQ0FBWCxDQUR5QixDQUMyQjtBQUNwRCxVQUFJWSxZQUFZLEtBQUtqRixJQUFMLENBQVUsVUFBVixDQUFoQixDQUZ5QixDQUVhOztBQUV0QyxVQUFHaUYsY0FBY0MsU0FBZCxJQUEyQkQsVUFBVVYsTUFBVixNQUFzQlcsU0FBcEQsRUFBOEQ7QUFBQztBQUM3RCxZQUFHLEtBQUt4RCxNQUFMLEtBQWdCLENBQW5CLEVBQXFCO0FBQUM7QUFDbEJ1RCxvQkFBVVYsTUFBVixFQUFrQkQsS0FBbEIsQ0FBd0JXLFNBQXhCLEVBQW1DYixJQUFuQztBQUNILFNBRkQsTUFFSztBQUNILGVBQUt4RCxJQUFMLENBQVUsVUFBU3dCLENBQVQsRUFBWVksRUFBWixFQUFlO0FBQUM7QUFDeEJpQyxzQkFBVVYsTUFBVixFQUFrQkQsS0FBbEIsQ0FBd0IzRixFQUFFcUUsRUFBRixFQUFNaEQsSUFBTixDQUFXLFVBQVgsQ0FBeEIsRUFBZ0RvRSxJQUFoRDtBQUNELFdBRkQ7QUFHRDtBQUNGLE9BUkQsTUFRSztBQUFDO0FBQ0osY0FBTSxJQUFJZSxjQUFKLENBQW1CLG1CQUFtQlosTUFBbkIsR0FBNEIsbUNBQTVCLElBQW1FVSxZQUFZM0YsYUFBYTJGLFNBQWIsQ0FBWixHQUFzQyxjQUF6RyxJQUEySCxHQUE5SSxDQUFOO0FBQ0Q7QUFDRixLQWZLLE1BZUQ7QUFBQztBQUNKLFlBQU0sSUFBSUcsU0FBSixvQkFBOEJ0RSxJQUE5QixrR0FBTjtBQUNEO0FBQ0QsV0FBTyxJQUFQO0FBQ0QsR0FsQ0Q7O0FBb0NBdUUsU0FBT3hHLFVBQVAsR0FBb0JBLFVBQXBCO0FBQ0FGLElBQUUyRyxFQUFGLENBQUtsRSxVQUFMLEdBQWtCQSxVQUFsQjs7QUFFQTtBQUNBLEdBQUMsWUFBVztBQUNWLFFBQUksQ0FBQ21FLEtBQUtDLEdBQU4sSUFBYSxDQUFDSCxPQUFPRSxJQUFQLENBQVlDLEdBQTlCLEVBQ0VILE9BQU9FLElBQVAsQ0FBWUMsR0FBWixHQUFrQkQsS0FBS0MsR0FBTCxHQUFXLFlBQVc7QUFBRSxhQUFPLElBQUlELElBQUosR0FBV0UsT0FBWCxFQUFQO0FBQThCLEtBQXhFOztBQUVGLFFBQUlDLFVBQVUsQ0FBQyxRQUFELEVBQVcsS0FBWCxDQUFkO0FBQ0EsU0FBSyxJQUFJdEQsSUFBSSxDQUFiLEVBQWdCQSxJQUFJc0QsUUFBUWhFLE1BQVosSUFBc0IsQ0FBQzJELE9BQU9NLHFCQUE5QyxFQUFxRSxFQUFFdkQsQ0FBdkUsRUFBMEU7QUFDdEUsVUFBSXdELEtBQUtGLFFBQVF0RCxDQUFSLENBQVQ7QUFDQWlELGFBQU9NLHFCQUFQLEdBQStCTixPQUFPTyxLQUFHLHVCQUFWLENBQS9CO0FBQ0FQLGFBQU9RLG9CQUFQLEdBQStCUixPQUFPTyxLQUFHLHNCQUFWLEtBQ0RQLE9BQU9PLEtBQUcsNkJBQVYsQ0FEOUI7QUFFSDtBQUNELFFBQUksdUJBQXVCRSxJQUF2QixDQUE0QlQsT0FBT1UsU0FBUCxDQUFpQkMsU0FBN0MsS0FDQyxDQUFDWCxPQUFPTSxxQkFEVCxJQUNrQyxDQUFDTixPQUFPUSxvQkFEOUMsRUFDb0U7QUFDbEUsVUFBSUksV0FBVyxDQUFmO0FBQ0FaLGFBQU9NLHFCQUFQLEdBQStCLFVBQVNPLFFBQVQsRUFBbUI7QUFDOUMsWUFBSVYsTUFBTUQsS0FBS0MsR0FBTCxFQUFWO0FBQ0EsWUFBSVcsV0FBV3ZFLEtBQUt3RSxHQUFMLENBQVNILFdBQVcsRUFBcEIsRUFBd0JULEdBQXhCLENBQWY7QUFDQSxlQUFPNUIsV0FBVyxZQUFXO0FBQUVzQyxtQkFBU0QsV0FBV0UsUUFBcEI7QUFBZ0MsU0FBeEQsRUFDV0EsV0FBV1gsR0FEdEIsQ0FBUDtBQUVILE9BTEQ7QUFNQUgsYUFBT1Esb0JBQVAsR0FBOEJRLFlBQTlCO0FBQ0Q7QUFDRDs7O0FBR0EsUUFBRyxDQUFDaEIsT0FBT2lCLFdBQVIsSUFBdUIsQ0FBQ2pCLE9BQU9pQixXQUFQLENBQW1CZCxHQUE5QyxFQUFrRDtBQUNoREgsYUFBT2lCLFdBQVAsR0FBcUI7QUFDbkJDLGVBQU9oQixLQUFLQyxHQUFMLEVBRFk7QUFFbkJBLGFBQUssZUFBVTtBQUFFLGlCQUFPRCxLQUFLQyxHQUFMLEtBQWEsS0FBS2UsS0FBekI7QUFBaUM7QUFGL0IsT0FBckI7QUFJRDtBQUNGLEdBL0JEO0FBZ0NBLE1BQUksQ0FBQ0MsU0FBU3pCLFNBQVQsQ0FBbUIwQixJQUF4QixFQUE4QjtBQUM1QkQsYUFBU3pCLFNBQVQsQ0FBbUIwQixJQUFuQixHQUEwQixVQUFTQyxLQUFULEVBQWdCO0FBQ3hDLFVBQUksT0FBTyxJQUFQLEtBQWdCLFVBQXBCLEVBQWdDO0FBQzlCO0FBQ0E7QUFDQSxjQUFNLElBQUl0QixTQUFKLENBQWMsc0VBQWQsQ0FBTjtBQUNEOztBQUVELFVBQUl1QixRQUFVN0IsTUFBTUMsU0FBTixDQUFnQjlDLEtBQWhCLENBQXNCK0MsSUFBdEIsQ0FBMkJYLFNBQTNCLEVBQXNDLENBQXRDLENBQWQ7QUFBQSxVQUNJdUMsVUFBVSxJQURkO0FBQUEsVUFFSUMsT0FBVSxTQUFWQSxJQUFVLEdBQVcsQ0FBRSxDQUYzQjtBQUFBLFVBR0lDLFNBQVUsU0FBVkEsTUFBVSxHQUFXO0FBQ25CLGVBQU9GLFFBQVF0QyxLQUFSLENBQWMsZ0JBQWdCdUMsSUFBaEIsR0FDWixJQURZLEdBRVpILEtBRkYsRUFHQUMsTUFBTUksTUFBTixDQUFhakMsTUFBTUMsU0FBTixDQUFnQjlDLEtBQWhCLENBQXNCK0MsSUFBdEIsQ0FBMkJYLFNBQTNCLENBQWIsQ0FIQSxDQUFQO0FBSUQsT0FSTDs7QUFVQSxVQUFJLEtBQUtVLFNBQVQsRUFBb0I7QUFDbEI7QUFDQThCLGFBQUs5QixTQUFMLEdBQWlCLEtBQUtBLFNBQXRCO0FBQ0Q7QUFDRCtCLGFBQU8vQixTQUFQLEdBQW1CLElBQUk4QixJQUFKLEVBQW5COztBQUVBLGFBQU9DLE1BQVA7QUFDRCxLQXhCRDtBQXlCRDtBQUNEO0FBQ0EsV0FBU3hILFlBQVQsQ0FBc0JnRyxFQUF0QixFQUEwQjtBQUN4QixRQUFJa0IsU0FBU3pCLFNBQVQsQ0FBbUIzRixJQUFuQixLQUE0QjhGLFNBQWhDLEVBQTJDO0FBQ3pDLFVBQUk4QixnQkFBZ0Isd0JBQXBCO0FBQ0EsVUFBSUMsVUFBV0QsYUFBRCxDQUFnQkUsSUFBaEIsQ0FBc0I1QixFQUFELENBQUt0RCxRQUFMLEVBQXJCLENBQWQ7QUFDQSxhQUFRaUYsV0FBV0EsUUFBUXZGLE1BQVIsR0FBaUIsQ0FBN0IsR0FBa0N1RixRQUFRLENBQVIsRUFBV2hFLElBQVgsRUFBbEMsR0FBc0QsRUFBN0Q7QUFDRCxLQUpELE1BS0ssSUFBSXFDLEdBQUdQLFNBQUgsS0FBaUJHLFNBQXJCLEVBQWdDO0FBQ25DLGFBQU9JLEdBQUczRixXQUFILENBQWVQLElBQXRCO0FBQ0QsS0FGSSxNQUdBO0FBQ0gsYUFBT2tHLEdBQUdQLFNBQUgsQ0FBYXBGLFdBQWIsQ0FBeUJQLElBQWhDO0FBQ0Q7QUFDRjtBQUNELFdBQVM4RCxVQUFULENBQW9CaUUsR0FBcEIsRUFBd0I7QUFDdEIsUUFBSSxXQUFXQSxHQUFmLEVBQW9CLE9BQU8sSUFBUCxDQUFwQixLQUNLLElBQUksWUFBWUEsR0FBaEIsRUFBcUIsT0FBTyxLQUFQLENBQXJCLEtBQ0EsSUFBSSxDQUFDQyxNQUFNRCxNQUFNLENBQVosQ0FBTCxFQUFxQixPQUFPRSxXQUFXRixHQUFYLENBQVA7QUFDMUIsV0FBT0EsR0FBUDtBQUNEO0FBQ0Q7QUFDQTtBQUNBLFdBQVMzSCxTQUFULENBQW1CMkgsR0FBbkIsRUFBd0I7QUFDdEIsV0FBT0EsSUFBSUcsT0FBSixDQUFZLGlCQUFaLEVBQStCLE9BQS9CLEVBQXdDMUgsV0FBeEMsRUFBUDtBQUNEO0FBRUEsQ0F6WEEsQ0F5WEMySCxNQXpYRCxDQUFEO0NDQUE7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViRSxhQUFXMkksR0FBWCxHQUFpQjtBQUNmQyxzQkFBa0JBLGdCQURIO0FBRWZDLG1CQUFlQSxhQUZBO0FBR2ZDLGdCQUFZQTs7QUFHZDs7Ozs7Ozs7OztBQU5pQixHQUFqQixDQWdCQSxTQUFTRixnQkFBVCxDQUEwQkcsT0FBMUIsRUFBbUNDLE1BQW5DLEVBQTJDQyxNQUEzQyxFQUFtREMsTUFBbkQsRUFBMkQ7QUFDekQsUUFBSUMsVUFBVU4sY0FBY0UsT0FBZCxDQUFkO0FBQUEsUUFDSUssR0FESjtBQUFBLFFBQ1NDLE1BRFQ7QUFBQSxRQUNpQkMsSUFEakI7QUFBQSxRQUN1QkMsS0FEdkI7O0FBR0EsUUFBSVAsTUFBSixFQUFZO0FBQ1YsVUFBSVEsVUFBVVgsY0FBY0csTUFBZCxDQUFkOztBQUVBSyxlQUFVRixRQUFRTSxNQUFSLENBQWVMLEdBQWYsR0FBcUJELFFBQVFPLE1BQTdCLElBQXVDRixRQUFRRSxNQUFSLEdBQWlCRixRQUFRQyxNQUFSLENBQWVMLEdBQWpGO0FBQ0FBLFlBQVVELFFBQVFNLE1BQVIsQ0FBZUwsR0FBZixJQUFzQkksUUFBUUMsTUFBUixDQUFlTCxHQUEvQztBQUNBRSxhQUFVSCxRQUFRTSxNQUFSLENBQWVILElBQWYsSUFBdUJFLFFBQVFDLE1BQVIsQ0FBZUgsSUFBaEQ7QUFDQUMsY0FBVUosUUFBUU0sTUFBUixDQUFlSCxJQUFmLEdBQXNCSCxRQUFRUSxLQUE5QixJQUF1Q0gsUUFBUUcsS0FBUixHQUFnQkgsUUFBUUMsTUFBUixDQUFlSCxJQUFoRjtBQUNELEtBUEQsTUFRSztBQUNIRCxlQUFVRixRQUFRTSxNQUFSLENBQWVMLEdBQWYsR0FBcUJELFFBQVFPLE1BQTdCLElBQXVDUCxRQUFRUyxVQUFSLENBQW1CRixNQUFuQixHQUE0QlAsUUFBUVMsVUFBUixDQUFtQkgsTUFBbkIsQ0FBMEJMLEdBQXZHO0FBQ0FBLFlBQVVELFFBQVFNLE1BQVIsQ0FBZUwsR0FBZixJQUFzQkQsUUFBUVMsVUFBUixDQUFtQkgsTUFBbkIsQ0FBMEJMLEdBQTFEO0FBQ0FFLGFBQVVILFFBQVFNLE1BQVIsQ0FBZUgsSUFBZixJQUF1QkgsUUFBUVMsVUFBUixDQUFtQkgsTUFBbkIsQ0FBMEJILElBQTNEO0FBQ0FDLGNBQVVKLFFBQVFNLE1BQVIsQ0FBZUgsSUFBZixHQUFzQkgsUUFBUVEsS0FBOUIsSUFBdUNSLFFBQVFTLFVBQVIsQ0FBbUJELEtBQXBFO0FBQ0Q7O0FBRUQsUUFBSUUsVUFBVSxDQUFDUixNQUFELEVBQVNELEdBQVQsRUFBY0UsSUFBZCxFQUFvQkMsS0FBcEIsQ0FBZDs7QUFFQSxRQUFJTixNQUFKLEVBQVk7QUFDVixhQUFPSyxTQUFTQyxLQUFULEtBQW1CLElBQTFCO0FBQ0Q7O0FBRUQsUUFBSUwsTUFBSixFQUFZO0FBQ1YsYUFBT0UsUUFBUUMsTUFBUixLQUFtQixJQUExQjtBQUNEOztBQUVELFdBQU9RLFFBQVFySSxPQUFSLENBQWdCLEtBQWhCLE1BQTJCLENBQUMsQ0FBbkM7QUFDRDs7QUFFRDs7Ozs7OztBQU9BLFdBQVNxSCxhQUFULENBQXVCdkYsSUFBdkIsRUFBNkIyRCxJQUE3QixFQUFrQztBQUNoQzNELFdBQU9BLEtBQUtULE1BQUwsR0FBY1MsS0FBSyxDQUFMLENBQWQsR0FBd0JBLElBQS9COztBQUVBLFFBQUlBLFNBQVNrRCxNQUFULElBQW1CbEQsU0FBU29CLFFBQWhDLEVBQTBDO0FBQ3hDLFlBQU0sSUFBSW9GLEtBQUosQ0FBVSw4Q0FBVixDQUFOO0FBQ0Q7O0FBRUQsUUFBSUMsT0FBT3pHLEtBQUswRyxxQkFBTCxFQUFYO0FBQUEsUUFDSUMsVUFBVTNHLEtBQUs0RyxVQUFMLENBQWdCRixxQkFBaEIsRUFEZDtBQUFBLFFBRUlHLFVBQVV6RixTQUFTMEYsSUFBVCxDQUFjSixxQkFBZCxFQUZkO0FBQUEsUUFHSUssT0FBTzdELE9BQU84RCxXQUhsQjtBQUFBLFFBSUlDLE9BQU8vRCxPQUFPZ0UsV0FKbEI7O0FBTUEsV0FBTztBQUNMYixhQUFPSSxLQUFLSixLQURQO0FBRUxELGNBQVFLLEtBQUtMLE1BRlI7QUFHTEQsY0FBUTtBQUNOTCxhQUFLVyxLQUFLWCxHQUFMLEdBQVdpQixJQURWO0FBRU5mLGNBQU1TLEtBQUtULElBQUwsR0FBWWlCO0FBRlosT0FISDtBQU9MRSxrQkFBWTtBQUNWZCxlQUFPTSxRQUFRTixLQURMO0FBRVZELGdCQUFRTyxRQUFRUCxNQUZOO0FBR1ZELGdCQUFRO0FBQ05MLGVBQUthLFFBQVFiLEdBQVIsR0FBY2lCLElBRGI7QUFFTmYsZ0JBQU1XLFFBQVFYLElBQVIsR0FBZWlCO0FBRmY7QUFIRSxPQVBQO0FBZUxYLGtCQUFZO0FBQ1ZELGVBQU9RLFFBQVFSLEtBREw7QUFFVkQsZ0JBQVFTLFFBQVFULE1BRk47QUFHVkQsZ0JBQVE7QUFDTkwsZUFBS2lCLElBREM7QUFFTmYsZ0JBQU1pQjtBQUZBO0FBSEU7QUFmUCxLQUFQO0FBd0JEOztBQUVEOzs7Ozs7Ozs7Ozs7QUFZQSxXQUFTekIsVUFBVCxDQUFvQkMsT0FBcEIsRUFBNkIyQixNQUE3QixFQUFxQ0MsUUFBckMsRUFBK0NDLE9BQS9DLEVBQXdEQyxPQUF4RCxFQUFpRUMsVUFBakUsRUFBNkU7QUFDM0UsUUFBSUMsV0FBV2xDLGNBQWNFLE9BQWQsQ0FBZjtBQUFBLFFBQ0lpQyxjQUFjTixTQUFTN0IsY0FBYzZCLE1BQWQsQ0FBVCxHQUFpQyxJQURuRDs7QUFHQSxZQUFRQyxRQUFSO0FBQ0UsV0FBSyxLQUFMO0FBQ0UsZUFBTztBQUNMckIsZ0JBQU90SixXQUFXSSxHQUFYLEtBQW1CNEssWUFBWXZCLE1BQVosQ0FBbUJILElBQW5CLEdBQTBCeUIsU0FBU3BCLEtBQW5DLEdBQTJDcUIsWUFBWXJCLEtBQTFFLEdBQWtGcUIsWUFBWXZCLE1BQVosQ0FBbUJILElBRHZHO0FBRUxGLGVBQUs0QixZQUFZdkIsTUFBWixDQUFtQkwsR0FBbkIsSUFBMEIyQixTQUFTckIsTUFBVCxHQUFrQmtCLE9BQTVDO0FBRkEsU0FBUDtBQUlBO0FBQ0YsV0FBSyxNQUFMO0FBQ0UsZUFBTztBQUNMdEIsZ0JBQU0wQixZQUFZdkIsTUFBWixDQUFtQkgsSUFBbkIsSUFBMkJ5QixTQUFTcEIsS0FBVCxHQUFpQmtCLE9BQTVDLENBREQ7QUFFTHpCLGVBQUs0QixZQUFZdkIsTUFBWixDQUFtQkw7QUFGbkIsU0FBUDtBQUlBO0FBQ0YsV0FBSyxPQUFMO0FBQ0UsZUFBTztBQUNMRSxnQkFBTTBCLFlBQVl2QixNQUFaLENBQW1CSCxJQUFuQixHQUEwQjBCLFlBQVlyQixLQUF0QyxHQUE4Q2tCLE9BRC9DO0FBRUx6QixlQUFLNEIsWUFBWXZCLE1BQVosQ0FBbUJMO0FBRm5CLFNBQVA7QUFJQTtBQUNGLFdBQUssWUFBTDtBQUNFLGVBQU87QUFDTEUsZ0JBQU8wQixZQUFZdkIsTUFBWixDQUFtQkgsSUFBbkIsR0FBMkIwQixZQUFZckIsS0FBWixHQUFvQixDQUFoRCxHQUF1RG9CLFNBQVNwQixLQUFULEdBQWlCLENBRHpFO0FBRUxQLGVBQUs0QixZQUFZdkIsTUFBWixDQUFtQkwsR0FBbkIsSUFBMEIyQixTQUFTckIsTUFBVCxHQUFrQmtCLE9BQTVDO0FBRkEsU0FBUDtBQUlBO0FBQ0YsV0FBSyxlQUFMO0FBQ0UsZUFBTztBQUNMdEIsZ0JBQU13QixhQUFhRCxPQUFiLEdBQXlCRyxZQUFZdkIsTUFBWixDQUFtQkgsSUFBbkIsR0FBMkIwQixZQUFZckIsS0FBWixHQUFvQixDQUFoRCxHQUF1RG9CLFNBQVNwQixLQUFULEdBQWlCLENBRGpHO0FBRUxQLGVBQUs0QixZQUFZdkIsTUFBWixDQUFtQkwsR0FBbkIsR0FBeUI0QixZQUFZdEIsTUFBckMsR0FBOENrQjtBQUY5QyxTQUFQO0FBSUE7QUFDRixXQUFLLGFBQUw7QUFDRSxlQUFPO0FBQ0x0QixnQkFBTTBCLFlBQVl2QixNQUFaLENBQW1CSCxJQUFuQixJQUEyQnlCLFNBQVNwQixLQUFULEdBQWlCa0IsT0FBNUMsQ0FERDtBQUVMekIsZUFBTTRCLFlBQVl2QixNQUFaLENBQW1CTCxHQUFuQixHQUEwQjRCLFlBQVl0QixNQUFaLEdBQXFCLENBQWhELEdBQXVEcUIsU0FBU3JCLE1BQVQsR0FBa0I7QUFGekUsU0FBUDtBQUlBO0FBQ0YsV0FBSyxjQUFMO0FBQ0UsZUFBTztBQUNMSixnQkFBTTBCLFlBQVl2QixNQUFaLENBQW1CSCxJQUFuQixHQUEwQjBCLFlBQVlyQixLQUF0QyxHQUE4Q2tCLE9BQTlDLEdBQXdELENBRHpEO0FBRUx6QixlQUFNNEIsWUFBWXZCLE1BQVosQ0FBbUJMLEdBQW5CLEdBQTBCNEIsWUFBWXRCLE1BQVosR0FBcUIsQ0FBaEQsR0FBdURxQixTQUFTckIsTUFBVCxHQUFrQjtBQUZ6RSxTQUFQO0FBSUE7QUFDRixXQUFLLFFBQUw7QUFDRSxlQUFPO0FBQ0xKLGdCQUFPeUIsU0FBU25CLFVBQVQsQ0FBb0JILE1BQXBCLENBQTJCSCxJQUEzQixHQUFtQ3lCLFNBQVNuQixVQUFULENBQW9CRCxLQUFwQixHQUE0QixDQUFoRSxHQUF1RW9CLFNBQVNwQixLQUFULEdBQWlCLENBRHpGO0FBRUxQLGVBQU0yQixTQUFTbkIsVUFBVCxDQUFvQkgsTUFBcEIsQ0FBMkJMLEdBQTNCLEdBQWtDMkIsU0FBU25CLFVBQVQsQ0FBb0JGLE1BQXBCLEdBQTZCLENBQWhFLEdBQXVFcUIsU0FBU3JCLE1BQVQsR0FBa0I7QUFGekYsU0FBUDtBQUlBO0FBQ0YsV0FBSyxRQUFMO0FBQ0UsZUFBTztBQUNMSixnQkFBTSxDQUFDeUIsU0FBU25CLFVBQVQsQ0FBb0JELEtBQXBCLEdBQTRCb0IsU0FBU3BCLEtBQXRDLElBQStDLENBRGhEO0FBRUxQLGVBQUsyQixTQUFTbkIsVUFBVCxDQUFvQkgsTUFBcEIsQ0FBMkJMLEdBQTNCLEdBQWlDd0I7QUFGakMsU0FBUDtBQUlGLFdBQUssYUFBTDtBQUNFLGVBQU87QUFDTHRCLGdCQUFNeUIsU0FBU25CLFVBQVQsQ0FBb0JILE1BQXBCLENBQTJCSCxJQUQ1QjtBQUVMRixlQUFLMkIsU0FBU25CLFVBQVQsQ0FBb0JILE1BQXBCLENBQTJCTDtBQUYzQixTQUFQO0FBSUE7QUFDRixXQUFLLGFBQUw7QUFDRSxlQUFPO0FBQ0xFLGdCQUFNMEIsWUFBWXZCLE1BQVosQ0FBbUJILElBRHBCO0FBRUxGLGVBQUs0QixZQUFZdkIsTUFBWixDQUFtQkwsR0FBbkIsR0FBeUI0QixZQUFZdEIsTUFBckMsR0FBOENrQjtBQUY5QyxTQUFQO0FBSUE7QUFDRixXQUFLLGNBQUw7QUFDRSxlQUFPO0FBQ0x0QixnQkFBTTBCLFlBQVl2QixNQUFaLENBQW1CSCxJQUFuQixHQUEwQjBCLFlBQVlyQixLQUF0QyxHQUE4Q2tCLE9BQTlDLEdBQXdERSxTQUFTcEIsS0FEbEU7QUFFTFAsZUFBSzRCLFlBQVl2QixNQUFaLENBQW1CTCxHQUFuQixHQUF5QjRCLFlBQVl0QixNQUFyQyxHQUE4Q2tCO0FBRjlDLFNBQVA7QUFJQTtBQUNGO0FBQ0UsZUFBTztBQUNMdEIsZ0JBQU90SixXQUFXSSxHQUFYLEtBQW1CNEssWUFBWXZCLE1BQVosQ0FBbUJILElBQW5CLEdBQTBCeUIsU0FBU3BCLEtBQW5DLEdBQTJDcUIsWUFBWXJCLEtBQTFFLEdBQWtGcUIsWUFBWXZCLE1BQVosQ0FBbUJILElBQW5CLEdBQTBCdUIsT0FEOUc7QUFFTHpCLGVBQUs0QixZQUFZdkIsTUFBWixDQUFtQkwsR0FBbkIsR0FBeUI0QixZQUFZdEIsTUFBckMsR0FBOENrQjtBQUY5QyxTQUFQO0FBekVKO0FBOEVEO0FBRUEsQ0FoTUEsQ0FnTUNsQyxNQWhNRCxDQUFEO0NDRkE7Ozs7Ozs7O0FBUUE7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViLE1BQU1tTCxXQUFXO0FBQ2YsT0FBRyxLQURZO0FBRWYsUUFBSSxPQUZXO0FBR2YsUUFBSSxRQUhXO0FBSWYsUUFBSSxPQUpXO0FBS2YsUUFBSSxZQUxXO0FBTWYsUUFBSSxVQU5XO0FBT2YsUUFBSSxhQVBXO0FBUWYsUUFBSTtBQVJXLEdBQWpCOztBQVdBLE1BQUlDLFdBQVcsRUFBZjs7QUFFQSxNQUFJQyxXQUFXO0FBQ2IxSSxVQUFNMkksWUFBWUgsUUFBWixDQURPOztBQUdiOzs7Ozs7QUFNQUksWUFUYSxvQkFTSkMsS0FUSSxFQVNHO0FBQ2QsVUFBSUMsTUFBTU4sU0FBU0ssTUFBTUUsS0FBTixJQUFlRixNQUFNRyxPQUE5QixLQUEwQ0MsT0FBT0MsWUFBUCxDQUFvQkwsTUFBTUUsS0FBMUIsRUFBaUNJLFdBQWpDLEVBQXBEOztBQUVBO0FBQ0FMLFlBQU1BLElBQUk5QyxPQUFKLENBQVksS0FBWixFQUFtQixFQUFuQixDQUFOOztBQUVBLFVBQUk2QyxNQUFNTyxRQUFWLEVBQW9CTixpQkFBZUEsR0FBZjtBQUNwQixVQUFJRCxNQUFNUSxPQUFWLEVBQW1CUCxnQkFBY0EsR0FBZDtBQUNuQixVQUFJRCxNQUFNUyxNQUFWLEVBQWtCUixlQUFhQSxHQUFiOztBQUVsQjtBQUNBQSxZQUFNQSxJQUFJOUMsT0FBSixDQUFZLElBQVosRUFBa0IsRUFBbEIsQ0FBTjs7QUFFQSxhQUFPOEMsR0FBUDtBQUNELEtBdkJZOzs7QUF5QmI7Ozs7OztBQU1BUyxhQS9CYSxxQkErQkhWLEtBL0JHLEVBK0JJVyxTQS9CSixFQStCZUMsU0EvQmYsRUErQjBCO0FBQ3JDLFVBQUlDLGNBQWNqQixTQUFTZSxTQUFULENBQWxCO0FBQUEsVUFDRVIsVUFBVSxLQUFLSixRQUFMLENBQWNDLEtBQWQsQ0FEWjtBQUFBLFVBRUVjLElBRkY7QUFBQSxVQUdFQyxPQUhGO0FBQUEsVUFJRTVGLEVBSkY7O0FBTUEsVUFBSSxDQUFDMEYsV0FBTCxFQUFrQixPQUFPeEosUUFBUWtCLElBQVIsQ0FBYSx3QkFBYixDQUFQOztBQUVsQixVQUFJLE9BQU9zSSxZQUFZRyxHQUFuQixLQUEyQixXQUEvQixFQUE0QztBQUFFO0FBQzFDRixlQUFPRCxXQUFQLENBRHdDLENBQ3BCO0FBQ3ZCLE9BRkQsTUFFTztBQUFFO0FBQ0wsWUFBSW5NLFdBQVdJLEdBQVgsRUFBSixFQUFzQmdNLE9BQU90TSxFQUFFeU0sTUFBRixDQUFTLEVBQVQsRUFBYUosWUFBWUcsR0FBekIsRUFBOEJILFlBQVkvTCxHQUExQyxDQUFQLENBQXRCLEtBRUtnTSxPQUFPdE0sRUFBRXlNLE1BQUYsQ0FBUyxFQUFULEVBQWFKLFlBQVkvTCxHQUF6QixFQUE4QitMLFlBQVlHLEdBQTFDLENBQVA7QUFDUjtBQUNERCxnQkFBVUQsS0FBS1gsT0FBTCxDQUFWOztBQUVBaEYsV0FBS3lGLFVBQVVHLE9BQVYsQ0FBTDtBQUNBLFVBQUk1RixNQUFNLE9BQU9BLEVBQVAsS0FBYyxVQUF4QixFQUFvQztBQUFFO0FBQ3BDLFlBQUkrRixjQUFjL0YsR0FBR2hCLEtBQUgsRUFBbEI7QUFDQSxZQUFJeUcsVUFBVU8sT0FBVixJQUFxQixPQUFPUCxVQUFVTyxPQUFqQixLQUE2QixVQUF0RCxFQUFrRTtBQUFFO0FBQ2hFUCxvQkFBVU8sT0FBVixDQUFrQkQsV0FBbEI7QUFDSDtBQUNGLE9BTEQsTUFLTztBQUNMLFlBQUlOLFVBQVVRLFNBQVYsSUFBdUIsT0FBT1IsVUFBVVEsU0FBakIsS0FBK0IsVUFBMUQsRUFBc0U7QUFBRTtBQUNwRVIsb0JBQVVRLFNBQVY7QUFDSDtBQUNGO0FBQ0YsS0E1RFk7OztBQThEYjs7Ozs7QUFLQUMsaUJBbkVhLHlCQW1FQ3pMLFFBbkVELEVBbUVXO0FBQ3RCLFVBQUcsQ0FBQ0EsUUFBSixFQUFjO0FBQUMsZUFBTyxLQUFQO0FBQWU7QUFDOUIsYUFBT0EsU0FBU3VDLElBQVQsQ0FBYyw4S0FBZCxFQUE4TG1KLE1BQTlMLENBQXFNLFlBQVc7QUFDck4sWUFBSSxDQUFDOU0sRUFBRSxJQUFGLEVBQVErTSxFQUFSLENBQVcsVUFBWCxDQUFELElBQTJCL00sRUFBRSxJQUFGLEVBQVFPLElBQVIsQ0FBYSxVQUFiLElBQTJCLENBQTFELEVBQTZEO0FBQUUsaUJBQU8sS0FBUDtBQUFlLFNBRHVJLENBQ3RJO0FBQy9FLGVBQU8sSUFBUDtBQUNELE9BSE0sQ0FBUDtBQUlELEtBekVZOzs7QUEyRWI7Ozs7OztBQU1BeU0sWUFqRmEsb0JBaUZKQyxhQWpGSSxFQWlGV1gsSUFqRlgsRUFpRmlCO0FBQzVCbEIsZUFBUzZCLGFBQVQsSUFBMEJYLElBQTFCO0FBQ0QsS0FuRlk7OztBQXFGYjs7OztBQUlBWSxhQXpGYSxxQkF5Rkg5TCxRQXpGRyxFQXlGTztBQUNsQixVQUFJK0wsYUFBYWpOLFdBQVdtTCxRQUFYLENBQW9Cd0IsYUFBcEIsQ0FBa0N6TCxRQUFsQyxDQUFqQjtBQUFBLFVBQ0lnTSxrQkFBa0JELFdBQVdFLEVBQVgsQ0FBYyxDQUFkLENBRHRCO0FBQUEsVUFFSUMsaUJBQWlCSCxXQUFXRSxFQUFYLENBQWMsQ0FBQyxDQUFmLENBRnJCOztBQUlBak0sZUFBU21NLEVBQVQsQ0FBWSxzQkFBWixFQUFvQyxVQUFTL0IsS0FBVCxFQUFnQjtBQUNsRCxZQUFJQSxNQUFNZ0MsTUFBTixLQUFpQkYsZUFBZSxDQUFmLENBQWpCLElBQXNDcE4sV0FBV21MLFFBQVgsQ0FBb0JFLFFBQXBCLENBQTZCQyxLQUE3QixNQUF3QyxLQUFsRixFQUF5RjtBQUN2RkEsZ0JBQU1pQyxjQUFOO0FBQ0FMLDBCQUFnQk0sS0FBaEI7QUFDRCxTQUhELE1BSUssSUFBSWxDLE1BQU1nQyxNQUFOLEtBQWlCSixnQkFBZ0IsQ0FBaEIsQ0FBakIsSUFBdUNsTixXQUFXbUwsUUFBWCxDQUFvQkUsUUFBcEIsQ0FBNkJDLEtBQTdCLE1BQXdDLFdBQW5GLEVBQWdHO0FBQ25HQSxnQkFBTWlDLGNBQU47QUFDQUgseUJBQWVJLEtBQWY7QUFDRDtBQUNGLE9BVEQ7QUFVRCxLQXhHWTs7QUF5R2I7Ozs7QUFJQUMsZ0JBN0dhLHdCQTZHQXZNLFFBN0dBLEVBNkdVO0FBQ3JCQSxlQUFTd00sR0FBVCxDQUFhLHNCQUFiO0FBQ0Q7QUEvR1ksR0FBZjs7QUFrSEE7Ozs7QUFJQSxXQUFTdEMsV0FBVCxDQUFxQnVDLEdBQXJCLEVBQTBCO0FBQ3hCLFFBQUlDLElBQUksRUFBUjtBQUNBLFNBQUssSUFBSUMsRUFBVCxJQUFlRixHQUFmO0FBQW9CQyxRQUFFRCxJQUFJRSxFQUFKLENBQUYsSUFBYUYsSUFBSUUsRUFBSixDQUFiO0FBQXBCLEtBQ0EsT0FBT0QsQ0FBUDtBQUNEOztBQUVENU4sYUFBV21MLFFBQVgsR0FBc0JBLFFBQXRCO0FBRUMsQ0E3SUEsQ0E2SUN6QyxNQTdJRCxDQUFEO0NDVkE7Ozs7QUFFQSxDQUFDLFVBQVM1SSxDQUFULEVBQVk7O0FBRWI7QUFDQSxNQUFNZ08saUJBQWlCO0FBQ3JCLGVBQVksYUFEUztBQUVyQkMsZUFBWSwwQ0FGUztBQUdyQkMsY0FBVyx5Q0FIVTtBQUlyQkMsWUFBUyx5REFDUCxtREFETyxHQUVQLG1EQUZPLEdBR1AsOENBSE8sR0FJUCwyQ0FKTyxHQUtQO0FBVG1CLEdBQXZCOztBQVlBLE1BQUlqSSxhQUFhO0FBQ2ZrSSxhQUFTLEVBRE07O0FBR2ZDLGFBQVMsRUFITTs7QUFLZjs7Ozs7QUFLQW5NLFNBVmUsbUJBVVA7QUFDTixVQUFJb00sT0FBTyxJQUFYO0FBQ0EsVUFBSUMsa0JBQWtCdk8sRUFBRSxnQkFBRixFQUFvQndPLEdBQXBCLENBQXdCLGFBQXhCLENBQXRCO0FBQ0EsVUFBSUMsWUFBSjs7QUFFQUEscUJBQWVDLG1CQUFtQkgsZUFBbkIsQ0FBZjs7QUFFQSxXQUFLLElBQUk5QyxHQUFULElBQWdCZ0QsWUFBaEIsRUFBOEI7QUFDNUIsWUFBR0EsYUFBYUUsY0FBYixDQUE0QmxELEdBQTVCLENBQUgsRUFBcUM7QUFDbkM2QyxlQUFLRixPQUFMLENBQWE3TSxJQUFiLENBQWtCO0FBQ2hCZCxrQkFBTWdMLEdBRFU7QUFFaEJtRCxvREFBc0NILGFBQWFoRCxHQUFiLENBQXRDO0FBRmdCLFdBQWxCO0FBSUQ7QUFDRjs7QUFFRCxXQUFLNEMsT0FBTCxHQUFlLEtBQUtRLGVBQUwsRUFBZjs7QUFFQSxXQUFLQyxRQUFMO0FBQ0QsS0E3QmM7OztBQStCZjs7Ozs7O0FBTUFDLFdBckNlLG1CQXFDUEMsSUFyQ08sRUFxQ0Q7QUFDWixVQUFJQyxRQUFRLEtBQUtDLEdBQUwsQ0FBU0YsSUFBVCxDQUFaOztBQUVBLFVBQUlDLEtBQUosRUFBVztBQUNULGVBQU92SSxPQUFPeUksVUFBUCxDQUFrQkYsS0FBbEIsRUFBeUJHLE9BQWhDO0FBQ0Q7O0FBRUQsYUFBTyxLQUFQO0FBQ0QsS0E3Q2M7OztBQStDZjs7Ozs7O0FBTUFyQyxNQXJEZSxjQXFEWmlDLElBckRZLEVBcUROO0FBQ1BBLGFBQU9BLEtBQUsxSyxJQUFMLEdBQVlMLEtBQVosQ0FBa0IsR0FBbEIsQ0FBUDtBQUNBLFVBQUcrSyxLQUFLak0sTUFBTCxHQUFjLENBQWQsSUFBbUJpTSxLQUFLLENBQUwsTUFBWSxNQUFsQyxFQUEwQztBQUN4QyxZQUFHQSxLQUFLLENBQUwsTUFBWSxLQUFLSCxlQUFMLEVBQWYsRUFBdUMsT0FBTyxJQUFQO0FBQ3hDLE9BRkQsTUFFTztBQUNMLGVBQU8sS0FBS0UsT0FBTCxDQUFhQyxLQUFLLENBQUwsQ0FBYixDQUFQO0FBQ0Q7QUFDRCxhQUFPLEtBQVA7QUFDRCxLQTdEYzs7O0FBK0RmOzs7Ozs7QUFNQUUsT0FyRWUsZUFxRVhGLElBckVXLEVBcUVMO0FBQ1IsV0FBSyxJQUFJdkwsQ0FBVCxJQUFjLEtBQUsySyxPQUFuQixFQUE0QjtBQUMxQixZQUFHLEtBQUtBLE9BQUwsQ0FBYU8sY0FBYixDQUE0QmxMLENBQTVCLENBQUgsRUFBbUM7QUFDakMsY0FBSXdMLFFBQVEsS0FBS2IsT0FBTCxDQUFhM0ssQ0FBYixDQUFaO0FBQ0EsY0FBSXVMLFNBQVNDLE1BQU14TyxJQUFuQixFQUF5QixPQUFPd08sTUFBTUwsS0FBYjtBQUMxQjtBQUNGOztBQUVELGFBQU8sSUFBUDtBQUNELEtBOUVjOzs7QUFnRmY7Ozs7OztBQU1BQyxtQkF0RmUsNkJBc0ZHO0FBQ2hCLFVBQUlRLE9BQUo7O0FBRUEsV0FBSyxJQUFJNUwsSUFBSSxDQUFiLEVBQWdCQSxJQUFJLEtBQUsySyxPQUFMLENBQWFyTCxNQUFqQyxFQUF5Q1UsR0FBekMsRUFBOEM7QUFDNUMsWUFBSXdMLFFBQVEsS0FBS2IsT0FBTCxDQUFhM0ssQ0FBYixDQUFaOztBQUVBLFlBQUlpRCxPQUFPeUksVUFBUCxDQUFrQkYsTUFBTUwsS0FBeEIsRUFBK0JRLE9BQW5DLEVBQTRDO0FBQzFDQyxvQkFBVUosS0FBVjtBQUNEO0FBQ0Y7O0FBRUQsVUFBSSxRQUFPSSxPQUFQLHlDQUFPQSxPQUFQLE9BQW1CLFFBQXZCLEVBQWlDO0FBQy9CLGVBQU9BLFFBQVE1TyxJQUFmO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsZUFBTzRPLE9BQVA7QUFDRDtBQUNGLEtBdEdjOzs7QUF3R2Y7Ozs7O0FBS0FQLFlBN0dlLHNCQTZHSjtBQUFBOztBQUNUOU8sUUFBRTBHLE1BQUYsRUFBVTZHLEVBQVYsQ0FBYSxzQkFBYixFQUFxQyxZQUFNO0FBQ3pDLFlBQUkrQixVQUFVLE1BQUtULGVBQUwsRUFBZDtBQUFBLFlBQXNDVSxjQUFjLE1BQUtsQixPQUF6RDs7QUFFQSxZQUFJaUIsWUFBWUMsV0FBaEIsRUFBNkI7QUFDM0I7QUFDQSxnQkFBS2xCLE9BQUwsR0FBZWlCLE9BQWY7O0FBRUE7QUFDQXRQLFlBQUUwRyxNQUFGLEVBQVVwRixPQUFWLENBQWtCLHVCQUFsQixFQUEyQyxDQUFDZ08sT0FBRCxFQUFVQyxXQUFWLENBQTNDO0FBQ0Q7QUFDRixPQVZEO0FBV0Q7QUF6SGMsR0FBakI7O0FBNEhBclAsYUFBV2dHLFVBQVgsR0FBd0JBLFVBQXhCOztBQUVBO0FBQ0E7QUFDQVEsU0FBT3lJLFVBQVAsS0FBc0J6SSxPQUFPeUksVUFBUCxHQUFvQixZQUFXO0FBQ25EOztBQUVBOztBQUNBLFFBQUlLLGFBQWM5SSxPQUFPOEksVUFBUCxJQUFxQjlJLE9BQU8rSSxLQUE5Qzs7QUFFQTtBQUNBLFFBQUksQ0FBQ0QsVUFBTCxFQUFpQjtBQUNmLFVBQUl4SyxRQUFVSixTQUFTQyxhQUFULENBQXVCLE9BQXZCLENBQWQ7QUFBQSxVQUNBNkssU0FBYzlLLFNBQVMrSyxvQkFBVCxDQUE4QixRQUE5QixFQUF3QyxDQUF4QyxDQURkO0FBQUEsVUFFQUMsT0FBYyxJQUZkOztBQUlBNUssWUFBTTdDLElBQU4sR0FBYyxVQUFkO0FBQ0E2QyxZQUFNNkssRUFBTixHQUFjLG1CQUFkOztBQUVBSCxnQkFBVUEsT0FBT3RGLFVBQWpCLElBQStCc0YsT0FBT3RGLFVBQVAsQ0FBa0IwRixZQUFsQixDQUErQjlLLEtBQS9CLEVBQXNDMEssTUFBdEMsQ0FBL0I7O0FBRUE7QUFDQUUsYUFBUSxzQkFBc0JsSixNQUF2QixJQUFrQ0EsT0FBT3FKLGdCQUFQLENBQXdCL0ssS0FBeEIsRUFBK0IsSUFBL0IsQ0FBbEMsSUFBMEVBLE1BQU1nTCxZQUF2Rjs7QUFFQVIsbUJBQWE7QUFDWFMsbUJBRFcsdUJBQ0NSLEtBREQsRUFDUTtBQUNqQixjQUFJUyxtQkFBaUJULEtBQWpCLDJDQUFKOztBQUVBO0FBQ0EsY0FBSXpLLE1BQU1tTCxVQUFWLEVBQXNCO0FBQ3BCbkwsa0JBQU1tTCxVQUFOLENBQWlCQyxPQUFqQixHQUEyQkYsSUFBM0I7QUFDRCxXQUZELE1BRU87QUFDTGxMLGtCQUFNcUwsV0FBTixHQUFvQkgsSUFBcEI7QUFDRDs7QUFFRDtBQUNBLGlCQUFPTixLQUFLL0YsS0FBTCxLQUFlLEtBQXRCO0FBQ0Q7QUFiVSxPQUFiO0FBZUQ7O0FBRUQsV0FBTyxVQUFTNEYsS0FBVCxFQUFnQjtBQUNyQixhQUFPO0FBQ0xMLGlCQUFTSSxXQUFXUyxXQUFYLENBQXVCUixTQUFTLEtBQWhDLENBREo7QUFFTEEsZUFBT0EsU0FBUztBQUZYLE9BQVA7QUFJRCxLQUxEO0FBTUQsR0EzQ3lDLEVBQTFDOztBQTZDQTtBQUNBLFdBQVNmLGtCQUFULENBQTRCbEcsR0FBNUIsRUFBaUM7QUFDL0IsUUFBSThILGNBQWMsRUFBbEI7O0FBRUEsUUFBSSxPQUFPOUgsR0FBUCxLQUFlLFFBQW5CLEVBQTZCO0FBQzNCLGFBQU84SCxXQUFQO0FBQ0Q7O0FBRUQ5SCxVQUFNQSxJQUFJbEUsSUFBSixHQUFXaEIsS0FBWCxDQUFpQixDQUFqQixFQUFvQixDQUFDLENBQXJCLENBQU4sQ0FQK0IsQ0FPQTs7QUFFL0IsUUFBSSxDQUFDa0YsR0FBTCxFQUFVO0FBQ1IsYUFBTzhILFdBQVA7QUFDRDs7QUFFREEsa0JBQWM5SCxJQUFJdkUsS0FBSixDQUFVLEdBQVYsRUFBZXNNLE1BQWYsQ0FBc0IsVUFBU0MsR0FBVCxFQUFjQyxLQUFkLEVBQXFCO0FBQ3ZELFVBQUlDLFFBQVFELE1BQU05SCxPQUFOLENBQWMsS0FBZCxFQUFxQixHQUFyQixFQUEwQjFFLEtBQTFCLENBQWdDLEdBQWhDLENBQVo7QUFDQSxVQUFJd0gsTUFBTWlGLE1BQU0sQ0FBTixDQUFWO0FBQ0EsVUFBSUMsTUFBTUQsTUFBTSxDQUFOLENBQVY7QUFDQWpGLFlBQU1tRixtQkFBbUJuRixHQUFuQixDQUFOOztBQUVBO0FBQ0E7QUFDQWtGLFlBQU1BLFFBQVFwSyxTQUFSLEdBQW9CLElBQXBCLEdBQTJCcUssbUJBQW1CRCxHQUFuQixDQUFqQzs7QUFFQSxVQUFJLENBQUNILElBQUk3QixjQUFKLENBQW1CbEQsR0FBbkIsQ0FBTCxFQUE4QjtBQUM1QitFLFlBQUkvRSxHQUFKLElBQVdrRixHQUFYO0FBQ0QsT0FGRCxNQUVPLElBQUl4SyxNQUFNMEssT0FBTixDQUFjTCxJQUFJL0UsR0FBSixDQUFkLENBQUosRUFBNkI7QUFDbEMrRSxZQUFJL0UsR0FBSixFQUFTbEssSUFBVCxDQUFjb1AsR0FBZDtBQUNELE9BRk0sTUFFQTtBQUNMSCxZQUFJL0UsR0FBSixJQUFXLENBQUMrRSxJQUFJL0UsR0FBSixDQUFELEVBQVdrRixHQUFYLENBQVg7QUFDRDtBQUNELGFBQU9ILEdBQVA7QUFDRCxLQWxCYSxFQWtCWCxFQWxCVyxDQUFkOztBQW9CQSxXQUFPRixXQUFQO0FBQ0Q7O0FBRURwUSxhQUFXZ0csVUFBWCxHQUF3QkEsVUFBeEI7QUFFQyxDQW5PQSxDQW1PQzBDLE1Bbk9ELENBQUQ7Q0NGQTs7QUFFQSxDQUFDLFVBQVM1SSxDQUFULEVBQVk7O0FBRWI7Ozs7O0FBS0EsTUFBTThRLGNBQWdCLENBQUMsV0FBRCxFQUFjLFdBQWQsQ0FBdEI7QUFDQSxNQUFNQyxnQkFBZ0IsQ0FBQyxrQkFBRCxFQUFxQixrQkFBckIsQ0FBdEI7O0FBRUEsTUFBTUMsU0FBUztBQUNiQyxlQUFXLG1CQUFTaEksT0FBVCxFQUFrQmlJLFNBQWxCLEVBQTZCQyxFQUE3QixFQUFpQztBQUMxQ0MsY0FBUSxJQUFSLEVBQWNuSSxPQUFkLEVBQXVCaUksU0FBdkIsRUFBa0NDLEVBQWxDO0FBQ0QsS0FIWTs7QUFLYkUsZ0JBQVksb0JBQVNwSSxPQUFULEVBQWtCaUksU0FBbEIsRUFBNkJDLEVBQTdCLEVBQWlDO0FBQzNDQyxjQUFRLEtBQVIsRUFBZW5JLE9BQWYsRUFBd0JpSSxTQUF4QixFQUFtQ0MsRUFBbkM7QUFDRDtBQVBZLEdBQWY7O0FBVUEsV0FBU0csSUFBVCxDQUFjQyxRQUFkLEVBQXdCL04sSUFBeEIsRUFBOEJtRCxFQUE5QixFQUFpQztBQUMvQixRQUFJNkssSUFBSjtBQUFBLFFBQVVDLElBQVY7QUFBQSxRQUFnQjdKLFFBQVEsSUFBeEI7QUFDQTs7QUFFQSxRQUFJMkosYUFBYSxDQUFqQixFQUFvQjtBQUNsQjVLLFNBQUdoQixLQUFILENBQVNuQyxJQUFUO0FBQ0FBLFdBQUtsQyxPQUFMLENBQWEscUJBQWIsRUFBb0MsQ0FBQ2tDLElBQUQsQ0FBcEMsRUFBNEMwQixjQUE1QyxDQUEyRCxxQkFBM0QsRUFBa0YsQ0FBQzFCLElBQUQsQ0FBbEY7QUFDQTtBQUNEOztBQUVELGFBQVNrTyxJQUFULENBQWNDLEVBQWQsRUFBaUI7QUFDZixVQUFHLENBQUMvSixLQUFKLEVBQVdBLFFBQVErSixFQUFSO0FBQ1g7QUFDQUYsYUFBT0UsS0FBSy9KLEtBQVo7QUFDQWpCLFNBQUdoQixLQUFILENBQVNuQyxJQUFUOztBQUVBLFVBQUdpTyxPQUFPRixRQUFWLEVBQW1CO0FBQUVDLGVBQU85SyxPQUFPTSxxQkFBUCxDQUE2QjBLLElBQTdCLEVBQW1DbE8sSUFBbkMsQ0FBUDtBQUFrRCxPQUF2RSxNQUNJO0FBQ0ZrRCxlQUFPUSxvQkFBUCxDQUE0QnNLLElBQTVCO0FBQ0FoTyxhQUFLbEMsT0FBTCxDQUFhLHFCQUFiLEVBQW9DLENBQUNrQyxJQUFELENBQXBDLEVBQTRDMEIsY0FBNUMsQ0FBMkQscUJBQTNELEVBQWtGLENBQUMxQixJQUFELENBQWxGO0FBQ0Q7QUFDRjtBQUNEZ08sV0FBTzlLLE9BQU9NLHFCQUFQLENBQTZCMEssSUFBN0IsQ0FBUDtBQUNEOztBQUVEOzs7Ozs7Ozs7QUFTQSxXQUFTTixPQUFULENBQWlCUSxJQUFqQixFQUF1QjNJLE9BQXZCLEVBQWdDaUksU0FBaEMsRUFBMkNDLEVBQTNDLEVBQStDO0FBQzdDbEksY0FBVWpKLEVBQUVpSixPQUFGLEVBQVdvRSxFQUFYLENBQWMsQ0FBZCxDQUFWOztBQUVBLFFBQUksQ0FBQ3BFLFFBQVFsRyxNQUFiLEVBQXFCOztBQUVyQixRQUFJOE8sWUFBWUQsT0FBT2QsWUFBWSxDQUFaLENBQVAsR0FBd0JBLFlBQVksQ0FBWixDQUF4QztBQUNBLFFBQUlnQixjQUFjRixPQUFPYixjQUFjLENBQWQsQ0FBUCxHQUEwQkEsY0FBYyxDQUFkLENBQTVDOztBQUVBO0FBQ0FnQjs7QUFFQTlJLFlBQ0crSSxRQURILENBQ1lkLFNBRFosRUFFRzFDLEdBRkgsQ0FFTyxZQUZQLEVBRXFCLE1BRnJCOztBQUlBeEgsMEJBQXNCLFlBQU07QUFDMUJpQyxjQUFRK0ksUUFBUixDQUFpQkgsU0FBakI7QUFDQSxVQUFJRCxJQUFKLEVBQVUzSSxRQUFRZ0osSUFBUjtBQUNYLEtBSEQ7O0FBS0E7QUFDQWpMLDBCQUFzQixZQUFNO0FBQzFCaUMsY0FBUSxDQUFSLEVBQVdpSixXQUFYO0FBQ0FqSixjQUNHdUYsR0FESCxDQUNPLFlBRFAsRUFDcUIsRUFEckIsRUFFR3dELFFBRkgsQ0FFWUYsV0FGWjtBQUdELEtBTEQ7O0FBT0E7QUFDQTdJLFlBQVFrSixHQUFSLENBQVlqUyxXQUFXd0UsYUFBWCxDQUF5QnVFLE9BQXpCLENBQVosRUFBK0NtSixNQUEvQzs7QUFFQTtBQUNBLGFBQVNBLE1BQVQsR0FBa0I7QUFDaEIsVUFBSSxDQUFDUixJQUFMLEVBQVczSSxRQUFRb0osSUFBUjtBQUNYTjtBQUNBLFVBQUlaLEVBQUosRUFBUUEsR0FBR3hMLEtBQUgsQ0FBU3NELE9BQVQ7QUFDVDs7QUFFRDtBQUNBLGFBQVM4SSxLQUFULEdBQWlCO0FBQ2Y5SSxjQUFRLENBQVIsRUFBV2pFLEtBQVgsQ0FBaUJzTixrQkFBakIsR0FBc0MsQ0FBdEM7QUFDQXJKLGNBQVFoRCxXQUFSLENBQXVCNEwsU0FBdkIsU0FBb0NDLFdBQXBDLFNBQW1EWixTQUFuRDtBQUNEO0FBQ0Y7O0FBRURoUixhQUFXb1IsSUFBWCxHQUFrQkEsSUFBbEI7QUFDQXBSLGFBQVc4USxNQUFYLEdBQW9CQSxNQUFwQjtBQUVDLENBdEdBLENBc0dDcEksTUF0R0QsQ0FBRDtDQ0ZBOztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYixNQUFNdVMsT0FBTztBQUNYQyxXQURXLG1CQUNIQyxJQURHLEVBQ2dCO0FBQUEsVUFBYnRRLElBQWEsdUVBQU4sSUFBTTs7QUFDekJzUSxXQUFLbFMsSUFBTCxDQUFVLE1BQVYsRUFBa0IsU0FBbEI7O0FBRUEsVUFBSW1TLFFBQVFELEtBQUs5TyxJQUFMLENBQVUsSUFBVixFQUFnQnBELElBQWhCLENBQXFCLEVBQUMsUUFBUSxVQUFULEVBQXJCLENBQVo7QUFBQSxVQUNJb1MsdUJBQXFCeFEsSUFBckIsYUFESjtBQUFBLFVBRUl5USxlQUFrQkQsWUFBbEIsVUFGSjtBQUFBLFVBR0lFLHNCQUFvQjFRLElBQXBCLG9CQUhKOztBQUtBdVEsWUFBTXpRLElBQU4sQ0FBVyxZQUFXO0FBQ3BCLFlBQUk2USxRQUFROVMsRUFBRSxJQUFGLENBQVo7QUFBQSxZQUNJK1MsT0FBT0QsTUFBTUUsUUFBTixDQUFlLElBQWYsQ0FEWDs7QUFHQSxZQUFJRCxLQUFLaFEsTUFBVCxFQUFpQjtBQUNmK1AsZ0JBQ0dkLFFBREgsQ0FDWWEsV0FEWixFQUVHdFMsSUFGSCxDQUVRO0FBQ0osNkJBQWlCLElBRGI7QUFFSiwwQkFBY3VTLE1BQU1FLFFBQU4sQ0FBZSxTQUFmLEVBQTBCOUMsSUFBMUI7QUFGVixXQUZSO0FBTUU7QUFDQTtBQUNBO0FBQ0EsY0FBRy9OLFNBQVMsV0FBWixFQUF5QjtBQUN2QjJRLGtCQUFNdlMsSUFBTixDQUFXLEVBQUMsaUJBQWlCLEtBQWxCLEVBQVg7QUFDRDs7QUFFSHdTLGVBQ0dmLFFBREgsY0FDdUJXLFlBRHZCLEVBRUdwUyxJQUZILENBRVE7QUFDSiw0QkFBZ0IsRUFEWjtBQUVKLG9CQUFRO0FBRkosV0FGUjtBQU1BLGNBQUc0QixTQUFTLFdBQVosRUFBeUI7QUFDdkI0USxpQkFBS3hTLElBQUwsQ0FBVSxFQUFDLGVBQWUsSUFBaEIsRUFBVjtBQUNEO0FBQ0Y7O0FBRUQsWUFBSXVTLE1BQU01SixNQUFOLENBQWEsZ0JBQWIsRUFBK0JuRyxNQUFuQyxFQUEyQztBQUN6QytQLGdCQUFNZCxRQUFOLHNCQUFrQ1ksWUFBbEM7QUFDRDtBQUNGLE9BaENEOztBQWtDQTtBQUNELEtBNUNVO0FBOENYSyxRQTlDVyxnQkE4Q05SLElBOUNNLEVBOENBdFEsSUE5Q0EsRUE4Q007QUFDZixVQUFJO0FBQ0F3USw2QkFBcUJ4USxJQUFyQixhQURKO0FBQUEsVUFFSXlRLGVBQWtCRCxZQUFsQixVQUZKO0FBQUEsVUFHSUUsc0JBQW9CMVEsSUFBcEIsb0JBSEo7O0FBS0FzUSxXQUNHOU8sSUFESCxDQUNRLHdCQURSLEVBRUdzQyxXQUZILENBRWtCME0sWUFGbEIsU0FFa0NDLFlBRmxDLFNBRWtEQyxXQUZsRCx5Q0FHR2xSLFVBSEgsQ0FHYyxjQUhkLEVBRzhCNk0sR0FIOUIsQ0FHa0MsU0FIbEMsRUFHNkMsRUFIN0M7O0FBS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEO0FBdkVVLEdBQWI7O0FBMEVBdE8sYUFBV3FTLElBQVgsR0FBa0JBLElBQWxCO0FBRUMsQ0E5RUEsQ0E4RUMzSixNQTlFRCxDQUFEO0NDRkE7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViLFdBQVNrVCxLQUFULENBQWUxUCxJQUFmLEVBQXFCMlAsT0FBckIsRUFBOEJoQyxFQUE5QixFQUFrQztBQUNoQyxRQUFJL08sUUFBUSxJQUFaO0FBQUEsUUFDSW1QLFdBQVc0QixRQUFRNUIsUUFEdkI7QUFBQSxRQUNnQztBQUM1QjZCLGdCQUFZMVEsT0FBT0MsSUFBUCxDQUFZYSxLQUFLbkMsSUFBTCxFQUFaLEVBQXlCLENBQXpCLEtBQStCLE9BRi9DO0FBQUEsUUFHSWdTLFNBQVMsQ0FBQyxDQUhkO0FBQUEsUUFJSXpMLEtBSko7QUFBQSxRQUtJckMsS0FMSjs7QUFPQSxTQUFLK04sUUFBTCxHQUFnQixLQUFoQjs7QUFFQSxTQUFLQyxPQUFMLEdBQWUsWUFBVztBQUN4QkYsZUFBUyxDQUFDLENBQVY7QUFDQTNMLG1CQUFhbkMsS0FBYjtBQUNBLFdBQUtxQyxLQUFMO0FBQ0QsS0FKRDs7QUFNQSxTQUFLQSxLQUFMLEdBQWEsWUFBVztBQUN0QixXQUFLMEwsUUFBTCxHQUFnQixLQUFoQjtBQUNBO0FBQ0E1TCxtQkFBYW5DLEtBQWI7QUFDQThOLGVBQVNBLFVBQVUsQ0FBVixHQUFjOUIsUUFBZCxHQUF5QjhCLE1BQWxDO0FBQ0E3UCxXQUFLbkMsSUFBTCxDQUFVLFFBQVYsRUFBb0IsS0FBcEI7QUFDQXVHLGNBQVFoQixLQUFLQyxHQUFMLEVBQVI7QUFDQXRCLGNBQVFOLFdBQVcsWUFBVTtBQUMzQixZQUFHa08sUUFBUUssUUFBWCxFQUFvQjtBQUNsQnBSLGdCQUFNbVIsT0FBTixHQURrQixDQUNGO0FBQ2pCO0FBQ0QsWUFBSXBDLE1BQU0sT0FBT0EsRUFBUCxLQUFjLFVBQXhCLEVBQW9DO0FBQUVBO0FBQU87QUFDOUMsT0FMTyxFQUtMa0MsTUFMSyxDQUFSO0FBTUE3UCxXQUFLbEMsT0FBTCxvQkFBOEI4UixTQUE5QjtBQUNELEtBZEQ7O0FBZ0JBLFNBQUtLLEtBQUwsR0FBYSxZQUFXO0FBQ3RCLFdBQUtILFFBQUwsR0FBZ0IsSUFBaEI7QUFDQTtBQUNBNUwsbUJBQWFuQyxLQUFiO0FBQ0EvQixXQUFLbkMsSUFBTCxDQUFVLFFBQVYsRUFBb0IsSUFBcEI7QUFDQSxVQUFJeUQsTUFBTThCLEtBQUtDLEdBQUwsRUFBVjtBQUNBd00sZUFBU0EsVUFBVXZPLE1BQU04QyxLQUFoQixDQUFUO0FBQ0FwRSxXQUFLbEMsT0FBTCxxQkFBK0I4UixTQUEvQjtBQUNELEtBUkQ7QUFTRDs7QUFFRDs7Ozs7QUFLQSxXQUFTTSxjQUFULENBQXdCQyxNQUF4QixFQUFnQ3BNLFFBQWhDLEVBQXlDO0FBQ3ZDLFFBQUkrRyxPQUFPLElBQVg7QUFBQSxRQUNJc0YsV0FBV0QsT0FBTzVRLE1BRHRCOztBQUdBLFFBQUk2USxhQUFhLENBQWpCLEVBQW9CO0FBQ2xCck07QUFDRDs7QUFFRG9NLFdBQU8xUixJQUFQLENBQVksWUFBVztBQUNyQjtBQUNBLFVBQUksS0FBSzRSLFFBQUwsSUFBa0IsS0FBS0MsVUFBTCxLQUFvQixDQUF0QyxJQUE2QyxLQUFLQSxVQUFMLEtBQW9CLFVBQXJFLEVBQWtGO0FBQ2hGQztBQUNEO0FBQ0Q7QUFIQSxXQUlLO0FBQ0g7QUFDQSxjQUFJQyxNQUFNaFUsRUFBRSxJQUFGLEVBQVFPLElBQVIsQ0FBYSxLQUFiLENBQVY7QUFDQVAsWUFBRSxJQUFGLEVBQVFPLElBQVIsQ0FBYSxLQUFiLEVBQW9CeVQsTUFBTSxHQUFOLEdBQWEsSUFBSXBOLElBQUosR0FBV0UsT0FBWCxFQUFqQztBQUNBOUcsWUFBRSxJQUFGLEVBQVFtUyxHQUFSLENBQVksTUFBWixFQUFvQixZQUFXO0FBQzdCNEI7QUFDRCxXQUZEO0FBR0Q7QUFDRixLQWREOztBQWdCQSxhQUFTQSxpQkFBVCxHQUE2QjtBQUMzQkg7QUFDQSxVQUFJQSxhQUFhLENBQWpCLEVBQW9CO0FBQ2xCck07QUFDRDtBQUNGO0FBQ0Y7O0FBRURySCxhQUFXZ1QsS0FBWCxHQUFtQkEsS0FBbkI7QUFDQWhULGFBQVd3VCxjQUFYLEdBQTRCQSxjQUE1QjtBQUVDLENBckZBLENBcUZDOUssTUFyRkQsQ0FBRDs7O0FDRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLFVBQVM1SSxDQUFULEVBQVk7O0FBRVhBLEdBQUVpVSxTQUFGLEdBQWM7QUFDWjlULFdBQVMsT0FERztBQUVaK1QsV0FBUyxrQkFBa0J0UCxTQUFTdVAsZUFGeEI7QUFHWjFHLGtCQUFnQixLQUhKO0FBSVoyRyxpQkFBZSxFQUpIO0FBS1pDLGlCQUFlO0FBTEgsRUFBZDs7QUFRQSxLQUFNQyxTQUFOO0FBQUEsS0FDTUMsU0FETjtBQUFBLEtBRU1DLFNBRk47QUFBQSxLQUdNQyxXQUhOO0FBQUEsS0FJTUMsV0FBVyxLQUpqQjs7QUFNQSxVQUFTQyxVQUFULEdBQXNCO0FBQ3BCO0FBQ0EsT0FBS0MsbUJBQUwsQ0FBeUIsV0FBekIsRUFBc0NDLFdBQXRDO0FBQ0EsT0FBS0QsbUJBQUwsQ0FBeUIsVUFBekIsRUFBcUNELFVBQXJDO0FBQ0FELGFBQVcsS0FBWDtBQUNEOztBQUVELFVBQVNHLFdBQVQsQ0FBcUIzUSxDQUFyQixFQUF3QjtBQUN0QixNQUFJbEUsRUFBRWlVLFNBQUYsQ0FBWXhHLGNBQWhCLEVBQWdDO0FBQUV2SixLQUFFdUosY0FBRjtBQUFxQjtBQUN2RCxNQUFHaUgsUUFBSCxFQUFhO0FBQ1gsT0FBSUksSUFBSTVRLEVBQUU2USxPQUFGLENBQVUsQ0FBVixFQUFhQyxLQUFyQjtBQUNBLE9BQUlDLElBQUkvUSxFQUFFNlEsT0FBRixDQUFVLENBQVYsRUFBYUcsS0FBckI7QUFDQSxPQUFJQyxLQUFLYixZQUFZUSxDQUFyQjtBQUNBLE9BQUlNLEtBQUtiLFlBQVlVLENBQXJCO0FBQ0EsT0FBSUksR0FBSjtBQUNBWixpQkFBYyxJQUFJN04sSUFBSixHQUFXRSxPQUFYLEtBQXVCME4sU0FBckM7QUFDQSxPQUFHdlIsS0FBS3FTLEdBQUwsQ0FBU0gsRUFBVCxLQUFnQm5WLEVBQUVpVSxTQUFGLENBQVlHLGFBQTVCLElBQTZDSyxlQUFlelUsRUFBRWlVLFNBQUYsQ0FBWUksYUFBM0UsRUFBMEY7QUFDeEZnQixVQUFNRixLQUFLLENBQUwsR0FBUyxNQUFULEdBQWtCLE9BQXhCO0FBQ0Q7QUFDRDtBQUNBO0FBQ0E7QUFDQSxPQUFHRSxHQUFILEVBQVE7QUFDTm5SLE1BQUV1SixjQUFGO0FBQ0FrSCxlQUFXdE8sSUFBWCxDQUFnQixJQUFoQjtBQUNBckcsTUFBRSxJQUFGLEVBQVFzQixPQUFSLENBQWdCLE9BQWhCLEVBQXlCK1QsR0FBekIsRUFBOEIvVCxPQUE5QixXQUE4QytULEdBQTlDO0FBQ0Q7QUFDRjtBQUNGOztBQUVELFVBQVNFLFlBQVQsQ0FBc0JyUixDQUF0QixFQUF5QjtBQUN2QixNQUFJQSxFQUFFNlEsT0FBRixDQUFVaFMsTUFBVixJQUFvQixDQUF4QixFQUEyQjtBQUN6QnVSLGVBQVlwUSxFQUFFNlEsT0FBRixDQUFVLENBQVYsRUFBYUMsS0FBekI7QUFDQVQsZUFBWXJRLEVBQUU2USxPQUFGLENBQVUsQ0FBVixFQUFhRyxLQUF6QjtBQUNBUixjQUFXLElBQVg7QUFDQUYsZUFBWSxJQUFJNU4sSUFBSixHQUFXRSxPQUFYLEVBQVo7QUFDQSxRQUFLME8sZ0JBQUwsQ0FBc0IsV0FBdEIsRUFBbUNYLFdBQW5DLEVBQWdELEtBQWhEO0FBQ0EsUUFBS1csZ0JBQUwsQ0FBc0IsVUFBdEIsRUFBa0NiLFVBQWxDLEVBQThDLEtBQTlDO0FBQ0Q7QUFDRjs7QUFFRCxVQUFTYyxJQUFULEdBQWdCO0FBQ2QsT0FBS0QsZ0JBQUwsSUFBeUIsS0FBS0EsZ0JBQUwsQ0FBc0IsWUFBdEIsRUFBb0NELFlBQXBDLEVBQWtELEtBQWxELENBQXpCO0FBQ0Q7O0FBRUQsVUFBU0csUUFBVCxHQUFvQjtBQUNsQixPQUFLZCxtQkFBTCxDQUF5QixZQUF6QixFQUF1Q1csWUFBdkM7QUFDRDs7QUFFRHZWLEdBQUV3TCxLQUFGLENBQVFtSyxPQUFSLENBQWdCQyxLQUFoQixHQUF3QixFQUFFQyxPQUFPSixJQUFULEVBQXhCOztBQUVBelYsR0FBRWlDLElBQUYsQ0FBTyxDQUFDLE1BQUQsRUFBUyxJQUFULEVBQWUsTUFBZixFQUF1QixPQUF2QixDQUFQLEVBQXdDLFlBQVk7QUFDbERqQyxJQUFFd0wsS0FBRixDQUFRbUssT0FBUixXQUF3QixJQUF4QixJQUFrQyxFQUFFRSxPQUFPLGlCQUFVO0FBQ25EN1YsTUFBRSxJQUFGLEVBQVF1TixFQUFSLENBQVcsT0FBWCxFQUFvQnZOLEVBQUU4VixJQUF0QjtBQUNELElBRmlDLEVBQWxDO0FBR0QsRUFKRDtBQUtELENBeEVELEVBd0VHbE4sTUF4RUg7QUF5RUE7OztBQUdBLENBQUMsVUFBUzVJLENBQVQsRUFBVztBQUNWQSxHQUFFMkcsRUFBRixDQUFLb1AsUUFBTCxHQUFnQixZQUFVO0FBQ3hCLE9BQUs5VCxJQUFMLENBQVUsVUFBU3dCLENBQVQsRUFBV1ksRUFBWCxFQUFjO0FBQ3RCckUsS0FBRXFFLEVBQUYsRUFBTXlELElBQU4sQ0FBVywyQ0FBWCxFQUF1RCxZQUFVO0FBQy9EO0FBQ0E7QUFDQWtPLGdCQUFZeEssS0FBWjtBQUNELElBSkQ7QUFLRCxHQU5EOztBQVFBLE1BQUl3SyxjQUFjLFNBQWRBLFdBQWMsQ0FBU3hLLEtBQVQsRUFBZTtBQUMvQixPQUFJdUosVUFBVXZKLE1BQU15SyxjQUFwQjtBQUFBLE9BQ0lDLFFBQVFuQixRQUFRLENBQVIsQ0FEWjtBQUFBLE9BRUlvQixhQUFhO0FBQ1hDLGdCQUFZLFdBREQ7QUFFWEMsZUFBVyxXQUZBO0FBR1hDLGNBQVU7QUFIQyxJQUZqQjtBQUFBLE9BT0luVSxPQUFPZ1UsV0FBVzNLLE1BQU1ySixJQUFqQixDQVBYO0FBQUEsT0FRSW9VLGNBUko7O0FBV0EsT0FBRyxnQkFBZ0I3UCxNQUFoQixJQUEwQixPQUFPQSxPQUFPOFAsVUFBZCxLQUE2QixVQUExRCxFQUFzRTtBQUNwRUQscUJBQWlCLElBQUk3UCxPQUFPOFAsVUFBWCxDQUFzQnJVLElBQXRCLEVBQTRCO0FBQzNDLGdCQUFXLElBRGdDO0FBRTNDLG1CQUFjLElBRjZCO0FBRzNDLGdCQUFXK1QsTUFBTU8sT0FIMEI7QUFJM0MsZ0JBQVdQLE1BQU1RLE9BSjBCO0FBSzNDLGdCQUFXUixNQUFNUyxPQUwwQjtBQU0zQyxnQkFBV1QsTUFBTVU7QUFOMEIsS0FBNUIsQ0FBakI7QUFRRCxJQVRELE1BU087QUFDTEwscUJBQWlCM1IsU0FBU2lTLFdBQVQsQ0FBcUIsWUFBckIsQ0FBakI7QUFDQU4sbUJBQWVPLGNBQWYsQ0FBOEIzVSxJQUE5QixFQUFvQyxJQUFwQyxFQUEwQyxJQUExQyxFQUFnRHVFLE1BQWhELEVBQXdELENBQXhELEVBQTJEd1AsTUFBTU8sT0FBakUsRUFBMEVQLE1BQU1RLE9BQWhGLEVBQXlGUixNQUFNUyxPQUEvRixFQUF3R1QsTUFBTVUsT0FBOUcsRUFBdUgsS0FBdkgsRUFBOEgsS0FBOUgsRUFBcUksS0FBckksRUFBNEksS0FBNUksRUFBbUosQ0FBbkosQ0FBb0osUUFBcEosRUFBOEosSUFBOUo7QUFDRDtBQUNEVixTQUFNMUksTUFBTixDQUFhdUosYUFBYixDQUEyQlIsY0FBM0I7QUFDRCxHQTFCRDtBQTJCRCxFQXBDRDtBQXFDRCxDQXRDQSxDQXNDQzNOLE1BdENELENBQUQ7O0FBeUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQy9IQTs7OztBQUVBLENBQUMsVUFBUzVJLENBQVQsRUFBWTs7QUFFYixNQUFNZ1gsbUJBQW9CLFlBQVk7QUFDcEMsUUFBSUMsV0FBVyxDQUFDLFFBQUQsRUFBVyxLQUFYLEVBQWtCLEdBQWxCLEVBQXVCLElBQXZCLEVBQTZCLEVBQTdCLENBQWY7QUFDQSxTQUFLLElBQUl4VCxJQUFFLENBQVgsRUFBY0EsSUFBSXdULFNBQVNsVSxNQUEzQixFQUFtQ1UsR0FBbkMsRUFBd0M7QUFDdEMsVUFBT3dULFNBQVN4VCxDQUFULENBQUgseUJBQW9DaUQsTUFBeEMsRUFBZ0Q7QUFDOUMsZUFBT0EsT0FBVXVRLFNBQVN4VCxDQUFULENBQVYsc0JBQVA7QUFDRDtBQUNGO0FBQ0QsV0FBTyxLQUFQO0FBQ0QsR0FSeUIsRUFBMUI7O0FBVUEsTUFBTXlULFdBQVcsU0FBWEEsUUFBVyxDQUFDN1MsRUFBRCxFQUFLbEMsSUFBTCxFQUFjO0FBQzdCa0MsT0FBR2hELElBQUgsQ0FBUWMsSUFBUixFQUFjOEIsS0FBZCxDQUFvQixHQUFwQixFQUF5QjFCLE9BQXpCLENBQWlDLGNBQU07QUFDckN2QyxjQUFNNlAsRUFBTixFQUFhMU4sU0FBUyxPQUFULEdBQW1CLFNBQW5CLEdBQStCLGdCQUE1QyxFQUFpRUEsSUFBakUsa0JBQW9GLENBQUNrQyxFQUFELENBQXBGO0FBQ0QsS0FGRDtBQUdELEdBSkQ7QUFLQTtBQUNBckUsSUFBRTRFLFFBQUYsRUFBWTJJLEVBQVosQ0FBZSxrQkFBZixFQUFtQyxhQUFuQyxFQUFrRCxZQUFXO0FBQzNEMkosYUFBU2xYLEVBQUUsSUFBRixDQUFULEVBQWtCLE1BQWxCO0FBQ0QsR0FGRDs7QUFJQTtBQUNBO0FBQ0FBLElBQUU0RSxRQUFGLEVBQVkySSxFQUFaLENBQWUsa0JBQWYsRUFBbUMsY0FBbkMsRUFBbUQsWUFBVztBQUM1RCxRQUFJc0MsS0FBSzdQLEVBQUUsSUFBRixFQUFRcUIsSUFBUixDQUFhLE9BQWIsQ0FBVDtBQUNBLFFBQUl3TyxFQUFKLEVBQVE7QUFDTnFILGVBQVNsWCxFQUFFLElBQUYsQ0FBVCxFQUFrQixPQUFsQjtBQUNELEtBRkQsTUFHSztBQUNIQSxRQUFFLElBQUYsRUFBUXNCLE9BQVIsQ0FBZ0Isa0JBQWhCO0FBQ0Q7QUFDRixHQVJEOztBQVVBO0FBQ0F0QixJQUFFNEUsUUFBRixFQUFZMkksRUFBWixDQUFlLGtCQUFmLEVBQW1DLGVBQW5DLEVBQW9ELFlBQVc7QUFDN0QsUUFBSXNDLEtBQUs3UCxFQUFFLElBQUYsRUFBUXFCLElBQVIsQ0FBYSxRQUFiLENBQVQ7QUFDQSxRQUFJd08sRUFBSixFQUFRO0FBQ05xSCxlQUFTbFgsRUFBRSxJQUFGLENBQVQsRUFBa0IsUUFBbEI7QUFDRCxLQUZELE1BRU87QUFDTEEsUUFBRSxJQUFGLEVBQVFzQixPQUFSLENBQWdCLG1CQUFoQjtBQUNEO0FBQ0YsR0FQRDs7QUFTQTtBQUNBdEIsSUFBRTRFLFFBQUYsRUFBWTJJLEVBQVosQ0FBZSxrQkFBZixFQUFtQyxpQkFBbkMsRUFBc0QsVUFBU3JKLENBQVQsRUFBVztBQUMvREEsTUFBRWlULGVBQUY7QUFDQSxRQUFJakcsWUFBWWxSLEVBQUUsSUFBRixFQUFRcUIsSUFBUixDQUFhLFVBQWIsQ0FBaEI7O0FBRUEsUUFBRzZQLGNBQWMsRUFBakIsRUFBb0I7QUFDbEJoUixpQkFBVzhRLE1BQVgsQ0FBa0JLLFVBQWxCLENBQTZCclIsRUFBRSxJQUFGLENBQTdCLEVBQXNDa1IsU0FBdEMsRUFBaUQsWUFBVztBQUMxRGxSLFVBQUUsSUFBRixFQUFRc0IsT0FBUixDQUFnQixXQUFoQjtBQUNELE9BRkQ7QUFHRCxLQUpELE1BSUs7QUFDSHRCLFFBQUUsSUFBRixFQUFRb1gsT0FBUixHQUFrQjlWLE9BQWxCLENBQTBCLFdBQTFCO0FBQ0Q7QUFDRixHQVhEOztBQWFBdEIsSUFBRTRFLFFBQUYsRUFBWTJJLEVBQVosQ0FBZSxrQ0FBZixFQUFtRCxxQkFBbkQsRUFBMEUsWUFBVztBQUNuRixRQUFJc0MsS0FBSzdQLEVBQUUsSUFBRixFQUFRcUIsSUFBUixDQUFhLGNBQWIsQ0FBVDtBQUNBckIsWUFBTTZQLEVBQU4sRUFBWTNLLGNBQVosQ0FBMkIsbUJBQTNCLEVBQWdELENBQUNsRixFQUFFLElBQUYsQ0FBRCxDQUFoRDtBQUNELEdBSEQ7O0FBS0E7Ozs7O0FBS0FBLElBQUUwRyxNQUFGLEVBQVU2RyxFQUFWLENBQWEsTUFBYixFQUFxQixZQUFNO0FBQ3pCOEo7QUFDRCxHQUZEOztBQUlBLFdBQVNBLGNBQVQsR0FBMEI7QUFDeEJDO0FBQ0FDO0FBQ0FDO0FBQ0FDO0FBQ0FDO0FBQ0Q7O0FBRUQ7QUFDQSxXQUFTQSxlQUFULENBQXlCM1csVUFBekIsRUFBcUM7QUFDbkMsUUFBSTRXLFlBQVkzWCxFQUFFLGlCQUFGLENBQWhCO0FBQUEsUUFDSTRYLFlBQVksQ0FBQyxVQUFELEVBQWEsU0FBYixFQUF3QixRQUF4QixDQURoQjs7QUFHQSxRQUFHN1csVUFBSCxFQUFjO0FBQ1osVUFBRyxPQUFPQSxVQUFQLEtBQXNCLFFBQXpCLEVBQWtDO0FBQ2hDNlcsa0JBQVVyVyxJQUFWLENBQWVSLFVBQWY7QUFDRCxPQUZELE1BRU0sSUFBRyxRQUFPQSxVQUFQLHlDQUFPQSxVQUFQLE9BQXNCLFFBQXRCLElBQWtDLE9BQU9BLFdBQVcsQ0FBWCxDQUFQLEtBQXlCLFFBQTlELEVBQXVFO0FBQzNFNlcsa0JBQVV4UCxNQUFWLENBQWlCckgsVUFBakI7QUFDRCxPQUZLLE1BRUQ7QUFDSDhCLGdCQUFRQyxLQUFSLENBQWMsOEJBQWQ7QUFDRDtBQUNGO0FBQ0QsUUFBRzZVLFVBQVU1VSxNQUFiLEVBQW9CO0FBQ2xCLFVBQUk4VSxZQUFZRCxVQUFVeFQsR0FBVixDQUFjLFVBQUMzRCxJQUFELEVBQVU7QUFDdEMsK0JBQXFCQSxJQUFyQjtBQUNELE9BRmUsRUFFYnFYLElBRmEsQ0FFUixHQUZRLENBQWhCOztBQUlBOVgsUUFBRTBHLE1BQUYsRUFBVWtILEdBQVYsQ0FBY2lLLFNBQWQsRUFBeUJ0SyxFQUF6QixDQUE0QnNLLFNBQTVCLEVBQXVDLFVBQVMzVCxDQUFULEVBQVk2VCxRQUFaLEVBQXFCO0FBQzFELFlBQUl2WCxTQUFTMEQsRUFBRWxCLFNBQUYsQ0FBWWlCLEtBQVosQ0FBa0IsR0FBbEIsRUFBdUIsQ0FBdkIsQ0FBYjtBQUNBLFlBQUlsQyxVQUFVL0IsYUFBV1EsTUFBWCxRQUFzQndYLEdBQXRCLHNCQUE2Q0QsUUFBN0MsUUFBZDs7QUFFQWhXLGdCQUFRRSxJQUFSLENBQWEsWUFBVTtBQUNyQixjQUFJRyxRQUFRcEMsRUFBRSxJQUFGLENBQVo7O0FBRUFvQyxnQkFBTThDLGNBQU4sQ0FBcUIsa0JBQXJCLEVBQXlDLENBQUM5QyxLQUFELENBQXpDO0FBQ0QsU0FKRDtBQUtELE9BVEQ7QUFVRDtBQUNGOztBQUVELFdBQVNtVixjQUFULENBQXdCVSxRQUF4QixFQUFpQztBQUMvQixRQUFJMVMsY0FBSjtBQUFBLFFBQ0kyUyxTQUFTbFksRUFBRSxlQUFGLENBRGI7QUFFQSxRQUFHa1ksT0FBT25WLE1BQVYsRUFBaUI7QUFDZi9DLFFBQUUwRyxNQUFGLEVBQVVrSCxHQUFWLENBQWMsbUJBQWQsRUFDQ0wsRUFERCxDQUNJLG1CQURKLEVBQ3lCLFVBQVNySixDQUFULEVBQVk7QUFDbkMsWUFBSXFCLEtBQUosRUFBVztBQUFFbUMsdUJBQWFuQyxLQUFiO0FBQXNCOztBQUVuQ0EsZ0JBQVFOLFdBQVcsWUFBVTs7QUFFM0IsY0FBRyxDQUFDK1IsZ0JBQUosRUFBcUI7QUFBQztBQUNwQmtCLG1CQUFPalcsSUFBUCxDQUFZLFlBQVU7QUFDcEJqQyxnQkFBRSxJQUFGLEVBQVFrRixjQUFSLENBQXVCLHFCQUF2QjtBQUNELGFBRkQ7QUFHRDtBQUNEO0FBQ0FnVCxpQkFBTzNYLElBQVAsQ0FBWSxhQUFaLEVBQTJCLFFBQTNCO0FBQ0QsU0FUTyxFQVNMMFgsWUFBWSxFQVRQLENBQVIsQ0FIbUMsQ0FZaEI7QUFDcEIsT0FkRDtBQWVEO0FBQ0Y7O0FBRUQsV0FBU1QsY0FBVCxDQUF3QlMsUUFBeEIsRUFBaUM7QUFDL0IsUUFBSTFTLGNBQUo7QUFBQSxRQUNJMlMsU0FBU2xZLEVBQUUsZUFBRixDQURiO0FBRUEsUUFBR2tZLE9BQU9uVixNQUFWLEVBQWlCO0FBQ2YvQyxRQUFFMEcsTUFBRixFQUFVa0gsR0FBVixDQUFjLG1CQUFkLEVBQ0NMLEVBREQsQ0FDSSxtQkFESixFQUN5QixVQUFTckosQ0FBVCxFQUFXO0FBQ2xDLFlBQUdxQixLQUFILEVBQVM7QUFBRW1DLHVCQUFhbkMsS0FBYjtBQUFzQjs7QUFFakNBLGdCQUFRTixXQUFXLFlBQVU7O0FBRTNCLGNBQUcsQ0FBQytSLGdCQUFKLEVBQXFCO0FBQUM7QUFDcEJrQixtQkFBT2pXLElBQVAsQ0FBWSxZQUFVO0FBQ3BCakMsZ0JBQUUsSUFBRixFQUFRa0YsY0FBUixDQUF1QixxQkFBdkI7QUFDRCxhQUZEO0FBR0Q7QUFDRDtBQUNBZ1QsaUJBQU8zWCxJQUFQLENBQVksYUFBWixFQUEyQixRQUEzQjtBQUNELFNBVE8sRUFTTDBYLFlBQVksRUFUUCxDQUFSLENBSGtDLENBWWY7QUFDcEIsT0FkRDtBQWVEO0FBQ0Y7O0FBRUQsV0FBU1IsY0FBVCxDQUF3QlEsUUFBeEIsRUFBa0M7QUFDOUIsUUFBSUMsU0FBU2xZLEVBQUUsZUFBRixDQUFiO0FBQ0EsUUFBSWtZLE9BQU9uVixNQUFQLElBQWlCaVUsZ0JBQXJCLEVBQXNDO0FBQ3ZDO0FBQ0c7QUFDSGtCLGFBQU9qVyxJQUFQLENBQVksWUFBWTtBQUN0QmpDLFVBQUUsSUFBRixFQUFRa0YsY0FBUixDQUF1QixxQkFBdkI7QUFDRCxPQUZEO0FBR0U7QUFDSDs7QUFFRixXQUFTb1MsY0FBVCxHQUEwQjtBQUN4QixRQUFHLENBQUNOLGdCQUFKLEVBQXFCO0FBQUUsYUFBTyxLQUFQO0FBQWU7QUFDdEMsUUFBSW1CLFFBQVF2VCxTQUFTd1QsZ0JBQVQsQ0FBMEIsNkNBQTFCLENBQVo7O0FBRUE7QUFDQSxRQUFJQyw0QkFBNEIsU0FBNUJBLHlCQUE0QixDQUFVQyxtQkFBVixFQUErQjtBQUMzRCxVQUFJQyxVQUFVdlksRUFBRXNZLG9CQUFvQixDQUFwQixFQUF1QjlLLE1BQXpCLENBQWQ7O0FBRUg7QUFDRyxjQUFROEssb0JBQW9CLENBQXBCLEVBQXVCblcsSUFBL0I7O0FBRUUsYUFBSyxZQUFMO0FBQ0UsY0FBSW9XLFFBQVFoWSxJQUFSLENBQWEsYUFBYixNQUFnQyxRQUFoQyxJQUE0QytYLG9CQUFvQixDQUFwQixFQUF1QkUsYUFBdkIsS0FBeUMsYUFBekYsRUFBd0c7QUFDN0dELG9CQUFRclQsY0FBUixDQUF1QixxQkFBdkIsRUFBOEMsQ0FBQ3FULE9BQUQsRUFBVTdSLE9BQU84RCxXQUFqQixDQUE5QztBQUNBO0FBQ0QsY0FBSStOLFFBQVFoWSxJQUFSLENBQWEsYUFBYixNQUFnQyxRQUFoQyxJQUE0QytYLG9CQUFvQixDQUFwQixFQUF1QkUsYUFBdkIsS0FBeUMsYUFBekYsRUFBd0c7QUFDdkdELG9CQUFRclQsY0FBUixDQUF1QixxQkFBdkIsRUFBOEMsQ0FBQ3FULE9BQUQsQ0FBOUM7QUFDQztBQUNGLGNBQUlELG9CQUFvQixDQUFwQixFQUF1QkUsYUFBdkIsS0FBeUMsT0FBN0MsRUFBc0Q7QUFDckRELG9CQUFRRSxPQUFSLENBQWdCLGVBQWhCLEVBQWlDbFksSUFBakMsQ0FBc0MsYUFBdEMsRUFBb0QsUUFBcEQ7QUFDQWdZLG9CQUFRRSxPQUFSLENBQWdCLGVBQWhCLEVBQWlDdlQsY0FBakMsQ0FBZ0QscUJBQWhELEVBQXVFLENBQUNxVCxRQUFRRSxPQUFSLENBQWdCLGVBQWhCLENBQUQsQ0FBdkU7QUFDQTtBQUNEOztBQUVJLGFBQUssV0FBTDtBQUNKRixrQkFBUUUsT0FBUixDQUFnQixlQUFoQixFQUFpQ2xZLElBQWpDLENBQXNDLGFBQXRDLEVBQW9ELFFBQXBEO0FBQ0FnWSxrQkFBUUUsT0FBUixDQUFnQixlQUFoQixFQUFpQ3ZULGNBQWpDLENBQWdELHFCQUFoRCxFQUF1RSxDQUFDcVQsUUFBUUUsT0FBUixDQUFnQixlQUFoQixDQUFELENBQXZFO0FBQ007O0FBRUY7QUFDRSxpQkFBTyxLQUFQO0FBQ0Y7QUF0QkY7QUF3QkQsS0E1Qkg7O0FBOEJFLFFBQUlOLE1BQU1wVixNQUFWLEVBQWtCO0FBQ2hCO0FBQ0EsV0FBSyxJQUFJVSxJQUFJLENBQWIsRUFBZ0JBLEtBQUswVSxNQUFNcFYsTUFBTixHQUFlLENBQXBDLEVBQXVDVSxHQUF2QyxFQUE0QztBQUMxQyxZQUFJaVYsa0JBQWtCLElBQUkxQixnQkFBSixDQUFxQnFCLHlCQUFyQixDQUF0QjtBQUNBSyx3QkFBZ0JDLE9BQWhCLENBQXdCUixNQUFNMVUsQ0FBTixDQUF4QixFQUFrQyxFQUFFbVYsWUFBWSxJQUFkLEVBQW9CQyxXQUFXLElBQS9CLEVBQXFDQyxlQUFlLEtBQXBELEVBQTJEQyxTQUFTLElBQXBFLEVBQTBFQyxpQkFBaUIsQ0FBQyxhQUFELEVBQWdCLE9BQWhCLENBQTNGLEVBQWxDO0FBQ0Q7QUFDRjtBQUNGOztBQUVIOztBQUVBO0FBQ0E7QUFDQTlZLGFBQVcrWSxRQUFYLEdBQXNCNUIsY0FBdEI7QUFDQTtBQUNBO0FBRUMsQ0EzTkEsQ0EyTkN6TyxNQTNORCxDQUFEOztBQTZOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQ2hRQTs7Ozs7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViOzs7Ozs7OztBQUZhLE1BVVBrWixhQVZPO0FBV1g7Ozs7Ozs7QUFPQSwyQkFBWWpRLE9BQVosRUFBcUJrSyxPQUFyQixFQUE4QjtBQUFBOztBQUM1QixXQUFLL1IsUUFBTCxHQUFnQjZILE9BQWhCO0FBQ0EsV0FBS2tLLE9BQUwsR0FBZW5ULEVBQUV5TSxNQUFGLENBQVMsRUFBVCxFQUFheU0sY0FBY0MsUUFBM0IsRUFBcUMsS0FBSy9YLFFBQUwsQ0FBY0MsSUFBZCxFQUFyQyxFQUEyRDhSLE9BQTNELENBQWY7O0FBRUFqVCxpQkFBV3FTLElBQVgsQ0FBZ0JDLE9BQWhCLENBQXdCLEtBQUtwUixRQUE3QixFQUF1QyxXQUF2Qzs7QUFFQSxXQUFLYyxLQUFMOztBQUVBaEMsaUJBQVdZLGNBQVgsQ0FBMEIsSUFBMUIsRUFBZ0MsZUFBaEM7QUFDQVosaUJBQVdtTCxRQUFYLENBQW9CMkIsUUFBcEIsQ0FBNkIsZUFBN0IsRUFBOEM7QUFDNUMsaUJBQVMsUUFEbUM7QUFFNUMsaUJBQVMsUUFGbUM7QUFHNUMsdUJBQWUsTUFINkI7QUFJNUMsb0JBQVksSUFKZ0M7QUFLNUMsc0JBQWMsTUFMOEI7QUFNNUMsc0JBQWMsT0FOOEI7QUFPNUMsa0JBQVU7QUFQa0MsT0FBOUM7QUFTRDs7QUFJRDs7Ozs7O0FBeENXO0FBQUE7QUFBQSw4QkE0Q0g7QUFDTixhQUFLNUwsUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixnQkFBbkIsRUFBcUNxVSxHQUFyQyxDQUF5QyxZQUF6QyxFQUF1RG9CLE9BQXZELENBQStELENBQS9ELEVBRE0sQ0FDNEQ7QUFDbEUsYUFBS2hZLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQjtBQUNqQixrQkFBUSxNQURTO0FBRWpCLGtDQUF3QixLQUFLNFMsT0FBTCxDQUFha0c7QUFGcEIsU0FBbkI7O0FBS0EsYUFBS0MsVUFBTCxHQUFrQixLQUFLbFksUUFBTCxDQUFjdUMsSUFBZCxDQUFtQiw4QkFBbkIsQ0FBbEI7QUFDQSxhQUFLMlYsVUFBTCxDQUFnQnJYLElBQWhCLENBQXFCLFlBQVU7QUFDN0IsY0FBSXNYLFNBQVMsS0FBSzFKLEVBQUwsSUFBVzNQLFdBQVdpQixXQUFYLENBQXVCLENBQXZCLEVBQTBCLGVBQTFCLENBQXhCO0FBQUEsY0FDSXVDLFFBQVExRCxFQUFFLElBQUYsQ0FEWjtBQUFBLGNBRUkrUyxPQUFPclAsTUFBTXNQLFFBQU4sQ0FBZSxnQkFBZixDQUZYO0FBQUEsY0FHSXdHLFFBQVF6RyxLQUFLLENBQUwsRUFBUWxELEVBQVIsSUFBYzNQLFdBQVdpQixXQUFYLENBQXVCLENBQXZCLEVBQTBCLFVBQTFCLENBSDFCO0FBQUEsY0FJSXNZLFdBQVcxRyxLQUFLMkcsUUFBTCxDQUFjLFdBQWQsQ0FKZjtBQUtBaFcsZ0JBQU1uRCxJQUFOLENBQVc7QUFDVCw2QkFBaUJpWixLQURSO0FBRVQsNkJBQWlCQyxRQUZSO0FBR1Qsb0JBQVEsVUFIQztBQUlULGtCQUFNRjtBQUpHLFdBQVg7QUFNQXhHLGVBQUt4UyxJQUFMLENBQVU7QUFDUiwrQkFBbUJnWixNQURYO0FBRVIsMkJBQWUsQ0FBQ0UsUUFGUjtBQUdSLG9CQUFRLE1BSEE7QUFJUixrQkFBTUQ7QUFKRSxXQUFWO0FBTUQsU0FsQkQ7QUFtQkEsWUFBSUcsWUFBWSxLQUFLdlksUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixZQUFuQixDQUFoQjtBQUNBLFlBQUdnVyxVQUFVNVcsTUFBYixFQUFvQjtBQUNsQixjQUFJWCxRQUFRLElBQVo7QUFDQXVYLG9CQUFVMVgsSUFBVixDQUFlLFlBQVU7QUFDdkJHLGtCQUFNd1gsSUFBTixDQUFXNVosRUFBRSxJQUFGLENBQVg7QUFDRCxXQUZEO0FBR0Q7QUFDRCxhQUFLNlosT0FBTDtBQUNEOztBQUVEOzs7OztBQWpGVztBQUFBO0FBQUEsZ0NBcUZEO0FBQ1IsWUFBSXpYLFFBQVEsSUFBWjs7QUFFQSxhQUFLaEIsUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixJQUFuQixFQUF5QjFCLElBQXpCLENBQThCLFlBQVc7QUFDdkMsY0FBSTZYLFdBQVc5WixFQUFFLElBQUYsRUFBUWdULFFBQVIsQ0FBaUIsZ0JBQWpCLENBQWY7O0FBRUEsY0FBSThHLFNBQVMvVyxNQUFiLEVBQXFCO0FBQ25CL0MsY0FBRSxJQUFGLEVBQVFnVCxRQUFSLENBQWlCLEdBQWpCLEVBQXNCcEYsR0FBdEIsQ0FBMEIsd0JBQTFCLEVBQW9ETCxFQUFwRCxDQUF1RCx3QkFBdkQsRUFBaUYsVUFBU3JKLENBQVQsRUFBWTtBQUMzRkEsZ0JBQUV1SixjQUFGOztBQUVBckwsb0JBQU0yWCxNQUFOLENBQWFELFFBQWI7QUFDRCxhQUpEO0FBS0Q7QUFDRixTQVZELEVBVUd2TSxFQVZILENBVU0sMEJBVk4sRUFVa0MsVUFBU3JKLENBQVQsRUFBVztBQUMzQyxjQUFJOUMsV0FBV3BCLEVBQUUsSUFBRixDQUFmO0FBQUEsY0FDSWdhLFlBQVk1WSxTQUFTOEgsTUFBVCxDQUFnQixJQUFoQixFQUFzQjhKLFFBQXRCLENBQStCLElBQS9CLENBRGhCO0FBQUEsY0FFSWlILFlBRko7QUFBQSxjQUdJQyxZQUhKO0FBQUEsY0FJSTNCLFVBQVVuWCxTQUFTNFIsUUFBVCxDQUFrQixnQkFBbEIsQ0FKZDs7QUFNQWdILG9CQUFVL1gsSUFBVixDQUFlLFVBQVN3QixDQUFULEVBQVk7QUFDekIsZ0JBQUl6RCxFQUFFLElBQUYsRUFBUStNLEVBQVIsQ0FBVzNMLFFBQVgsQ0FBSixFQUEwQjtBQUN4QjZZLDZCQUFlRCxVQUFVM00sRUFBVixDQUFhcEssS0FBS3dFLEdBQUwsQ0FBUyxDQUFULEVBQVloRSxJQUFFLENBQWQsQ0FBYixFQUErQkUsSUFBL0IsQ0FBb0MsR0FBcEMsRUFBeUN1UyxLQUF6QyxFQUFmO0FBQ0FnRSw2QkFBZUYsVUFBVTNNLEVBQVYsQ0FBYXBLLEtBQUtrWCxHQUFMLENBQVMxVyxJQUFFLENBQVgsRUFBY3VXLFVBQVVqWCxNQUFWLEdBQWlCLENBQS9CLENBQWIsRUFBZ0RZLElBQWhELENBQXFELEdBQXJELEVBQTBEdVMsS0FBMUQsRUFBZjs7QUFFQSxrQkFBSWxXLEVBQUUsSUFBRixFQUFRZ1QsUUFBUixDQUFpQix3QkFBakIsRUFBMkNqUSxNQUEvQyxFQUF1RDtBQUFFO0FBQ3ZEbVgsK0JBQWU5WSxTQUFTdUMsSUFBVCxDQUFjLGdCQUFkLEVBQWdDQSxJQUFoQyxDQUFxQyxHQUFyQyxFQUEwQ3VTLEtBQTFDLEVBQWY7QUFDRDtBQUNELGtCQUFJbFcsRUFBRSxJQUFGLEVBQVErTSxFQUFSLENBQVcsY0FBWCxDQUFKLEVBQWdDO0FBQUU7QUFDaENrTiwrQkFBZTdZLFNBQVNnWixPQUFULENBQWlCLElBQWpCLEVBQXVCbEUsS0FBdkIsR0FBK0J2UyxJQUEvQixDQUFvQyxHQUFwQyxFQUF5Q3VTLEtBQXpDLEVBQWY7QUFDRCxlQUZELE1BRU8sSUFBSStELGFBQWFHLE9BQWIsQ0FBcUIsSUFBckIsRUFBMkJsRSxLQUEzQixHQUFtQ2xELFFBQW5DLENBQTRDLHdCQUE1QyxFQUFzRWpRLE1BQTFFLEVBQWtGO0FBQUU7QUFDekZrWCwrQkFBZUEsYUFBYUcsT0FBYixDQUFxQixJQUFyQixFQUEyQnpXLElBQTNCLENBQWdDLGVBQWhDLEVBQWlEQSxJQUFqRCxDQUFzRCxHQUF0RCxFQUEyRHVTLEtBQTNELEVBQWY7QUFDRDtBQUNELGtCQUFJbFcsRUFBRSxJQUFGLEVBQVErTSxFQUFSLENBQVcsYUFBWCxDQUFKLEVBQStCO0FBQUU7QUFDL0JtTiwrQkFBZTlZLFNBQVNnWixPQUFULENBQWlCLElBQWpCLEVBQXVCbEUsS0FBdkIsR0FBK0JtRSxJQUEvQixDQUFvQyxJQUFwQyxFQUEwQzFXLElBQTFDLENBQStDLEdBQS9DLEVBQW9EdVMsS0FBcEQsRUFBZjtBQUNEOztBQUVEO0FBQ0Q7QUFDRixXQW5CRDs7QUFxQkFoVyxxQkFBV21MLFFBQVgsQ0FBb0JhLFNBQXBCLENBQThCaEksQ0FBOUIsRUFBaUMsZUFBakMsRUFBa0Q7QUFDaERvVyxrQkFBTSxnQkFBVztBQUNmLGtCQUFJL0IsUUFBUXhMLEVBQVIsQ0FBVyxTQUFYLENBQUosRUFBMkI7QUFDekIzSyxzQkFBTXdYLElBQU4sQ0FBV3JCLE9BQVg7QUFDQUEsd0JBQVE1VSxJQUFSLENBQWEsSUFBYixFQUFtQnVTLEtBQW5CLEdBQTJCdlMsSUFBM0IsQ0FBZ0MsR0FBaEMsRUFBcUN1UyxLQUFyQyxHQUE2Q3hJLEtBQTdDO0FBQ0Q7QUFDRixhQU4rQztBQU9oRDZNLG1CQUFPLGlCQUFXO0FBQ2hCLGtCQUFJaEMsUUFBUXhWLE1BQVIsSUFBa0IsQ0FBQ3dWLFFBQVF4TCxFQUFSLENBQVcsU0FBWCxDQUF2QixFQUE4QztBQUFFO0FBQzlDM0ssc0JBQU1vWSxFQUFOLENBQVNqQyxPQUFUO0FBQ0QsZUFGRCxNQUVPLElBQUluWCxTQUFTOEgsTUFBVCxDQUFnQixnQkFBaEIsRUFBa0NuRyxNQUF0QyxFQUE4QztBQUFFO0FBQ3JEWCxzQkFBTW9ZLEVBQU4sQ0FBU3BaLFNBQVM4SCxNQUFULENBQWdCLGdCQUFoQixDQUFUO0FBQ0E5SCx5QkFBU2daLE9BQVQsQ0FBaUIsSUFBakIsRUFBdUJsRSxLQUF2QixHQUErQnZTLElBQS9CLENBQW9DLEdBQXBDLEVBQXlDdVMsS0FBekMsR0FBaUR4SSxLQUFqRDtBQUNEO0FBQ0YsYUFkK0M7QUFlaEQ4TSxnQkFBSSxjQUFXO0FBQ2JQLDJCQUFhdk0sS0FBYjtBQUNBLHFCQUFPLElBQVA7QUFDRCxhQWxCK0M7QUFtQmhEa00sa0JBQU0sZ0JBQVc7QUFDZk0sMkJBQWF4TSxLQUFiO0FBQ0EscUJBQU8sSUFBUDtBQUNELGFBdEIrQztBQXVCaERxTSxvQkFBUSxrQkFBVztBQUNqQixrQkFBSTNZLFNBQVM0UixRQUFULENBQWtCLGdCQUFsQixFQUFvQ2pRLE1BQXhDLEVBQWdEO0FBQzlDWCxzQkFBTTJYLE1BQU4sQ0FBYTNZLFNBQVM0UixRQUFULENBQWtCLGdCQUFsQixDQUFiO0FBQ0Q7QUFDRixhQTNCK0M7QUE0QmhEeUgsc0JBQVUsb0JBQVc7QUFDbkJyWSxvQkFBTXNZLE9BQU47QUFDRCxhQTlCK0M7QUErQmhEL04scUJBQVMsaUJBQVNjLGNBQVQsRUFBeUI7QUFDaEMsa0JBQUlBLGNBQUosRUFBb0I7QUFDbEJ2SixrQkFBRXVKLGNBQUY7QUFDRDtBQUNEdkosZ0JBQUV5Vyx3QkFBRjtBQUNEO0FBcEMrQyxXQUFsRDtBQXNDRCxTQTVFRCxFQUhRLENBK0VMO0FBQ0o7O0FBRUQ7Ozs7O0FBdktXO0FBQUE7QUFBQSxnQ0EyS0Q7QUFDUixhQUFLSCxFQUFMLENBQVEsS0FBS3BaLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsZ0JBQW5CLENBQVI7QUFDRDs7QUFFRDs7Ozs7QUEvS1c7QUFBQTtBQUFBLGdDQW1MRDtBQUNSLGFBQUtpVyxJQUFMLENBQVUsS0FBS3hZLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsZ0JBQW5CLENBQVY7QUFDRDs7QUFFRDs7Ozs7O0FBdkxXO0FBQUE7QUFBQSw2QkE0TEo0VSxPQTVMSSxFQTRMSTtBQUNiLFlBQUcsQ0FBQ0EsUUFBUXhMLEVBQVIsQ0FBVyxXQUFYLENBQUosRUFBNkI7QUFDM0IsY0FBSSxDQUFDd0wsUUFBUXhMLEVBQVIsQ0FBVyxTQUFYLENBQUwsRUFBNEI7QUFDMUIsaUJBQUt5TixFQUFMLENBQVFqQyxPQUFSO0FBQ0QsV0FGRCxNQUdLO0FBQ0gsaUJBQUtxQixJQUFMLENBQVVyQixPQUFWO0FBQ0Q7QUFDRjtBQUNGOztBQUVEOzs7Ozs7QUF2TVc7QUFBQTtBQUFBLDJCQTRNTkEsT0E1TU0sRUE0TUc7QUFDWixZQUFJblcsUUFBUSxJQUFaOztBQUVBLFlBQUcsQ0FBQyxLQUFLK1EsT0FBTCxDQUFha0csU0FBakIsRUFBNEI7QUFDMUIsZUFBS21CLEVBQUwsQ0FBUSxLQUFLcFosUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixZQUFuQixFQUFpQ3FVLEdBQWpDLENBQXFDTyxRQUFRcUMsWUFBUixDQUFxQixLQUFLeFosUUFBMUIsRUFBb0N5WixHQUFwQyxDQUF3Q3RDLE9BQXhDLENBQXJDLENBQVI7QUFDRDs7QUFFREEsZ0JBQVF2RyxRQUFSLENBQWlCLFdBQWpCLEVBQThCelIsSUFBOUIsQ0FBbUMsRUFBQyxlQUFlLEtBQWhCLEVBQW5DLEVBQ0cySSxNQURILENBQ1UsOEJBRFYsRUFDMEMzSSxJQUQxQyxDQUMrQyxFQUFDLGlCQUFpQixJQUFsQixFQUQvQzs7QUFHRTtBQUNFZ1ksZ0JBQVF1QyxTQUFSLENBQWtCMVksTUFBTStRLE9BQU4sQ0FBYzRILFVBQWhDLEVBQTRDLFlBQVk7QUFDdEQ7Ozs7QUFJQTNZLGdCQUFNaEIsUUFBTixDQUFlRSxPQUFmLENBQXVCLHVCQUF2QixFQUFnRCxDQUFDaVgsT0FBRCxDQUFoRDtBQUNELFNBTkQ7QUFPRjtBQUNIOztBQUVEOzs7Ozs7QUFqT1c7QUFBQTtBQUFBLHlCQXNPUkEsT0F0T1EsRUFzT0M7QUFDVixZQUFJblcsUUFBUSxJQUFaO0FBQ0E7QUFDRW1XLGdCQUFRYSxPQUFSLENBQWdCaFgsTUFBTStRLE9BQU4sQ0FBYzRILFVBQTlCLEVBQTBDLFlBQVk7QUFDcEQ7Ozs7QUFJQTNZLGdCQUFNaEIsUUFBTixDQUFlRSxPQUFmLENBQXVCLHFCQUF2QixFQUE4QyxDQUFDaVgsT0FBRCxDQUE5QztBQUNELFNBTkQ7QUFPRjs7QUFFQSxZQUFJeUMsU0FBU3pDLFFBQVE1VSxJQUFSLENBQWEsZ0JBQWIsRUFBK0J5VixPQUEvQixDQUF1QyxDQUF2QyxFQUEwQ3hWLE9BQTFDLEdBQW9EckQsSUFBcEQsQ0FBeUQsYUFBekQsRUFBd0UsSUFBeEUsQ0FBYjs7QUFFQXlhLGVBQU85UixNQUFQLENBQWMsOEJBQWQsRUFBOEMzSSxJQUE5QyxDQUFtRCxlQUFuRCxFQUFvRSxLQUFwRTtBQUNEOztBQUVEOzs7OztBQXZQVztBQUFBO0FBQUEsZ0NBMlBEO0FBQ1IsYUFBS2EsUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixnQkFBbkIsRUFBcUNtWCxTQUFyQyxDQUErQyxDQUEvQyxFQUFrRHRNLEdBQWxELENBQXNELFNBQXRELEVBQWlFLEVBQWpFO0FBQ0EsYUFBS3BOLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsR0FBbkIsRUFBd0JpSyxHQUF4QixDQUE0Qix3QkFBNUI7O0FBRUExTixtQkFBV3FTLElBQVgsQ0FBZ0JVLElBQWhCLENBQXFCLEtBQUs3UixRQUExQixFQUFvQyxXQUFwQztBQUNBbEIsbUJBQVdzQixnQkFBWCxDQUE0QixJQUE1QjtBQUNEO0FBalFVOztBQUFBO0FBQUE7O0FBb1FiMFgsZ0JBQWNDLFFBQWQsR0FBeUI7QUFDdkI7Ozs7O0FBS0E0QixnQkFBWSxHQU5XO0FBT3ZCOzs7OztBQUtBMUIsZUFBVztBQVpZLEdBQXpCOztBQWVBO0FBQ0FuWixhQUFXTSxNQUFYLENBQWtCMFksYUFBbEIsRUFBaUMsZUFBakM7QUFFQyxDQXRSQSxDQXNSQ3RRLE1BdFJELENBQUQ7Q0NGQTs7Ozs7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViOzs7Ozs7OztBQUZhLE1BVVBpYixTQVZPO0FBV1g7Ozs7OztBQU1BLHVCQUFZaFMsT0FBWixFQUFxQmtLLE9BQXJCLEVBQThCO0FBQUE7O0FBQzVCLFdBQUsvUixRQUFMLEdBQWdCNkgsT0FBaEI7QUFDQSxXQUFLa0ssT0FBTCxHQUFlblQsRUFBRXlNLE1BQUYsQ0FBUyxFQUFULEVBQWF3TyxVQUFVOUIsUUFBdkIsRUFBaUMsS0FBSy9YLFFBQUwsQ0FBY0MsSUFBZCxFQUFqQyxFQUF1RDhSLE9BQXZELENBQWY7O0FBRUFqVCxpQkFBV3FTLElBQVgsQ0FBZ0JDLE9BQWhCLENBQXdCLEtBQUtwUixRQUE3QixFQUF1QyxXQUF2Qzs7QUFFQSxXQUFLYyxLQUFMOztBQUVBaEMsaUJBQVdZLGNBQVgsQ0FBMEIsSUFBMUIsRUFBZ0MsV0FBaEM7QUFDQVosaUJBQVdtTCxRQUFYLENBQW9CMkIsUUFBcEIsQ0FBNkIsV0FBN0IsRUFBMEM7QUFDeEMsaUJBQVMsTUFEK0I7QUFFeEMsaUJBQVMsTUFGK0I7QUFHeEMsdUJBQWUsTUFIeUI7QUFJeEMsb0JBQVksSUFKNEI7QUFLeEMsc0JBQWMsTUFMMEI7QUFNeEMsc0JBQWMsVUFOMEI7QUFPeEMsa0JBQVUsT0FQOEI7QUFReEMsZUFBTyxNQVJpQztBQVN4QyxxQkFBYTtBQVQyQixPQUExQztBQVdEOztBQUVEOzs7Ozs7QUF2Q1c7QUFBQTtBQUFBLDhCQTJDSDtBQUNOLGFBQUtrTyxlQUFMLEdBQXVCLEtBQUs5WixRQUFMLENBQWN1QyxJQUFkLENBQW1CLGdDQUFuQixFQUFxRHFQLFFBQXJELENBQThELEdBQTlELENBQXZCO0FBQ0EsYUFBS21JLFNBQUwsR0FBaUIsS0FBS0QsZUFBTCxDQUFxQmhTLE1BQXJCLENBQTRCLElBQTVCLEVBQWtDOEosUUFBbEMsQ0FBMkMsZ0JBQTNDLENBQWpCO0FBQ0EsYUFBS29JLFVBQUwsR0FBa0IsS0FBS2hhLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsSUFBbkIsRUFBeUJxVSxHQUF6QixDQUE2QixvQkFBN0IsRUFBbUR6WCxJQUFuRCxDQUF3RCxNQUF4RCxFQUFnRSxVQUFoRSxFQUE0RW9ELElBQTVFLENBQWlGLEdBQWpGLENBQWxCO0FBQ0EsYUFBS3ZDLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixhQUFuQixFQUFtQyxLQUFLYSxRQUFMLENBQWNiLElBQWQsQ0FBbUIsZ0JBQW5CLEtBQXdDTCxXQUFXaUIsV0FBWCxDQUF1QixDQUF2QixFQUEwQixXQUExQixDQUEzRTs7QUFFQSxhQUFLa2EsWUFBTDtBQUNBLGFBQUtDLGVBQUw7O0FBRUEsYUFBS0MsZUFBTDtBQUNEOztBQUVEOzs7Ozs7OztBQXZEVztBQUFBO0FBQUEscUNBOERJO0FBQ2IsWUFBSW5aLFFBQVEsSUFBWjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQUs4WSxlQUFMLENBQXFCalosSUFBckIsQ0FBMEIsWUFBVTtBQUNsQyxjQUFJdVosUUFBUXhiLEVBQUUsSUFBRixDQUFaO0FBQ0EsY0FBSStTLE9BQU95SSxNQUFNdFMsTUFBTixFQUFYO0FBQ0EsY0FBRzlHLE1BQU0rUSxPQUFOLENBQWNzSSxVQUFqQixFQUE0QjtBQUMxQkQsa0JBQU1FLEtBQU4sR0FBY0MsU0FBZCxDQUF3QjVJLEtBQUtDLFFBQUwsQ0FBYyxnQkFBZCxDQUF4QixFQUF5RDRJLElBQXpELENBQThELHFHQUE5RDtBQUNEO0FBQ0RKLGdCQUFNbmEsSUFBTixDQUFXLFdBQVgsRUFBd0JtYSxNQUFNamIsSUFBTixDQUFXLE1BQVgsQ0FBeEIsRUFBNENvQixVQUE1QyxDQUF1RCxNQUF2RCxFQUErRHBCLElBQS9ELENBQW9FLFVBQXBFLEVBQWdGLENBQWhGO0FBQ0FpYixnQkFBTXhJLFFBQU4sQ0FBZSxnQkFBZixFQUNLelMsSUFETCxDQUNVO0FBQ0osMkJBQWUsSUFEWDtBQUVKLHdCQUFZLENBRlI7QUFHSixvQkFBUTtBQUhKLFdBRFY7QUFNQTZCLGdCQUFNeVgsT0FBTixDQUFjMkIsS0FBZDtBQUNELFNBZEQ7QUFlQSxhQUFLTCxTQUFMLENBQWVsWixJQUFmLENBQW9CLFlBQVU7QUFDNUIsY0FBSTRaLFFBQVE3YixFQUFFLElBQUYsQ0FBWjtBQUFBLGNBQ0k4YixRQUFRRCxNQUFNbFksSUFBTixDQUFXLG9CQUFYLENBRFo7QUFFQSxjQUFHLENBQUNtWSxNQUFNL1ksTUFBVixFQUFpQjtBQUNmLG9CQUFRWCxNQUFNK1EsT0FBTixDQUFjNEksa0JBQXRCO0FBQ0UsbUJBQUssUUFBTDtBQUNFRixzQkFBTUcsTUFBTixDQUFhNVosTUFBTStRLE9BQU4sQ0FBYzhJLFVBQTNCO0FBQ0E7QUFDRixtQkFBSyxLQUFMO0FBQ0VKLHNCQUFNSyxPQUFOLENBQWM5WixNQUFNK1EsT0FBTixDQUFjOEksVUFBNUI7QUFDQTtBQUNGO0FBQ0VwWix3QkFBUUMsS0FBUixDQUFjLDJDQUEyQ1YsTUFBTStRLE9BQU4sQ0FBYzRJLGtCQUF6RCxHQUE4RSxHQUE1RjtBQVJKO0FBVUQ7QUFDRDNaLGdCQUFNK1osS0FBTixDQUFZTixLQUFaO0FBQ0QsU0FoQkQ7O0FBa0JBLFlBQUcsQ0FBQyxLQUFLMUksT0FBTCxDQUFhaUosVUFBakIsRUFBNkI7QUFDM0IsZUFBS2pCLFNBQUwsQ0FBZW5KLFFBQWYsQ0FBd0Isa0NBQXhCO0FBQ0Q7O0FBRUQsWUFBRyxDQUFDLEtBQUs1USxRQUFMLENBQWM4SCxNQUFkLEdBQXVCd1EsUUFBdkIsQ0FBZ0MsY0FBaEMsQ0FBSixFQUFvRDtBQUNsRCxlQUFLMkMsUUFBTCxHQUFnQnJjLEVBQUUsS0FBS21ULE9BQUwsQ0FBYW1KLE9BQWYsRUFBd0J0SyxRQUF4QixDQUFpQyxjQUFqQyxDQUFoQjtBQUNBLGNBQUcsS0FBS21CLE9BQUwsQ0FBYW9KLGFBQWhCLEVBQStCLEtBQUtGLFFBQUwsQ0FBY3JLLFFBQWQsQ0FBdUIsZ0JBQXZCO0FBQy9CLGVBQUtxSyxRQUFMLEdBQWdCLEtBQUtqYixRQUFMLENBQWN3YSxJQUFkLENBQW1CLEtBQUtTLFFBQXhCLEVBQWtDblQsTUFBbEMsR0FBMkNzRixHQUEzQyxDQUErQyxLQUFLZ08sV0FBTCxFQUEvQyxDQUFoQjtBQUNEO0FBQ0Y7QUE3R1U7QUFBQTtBQUFBLGdDQStHRDtBQUNSLGFBQUtILFFBQUwsQ0FBYzdOLEdBQWQsQ0FBa0IsRUFBQyxhQUFhLE1BQWQsRUFBc0IsY0FBYyxNQUFwQyxFQUFsQjtBQUNBO0FBQ0EsYUFBSzZOLFFBQUwsQ0FBYzdOLEdBQWQsQ0FBa0IsS0FBS2dPLFdBQUwsRUFBbEI7QUFDRDs7QUFFRDs7Ozs7OztBQXJIVztBQUFBO0FBQUEsOEJBMkhIOVksS0EzSEcsRUEySEk7QUFDYixZQUFJdEIsUUFBUSxJQUFaOztBQUVBc0IsY0FBTWtLLEdBQU4sQ0FBVSxvQkFBVixFQUNDTCxFQURELENBQ0ksb0JBREosRUFDMEIsVUFBU3JKLENBQVQsRUFBVztBQUNuQyxjQUFHbEUsRUFBRWtFLEVBQUVzSixNQUFKLEVBQVlvTixZQUFaLENBQXlCLElBQXpCLEVBQStCLElBQS9CLEVBQXFDbEIsUUFBckMsQ0FBOEMsNkJBQTlDLENBQUgsRUFBZ0Y7QUFDOUV4VixjQUFFeVcsd0JBQUY7QUFDQXpXLGNBQUV1SixjQUFGO0FBQ0Q7O0FBRUQ7QUFDQTtBQUNBO0FBQ0FyTCxnQkFBTXFhLEtBQU4sQ0FBWS9ZLE1BQU13RixNQUFOLENBQWEsSUFBYixDQUFaOztBQUVBLGNBQUc5RyxNQUFNK1EsT0FBTixDQUFjdUosWUFBakIsRUFBOEI7QUFDNUIsZ0JBQUlDLFFBQVEzYyxFQUFFLE1BQUYsQ0FBWjtBQUNBMmMsa0JBQU0vTyxHQUFOLENBQVUsZUFBVixFQUEyQkwsRUFBM0IsQ0FBOEIsb0JBQTlCLEVBQW9ELFVBQVNySixDQUFULEVBQVc7QUFDN0Qsa0JBQUlBLEVBQUVzSixNQUFGLEtBQWFwTCxNQUFNaEIsUUFBTixDQUFlLENBQWYsQ0FBYixJQUFrQ3BCLEVBQUU0YyxRQUFGLENBQVd4YSxNQUFNaEIsUUFBTixDQUFlLENBQWYsQ0FBWCxFQUE4QjhDLEVBQUVzSixNQUFoQyxDQUF0QyxFQUErRTtBQUFFO0FBQVM7QUFDMUZ0SixnQkFBRXVKLGNBQUY7QUFDQXJMLG9CQUFNeWEsUUFBTjtBQUNBRixvQkFBTS9PLEdBQU4sQ0FBVSxlQUFWO0FBQ0QsYUFMRDtBQU1EO0FBQ0YsU0FyQkQ7QUFzQkQsYUFBS3hNLFFBQUwsQ0FBY21NLEVBQWQsQ0FBaUIscUJBQWpCLEVBQXdDLEtBQUt1UCxPQUFMLENBQWFoVixJQUFiLENBQWtCLElBQWxCLENBQXhDO0FBQ0E7O0FBRUQ7Ozs7OztBQXZKVztBQUFBO0FBQUEsd0NBNEpPO0FBQ2hCLFlBQUcsS0FBS3FMLE9BQUwsQ0FBYTRKLFNBQWhCLEVBQTBCO0FBQ3hCLGVBQUtDLFlBQUwsR0FBb0IsS0FBS0MsVUFBTCxDQUFnQm5WLElBQWhCLENBQXFCLElBQXJCLENBQXBCO0FBQ0EsZUFBSzFHLFFBQUwsQ0FBY21NLEVBQWQsQ0FBaUIseURBQWpCLEVBQTJFLEtBQUt5UCxZQUFoRjtBQUNEO0FBQ0Y7O0FBRUQ7Ozs7OztBQW5LVztBQUFBO0FBQUEsbUNBd0tFO0FBQ1gsWUFBSTVhLFFBQVEsSUFBWjtBQUNBLFlBQUk4YSxvQkFBb0I5YSxNQUFNK1EsT0FBTixDQUFjZ0ssZ0JBQWQsSUFBZ0MsRUFBaEMsR0FBbUNuZCxFQUFFb0MsTUFBTStRLE9BQU4sQ0FBY2dLLGdCQUFoQixDQUFuQyxHQUFxRS9hLE1BQU1oQixRQUFuRztBQUFBLFlBQ0lnYyxZQUFZQyxTQUFTSCxrQkFBa0J2VCxNQUFsQixHQUEyQkwsR0FBM0IsR0FBK0JsSCxNQUFNK1EsT0FBTixDQUFjbUssZUFBdEQsQ0FEaEI7QUFFQXRkLFVBQUUsWUFBRixFQUFnQnVkLElBQWhCLENBQXFCLElBQXJCLEVBQTJCbk0sT0FBM0IsQ0FBbUMsRUFBRTJMLFdBQVdLLFNBQWIsRUFBbkMsRUFBNkRoYixNQUFNK1EsT0FBTixDQUFjcUssaUJBQTNFLEVBQThGcGIsTUFBTStRLE9BQU4sQ0FBY3NLLGVBQTVHLEVBQTRILFlBQVU7QUFDcEk7Ozs7QUFJQSxjQUFHLFNBQU96ZCxFQUFFLE1BQUYsRUFBVSxDQUFWLENBQVYsRUFBdUJvQyxNQUFNaEIsUUFBTixDQUFlRSxPQUFmLENBQXVCLHVCQUF2QjtBQUN4QixTQU5EO0FBT0Q7O0FBRUQ7Ozs7O0FBckxXO0FBQUE7QUFBQSx3Q0F5TE87QUFDaEIsWUFBSWMsUUFBUSxJQUFaOztBQUVBLGFBQUtnWixVQUFMLENBQWdCUCxHQUFoQixDQUFvQixLQUFLelosUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixxREFBbkIsQ0FBcEIsRUFBK0Y0SixFQUEvRixDQUFrRyxzQkFBbEcsRUFBMEgsVUFBU3JKLENBQVQsRUFBVztBQUNuSSxjQUFJOUMsV0FBV3BCLEVBQUUsSUFBRixDQUFmO0FBQUEsY0FDSWdhLFlBQVk1WSxTQUFTOEgsTUFBVCxDQUFnQixJQUFoQixFQUFzQkEsTUFBdEIsQ0FBNkIsSUFBN0IsRUFBbUM4SixRQUFuQyxDQUE0QyxJQUE1QyxFQUFrREEsUUFBbEQsQ0FBMkQsR0FBM0QsQ0FEaEI7QUFBQSxjQUVJaUgsWUFGSjtBQUFBLGNBR0lDLFlBSEo7O0FBS0FGLG9CQUFVL1gsSUFBVixDQUFlLFVBQVN3QixDQUFULEVBQVk7QUFDekIsZ0JBQUl6RCxFQUFFLElBQUYsRUFBUStNLEVBQVIsQ0FBVzNMLFFBQVgsQ0FBSixFQUEwQjtBQUN4QjZZLDZCQUFlRCxVQUFVM00sRUFBVixDQUFhcEssS0FBS3dFLEdBQUwsQ0FBUyxDQUFULEVBQVloRSxJQUFFLENBQWQsQ0FBYixDQUFmO0FBQ0F5Vyw2QkFBZUYsVUFBVTNNLEVBQVYsQ0FBYXBLLEtBQUtrWCxHQUFMLENBQVMxVyxJQUFFLENBQVgsRUFBY3VXLFVBQVVqWCxNQUFWLEdBQWlCLENBQS9CLENBQWIsQ0FBZjtBQUNBO0FBQ0Q7QUFDRixXQU5EOztBQVFBN0MscUJBQVdtTCxRQUFYLENBQW9CYSxTQUFwQixDQUE4QmhJLENBQTlCLEVBQWlDLFdBQWpDLEVBQThDO0FBQzVDbVcsa0JBQU0sZ0JBQVc7QUFDZixrQkFBSWpaLFNBQVMyTCxFQUFULENBQVkzSyxNQUFNOFksZUFBbEIsQ0FBSixFQUF3QztBQUN0QzlZLHNCQUFNcWEsS0FBTixDQUFZcmIsU0FBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsQ0FBWjtBQUNBOUgseUJBQVM4SCxNQUFULENBQWdCLElBQWhCLEVBQXNCaUosR0FBdEIsQ0FBMEJqUyxXQUFXd0UsYUFBWCxDQUF5QnRELFFBQXpCLENBQTFCLEVBQThELFlBQVU7QUFDdEVBLDJCQUFTOEgsTUFBVCxDQUFnQixJQUFoQixFQUFzQnZGLElBQXRCLENBQTJCLFNBQTNCLEVBQXNDbUosTUFBdEMsQ0FBNkMxSyxNQUFNZ1osVUFBbkQsRUFBK0RsRixLQUEvRCxHQUF1RXhJLEtBQXZFO0FBQ0QsaUJBRkQ7QUFHQSx1QkFBTyxJQUFQO0FBQ0Q7QUFDRixhQVQyQztBQVU1Q2dRLHNCQUFVLG9CQUFXO0FBQ25CdGIsb0JBQU11YixLQUFOLENBQVl2YyxTQUFTOEgsTUFBVCxDQUFnQixJQUFoQixFQUFzQkEsTUFBdEIsQ0FBNkIsSUFBN0IsQ0FBWjtBQUNBOUgsdUJBQVM4SCxNQUFULENBQWdCLElBQWhCLEVBQXNCQSxNQUF0QixDQUE2QixJQUE3QixFQUFtQ2lKLEdBQW5DLENBQXVDalMsV0FBV3dFLGFBQVgsQ0FBeUJ0RCxRQUF6QixDQUF2QyxFQUEyRSxZQUFVO0FBQ25GNkQsMkJBQVcsWUFBVztBQUNwQjdELDJCQUFTOEgsTUFBVCxDQUFnQixJQUFoQixFQUFzQkEsTUFBdEIsQ0FBNkIsSUFBN0IsRUFBbUNBLE1BQW5DLENBQTBDLElBQTFDLEVBQWdEOEosUUFBaEQsQ0FBeUQsR0FBekQsRUFBOERrRCxLQUE5RCxHQUFzRXhJLEtBQXRFO0FBQ0QsaUJBRkQsRUFFRyxDQUZIO0FBR0QsZUFKRDtBQUtBLHFCQUFPLElBQVA7QUFDRCxhQWxCMkM7QUFtQjVDOE0sZ0JBQUksY0FBVztBQUNiUCwyQkFBYXZNLEtBQWI7QUFDQSxxQkFBTyxJQUFQO0FBQ0QsYUF0QjJDO0FBdUI1Q2tNLGtCQUFNLGdCQUFXO0FBQ2ZNLDJCQUFheE0sS0FBYjtBQUNBLHFCQUFPLElBQVA7QUFDRCxhQTFCMkM7QUEyQjVDNk0sbUJBQU8saUJBQVc7QUFDaEJuWSxvQkFBTStaLEtBQU47QUFDQTtBQUNELGFBOUIyQztBQStCNUM3QixrQkFBTSxnQkFBVztBQUNmLGtCQUFJLENBQUNsWixTQUFTMkwsRUFBVCxDQUFZM0ssTUFBTWdaLFVBQWxCLENBQUwsRUFBb0M7QUFBRTtBQUNwQ2haLHNCQUFNdWIsS0FBTixDQUFZdmMsU0FBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsRUFBc0JBLE1BQXRCLENBQTZCLElBQTdCLENBQVo7QUFDQTlILHlCQUFTOEgsTUFBVCxDQUFnQixJQUFoQixFQUFzQkEsTUFBdEIsQ0FBNkIsSUFBN0IsRUFBbUNpSixHQUFuQyxDQUF1Q2pTLFdBQVd3RSxhQUFYLENBQXlCdEQsUUFBekIsQ0FBdkMsRUFBMkUsWUFBVTtBQUNuRjZELDZCQUFXLFlBQVc7QUFDcEI3RCw2QkFBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsRUFBc0JBLE1BQXRCLENBQTZCLElBQTdCLEVBQW1DQSxNQUFuQyxDQUEwQyxJQUExQyxFQUFnRDhKLFFBQWhELENBQXlELEdBQXpELEVBQThEa0QsS0FBOUQsR0FBc0V4SSxLQUF0RTtBQUNELG1CQUZELEVBRUcsQ0FGSDtBQUdELGlCQUpEO0FBS0EsdUJBQU8sSUFBUDtBQUNELGVBUkQsTUFRTyxJQUFJdE0sU0FBUzJMLEVBQVQsQ0FBWTNLLE1BQU04WSxlQUFsQixDQUFKLEVBQXdDO0FBQzdDOVksc0JBQU1xYSxLQUFOLENBQVlyYixTQUFTOEgsTUFBVCxDQUFnQixJQUFoQixDQUFaO0FBQ0E5SCx5QkFBUzhILE1BQVQsQ0FBZ0IsSUFBaEIsRUFBc0JpSixHQUF0QixDQUEwQmpTLFdBQVd3RSxhQUFYLENBQXlCdEQsUUFBekIsQ0FBMUIsRUFBOEQsWUFBVTtBQUN0RUEsMkJBQVM4SCxNQUFULENBQWdCLElBQWhCLEVBQXNCdkYsSUFBdEIsQ0FBMkIsU0FBM0IsRUFBc0NtSixNQUF0QyxDQUE2QzFLLE1BQU1nWixVQUFuRCxFQUErRGxGLEtBQS9ELEdBQXVFeEksS0FBdkU7QUFDRCxpQkFGRDtBQUdBLHVCQUFPLElBQVA7QUFDRDtBQUNGLGFBL0MyQztBQWdENUNmLHFCQUFTLGlCQUFTYyxjQUFULEVBQXlCO0FBQ2hDLGtCQUFJQSxjQUFKLEVBQW9CO0FBQ2xCdkosa0JBQUV1SixjQUFGO0FBQ0Q7QUFDRHZKLGdCQUFFeVcsd0JBQUY7QUFDRDtBQXJEMkMsV0FBOUM7QUF1REQsU0FyRUQsRUFIZ0IsQ0F3RVo7QUFDTDs7QUFFRDs7Ozs7O0FBcFFXO0FBQUE7QUFBQSxpQ0F5UUE7QUFDVCxZQUFJalgsUUFBUSxLQUFLdEMsUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixpQ0FBbkIsRUFBc0RxTyxRQUF0RCxDQUErRCxZQUEvRCxDQUFaO0FBQ0EsWUFBRyxLQUFLbUIsT0FBTCxDQUFhaUosVUFBaEIsRUFBNEIsS0FBS0MsUUFBTCxDQUFjN04sR0FBZCxDQUFrQixFQUFDNUUsUUFBT2xHLE1BQU13RixNQUFOLEdBQWV1UCxPQUFmLENBQXVCLElBQXZCLEVBQTZCcFgsSUFBN0IsQ0FBa0MsWUFBbEMsQ0FBUixFQUFsQjtBQUM1QnFDLGNBQU15TyxHQUFOLENBQVVqUyxXQUFXd0UsYUFBWCxDQUF5QmhCLEtBQXpCLENBQVYsRUFBMkMsVUFBU1EsQ0FBVCxFQUFXO0FBQ3BEUixnQkFBTXVDLFdBQU4sQ0FBa0Isc0JBQWxCO0FBQ0QsU0FGRDtBQUdJOzs7O0FBSUosYUFBSzdFLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQixxQkFBdEI7QUFDRDs7QUFFRDs7Ozs7OztBQXRSVztBQUFBO0FBQUEsNEJBNFJMb0MsS0E1UkssRUE0UkU7QUFDWCxZQUFJdEIsUUFBUSxJQUFaO0FBQ0FzQixjQUFNa0ssR0FBTixDQUFVLG9CQUFWO0FBQ0FsSyxjQUFNc1AsUUFBTixDQUFlLG9CQUFmLEVBQ0d6RixFQURILENBQ00sb0JBRE4sRUFDNEIsVUFBU3JKLENBQVQsRUFBVztBQUNuQ0EsWUFBRXlXLHdCQUFGO0FBQ0E7QUFDQXZZLGdCQUFNdWIsS0FBTixDQUFZamEsS0FBWjs7QUFFQTtBQUNBLGNBQUlrYSxnQkFBZ0JsYSxNQUFNd0YsTUFBTixDQUFhLElBQWIsRUFBbUJBLE1BQW5CLENBQTBCLElBQTFCLEVBQWdDQSxNQUFoQyxDQUF1QyxJQUF2QyxDQUFwQjtBQUNBLGNBQUkwVSxjQUFjN2EsTUFBbEIsRUFBMEI7QUFDeEJYLGtCQUFNcWEsS0FBTixDQUFZbUIsYUFBWjtBQUNEO0FBQ0YsU0FYSDtBQVlEOztBQUVEOzs7Ozs7QUE3U1c7QUFBQTtBQUFBLHdDQWtUTztBQUNoQixZQUFJeGIsUUFBUSxJQUFaO0FBQ0EsYUFBS2daLFVBQUwsQ0FBZ0JwRCxHQUFoQixDQUFvQiw4QkFBcEIsRUFDS3BLLEdBREwsQ0FDUyxvQkFEVCxFQUVLTCxFQUZMLENBRVEsb0JBRlIsRUFFOEIsVUFBU3JKLENBQVQsRUFBVztBQUNuQztBQUNBZSxxQkFBVyxZQUFVO0FBQ25CN0Msa0JBQU15YSxRQUFOO0FBQ0QsV0FGRCxFQUVHLENBRkg7QUFHSCxTQVBIO0FBUUQ7O0FBRUQ7Ozs7Ozs7QUE5VFc7QUFBQTtBQUFBLDRCQW9VTG5aLEtBcFVLLEVBb1VFO0FBQ1gsWUFBRyxLQUFLeVAsT0FBTCxDQUFhaUosVUFBaEIsRUFBNEIsS0FBS0MsUUFBTCxDQUFjN04sR0FBZCxDQUFrQixFQUFDNUUsUUFBT2xHLE1BQU1zUCxRQUFOLENBQWUsZ0JBQWYsRUFBaUMzUixJQUFqQyxDQUFzQyxZQUF0QyxDQUFSLEVBQWxCO0FBQzVCcUMsY0FBTW5ELElBQU4sQ0FBVyxlQUFYLEVBQTRCLElBQTVCO0FBQ0FtRCxjQUFNc1AsUUFBTixDQUFlLGdCQUFmLEVBQWlDaEIsUUFBakMsQ0FBMEMsV0FBMUMsRUFBdUR6UixJQUF2RCxDQUE0RCxhQUE1RCxFQUEyRSxLQUEzRTtBQUNBOzs7O0FBSUEsYUFBS2EsUUFBTCxDQUFjRSxPQUFkLENBQXNCLG1CQUF0QixFQUEyQyxDQUFDb0MsS0FBRCxDQUEzQztBQUNEO0FBN1VVO0FBQUE7OztBQStVWDs7Ozs7O0FBL1VXLDRCQXFWTEEsS0FyVkssRUFxVkU7QUFDWCxZQUFHLEtBQUt5UCxPQUFMLENBQWFpSixVQUFoQixFQUE0QixLQUFLQyxRQUFMLENBQWM3TixHQUFkLENBQWtCLEVBQUM1RSxRQUFPbEcsTUFBTXdGLE1BQU4sR0FBZXVQLE9BQWYsQ0FBdUIsSUFBdkIsRUFBNkJwWCxJQUE3QixDQUFrQyxZQUFsQyxDQUFSLEVBQWxCO0FBQzVCLFlBQUllLFFBQVEsSUFBWjtBQUNBc0IsY0FBTXdGLE1BQU4sQ0FBYSxJQUFiLEVBQW1CM0ksSUFBbkIsQ0FBd0IsZUFBeEIsRUFBeUMsS0FBekM7QUFDQW1ELGNBQU1uRCxJQUFOLENBQVcsYUFBWCxFQUEwQixJQUExQixFQUFnQ3lSLFFBQWhDLENBQXlDLFlBQXpDO0FBQ0F0TyxjQUFNc08sUUFBTixDQUFlLFlBQWYsRUFDTUcsR0FETixDQUNValMsV0FBV3dFLGFBQVgsQ0FBeUJoQixLQUF6QixDQURWLEVBQzJDLFlBQVU7QUFDOUNBLGdCQUFNdUMsV0FBTixDQUFrQixzQkFBbEI7QUFDQXZDLGdCQUFNbWEsSUFBTjtBQUNELFNBSk47QUFLQTs7OztBQUlBbmEsY0FBTXBDLE9BQU4sQ0FBYyxtQkFBZCxFQUFtQyxDQUFDb0MsS0FBRCxDQUFuQztBQUNEOztBQUVEOzs7Ozs7O0FBdFdXO0FBQUE7QUFBQSxvQ0E0V0c7QUFDWixZQUFLb2EsWUFBWSxDQUFqQjtBQUFBLFlBQW9CQyxTQUFTLEVBQTdCO0FBQUEsWUFBaUMzYixRQUFRLElBQXpDO0FBQ0EsYUFBSytZLFNBQUwsQ0FBZU4sR0FBZixDQUFtQixLQUFLelosUUFBeEIsRUFBa0NhLElBQWxDLENBQXVDLFlBQVU7QUFDL0MsY0FBSStiLGFBQWFoZSxFQUFFLElBQUYsRUFBUWdULFFBQVIsQ0FBaUIsSUFBakIsRUFBdUJqUSxNQUF4QztBQUNBLGNBQUk2RyxTQUFTMUosV0FBVzJJLEdBQVgsQ0FBZUUsYUFBZixDQUE2QixJQUE3QixFQUFtQ2EsTUFBaEQ7QUFDQWtVLHNCQUFZbFUsU0FBU2tVLFNBQVQsR0FBcUJsVSxNQUFyQixHQUE4QmtVLFNBQTFDO0FBQ0EsY0FBRzFiLE1BQU0rUSxPQUFOLENBQWNpSixVQUFqQixFQUE2QjtBQUMzQnBjLGNBQUUsSUFBRixFQUFRcUIsSUFBUixDQUFhLFlBQWIsRUFBMEJ1SSxNQUExQjtBQUNBLGdCQUFJLENBQUM1SixFQUFFLElBQUYsRUFBUTBaLFFBQVIsQ0FBaUIsc0JBQWpCLENBQUwsRUFBK0NxRSxPQUFPLFFBQVAsSUFBbUJuVSxNQUFuQjtBQUNoRDtBQUNGLFNBUkQ7O0FBVUEsWUFBRyxDQUFDLEtBQUt1SixPQUFMLENBQWFpSixVQUFqQixFQUE2QjJCLE9BQU8sWUFBUCxJQUEwQkQsU0FBMUI7O0FBRTdCQyxlQUFPLFdBQVAsSUFBeUIsS0FBSzNjLFFBQUwsQ0FBYyxDQUFkLEVBQWlCOEkscUJBQWpCLEdBQXlDTCxLQUFsRTs7QUFFQSxlQUFPa1UsTUFBUDtBQUNEOztBQUVEOzs7OztBQS9YVztBQUFBO0FBQUEsZ0NBbVlEO0FBQ1IsWUFBRyxLQUFLNUssT0FBTCxDQUFhNEosU0FBaEIsRUFBMkIsS0FBSzNiLFFBQUwsQ0FBY3dNLEdBQWQsQ0FBa0IsZUFBbEIsRUFBa0MsS0FBS29QLFlBQXZDO0FBQzNCLGFBQUtILFFBQUw7QUFDRCxhQUFLemIsUUFBTCxDQUFjd00sR0FBZCxDQUFrQixxQkFBbEI7QUFDQzFOLG1CQUFXcVMsSUFBWCxDQUFnQlUsSUFBaEIsQ0FBcUIsS0FBSzdSLFFBQTFCLEVBQW9DLFdBQXBDO0FBQ0EsYUFBS0EsUUFBTCxDQUFjNmMsTUFBZCxHQUNjdGEsSUFEZCxDQUNtQiw2Q0FEbkIsRUFDa0V1YSxNQURsRSxHQUVjcFosR0FGZCxHQUVvQm5CLElBRnBCLENBRXlCLGdEQUZ6QixFQUUyRXNDLFdBRjNFLENBRXVGLDJDQUZ2RixFQUdjbkIsR0FIZCxHQUdvQm5CLElBSHBCLENBR3lCLGdCQUh6QixFQUcyQ2hDLFVBSDNDLENBR3NELDJCQUh0RDtBQUlBLGFBQUt1WixlQUFMLENBQXFCalosSUFBckIsQ0FBMEIsWUFBVztBQUNuQ2pDLFlBQUUsSUFBRixFQUFRNE4sR0FBUixDQUFZLGVBQVo7QUFDRCxTQUZEOztBQUlBLGFBQUt1TixTQUFMLENBQWVsVixXQUFmLENBQTJCLGtDQUEzQjs7QUFFQSxhQUFLN0UsUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixHQUFuQixFQUF3QjFCLElBQXhCLENBQTZCLFlBQVU7QUFDckMsY0FBSXVaLFFBQVF4YixFQUFFLElBQUYsQ0FBWjtBQUNBd2IsZ0JBQU03WixVQUFOLENBQWlCLFVBQWpCO0FBQ0EsY0FBRzZaLE1BQU1uYSxJQUFOLENBQVcsV0FBWCxDQUFILEVBQTJCO0FBQ3pCbWEsa0JBQU1qYixJQUFOLENBQVcsTUFBWCxFQUFtQmliLE1BQU1uYSxJQUFOLENBQVcsV0FBWCxDQUFuQixFQUE0Q08sVUFBNUMsQ0FBdUQsV0FBdkQ7QUFDRCxXQUZELE1BRUs7QUFBRTtBQUFTO0FBQ2pCLFNBTkQ7QUFPQTFCLG1CQUFXc0IsZ0JBQVgsQ0FBNEIsSUFBNUI7QUFDRDtBQTFaVTs7QUFBQTtBQUFBOztBQTZaYnlaLFlBQVU5QixRQUFWLEdBQXFCO0FBQ25COzs7OztBQUtBOEMsZ0JBQVksNkRBTk87QUFPbkI7Ozs7O0FBS0FGLHdCQUFvQixLQVpEO0FBYW5COzs7OztBQUtBTyxhQUFTLGFBbEJVO0FBbUJuQjs7Ozs7QUFLQWIsZ0JBQVksS0F4Qk87QUF5Qm5COzs7OztBQUtBaUIsa0JBQWMsS0E5Qks7QUErQm5COzs7OztBQUtBTixnQkFBWSxLQXBDTztBQXFDbkI7Ozs7O0FBS0FHLG1CQUFlLEtBMUNJO0FBMkNuQjs7Ozs7QUFLQVEsZUFBVyxLQWhEUTtBQWlEbkI7Ozs7O0FBS0FJLHNCQUFrQixFQXREQztBQXVEbkI7Ozs7O0FBS0FHLHFCQUFpQixDQTVERTtBQTZEbkI7Ozs7O0FBS0FFLHVCQUFtQixHQWxFQTtBQW1FbkI7Ozs7O0FBS0FDLHFCQUFpQjtBQUNqQjtBQXpFbUIsR0FBckI7O0FBNEVBO0FBQ0F2ZCxhQUFXTSxNQUFYLENBQWtCeWEsU0FBbEIsRUFBNkIsV0FBN0I7QUFFQyxDQTVlQSxDQTRlQ3JTLE1BNWVELENBQUQ7Q0NGQTs7Ozs7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViOzs7Ozs7OztBQUZhLE1BVVBtZSxRQVZPO0FBV1g7Ozs7Ozs7QUFPQSxzQkFBWWxWLE9BQVosRUFBcUJrSyxPQUFyQixFQUE4QjtBQUFBOztBQUM1QixXQUFLL1IsUUFBTCxHQUFnQjZILE9BQWhCO0FBQ0EsV0FBS2tLLE9BQUwsR0FBZW5ULEVBQUV5TSxNQUFGLENBQVMsRUFBVCxFQUFhMFIsU0FBU2hGLFFBQXRCLEVBQWdDLEtBQUsvWCxRQUFMLENBQWNDLElBQWQsRUFBaEMsRUFBc0Q4UixPQUF0RCxDQUFmO0FBQ0EsV0FBS2pSLEtBQUw7O0FBRUFoQyxpQkFBV1ksY0FBWCxDQUEwQixJQUExQixFQUFnQyxVQUFoQztBQUNBWixpQkFBV21MLFFBQVgsQ0FBb0IyQixRQUFwQixDQUE2QixVQUE3QixFQUF5QztBQUN2QyxpQkFBUyxNQUQ4QjtBQUV2QyxpQkFBUyxNQUY4QjtBQUd2QyxrQkFBVTtBQUg2QixPQUF6QztBQUtEOztBQUVEOzs7Ozs7O0FBL0JXO0FBQUE7QUFBQSw4QkFvQ0g7QUFDTixZQUFJb1IsTUFBTSxLQUFLaGQsUUFBTCxDQUFjYixJQUFkLENBQW1CLElBQW5CLENBQVY7O0FBRUEsYUFBSzhkLE9BQUwsR0FBZXJlLHFCQUFtQm9lLEdBQW5CLFNBQTRCcmIsTUFBNUIsR0FBcUMvQyxxQkFBbUJvZSxHQUFuQixRQUFyQyxHQUFtRXBlLG1CQUFpQm9lLEdBQWpCLFFBQWxGO0FBQ0EsYUFBS0MsT0FBTCxDQUFhOWQsSUFBYixDQUFrQjtBQUNoQiwyQkFBaUI2ZCxHQUREO0FBRWhCLDJCQUFpQixLQUZEO0FBR2hCLDJCQUFpQkEsR0FIRDtBQUloQiwyQkFBaUIsSUFKRDtBQUtoQiwyQkFBaUI7O0FBTEQsU0FBbEI7O0FBU0EsWUFBRyxLQUFLakwsT0FBTCxDQUFhbUwsV0FBaEIsRUFBNEI7QUFDMUIsZUFBS0MsT0FBTCxHQUFlLEtBQUtuZCxRQUFMLENBQWNnWixPQUFkLENBQXNCLE1BQU0sS0FBS2pILE9BQUwsQ0FBYW1MLFdBQXpDLENBQWY7QUFDRCxTQUZELE1BRUs7QUFDSCxlQUFLQyxPQUFMLEdBQWUsSUFBZjtBQUNEO0FBQ0QsYUFBS3BMLE9BQUwsQ0FBYXFMLGFBQWIsR0FBNkIsS0FBS0MsZ0JBQUwsRUFBN0I7QUFDQSxhQUFLQyxPQUFMLEdBQWUsQ0FBZjtBQUNBLGFBQUtDLGFBQUwsR0FBcUIsRUFBckI7QUFDQSxhQUFLdmQsUUFBTCxDQUFjYixJQUFkLENBQW1CO0FBQ2pCLHlCQUFlLE1BREU7QUFFakIsMkJBQWlCNmQsR0FGQTtBQUdqQix5QkFBZUEsR0FIRTtBQUlqQiw2QkFBbUIsS0FBS0MsT0FBTCxDQUFhLENBQWIsRUFBZ0J4TyxFQUFoQixJQUFzQjNQLFdBQVdpQixXQUFYLENBQXVCLENBQXZCLEVBQTBCLFdBQTFCO0FBSnhCLFNBQW5CO0FBTUEsYUFBSzBZLE9BQUw7QUFDRDs7QUFFRDs7Ozs7O0FBbEVXO0FBQUE7QUFBQSx5Q0F1RVE7QUFDakIsWUFBSStFLG1CQUFtQixLQUFLeGQsUUFBTCxDQUFjLENBQWQsRUFBaUJWLFNBQWpCLENBQTJCbWUsS0FBM0IsQ0FBaUMsMEJBQWpDLENBQXZCO0FBQ0lELDJCQUFtQkEsbUJBQW1CQSxpQkFBaUIsQ0FBakIsQ0FBbkIsR0FBeUMsRUFBNUQ7QUFDSixZQUFJRSxxQkFBcUIsY0FBY3ZXLElBQWQsQ0FBbUIsS0FBSzhWLE9BQUwsQ0FBYSxDQUFiLEVBQWdCM2QsU0FBbkMsQ0FBekI7QUFDSW9lLDZCQUFxQkEscUJBQXFCQSxtQkFBbUIsQ0FBbkIsQ0FBckIsR0FBNkMsRUFBbEU7QUFDSixZQUFJalUsV0FBV2lVLHFCQUFxQkEscUJBQXFCLEdBQXJCLEdBQTJCRixnQkFBaEQsR0FBbUVBLGdCQUFsRjs7QUFFQSxlQUFPL1QsUUFBUDtBQUNEOztBQUVEOzs7Ozs7O0FBakZXO0FBQUE7QUFBQSxrQ0F1RkNBLFFBdkZELEVBdUZXO0FBQ3BCLGFBQUs4VCxhQUFMLENBQW1CcGQsSUFBbkIsQ0FBd0JzSixXQUFXQSxRQUFYLEdBQXNCLFFBQTlDO0FBQ0E7QUFDQSxZQUFHLENBQUNBLFFBQUQsSUFBYyxLQUFLOFQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLEtBQTNCLElBQW9DLENBQXJELEVBQXdEO0FBQ3RELGVBQUtOLFFBQUwsQ0FBYzRRLFFBQWQsQ0FBdUIsS0FBdkI7QUFDRCxTQUZELE1BRU0sSUFBR25ILGFBQWEsS0FBYixJQUF1QixLQUFLOFQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLFFBQTNCLElBQXVDLENBQWpFLEVBQW9FO0FBQ3hFLGVBQUtOLFFBQUwsQ0FBYzZFLFdBQWQsQ0FBMEI0RSxRQUExQjtBQUNELFNBRkssTUFFQSxJQUFHQSxhQUFhLE1BQWIsSUFBd0IsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixPQUEzQixJQUFzQyxDQUFqRSxFQUFvRTtBQUN4RSxlQUFLTixRQUFMLENBQWM2RSxXQUFkLENBQTBCNEUsUUFBMUIsRUFDS21ILFFBREwsQ0FDYyxPQURkO0FBRUQsU0FISyxNQUdBLElBQUduSCxhQUFhLE9BQWIsSUFBeUIsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixNQUEzQixJQUFxQyxDQUFqRSxFQUFvRTtBQUN4RSxlQUFLTixRQUFMLENBQWM2RSxXQUFkLENBQTBCNEUsUUFBMUIsRUFDS21ILFFBREwsQ0FDYyxNQURkO0FBRUQ7O0FBRUQ7QUFMTSxhQU1ELElBQUcsQ0FBQ25ILFFBQUQsSUFBYyxLQUFLOFQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLEtBQTNCLElBQW9DLENBQUMsQ0FBbkQsSUFBMEQsS0FBS2lkLGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixNQUEzQixJQUFxQyxDQUFsRyxFQUFxRztBQUN4RyxpQkFBS04sUUFBTCxDQUFjNFEsUUFBZCxDQUF1QixNQUF2QjtBQUNELFdBRkksTUFFQyxJQUFHbkgsYUFBYSxLQUFiLElBQXVCLEtBQUs4VCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsUUFBM0IsSUFBdUMsQ0FBQyxDQUEvRCxJQUFzRSxLQUFLaWQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLE1BQTNCLElBQXFDLENBQTlHLEVBQWlIO0FBQ3JILGlCQUFLTixRQUFMLENBQWM2RSxXQUFkLENBQTBCNEUsUUFBMUIsRUFDS21ILFFBREwsQ0FDYyxNQURkO0FBRUQsV0FISyxNQUdBLElBQUduSCxhQUFhLE1BQWIsSUFBd0IsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixPQUEzQixJQUFzQyxDQUFDLENBQS9ELElBQXNFLEtBQUtpZCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsUUFBM0IsSUFBdUMsQ0FBaEgsRUFBbUg7QUFDdkgsaUJBQUtOLFFBQUwsQ0FBYzZFLFdBQWQsQ0FBMEI0RSxRQUExQjtBQUNELFdBRkssTUFFQSxJQUFHQSxhQUFhLE9BQWIsSUFBeUIsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixNQUEzQixJQUFxQyxDQUFDLENBQS9ELElBQXNFLEtBQUtpZCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsUUFBM0IsSUFBdUMsQ0FBaEgsRUFBbUg7QUFDdkgsaUJBQUtOLFFBQUwsQ0FBYzZFLFdBQWQsQ0FBMEI0RSxRQUExQjtBQUNEO0FBQ0Q7QUFITSxlQUlGO0FBQ0YsbUJBQUt6SixRQUFMLENBQWM2RSxXQUFkLENBQTBCNEUsUUFBMUI7QUFDRDtBQUNELGFBQUtrVSxZQUFMLEdBQW9CLElBQXBCO0FBQ0EsYUFBS0wsT0FBTDtBQUNEOztBQUVEOzs7Ozs7O0FBekhXO0FBQUE7QUFBQSxxQ0ErSEk7QUFDYixZQUFHLEtBQUtMLE9BQUwsQ0FBYTlkLElBQWIsQ0FBa0IsZUFBbEIsTUFBdUMsT0FBMUMsRUFBa0Q7QUFBRSxpQkFBTyxLQUFQO0FBQWU7QUFDbkUsWUFBSXNLLFdBQVcsS0FBSzRULGdCQUFMLEVBQWY7QUFBQSxZQUNJeFQsV0FBVy9LLFdBQVcySSxHQUFYLENBQWVFLGFBQWYsQ0FBNkIsS0FBSzNILFFBQWxDLENBRGY7QUFBQSxZQUVJOEosY0FBY2hMLFdBQVcySSxHQUFYLENBQWVFLGFBQWYsQ0FBNkIsS0FBS3NWLE9BQWxDLENBRmxCO0FBQUEsWUFHSWpjLFFBQVEsSUFIWjtBQUFBLFlBSUk0YyxZQUFhblUsYUFBYSxNQUFiLEdBQXNCLE1BQXRCLEdBQWlDQSxhQUFhLE9BQWQsR0FBeUIsTUFBekIsR0FBa0MsS0FKbkY7QUFBQSxZQUtJNEYsUUFBU3VPLGNBQWMsS0FBZixHQUF3QixRQUF4QixHQUFtQyxPQUwvQztBQUFBLFlBTUlyVixTQUFVOEcsVUFBVSxRQUFYLEdBQXVCLEtBQUswQyxPQUFMLENBQWFySSxPQUFwQyxHQUE4QyxLQUFLcUksT0FBTCxDQUFhcEksT0FOeEU7O0FBUUEsWUFBSUUsU0FBU3BCLEtBQVQsSUFBa0JvQixTQUFTbkIsVUFBVCxDQUFvQkQsS0FBdkMsSUFBa0QsQ0FBQyxLQUFLNlUsT0FBTixJQUFpQixDQUFDeGUsV0FBVzJJLEdBQVgsQ0FBZUMsZ0JBQWYsQ0FBZ0MsS0FBSzFILFFBQXJDLEVBQStDLEtBQUttZCxPQUFwRCxDQUF2RSxFQUFxSTtBQUNuSSxjQUFJVSxXQUFXaFUsU0FBU25CLFVBQVQsQ0FBb0JELEtBQW5DO0FBQUEsY0FDSXFWLGdCQUFnQixDQURwQjtBQUVBLGNBQUcsS0FBS1gsT0FBUixFQUFnQjtBQUNkLGdCQUFJWSxjQUFjamYsV0FBVzJJLEdBQVgsQ0FBZUUsYUFBZixDQUE2QixLQUFLd1YsT0FBbEMsQ0FBbEI7QUFBQSxnQkFDSVcsZ0JBQWdCQyxZQUFZeFYsTUFBWixDQUFtQkgsSUFEdkM7QUFFQSxnQkFBSTJWLFlBQVl0VixLQUFaLEdBQW9Cb1YsUUFBeEIsRUFBaUM7QUFDL0JBLHlCQUFXRSxZQUFZdFYsS0FBdkI7QUFDRDtBQUNGOztBQUVELGVBQUt6SSxRQUFMLENBQWN1SSxNQUFkLENBQXFCekosV0FBVzJJLEdBQVgsQ0FBZUcsVUFBZixDQUEwQixLQUFLNUgsUUFBL0IsRUFBeUMsS0FBS2lkLE9BQTlDLEVBQXVELGVBQXZELEVBQXdFLEtBQUtsTCxPQUFMLENBQWFySSxPQUFyRixFQUE4RixLQUFLcUksT0FBTCxDQUFhcEksT0FBYixHQUF1Qm1VLGFBQXJILEVBQW9JLElBQXBJLENBQXJCLEVBQWdLMVEsR0FBaEssQ0FBb0s7QUFDbEsscUJBQVN5USxXQUFZLEtBQUs5TCxPQUFMLENBQWFwSSxPQUFiLEdBQXVCLENBRHNIO0FBRWxLLHNCQUFVO0FBRndKLFdBQXBLO0FBSUEsZUFBS2dVLFlBQUwsR0FBb0IsSUFBcEI7QUFDQSxpQkFBTyxLQUFQO0FBQ0Q7O0FBRUQsYUFBSzNkLFFBQUwsQ0FBY3VJLE1BQWQsQ0FBcUJ6SixXQUFXMkksR0FBWCxDQUFlRyxVQUFmLENBQTBCLEtBQUs1SCxRQUEvQixFQUF5QyxLQUFLaWQsT0FBOUMsRUFBdUR4VCxRQUF2RCxFQUFpRSxLQUFLc0ksT0FBTCxDQUFhckksT0FBOUUsRUFBdUYsS0FBS3FJLE9BQUwsQ0FBYXBJLE9BQXBHLENBQXJCOztBQUVBLGVBQU0sQ0FBQzdLLFdBQVcySSxHQUFYLENBQWVDLGdCQUFmLENBQWdDLEtBQUsxSCxRQUFyQyxFQUErQyxLQUFLbWQsT0FBcEQsRUFBNkQsSUFBN0QsQ0FBRCxJQUF1RSxLQUFLRyxPQUFsRixFQUEwRjtBQUN4RixlQUFLVSxXQUFMLENBQWlCdlUsUUFBakI7QUFDQSxlQUFLd1UsWUFBTDtBQUNEO0FBQ0Y7O0FBRUQ7Ozs7OztBQXBLVztBQUFBO0FBQUEsZ0NBeUtEO0FBQ1IsWUFBSWpkLFFBQVEsSUFBWjtBQUNBLGFBQUtoQixRQUFMLENBQWNtTSxFQUFkLENBQWlCO0FBQ2YsNkJBQW1CLEtBQUsrTSxJQUFMLENBQVV4UyxJQUFWLENBQWUsSUFBZixDQURKO0FBRWYsOEJBQW9CLEtBQUt5UyxLQUFMLENBQVd6UyxJQUFYLENBQWdCLElBQWhCLENBRkw7QUFHZiwrQkFBcUIsS0FBS2lTLE1BQUwsQ0FBWWpTLElBQVosQ0FBaUIsSUFBakIsQ0FITjtBQUlmLGlDQUF1QixLQUFLdVgsWUFBTCxDQUFrQnZYLElBQWxCLENBQXVCLElBQXZCO0FBSlIsU0FBakI7O0FBT0EsWUFBRyxLQUFLcUwsT0FBTCxDQUFhbU0sS0FBaEIsRUFBc0I7QUFDcEIsZUFBS2pCLE9BQUwsQ0FBYXpRLEdBQWIsQ0FBaUIsK0NBQWpCLEVBQ0NMLEVBREQsQ0FDSSx3QkFESixFQUM4QixZQUFVO0FBQ3RDLGdCQUFJZ1MsV0FBV3ZmLEVBQUUsTUFBRixFQUFVcUIsSUFBVixFQUFmO0FBQ0EsZ0JBQUcsT0FBT2tlLFNBQVNDLFNBQWhCLEtBQStCLFdBQS9CLElBQThDRCxTQUFTQyxTQUFULEtBQXVCLE9BQXhFLEVBQWlGO0FBQy9FOVgsMkJBQWF0RixNQUFNcWQsT0FBbkI7QUFDQXJkLG9CQUFNcWQsT0FBTixHQUFnQnhhLFdBQVcsWUFBVTtBQUNuQzdDLHNCQUFNa1ksSUFBTjtBQUNBbFksc0JBQU1pYyxPQUFOLENBQWNoZCxJQUFkLENBQW1CLE9BQW5CLEVBQTRCLElBQTVCO0FBQ0QsZUFIZSxFQUdiZSxNQUFNK1EsT0FBTixDQUFjdU0sVUFIRCxDQUFoQjtBQUlEO0FBQ0YsV0FWRCxFQVVHblMsRUFWSCxDQVVNLHdCQVZOLEVBVWdDLFlBQVU7QUFDeEM3Rix5QkFBYXRGLE1BQU1xZCxPQUFuQjtBQUNBcmQsa0JBQU1xZCxPQUFOLEdBQWdCeGEsV0FBVyxZQUFVO0FBQ25DN0Msb0JBQU1tWSxLQUFOO0FBQ0FuWSxvQkFBTWljLE9BQU4sQ0FBY2hkLElBQWQsQ0FBbUIsT0FBbkIsRUFBNEIsS0FBNUI7QUFDRCxhQUhlLEVBR2JlLE1BQU0rUSxPQUFOLENBQWN1TSxVQUhELENBQWhCO0FBSUQsV0FoQkQ7QUFpQkEsY0FBRyxLQUFLdk0sT0FBTCxDQUFhd00sU0FBaEIsRUFBMEI7QUFDeEIsaUJBQUt2ZSxRQUFMLENBQWN3TSxHQUFkLENBQWtCLCtDQUFsQixFQUNLTCxFQURMLENBQ1Esd0JBRFIsRUFDa0MsWUFBVTtBQUN0QzdGLDJCQUFhdEYsTUFBTXFkLE9BQW5CO0FBQ0QsYUFITCxFQUdPbFMsRUFIUCxDQUdVLHdCQUhWLEVBR29DLFlBQVU7QUFDeEM3RiwyQkFBYXRGLE1BQU1xZCxPQUFuQjtBQUNBcmQsb0JBQU1xZCxPQUFOLEdBQWdCeGEsV0FBVyxZQUFVO0FBQ25DN0Msc0JBQU1tWSxLQUFOO0FBQ0FuWSxzQkFBTWljLE9BQU4sQ0FBY2hkLElBQWQsQ0FBbUIsT0FBbkIsRUFBNEIsS0FBNUI7QUFDRCxlQUhlLEVBR2JlLE1BQU0rUSxPQUFOLENBQWN1TSxVQUhELENBQWhCO0FBSUQsYUFUTDtBQVVEO0FBQ0Y7QUFDRCxhQUFLckIsT0FBTCxDQUFheEQsR0FBYixDQUFpQixLQUFLelosUUFBdEIsRUFBZ0NtTSxFQUFoQyxDQUFtQyxxQkFBbkMsRUFBMEQsVUFBU3JKLENBQVQsRUFBWTs7QUFFcEUsY0FBSXFVLFVBQVV2WSxFQUFFLElBQUYsQ0FBZDtBQUFBLGNBQ0U0ZiwyQkFBMkIxZixXQUFXbUwsUUFBWCxDQUFvQndCLGFBQXBCLENBQWtDekssTUFBTWhCLFFBQXhDLENBRDdCOztBQUdBbEIscUJBQVdtTCxRQUFYLENBQW9CYSxTQUFwQixDQUE4QmhJLENBQTlCLEVBQWlDLFVBQWpDLEVBQTZDO0FBQzNDb1csa0JBQU0sZ0JBQVc7QUFDZixrQkFBSS9CLFFBQVF4TCxFQUFSLENBQVczSyxNQUFNaWMsT0FBakIsQ0FBSixFQUErQjtBQUM3QmpjLHNCQUFNa1ksSUFBTjtBQUNBbFksc0JBQU1oQixRQUFOLENBQWViLElBQWYsQ0FBb0IsVUFBcEIsRUFBZ0MsQ0FBQyxDQUFqQyxFQUFvQ21OLEtBQXBDO0FBQ0F4SixrQkFBRXVKLGNBQUY7QUFDRDtBQUNGLGFBUDBDO0FBUTNDOE0sbUJBQU8saUJBQVc7QUFDaEJuWSxvQkFBTW1ZLEtBQU47QUFDQW5ZLG9CQUFNaWMsT0FBTixDQUFjM1EsS0FBZDtBQUNEO0FBWDBDLFdBQTdDO0FBYUQsU0FsQkQ7QUFtQkQ7O0FBRUQ7Ozs7OztBQXRPVztBQUFBO0FBQUEsd0NBMk9PO0FBQ2YsWUFBSWlQLFFBQVEzYyxFQUFFNEUsU0FBUzBGLElBQVgsRUFBaUIwTixHQUFqQixDQUFxQixLQUFLNVcsUUFBMUIsQ0FBWjtBQUFBLFlBQ0lnQixRQUFRLElBRFo7QUFFQXVhLGNBQU0vTyxHQUFOLENBQVUsbUJBQVYsRUFDTUwsRUFETixDQUNTLG1CQURULEVBQzhCLFVBQVNySixDQUFULEVBQVc7QUFDbEMsY0FBRzlCLE1BQU1pYyxPQUFOLENBQWN0UixFQUFkLENBQWlCN0ksRUFBRXNKLE1BQW5CLEtBQThCcEwsTUFBTWljLE9BQU4sQ0FBYzFhLElBQWQsQ0FBbUJPLEVBQUVzSixNQUFyQixFQUE2QnpLLE1BQTlELEVBQXNFO0FBQ3BFO0FBQ0Q7QUFDRCxjQUFHWCxNQUFNaEIsUUFBTixDQUFldUMsSUFBZixDQUFvQk8sRUFBRXNKLE1BQXRCLEVBQThCekssTUFBakMsRUFBeUM7QUFDdkM7QUFDRDtBQUNEWCxnQkFBTW1ZLEtBQU47QUFDQW9DLGdCQUFNL08sR0FBTixDQUFVLG1CQUFWO0FBQ0QsU0FWTjtBQVdGOztBQUVEOzs7Ozs7O0FBM1BXO0FBQUE7QUFBQSw2QkFpUUo7QUFDTDtBQUNBOzs7O0FBSUEsYUFBS3hNLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQixxQkFBdEIsRUFBNkMsS0FBS0YsUUFBTCxDQUFjYixJQUFkLENBQW1CLElBQW5CLENBQTdDO0FBQ0EsYUFBSzhkLE9BQUwsQ0FBYXJNLFFBQWIsQ0FBc0IsT0FBdEIsRUFDS3pSLElBREwsQ0FDVSxFQUFDLGlCQUFpQixJQUFsQixFQURWO0FBRUE7QUFDQSxhQUFLOGUsWUFBTDtBQUNBLGFBQUtqZSxRQUFMLENBQWM0USxRQUFkLENBQXVCLFNBQXZCLEVBQ0t6UixJQURMLENBQ1UsRUFBQyxlQUFlLEtBQWhCLEVBRFY7O0FBR0EsWUFBRyxLQUFLNFMsT0FBTCxDQUFhME0sU0FBaEIsRUFBMEI7QUFDeEIsY0FBSTFTLGFBQWFqTixXQUFXbUwsUUFBWCxDQUFvQndCLGFBQXBCLENBQWtDLEtBQUt6TCxRQUF2QyxDQUFqQjtBQUNBLGNBQUcrTCxXQUFXcEssTUFBZCxFQUFxQjtBQUNuQm9LLHVCQUFXRSxFQUFYLENBQWMsQ0FBZCxFQUFpQkssS0FBakI7QUFDRDtBQUNGOztBQUVELFlBQUcsS0FBS3lGLE9BQUwsQ0FBYXVKLFlBQWhCLEVBQTZCO0FBQUUsZUFBS29ELGVBQUw7QUFBeUI7O0FBRXhELFlBQUksS0FBSzNNLE9BQUwsQ0FBYWpHLFNBQWpCLEVBQTRCO0FBQzFCaE4scUJBQVdtTCxRQUFYLENBQW9CNkIsU0FBcEIsQ0FBOEIsS0FBSzlMLFFBQW5DO0FBQ0Q7O0FBRUQ7Ozs7QUFJQSxhQUFLQSxRQUFMLENBQWNFLE9BQWQsQ0FBc0Isa0JBQXRCLEVBQTBDLENBQUMsS0FBS0YsUUFBTixDQUExQztBQUNEOztBQUVEOzs7Ozs7QUFuU1c7QUFBQTtBQUFBLDhCQXdTSDtBQUNOLFlBQUcsQ0FBQyxLQUFLQSxRQUFMLENBQWNzWSxRQUFkLENBQXVCLFNBQXZCLENBQUosRUFBc0M7QUFDcEMsaUJBQU8sS0FBUDtBQUNEO0FBQ0QsYUFBS3RZLFFBQUwsQ0FBYzZFLFdBQWQsQ0FBMEIsU0FBMUIsRUFDSzFGLElBREwsQ0FDVSxFQUFDLGVBQWUsSUFBaEIsRUFEVjs7QUFHQSxhQUFLOGQsT0FBTCxDQUFhcFksV0FBYixDQUF5QixPQUF6QixFQUNLMUYsSUFETCxDQUNVLGVBRFYsRUFDMkIsS0FEM0I7O0FBR0EsWUFBRyxLQUFLd2UsWUFBUixFQUFxQjtBQUNuQixjQUFJZ0IsbUJBQW1CLEtBQUt0QixnQkFBTCxFQUF2QjtBQUNBLGNBQUdzQixnQkFBSCxFQUFvQjtBQUNsQixpQkFBSzNlLFFBQUwsQ0FBYzZFLFdBQWQsQ0FBMEI4WixnQkFBMUI7QUFDRDtBQUNELGVBQUszZSxRQUFMLENBQWM0USxRQUFkLENBQXVCLEtBQUttQixPQUFMLENBQWFxTCxhQUFwQztBQUNJLHFCQURKLENBQ2dCaFEsR0FEaEIsQ0FDb0IsRUFBQzVFLFFBQVEsRUFBVCxFQUFhQyxPQUFPLEVBQXBCLEVBRHBCO0FBRUEsZUFBS2tWLFlBQUwsR0FBb0IsS0FBcEI7QUFDQSxlQUFLTCxPQUFMLEdBQWUsQ0FBZjtBQUNBLGVBQUtDLGFBQUwsQ0FBbUI1YixNQUFuQixHQUE0QixDQUE1QjtBQUNEO0FBQ0QsYUFBSzNCLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQixrQkFBdEIsRUFBMEMsQ0FBQyxLQUFLRixRQUFOLENBQTFDOztBQUVBLFlBQUksS0FBSytSLE9BQUwsQ0FBYWpHLFNBQWpCLEVBQTRCO0FBQzFCaE4scUJBQVdtTCxRQUFYLENBQW9Cc0MsWUFBcEIsQ0FBaUMsS0FBS3ZNLFFBQXRDO0FBQ0Q7QUFDRjs7QUFFRDs7Ozs7QUFwVVc7QUFBQTtBQUFBLCtCQXdVRjtBQUNQLFlBQUcsS0FBS0EsUUFBTCxDQUFjc1ksUUFBZCxDQUF1QixTQUF2QixDQUFILEVBQXFDO0FBQ25DLGNBQUcsS0FBSzJFLE9BQUwsQ0FBYWhkLElBQWIsQ0FBa0IsT0FBbEIsQ0FBSCxFQUErQjtBQUMvQixlQUFLa1osS0FBTDtBQUNELFNBSEQsTUFHSztBQUNILGVBQUtELElBQUw7QUFDRDtBQUNGOztBQUVEOzs7OztBQWpWVztBQUFBO0FBQUEsZ0NBcVZEO0FBQ1IsYUFBS2xaLFFBQUwsQ0FBY3dNLEdBQWQsQ0FBa0IsYUFBbEIsRUFBaUN5RSxJQUFqQztBQUNBLGFBQUtnTSxPQUFMLENBQWF6USxHQUFiLENBQWlCLGNBQWpCOztBQUVBMU4sbUJBQVdzQixnQkFBWCxDQUE0QixJQUE1QjtBQUNEO0FBMVZVOztBQUFBO0FBQUE7O0FBNlZiMmMsV0FBU2hGLFFBQVQsR0FBb0I7QUFDbEI7Ozs7O0FBS0FtRixpQkFBYSxJQU5LO0FBT2xCOzs7OztBQUtBb0IsZ0JBQVksR0FaTTtBQWFsQjs7Ozs7QUFLQUosV0FBTyxLQWxCVztBQW1CbEI7Ozs7O0FBS0FLLGVBQVcsS0F4Qk87QUF5QmxCOzs7OztBQUtBN1UsYUFBUyxDQTlCUztBQStCbEI7Ozs7O0FBS0FDLGFBQVMsQ0FwQ1M7QUFxQ2xCOzs7OztBQUtBeVQsbUJBQWUsRUExQ0c7QUEyQ2xCOzs7OztBQUtBdFIsZUFBVyxLQWhETztBQWlEbEI7Ozs7O0FBS0EyUyxlQUFXLEtBdERPO0FBdURsQjs7Ozs7QUFLQW5ELGtCQUFjOztBQUdoQjtBQS9Eb0IsR0FBcEIsQ0FnRUF4YyxXQUFXTSxNQUFYLENBQWtCMmQsUUFBbEIsRUFBNEIsVUFBNUI7QUFFQyxDQS9aQSxDQStaQ3ZWLE1BL1pELENBQUQ7Q0NGQTs7Ozs7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViOzs7Ozs7OztBQUZhLE1BVVBnZ0IsWUFWTztBQVdYOzs7Ozs7O0FBT0EsMEJBQVkvVyxPQUFaLEVBQXFCa0ssT0FBckIsRUFBOEI7QUFBQTs7QUFDNUIsV0FBSy9SLFFBQUwsR0FBZ0I2SCxPQUFoQjtBQUNBLFdBQUtrSyxPQUFMLEdBQWVuVCxFQUFFeU0sTUFBRixDQUFTLEVBQVQsRUFBYXVULGFBQWE3RyxRQUExQixFQUFvQyxLQUFLL1gsUUFBTCxDQUFjQyxJQUFkLEVBQXBDLEVBQTBEOFIsT0FBMUQsQ0FBZjs7QUFFQWpULGlCQUFXcVMsSUFBWCxDQUFnQkMsT0FBaEIsQ0FBd0IsS0FBS3BSLFFBQTdCLEVBQXVDLFVBQXZDO0FBQ0EsV0FBS2MsS0FBTDs7QUFFQWhDLGlCQUFXWSxjQUFYLENBQTBCLElBQTFCLEVBQWdDLGNBQWhDO0FBQ0FaLGlCQUFXbUwsUUFBWCxDQUFvQjJCLFFBQXBCLENBQTZCLGNBQTdCLEVBQTZDO0FBQzNDLGlCQUFTLE1BRGtDO0FBRTNDLGlCQUFTLE1BRmtDO0FBRzNDLHVCQUFlLE1BSDRCO0FBSTNDLG9CQUFZLElBSitCO0FBSzNDLHNCQUFjLE1BTDZCO0FBTTNDLHNCQUFjLFVBTjZCO0FBTzNDLGtCQUFVO0FBUGlDLE9BQTdDO0FBU0Q7O0FBRUQ7Ozs7Ozs7QUFyQ1c7QUFBQTtBQUFBLDhCQTBDSDtBQUNOLFlBQUlpVCxPQUFPLEtBQUs3ZSxRQUFMLENBQWN1QyxJQUFkLENBQW1CLCtCQUFuQixDQUFYO0FBQ0EsYUFBS3ZDLFFBQUwsQ0FBYzRSLFFBQWQsQ0FBdUIsNkJBQXZCLEVBQXNEQSxRQUF0RCxDQUErRCxzQkFBL0QsRUFBdUZoQixRQUF2RixDQUFnRyxXQUFoRzs7QUFFQSxhQUFLb0osVUFBTCxHQUFrQixLQUFLaGEsUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixtQkFBbkIsQ0FBbEI7QUFDQSxhQUFLdWMsS0FBTCxHQUFhLEtBQUs5ZSxRQUFMLENBQWM0UixRQUFkLENBQXVCLG1CQUF2QixDQUFiO0FBQ0EsYUFBS2tOLEtBQUwsQ0FBV3ZjLElBQVgsQ0FBZ0Isd0JBQWhCLEVBQTBDcU8sUUFBMUMsQ0FBbUQsS0FBS21CLE9BQUwsQ0FBYWdOLGFBQWhFOztBQUVBLFlBQUksS0FBSy9lLFFBQUwsQ0FBY3NZLFFBQWQsQ0FBdUIsS0FBS3ZHLE9BQUwsQ0FBYWlOLFVBQXBDLEtBQW1ELEtBQUtqTixPQUFMLENBQWFrTixTQUFiLEtBQTJCLE9BQTlFLElBQXlGbmdCLFdBQVdJLEdBQVgsRUFBekYsSUFBNkcsS0FBS2MsUUFBTCxDQUFjZ1osT0FBZCxDQUFzQixnQkFBdEIsRUFBd0NyTixFQUF4QyxDQUEyQyxHQUEzQyxDQUFqSCxFQUFrSztBQUNoSyxlQUFLb0csT0FBTCxDQUFha04sU0FBYixHQUF5QixPQUF6QjtBQUNBSixlQUFLak8sUUFBTCxDQUFjLFlBQWQ7QUFDRCxTQUhELE1BR087QUFDTGlPLGVBQUtqTyxRQUFMLENBQWMsYUFBZDtBQUNEO0FBQ0QsYUFBS3NPLE9BQUwsR0FBZSxLQUFmO0FBQ0EsYUFBS3pHLE9BQUw7QUFDRDtBQTFEVTtBQUFBO0FBQUEsb0NBNERHO0FBQ1osZUFBTyxLQUFLcUcsS0FBTCxDQUFXMVIsR0FBWCxDQUFlLFNBQWYsTUFBOEIsT0FBckM7QUFDRDs7QUFFRDs7Ozs7O0FBaEVXO0FBQUE7QUFBQSxnQ0FxRUQ7QUFDUixZQUFJcE0sUUFBUSxJQUFaO0FBQUEsWUFDSW1lLFdBQVcsa0JBQWtCN1osTUFBbEIsSUFBNkIsT0FBT0EsT0FBTzhaLFlBQWQsS0FBK0IsV0FEM0U7QUFBQSxZQUVJQyxXQUFXLDRCQUZmOztBQUlBO0FBQ0EsWUFBSUMsZ0JBQWdCLFNBQWhCQSxhQUFnQixDQUFTeGMsQ0FBVCxFQUFZO0FBQzlCLGNBQUlSLFFBQVExRCxFQUFFa0UsRUFBRXNKLE1BQUosRUFBWW9OLFlBQVosQ0FBeUIsSUFBekIsUUFBbUM2RixRQUFuQyxDQUFaO0FBQUEsY0FDSUUsU0FBU2pkLE1BQU1nVyxRQUFOLENBQWUrRyxRQUFmLENBRGI7QUFBQSxjQUVJRyxhQUFhbGQsTUFBTW5ELElBQU4sQ0FBVyxlQUFYLE1BQWdDLE1BRmpEO0FBQUEsY0FHSXdTLE9BQU9yUCxNQUFNc1AsUUFBTixDQUFlLHNCQUFmLENBSFg7O0FBS0EsY0FBSTJOLE1BQUosRUFBWTtBQUNWLGdCQUFJQyxVQUFKLEVBQWdCO0FBQ2Qsa0JBQUksQ0FBQ3hlLE1BQU0rUSxPQUFOLENBQWN1SixZQUFmLElBQWdDLENBQUN0YSxNQUFNK1EsT0FBTixDQUFjME4sU0FBZixJQUE0QixDQUFDTixRQUE3RCxJQUEyRW5lLE1BQU0rUSxPQUFOLENBQWMyTixXQUFkLElBQTZCUCxRQUE1RyxFQUF1SDtBQUFFO0FBQVMsZUFBbEksTUFDSztBQUNIcmMsa0JBQUV5Vyx3QkFBRjtBQUNBelcsa0JBQUV1SixjQUFGO0FBQ0FyTCxzQkFBTXViLEtBQU4sQ0FBWWphLEtBQVo7QUFDRDtBQUNGLGFBUEQsTUFPTztBQUNMUSxnQkFBRXVKLGNBQUY7QUFDQXZKLGdCQUFFeVcsd0JBQUY7QUFDQXZZLG9CQUFNcWEsS0FBTixDQUFZMUosSUFBWjtBQUNBclAsb0JBQU1tWCxHQUFOLENBQVVuWCxNQUFNa1gsWUFBTixDQUFtQnhZLE1BQU1oQixRQUF6QixRQUF1Q3FmLFFBQXZDLENBQVYsRUFBOERsZ0IsSUFBOUQsQ0FBbUUsZUFBbkUsRUFBb0YsSUFBcEY7QUFDRDtBQUNGO0FBQ0YsU0FyQkQ7O0FBdUJBLFlBQUksS0FBSzRTLE9BQUwsQ0FBYTBOLFNBQWIsSUFBMEJOLFFBQTlCLEVBQXdDO0FBQ3RDLGVBQUtuRixVQUFMLENBQWdCN04sRUFBaEIsQ0FBbUIsa0RBQW5CLEVBQXVFbVQsYUFBdkU7QUFDRDs7QUFFRDtBQUNBLFlBQUd0ZSxNQUFNK1EsT0FBTixDQUFjNE4sa0JBQWpCLEVBQW9DO0FBQ2xDLGVBQUszRixVQUFMLENBQWdCN04sRUFBaEIsQ0FBbUIsZ0RBQW5CLEVBQXFFLFVBQVNySixDQUFULEVBQVk7QUFDL0UsZ0JBQUlSLFFBQVExRCxFQUFFLElBQUYsQ0FBWjtBQUFBLGdCQUNJMmdCLFNBQVNqZCxNQUFNZ1csUUFBTixDQUFlK0csUUFBZixDQURiO0FBRUEsZ0JBQUcsQ0FBQ0UsTUFBSixFQUFXO0FBQ1R2ZSxvQkFBTXViLEtBQU47QUFDRDtBQUNGLFdBTkQ7QUFPRDs7QUFFRCxZQUFJLENBQUMsS0FBS3hLLE9BQUwsQ0FBYTZOLFlBQWxCLEVBQWdDO0FBQzlCLGVBQUs1RixVQUFMLENBQWdCN04sRUFBaEIsQ0FBbUIsNEJBQW5CLEVBQWlELFVBQVNySixDQUFULEVBQVk7QUFDM0QsZ0JBQUlSLFFBQVExRCxFQUFFLElBQUYsQ0FBWjtBQUFBLGdCQUNJMmdCLFNBQVNqZCxNQUFNZ1csUUFBTixDQUFlK0csUUFBZixDQURiOztBQUdBLGdCQUFJRSxNQUFKLEVBQVk7QUFDVmpaLDJCQUFhaEUsTUFBTXJDLElBQU4sQ0FBVyxRQUFYLENBQWI7QUFDQXFDLG9CQUFNckMsSUFBTixDQUFXLFFBQVgsRUFBcUI0RCxXQUFXLFlBQVc7QUFDekM3QyxzQkFBTXFhLEtBQU4sQ0FBWS9ZLE1BQU1zUCxRQUFOLENBQWUsc0JBQWYsQ0FBWjtBQUNELGVBRm9CLEVBRWxCNVEsTUFBTStRLE9BQU4sQ0FBY3VNLFVBRkksQ0FBckI7QUFHRDtBQUNGLFdBVkQsRUFVR25TLEVBVkgsQ0FVTSw0QkFWTixFQVVvQyxVQUFTckosQ0FBVCxFQUFZO0FBQzlDLGdCQUFJUixRQUFRMUQsRUFBRSxJQUFGLENBQVo7QUFBQSxnQkFDSTJnQixTQUFTamQsTUFBTWdXLFFBQU4sQ0FBZStHLFFBQWYsQ0FEYjtBQUVBLGdCQUFJRSxVQUFVdmUsTUFBTStRLE9BQU4sQ0FBYzhOLFNBQTVCLEVBQXVDO0FBQ3JDLGtCQUFJdmQsTUFBTW5ELElBQU4sQ0FBVyxlQUFYLE1BQWdDLE1BQWhDLElBQTBDNkIsTUFBTStRLE9BQU4sQ0FBYzBOLFNBQTVELEVBQXVFO0FBQUUsdUJBQU8sS0FBUDtBQUFlOztBQUV4Rm5aLDJCQUFhaEUsTUFBTXJDLElBQU4sQ0FBVyxRQUFYLENBQWI7QUFDQXFDLG9CQUFNckMsSUFBTixDQUFXLFFBQVgsRUFBcUI0RCxXQUFXLFlBQVc7QUFDekM3QyxzQkFBTXViLEtBQU4sQ0FBWWphLEtBQVo7QUFDRCxlQUZvQixFQUVsQnRCLE1BQU0rUSxPQUFOLENBQWMrTixXQUZJLENBQXJCO0FBR0Q7QUFDRixXQXJCRDtBQXNCRDtBQUNELGFBQUs5RixVQUFMLENBQWdCN04sRUFBaEIsQ0FBbUIseUJBQW5CLEVBQThDLFVBQVNySixDQUFULEVBQVk7QUFDeEQsY0FBSTlDLFdBQVdwQixFQUFFa0UsRUFBRXNKLE1BQUosRUFBWW9OLFlBQVosQ0FBeUIsSUFBekIsRUFBK0IsbUJBQS9CLENBQWY7QUFBQSxjQUNJdUcsUUFBUS9lLE1BQU04ZCxLQUFOLENBQVlrQixLQUFaLENBQWtCaGdCLFFBQWxCLElBQThCLENBQUMsQ0FEM0M7QUFBQSxjQUVJNFksWUFBWW1ILFFBQVEvZSxNQUFNOGQsS0FBZCxHQUFzQjllLFNBQVNpZ0IsUUFBVCxDQUFrQixJQUFsQixFQUF3QnhHLEdBQXhCLENBQTRCelosUUFBNUIsQ0FGdEM7QUFBQSxjQUdJNlksWUFISjtBQUFBLGNBSUlDLFlBSko7O0FBTUFGLG9CQUFVL1gsSUFBVixDQUFlLFVBQVN3QixDQUFULEVBQVk7QUFDekIsZ0JBQUl6RCxFQUFFLElBQUYsRUFBUStNLEVBQVIsQ0FBVzNMLFFBQVgsQ0FBSixFQUEwQjtBQUN4QjZZLDZCQUFlRCxVQUFVM00sRUFBVixDQUFhNUosSUFBRSxDQUFmLENBQWY7QUFDQXlXLDZCQUFlRixVQUFVM00sRUFBVixDQUFhNUosSUFBRSxDQUFmLENBQWY7QUFDQTtBQUNEO0FBQ0YsV0FORDs7QUFRQSxjQUFJNmQsY0FBYyxTQUFkQSxXQUFjLEdBQVc7QUFDM0IsZ0JBQUksQ0FBQ2xnQixTQUFTMkwsRUFBVCxDQUFZLGFBQVosQ0FBTCxFQUFpQztBQUMvQm1OLDJCQUFhbEgsUUFBYixDQUFzQixTQUF0QixFQUFpQ3RGLEtBQWpDO0FBQ0F4SixnQkFBRXVKLGNBQUY7QUFDRDtBQUNGLFdBTEQ7QUFBQSxjQUtHOFQsY0FBYyxTQUFkQSxXQUFjLEdBQVc7QUFDMUJ0SCx5QkFBYWpILFFBQWIsQ0FBc0IsU0FBdEIsRUFBaUN0RixLQUFqQztBQUNBeEosY0FBRXVKLGNBQUY7QUFDRCxXQVJEO0FBQUEsY0FRRytULFVBQVUsU0FBVkEsT0FBVSxHQUFXO0FBQ3RCLGdCQUFJek8sT0FBTzNSLFNBQVM0UixRQUFULENBQWtCLHdCQUFsQixDQUFYO0FBQ0EsZ0JBQUlELEtBQUtoUSxNQUFULEVBQWlCO0FBQ2ZYLG9CQUFNcWEsS0FBTixDQUFZMUosSUFBWjtBQUNBM1IsdUJBQVN1QyxJQUFULENBQWMsY0FBZCxFQUE4QitKLEtBQTlCO0FBQ0F4SixnQkFBRXVKLGNBQUY7QUFDRCxhQUpELE1BSU87QUFBRTtBQUFTO0FBQ25CLFdBZkQ7QUFBQSxjQWVHZ1UsV0FBVyxTQUFYQSxRQUFXLEdBQVc7QUFDdkI7QUFDQSxnQkFBSWxILFFBQVFuWixTQUFTOEgsTUFBVCxDQUFnQixJQUFoQixFQUFzQkEsTUFBdEIsQ0FBNkIsSUFBN0IsQ0FBWjtBQUNBcVIsa0JBQU12SCxRQUFOLENBQWUsU0FBZixFQUEwQnRGLEtBQTFCO0FBQ0F0TCxrQkFBTXViLEtBQU4sQ0FBWXBELEtBQVo7QUFDQXJXLGNBQUV1SixjQUFGO0FBQ0E7QUFDRCxXQXRCRDtBQXVCQSxjQUFJckIsWUFBWTtBQUNka08sa0JBQU1rSCxPQURRO0FBRWRqSCxtQkFBTyxpQkFBVztBQUNoQm5ZLG9CQUFNdWIsS0FBTixDQUFZdmIsTUFBTWhCLFFBQWxCO0FBQ0FnQixvQkFBTWdaLFVBQU4sQ0FBaUJ6WCxJQUFqQixDQUFzQixTQUF0QixFQUFpQytKLEtBQWpDLEdBRmdCLENBRTBCO0FBQzFDeEosZ0JBQUV1SixjQUFGO0FBQ0QsYUFOYTtBQU9kZCxxQkFBUyxtQkFBVztBQUNsQnpJLGdCQUFFeVcsd0JBQUY7QUFDRDtBQVRhLFdBQWhCOztBQVlBLGNBQUl3RyxLQUFKLEVBQVc7QUFDVCxnQkFBSS9lLE1BQU1zZixXQUFOLEVBQUosRUFBeUI7QUFBRTtBQUN6QixrQkFBSXhoQixXQUFXSSxHQUFYLEVBQUosRUFBc0I7QUFBRTtBQUN0Qk4sa0JBQUV5TSxNQUFGLENBQVNMLFNBQVQsRUFBb0I7QUFDbEJ3Tix3QkFBTTBILFdBRFk7QUFFbEI5RyxzQkFBSStHLFdBRmM7QUFHbEJsSCx3QkFBTW9ILFFBSFk7QUFJbEIvRCw0QkFBVThEO0FBSlEsaUJBQXBCO0FBTUQsZUFQRCxNQU9PO0FBQUU7QUFDUHhoQixrQkFBRXlNLE1BQUYsQ0FBU0wsU0FBVCxFQUFvQjtBQUNsQndOLHdCQUFNMEgsV0FEWTtBQUVsQjlHLHNCQUFJK0csV0FGYztBQUdsQmxILHdCQUFNbUgsT0FIWTtBQUlsQjlELDRCQUFVK0Q7QUFKUSxpQkFBcEI7QUFNRDtBQUNGLGFBaEJELE1BZ0JPO0FBQUU7QUFDUCxrQkFBSXZoQixXQUFXSSxHQUFYLEVBQUosRUFBc0I7QUFBRTtBQUN0Qk4sa0JBQUV5TSxNQUFGLENBQVNMLFNBQVQsRUFBb0I7QUFDbEJpTyx3QkFBTWtILFdBRFk7QUFFbEI3RCw0QkFBVTRELFdBRlE7QUFHbEIxSCx3QkFBTTRILE9BSFk7QUFJbEJoSCxzQkFBSWlIO0FBSmMsaUJBQXBCO0FBTUQsZUFQRCxNQU9PO0FBQUU7QUFDUHpoQixrQkFBRXlNLE1BQUYsQ0FBU0wsU0FBVCxFQUFvQjtBQUNsQmlPLHdCQUFNaUgsV0FEWTtBQUVsQjVELDRCQUFVNkQsV0FGUTtBQUdsQjNILHdCQUFNNEgsT0FIWTtBQUlsQmhILHNCQUFJaUg7QUFKYyxpQkFBcEI7QUFNRDtBQUNGO0FBQ0YsV0FsQ0QsTUFrQ087QUFBRTtBQUNQLGdCQUFJdmhCLFdBQVdJLEdBQVgsRUFBSixFQUFzQjtBQUFFO0FBQ3RCTixnQkFBRXlNLE1BQUYsQ0FBU0wsU0FBVCxFQUFvQjtBQUNsQmlPLHNCQUFNb0gsUUFEWTtBQUVsQi9ELDBCQUFVOEQsT0FGUTtBQUdsQjVILHNCQUFNMEgsV0FIWTtBQUlsQjlHLG9CQUFJK0c7QUFKYyxlQUFwQjtBQU1ELGFBUEQsTUFPTztBQUFFO0FBQ1B2aEIsZ0JBQUV5TSxNQUFGLENBQVNMLFNBQVQsRUFBb0I7QUFDbEJpTyxzQkFBTW1ILE9BRFk7QUFFbEI5RCwwQkFBVStELFFBRlE7QUFHbEI3SCxzQkFBTTBILFdBSFk7QUFJbEI5RyxvQkFBSStHO0FBSmMsZUFBcEI7QUFNRDtBQUNGO0FBQ0RyaEIscUJBQVdtTCxRQUFYLENBQW9CYSxTQUFwQixDQUE4QmhJLENBQTlCLEVBQWlDLGNBQWpDLEVBQWlEa0ksU0FBakQ7QUFFRCxTQXZHRDtBQXdHRDs7QUFFRDs7Ozs7O0FBblBXO0FBQUE7QUFBQSx3Q0F3UE87QUFDaEIsWUFBSXVRLFFBQVEzYyxFQUFFNEUsU0FBUzBGLElBQVgsQ0FBWjtBQUFBLFlBQ0lsSSxRQUFRLElBRFo7QUFFQXVhLGNBQU0vTyxHQUFOLENBQVUsa0RBQVYsRUFDTUwsRUFETixDQUNTLGtEQURULEVBQzZELFVBQVNySixDQUFULEVBQVk7QUFDbEUsY0FBSXNYLFFBQVFwWixNQUFNaEIsUUFBTixDQUFldUMsSUFBZixDQUFvQk8sRUFBRXNKLE1BQXRCLENBQVo7QUFDQSxjQUFJZ08sTUFBTXpZLE1BQVYsRUFBa0I7QUFBRTtBQUFTOztBQUU3QlgsZ0JBQU11YixLQUFOO0FBQ0FoQixnQkFBTS9PLEdBQU4sQ0FBVSxrREFBVjtBQUNELFNBUE47QUFRRDs7QUFFRDs7Ozs7Ozs7QUFyUVc7QUFBQTtBQUFBLDRCQTRRTG1GLElBNVFLLEVBNFFDO0FBQ1YsWUFBSTRPLE1BQU0sS0FBS3pCLEtBQUwsQ0FBV2tCLEtBQVgsQ0FBaUIsS0FBS2xCLEtBQUwsQ0FBV3BULE1BQVgsQ0FBa0IsVUFBU3JKLENBQVQsRUFBWVksRUFBWixFQUFnQjtBQUMzRCxpQkFBT3JFLEVBQUVxRSxFQUFGLEVBQU1WLElBQU4sQ0FBV29QLElBQVgsRUFBaUJoUSxNQUFqQixHQUEwQixDQUFqQztBQUNELFNBRjBCLENBQWpCLENBQVY7QUFHQSxZQUFJNmUsUUFBUTdPLEtBQUs3SixNQUFMLENBQVksK0JBQVosRUFBNkNtWSxRQUE3QyxDQUFzRCwrQkFBdEQsQ0FBWjtBQUNBLGFBQUsxRCxLQUFMLENBQVdpRSxLQUFYLEVBQWtCRCxHQUFsQjtBQUNBNU8sYUFBS3ZFLEdBQUwsQ0FBUyxZQUFULEVBQXVCLFFBQXZCLEVBQWlDd0QsUUFBakMsQ0FBMEMsb0JBQTFDLEVBQ0s5SSxNQURMLENBQ1ksK0JBRFosRUFDNkM4SSxRQUQ3QyxDQUNzRCxXQUR0RDtBQUVBLFlBQUk2UCxRQUFRM2hCLFdBQVcySSxHQUFYLENBQWVDLGdCQUFmLENBQWdDaUssSUFBaEMsRUFBc0MsSUFBdEMsRUFBNEMsSUFBNUMsQ0FBWjtBQUNBLFlBQUksQ0FBQzhPLEtBQUwsRUFBWTtBQUNWLGNBQUlDLFdBQVcsS0FBSzNPLE9BQUwsQ0FBYWtOLFNBQWIsS0FBMkIsTUFBM0IsR0FBb0MsUUFBcEMsR0FBK0MsT0FBOUQ7QUFBQSxjQUNJMEIsWUFBWWhQLEtBQUs3SixNQUFMLENBQVksNkJBQVosQ0FEaEI7QUFFQTZZLG9CQUFVOWIsV0FBVixXQUE4QjZiLFFBQTlCLEVBQTBDOVAsUUFBMUMsWUFBNEQsS0FBS21CLE9BQUwsQ0FBYWtOLFNBQXpFO0FBQ0F3QixrQkFBUTNoQixXQUFXMkksR0FBWCxDQUFlQyxnQkFBZixDQUFnQ2lLLElBQWhDLEVBQXNDLElBQXRDLEVBQTRDLElBQTVDLENBQVI7QUFDQSxjQUFJLENBQUM4TyxLQUFMLEVBQVk7QUFDVkUsc0JBQVU5YixXQUFWLFlBQStCLEtBQUtrTixPQUFMLENBQWFrTixTQUE1QyxFQUF5RHJPLFFBQXpELENBQWtFLGFBQWxFO0FBQ0Q7QUFDRCxlQUFLc08sT0FBTCxHQUFlLElBQWY7QUFDRDtBQUNEdk4sYUFBS3ZFLEdBQUwsQ0FBUyxZQUFULEVBQXVCLEVBQXZCO0FBQ0EsWUFBSSxLQUFLMkUsT0FBTCxDQUFhdUosWUFBakIsRUFBK0I7QUFBRSxlQUFLb0QsZUFBTDtBQUF5QjtBQUMxRDs7OztBQUlBLGFBQUsxZSxRQUFMLENBQWNFLE9BQWQsQ0FBc0Isc0JBQXRCLEVBQThDLENBQUN5UixJQUFELENBQTlDO0FBQ0Q7O0FBRUQ7Ozs7Ozs7O0FBeFNXO0FBQUE7QUFBQSw0QkErU0xyUCxLQS9TSyxFQStTRWllLEdBL1NGLEVBK1NPO0FBQ2hCLFlBQUlLLFFBQUo7QUFDQSxZQUFJdGUsU0FBU0EsTUFBTVgsTUFBbkIsRUFBMkI7QUFDekJpZixxQkFBV3RlLEtBQVg7QUFDRCxTQUZELE1BRU8sSUFBSWllLFFBQVFwYixTQUFaLEVBQXVCO0FBQzVCeWIscUJBQVcsS0FBSzlCLEtBQUwsQ0FBV2xJLEdBQVgsQ0FBZSxVQUFTdlUsQ0FBVCxFQUFZWSxFQUFaLEVBQWdCO0FBQ3hDLG1CQUFPWixNQUFNa2UsR0FBYjtBQUNELFdBRlUsQ0FBWDtBQUdELFNBSk0sTUFLRjtBQUNISyxxQkFBVyxLQUFLNWdCLFFBQWhCO0FBQ0Q7QUFDRCxZQUFJNmdCLG1CQUFtQkQsU0FBU3RJLFFBQVQsQ0FBa0IsV0FBbEIsS0FBa0NzSSxTQUFTcmUsSUFBVCxDQUFjLFlBQWQsRUFBNEJaLE1BQTVCLEdBQXFDLENBQTlGOztBQUVBLFlBQUlrZixnQkFBSixFQUFzQjtBQUNwQkQsbUJBQVNyZSxJQUFULENBQWMsY0FBZCxFQUE4QmtYLEdBQTlCLENBQWtDbUgsUUFBbEMsRUFBNEN6aEIsSUFBNUMsQ0FBaUQ7QUFDL0MsNkJBQWlCO0FBRDhCLFdBQWpELEVBRUcwRixXQUZILENBRWUsV0FGZjs7QUFJQStiLG1CQUFTcmUsSUFBVCxDQUFjLHVCQUFkLEVBQXVDc0MsV0FBdkMsQ0FBbUQsb0JBQW5EOztBQUVBLGNBQUksS0FBS3FhLE9BQUwsSUFBZ0IwQixTQUFTcmUsSUFBVCxDQUFjLGFBQWQsRUFBNkJaLE1BQWpELEVBQXlEO0FBQ3ZELGdCQUFJK2UsV0FBVyxLQUFLM08sT0FBTCxDQUFha04sU0FBYixLQUEyQixNQUEzQixHQUFvQyxPQUFwQyxHQUE4QyxNQUE3RDtBQUNBMkIscUJBQVNyZSxJQUFULENBQWMsK0JBQWQsRUFBK0NrWCxHQUEvQyxDQUFtRG1ILFFBQW5ELEVBQ1MvYixXQURULHdCQUMwQyxLQUFLa04sT0FBTCxDQUFha04sU0FEdkQsRUFFU3JPLFFBRlQsWUFFMkI4UCxRQUYzQjtBQUdBLGlCQUFLeEIsT0FBTCxHQUFlLEtBQWY7QUFDRDtBQUNEOzs7O0FBSUEsZUFBS2xmLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQixzQkFBdEIsRUFBOEMsQ0FBQzBnQixRQUFELENBQTlDO0FBQ0Q7QUFDRjs7QUFFRDs7Ozs7QUFuVlc7QUFBQTtBQUFBLGdDQXVWRDtBQUNSLGFBQUs1RyxVQUFMLENBQWdCeE4sR0FBaEIsQ0FBb0Isa0JBQXBCLEVBQXdDak0sVUFBeEMsQ0FBbUQsZUFBbkQsRUFDS3NFLFdBREwsQ0FDaUIsK0VBRGpCO0FBRUFqRyxVQUFFNEUsU0FBUzBGLElBQVgsRUFBaUJzRCxHQUFqQixDQUFxQixrQkFBckI7QUFDQTFOLG1CQUFXcVMsSUFBWCxDQUFnQlUsSUFBaEIsQ0FBcUIsS0FBSzdSLFFBQTFCLEVBQW9DLFVBQXBDO0FBQ0FsQixtQkFBV3NCLGdCQUFYLENBQTRCLElBQTVCO0FBQ0Q7QUE3VlU7O0FBQUE7QUFBQTs7QUFnV2I7Ozs7O0FBR0F3ZSxlQUFhN0csUUFBYixHQUF3QjtBQUN0Qjs7Ozs7QUFLQTZILGtCQUFjLEtBTlE7QUFPdEI7Ozs7O0FBS0FDLGVBQVcsSUFaVztBQWF0Qjs7Ozs7QUFLQXZCLGdCQUFZLEVBbEJVO0FBbUJ0Qjs7Ozs7QUFLQW1CLGVBQVcsS0F4Qlc7QUF5QnRCOzs7Ozs7QUFNQUssaUJBQWEsR0EvQlM7QUFnQ3RCOzs7OztBQUtBYixlQUFXLE1BckNXO0FBc0N0Qjs7Ozs7QUFLQTNELGtCQUFjLElBM0NRO0FBNEN0Qjs7Ozs7QUFLQXFFLHdCQUFvQixJQWpERTtBQWtEdEI7Ozs7O0FBS0FaLG1CQUFlLFVBdkRPO0FBd0R0Qjs7Ozs7QUFLQUMsZ0JBQVksYUE3RFU7QUE4RHRCOzs7OztBQUtBVSxpQkFBYTtBQW5FUyxHQUF4Qjs7QUFzRUE7QUFDQTVnQixhQUFXTSxNQUFYLENBQWtCd2YsWUFBbEIsRUFBZ0MsY0FBaEM7QUFFQyxDQTVhQSxDQTRhQ3BYLE1BNWFELENBQUQ7Q0NGQTs7Ozs7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViOzs7Ozs7OztBQUZhLE1BVVBraUIsU0FWTztBQVdYOzs7Ozs7O0FBT0EsdUJBQVlqWixPQUFaLEVBQXFCa0ssT0FBckIsRUFBOEI7QUFBQTs7QUFDNUIsV0FBSy9SLFFBQUwsR0FBZ0I2SCxPQUFoQjtBQUNBLFdBQUtrSyxPQUFMLEdBQWVuVCxFQUFFeU0sTUFBRixDQUFTLEVBQVQsRUFBYXlWLFVBQVUvSSxRQUF2QixFQUFpQyxLQUFLL1gsUUFBTCxDQUFjQyxJQUFkLEVBQWpDLEVBQXVEOFIsT0FBdkQsQ0FBZjtBQUNBLFdBQUtnUCxZQUFMLEdBQW9CbmlCLEdBQXBCO0FBQ0EsV0FBS29pQixTQUFMLEdBQWlCcGlCLEdBQWpCOztBQUVBLFdBQUtrQyxLQUFMO0FBQ0EsV0FBSzJYLE9BQUw7O0FBRUEzWixpQkFBV1ksY0FBWCxDQUEwQixJQUExQixFQUFnQyxXQUFoQztBQUNBWixpQkFBV21MLFFBQVgsQ0FBb0IyQixRQUFwQixDQUE2QixXQUE3QixFQUEwQztBQUN4QyxrQkFBVTtBQUQ4QixPQUExQztBQUlEOztBQUVEOzs7Ozs7O0FBbENXO0FBQUE7QUFBQSw4QkF1Q0g7QUFDTixZQUFJNkMsS0FBSyxLQUFLek8sUUFBTCxDQUFjYixJQUFkLENBQW1CLElBQW5CLENBQVQ7O0FBRUEsYUFBS2EsUUFBTCxDQUFjYixJQUFkLENBQW1CLGFBQW5CLEVBQWtDLE1BQWxDOztBQUVBLGFBQUthLFFBQUwsQ0FBYzRRLFFBQWQsb0JBQXdDLEtBQUttQixPQUFMLENBQWFrUCxVQUFyRDs7QUFFQTtBQUNBLGFBQUtELFNBQUwsR0FBaUJwaUIsRUFBRTRFLFFBQUYsRUFDZGpCLElBRGMsQ0FDVCxpQkFBZWtNLEVBQWYsR0FBa0IsbUJBQWxCLEdBQXNDQSxFQUF0QyxHQUF5QyxvQkFBekMsR0FBOERBLEVBQTlELEdBQWlFLElBRHhELEVBRWR0UCxJQUZjLENBRVQsZUFGUyxFQUVRLE9BRlIsRUFHZEEsSUFIYyxDQUdULGVBSFMsRUFHUXNQLEVBSFIsQ0FBakI7O0FBS0E7QUFDQSxZQUFJLEtBQUtzRCxPQUFMLENBQWFtUCxjQUFiLEtBQWdDLElBQXBDLEVBQTBDO0FBQ3hDLGNBQUlDLFVBQVUzZCxTQUFTQyxhQUFULENBQXVCLEtBQXZCLENBQWQ7QUFDQSxjQUFJMmQsa0JBQWtCeGlCLEVBQUUsS0FBS29CLFFBQVAsRUFBaUJvTixHQUFqQixDQUFxQixVQUFyQixNQUFxQyxPQUFyQyxHQUErQyxrQkFBL0MsR0FBb0UscUJBQTFGO0FBQ0ErVCxrQkFBUUUsWUFBUixDQUFxQixPQUFyQixFQUE4QiwyQkFBMkJELGVBQXpEO0FBQ0EsZUFBS0UsUUFBTCxHQUFnQjFpQixFQUFFdWlCLE9BQUYsQ0FBaEI7QUFDQSxjQUFHQyxvQkFBb0Isa0JBQXZCLEVBQTJDO0FBQ3pDeGlCLGNBQUUsTUFBRixFQUFVZ2MsTUFBVixDQUFpQixLQUFLMEcsUUFBdEI7QUFDRCxXQUZELE1BRU87QUFDTCxpQkFBS3RoQixRQUFMLENBQWNpZ0IsUUFBZCxDQUF1QiwyQkFBdkIsRUFBb0RyRixNQUFwRCxDQUEyRCxLQUFLMEcsUUFBaEU7QUFDRDtBQUNGOztBQUVELGFBQUt2UCxPQUFMLENBQWF3UCxVQUFiLEdBQTBCLEtBQUt4UCxPQUFMLENBQWF3UCxVQUFiLElBQTJCLElBQUlDLE1BQUosQ0FBVyxLQUFLelAsT0FBTCxDQUFhMFAsV0FBeEIsRUFBcUMsR0FBckMsRUFBMEMxYixJQUExQyxDQUErQyxLQUFLL0YsUUFBTCxDQUFjLENBQWQsRUFBaUJWLFNBQWhFLENBQXJEOztBQUVBLFlBQUksS0FBS3lTLE9BQUwsQ0FBYXdQLFVBQWIsS0FBNEIsSUFBaEMsRUFBc0M7QUFDcEMsZUFBS3hQLE9BQUwsQ0FBYTJQLFFBQWIsR0FBd0IsS0FBSzNQLE9BQUwsQ0FBYTJQLFFBQWIsSUFBeUIsS0FBSzFoQixRQUFMLENBQWMsQ0FBZCxFQUFpQlYsU0FBakIsQ0FBMkJtZSxLQUEzQixDQUFpQyx1Q0FBakMsRUFBMEUsQ0FBMUUsRUFBNkU1YSxLQUE3RSxDQUFtRixHQUFuRixFQUF3RixDQUF4RixDQUFqRDtBQUNBLGVBQUs4ZSxhQUFMO0FBQ0Q7QUFDRCxZQUFJLENBQUMsS0FBSzVQLE9BQUwsQ0FBYTZQLGNBQWQsS0FBaUMsSUFBckMsRUFBMkM7QUFDekMsZUFBSzdQLE9BQUwsQ0FBYTZQLGNBQWIsR0FBOEJ0YSxXQUFXaEMsT0FBT3FKLGdCQUFQLENBQXdCL1AsRUFBRSxtQkFBRixFQUF1QixDQUF2QixDQUF4QixFQUFtRHNTLGtCQUE5RCxJQUFvRixJQUFsSDtBQUNEO0FBQ0Y7O0FBRUQ7Ozs7OztBQTVFVztBQUFBO0FBQUEsZ0NBaUZEO0FBQ1IsYUFBS2xSLFFBQUwsQ0FBY3dNLEdBQWQsQ0FBa0IsMkJBQWxCLEVBQStDTCxFQUEvQyxDQUFrRDtBQUNoRCw2QkFBbUIsS0FBSytNLElBQUwsQ0FBVXhTLElBQVYsQ0FBZSxJQUFmLENBRDZCO0FBRWhELDhCQUFvQixLQUFLeVMsS0FBTCxDQUFXelMsSUFBWCxDQUFnQixJQUFoQixDQUY0QjtBQUdoRCwrQkFBcUIsS0FBS2lTLE1BQUwsQ0FBWWpTLElBQVosQ0FBaUIsSUFBakIsQ0FIMkI7QUFJaEQsa0NBQXdCLEtBQUttYixlQUFMLENBQXFCbmIsSUFBckIsQ0FBMEIsSUFBMUI7QUFKd0IsU0FBbEQ7O0FBT0EsWUFBSSxLQUFLcUwsT0FBTCxDQUFhdUosWUFBYixLQUE4QixJQUFsQyxFQUF3QztBQUN0QyxjQUFJbkUsVUFBVSxLQUFLcEYsT0FBTCxDQUFhbVAsY0FBYixHQUE4QixLQUFLSSxRQUFuQyxHQUE4QzFpQixFQUFFLDJCQUFGLENBQTVEO0FBQ0F1WSxrQkFBUWhMLEVBQVIsQ0FBVyxFQUFDLHNCQUFzQixLQUFLZ04sS0FBTCxDQUFXelMsSUFBWCxDQUFnQixJQUFoQixDQUF2QixFQUFYO0FBQ0Q7QUFDRjs7QUFFRDs7Ozs7QUEvRlc7QUFBQTtBQUFBLHNDQW1HSztBQUNkLFlBQUkxRixRQUFRLElBQVo7O0FBRUFwQyxVQUFFMEcsTUFBRixFQUFVNkcsRUFBVixDQUFhLHVCQUFiLEVBQXNDLFlBQVc7QUFDL0MsY0FBSXJOLFdBQVdnRyxVQUFYLENBQXNCNkksT0FBdEIsQ0FBOEIzTSxNQUFNK1EsT0FBTixDQUFjMlAsUUFBNUMsQ0FBSixFQUEyRDtBQUN6RDFnQixrQkFBTThnQixNQUFOLENBQWEsSUFBYjtBQUNELFdBRkQsTUFFTztBQUNMOWdCLGtCQUFNOGdCLE1BQU4sQ0FBYSxLQUFiO0FBQ0Q7QUFDRixTQU5ELEVBTUcvUSxHQU5ILENBTU8sbUJBTlAsRUFNNEIsWUFBVztBQUNyQyxjQUFJalMsV0FBV2dHLFVBQVgsQ0FBc0I2SSxPQUF0QixDQUE4QjNNLE1BQU0rUSxPQUFOLENBQWMyUCxRQUE1QyxDQUFKLEVBQTJEO0FBQ3pEMWdCLGtCQUFNOGdCLE1BQU4sQ0FBYSxJQUFiO0FBQ0Q7QUFDRixTQVZEO0FBV0Q7O0FBRUQ7Ozs7OztBQW5IVztBQUFBO0FBQUEsNkJBd0hKUCxVQXhISSxFQXdIUTtBQUNqQixZQUFJUSxVQUFVLEtBQUsvaEIsUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixjQUFuQixDQUFkO0FBQ0EsWUFBSWdmLFVBQUosRUFBZ0I7QUFDZCxlQUFLcEksS0FBTDtBQUNBLGVBQUtvSSxVQUFMLEdBQWtCLElBQWxCO0FBQ0EsZUFBS3ZoQixRQUFMLENBQWNiLElBQWQsQ0FBbUIsYUFBbkIsRUFBa0MsT0FBbEM7QUFDQSxlQUFLYSxRQUFMLENBQWN3TSxHQUFkLENBQWtCLG1DQUFsQjtBQUNBLGNBQUl1VixRQUFRcGdCLE1BQVosRUFBb0I7QUFBRW9nQixvQkFBUTlRLElBQVI7QUFBaUI7QUFDeEMsU0FORCxNQU1PO0FBQ0wsZUFBS3NRLFVBQUwsR0FBa0IsS0FBbEI7QUFDQSxlQUFLdmhCLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixhQUFuQixFQUFrQyxNQUFsQztBQUNBLGVBQUthLFFBQUwsQ0FBY21NLEVBQWQsQ0FBaUI7QUFDZiwrQkFBbUIsS0FBSytNLElBQUwsQ0FBVXhTLElBQVYsQ0FBZSxJQUFmLENBREo7QUFFZixpQ0FBcUIsS0FBS2lTLE1BQUwsQ0FBWWpTLElBQVosQ0FBaUIsSUFBakI7QUFGTixXQUFqQjtBQUlBLGNBQUlxYixRQUFRcGdCLE1BQVosRUFBb0I7QUFDbEJvZ0Isb0JBQVFsUixJQUFSO0FBQ0Q7QUFDRjtBQUNGOztBQUVEOzs7OztBQTdJVztBQUFBO0FBQUEscUNBaUpJekcsS0FqSkosRUFpSlc7QUFDckIsZUFBTyxLQUFQO0FBQ0E7O0FBRUQ7Ozs7Ozs7O0FBckpXO0FBQUE7QUFBQSwyQkE0Sk5BLEtBNUpNLEVBNEpDbEssT0E1SkQsRUE0SlU7QUFDbkIsWUFBSSxLQUFLRixRQUFMLENBQWNzWSxRQUFkLENBQXVCLFNBQXZCLEtBQXFDLEtBQUtpSixVQUE5QyxFQUEwRDtBQUFFO0FBQVM7QUFDckUsWUFBSXZnQixRQUFRLElBQVo7O0FBRUEsWUFBSWQsT0FBSixFQUFhO0FBQ1gsZUFBSzZnQixZQUFMLEdBQW9CN2dCLE9BQXBCO0FBQ0Q7O0FBRUQsWUFBSSxLQUFLNlIsT0FBTCxDQUFhaVEsT0FBYixLQUF5QixLQUE3QixFQUFvQztBQUNsQzFjLGlCQUFPMmMsUUFBUCxDQUFnQixDQUFoQixFQUFtQixDQUFuQjtBQUNELFNBRkQsTUFFTyxJQUFJLEtBQUtsUSxPQUFMLENBQWFpUSxPQUFiLEtBQXlCLFFBQTdCLEVBQXVDO0FBQzVDMWMsaUJBQU8yYyxRQUFQLENBQWdCLENBQWhCLEVBQWtCemUsU0FBUzBGLElBQVQsQ0FBY2daLFlBQWhDO0FBQ0Q7O0FBRUQ7Ozs7QUFJQWxoQixjQUFNaEIsUUFBTixDQUFlNFEsUUFBZixDQUF3QixTQUF4Qjs7QUFFQSxhQUFLb1EsU0FBTCxDQUFlN2hCLElBQWYsQ0FBb0IsZUFBcEIsRUFBcUMsTUFBckM7QUFDQSxhQUFLYSxRQUFMLENBQWNiLElBQWQsQ0FBbUIsYUFBbkIsRUFBa0MsT0FBbEMsRUFDS2UsT0FETCxDQUNhLHFCQURiOztBQUdBO0FBQ0EsWUFBSSxLQUFLNlIsT0FBTCxDQUFhb1EsYUFBYixLQUErQixLQUFuQyxFQUEwQztBQUN4Q3ZqQixZQUFFLE1BQUYsRUFBVWdTLFFBQVYsQ0FBbUIsb0JBQW5CLEVBQXlDekUsRUFBekMsQ0FBNEMsV0FBNUMsRUFBeUQsS0FBS2lXLGNBQTlEO0FBQ0Q7O0FBRUQsWUFBSSxLQUFLclEsT0FBTCxDQUFhbVAsY0FBYixLQUFnQyxJQUFwQyxFQUEwQztBQUN4QyxlQUFLSSxRQUFMLENBQWMxUSxRQUFkLENBQXVCLFlBQXZCO0FBQ0Q7O0FBRUQsWUFBSSxLQUFLbUIsT0FBTCxDQUFhdUosWUFBYixLQUE4QixJQUE5QixJQUFzQyxLQUFLdkosT0FBTCxDQUFhbVAsY0FBYixLQUFnQyxJQUExRSxFQUFnRjtBQUM5RSxlQUFLSSxRQUFMLENBQWMxUSxRQUFkLENBQXVCLGFBQXZCO0FBQ0Q7O0FBRUQsWUFBSSxLQUFLbUIsT0FBTCxDQUFhME0sU0FBYixLQUEyQixJQUEvQixFQUFxQztBQUNuQyxlQUFLemUsUUFBTCxDQUFjK1EsR0FBZCxDQUFrQmpTLFdBQVd3RSxhQUFYLENBQXlCLEtBQUt0RCxRQUE5QixDQUFsQixFQUEyRCxZQUFXO0FBQ3BFZ0Isa0JBQU1oQixRQUFOLENBQWV1QyxJQUFmLENBQW9CLFdBQXBCLEVBQWlDMEosRUFBakMsQ0FBb0MsQ0FBcEMsRUFBdUNLLEtBQXZDO0FBQ0QsV0FGRDtBQUdEOztBQUVELFlBQUksS0FBS3lGLE9BQUwsQ0FBYWpHLFNBQWIsS0FBMkIsSUFBL0IsRUFBcUM7QUFDbkMsZUFBSzlMLFFBQUwsQ0FBY2lnQixRQUFkLENBQXVCLDJCQUF2QixFQUFvRDlnQixJQUFwRCxDQUF5RCxVQUF6RCxFQUFxRSxJQUFyRTtBQUNBTCxxQkFBV21MLFFBQVgsQ0FBb0I2QixTQUFwQixDQUE4QixLQUFLOUwsUUFBbkM7QUFDRDtBQUNGOztBQUVEOzs7Ozs7O0FBN01XO0FBQUE7QUFBQSw0QkFtTkwrUCxFQW5OSyxFQW1ORDtBQUNSLFlBQUksQ0FBQyxLQUFLL1AsUUFBTCxDQUFjc1ksUUFBZCxDQUF1QixTQUF2QixDQUFELElBQXNDLEtBQUtpSixVQUEvQyxFQUEyRDtBQUFFO0FBQVM7O0FBRXRFLFlBQUl2Z0IsUUFBUSxJQUFaOztBQUVBQSxjQUFNaEIsUUFBTixDQUFlNkUsV0FBZixDQUEyQixTQUEzQjs7QUFFQSxhQUFLN0UsUUFBTCxDQUFjYixJQUFkLENBQW1CLGFBQW5CLEVBQWtDLE1BQWxDO0FBQ0U7Ozs7QUFERixTQUtLZSxPQUxMLENBS2EscUJBTGI7O0FBT0E7QUFDQSxZQUFJLEtBQUs2UixPQUFMLENBQWFvUSxhQUFiLEtBQStCLEtBQW5DLEVBQTBDO0FBQ3hDdmpCLFlBQUUsTUFBRixFQUFVaUcsV0FBVixDQUFzQixvQkFBdEIsRUFBNEMySCxHQUE1QyxDQUFnRCxXQUFoRCxFQUE2RCxLQUFLNFYsY0FBbEU7QUFDRDs7QUFFRCxZQUFJLEtBQUtyUSxPQUFMLENBQWFtUCxjQUFiLEtBQWdDLElBQXBDLEVBQTBDO0FBQ3hDLGVBQUtJLFFBQUwsQ0FBY3pjLFdBQWQsQ0FBMEIsWUFBMUI7QUFDRDs7QUFFRCxZQUFJLEtBQUtrTixPQUFMLENBQWF1SixZQUFiLEtBQThCLElBQTlCLElBQXNDLEtBQUt2SixPQUFMLENBQWFtUCxjQUFiLEtBQWdDLElBQTFFLEVBQWdGO0FBQzlFLGVBQUtJLFFBQUwsQ0FBY3pjLFdBQWQsQ0FBMEIsYUFBMUI7QUFDRDs7QUFFRCxhQUFLbWMsU0FBTCxDQUFlN2hCLElBQWYsQ0FBb0IsZUFBcEIsRUFBcUMsT0FBckM7O0FBRUEsWUFBSSxLQUFLNFMsT0FBTCxDQUFhakcsU0FBYixLQUEyQixJQUEvQixFQUFxQztBQUNuQyxlQUFLOUwsUUFBTCxDQUFjaWdCLFFBQWQsQ0FBdUIsMkJBQXZCLEVBQW9EMWYsVUFBcEQsQ0FBK0QsVUFBL0Q7QUFDQXpCLHFCQUFXbUwsUUFBWCxDQUFvQnNDLFlBQXBCLENBQWlDLEtBQUt2TSxRQUF0QztBQUNEO0FBQ0Y7O0FBRUQ7Ozs7Ozs7QUF0UFc7QUFBQTtBQUFBLDZCQTRQSm9LLEtBNVBJLEVBNFBHbEssT0E1UEgsRUE0UFk7QUFDckIsWUFBSSxLQUFLRixRQUFMLENBQWNzWSxRQUFkLENBQXVCLFNBQXZCLENBQUosRUFBdUM7QUFDckMsZUFBS2EsS0FBTCxDQUFXL08sS0FBWCxFQUFrQmxLLE9BQWxCO0FBQ0QsU0FGRCxNQUdLO0FBQ0gsZUFBS2daLElBQUwsQ0FBVTlPLEtBQVYsRUFBaUJsSyxPQUFqQjtBQUNEO0FBQ0Y7O0FBRUQ7Ozs7OztBQXJRVztBQUFBO0FBQUEsc0NBMFFLNEMsQ0ExUUwsRUEwUVE7QUFBQTs7QUFDakJoRSxtQkFBV21MLFFBQVgsQ0FBb0JhLFNBQXBCLENBQThCaEksQ0FBOUIsRUFBaUMsV0FBakMsRUFBOEM7QUFDNUNxVyxpQkFBTyxpQkFBTTtBQUNYLG1CQUFLQSxLQUFMO0FBQ0EsbUJBQUs0SCxZQUFMLENBQWtCelUsS0FBbEI7QUFDQSxtQkFBTyxJQUFQO0FBQ0QsV0FMMkM7QUFNNUNmLG1CQUFTLG1CQUFNO0FBQ2J6SSxjQUFFaVQsZUFBRjtBQUNBalQsY0FBRXVKLGNBQUY7QUFDRDtBQVQyQyxTQUE5QztBQVdEOztBQUVEOzs7OztBQXhSVztBQUFBO0FBQUEsZ0NBNFJEO0FBQ1IsYUFBSzhNLEtBQUw7QUFDQSxhQUFLblosUUFBTCxDQUFjd00sR0FBZCxDQUFrQiwyQkFBbEI7QUFDQSxhQUFLOFUsUUFBTCxDQUFjOVUsR0FBZCxDQUFrQixlQUFsQjs7QUFFQTFOLG1CQUFXc0IsZ0JBQVgsQ0FBNEIsSUFBNUI7QUFDRDtBQWxTVTs7QUFBQTtBQUFBOztBQXFTYjBnQixZQUFVL0ksUUFBVixHQUFxQjtBQUNuQjs7Ozs7QUFLQXVELGtCQUFjLElBTks7O0FBUW5COzs7OztBQUtBNEYsb0JBQWdCLElBYkc7O0FBZW5COzs7OztBQUtBaUIsbUJBQWUsSUFwQkk7O0FBc0JuQjs7Ozs7QUFLQVAsb0JBQWdCLENBM0JHOztBQTZCbkI7Ozs7O0FBS0FYLGdCQUFZLE1BbENPOztBQW9DbkI7Ozs7O0FBS0FlLGFBQVMsSUF6Q1U7O0FBMkNuQjs7Ozs7QUFLQVQsZ0JBQVksS0FoRE87O0FBa0RuQjs7Ozs7QUFLQUcsY0FBVSxJQXZEUzs7QUF5RG5COzs7OztBQUtBakQsZUFBVyxJQTlEUTs7QUFnRW5COzs7Ozs7QUFNQWdELGlCQUFhLGFBdEVNOztBQXdFbkI7Ozs7O0FBS0EzVixlQUFXOztBQUdiO0FBaEZxQixHQUFyQixDQWlGQWhOLFdBQVdNLE1BQVgsQ0FBa0IwaEIsU0FBbEIsRUFBNkIsV0FBN0I7QUFFQyxDQXhYQSxDQXdYQ3RaLE1BeFhELENBQUQ7Q0NGQTs7Ozs7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViOzs7Ozs7Ozs7O0FBRmEsTUFZUHlqQixjQVpPO0FBYVg7Ozs7Ozs7QUFPQSw0QkFBWXhhLE9BQVosRUFBcUJrSyxPQUFyQixFQUE4QjtBQUFBOztBQUM1QixXQUFLL1IsUUFBTCxHQUFnQnBCLEVBQUVpSixPQUFGLENBQWhCO0FBQ0EsV0FBS3lhLEtBQUwsR0FBYSxLQUFLdGlCLFFBQUwsQ0FBY0MsSUFBZCxDQUFtQixpQkFBbkIsQ0FBYjtBQUNBLFdBQUtzaUIsU0FBTCxHQUFpQixJQUFqQjtBQUNBLFdBQUtDLGFBQUwsR0FBcUIsSUFBckI7O0FBRUEsV0FBSzFoQixLQUFMO0FBQ0EsV0FBSzJYLE9BQUw7O0FBRUEzWixpQkFBV1ksY0FBWCxDQUEwQixJQUExQixFQUFnQyxnQkFBaEM7QUFDRDs7QUFFRDs7Ozs7OztBQWhDVztBQUFBO0FBQUEsOEJBcUNIO0FBQ047QUFDQSxZQUFJLE9BQU8sS0FBSzRpQixLQUFaLEtBQXNCLFFBQTFCLEVBQW9DO0FBQ2xDLGNBQUlHLFlBQVksRUFBaEI7O0FBRUE7QUFDQSxjQUFJSCxRQUFRLEtBQUtBLEtBQUwsQ0FBV3pmLEtBQVgsQ0FBaUIsR0FBakIsQ0FBWjs7QUFFQTtBQUNBLGVBQUssSUFBSVIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJaWdCLE1BQU0zZ0IsTUFBMUIsRUFBa0NVLEdBQWxDLEVBQXVDO0FBQ3JDLGdCQUFJcWdCLE9BQU9KLE1BQU1qZ0IsQ0FBTixFQUFTUSxLQUFULENBQWUsR0FBZixDQUFYO0FBQ0EsZ0JBQUk4ZixXQUFXRCxLQUFLL2dCLE1BQUwsR0FBYyxDQUFkLEdBQWtCK2dCLEtBQUssQ0FBTCxDQUFsQixHQUE0QixPQUEzQztBQUNBLGdCQUFJRSxhQUFhRixLQUFLL2dCLE1BQUwsR0FBYyxDQUFkLEdBQWtCK2dCLEtBQUssQ0FBTCxDQUFsQixHQUE0QkEsS0FBSyxDQUFMLENBQTdDOztBQUVBLGdCQUFJRyxZQUFZRCxVQUFaLE1BQTRCLElBQWhDLEVBQXNDO0FBQ3BDSCx3QkFBVUUsUUFBVixJQUFzQkUsWUFBWUQsVUFBWixDQUF0QjtBQUNEO0FBQ0Y7O0FBRUQsZUFBS04sS0FBTCxHQUFhRyxTQUFiO0FBQ0Q7O0FBRUQsWUFBSSxDQUFDN2pCLEVBQUVra0IsYUFBRixDQUFnQixLQUFLUixLQUFyQixDQUFMLEVBQWtDO0FBQ2hDLGVBQUtTLGtCQUFMO0FBQ0Q7QUFDRDtBQUNBLGFBQUsvaUIsUUFBTCxDQUFjYixJQUFkLENBQW1CLGFBQW5CLEVBQW1DLEtBQUthLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixhQUFuQixLQUFxQ0wsV0FBV2lCLFdBQVgsQ0FBdUIsQ0FBdkIsRUFBMEIsaUJBQTFCLENBQXhFO0FBQ0Q7O0FBRUQ7Ozs7OztBQWxFVztBQUFBO0FBQUEsZ0NBdUVEO0FBQ1IsWUFBSWlCLFFBQVEsSUFBWjs7QUFFQXBDLFVBQUUwRyxNQUFGLEVBQVU2RyxFQUFWLENBQWEsdUJBQWIsRUFBc0MsWUFBVztBQUMvQ25MLGdCQUFNK2hCLGtCQUFOO0FBQ0QsU0FGRDtBQUdBO0FBQ0E7QUFDQTtBQUNEOztBQUVEOzs7Ozs7QUFsRlc7QUFBQTtBQUFBLDJDQXVGVTtBQUNuQixZQUFJQyxTQUFKO0FBQUEsWUFBZWhpQixRQUFRLElBQXZCO0FBQ0E7QUFDQXBDLFVBQUVpQyxJQUFGLENBQU8sS0FBS3loQixLQUFaLEVBQW1CLFVBQVNqWSxHQUFULEVBQWM7QUFDL0IsY0FBSXZMLFdBQVdnRyxVQUFYLENBQXNCNkksT0FBdEIsQ0FBOEJ0RCxHQUE5QixDQUFKLEVBQXdDO0FBQ3RDMlksd0JBQVkzWSxHQUFaO0FBQ0Q7QUFDRixTQUpEOztBQU1BO0FBQ0EsWUFBSSxDQUFDMlksU0FBTCxFQUFnQjs7QUFFaEI7QUFDQSxZQUFJLEtBQUtSLGFBQUwsWUFBOEIsS0FBS0YsS0FBTCxDQUFXVSxTQUFYLEVBQXNCNWpCLE1BQXhELEVBQWdFOztBQUVoRTtBQUNBUixVQUFFaUMsSUFBRixDQUFPZ2lCLFdBQVAsRUFBb0IsVUFBU3hZLEdBQVQsRUFBY21ELEtBQWQsRUFBcUI7QUFDdkN4TSxnQkFBTWhCLFFBQU4sQ0FBZTZFLFdBQWYsQ0FBMkIySSxNQUFNeVYsUUFBakM7QUFDRCxTQUZEOztBQUlBO0FBQ0EsYUFBS2pqQixRQUFMLENBQWM0USxRQUFkLENBQXVCLEtBQUswUixLQUFMLENBQVdVLFNBQVgsRUFBc0JDLFFBQTdDOztBQUVBO0FBQ0EsWUFBSSxLQUFLVCxhQUFULEVBQXdCLEtBQUtBLGFBQUwsQ0FBbUJVLE9BQW5CO0FBQ3hCLGFBQUtWLGFBQUwsR0FBcUIsSUFBSSxLQUFLRixLQUFMLENBQVdVLFNBQVgsRUFBc0I1akIsTUFBMUIsQ0FBaUMsS0FBS1ksUUFBdEMsRUFBZ0QsRUFBaEQsQ0FBckI7QUFDRDs7QUFFRDs7Ozs7QUFuSFc7QUFBQTtBQUFBLGdDQXVIRDtBQUNSLGFBQUt3aUIsYUFBTCxDQUFtQlUsT0FBbkI7QUFDQXRrQixVQUFFMEcsTUFBRixFQUFVa0gsR0FBVixDQUFjLG9CQUFkO0FBQ0ExTixtQkFBV3NCLGdCQUFYLENBQTRCLElBQTVCO0FBQ0Q7QUEzSFU7O0FBQUE7QUFBQTs7QUE4SGJpaUIsaUJBQWV0SyxRQUFmLEdBQTBCLEVBQTFCOztBQUVBO0FBQ0EsTUFBSThLLGNBQWM7QUFDaEJNLGNBQVU7QUFDUkYsZ0JBQVUsVUFERjtBQUVSN2pCLGNBQVFOLFdBQVdFLFFBQVgsQ0FBb0IsZUFBcEIsS0FBd0M7QUFGeEMsS0FETTtBQUtqQm9rQixlQUFXO0FBQ1JILGdCQUFVLFdBREY7QUFFUjdqQixjQUFRTixXQUFXRSxRQUFYLENBQW9CLFdBQXBCLEtBQW9DO0FBRnBDLEtBTE07QUFTaEJxa0IsZUFBVztBQUNUSixnQkFBVSxnQkFERDtBQUVUN2pCLGNBQVFOLFdBQVdFLFFBQVgsQ0FBb0IsZ0JBQXBCLEtBQXlDO0FBRnhDO0FBVEssR0FBbEI7O0FBZUE7QUFDQUYsYUFBV00sTUFBWCxDQUFrQmlqQixjQUFsQixFQUFrQyxnQkFBbEM7QUFFQyxDQW5KQSxDQW1KQzdhLE1BbkpELENBQUQ7Q0NGQTs7Ozs7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViOzs7Ozs7QUFGYSxNQVFQMGtCLGdCQVJPO0FBU1g7Ozs7Ozs7QUFPQSw4QkFBWXpiLE9BQVosRUFBcUJrSyxPQUFyQixFQUE4QjtBQUFBOztBQUM1QixXQUFLL1IsUUFBTCxHQUFnQnBCLEVBQUVpSixPQUFGLENBQWhCO0FBQ0EsV0FBS2tLLE9BQUwsR0FBZW5ULEVBQUV5TSxNQUFGLENBQVMsRUFBVCxFQUFhaVksaUJBQWlCdkwsUUFBOUIsRUFBd0MsS0FBSy9YLFFBQUwsQ0FBY0MsSUFBZCxFQUF4QyxFQUE4RDhSLE9BQTlELENBQWY7O0FBRUEsV0FBS2pSLEtBQUw7QUFDQSxXQUFLMlgsT0FBTDs7QUFFQTNaLGlCQUFXWSxjQUFYLENBQTBCLElBQTFCLEVBQWdDLGtCQUFoQztBQUNEOztBQUVEOzs7Ozs7O0FBMUJXO0FBQUE7QUFBQSw4QkErQkg7QUFDTixZQUFJNmpCLFdBQVcsS0FBS3ZqQixRQUFMLENBQWNDLElBQWQsQ0FBbUIsbUJBQW5CLENBQWY7QUFDQSxZQUFJLENBQUNzakIsUUFBTCxFQUFlO0FBQ2I5aEIsa0JBQVFDLEtBQVIsQ0FBYyxrRUFBZDtBQUNEOztBQUVELGFBQUs4aEIsV0FBTCxHQUFtQjVrQixRQUFNMmtCLFFBQU4sQ0FBbkI7QUFDQSxhQUFLRSxRQUFMLEdBQWdCLEtBQUt6akIsUUFBTCxDQUFjdUMsSUFBZCxDQUFtQixlQUFuQixDQUFoQjtBQUNBLGFBQUt3UCxPQUFMLEdBQWVuVCxFQUFFeU0sTUFBRixDQUFTLEVBQVQsRUFBYSxLQUFLMEcsT0FBbEIsRUFBMkIsS0FBS3lSLFdBQUwsQ0FBaUJ2akIsSUFBakIsRUFBM0IsQ0FBZjs7QUFFQTtBQUNBLFlBQUcsS0FBSzhSLE9BQUwsQ0FBYS9CLE9BQWhCLEVBQXlCO0FBQ3ZCLGNBQUkwVCxRQUFRLEtBQUszUixPQUFMLENBQWEvQixPQUFiLENBQXFCbk4sS0FBckIsQ0FBMkIsR0FBM0IsQ0FBWjs7QUFFQSxlQUFLOGdCLFdBQUwsR0FBbUJELE1BQU0sQ0FBTixDQUFuQjtBQUNBLGVBQUtFLFlBQUwsR0FBb0JGLE1BQU0sQ0FBTixLQUFZLElBQWhDO0FBQ0Q7O0FBRUQsYUFBS0csT0FBTDtBQUNEOztBQUVEOzs7Ozs7QUFwRFc7QUFBQTtBQUFBLGdDQXlERDtBQUNSLFlBQUk3aUIsUUFBUSxJQUFaOztBQUVBLGFBQUs4aUIsZ0JBQUwsR0FBd0IsS0FBS0QsT0FBTCxDQUFhbmQsSUFBYixDQUFrQixJQUFsQixDQUF4Qjs7QUFFQTlILFVBQUUwRyxNQUFGLEVBQVU2RyxFQUFWLENBQWEsdUJBQWIsRUFBc0MsS0FBSzJYLGdCQUEzQzs7QUFFQSxhQUFLTCxRQUFMLENBQWN0WCxFQUFkLENBQWlCLDJCQUFqQixFQUE4QyxLQUFLNFgsVUFBTCxDQUFnQnJkLElBQWhCLENBQXFCLElBQXJCLENBQTlDO0FBQ0Q7O0FBRUQ7Ozs7OztBQW5FVztBQUFBO0FBQUEsZ0NBd0VEO0FBQ1I7QUFDQSxZQUFJLENBQUM1SCxXQUFXZ0csVUFBWCxDQUFzQjZJLE9BQXRCLENBQThCLEtBQUtvRSxPQUFMLENBQWFpUyxPQUEzQyxDQUFMLEVBQTBEO0FBQ3hELGVBQUtoa0IsUUFBTCxDQUFjNlEsSUFBZDtBQUNBLGVBQUsyUyxXQUFMLENBQWlCdlMsSUFBakI7QUFDRDs7QUFFRDtBQUxBLGFBTUs7QUFDSCxpQkFBS2pSLFFBQUwsQ0FBY2lSLElBQWQ7QUFDQSxpQkFBS3VTLFdBQUwsQ0FBaUIzUyxJQUFqQjtBQUNEO0FBQ0Y7O0FBRUQ7Ozs7OztBQXRGVztBQUFBO0FBQUEsbUNBMkZFO0FBQUE7O0FBQ1gsWUFBSSxDQUFDL1IsV0FBV2dHLFVBQVgsQ0FBc0I2SSxPQUF0QixDQUE4QixLQUFLb0UsT0FBTCxDQUFhaVMsT0FBM0MsQ0FBTCxFQUEwRDtBQUN4RCxjQUFHLEtBQUtqUyxPQUFMLENBQWEvQixPQUFoQixFQUF5QjtBQUN2QixnQkFBSSxLQUFLd1QsV0FBTCxDQUFpQjdYLEVBQWpCLENBQW9CLFNBQXBCLENBQUosRUFBb0M7QUFDbEM3TSx5QkFBVzhRLE1BQVgsQ0FBa0JDLFNBQWxCLENBQTRCLEtBQUsyVCxXQUFqQyxFQUE4QyxLQUFLRyxXQUFuRCxFQUFnRSxZQUFNO0FBQ3BFOzs7O0FBSUEsdUJBQUszakIsUUFBTCxDQUFjRSxPQUFkLENBQXNCLDZCQUF0QjtBQUNBLHVCQUFLc2pCLFdBQUwsQ0FBaUJqaEIsSUFBakIsQ0FBc0IsZUFBdEIsRUFBdUN1QixjQUF2QyxDQUFzRCxxQkFBdEQ7QUFDRCxlQVBEO0FBUUQsYUFURCxNQVVLO0FBQ0hoRix5QkFBVzhRLE1BQVgsQ0FBa0JLLFVBQWxCLENBQTZCLEtBQUt1VCxXQUFsQyxFQUErQyxLQUFLSSxZQUFwRCxFQUFrRSxZQUFNO0FBQ3RFOzs7O0FBSUEsdUJBQUs1akIsUUFBTCxDQUFjRSxPQUFkLENBQXNCLDZCQUF0QjtBQUNELGVBTkQ7QUFPRDtBQUNGLFdBcEJELE1BcUJLO0FBQ0gsaUJBQUtzakIsV0FBTCxDQUFpQjdLLE1BQWpCLENBQXdCLENBQXhCO0FBQ0EsaUJBQUs2SyxXQUFMLENBQWlCamhCLElBQWpCLENBQXNCLGVBQXRCLEVBQXVDckMsT0FBdkMsQ0FBK0MscUJBQS9DOztBQUVBOzs7O0FBSUEsaUJBQUtGLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQiw2QkFBdEI7QUFDRDtBQUNGO0FBQ0Y7QUE3SFU7QUFBQTtBQUFBLGdDQStIRDtBQUNSLGFBQUtGLFFBQUwsQ0FBY3dNLEdBQWQsQ0FBa0Isc0JBQWxCO0FBQ0EsYUFBS2lYLFFBQUwsQ0FBY2pYLEdBQWQsQ0FBa0Isc0JBQWxCOztBQUVBNU4sVUFBRTBHLE1BQUYsRUFBVWtILEdBQVYsQ0FBYyx1QkFBZCxFQUF1QyxLQUFLc1gsZ0JBQTVDOztBQUVBaGxCLG1CQUFXc0IsZ0JBQVgsQ0FBNEIsSUFBNUI7QUFDRDtBQXRJVTs7QUFBQTtBQUFBOztBQXlJYmtqQixtQkFBaUJ2TCxRQUFqQixHQUE0QjtBQUMxQjs7Ozs7QUFLQWlNLGFBQVMsUUFOaUI7O0FBUTFCOzs7OztBQUtBaFUsYUFBUztBQWJpQixHQUE1Qjs7QUFnQkE7QUFDQWxSLGFBQVdNLE1BQVgsQ0FBa0Jra0IsZ0JBQWxCLEVBQW9DLGtCQUFwQztBQUVDLENBNUpBLENBNEpDOWIsTUE1SkQsQ0FBRDtDQ0ZBOzs7Ozs7QUFFQSxDQUFDLFVBQVM1SSxDQUFULEVBQVk7O0FBRWI7Ozs7Ozs7QUFGYSxNQVNQcWxCLE9BVE87QUFVWDs7Ozs7OztBQU9BLHFCQUFZcGMsT0FBWixFQUFxQmtLLE9BQXJCLEVBQThCO0FBQUE7O0FBQzVCLFdBQUsvUixRQUFMLEdBQWdCNkgsT0FBaEI7QUFDQSxXQUFLa0ssT0FBTCxHQUFlblQsRUFBRXlNLE1BQUYsQ0FBUyxFQUFULEVBQWE0WSxRQUFRbE0sUUFBckIsRUFBK0JsUSxRQUFRNUgsSUFBUixFQUEvQixFQUErQzhSLE9BQS9DLENBQWY7QUFDQSxXQUFLelMsU0FBTCxHQUFpQixFQUFqQjs7QUFFQSxXQUFLd0IsS0FBTDtBQUNBLFdBQUsyWCxPQUFMOztBQUVBM1osaUJBQVdZLGNBQVgsQ0FBMEIsSUFBMUIsRUFBZ0MsU0FBaEM7QUFDRDs7QUFFRDs7Ozs7OztBQTVCVztBQUFBO0FBQUEsOEJBaUNIO0FBQ04sWUFBSWdrQixLQUFKO0FBQ0E7QUFDQSxZQUFJLEtBQUszUixPQUFMLENBQWEvQixPQUFqQixFQUEwQjtBQUN4QjBULGtCQUFRLEtBQUszUixPQUFMLENBQWEvQixPQUFiLENBQXFCbk4sS0FBckIsQ0FBMkIsR0FBM0IsQ0FBUjs7QUFFQSxlQUFLOGdCLFdBQUwsR0FBbUJELE1BQU0sQ0FBTixDQUFuQjtBQUNBLGVBQUtFLFlBQUwsR0FBb0JGLE1BQU0sQ0FBTixLQUFZLElBQWhDO0FBQ0Q7QUFDRDtBQU5BLGFBT0s7QUFDSEEsb0JBQVEsS0FBSzFqQixRQUFMLENBQWNDLElBQWQsQ0FBbUIsU0FBbkIsQ0FBUjtBQUNBO0FBQ0EsaUJBQUtYLFNBQUwsR0FBaUJva0IsTUFBTSxDQUFOLE1BQWEsR0FBYixHQUFtQkEsTUFBTXhoQixLQUFOLENBQVksQ0FBWixDQUFuQixHQUFvQ3doQixLQUFyRDtBQUNEOztBQUVEO0FBQ0EsWUFBSWpWLEtBQUssS0FBS3pPLFFBQUwsQ0FBYyxDQUFkLEVBQWlCeU8sRUFBMUI7QUFDQTdQLDJCQUFpQjZQLEVBQWpCLHlCQUF1Q0EsRUFBdkMsMEJBQThEQSxFQUE5RCxTQUNHdFAsSUFESCxDQUNRLGVBRFIsRUFDeUJzUCxFQUR6QjtBQUVBO0FBQ0EsYUFBS3pPLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixlQUFuQixFQUFvQyxLQUFLYSxRQUFMLENBQWMyTCxFQUFkLENBQWlCLFNBQWpCLElBQThCLEtBQTlCLEdBQXNDLElBQTFFO0FBQ0Q7O0FBRUQ7Ozs7OztBQXpEVztBQUFBO0FBQUEsZ0NBOEREO0FBQ1IsYUFBSzNMLFFBQUwsQ0FBY3dNLEdBQWQsQ0FBa0IsbUJBQWxCLEVBQXVDTCxFQUF2QyxDQUEwQyxtQkFBMUMsRUFBK0QsS0FBS3dNLE1BQUwsQ0FBWWpTLElBQVosQ0FBaUIsSUFBakIsQ0FBL0Q7QUFDRDs7QUFFRDs7Ozs7OztBQWxFVztBQUFBO0FBQUEsK0JBd0VGO0FBQ1AsYUFBTSxLQUFLcUwsT0FBTCxDQUFhL0IsT0FBYixHQUF1QixnQkFBdkIsR0FBMEMsY0FBaEQ7QUFDRDtBQTFFVTtBQUFBO0FBQUEscUNBNEVJO0FBQ2IsYUFBS2hRLFFBQUwsQ0FBY2trQixXQUFkLENBQTBCLEtBQUs1a0IsU0FBL0I7O0FBRUEsWUFBSTZrQixPQUFPLEtBQUtua0IsUUFBTCxDQUFjc1ksUUFBZCxDQUF1QixLQUFLaFosU0FBNUIsQ0FBWDtBQUNBLFlBQUk2a0IsSUFBSixFQUFVO0FBQ1I7Ozs7QUFJQSxlQUFLbmtCLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQixlQUF0QjtBQUNELFNBTkQsTUFPSztBQUNIOzs7O0FBSUEsZUFBS0YsUUFBTCxDQUFjRSxPQUFkLENBQXNCLGdCQUF0QjtBQUNEOztBQUVELGFBQUtra0IsV0FBTCxDQUFpQkQsSUFBakI7QUFDQSxhQUFLbmtCLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsZUFBbkIsRUFBb0NyQyxPQUFwQyxDQUE0QyxxQkFBNUM7QUFDRDtBQWpHVTtBQUFBO0FBQUEsdUNBbUdNO0FBQ2YsWUFBSWMsUUFBUSxJQUFaOztBQUVBLFlBQUksS0FBS2hCLFFBQUwsQ0FBYzJMLEVBQWQsQ0FBaUIsU0FBakIsQ0FBSixFQUFpQztBQUMvQjdNLHFCQUFXOFEsTUFBWCxDQUFrQkMsU0FBbEIsQ0FBNEIsS0FBSzdQLFFBQWpDLEVBQTJDLEtBQUsyakIsV0FBaEQsRUFBNkQsWUFBVztBQUN0RTNpQixrQkFBTW9qQixXQUFOLENBQWtCLElBQWxCO0FBQ0EsaUJBQUtsa0IsT0FBTCxDQUFhLGVBQWI7QUFDQSxpQkFBS3FDLElBQUwsQ0FBVSxlQUFWLEVBQTJCckMsT0FBM0IsQ0FBbUMscUJBQW5DO0FBQ0QsV0FKRDtBQUtELFNBTkQsTUFPSztBQUNIcEIscUJBQVc4USxNQUFYLENBQWtCSyxVQUFsQixDQUE2QixLQUFLalEsUUFBbEMsRUFBNEMsS0FBSzRqQixZQUFqRCxFQUErRCxZQUFXO0FBQ3hFNWlCLGtCQUFNb2pCLFdBQU4sQ0FBa0IsS0FBbEI7QUFDQSxpQkFBS2xrQixPQUFMLENBQWEsZ0JBQWI7QUFDQSxpQkFBS3FDLElBQUwsQ0FBVSxlQUFWLEVBQTJCckMsT0FBM0IsQ0FBbUMscUJBQW5DO0FBQ0QsV0FKRDtBQUtEO0FBQ0Y7QUFwSFU7QUFBQTtBQUFBLGtDQXNIQ2lrQixJQXRIRCxFQXNITztBQUNoQixhQUFLbmtCLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixlQUFuQixFQUFvQ2dsQixPQUFPLElBQVAsR0FBYyxLQUFsRDtBQUNEOztBQUVEOzs7OztBQTFIVztBQUFBO0FBQUEsZ0NBOEhEO0FBQ1IsYUFBS25rQixRQUFMLENBQWN3TSxHQUFkLENBQWtCLGFBQWxCO0FBQ0ExTixtQkFBV3NCLGdCQUFYLENBQTRCLElBQTVCO0FBQ0Q7QUFqSVU7O0FBQUE7QUFBQTs7QUFvSWI2akIsVUFBUWxNLFFBQVIsR0FBbUI7QUFDakI7Ozs7O0FBS0EvSCxhQUFTO0FBTlEsR0FBbkI7O0FBU0E7QUFDQWxSLGFBQVdNLE1BQVgsQ0FBa0I2a0IsT0FBbEIsRUFBMkIsU0FBM0I7QUFFQyxDQWhKQSxDQWdKQ3pjLE1BaEpELENBQUQ7Q0NGQTs7Ozs7O0FBRUEsQ0FBQyxVQUFTNUksQ0FBVCxFQUFZOztBQUViOzs7Ozs7OztBQUZhLE1BVVB5bEIsT0FWTztBQVdYOzs7Ozs7O0FBT0EscUJBQVl4YyxPQUFaLEVBQXFCa0ssT0FBckIsRUFBOEI7QUFBQTs7QUFDNUIsV0FBSy9SLFFBQUwsR0FBZ0I2SCxPQUFoQjtBQUNBLFdBQUtrSyxPQUFMLEdBQWVuVCxFQUFFeU0sTUFBRixDQUFTLEVBQVQsRUFBYWdaLFFBQVF0TSxRQUFyQixFQUErQixLQUFLL1gsUUFBTCxDQUFjQyxJQUFkLEVBQS9CLEVBQXFEOFIsT0FBckQsQ0FBZjs7QUFFQSxXQUFLc0csUUFBTCxHQUFnQixLQUFoQjtBQUNBLFdBQUtpTSxPQUFMLEdBQWUsS0FBZjtBQUNBLFdBQUt4akIsS0FBTDs7QUFFQWhDLGlCQUFXWSxjQUFYLENBQTBCLElBQTFCLEVBQWdDLFNBQWhDO0FBQ0Q7O0FBRUQ7Ozs7OztBQTdCVztBQUFBO0FBQUEsOEJBaUNIO0FBQ04sWUFBSTZrQixTQUFTLEtBQUt2a0IsUUFBTCxDQUFjYixJQUFkLENBQW1CLGtCQUFuQixLQUEwQ0wsV0FBV2lCLFdBQVgsQ0FBdUIsQ0FBdkIsRUFBMEIsU0FBMUIsQ0FBdkQ7O0FBRUEsYUFBS2dTLE9BQUwsQ0FBYXFMLGFBQWIsR0FBNkIsS0FBS3JMLE9BQUwsQ0FBYXFMLGFBQWIsSUFBOEIsS0FBS29ILGlCQUFMLENBQXVCLEtBQUt4a0IsUUFBNUIsQ0FBM0Q7QUFDQSxhQUFLK1IsT0FBTCxDQUFhMFMsT0FBYixHQUF1QixLQUFLMVMsT0FBTCxDQUFhMFMsT0FBYixJQUF3QixLQUFLemtCLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixPQUFuQixDQUEvQztBQUNBLGFBQUt1bEIsUUFBTCxHQUFnQixLQUFLM1MsT0FBTCxDQUFhMlMsUUFBYixHQUF3QjlsQixFQUFFLEtBQUttVCxPQUFMLENBQWEyUyxRQUFmLENBQXhCLEdBQW1ELEtBQUtDLGNBQUwsQ0FBb0JKLE1BQXBCLENBQW5FOztBQUVBLFlBQUksS0FBS3hTLE9BQUwsQ0FBYTZTLFNBQWpCLEVBQTRCO0FBQzFCLGVBQUtGLFFBQUwsQ0FBYy9mLFFBQWQsQ0FBdUJuQixTQUFTMEYsSUFBaEMsRUFDRzJiLElBREgsQ0FDUSxLQUFLOVMsT0FBTCxDQUFhMFMsT0FEckIsRUFFR3hULElBRkg7QUFHRCxTQUpELE1BSU87QUFDTCxlQUFLeVQsUUFBTCxDQUFjL2YsUUFBZCxDQUF1Qm5CLFNBQVMwRixJQUFoQyxFQUNHNEYsSUFESCxDQUNRLEtBQUtpRCxPQUFMLENBQWEwUyxPQURyQixFQUVHeFQsSUFGSDtBQUdEOztBQUVELGFBQUtqUixRQUFMLENBQWNiLElBQWQsQ0FBbUI7QUFDakIsbUJBQVMsRUFEUTtBQUVqQiw4QkFBb0JvbEIsTUFGSDtBQUdqQiwyQkFBaUJBLE1BSEE7QUFJakIseUJBQWVBLE1BSkU7QUFLakIseUJBQWVBO0FBTEUsU0FBbkIsRUFNRzNULFFBTkgsQ0FNWSxLQUFLbUIsT0FBTCxDQUFhK1MsWUFOekI7O0FBUUE7QUFDQSxhQUFLdkgsYUFBTCxHQUFxQixFQUFyQjtBQUNBLGFBQUtELE9BQUwsR0FBZSxDQUFmO0FBQ0EsYUFBS0ssWUFBTCxHQUFvQixLQUFwQjs7QUFFQSxhQUFLbEYsT0FBTDtBQUNEOztBQUVEOzs7OztBQWxFVztBQUFBO0FBQUEsd0NBc0VPNVEsT0F0RVAsRUFzRWdCO0FBQ3pCLFlBQUksQ0FBQ0EsT0FBTCxFQUFjO0FBQUUsaUJBQU8sRUFBUDtBQUFZO0FBQzVCO0FBQ0EsWUFBSTRCLFdBQVc1QixRQUFRLENBQVIsRUFBV3ZJLFNBQVgsQ0FBcUJtZSxLQUFyQixDQUEyQix1QkFBM0IsQ0FBZjtBQUNJaFUsbUJBQVdBLFdBQVdBLFNBQVMsQ0FBVCxDQUFYLEdBQXlCLEVBQXBDO0FBQ0osZUFBT0EsUUFBUDtBQUNEO0FBNUVVO0FBQUE7O0FBNkVYOzs7O0FBN0VXLHFDQWlGSWdGLEVBakZKLEVBaUZRO0FBQ2pCLFlBQUlzVyxrQkFBa0IsQ0FBSSxLQUFLaFQsT0FBTCxDQUFhaVQsWUFBakIsU0FBaUMsS0FBS2pULE9BQUwsQ0FBYXFMLGFBQTlDLFNBQStELEtBQUtyTCxPQUFMLENBQWFnVCxlQUE1RSxFQUErRjdoQixJQUEvRixFQUF0QjtBQUNBLFlBQUkraEIsWUFBYXJtQixFQUFFLGFBQUYsRUFBaUJnUyxRQUFqQixDQUEwQm1VLGVBQTFCLEVBQTJDNWxCLElBQTNDLENBQWdEO0FBQy9ELGtCQUFRLFNBRHVEO0FBRS9ELHlCQUFlLElBRmdEO0FBRy9ELDRCQUFrQixLQUg2QztBQUkvRCwyQkFBaUIsS0FKOEM7QUFLL0QsZ0JBQU1zUDtBQUx5RCxTQUFoRCxDQUFqQjtBQU9BLGVBQU93VyxTQUFQO0FBQ0Q7O0FBRUQ7Ozs7OztBQTdGVztBQUFBO0FBQUEsa0NBa0dDeGIsUUFsR0QsRUFrR1c7QUFDcEIsYUFBSzhULGFBQUwsQ0FBbUJwZCxJQUFuQixDQUF3QnNKLFdBQVdBLFFBQVgsR0FBc0IsUUFBOUM7O0FBRUE7QUFDQSxZQUFJLENBQUNBLFFBQUQsSUFBYyxLQUFLOFQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLEtBQTNCLElBQW9DLENBQXRELEVBQTBEO0FBQ3hELGVBQUtva0IsUUFBTCxDQUFjOVQsUUFBZCxDQUF1QixLQUF2QjtBQUNELFNBRkQsTUFFTyxJQUFJbkgsYUFBYSxLQUFiLElBQXVCLEtBQUs4VCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsUUFBM0IsSUFBdUMsQ0FBbEUsRUFBc0U7QUFDM0UsZUFBS29rQixRQUFMLENBQWM3ZixXQUFkLENBQTBCNEUsUUFBMUI7QUFDRCxTQUZNLE1BRUEsSUFBSUEsYUFBYSxNQUFiLElBQXdCLEtBQUs4VCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsT0FBM0IsSUFBc0MsQ0FBbEUsRUFBc0U7QUFDM0UsZUFBS29rQixRQUFMLENBQWM3ZixXQUFkLENBQTBCNEUsUUFBMUIsRUFDS21ILFFBREwsQ0FDYyxPQURkO0FBRUQsU0FITSxNQUdBLElBQUluSCxhQUFhLE9BQWIsSUFBeUIsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixNQUEzQixJQUFxQyxDQUFsRSxFQUFzRTtBQUMzRSxlQUFLb2tCLFFBQUwsQ0FBYzdmLFdBQWQsQ0FBMEI0RSxRQUExQixFQUNLbUgsUUFETCxDQUNjLE1BRGQ7QUFFRDs7QUFFRDtBQUxPLGFBTUYsSUFBSSxDQUFDbkgsUUFBRCxJQUFjLEtBQUs4VCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsS0FBM0IsSUFBb0MsQ0FBQyxDQUFuRCxJQUEwRCxLQUFLaWQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLE1BQTNCLElBQXFDLENBQW5HLEVBQXVHO0FBQzFHLGlCQUFLb2tCLFFBQUwsQ0FBYzlULFFBQWQsQ0FBdUIsTUFBdkI7QUFDRCxXQUZJLE1BRUUsSUFBSW5ILGFBQWEsS0FBYixJQUF1QixLQUFLOFQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLFFBQTNCLElBQXVDLENBQUMsQ0FBL0QsSUFBc0UsS0FBS2lkLGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixNQUEzQixJQUFxQyxDQUEvRyxFQUFtSDtBQUN4SCxpQkFBS29rQixRQUFMLENBQWM3ZixXQUFkLENBQTBCNEUsUUFBMUIsRUFDS21ILFFBREwsQ0FDYyxNQURkO0FBRUQsV0FITSxNQUdBLElBQUluSCxhQUFhLE1BQWIsSUFBd0IsS0FBSzhULGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixPQUEzQixJQUFzQyxDQUFDLENBQS9ELElBQXNFLEtBQUtpZCxhQUFMLENBQW1CamQsT0FBbkIsQ0FBMkIsUUFBM0IsSUFBdUMsQ0FBakgsRUFBcUg7QUFDMUgsaUJBQUtva0IsUUFBTCxDQUFjN2YsV0FBZCxDQUEwQjRFLFFBQTFCO0FBQ0QsV0FGTSxNQUVBLElBQUlBLGFBQWEsT0FBYixJQUF5QixLQUFLOFQsYUFBTCxDQUFtQmpkLE9BQW5CLENBQTJCLE1BQTNCLElBQXFDLENBQUMsQ0FBL0QsSUFBc0UsS0FBS2lkLGFBQUwsQ0FBbUJqZCxPQUFuQixDQUEyQixRQUEzQixJQUF1QyxDQUFqSCxFQUFxSDtBQUMxSCxpQkFBS29rQixRQUFMLENBQWM3ZixXQUFkLENBQTBCNEUsUUFBMUI7QUFDRDtBQUNEO0FBSE8sZUFJRjtBQUNILG1CQUFLaWIsUUFBTCxDQUFjN2YsV0FBZCxDQUEwQjRFLFFBQTFCO0FBQ0Q7QUFDRCxhQUFLa1UsWUFBTCxHQUFvQixJQUFwQjtBQUNBLGFBQUtMLE9BQUw7QUFDRDs7QUFFRDs7Ozs7O0FBcklXO0FBQUE7QUFBQSxxQ0EwSUk7QUFDYixZQUFJN1QsV0FBVyxLQUFLK2EsaUJBQUwsQ0FBdUIsS0FBS0UsUUFBNUIsQ0FBZjtBQUFBLFlBQ0lRLFdBQVdwbUIsV0FBVzJJLEdBQVgsQ0FBZUUsYUFBZixDQUE2QixLQUFLK2MsUUFBbEMsQ0FEZjtBQUFBLFlBRUk1YSxjQUFjaEwsV0FBVzJJLEdBQVgsQ0FBZUUsYUFBZixDQUE2QixLQUFLM0gsUUFBbEMsQ0FGbEI7QUFBQSxZQUdJNGQsWUFBYW5VLGFBQWEsTUFBYixHQUFzQixNQUF0QixHQUFpQ0EsYUFBYSxPQUFkLEdBQXlCLE1BQXpCLEdBQWtDLEtBSG5GO0FBQUEsWUFJSTRGLFFBQVN1TyxjQUFjLEtBQWYsR0FBd0IsUUFBeEIsR0FBbUMsT0FKL0M7QUFBQSxZQUtJclYsU0FBVThHLFVBQVUsUUFBWCxHQUF1QixLQUFLMEMsT0FBTCxDQUFhckksT0FBcEMsR0FBOEMsS0FBS3FJLE9BQUwsQ0FBYXBJLE9BTHhFO0FBQUEsWUFNSTNJLFFBQVEsSUFOWjs7QUFRQSxZQUFLa2tCLFNBQVN6YyxLQUFULElBQWtCeWMsU0FBU3hjLFVBQVQsQ0FBb0JELEtBQXZDLElBQWtELENBQUMsS0FBSzZVLE9BQU4sSUFBaUIsQ0FBQ3hlLFdBQVcySSxHQUFYLENBQWVDLGdCQUFmLENBQWdDLEtBQUtnZCxRQUFyQyxDQUF4RSxFQUF5SDtBQUN2SCxlQUFLQSxRQUFMLENBQWNuYyxNQUFkLENBQXFCekosV0FBVzJJLEdBQVgsQ0FBZUcsVUFBZixDQUEwQixLQUFLOGMsUUFBL0IsRUFBeUMsS0FBSzFrQixRQUE5QyxFQUF3RCxlQUF4RCxFQUF5RSxLQUFLK1IsT0FBTCxDQUFhckksT0FBdEYsRUFBK0YsS0FBS3FJLE9BQUwsQ0FBYXBJLE9BQTVHLEVBQXFILElBQXJILENBQXJCLEVBQWlKeUQsR0FBakosQ0FBcUo7QUFDcko7QUFDRSxxQkFBU3RELFlBQVlwQixVQUFaLENBQXVCRCxLQUF2QixHQUFnQyxLQUFLc0osT0FBTCxDQUFhcEksT0FBYixHQUF1QixDQUZtRjtBQUduSixzQkFBVTtBQUh5SSxXQUFySjtBQUtBLGlCQUFPLEtBQVA7QUFDRDs7QUFFRCxhQUFLK2EsUUFBTCxDQUFjbmMsTUFBZCxDQUFxQnpKLFdBQVcySSxHQUFYLENBQWVHLFVBQWYsQ0FBMEIsS0FBSzhjLFFBQS9CLEVBQXlDLEtBQUsxa0IsUUFBOUMsRUFBdUQsYUFBYXlKLFlBQVksUUFBekIsQ0FBdkQsRUFBMkYsS0FBS3NJLE9BQUwsQ0FBYXJJLE9BQXhHLEVBQWlILEtBQUtxSSxPQUFMLENBQWFwSSxPQUE5SCxDQUFyQjs7QUFFQSxlQUFNLENBQUM3SyxXQUFXMkksR0FBWCxDQUFlQyxnQkFBZixDQUFnQyxLQUFLZ2QsUUFBckMsQ0FBRCxJQUFtRCxLQUFLcEgsT0FBOUQsRUFBdUU7QUFDckUsZUFBS1UsV0FBTCxDQUFpQnZVLFFBQWpCO0FBQ0EsZUFBS3dVLFlBQUw7QUFDRDtBQUNGOztBQUVEOzs7Ozs7O0FBcEtXO0FBQUE7QUFBQSw2QkEwS0o7QUFDTCxZQUFJLEtBQUtsTSxPQUFMLENBQWFvVCxNQUFiLEtBQXdCLEtBQXhCLElBQWlDLENBQUNybUIsV0FBV2dHLFVBQVgsQ0FBc0I2RyxFQUF0QixDQUF5QixLQUFLb0csT0FBTCxDQUFhb1QsTUFBdEMsQ0FBdEMsRUFBcUY7QUFDbkY7QUFDQSxpQkFBTyxLQUFQO0FBQ0Q7O0FBRUQsWUFBSW5rQixRQUFRLElBQVo7QUFDQSxhQUFLMGpCLFFBQUwsQ0FBY3RYLEdBQWQsQ0FBa0IsWUFBbEIsRUFBZ0MsUUFBaEMsRUFBMEN5RCxJQUExQztBQUNBLGFBQUtvTixZQUFMOztBQUVBOzs7O0FBSUEsYUFBS2plLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQixvQkFBdEIsRUFBNEMsS0FBS3drQixRQUFMLENBQWN2bEIsSUFBZCxDQUFtQixJQUFuQixDQUE1Qzs7QUFHQSxhQUFLdWxCLFFBQUwsQ0FBY3ZsQixJQUFkLENBQW1CO0FBQ2pCLDRCQUFrQixJQUREO0FBRWpCLHlCQUFlO0FBRkUsU0FBbkI7QUFJQTZCLGNBQU1xWCxRQUFOLEdBQWlCLElBQWpCO0FBQ0E7QUFDQSxhQUFLcU0sUUFBTCxDQUFjdkksSUFBZCxHQUFxQmxMLElBQXJCLEdBQTRCN0QsR0FBNUIsQ0FBZ0MsWUFBaEMsRUFBOEMsRUFBOUMsRUFBa0RnWSxNQUFsRCxDQUF5RCxLQUFLclQsT0FBTCxDQUFhc1QsY0FBdEUsRUFBc0YsWUFBVztBQUMvRjtBQUNELFNBRkQ7QUFHQTs7OztBQUlBLGFBQUtybEIsUUFBTCxDQUFjRSxPQUFkLENBQXNCLGlCQUF0QjtBQUNEOztBQUVEOzs7Ozs7QUEzTVc7QUFBQTtBQUFBLDZCQWdOSjtBQUNMO0FBQ0EsWUFBSWMsUUFBUSxJQUFaO0FBQ0EsYUFBSzBqQixRQUFMLENBQWN2SSxJQUFkLEdBQXFCaGQsSUFBckIsQ0FBMEI7QUFDeEIseUJBQWUsSUFEUztBQUV4Qiw0QkFBa0I7QUFGTSxTQUExQixFQUdHNlcsT0FISCxDQUdXLEtBQUtqRSxPQUFMLENBQWF1VCxlQUh4QixFQUd5QyxZQUFXO0FBQ2xEdGtCLGdCQUFNcVgsUUFBTixHQUFpQixLQUFqQjtBQUNBclgsZ0JBQU1zakIsT0FBTixHQUFnQixLQUFoQjtBQUNBLGNBQUl0akIsTUFBTTJjLFlBQVYsRUFBd0I7QUFDdEIzYyxrQkFBTTBqQixRQUFOLENBQ003ZixXQUROLENBQ2tCN0QsTUFBTXdqQixpQkFBTixDQUF3QnhqQixNQUFNMGpCLFFBQTlCLENBRGxCLEVBRU05VCxRQUZOLENBRWU1UCxNQUFNK1EsT0FBTixDQUFjcUwsYUFGN0I7O0FBSURwYyxrQkFBTXVjLGFBQU4sR0FBc0IsRUFBdEI7QUFDQXZjLGtCQUFNc2MsT0FBTixHQUFnQixDQUFoQjtBQUNBdGMsa0JBQU0yYyxZQUFOLEdBQXFCLEtBQXJCO0FBQ0E7QUFDRixTQWZEO0FBZ0JBOzs7O0FBSUEsYUFBSzNkLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQixpQkFBdEI7QUFDRDs7QUFFRDs7Ozs7O0FBMU9XO0FBQUE7QUFBQSxnQ0ErT0Q7QUFDUixZQUFJYyxRQUFRLElBQVo7QUFDQSxZQUFJaWtCLFlBQVksS0FBS1AsUUFBckI7QUFDQSxZQUFJYSxVQUFVLEtBQWQ7O0FBRUEsWUFBSSxDQUFDLEtBQUt4VCxPQUFMLENBQWE2TixZQUFsQixFQUFnQzs7QUFFOUIsZUFBSzVmLFFBQUwsQ0FDQ21NLEVBREQsQ0FDSSx1QkFESixFQUM2QixVQUFTckosQ0FBVCxFQUFZO0FBQ3ZDLGdCQUFJLENBQUM5QixNQUFNcVgsUUFBWCxFQUFxQjtBQUNuQnJYLG9CQUFNcWQsT0FBTixHQUFnQnhhLFdBQVcsWUFBVztBQUNwQzdDLHNCQUFNNlAsSUFBTjtBQUNELGVBRmUsRUFFYjdQLE1BQU0rUSxPQUFOLENBQWN1TSxVQUZELENBQWhCO0FBR0Q7QUFDRixXQVBELEVBUUNuUyxFQVJELENBUUksdUJBUkosRUFRNkIsVUFBU3JKLENBQVQsRUFBWTtBQUN2Q3dELHlCQUFhdEYsTUFBTXFkLE9BQW5CO0FBQ0EsZ0JBQUksQ0FBQ2tILE9BQUQsSUFBYXZrQixNQUFNc2pCLE9BQU4sSUFBaUIsQ0FBQ3RqQixNQUFNK1EsT0FBTixDQUFjME4sU0FBakQsRUFBNkQ7QUFDM0R6ZSxvQkFBTWlRLElBQU47QUFDRDtBQUNGLFdBYkQ7QUFjRDs7QUFFRCxZQUFJLEtBQUtjLE9BQUwsQ0FBYTBOLFNBQWpCLEVBQTRCO0FBQzFCLGVBQUt6ZixRQUFMLENBQWNtTSxFQUFkLENBQWlCLHNCQUFqQixFQUF5QyxVQUFTckosQ0FBVCxFQUFZO0FBQ25EQSxjQUFFeVcsd0JBQUY7QUFDQSxnQkFBSXZZLE1BQU1zakIsT0FBVixFQUFtQjtBQUNqQjtBQUNBO0FBQ0QsYUFIRCxNQUdPO0FBQ0x0akIsb0JBQU1zakIsT0FBTixHQUFnQixJQUFoQjtBQUNBLGtCQUFJLENBQUN0akIsTUFBTStRLE9BQU4sQ0FBYzZOLFlBQWQsSUFBOEIsQ0FBQzVlLE1BQU1oQixRQUFOLENBQWViLElBQWYsQ0FBb0IsVUFBcEIsQ0FBaEMsS0FBb0UsQ0FBQzZCLE1BQU1xWCxRQUEvRSxFQUF5RjtBQUN2RnJYLHNCQUFNNlAsSUFBTjtBQUNEO0FBQ0Y7QUFDRixXQVhEO0FBWUQsU0FiRCxNQWFPO0FBQ0wsZUFBSzdRLFFBQUwsQ0FBY21NLEVBQWQsQ0FBaUIsc0JBQWpCLEVBQXlDLFVBQVNySixDQUFULEVBQVk7QUFDbkRBLGNBQUV5Vyx3QkFBRjtBQUNBdlksa0JBQU1zakIsT0FBTixHQUFnQixJQUFoQjtBQUNELFdBSEQ7QUFJRDs7QUFFRCxZQUFJLENBQUMsS0FBS3ZTLE9BQUwsQ0FBYXlULGVBQWxCLEVBQW1DO0FBQ2pDLGVBQUt4bEIsUUFBTCxDQUNDbU0sRUFERCxDQUNJLG9DQURKLEVBQzBDLFVBQVNySixDQUFULEVBQVk7QUFDcEQ5QixrQkFBTXFYLFFBQU4sR0FBaUJyWCxNQUFNaVEsSUFBTixFQUFqQixHQUFnQ2pRLE1BQU02UCxJQUFOLEVBQWhDO0FBQ0QsV0FIRDtBQUlEOztBQUVELGFBQUs3USxRQUFMLENBQWNtTSxFQUFkLENBQWlCO0FBQ2Y7QUFDQTtBQUNBLDhCQUFvQixLQUFLOEUsSUFBTCxDQUFVdkssSUFBVixDQUFlLElBQWY7QUFITCxTQUFqQjs7QUFNQSxhQUFLMUcsUUFBTCxDQUNHbU0sRUFESCxDQUNNLGtCQUROLEVBQzBCLFVBQVNySixDQUFULEVBQVk7QUFDbEN5aUIsb0JBQVUsSUFBVjtBQUNBLGNBQUl2a0IsTUFBTXNqQixPQUFWLEVBQW1CO0FBQ2pCO0FBQ0E7QUFDQSxnQkFBRyxDQUFDdGpCLE1BQU0rUSxPQUFOLENBQWMwTixTQUFsQixFQUE2QjtBQUFFOEYsd0JBQVUsS0FBVjtBQUFrQjtBQUNqRCxtQkFBTyxLQUFQO0FBQ0QsV0FMRCxNQUtPO0FBQ0x2a0Isa0JBQU02UCxJQUFOO0FBQ0Q7QUFDRixTQVhILEVBYUcxRSxFQWJILENBYU0scUJBYk4sRUFhNkIsVUFBU3JKLENBQVQsRUFBWTtBQUNyQ3lpQixvQkFBVSxLQUFWO0FBQ0F2a0IsZ0JBQU1zakIsT0FBTixHQUFnQixLQUFoQjtBQUNBdGpCLGdCQUFNaVEsSUFBTjtBQUNELFNBakJILEVBbUJHOUUsRUFuQkgsQ0FtQk0scUJBbkJOLEVBbUI2QixZQUFXO0FBQ3BDLGNBQUluTCxNQUFNcVgsUUFBVixFQUFvQjtBQUNsQnJYLGtCQUFNaWQsWUFBTjtBQUNEO0FBQ0YsU0F2Qkg7QUF3QkQ7O0FBRUQ7Ozs7O0FBalVXO0FBQUE7QUFBQSwrQkFxVUY7QUFDUCxZQUFJLEtBQUs1RixRQUFULEVBQW1CO0FBQ2pCLGVBQUtwSCxJQUFMO0FBQ0QsU0FGRCxNQUVPO0FBQ0wsZUFBS0osSUFBTDtBQUNEO0FBQ0Y7O0FBRUQ7Ozs7O0FBN1VXO0FBQUE7QUFBQSxnQ0FpVkQ7QUFDUixhQUFLN1EsUUFBTCxDQUFjYixJQUFkLENBQW1CLE9BQW5CLEVBQTRCLEtBQUt1bEIsUUFBTCxDQUFjNVYsSUFBZCxFQUE1QixFQUNjdEMsR0FEZCxDQUNrQix5QkFEbEIsRUFFYzNILFdBRmQsQ0FFMEIsd0JBRjFCLEVBR2N0RSxVQUhkLENBR3lCLHNHQUh6Qjs7QUFLQSxhQUFLbWtCLFFBQUwsQ0FBYzVILE1BQWQ7O0FBRUFoZSxtQkFBV3NCLGdCQUFYLENBQTRCLElBQTVCO0FBQ0Q7QUExVlU7O0FBQUE7QUFBQTs7QUE2VmJpa0IsVUFBUXRNLFFBQVIsR0FBbUI7QUFDakJ5TixxQkFBaUIsS0FEQTtBQUVqQjs7Ozs7QUFLQWxILGdCQUFZLEdBUEs7QUFRakI7Ozs7O0FBS0ErRyxvQkFBZ0IsR0FiQztBQWNqQjs7Ozs7QUFLQUMscUJBQWlCLEdBbkJBO0FBb0JqQjs7Ozs7QUFLQTFGLGtCQUFjLEtBekJHO0FBMEJqQjs7Ozs7QUFLQW1GLHFCQUFpQixFQS9CQTtBQWdDakI7Ozs7O0FBS0FDLGtCQUFjLFNBckNHO0FBc0NqQjs7Ozs7QUFLQUYsa0JBQWMsU0EzQ0c7QUE0Q2pCOzs7OztBQUtBSyxZQUFRLE9BakRTO0FBa0RqQjs7Ozs7QUFLQVQsY0FBVSxFQXZETztBQXdEakI7Ozs7O0FBS0FELGFBQVMsRUE3RFE7QUE4RGpCZ0Isb0JBQWdCLGVBOURDO0FBK0RqQjs7Ozs7QUFLQWhHLGVBQVcsSUFwRU07QUFxRWpCOzs7OztBQUtBckMsbUJBQWUsRUExRUU7QUEyRWpCOzs7OztBQUtBMVQsYUFBUyxFQWhGUTtBQWlGakI7Ozs7O0FBS0FDLGFBQVMsRUF0RlE7QUF1RmY7Ozs7OztBQU1GaWIsZUFBVztBQTdGTSxHQUFuQjs7QUFnR0E7Ozs7QUFJQTtBQUNBOWxCLGFBQVdNLE1BQVgsQ0FBa0JpbEIsT0FBbEIsRUFBMkIsU0FBM0I7QUFFQyxDQXBjQSxDQW9jQzdjLE1BcGNELENBQUQ7Ozs7O0FDRkE7Ozs7O0FBS0EsQ0FBQyxVQUFTa2UsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZUMsQ0FBZixFQUFpQjtBQUFDLFdBQVMvaUIsQ0FBVCxDQUFXNmlCLENBQVgsRUFBYUMsQ0FBYixFQUFlO0FBQUMsU0FBS0UsUUFBTCxHQUFjLElBQWQsRUFBbUIsS0FBSy9ULE9BQUwsR0FBYTJULEVBQUVyYSxNQUFGLENBQVMsRUFBVCxFQUFZdkksRUFBRWlqQixRQUFkLEVBQXVCSCxDQUF2QixDQUFoQyxFQUEwRCxLQUFLNWxCLFFBQUwsR0FBYzBsQixFQUFFQyxDQUFGLENBQXhFLEVBQTZFLEtBQUtLLFNBQUwsR0FBZSxFQUE1RixFQUErRixLQUFLaG5CLFFBQUwsR0FBYyxFQUE3RyxFQUFnSCxLQUFLaW5CLFFBQUwsR0FBYyxFQUE5SCxFQUFpSSxLQUFLQyxRQUFMLEdBQWMsSUFBL0ksRUFBb0osS0FBS0MsTUFBTCxHQUFZLElBQWhLLEVBQXFLLEtBQUtDLFlBQUwsR0FBa0IsRUFBdkwsRUFBMEwsS0FBS0MsV0FBTCxHQUFpQixJQUEzTSxFQUFnTixLQUFLQyxNQUFMLEdBQVksSUFBNU4sRUFBaU8sS0FBS0MsTUFBTCxHQUFZLEVBQTdPLEVBQWdQLEtBQUtDLE9BQUwsR0FBYSxFQUE3UCxFQUFnUSxLQUFLQyxRQUFMLEdBQWMsRUFBOVEsRUFBaVIsS0FBS0MsT0FBTCxHQUFhLEVBQTlSLEVBQWlTLEtBQUtDLFlBQUwsR0FBa0IsRUFBblQsRUFBc1QsS0FBS0MsS0FBTCxHQUFXLEVBQWpVLEVBQW9VLEtBQUtDLEtBQUwsR0FBVyxFQUFDQyxNQUFLLElBQU4sRUFBVzFhLFFBQU8sSUFBbEIsRUFBdUIyYSxTQUFRLElBQS9CLEVBQW9DQyxPQUFNLEVBQUN4Z0IsT0FBTSxJQUFQLEVBQVl5RyxTQUFRLElBQXBCLEVBQTFDLEVBQW9FMlEsV0FBVSxJQUE5RSxFQUEvVSxFQUFtYSxLQUFLcUosT0FBTCxHQUFhLEVBQUNoYSxTQUFRLEVBQVQsRUFBWWlhLE1BQUssRUFBQ0MsY0FBYSxDQUFDLE1BQUQsQ0FBZCxFQUF1QkMsV0FBVSxDQUFDLE1BQUQsQ0FBakMsRUFBMENDLFVBQVMsQ0FBQyxhQUFELENBQW5ELEVBQWpCLEVBQWhiLEVBQXNnQjNCLEVBQUU3a0IsSUFBRixDQUFPLENBQUMsVUFBRCxFQUFZLG1CQUFaLENBQVAsRUFBd0M2a0IsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTM0IsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxXQUFLSSxTQUFMLENBQWVKLENBQWYsSUFBa0JGLEVBQUU0QixLQUFGLENBQVEsS0FBSzFCLENBQUwsQ0FBUixFQUFnQixJQUFoQixDQUFsQjtBQUF3QyxLQUE5RCxFQUErRCxJQUEvRCxDQUF4QyxDQUF0Z0IsRUFBb25CRixFQUFFN2tCLElBQUYsQ0FBT2lDLEVBQUV5a0IsT0FBVCxFQUFpQjdCLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsV0FBSzNtQixRQUFMLENBQWMwbUIsRUFBRThCLE1BQUYsQ0FBUyxDQUFULEVBQVkzbkIsV0FBWixLQUEwQjZsQixFQUFFeGpCLEtBQUYsQ0FBUSxDQUFSLENBQXhDLElBQW9ELElBQUl5akIsQ0FBSixDQUFNLElBQU4sQ0FBcEQ7QUFBZ0UsS0FBdEYsRUFBdUYsSUFBdkYsQ0FBakIsQ0FBcG5CLEVBQW11QkQsRUFBRTdrQixJQUFGLENBQU9pQyxFQUFFMmtCLE9BQVQsRUFBaUIvQixFQUFFNEIsS0FBRixDQUFRLFVBQVMzQixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFdBQUtnQixLQUFMLENBQVd6bUIsSUFBWCxDQUFnQixFQUFDdUwsUUFBT2thLEVBQUVsYSxNQUFWLEVBQWlCZ2MsS0FBSWhDLEVBQUU0QixLQUFGLENBQVExQixFQUFFOEIsR0FBVixFQUFjLElBQWQsQ0FBckIsRUFBaEI7QUFBMkQsS0FBakYsRUFBa0YsSUFBbEYsQ0FBakIsQ0FBbnVCLEVBQTYwQixLQUFLalQsS0FBTCxFQUE3MEIsRUFBMDFCLEtBQUtrVCxVQUFMLEVBQTExQjtBQUE0MkIsS0FBRTVCLFFBQUYsR0FBVyxFQUFDelUsT0FBTSxDQUFQLEVBQVNzVyxNQUFLLENBQUMsQ0FBZixFQUFpQkMsUUFBTyxDQUFDLENBQXpCLEVBQTJCQyxRQUFPLENBQUMsQ0FBbkMsRUFBcUNDLFdBQVUsQ0FBQyxDQUFoRCxFQUFrREMsV0FBVSxDQUFDLENBQTdELEVBQStEQyxVQUFTLENBQUMsQ0FBekUsRUFBMkVDLFVBQVMsQ0FBQyxDQUFyRixFQUF1RkMsUUFBTyxDQUE5RixFQUFnR0MsY0FBYSxDQUE3RyxFQUErR0MsT0FBTSxDQUFDLENBQXRILEVBQXdIQyxVQUFTLENBQUMsQ0FBbEksRUFBb0lDLFdBQVUsQ0FBQyxDQUEvSSxFQUFpSkMsZUFBYyxDQUEvSixFQUFpS3RwQixLQUFJLENBQUMsQ0FBdEssRUFBd0t1cEIsWUFBVyxHQUFuTCxFQUF1TEMsWUFBVyxDQUFDLENBQW5NLEVBQXFNQyxjQUFhLENBQUMsQ0FBbk4sRUFBcU5DLFlBQVcsRUFBaE8sRUFBbU9DLHVCQUFzQixHQUF6UCxFQUE2UEMsdUJBQXNCbkQsQ0FBblIsRUFBcVJvRCxnQkFBZSxPQUFwUyxFQUE0U3ZhLE1BQUssQ0FBQyxDQUFsVCxFQUFvVHdhLG9CQUFtQixDQUFDLENBQXhVLEVBQTBVQyxhQUFZLEtBQXRWLEVBQTRWQyxjQUFhLEtBQXpXLEVBQStXQyxjQUFhLGFBQTVYLEVBQTBZQyxhQUFZLFlBQXRaLEVBQW1hQyxjQUFhLGFBQWhiLEVBQThiQyxVQUFTLFNBQXZjLEVBQWlkQyxpQkFBZ0IsZ0JBQWplLEVBQWtmQyxXQUFVLFVBQTVmLEVBQXVnQkMsV0FBVSxVQUFqaEIsRUFBNGhCQyxZQUFXLFdBQXZpQixFQUFtakJDLGlCQUFnQixpQkFBbmtCLEVBQXFsQkMsV0FBVSxVQUEvbEIsRUFBWCxFQUFzbkI5bUIsRUFBRSttQixLQUFGLEdBQVEsRUFBQ0MsU0FBUSxTQUFULEVBQW1CQyxPQUFNLE9BQXpCLEVBQWlDQyxPQUFNLE9BQXZDLEVBQTluQixFQUE4cUJsbkIsRUFBRW1uQixJQUFGLEdBQU8sRUFBQ0MsT0FBTSxPQUFQLEVBQWVDLE9BQU0sT0FBckIsRUFBcnJCLEVBQW10QnJuQixFQUFFeWtCLE9BQUYsR0FBVSxFQUE3dEIsRUFBZ3VCemtCLEVBQUUya0IsT0FBRixHQUFVLENBQUMsRUFBQy9iLFFBQU8sQ0FBQyxPQUFELEVBQVMsVUFBVCxDQUFSLEVBQTZCZ2MsS0FBSSxlQUFVO0FBQUMsV0FBS3BCLE1BQUwsR0FBWSxLQUFLdG1CLFFBQUwsQ0FBY3lJLEtBQWQsRUFBWjtBQUFrQyxLQUE5RSxFQUFELEVBQWlGLEVBQUNpRCxRQUFPLENBQUMsT0FBRCxFQUFTLE9BQVQsRUFBaUIsVUFBakIsQ0FBUixFQUFxQ2djLEtBQUksYUFBU2hDLENBQVQsRUFBVztBQUFDQSxRQUFFelksT0FBRixHQUFVLEtBQUtzWixNQUFMLElBQWEsS0FBS0EsTUFBTCxDQUFZLEtBQUs2RCxRQUFMLENBQWMsS0FBS2xFLFFBQW5CLENBQVosQ0FBdkI7QUFBaUUsS0FBdEgsRUFBakYsRUFBeU0sRUFBQ3hhLFFBQU8sQ0FBQyxPQUFELEVBQVMsVUFBVCxDQUFSLEVBQTZCZ2MsS0FBSSxlQUFVO0FBQUMsV0FBSzJDLE1BQUwsQ0FBWXpZLFFBQVosQ0FBcUIsU0FBckIsRUFBZ0NrTCxNQUFoQztBQUF5QyxLQUFyRixFQUF6TSxFQUFnUyxFQUFDcFIsUUFBTyxDQUFDLE9BQUQsRUFBUyxPQUFULEVBQWlCLFVBQWpCLENBQVIsRUFBcUNnYyxLQUFJLGFBQVNoQyxDQUFULEVBQVc7QUFBQyxVQUFJQyxJQUFFLEtBQUtHLFFBQUwsQ0FBY3FDLE1BQWQsSUFBc0IsRUFBNUI7QUFBQSxVQUErQnZDLElBQUUsQ0FBQyxLQUFLRSxRQUFMLENBQWN5QyxTQUFoRDtBQUFBLFVBQTBEMUMsSUFBRSxLQUFLQyxRQUFMLENBQWM1bUIsR0FBMUU7QUFBQSxVQUE4RTRELElBQUUsRUFBQzJGLE9BQU0sTUFBUCxFQUFjLGVBQWNvZCxJQUFFRixDQUFGLEdBQUksRUFBaEMsRUFBbUMsZ0JBQWVFLElBQUUsRUFBRixHQUFLRixDQUF2RCxFQUFoRixDQUEwSSxDQUFDQyxDQUFELElBQUksS0FBS3lFLE1BQUwsQ0FBWXpZLFFBQVosR0FBdUJ4RSxHQUF2QixDQUEyQnRLLENBQTNCLENBQUosRUFBa0M0aUIsRUFBRXRZLEdBQUYsR0FBTXRLLENBQXhDO0FBQTBDLEtBQXpPLEVBQWhTLEVBQTJnQixFQUFDNEksUUFBTyxDQUFDLE9BQUQsRUFBUyxPQUFULEVBQWlCLFVBQWpCLENBQVIsRUFBcUNnYyxLQUFJLGFBQVNoQyxDQUFULEVBQVc7QUFBQyxVQUFJQyxJQUFFLENBQUMsS0FBS2xkLEtBQUwsS0FBYSxLQUFLcWQsUUFBTCxDQUFjeFUsS0FBNUIsRUFBbUNnWixPQUFuQyxDQUEyQyxDQUEzQyxJQUE4QyxLQUFLeEUsUUFBTCxDQUFjcUMsTUFBbEU7QUFBQSxVQUF5RXZDLElBQUUsSUFBM0U7QUFBQSxVQUFnRkMsSUFBRSxLQUFLVSxNQUFMLENBQVk1a0IsTUFBOUY7QUFBQSxVQUFxR21CLElBQUUsQ0FBQyxLQUFLZ2pCLFFBQUwsQ0FBY3lDLFNBQXRIO0FBQUEsVUFBZ0lnQyxJQUFFLEVBQWxJLENBQXFJLEtBQUk3RSxFQUFFcFUsS0FBRixHQUFRLEVBQUMrVyxPQUFNLENBQUMsQ0FBUixFQUFVNWYsT0FBTWtkLENBQWhCLEVBQVosRUFBK0JFLEdBQS9CO0FBQW9DRCxZQUFFLEtBQUthLFFBQUwsQ0FBY1osQ0FBZCxDQUFGLEVBQW1CRCxJQUFFLEtBQUtFLFFBQUwsQ0FBY3dDLFFBQWQsSUFBd0J6bUIsS0FBS2tYLEdBQUwsQ0FBUzZNLENBQVQsRUFBVyxLQUFLRSxRQUFMLENBQWN4VSxLQUF6QixDQUF4QixJQUF5RHNVLENBQTlFLEVBQWdGRixFQUFFcFUsS0FBRixDQUFRK1csS0FBUixHQUFjekMsSUFBRSxDQUFGLElBQUtGLEVBQUVwVSxLQUFGLENBQVErVyxLQUEzRyxFQUFpSGtDLEVBQUUxRSxDQUFGLElBQUsvaUIsSUFBRTZpQixJQUFFQyxDQUFKLEdBQU0sS0FBS1csTUFBTCxDQUFZVixDQUFaLEVBQWVwZCxLQUFmLEVBQTVIO0FBQXBDLE9BQXVMLEtBQUtpZSxPQUFMLEdBQWE2RCxDQUFiO0FBQWUsS0FBaFksRUFBM2dCLEVBQTY0QixFQUFDN2UsUUFBTyxDQUFDLE9BQUQsRUFBUyxVQUFULENBQVIsRUFBNkJnYyxLQUFJLGVBQVU7QUFBQyxVQUFJL0IsSUFBRSxFQUFOO0FBQUEsVUFBU0MsSUFBRSxLQUFLVyxNQUFoQjtBQUFBLFVBQXVCVixJQUFFLEtBQUtDLFFBQTlCO0FBQUEsVUFBdUNoakIsSUFBRWpCLEtBQUt3RSxHQUFMLENBQVMsSUFBRXdmLEVBQUV2VSxLQUFiLEVBQW1CLENBQW5CLENBQXpDO0FBQUEsVUFBK0RpWixJQUFFLElBQUUxb0IsS0FBSzJvQixJQUFMLENBQVU1RSxFQUFFamtCLE1BQUYsR0FBUyxDQUFuQixDQUFuRTtBQUFBLFVBQXlGOG9CLElBQUU1RSxFQUFFK0IsSUFBRixJQUFRaEMsRUFBRWprQixNQUFWLEdBQWlCa2tCLEVBQUVpQyxNQUFGLEdBQVNobEIsQ0FBVCxHQUFXakIsS0FBS3dFLEdBQUwsQ0FBU3ZELENBQVQsRUFBV3luQixDQUFYLENBQTVCLEdBQTBDLENBQXJJO0FBQUEsVUFBdUlHLElBQUUsRUFBekk7QUFBQSxVQUE0SXJvQixJQUFFLEVBQTlJLENBQWlKLEtBQUlvb0IsS0FBRyxDQUFQLEVBQVNBLEdBQVQ7QUFBYzlFLFVBQUV4bEIsSUFBRixDQUFPLEtBQUt3cUIsU0FBTCxDQUFlaEYsRUFBRWhrQixNQUFGLEdBQVMsQ0FBeEIsRUFBMEIsQ0FBQyxDQUEzQixDQUFQLEdBQXNDK29CLEtBQUc5RSxFQUFFRCxFQUFFQSxFQUFFaGtCLE1BQUYsR0FBUyxDQUFYLENBQUYsRUFBaUIsQ0FBakIsRUFBb0JpcEIsU0FBN0QsRUFBdUVqRixFQUFFeGxCLElBQUYsQ0FBTyxLQUFLd3FCLFNBQUwsQ0FBZS9FLEVBQUVqa0IsTUFBRixHQUFTLENBQVQsR0FBVyxDQUFDZ2tCLEVBQUVoa0IsTUFBRixHQUFTLENBQVYsSUFBYSxDQUF2QyxFQUF5QyxDQUFDLENBQTFDLENBQVAsQ0FBdkUsRUFBNEhVLElBQUV1akIsRUFBRUQsRUFBRUEsRUFBRWhrQixNQUFGLEdBQVMsQ0FBWCxDQUFGLEVBQWlCLENBQWpCLEVBQW9CaXBCLFNBQXBCLEdBQThCdm9CLENBQTVKO0FBQWQsT0FBNEssS0FBS21rQixPQUFMLEdBQWFiLENBQWIsRUFBZUQsRUFBRWdGLENBQUYsRUFBSzlaLFFBQUwsQ0FBYyxRQUFkLEVBQXdCak0sUUFBeEIsQ0FBaUMsS0FBSzBsQixNQUF0QyxDQUFmLEVBQTZEM0UsRUFBRXJqQixDQUFGLEVBQUt1TyxRQUFMLENBQWMsUUFBZCxFQUF3QjJKLFNBQXhCLENBQWtDLEtBQUs4UCxNQUF2QyxDQUE3RDtBQUE0RyxLQUFyZCxFQUE3NEIsRUFBbzJDLEVBQUMzZSxRQUFPLENBQUMsT0FBRCxFQUFTLE9BQVQsRUFBaUIsVUFBakIsQ0FBUixFQUFxQ2djLEtBQUksZUFBVTtBQUFDLFdBQUksSUFBSWhDLElBQUUsS0FBS0ksUUFBTCxDQUFjNW1CLEdBQWQsR0FBa0IsQ0FBbEIsR0FBb0IsQ0FBQyxDQUEzQixFQUE2QnltQixJQUFFLEtBQUthLE9BQUwsQ0FBYTdrQixNQUFiLEdBQW9CLEtBQUs0a0IsTUFBTCxDQUFZNWtCLE1BQS9ELEVBQXNFaWtCLElBQUUsQ0FBQyxDQUF6RSxFQUEyRUMsSUFBRSxDQUE3RSxFQUErRS9pQixJQUFFLENBQWpGLEVBQW1GeW5CLElBQUUsRUFBekYsRUFBNEYsRUFBRTNFLENBQUYsR0FBSUQsQ0FBaEc7QUFBbUdFLFlBQUUwRSxFQUFFM0UsSUFBRSxDQUFKLEtBQVEsQ0FBVixFQUFZOWlCLElBQUUsS0FBSzRqQixPQUFMLENBQWEsS0FBSzBELFFBQUwsQ0FBY3hFLENBQWQsQ0FBYixJQUErQixLQUFLRSxRQUFMLENBQWNxQyxNQUEzRCxFQUFrRW9DLEVBQUVwcUIsSUFBRixDQUFPMGxCLElBQUUvaUIsSUFBRTRpQixDQUFYLENBQWxFO0FBQW5HLE9BQW1MLEtBQUtVLFlBQUwsR0FBa0JtRSxDQUFsQjtBQUFvQixLQUEzUCxFQUFwMkMsRUFBaW1ELEVBQUM3ZSxRQUFPLENBQUMsT0FBRCxFQUFTLE9BQVQsRUFBaUIsVUFBakIsQ0FBUixFQUFxQ2djLEtBQUksZUFBVTtBQUFDLFVBQUloQyxJQUFFLEtBQUtJLFFBQUwsQ0FBY3NDLFlBQXBCO0FBQUEsVUFBaUN6QyxJQUFFLEtBQUtTLFlBQXhDO0FBQUEsVUFBcURSLElBQUUsRUFBQ25kLE9BQU01RyxLQUFLMm9CLElBQUwsQ0FBVTNvQixLQUFLcVMsR0FBTCxDQUFTeVIsRUFBRUEsRUFBRWhrQixNQUFGLEdBQVMsQ0FBWCxDQUFULENBQVYsSUFBbUMsSUFBRStqQixDQUE1QyxFQUE4QyxnQkFBZUEsS0FBRyxFQUFoRSxFQUFtRSxpQkFBZ0JBLEtBQUcsRUFBdEYsRUFBdkQsQ0FBaUosS0FBSzJFLE1BQUwsQ0FBWWpkLEdBQVosQ0FBZ0J3WSxDQUFoQjtBQUFtQixLQUF4TixFQUFqbUQsRUFBMnpELEVBQUNsYSxRQUFPLENBQUMsT0FBRCxFQUFTLE9BQVQsRUFBaUIsVUFBakIsQ0FBUixFQUFxQ2djLEtBQUksYUFBU2hDLENBQVQsRUFBVztBQUFDLFVBQUlDLElBQUUsS0FBS1MsWUFBTCxDQUFrQnprQixNQUF4QjtBQUFBLFVBQStCaWtCLElBQUUsQ0FBQyxLQUFLRSxRQUFMLENBQWN5QyxTQUFoRDtBQUFBLFVBQTBEMUMsSUFBRSxLQUFLd0UsTUFBTCxDQUFZelksUUFBWixFQUE1RCxDQUFtRixJQUFHZ1UsS0FBR0YsRUFBRXBVLEtBQUYsQ0FBUStXLEtBQWQsRUFBb0IsT0FBSzFDLEdBQUw7QUFBVUQsVUFBRXRZLEdBQUYsQ0FBTTNFLEtBQU4sR0FBWSxLQUFLaWUsT0FBTCxDQUFhLEtBQUswRCxRQUFMLENBQWN6RSxDQUFkLENBQWIsQ0FBWixFQUEyQ0UsRUFBRTVaLEVBQUYsQ0FBSzBaLENBQUwsRUFBUXZZLEdBQVIsQ0FBWXNZLEVBQUV0WSxHQUFkLENBQTNDO0FBQVYsT0FBcEIsTUFBaUd3WSxNQUFJRixFQUFFdFksR0FBRixDQUFNM0UsS0FBTixHQUFZaWQsRUFBRXBVLEtBQUYsQ0FBUTdJLEtBQXBCLEVBQTBCb2QsRUFBRXpZLEdBQUYsQ0FBTXNZLEVBQUV0WSxHQUFSLENBQTlCO0FBQTRDLEtBQXJSLEVBQTN6RCxFQUFrbEUsRUFBQzFCLFFBQU8sQ0FBQyxPQUFELENBQVIsRUFBa0JnYyxLQUFJLGVBQVU7QUFBQyxXQUFLdEIsWUFBTCxDQUFrQnprQixNQUFsQixHQUF5QixDQUF6QixJQUE0QixLQUFLMG9CLE1BQUwsQ0FBWTlwQixVQUFaLENBQXVCLE9BQXZCLENBQTVCO0FBQTRELEtBQTdGLEVBQWxsRSxFQUFpckUsRUFBQ21MLFFBQU8sQ0FBQyxPQUFELEVBQVMsT0FBVCxFQUFpQixVQUFqQixDQUFSLEVBQXFDZ2MsS0FBSSxhQUFTaEMsQ0FBVCxFQUFXO0FBQUNBLFFBQUV6WSxPQUFGLEdBQVV5WSxFQUFFelksT0FBRixHQUFVLEtBQUtvZCxNQUFMLENBQVl6WSxRQUFaLEdBQXVCb08sS0FBdkIsQ0FBNkIwRixFQUFFelksT0FBL0IsQ0FBVixHQUFrRCxDQUE1RCxFQUE4RHlZLEVBQUV6WSxPQUFGLEdBQVVwTCxLQUFLd0UsR0FBTCxDQUFTLEtBQUt3a0IsT0FBTCxFQUFULEVBQXdCaHBCLEtBQUtrWCxHQUFMLENBQVMsS0FBSytSLE9BQUwsRUFBVCxFQUF3QnBGLEVBQUV6WSxPQUExQixDQUF4QixDQUF4RSxFQUFvSSxLQUFLMEQsS0FBTCxDQUFXK1UsRUFBRXpZLE9BQWIsQ0FBcEk7QUFBMEosS0FBL00sRUFBanJFLEVBQWs0RSxFQUFDdkIsUUFBTyxDQUFDLFVBQUQsQ0FBUixFQUFxQmdjLEtBQUksZUFBVTtBQUFDLFdBQUsxWCxPQUFMLENBQWEsS0FBSythLFdBQUwsQ0FBaUIsS0FBSzdFLFFBQXRCLENBQWI7QUFBOEMsS0FBbEYsRUFBbDRFLEVBQXM5RSxFQUFDeGEsUUFBTyxDQUFDLE9BQUQsRUFBUyxVQUFULEVBQW9CLE9BQXBCLEVBQTRCLFVBQTVCLENBQVIsRUFBZ0RnYyxLQUFJLGVBQVU7QUFBQyxVQUFJaEMsQ0FBSjtBQUFBLFVBQU1DLENBQU47QUFBQSxVQUFRQyxDQUFSO0FBQUEsVUFBVUMsQ0FBVjtBQUFBLFVBQVkvaUIsSUFBRSxLQUFLZ2pCLFFBQUwsQ0FBYzVtQixHQUFkLEdBQWtCLENBQWxCLEdBQW9CLENBQUMsQ0FBbkM7QUFBQSxVQUFxQ3FyQixJQUFFLElBQUUsS0FBS3pFLFFBQUwsQ0FBY3NDLFlBQXZEO0FBQUEsVUFBb0VxQyxJQUFFLEtBQUtNLFdBQUwsQ0FBaUIsS0FBSzlkLE9BQUwsRUFBakIsSUFBaUNzZCxDQUF2RztBQUFBLFVBQXlHRyxJQUFFRCxJQUFFLEtBQUtoaUIsS0FBTCxLQUFhM0YsQ0FBMUg7QUFBQSxVQUE0SFQsSUFBRSxFQUE5SCxDQUFpSSxLQUFJdWpCLElBQUUsQ0FBRixFQUFJQyxJQUFFLEtBQUtPLFlBQUwsQ0FBa0J6a0IsTUFBNUIsRUFBbUNpa0IsSUFBRUMsQ0FBckMsRUFBdUNELEdBQXZDO0FBQTJDRixZQUFFLEtBQUtVLFlBQUwsQ0FBa0JSLElBQUUsQ0FBcEIsS0FBd0IsQ0FBMUIsRUFBNEJELElBQUU5akIsS0FBS3FTLEdBQUwsQ0FBUyxLQUFLa1MsWUFBTCxDQUFrQlIsQ0FBbEIsQ0FBVCxJQUErQjJFLElBQUV6bkIsQ0FBL0QsRUFBaUUsQ0FBQyxLQUFLa29CLEVBQUwsQ0FBUXRGLENBQVIsRUFBVSxJQUFWLEVBQWUrRSxDQUFmLEtBQW1CLEtBQUtPLEVBQUwsQ0FBUXRGLENBQVIsRUFBVSxHQUFWLEVBQWNnRixDQUFkLENBQW5CLElBQXFDLEtBQUtNLEVBQUwsQ0FBUXJGLENBQVIsRUFBVSxHQUFWLEVBQWM4RSxDQUFkLEtBQWtCLEtBQUtPLEVBQUwsQ0FBUXJGLENBQVIsRUFBVSxHQUFWLEVBQWMrRSxDQUFkLENBQXhELEtBQTJFcm9CLEVBQUVsQyxJQUFGLENBQU95bEIsQ0FBUCxDQUE1STtBQUEzQyxPQUFpTSxLQUFLeUUsTUFBTCxDQUFZelksUUFBWixDQUFxQixTQUFyQixFQUFnQy9NLFdBQWhDLENBQTRDLFFBQTVDLEdBQXNELEtBQUt3bEIsTUFBTCxDQUFZelksUUFBWixDQUFxQixTQUFPdlAsRUFBRXFVLElBQUYsQ0FBTyxTQUFQLENBQVAsR0FBeUIsR0FBOUMsRUFBbUQ5RixRQUFuRCxDQUE0RCxRQUE1RCxDQUF0RCxFQUE0SCxLQUFLa1YsUUFBTCxDQUFjK0IsTUFBZCxLQUF1QixLQUFLd0MsTUFBTCxDQUFZelksUUFBWixDQUFxQixTQUFyQixFQUFnQy9NLFdBQWhDLENBQTRDLFFBQTVDLEdBQXNELEtBQUt3bEIsTUFBTCxDQUFZelksUUFBWixHQUF1QjNGLEVBQXZCLENBQTBCLEtBQUtnQixPQUFMLEVBQTFCLEVBQTBDMkQsUUFBMUMsQ0FBbUQsUUFBbkQsQ0FBN0UsQ0FBNUg7QUFBdVEsS0FBeG9CLEVBQXQ5RSxDQUExdUIsRUFBMjBIOU4sRUFBRWtDLFNBQUYsQ0FBWTJpQixVQUFaLEdBQXVCLFlBQVU7QUFBQyxRQUFHLEtBQUtzRCxLQUFMLENBQVcsY0FBWCxHQUEyQixLQUFLL3FCLE9BQUwsQ0FBYSxZQUFiLENBQTNCLEVBQXNELEtBQUtGLFFBQUwsQ0FBY2trQixXQUFkLENBQTBCLEtBQUs0QixRQUFMLENBQWN3RCxRQUF4QyxFQUFpRCxLQUFLeEQsUUFBTCxDQUFjNW1CLEdBQS9ELENBQXRELEVBQTBILEtBQUs0bUIsUUFBTCxDQUFjeUMsU0FBZCxJQUF5QixDQUFDLEtBQUs1YyxFQUFMLENBQVEsYUFBUixDQUF2SixFQUE4SztBQUFDLFVBQUlnYSxDQUFKLEVBQU1DLENBQU4sRUFBUTlpQixDQUFSLENBQVU2aUIsSUFBRSxLQUFLM2xCLFFBQUwsQ0FBY3VDLElBQWQsQ0FBbUIsS0FBbkIsQ0FBRixFQUE0QnFqQixJQUFFLEtBQUtFLFFBQUwsQ0FBY2tELGtCQUFkLEdBQWlDLE1BQUksS0FBS2xELFFBQUwsQ0FBY2tELGtCQUFuRCxHQUFzRW5ELENBQXBHLEVBQXNHL2lCLElBQUUsS0FBSzlDLFFBQUwsQ0FBYzRSLFFBQWQsQ0FBdUJnVSxDQUF2QixFQUEwQm5kLEtBQTFCLEVBQXhHLEVBQTBJa2QsRUFBRWhrQixNQUFGLElBQVVtQixLQUFHLENBQWIsSUFBZ0IsS0FBS29vQixzQkFBTCxDQUE0QnZGLENBQTVCLENBQTFKO0FBQXlMLFVBQUszbEIsUUFBTCxDQUFjNFEsUUFBZCxDQUF1QixLQUFLbUIsT0FBTCxDQUFhc1gsWUFBcEMsR0FBa0QsS0FBS2dCLE1BQUwsR0FBWTNFLEVBQUUsTUFBSSxLQUFLSSxRQUFMLENBQWNvRCxZQUFsQixHQUErQixVQUEvQixHQUEwQyxLQUFLcEQsUUFBTCxDQUFjNEQsVUFBeEQsR0FBbUUsS0FBckUsRUFBNEVsUCxJQUE1RSxDQUFpRixpQkFBZSxLQUFLc0wsUUFBTCxDQUFjNkQsZUFBN0IsR0FBNkMsS0FBOUgsQ0FBOUQsRUFBbU0sS0FBSzNwQixRQUFMLENBQWM0YSxNQUFkLENBQXFCLEtBQUt5UCxNQUFMLENBQVl2aUIsTUFBWixFQUFyQixDQUFuTSxFQUE4TyxLQUFLUCxPQUFMLENBQWEsS0FBS3ZILFFBQUwsQ0FBYzRSLFFBQWQsR0FBeUJnRixHQUF6QixDQUE2QixLQUFLeVQsTUFBTCxDQUFZdmlCLE1BQVosRUFBN0IsQ0FBYixDQUE5TyxFQUErUyxLQUFLOUgsUUFBTCxDQUFjMkwsRUFBZCxDQUFpQixVQUFqQixJQUE2QixLQUFLd2YsT0FBTCxFQUE3QixHQUE0QyxLQUFLQyxVQUFMLENBQWdCLE9BQWhCLENBQTNWLEVBQW9YLEtBQUtwckIsUUFBTCxDQUFjNkUsV0FBZCxDQUEwQixLQUFLa04sT0FBTCxDQUFhc1gsWUFBdkMsRUFBcUR6WSxRQUFyRCxDQUE4RCxLQUFLbUIsT0FBTCxDQUFhcVgsV0FBM0UsQ0FBcFgsRUFBNGMsS0FBS2lDLHFCQUFMLEVBQTVjLEVBQXllLEtBQUtDLEtBQUwsQ0FBVyxjQUFYLENBQXplLEVBQW9nQixLQUFLcHJCLE9BQUwsQ0FBYSxhQUFiLENBQXBnQjtBQUFnaUIsR0FBL3ZKLEVBQWd3SjRDLEVBQUVrQyxTQUFGLENBQVl5UCxLQUFaLEdBQWtCLFlBQVU7QUFBQyxRQUFJa1IsSUFBRSxLQUFLNEYsUUFBTCxFQUFOO0FBQUEsUUFBc0IzRixJQUFFLEtBQUs3VCxPQUFMLENBQWE2VyxVQUFyQztBQUFBLFFBQWdEL0MsSUFBRSxDQUFDLENBQW5EO0FBQUEsUUFBcUQvaUIsSUFBRSxJQUF2RCxDQUE0RDhpQixLQUFHRixFQUFFN2tCLElBQUYsQ0FBTytrQixDQUFQLEVBQVMsVUFBU0YsQ0FBVCxFQUFXO0FBQUNBLFdBQUdDLENBQUgsSUFBTUQsSUFBRUcsQ0FBUixLQUFZQSxJQUFFMkYsT0FBTzlGLENBQVAsQ0FBZDtBQUF5QixLQUE5QyxHQUFnRDVpQixJQUFFNGlCLEVBQUVyYSxNQUFGLENBQVMsRUFBVCxFQUFZLEtBQUswRyxPQUFqQixFQUF5QjZULEVBQUVDLENBQUYsQ0FBekIsQ0FBbEQsRUFBaUYsY0FBWSxPQUFPL2lCLEVBQUVzbEIsWUFBckIsS0FBb0N0bEIsRUFBRXNsQixZQUFGLEdBQWV0bEIsRUFBRXNsQixZQUFGLEVBQW5ELENBQWpGLEVBQXNKLE9BQU90bEIsRUFBRThsQixVQUEvSixFQUEwSzlsQixFQUFFeW1CLGVBQUYsSUFBbUIsS0FBS3ZwQixRQUFMLENBQWNiLElBQWQsQ0FBbUIsT0FBbkIsRUFBMkIsS0FBS2EsUUFBTCxDQUFjYixJQUFkLENBQW1CLE9BQW5CLEVBQTRCb0ksT0FBNUIsQ0FBb0MsSUFBSWlhLE1BQUosQ0FBVyxNQUFJLEtBQUt6UCxPQUFMLENBQWF3WCxlQUFqQixHQUFpQyxXQUE1QyxFQUF3RCxHQUF4RCxDQUFwQyxFQUFpRyxPQUFLMUQsQ0FBdEcsQ0FBM0IsQ0FBaE0sSUFBc1UvaUIsSUFBRTRpQixFQUFFcmEsTUFBRixDQUFTLEVBQVQsRUFBWSxLQUFLMEcsT0FBakIsQ0FBeFUsRUFBa1csS0FBSzdSLE9BQUwsQ0FBYSxRQUFiLEVBQXNCLEVBQUN1ckIsVUFBUyxFQUFDcHNCLE1BQUssVUFBTixFQUFpQm1PLE9BQU0xSyxDQUF2QixFQUFWLEVBQXRCLENBQWxXLEVBQThaLEtBQUt1akIsV0FBTCxHQUFpQlIsQ0FBL2EsRUFBaWIsS0FBS0MsUUFBTCxHQUFjaGpCLENBQS9iLEVBQWljLEtBQUtzb0IsVUFBTCxDQUFnQixVQUFoQixDQUFqYyxFQUE2ZCxLQUFLbHJCLE9BQUwsQ0FBYSxTQUFiLEVBQXVCLEVBQUN1ckIsVUFBUyxFQUFDcHNCLE1BQUssVUFBTixFQUFpQm1PLE9BQU0sS0FBS3NZLFFBQTVCLEVBQVYsRUFBdkIsQ0FBN2Q7QUFBc2lCLEdBQS8zSyxFQUFnNEtoakIsRUFBRWtDLFNBQUYsQ0FBWTBtQixZQUFaLEdBQXlCLFlBQVU7QUFBQyxTQUFLNUYsUUFBTCxDQUFjeUMsU0FBZCxLQUEwQixLQUFLekMsUUFBTCxDQUFjc0MsWUFBZCxHQUEyQixDQUFDLENBQTVCLEVBQThCLEtBQUt0QyxRQUFMLENBQWN1QyxLQUFkLEdBQW9CLENBQUMsQ0FBN0U7QUFBZ0YsR0FBcC9LLEVBQXEvS3ZsQixFQUFFa0MsU0FBRixDQUFZMm1CLE9BQVosR0FBb0IsVUFBU2hHLENBQVQsRUFBVztBQUFDLFFBQUlDLElBQUUsS0FBSzFsQixPQUFMLENBQWEsU0FBYixFQUF1QixFQUFDMHJCLFNBQVFqRyxDQUFULEVBQXZCLENBQU4sQ0FBMEMsT0FBT0MsRUFBRTNsQixJQUFGLEtBQVMybEIsRUFBRTNsQixJQUFGLEdBQU95bEIsRUFBRSxNQUFJLEtBQUtJLFFBQUwsQ0FBY21ELFdBQWxCLEdBQThCLElBQWhDLEVBQXNDclksUUFBdEMsQ0FBK0MsS0FBS21CLE9BQUwsQ0FBYTBYLFNBQTVELEVBQXVFN08sTUFBdkUsQ0FBOEUrSyxDQUE5RSxDQUFoQixHQUFrRyxLQUFLemxCLE9BQUwsQ0FBYSxVQUFiLEVBQXdCLEVBQUMwckIsU0FBUWhHLEVBQUUzbEIsSUFBWCxFQUF4QixDQUFsRyxFQUE0STJsQixFQUFFM2xCLElBQXJKO0FBQTBKLEdBQXp0TCxFQUEwdEw2QyxFQUFFa0MsU0FBRixDQUFZNm1CLE1BQVosR0FBbUIsWUFBVTtBQUFDLFNBQUksSUFBSWxHLElBQUUsQ0FBTixFQUFRQyxJQUFFLEtBQUtnQixLQUFMLENBQVdqbEIsTUFBckIsRUFBNEJra0IsSUFBRUgsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUMsYUFBTyxLQUFLQSxDQUFMLENBQVA7QUFBZSxLQUFuQyxFQUFvQyxLQUFLaUIsWUFBekMsQ0FBOUIsRUFBcUY3akIsSUFBRSxFQUEzRixFQUE4RjZpQixJQUFFQyxDQUFoRztBQUFtRyxPQUFDLEtBQUtlLFlBQUwsQ0FBa0JtRixHQUFsQixJQUF1QnBHLEVBQUVxRyxJQUFGLENBQU8sS0FBS25GLEtBQUwsQ0FBV2pCLENBQVgsRUFBY2phLE1BQXJCLEVBQTRCbWEsQ0FBNUIsRUFBK0Jsa0IsTUFBL0IsR0FBc0MsQ0FBOUQsS0FBa0UsS0FBS2lsQixLQUFMLENBQVdqQixDQUFYLEVBQWMrQixHQUFkLENBQWtCNWtCLENBQWxCLENBQWxFLEVBQXVGNmlCLEdBQXZGO0FBQW5HLEtBQThMLEtBQUtnQixZQUFMLEdBQWtCLEVBQWxCLEVBQXFCLENBQUMsS0FBS2hiLEVBQUwsQ0FBUSxPQUFSLENBQUQsSUFBbUIsS0FBS3NmLEtBQUwsQ0FBVyxPQUFYLENBQXhDO0FBQTRELEdBQWwvTCxFQUFtL0xub0IsRUFBRWtDLFNBQUYsQ0FBWXlELEtBQVosR0FBa0IsVUFBU2lkLENBQVQsRUFBVztBQUFDLFlBQU9BLElBQUVBLEtBQUc1aUIsRUFBRSttQixLQUFGLENBQVFDLE9BQXBCLEdBQTZCLEtBQUtobkIsRUFBRSttQixLQUFGLENBQVFFLEtBQWIsQ0FBbUIsS0FBS2puQixFQUFFK21CLEtBQUYsQ0FBUUcsS0FBYjtBQUFtQixlQUFPLEtBQUsxRCxNQUFaLENBQW1CO0FBQVEsZUFBTyxLQUFLQSxNQUFMLEdBQVksSUFBRSxLQUFLUixRQUFMLENBQWNzQyxZQUE1QixHQUF5QyxLQUFLdEMsUUFBTCxDQUFjcUMsTUFBOUQsQ0FBOUY7QUFBb0ssR0FBcnJNLEVBQXNyTXJsQixFQUFFa0MsU0FBRixDQUFZbW1CLE9BQVosR0FBb0IsWUFBVTtBQUFDLFNBQUtGLEtBQUwsQ0FBVyxZQUFYLEdBQXlCLEtBQUsvcUIsT0FBTCxDQUFhLFNBQWIsQ0FBekIsRUFBaUQsS0FBS3VVLEtBQUwsRUFBakQsRUFBOEQsS0FBS2lYLFlBQUwsRUFBOUQsRUFBa0YsS0FBSzFyQixRQUFMLENBQWM0USxRQUFkLENBQXVCLEtBQUttQixPQUFMLENBQWFvWCxZQUFwQyxDQUFsRixFQUFvSSxLQUFLMEMsTUFBTCxFQUFwSSxFQUFrSixLQUFLN3JCLFFBQUwsQ0FBYzZFLFdBQWQsQ0FBMEIsS0FBS2tOLE9BQUwsQ0FBYW9YLFlBQXZDLENBQWxKLEVBQXVNLEtBQUttQyxLQUFMLENBQVcsWUFBWCxDQUF2TSxFQUFnTyxLQUFLcHJCLE9BQUwsQ0FBYSxXQUFiLENBQWhPO0FBQTBQLEdBQS84TSxFQUFnOU00QyxFQUFFa0MsU0FBRixDQUFZZ25CLGlCQUFaLEdBQThCLFlBQVU7QUFBQ3JHLE1BQUVyZixZQUFGLENBQWUsS0FBSzJsQixXQUFwQixHQUFpQyxLQUFLQSxXQUFMLEdBQWlCdEcsRUFBRTloQixVQUFGLENBQWEsS0FBS21pQixTQUFMLENBQWVrRyxRQUE1QixFQUFxQyxLQUFLcEcsUUFBTCxDQUFjK0MscUJBQW5ELENBQWxEO0FBQTRILEdBQXJuTixFQUFzbk4vbEIsRUFBRWtDLFNBQUYsQ0FBWWtuQixRQUFaLEdBQXFCLFlBQVU7QUFBQyxXQUFNLENBQUMsQ0FBQyxLQUFLM0YsTUFBTCxDQUFZNWtCLE1BQWQsSUFBdUIsS0FBSzJrQixNQUFMLEtBQWMsS0FBS3RtQixRQUFMLENBQWN5SSxLQUFkLEVBQWQsSUFBc0MsQ0FBQyxDQUFDLEtBQUt6SSxRQUFMLENBQWMyTCxFQUFkLENBQWlCLFVBQWpCLENBQUYsS0FBaUMsS0FBS3NmLEtBQUwsQ0FBVyxVQUFYLEdBQXVCLEtBQUsvcUIsT0FBTCxDQUFhLFFBQWIsRUFBdUJpc0Isa0JBQXZCLE1BQTZDLEtBQUtiLEtBQUwsQ0FBVyxVQUFYLEdBQXVCLENBQUMsQ0FBckUsS0FBeUUsS0FBS0YsVUFBTCxDQUFnQixPQUFoQixHQUF5QixLQUFLRCxPQUFMLEVBQXpCLEVBQXdDLEtBQUtHLEtBQUwsQ0FBVyxVQUFYLENBQXhDLEVBQStELEtBQUssS0FBS3ByQixPQUFMLENBQWEsU0FBYixDQUE3SSxDQUF4RCxDQUFuRTtBQUFvUyxHQUExN04sRUFBMjdONEMsRUFBRWtDLFNBQUYsQ0FBWXFtQixxQkFBWixHQUFrQyxZQUFVO0FBQUMzRixNQUFFMEcsT0FBRixDQUFVbkwsVUFBVixJQUFzQixLQUFLb0osTUFBTCxDQUFZbGUsRUFBWixDQUFldVosRUFBRTBHLE9BQUYsQ0FBVW5MLFVBQVYsQ0FBcUJ2ZCxHQUFyQixHQUF5QixXQUF4QyxFQUFvRGdpQixFQUFFNEIsS0FBRixDQUFRLEtBQUsrRSxlQUFiLEVBQTZCLElBQTdCLENBQXBELENBQXRCLEVBQThHLEtBQUt2RyxRQUFMLENBQWM4QyxVQUFkLEtBQTJCLENBQUMsQ0FBNUIsSUFBK0IsS0FBS3pjLEVBQUwsQ0FBUXdaLENBQVIsRUFBVSxRQUFWLEVBQW1CLEtBQUtLLFNBQUwsQ0FBZWdHLGlCQUFsQyxDQUE3SSxFQUFrTSxLQUFLbEcsUUFBTCxDQUFjaUMsU0FBZCxLQUEwQixLQUFLL25CLFFBQUwsQ0FBYzRRLFFBQWQsQ0FBdUIsS0FBS21CLE9BQUwsQ0FBYXlYLFNBQXBDLEdBQStDLEtBQUthLE1BQUwsQ0FBWWxlLEVBQVosQ0FBZSxvQkFBZixFQUFvQ3VaLEVBQUU0QixLQUFGLENBQVEsS0FBS2dGLFdBQWIsRUFBeUIsSUFBekIsQ0FBcEMsQ0FBL0MsRUFBbUgsS0FBS2pDLE1BQUwsQ0FBWWxlLEVBQVosQ0FBZSx5Q0FBZixFQUF5RCxZQUFVO0FBQUMsYUFBTSxDQUFDLENBQVA7QUFBUyxLQUE3RSxDQUE3SSxDQUFsTSxFQUErWixLQUFLMlosUUFBTCxDQUFja0MsU0FBZCxLQUEwQixLQUFLcUMsTUFBTCxDQUFZbGUsRUFBWixDQUFlLHFCQUFmLEVBQXFDdVosRUFBRTRCLEtBQUYsQ0FBUSxLQUFLZ0YsV0FBYixFQUF5QixJQUF6QixDQUFyQyxHQUFxRSxLQUFLakMsTUFBTCxDQUFZbGUsRUFBWixDQUFlLHNCQUFmLEVBQXNDdVosRUFBRTRCLEtBQUYsQ0FBUSxLQUFLaUYsU0FBYixFQUF1QixJQUF2QixDQUF0QyxDQUEvRixDQUEvWjtBQUFta0IsR0FBM2lQLEVBQTRpUHpwQixFQUFFa0MsU0FBRixDQUFZc25CLFdBQVosR0FBd0IsVUFBUzNHLENBQVQsRUFBVztBQUFDLFFBQUlFLElBQUUsSUFBTixDQUFXLE1BQUlGLEVBQUVyYixLQUFOLEtBQWNvYixFQUFFMEcsT0FBRixDQUFVSSxTQUFWLElBQXFCM0csSUFBRSxLQUFLd0UsTUFBTCxDQUFZamQsR0FBWixDQUFnQixXQUFoQixFQUE2QjdGLE9BQTdCLENBQXFDLFlBQXJDLEVBQWtELEVBQWxELEVBQXNEMUUsS0FBdEQsQ0FBNEQsR0FBNUQsQ0FBRixFQUFtRWdqQixJQUFFLEVBQUNuUyxHQUFFbVMsRUFBRSxPQUFLQSxFQUFFbGtCLE1BQVAsR0FBYyxFQUFkLEdBQWlCLENBQW5CLENBQUgsRUFBeUJrUyxHQUFFZ1MsRUFBRSxPQUFLQSxFQUFFbGtCLE1BQVAsR0FBYyxFQUFkLEdBQWlCLENBQW5CLENBQTNCLEVBQTFGLEtBQThJa2tCLElBQUUsS0FBS3dFLE1BQUwsQ0FBWTVnQixRQUFaLEVBQUYsRUFBeUJvYyxJQUFFLEVBQUNuUyxHQUFFLEtBQUtvUyxRQUFMLENBQWM1bUIsR0FBZCxHQUFrQjJtQixFQUFFemQsSUFBRixHQUFPLEtBQUtpaUIsTUFBTCxDQUFZNWhCLEtBQVosRUFBUCxHQUEyQixLQUFLQSxLQUFMLEVBQTNCLEdBQXdDLEtBQUtxZCxRQUFMLENBQWNxQyxNQUF4RSxHQUErRXRDLEVBQUV6ZCxJQUFwRixFQUF5RnlMLEdBQUVnUyxFQUFFM2QsR0FBN0YsRUFBekssR0FBNFEsS0FBS3lELEVBQUwsQ0FBUSxXQUFSLE1BQXVCK1osRUFBRTBHLE9BQUYsQ0FBVUksU0FBVixHQUFvQixLQUFLeGMsT0FBTCxDQUFhNlYsRUFBRW5TLENBQWYsQ0FBcEIsR0FBc0MsS0FBSzJXLE1BQUwsQ0FBWWxPLElBQVosRUFBdEMsRUFBeUQsS0FBS2lQLFVBQUwsQ0FBZ0IsVUFBaEIsQ0FBaEYsQ0FBNVEsRUFBeVgsS0FBS3ByQixRQUFMLENBQWNra0IsV0FBZCxDQUEwQixLQUFLblMsT0FBTCxDQUFhNlgsU0FBdkMsRUFBaUQsZ0JBQWNqRSxFQUFFNWtCLElBQWpFLENBQXpYLEVBQWdjLEtBQUswckIsS0FBTCxDQUFXLENBQVgsQ0FBaGMsRUFBOGMsS0FBSzVGLEtBQUwsQ0FBV0MsSUFBWCxHQUFpQixJQUFJdGhCLElBQUosRUFBRCxDQUFXRSxPQUFYLEVBQTlkLEVBQW1mLEtBQUttaEIsS0FBTCxDQUFXemEsTUFBWCxHQUFrQnNaLEVBQUVDLEVBQUV2WixNQUFKLENBQXJnQixFQUFpaEIsS0FBS3lhLEtBQUwsQ0FBV0csS0FBWCxDQUFpQnhnQixLQUFqQixHQUF1QnFmLENBQXhpQixFQUEwaUIsS0FBS2dCLEtBQUwsQ0FBV0csS0FBWCxDQUFpQi9aLE9BQWpCLEdBQXlCNFksQ0FBbmtCLEVBQXFrQixLQUFLZ0IsS0FBTCxDQUFXRSxPQUFYLEdBQW1CLEtBQUtBLE9BQUwsQ0FBYXBCLENBQWIsQ0FBeGxCLEVBQXdtQkQsRUFBRUUsQ0FBRixFQUFLelosRUFBTCxDQUFRLG9DQUFSLEVBQTZDdVosRUFBRTRCLEtBQUYsQ0FBUSxLQUFLaUYsU0FBYixFQUF1QixJQUF2QixDQUE3QyxDQUF4bUIsRUFBbXJCN0csRUFBRUUsQ0FBRixFQUFLN1UsR0FBTCxDQUFTLHVDQUFULEVBQWlEMlUsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTM0IsQ0FBVCxFQUFXO0FBQUMsVUFBSUUsSUFBRSxLQUFLNkcsVUFBTCxDQUFnQixLQUFLN0YsS0FBTCxDQUFXRSxPQUEzQixFQUFtQyxLQUFLQSxPQUFMLENBQWFwQixDQUFiLENBQW5DLENBQU4sQ0FBMERELEVBQUVFLENBQUYsRUFBS3paLEVBQUwsQ0FBUSx1Q0FBUixFQUFnRHVaLEVBQUU0QixLQUFGLENBQVEsS0FBS3FGLFVBQWIsRUFBd0IsSUFBeEIsQ0FBaEQsR0FBK0U5cUIsS0FBS3FTLEdBQUwsQ0FBUzJSLEVBQUVuUyxDQUFYLElBQWM3UixLQUFLcVMsR0FBTCxDQUFTMlIsRUFBRWhTLENBQVgsQ0FBZCxJQUE2QixLQUFLbEksRUFBTCxDQUFRLE9BQVIsQ0FBN0IsS0FBZ0RnYSxFQUFFdFosY0FBRixJQUFtQixLQUFLNGUsS0FBTCxDQUFXLFVBQVgsQ0FBbkIsRUFBMEMsS0FBSy9xQixPQUFMLENBQWEsTUFBYixDQUExRixDQUEvRTtBQUErTCxLQUE3USxFQUE4USxJQUE5USxDQUFqRCxDQUFqc0I7QUFBd2dDLEdBQW5tUixFQUFvbVI0QyxFQUFFa0MsU0FBRixDQUFZMm5CLFVBQVosR0FBdUIsVUFBU2pILENBQVQsRUFBVztBQUFDLFFBQUlDLElBQUUsSUFBTjtBQUFBLFFBQVdDLElBQUUsSUFBYjtBQUFBLFFBQWtCQyxJQUFFLElBQXBCO0FBQUEsUUFBeUIvaUIsSUFBRSxLQUFLNHBCLFVBQUwsQ0FBZ0IsS0FBSzdGLEtBQUwsQ0FBV0UsT0FBM0IsRUFBbUMsS0FBS0EsT0FBTCxDQUFhckIsQ0FBYixDQUFuQyxDQUEzQjtBQUFBLFFBQStFNkUsSUFBRSxLQUFLbUMsVUFBTCxDQUFnQixLQUFLN0YsS0FBTCxDQUFXRyxLQUFYLENBQWlCeGdCLEtBQWpDLEVBQXVDMUQsQ0FBdkMsQ0FBakYsQ0FBMkgsS0FBSzZJLEVBQUwsQ0FBUSxVQUFSLE1BQXNCK1osRUFBRXJaLGNBQUYsSUFBbUIsS0FBS3laLFFBQUwsQ0FBYzhCLElBQWQsSUFBb0JqQyxJQUFFLEtBQUtvRixXQUFMLENBQWlCLEtBQUtGLE9BQUwsRUFBakIsQ0FBRixFQUFtQ2pGLElBQUUsS0FBS21GLFdBQUwsQ0FBaUIsS0FBS0QsT0FBTCxLQUFlLENBQWhDLElBQW1DbkYsQ0FBeEUsRUFBMEU0RSxFQUFFN1csQ0FBRixHQUFJLENBQUMsQ0FBQzZXLEVBQUU3VyxDQUFGLEdBQUlpUyxDQUFMLElBQVFDLENBQVIsR0FBVUEsQ0FBWCxJQUFjQSxDQUFkLEdBQWdCRCxDQUFsSCxLQUFzSEEsSUFBRSxLQUFLRyxRQUFMLENBQWM1bUIsR0FBZCxHQUFrQixLQUFLNnJCLFdBQUwsQ0FBaUIsS0FBS0QsT0FBTCxFQUFqQixDQUFsQixHQUFtRCxLQUFLQyxXQUFMLENBQWlCLEtBQUtGLE9BQUwsRUFBakIsQ0FBckQsRUFBc0ZqRixJQUFFLEtBQUtFLFFBQUwsQ0FBYzVtQixHQUFkLEdBQWtCLEtBQUs2ckIsV0FBTCxDQUFpQixLQUFLRixPQUFMLEVBQWpCLENBQWxCLEdBQW1ELEtBQUtFLFdBQUwsQ0FBaUIsS0FBS0QsT0FBTCxFQUFqQixDQUEzSSxFQUE0S2pGLElBQUUsS0FBS0MsUUFBTCxDQUFjbUMsUUFBZCxHQUF1QixDQUFDLENBQUQsR0FBR25sQixFQUFFNFEsQ0FBTCxHQUFPLENBQTlCLEdBQWdDLENBQTlNLEVBQWdONlcsRUFBRTdXLENBQUYsR0FBSTdSLEtBQUt3RSxHQUFMLENBQVN4RSxLQUFLa1gsR0FBTCxDQUFTd1IsRUFBRTdXLENBQVgsRUFBYWlTLElBQUVFLENBQWYsQ0FBVCxFQUEyQkQsSUFBRUMsQ0FBN0IsQ0FBMVUsQ0FBbkIsRUFBOFgsS0FBS2dCLEtBQUwsQ0FBV0csS0FBWCxDQUFpQi9aLE9BQWpCLEdBQXlCc2QsQ0FBdlosRUFBeVosS0FBS3ZhLE9BQUwsQ0FBYXVhLEVBQUU3VyxDQUFmLENBQS9hO0FBQWtjLEdBQXBzUyxFQUFxc1M1USxFQUFFa0MsU0FBRixDQUFZdW5CLFNBQVosR0FBc0IsVUFBUzVHLENBQVQsRUFBVztBQUFDLFFBQUlFLElBQUUsS0FBSzZHLFVBQUwsQ0FBZ0IsS0FBSzdGLEtBQUwsQ0FBV0UsT0FBM0IsRUFBbUMsS0FBS0EsT0FBTCxDQUFhcEIsQ0FBYixDQUFuQyxDQUFOO0FBQUEsUUFBMEQ3aUIsSUFBRSxLQUFLK2pCLEtBQUwsQ0FBV0csS0FBWCxDQUFpQi9aLE9BQTdFO0FBQUEsUUFBcUZzZCxJQUFFMUUsRUFBRW5TLENBQUYsR0FBSSxDQUFKLEdBQU0sS0FBS29TLFFBQUwsQ0FBYzVtQixHQUFwQixHQUF3QixNQUF4QixHQUErQixPQUF0SCxDQUE4SHdtQixFQUFFRSxDQUFGLEVBQUtwWixHQUFMLENBQVMsV0FBVCxHQUFzQixLQUFLeE0sUUFBTCxDQUFjNkUsV0FBZCxDQUEwQixLQUFLa04sT0FBTCxDQUFhNlgsU0FBdkMsQ0FBdEIsRUFBd0UsQ0FBQyxNQUFJL0QsRUFBRW5TLENBQU4sSUFBUyxLQUFLL0gsRUFBTCxDQUFRLFVBQVIsQ0FBVCxJQUE4QixDQUFDLEtBQUtBLEVBQUwsQ0FBUSxPQUFSLENBQWhDLE1BQW9ELEtBQUs4Z0IsS0FBTCxDQUFXLEtBQUszRyxRQUFMLENBQWM2QyxZQUFkLElBQTRCLEtBQUs3QyxRQUFMLENBQWMyQyxVQUFyRCxHQUFpRSxLQUFLeGIsT0FBTCxDQUFhLEtBQUtvSyxPQUFMLENBQWF2VSxFQUFFNFEsQ0FBZixFQUFpQixNQUFJbVMsRUFBRW5TLENBQU4sR0FBUTZXLENBQVIsR0FBVSxLQUFLMUQsS0FBTCxDQUFXakosU0FBdEMsQ0FBYixDQUFqRSxFQUFnSSxLQUFLd04sVUFBTCxDQUFnQixVQUFoQixDQUFoSSxFQUE0SixLQUFLUyxNQUFMLEVBQTVKLEVBQTBLLEtBQUtoRixLQUFMLENBQVdqSixTQUFYLEdBQXFCMk0sQ0FBL0wsRUFBaU0sQ0FBQzFvQixLQUFLcVMsR0FBTCxDQUFTMlIsRUFBRW5TLENBQVgsSUFBYyxDQUFkLElBQWtCLElBQUlsTyxJQUFKLEVBQUQsQ0FBV0UsT0FBWCxLQUFxQixLQUFLbWhCLEtBQUwsQ0FBV0MsSUFBaEMsR0FBcUMsR0FBdkQsS0FBNkQsS0FBS0QsS0FBTCxDQUFXemEsTUFBWCxDQUFrQjJFLEdBQWxCLENBQXNCLGdCQUF0QixFQUF1QyxZQUFVO0FBQUMsYUFBTSxDQUFDLENBQVA7QUFBUyxLQUEzRCxDQUFsVCxDQUF4RSxFQUF3YixLQUFLcEYsRUFBTCxDQUFRLFVBQVIsTUFBc0IsS0FBSzJmLEtBQUwsQ0FBVyxVQUFYLEdBQXVCLEtBQUtwckIsT0FBTCxDQUFhLFNBQWIsQ0FBN0MsQ0FBeGI7QUFBOGYsR0FBbjJULEVBQW8yVDRDLEVBQUVrQyxTQUFGLENBQVlxUyxPQUFaLEdBQW9CLFVBQVNzTyxDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFFBQUlDLElBQUUsQ0FBQyxDQUFQO0FBQUEsUUFBUy9pQixJQUFFLEVBQVg7QUFBQSxRQUFjeW5CLElBQUUsS0FBSzloQixLQUFMLEVBQWhCO0FBQUEsUUFBNkJnaUIsSUFBRSxLQUFLTSxXQUFMLEVBQS9CLENBQWtELE9BQU8sS0FBS2pGLFFBQUwsQ0FBY29DLFFBQWQsSUFBd0J4QyxFQUFFN2tCLElBQUYsQ0FBTzRwQixDQUFQLEVBQVMvRSxFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVdnRixDQUFYLEVBQWE7QUFBQyxhQUFNLFdBQVM5RSxDQUFULElBQVlELElBQUUrRSxJQUFFNW5CLENBQWhCLElBQW1CNmlCLElBQUUrRSxJQUFFNW5CLENBQXZCLEdBQXlCK2lCLElBQUVILENBQTNCLEdBQTZCLFlBQVVFLENBQVYsSUFBYUQsSUFBRStFLElBQUVILENBQUYsR0FBSXpuQixDQUFuQixJQUFzQjZpQixJQUFFK0UsSUFBRUgsQ0FBRixHQUFJem5CLENBQTVCLEdBQThCK2lCLElBQUVILElBQUUsQ0FBbEMsR0FBb0MsS0FBS3NGLEVBQUwsQ0FBUXJGLENBQVIsRUFBVSxHQUFWLEVBQWMrRSxDQUFkLEtBQWtCLEtBQUtNLEVBQUwsQ0FBUXJGLENBQVIsRUFBVSxHQUFWLEVBQWM4RSxFQUFFL0UsSUFBRSxDQUFKLEtBQVFnRixJQUFFSCxDQUF4QixDQUFsQixLQUErQzFFLElBQUUsV0FBU0QsQ0FBVCxHQUFXRixJQUFFLENBQWIsR0FBZUEsQ0FBaEUsQ0FBakUsRUFBb0lHLE1BQUksQ0FBQyxDQUEvSTtBQUFpSixLQUF2SyxFQUF3SyxJQUF4SyxDQUFULENBQXhCLEVBQWdOLEtBQUtDLFFBQUwsQ0FBYzhCLElBQWQsS0FBcUIsS0FBS29ELEVBQUwsQ0FBUXJGLENBQVIsRUFBVSxHQUFWLEVBQWM4RSxFQUFFLEtBQUtJLE9BQUwsRUFBRixDQUFkLElBQWlDaEYsSUFBRUYsSUFBRSxLQUFLa0YsT0FBTCxFQUFyQyxHQUFvRCxLQUFLRyxFQUFMLENBQVFyRixDQUFSLEVBQVUsR0FBVixFQUFjOEUsRUFBRSxLQUFLSyxPQUFMLEVBQUYsQ0FBZCxNQUFtQ2pGLElBQUVGLElBQUUsS0FBS21GLE9BQUwsRUFBdkMsQ0FBekUsQ0FBaE4sRUFBaVZqRixDQUF4VjtBQUEwVixHQUFseFUsRUFBbXhVL2lCLEVBQUVrQyxTQUFGLENBQVlnTCxPQUFaLEdBQW9CLFVBQVMyVixDQUFULEVBQVc7QUFBQyxRQUFJQyxJQUFFLEtBQUs2RyxLQUFMLEtBQWEsQ0FBbkIsQ0FBcUIsS0FBSzlnQixFQUFMLENBQVEsV0FBUixLQUFzQixLQUFLMGdCLGVBQUwsRUFBdEIsRUFBNkN6RyxNQUFJLEtBQUtxRixLQUFMLENBQVcsV0FBWCxHQUF3QixLQUFLL3FCLE9BQUwsQ0FBYSxXQUFiLENBQTVCLENBQTdDLEVBQW9Hd2xCLEVBQUUwRyxPQUFGLENBQVVRLFdBQVYsSUFBdUJsSCxFQUFFMEcsT0FBRixDQUFVbkwsVUFBakMsR0FBNEMsS0FBS29KLE1BQUwsQ0FBWWpkLEdBQVosQ0FBZ0IsRUFBQ29mLFdBQVUsaUJBQWU3RyxDQUFmLEdBQWlCLGFBQTVCLEVBQTBDMUUsWUFBVyxLQUFLd0wsS0FBTCxLQUFhLEdBQWIsR0FBaUIsR0FBdEUsRUFBaEIsQ0FBNUMsR0FBd0k3RyxJQUFFLEtBQUt5RSxNQUFMLENBQVlyYSxPQUFaLENBQW9CLEVBQUM1SCxNQUFLdWQsSUFBRSxJQUFSLEVBQXBCLEVBQWtDLEtBQUs4RyxLQUFMLEVBQWxDLEVBQStDLEtBQUszRyxRQUFMLENBQWNpRCxjQUE3RCxFQUE0RXJELEVBQUU0QixLQUFGLENBQVEsS0FBSytFLGVBQWIsRUFBNkIsSUFBN0IsQ0FBNUUsQ0FBRixHQUFrSCxLQUFLaEMsTUFBTCxDQUFZamQsR0FBWixDQUFnQixFQUFDaEYsTUFBS3VkLElBQUUsSUFBUixFQUFoQixDQUE5VjtBQUE2WCxHQUFyc1YsRUFBc3NWN2lCLEVBQUVrQyxTQUFGLENBQVkyRyxFQUFaLEdBQWUsVUFBUytaLENBQVQsRUFBVztBQUFDLFdBQU8sS0FBS3VCLE9BQUwsQ0FBYWhhLE9BQWIsQ0FBcUJ5WSxDQUFyQixLQUF5QixLQUFLdUIsT0FBTCxDQUFhaGEsT0FBYixDQUFxQnlZLENBQXJCLElBQXdCLENBQXhEO0FBQTBELEdBQTN4VixFQUE0eFY1aUIsRUFBRWtDLFNBQUYsQ0FBWWlJLE9BQVosR0FBb0IsVUFBU3lZLENBQVQsRUFBVztBQUFDLFFBQUdBLE1BQUlHLENBQVAsRUFBUyxPQUFPLEtBQUtLLFFBQVosQ0FBcUIsSUFBRyxNQUFJLEtBQUtLLE1BQUwsQ0FBWTVrQixNQUFuQixFQUEwQixPQUFPa2tCLENBQVAsQ0FBUyxJQUFHSCxJQUFFLEtBQUtpRixTQUFMLENBQWVqRixDQUFmLENBQUYsRUFBb0IsS0FBS1EsUUFBTCxLQUFnQlIsQ0FBdkMsRUFBeUM7QUFBQyxVQUFJQyxJQUFFLEtBQUt6bEIsT0FBTCxDQUFhLFFBQWIsRUFBc0IsRUFBQ3VyQixVQUFTLEVBQUNwc0IsTUFBSyxVQUFOLEVBQWlCbU8sT0FBTWtZLENBQXZCLEVBQVYsRUFBdEIsQ0FBTixDQUFrRUMsRUFBRTFsQixJQUFGLEtBQVM0bEIsQ0FBVCxLQUFhSCxJQUFFLEtBQUtpRixTQUFMLENBQWVoRixFQUFFMWxCLElBQWpCLENBQWYsR0FBdUMsS0FBS2ltQixRQUFMLEdBQWNSLENBQXJELEVBQXVELEtBQUswRixVQUFMLENBQWdCLFVBQWhCLENBQXZELEVBQW1GLEtBQUtsckIsT0FBTCxDQUFhLFNBQWIsRUFBdUIsRUFBQ3VyQixVQUFTLEVBQUNwc0IsTUFBSyxVQUFOLEVBQWlCbU8sT0FBTSxLQUFLMFksUUFBNUIsRUFBVixFQUF2QixDQUFuRjtBQUE0SixZQUFPLEtBQUtBLFFBQVo7QUFBcUIsR0FBMXBXLEVBQTJwV3BqQixFQUFFa0MsU0FBRixDQUFZb21CLFVBQVosR0FBdUIsVUFBU3pGLENBQVQsRUFBVztBQUFDLFdBQU0sYUFBV0QsRUFBRTNrQixJQUFGLENBQU80a0IsQ0FBUCxDQUFYLEtBQXVCLEtBQUtnQixZQUFMLENBQWtCaEIsQ0FBbEIsSUFBcUIsQ0FBQyxDQUF0QixFQUF3QixLQUFLaGEsRUFBTCxDQUFRLE9BQVIsS0FBa0IsS0FBSzJmLEtBQUwsQ0FBVyxPQUFYLENBQWpFLEdBQXNGNUYsRUFBRTFpQixHQUFGLENBQU0sS0FBSzJqQixZQUFYLEVBQXdCLFVBQVNqQixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLGFBQU9BLENBQVA7QUFBUyxLQUEvQyxDQUE1RjtBQUE2SSxHQUEzMFcsRUFBNDBXN2lCLEVBQUVrQyxTQUFGLENBQVkyTCxLQUFaLEdBQWtCLFVBQVMrVSxDQUFULEVBQVc7QUFBQ0EsUUFBRSxLQUFLaUYsU0FBTCxDQUFlakYsQ0FBZixDQUFGLEVBQW9CQSxNQUFJRyxDQUFKLEtBQVEsS0FBS00sTUFBTCxHQUFZLENBQVosRUFBYyxLQUFLRCxRQUFMLEdBQWNSLENBQTVCLEVBQThCLEtBQUttSCxRQUFMLENBQWMsQ0FBQyxXQUFELEVBQWEsWUFBYixDQUFkLENBQTlCLEVBQXdFLEtBQUs3YyxPQUFMLENBQWEsS0FBSythLFdBQUwsQ0FBaUJyRixDQUFqQixDQUFiLENBQXhFLEVBQTBHLEtBQUtvSCxPQUFMLENBQWEsQ0FBQyxXQUFELEVBQWEsWUFBYixDQUFiLENBQWxILENBQXBCO0FBQWdMLEdBQTFoWCxFQUEyaFhocUIsRUFBRWtDLFNBQUYsQ0FBWTJsQixTQUFaLEdBQXNCLFVBQVNqRixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFFBQUlDLElBQUUsS0FBS1csTUFBTCxDQUFZNWtCLE1BQWxCO0FBQUEsUUFBeUJtQixJQUFFNmlCLElBQUUsQ0FBRixHQUFJLEtBQUthLE9BQUwsQ0FBYTdrQixNQUE1QyxDQUFtRCxPQUFNLENBQUMsS0FBS29yQixTQUFMLENBQWVySCxDQUFmLENBQUQsSUFBb0JFLElBQUUsQ0FBdEIsR0FBd0JGLElBQUVHLENBQTFCLEdBQTRCLENBQUNILElBQUUsQ0FBRixJQUFLQSxLQUFHRSxJQUFFOWlCLENBQVgsTUFBZ0I0aUIsSUFBRSxDQUFDLENBQUNBLElBQUU1aUIsSUFBRSxDQUFMLElBQVE4aUIsQ0FBUixHQUFVQSxDQUFYLElBQWNBLENBQWQsR0FBZ0I5aUIsSUFBRSxDQUFwQyxDQUE1QixFQUFtRTRpQixDQUF6RTtBQUEyRSxHQUE3clgsRUFBOHJYNWlCLEVBQUVrQyxTQUFGLENBQVlvbEIsUUFBWixHQUFxQixVQUFTMUUsQ0FBVCxFQUFXO0FBQUMsV0FBT0EsS0FBRyxLQUFLYyxPQUFMLENBQWE3a0IsTUFBYixHQUFvQixDQUF2QixFQUF5QixLQUFLZ3BCLFNBQUwsQ0FBZWpGLENBQWYsRUFBaUIsQ0FBQyxDQUFsQixDQUFoQztBQUFxRCxHQUFweFgsRUFBcXhYNWlCLEVBQUVrQyxTQUFGLENBQVk4bEIsT0FBWixHQUFvQixVQUFTcEYsQ0FBVCxFQUFXO0FBQUMsUUFBSUMsQ0FBSjtBQUFBLFFBQU1DLENBQU47QUFBQSxRQUFRQyxDQUFSO0FBQUEsUUFBVS9pQixJQUFFLEtBQUtnakIsUUFBakI7QUFBQSxRQUEwQnlFLElBQUUsS0FBS25FLFlBQUwsQ0FBa0J6a0IsTUFBOUMsQ0FBcUQsSUFBR21CLEVBQUU4a0IsSUFBTCxFQUFVMkMsSUFBRSxLQUFLL0QsT0FBTCxDQUFhN2tCLE1BQWIsR0FBb0IsQ0FBcEIsR0FBc0IsS0FBSzRrQixNQUFMLENBQVk1a0IsTUFBbEMsR0FBeUMsQ0FBM0MsQ0FBVixLQUE0RCxJQUFHbUIsRUFBRXlsQixTQUFGLElBQWF6bEIsRUFBRXVsQixLQUFsQixFQUF3QjtBQUFDLFdBQUkxQyxJQUFFLEtBQUtZLE1BQUwsQ0FBWTVrQixNQUFkLEVBQXFCaWtCLElBQUUsS0FBS1csTUFBTCxDQUFZLEVBQUVaLENBQWQsRUFBaUJsZCxLQUFqQixFQUF2QixFQUFnRG9kLElBQUUsS0FBSzdsQixRQUFMLENBQWN5SSxLQUFkLEVBQXRELEVBQTRFa2QsUUFBTUMsS0FBRyxLQUFLVyxNQUFMLENBQVlaLENBQVosRUFBZWxkLEtBQWYsS0FBdUIsS0FBS3FkLFFBQUwsQ0FBY3FDLE1BQXhDLEVBQStDLEVBQUV2QyxJQUFFQyxDQUFKLENBQXJELENBQTVFLEtBQTJJMEUsSUFBRTVFLElBQUUsQ0FBSjtBQUFNLEtBQTFLLE1BQStLNEUsSUFBRXpuQixFQUFFK2tCLE1BQUYsR0FBUyxLQUFLdEIsTUFBTCxDQUFZNWtCLE1BQVosR0FBbUIsQ0FBNUIsR0FBOEIsS0FBSzRrQixNQUFMLENBQVk1a0IsTUFBWixHQUFtQm1CLEVBQUV3TyxLQUFyRCxDQUEyRCxPQUFPb1UsTUFBSTZFLEtBQUcsS0FBSy9ELE9BQUwsQ0FBYTdrQixNQUFiLEdBQW9CLENBQTNCLEdBQThCRSxLQUFLd0UsR0FBTCxDQUFTa2tCLENBQVQsRUFBVyxDQUFYLENBQXJDO0FBQW1ELEdBQW5zWSxFQUFvc1l6bkIsRUFBRWtDLFNBQUYsQ0FBWTZsQixPQUFaLEdBQW9CLFVBQVNuRixDQUFULEVBQVc7QUFBQyxXQUFPQSxJQUFFLENBQUYsR0FBSSxLQUFLYyxPQUFMLENBQWE3a0IsTUFBYixHQUFvQixDQUEvQjtBQUFpQyxHQUFyd1ksRUFBc3dZbUIsRUFBRWtDLFNBQUYsQ0FBWXNNLEtBQVosR0FBa0IsVUFBU29VLENBQVQsRUFBVztBQUFDLFdBQU9BLE1BQUlHLENBQUosR0FBTSxLQUFLVSxNQUFMLENBQVlya0IsS0FBWixFQUFOLElBQTJCd2pCLElBQUUsS0FBS2lGLFNBQUwsQ0FBZWpGLENBQWYsRUFBaUIsQ0FBQyxDQUFsQixDQUFGLEVBQXVCLEtBQUthLE1BQUwsQ0FBWWIsQ0FBWixDQUFsRCxDQUFQO0FBQXlFLEdBQTcyWSxFQUE4Mlk1aUIsRUFBRWtDLFNBQUYsQ0FBWWdvQixPQUFaLEdBQW9CLFVBQVN0SCxDQUFULEVBQVc7QUFBQyxXQUFPQSxNQUFJRyxDQUFKLEdBQU0sS0FBS1ksUUFBTCxDQUFjdmtCLEtBQWQsRUFBTixJQUE2QndqQixJQUFFLEtBQUtpRixTQUFMLENBQWVqRixDQUFmLEVBQWlCLENBQUMsQ0FBbEIsQ0FBRixFQUF1QixLQUFLZSxRQUFMLENBQWNmLENBQWQsQ0FBcEQsQ0FBUDtBQUE2RSxHQUEzOVksRUFBNDlZNWlCLEVBQUVrQyxTQUFGLENBQVlpb0IsTUFBWixHQUFtQixVQUFTdEgsQ0FBVCxFQUFXO0FBQUMsUUFBSUMsSUFBRSxLQUFLWSxPQUFMLENBQWE3a0IsTUFBYixHQUFvQixDQUExQjtBQUFBLFFBQTRCbUIsSUFBRThpQixJQUFFLEtBQUtXLE1BQUwsQ0FBWTVrQixNQUE1QztBQUFBLFFBQW1ENG9CLElBQUUsU0FBRkEsQ0FBRSxDQUFTN0UsQ0FBVCxFQUFXO0FBQUMsYUFBT0EsSUFBRSxDQUFGLEtBQU0sQ0FBTixHQUFRNWlCLElBQUU0aUIsSUFBRSxDQUFaLEdBQWNFLElBQUUsQ0FBQ0YsSUFBRSxDQUFILElBQU0sQ0FBN0I7QUFBK0IsS0FBaEcsQ0FBaUcsT0FBT0MsTUFBSUUsQ0FBSixHQUFNSCxFQUFFMWlCLEdBQUYsQ0FBTSxLQUFLd2pCLE9BQVgsRUFBbUIsVUFBU2QsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxhQUFPNEUsRUFBRTVFLENBQUYsQ0FBUDtBQUFZLEtBQTdDLENBQU4sR0FBcURELEVBQUUxaUIsR0FBRixDQUFNLEtBQUt3akIsT0FBWCxFQUFtQixVQUFTZCxDQUFULEVBQVdFLENBQVgsRUFBYTtBQUFDLGFBQU9GLE1BQUlDLENBQUosR0FBTTRFLEVBQUUzRSxDQUFGLENBQU4sR0FBVyxJQUFsQjtBQUF1QixLQUF4RCxDQUE1RDtBQUFzSCxHQUFsdFosRUFBbXRaOWlCLEVBQUVrQyxTQUFGLENBQVl5bkIsS0FBWixHQUFrQixVQUFTL0csQ0FBVCxFQUFXO0FBQUMsV0FBT0EsTUFBSUcsQ0FBSixLQUFRLEtBQUtNLE1BQUwsR0FBWVQsQ0FBcEIsR0FBdUIsS0FBS1MsTUFBbkM7QUFBMEMsR0FBM3haLEVBQTR4WnJqQixFQUFFa0MsU0FBRixDQUFZK2xCLFdBQVosR0FBd0IsVUFBU3BGLENBQVQsRUFBVztBQUFDLFFBQUlDLENBQUo7QUFBQSxRQUFNOWlCLElBQUUsQ0FBUjtBQUFBLFFBQVV5bkIsSUFBRTVFLElBQUUsQ0FBZCxDQUFnQixPQUFPQSxNQUFJRSxDQUFKLEdBQU1ILEVBQUUxaUIsR0FBRixDQUFNLEtBQUtvakIsWUFBWCxFQUF3QlYsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxhQUFPLEtBQUtvRixXQUFMLENBQWlCcEYsQ0FBakIsQ0FBUDtBQUEyQixLQUFqRCxFQUFrRCxJQUFsRCxDQUF4QixDQUFOLElBQXdGLEtBQUtHLFFBQUwsQ0FBYytCLE1BQWQsSUFBc0IsS0FBSy9CLFFBQUwsQ0FBYzVtQixHQUFkLEtBQW9CNEQsSUFBRSxDQUFDLENBQUgsRUFBS3luQixJQUFFNUUsSUFBRSxDQUE3QixHQUFnQ0MsSUFBRSxLQUFLUSxZQUFMLENBQWtCVCxDQUFsQixDQUFsQyxFQUF1REMsS0FBRyxDQUFDLEtBQUtuZCxLQUFMLEtBQWFtZCxDQUFiLElBQWdCLEtBQUtRLFlBQUwsQ0FBa0JtRSxDQUFsQixLQUFzQixDQUF0QyxDQUFELElBQTJDLENBQTNDLEdBQTZDem5CLENBQTdILElBQWdJOGlCLElBQUUsS0FBS1EsWUFBTCxDQUFrQm1FLENBQWxCLEtBQXNCLENBQXhKLEVBQTBKM0UsSUFBRS9qQixLQUFLMm9CLElBQUwsQ0FBVTVFLENBQVYsQ0FBcFAsQ0FBUDtBQUF5USxHQUF6bGEsRUFBMGxhOWlCLEVBQUVrQyxTQUFGLENBQVltTCxRQUFaLEdBQXFCLFVBQVN1VixDQUFULEVBQVdDLENBQVgsRUFBYUMsQ0FBYixFQUFlO0FBQUMsV0FBTyxNQUFJQSxDQUFKLEdBQU0sQ0FBTixHQUFRL2pCLEtBQUtrWCxHQUFMLENBQVNsWCxLQUFLd0UsR0FBTCxDQUFTeEUsS0FBS3FTLEdBQUwsQ0FBU3lSLElBQUVELENBQVgsQ0FBVCxFQUF1QixDQUF2QixDQUFULEVBQW1DLENBQW5DLElBQXNDN2pCLEtBQUtxUyxHQUFMLENBQVMwUixLQUFHLEtBQUtFLFFBQUwsQ0FBYzJDLFVBQTFCLENBQXJEO0FBQTJGLEdBQTF0YSxFQUEydGEzbEIsRUFBRWtDLFNBQUYsQ0FBWWtvQixFQUFaLEdBQWUsVUFBU3hILENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsUUFBSUMsSUFBRSxLQUFLM1ksT0FBTCxFQUFOO0FBQUEsUUFBcUI0WSxJQUFFLElBQXZCO0FBQUEsUUFBNEIvaUIsSUFBRTRpQixJQUFFLEtBQUswRSxRQUFMLENBQWN4RSxDQUFkLENBQWhDO0FBQUEsUUFBaUQyRSxJQUFFLENBQUN6bkIsSUFBRSxDQUFILEtBQU9BLElBQUUsQ0FBVCxDQUFuRDtBQUFBLFFBQStEMm5CLElBQUUsS0FBS2xFLE1BQUwsQ0FBWTVrQixNQUE3RTtBQUFBLFFBQW9GK29CLElBQUUsS0FBS0csT0FBTCxFQUF0RjtBQUFBLFFBQXFHeG9CLElBQUUsS0FBS3lvQixPQUFMLEVBQXZHLENBQXNILEtBQUtoRixRQUFMLENBQWM4QixJQUFkLElBQW9CLENBQUMsS0FBSzlCLFFBQUwsQ0FBY2dDLE1BQWYsSUFBdUJqbUIsS0FBS3FTLEdBQUwsQ0FBU3BSLENBQVQsSUFBWTJuQixJQUFFLENBQXJDLEtBQXlDM25CLEtBQUd5bkIsSUFBRSxDQUFDLENBQUgsR0FBS0UsQ0FBakQsR0FBb0QvRSxJQUFFRSxJQUFFOWlCLENBQXhELEVBQTBEK2lCLElBQUUsQ0FBQyxDQUFDSCxJQUFFZ0YsQ0FBSCxJQUFNRCxDQUFOLEdBQVFBLENBQVQsSUFBWUEsQ0FBWixHQUFjQyxDQUExRSxFQUE0RTdFLE1BQUlILENBQUosSUFBT0csSUFBRS9pQixDQUFGLElBQUtULENBQVosSUFBZXdqQixJQUFFL2lCLENBQUYsR0FBSSxDQUFuQixLQUF1QjhpQixJQUFFQyxJQUFFL2lCLENBQUosRUFBTTRpQixJQUFFRyxDQUFSLEVBQVUsS0FBS2xWLEtBQUwsQ0FBV2lWLENBQVgsQ0FBakMsQ0FBaEcsSUFBaUosS0FBS0UsUUFBTCxDQUFjZ0MsTUFBZCxJQUFzQnpsQixLQUFHLENBQUgsRUFBS3FqQixJQUFFLENBQUNBLElBQUVyakIsQ0FBRixHQUFJQSxDQUFMLElBQVFBLENBQXJDLElBQXdDcWpCLElBQUU3akIsS0FBS3dFLEdBQUwsQ0FBU3FrQixDQUFULEVBQVc3b0IsS0FBS2tYLEdBQUwsQ0FBUzFXLENBQVQsRUFBV3FqQixDQUFYLENBQVgsQ0FBM0wsRUFBcU4sS0FBSytHLEtBQUwsQ0FBVyxLQUFLdGMsUUFBTCxDQUFjeVYsQ0FBZCxFQUFnQkYsQ0FBaEIsRUFBa0JDLENBQWxCLENBQVgsQ0FBck4sRUFBc1AsS0FBSzFZLE9BQUwsQ0FBYXlZLENBQWIsQ0FBdFAsRUFBc1EsS0FBSzFsQixRQUFMLENBQWMyTCxFQUFkLENBQWlCLFVBQWpCLEtBQThCLEtBQUtrZ0IsTUFBTCxFQUFwUztBQUFrVCxHQUFocWIsRUFBaXFiL29CLEVBQUVrQyxTQUFGLENBQVlpVSxJQUFaLEdBQWlCLFVBQVN5TSxDQUFULEVBQVc7QUFBQ0EsUUFBRUEsS0FBRyxDQUFDLENBQU4sRUFBUSxLQUFLd0gsRUFBTCxDQUFRLEtBQUs5QyxRQUFMLENBQWMsS0FBS25kLE9BQUwsRUFBZCxJQUE4QixDQUF0QyxFQUF3Q3lZLENBQXhDLENBQVI7QUFBbUQsR0FBanZiLEVBQWt2YjVpQixFQUFFa0MsU0FBRixDQUFZbW9CLElBQVosR0FBaUIsVUFBU3pILENBQVQsRUFBVztBQUFDQSxRQUFFQSxLQUFHLENBQUMsQ0FBTixFQUFRLEtBQUt3SCxFQUFMLENBQVEsS0FBSzlDLFFBQUwsQ0FBYyxLQUFLbmQsT0FBTCxFQUFkLElBQThCLENBQXRDLEVBQXdDeVksQ0FBeEMsQ0FBUjtBQUFtRCxHQUFsMGIsRUFBbTBiNWlCLEVBQUVrQyxTQUFGLENBQVlxbkIsZUFBWixHQUE0QixVQUFTM0csQ0FBVCxFQUFXO0FBQUMsUUFBR0EsTUFBSUcsQ0FBSixLQUFRSCxFQUFFM1AsZUFBRixJQUFvQixDQUFDMlAsRUFBRXRaLE1BQUYsSUFBVXNaLEVBQUUwSCxVQUFaLElBQXdCMUgsRUFBRTJILGNBQTNCLE1BQTZDLEtBQUtoRCxNQUFMLENBQVl2YyxHQUFaLENBQWdCLENBQWhCLENBQXpFLENBQUgsRUFBZ0csT0FBTSxDQUFDLENBQVAsQ0FBUyxLQUFLd2QsS0FBTCxDQUFXLFdBQVgsR0FBd0IsS0FBS3ByQixPQUFMLENBQWEsWUFBYixDQUF4QjtBQUFtRCxHQUF2Z2MsRUFBd2djNEMsRUFBRWtDLFNBQUYsQ0FBWXVtQixRQUFaLEdBQXFCLFlBQVU7QUFBQyxRQUFJMUYsQ0FBSixDQUFNLE9BQU8sS0FBSzlULE9BQUwsQ0FBYStXLHFCQUFiLEtBQXFDbkQsQ0FBckMsR0FBdUNFLElBQUVILEVBQUUsS0FBSzNULE9BQUwsQ0FBYStXLHFCQUFmLEVBQXNDcmdCLEtBQXRDLEVBQXpDLEdBQXVGa2QsRUFBRTJILFVBQUYsR0FBYXpILElBQUVGLEVBQUUySCxVQUFqQixHQUE0QjFILEVBQUU3UyxlQUFGLElBQW1CNlMsRUFBRTdTLGVBQUYsQ0FBa0J3YSxXQUFyQyxHQUFpRDFILElBQUVELEVBQUU3UyxlQUFGLENBQWtCd2EsV0FBckUsR0FBaUY5ckIsUUFBUWtCLElBQVIsQ0FBYSxnQ0FBYixDQUFwTSxFQUFtUGtqQixDQUExUDtBQUE0UCxHQUExeWMsRUFBMnljL2lCLEVBQUVrQyxTQUFGLENBQVl1QyxPQUFaLEdBQW9CLFVBQVNvZSxDQUFULEVBQVc7QUFBQyxTQUFLMEUsTUFBTCxDQUFZbUQsS0FBWixJQUFvQixLQUFLakgsTUFBTCxHQUFZLEVBQWhDLEVBQW1DWixNQUFJQSxJQUFFQSxhQUFhbmUsTUFBYixHQUFvQm1lLENBQXBCLEdBQXNCRCxFQUFFQyxDQUFGLENBQTVCLENBQW5DLEVBQXFFLEtBQUtHLFFBQUwsQ0FBY2tELGtCQUFkLEtBQW1DckQsSUFBRUEsRUFBRXBqQixJQUFGLENBQU8sTUFBSSxLQUFLdWpCLFFBQUwsQ0FBY2tELGtCQUF6QixDQUFyQyxDQUFyRSxFQUF3SnJELEVBQUVqYSxNQUFGLENBQVMsWUFBVTtBQUFDLGFBQU8sTUFBSSxLQUFLK2hCLFFBQWhCO0FBQXlCLEtBQTdDLEVBQStDNXNCLElBQS9DLENBQW9ENmtCLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUNBLFVBQUUsS0FBS2dHLE9BQUwsQ0FBYWhHLENBQWIsQ0FBRixFQUFrQixLQUFLMEUsTUFBTCxDQUFZelAsTUFBWixDQUFtQitLLENBQW5CLENBQWxCLEVBQXdDLEtBQUtZLE1BQUwsQ0FBWXBtQixJQUFaLENBQWlCd2xCLENBQWpCLENBQXhDLEVBQTRELEtBQUtjLFFBQUwsQ0FBY3RtQixJQUFkLENBQW1CLElBQUV3bEIsRUFBRXBqQixJQUFGLENBQU8sY0FBUCxFQUF1QkMsT0FBdkIsQ0FBK0IsY0FBL0IsRUFBK0NyRCxJQUEvQyxDQUFvRCxZQUFwRCxDQUFGLElBQXFFLENBQXhGLENBQTVEO0FBQXVKLEtBQTdLLEVBQThLLElBQTlLLENBQXBELENBQXhKLEVBQWlZLEtBQUt3UixLQUFMLENBQVcsS0FBS29jLFNBQUwsQ0FBZSxLQUFLakgsUUFBTCxDQUFjMEMsYUFBN0IsSUFBNEMsS0FBSzFDLFFBQUwsQ0FBYzBDLGFBQTFELEdBQXdFLENBQW5GLENBQWpZLEVBQXVkLEtBQUs0QyxVQUFMLENBQWdCLE9BQWhCLENBQXZkO0FBQWdmLEdBQTN6ZCxFQUE0emR0b0IsRUFBRWtDLFNBQUYsQ0FBWXlVLEdBQVosR0FBZ0IsVUFBU2tNLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsUUFBSTlpQixJQUFFLEtBQUtzbkIsUUFBTCxDQUFjLEtBQUtsRSxRQUFuQixDQUFOLENBQW1DTixJQUFFQSxNQUFJQyxDQUFKLEdBQU0sS0FBS1UsTUFBTCxDQUFZNWtCLE1BQWxCLEdBQXlCLEtBQUtncEIsU0FBTCxDQUFlL0UsQ0FBZixFQUFpQixDQUFDLENBQWxCLENBQTNCLEVBQWdERCxJQUFFQSxhQUFhbmUsTUFBYixHQUFvQm1lLENBQXBCLEdBQXNCRCxFQUFFQyxDQUFGLENBQXhFLEVBQTZFLEtBQUt6bEIsT0FBTCxDQUFhLEtBQWIsRUFBbUIsRUFBQzByQixTQUFRakcsQ0FBVCxFQUFXbGMsVUFBU21jLENBQXBCLEVBQW5CLENBQTdFLEVBQXdIRCxJQUFFLEtBQUtnRyxPQUFMLENBQWFoRyxDQUFiLENBQTFILEVBQTBJLE1BQUksS0FBS1ksTUFBTCxDQUFZNWtCLE1BQWhCLElBQXdCaWtCLE1BQUksS0FBS1csTUFBTCxDQUFZNWtCLE1BQXhDLElBQWdELE1BQUksS0FBSzRrQixNQUFMLENBQVk1a0IsTUFBaEIsSUFBd0IsS0FBSzBvQixNQUFMLENBQVl6UCxNQUFaLENBQW1CK0ssQ0FBbkIsQ0FBeEIsRUFBOEMsTUFBSSxLQUFLWSxNQUFMLENBQVk1a0IsTUFBaEIsSUFBd0IsS0FBSzRrQixNQUFMLENBQVlYLElBQUUsQ0FBZCxFQUFpQjhILEtBQWpCLENBQXVCL0gsQ0FBdkIsQ0FBdEUsRUFBZ0csS0FBS1ksTUFBTCxDQUFZcG1CLElBQVosQ0FBaUJ3bEIsQ0FBakIsQ0FBaEcsRUFBb0gsS0FBS2MsUUFBTCxDQUFjdG1CLElBQWQsQ0FBbUIsSUFBRXdsQixFQUFFcGpCLElBQUYsQ0FBTyxjQUFQLEVBQXVCQyxPQUF2QixDQUErQixjQUEvQixFQUErQ3JELElBQS9DLENBQW9ELFlBQXBELENBQUYsSUFBcUUsQ0FBeEYsQ0FBcEssS0FBaVEsS0FBS29uQixNQUFMLENBQVlYLENBQVosRUFBZStILE1BQWYsQ0FBc0JoSSxDQUF0QixHQUF5QixLQUFLWSxNQUFMLENBQVlsbUIsTUFBWixDQUFtQnVsQixDQUFuQixFQUFxQixDQUFyQixFQUF1QkQsQ0FBdkIsQ0FBekIsRUFBbUQsS0FBS2MsUUFBTCxDQUFjcG1CLE1BQWQsQ0FBcUJ1bEIsQ0FBckIsRUFBdUIsQ0FBdkIsRUFBeUIsSUFBRUQsRUFBRXBqQixJQUFGLENBQU8sY0FBUCxFQUF1QkMsT0FBdkIsQ0FBK0IsY0FBL0IsRUFBK0NyRCxJQUEvQyxDQUFvRCxZQUFwRCxDQUFGLElBQXFFLENBQTlGLENBQXBULENBQTFJLEVBQWdpQixLQUFLb25CLE1BQUwsQ0FBWXpqQixDQUFaLEtBQWdCLEtBQUs2TixLQUFMLENBQVcsS0FBSzRWLE1BQUwsQ0FBWXpqQixDQUFaLEVBQWVrZCxLQUFmLEVBQVgsQ0FBaGpCLEVBQW1sQixLQUFLb0wsVUFBTCxDQUFnQixPQUFoQixDQUFubEIsRUFBNG1CLEtBQUtsckIsT0FBTCxDQUFhLE9BQWIsRUFBcUIsRUFBQzByQixTQUFRakcsQ0FBVCxFQUFXbGMsVUFBU21jLENBQXBCLEVBQXJCLENBQTVtQjtBQUF5cEIsR0FBdGhmLEVBQXVoZjlpQixFQUFFa0MsU0FBRixDQUFZOFgsTUFBWixHQUFtQixVQUFTNEksQ0FBVCxFQUFXO0FBQUNBLFFBQUUsS0FBS2lGLFNBQUwsQ0FBZWpGLENBQWYsRUFBaUIsQ0FBQyxDQUFsQixDQUFGLEVBQXVCQSxNQUFJRyxDQUFKLEtBQVEsS0FBSzNsQixPQUFMLENBQWEsUUFBYixFQUFzQixFQUFDMHJCLFNBQVEsS0FBS3JGLE1BQUwsQ0FBWWIsQ0FBWixDQUFULEVBQXdCamMsVUFBU2ljLENBQWpDLEVBQXRCLEdBQTJELEtBQUthLE1BQUwsQ0FBWWIsQ0FBWixFQUFlNUksTUFBZixFQUEzRCxFQUFtRixLQUFLeUosTUFBTCxDQUFZbG1CLE1BQVosQ0FBbUJxbEIsQ0FBbkIsRUFBcUIsQ0FBckIsQ0FBbkYsRUFBMkcsS0FBS2UsUUFBTCxDQUFjcG1CLE1BQWQsQ0FBcUJxbEIsQ0FBckIsRUFBdUIsQ0FBdkIsQ0FBM0csRUFBcUksS0FBSzBGLFVBQUwsQ0FBZ0IsT0FBaEIsQ0FBckksRUFBOEosS0FBS2xyQixPQUFMLENBQWEsU0FBYixFQUF1QixFQUFDMHJCLFNBQVEsSUFBVCxFQUFjbmlCLFVBQVNpYyxDQUF2QixFQUF2QixDQUF0SyxDQUF2QjtBQUFnUCxHQUF0eWYsRUFBdXlmNWlCLEVBQUVrQyxTQUFGLENBQVlrbUIsc0JBQVosR0FBbUMsVUFBU3ZGLENBQVQsRUFBVztBQUFDQSxNQUFFOWtCLElBQUYsQ0FBTzZrQixFQUFFNEIsS0FBRixDQUFRLFVBQVMzQixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFdBQUtxRixLQUFMLENBQVcsYUFBWCxHQUEwQnJGLElBQUVGLEVBQUVFLENBQUYsQ0FBNUIsRUFBaUNGLEVBQUUsSUFBSWtJLEtBQUosRUFBRixFQUFhN2MsR0FBYixDQUFpQixNQUFqQixFQUF3QjJVLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDRSxVQUFFem1CLElBQUYsQ0FBTyxLQUFQLEVBQWF1bUIsRUFBRXRaLE1BQUYsQ0FBU3dHLEdBQXRCLEdBQTJCZ1QsRUFBRXhZLEdBQUYsQ0FBTSxTQUFOLEVBQWdCLENBQWhCLENBQTNCLEVBQThDLEtBQUtrZSxLQUFMLENBQVcsYUFBWCxDQUE5QyxFQUF3RSxDQUFDLEtBQUszZixFQUFMLENBQVEsYUFBUixDQUFELElBQXlCLENBQUMsS0FBS0EsRUFBTCxDQUFRLGNBQVIsQ0FBMUIsSUFBbUQsS0FBS3dmLE9BQUwsRUFBM0g7QUFBMEksT0FBOUosRUFBK0osSUFBL0osQ0FBeEIsRUFBOExoc0IsSUFBOUwsQ0FBbU0sS0FBbk0sRUFBeU15bUIsRUFBRXptQixJQUFGLENBQU8sS0FBUCxLQUFleW1CLEVBQUV6bUIsSUFBRixDQUFPLFVBQVAsQ0FBZixJQUFtQ3ltQixFQUFFem1CLElBQUYsQ0FBTyxpQkFBUCxDQUE1TyxDQUFqQztBQUF3UyxLQUE5VCxFQUErVCxJQUEvVCxDQUFQO0FBQTZVLEdBQW5xZ0IsRUFBb3FnQjJELEVBQUVrQyxTQUFGLENBQVlrZSxPQUFaLEdBQW9CLFlBQVU7QUFBQyxTQUFLbGpCLFFBQUwsQ0FBY3dNLEdBQWQsQ0FBa0IsV0FBbEIsR0FBK0IsS0FBSzZkLE1BQUwsQ0FBWTdkLEdBQVosQ0FBZ0IsV0FBaEIsQ0FBL0IsRUFBNERrWixFQUFFRSxDQUFGLEVBQUtwWixHQUFMLENBQVMsV0FBVCxDQUE1RCxFQUFrRixLQUFLc1osUUFBTCxDQUFjOEMsVUFBZCxLQUEyQixDQUFDLENBQTVCLEtBQWdDakQsRUFBRXJmLFlBQUYsQ0FBZSxLQUFLMmxCLFdBQXBCLEdBQWlDLEtBQUt6ZixHQUFMLENBQVNtWixDQUFULEVBQVcsUUFBWCxFQUFvQixLQUFLSyxTQUFMLENBQWVnRyxpQkFBbkMsQ0FBakUsQ0FBbEYsQ0FBME0sS0FBSSxJQUFJbkcsQ0FBUixJQUFhLEtBQUs3bUIsUUFBbEI7QUFBMkIsV0FBS0EsUUFBTCxDQUFjNm1CLENBQWQsRUFBaUIzQyxPQUFqQjtBQUEzQixLQUFzRCxLQUFLbUgsTUFBTCxDQUFZelksUUFBWixDQUFxQixTQUFyQixFQUFnQ2tMLE1BQWhDLElBQXlDLEtBQUt1TixNQUFMLENBQVl4TixNQUFaLEVBQXpDLEVBQThELEtBQUt3TixNQUFMLENBQVl6WSxRQUFaLEdBQXVCaWMsUUFBdkIsR0FBa0NoUixNQUFsQyxFQUE5RCxFQUF5RyxLQUFLd04sTUFBTCxDQUFZelksUUFBWixHQUF1QmlMLE1BQXZCLEVBQXpHLEVBQXlJLEtBQUs3YyxRQUFMLENBQWM2RSxXQUFkLENBQTBCLEtBQUtrTixPQUFMLENBQWFvWCxZQUF2QyxFQUFxRHRrQixXQUFyRCxDQUFpRSxLQUFLa04sT0FBTCxDQUFhc1gsWUFBOUUsRUFBNEZ4a0IsV0FBNUYsQ0FBd0csS0FBS2tOLE9BQUwsQ0FBYXFYLFdBQXJILEVBQWtJdmtCLFdBQWxJLENBQThJLEtBQUtrTixPQUFMLENBQWF1WCxRQUEzSixFQUFxS3prQixXQUFySyxDQUFpTCxLQUFLa04sT0FBTCxDQUFheVgsU0FBOUwsRUFBeU0za0IsV0FBek0sQ0FBcU4sS0FBS2tOLE9BQUwsQ0FBYTZYLFNBQWxPLEVBQTZPenFCLElBQTdPLENBQWtQLE9BQWxQLEVBQTBQLEtBQUthLFFBQUwsQ0FBY2IsSUFBZCxDQUFtQixPQUFuQixFQUE0Qm9JLE9BQTVCLENBQW9DLElBQUlpYSxNQUFKLENBQVcsS0FBS3pQLE9BQUwsQ0FBYXdYLGVBQWIsR0FBNkIsVUFBeEMsRUFBbUQsR0FBbkQsQ0FBcEMsRUFBNEYsRUFBNUYsQ0FBMVAsRUFBMlYvb0IsVUFBM1YsQ0FBc1csY0FBdFcsQ0FBekk7QUFBK2YsR0FBbDhoQixFQUFtOGhCc0MsRUFBRWtDLFNBQUYsQ0FBWWdtQixFQUFaLEdBQWUsVUFBU3RGLENBQVQsRUFBV0MsQ0FBWCxFQUFhQyxDQUFiLEVBQWU7QUFBQyxRQUFJQyxJQUFFLEtBQUtDLFFBQUwsQ0FBYzVtQixHQUFwQixDQUF3QixRQUFPeW1CLENBQVAsR0FBVSxLQUFJLEdBQUo7QUFBUSxlQUFPRSxJQUFFSCxJQUFFRSxDQUFKLEdBQU1GLElBQUVFLENBQWYsQ0FBaUIsS0FBSSxHQUFKO0FBQVEsZUFBT0MsSUFBRUgsSUFBRUUsQ0FBSixHQUFNRixJQUFFRSxDQUFmLENBQWlCLEtBQUksSUFBSjtBQUFTLGVBQU9DLElBQUVILEtBQUdFLENBQUwsR0FBT0YsS0FBR0UsQ0FBakIsQ0FBbUIsS0FBSSxJQUFKO0FBQVMsZUFBT0MsSUFBRUgsS0FBR0UsQ0FBTCxHQUFPRixLQUFHRSxDQUFqQixDQUFqRztBQUFxSCxHQUEvbWlCLEVBQWduaUI5aUIsRUFBRWtDLFNBQUYsQ0FBWW1ILEVBQVosR0FBZSxVQUFTdVosQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZUMsQ0FBZixFQUFpQjtBQUFDSCxNQUFFdFIsZ0JBQUYsR0FBbUJzUixFQUFFdFIsZ0JBQUYsQ0FBbUJ1UixDQUFuQixFQUFxQkMsQ0FBckIsRUFBdUJDLENBQXZCLENBQW5CLEdBQTZDSCxFQUFFb0ksV0FBRixJQUFlcEksRUFBRW9JLFdBQUYsQ0FBYyxPQUFLbkksQ0FBbkIsRUFBcUJDLENBQXJCLENBQTVEO0FBQW9GLEdBQXJ1aUIsRUFBc3VpQjlpQixFQUFFa0MsU0FBRixDQUFZd0gsR0FBWixHQUFnQixVQUFTa1osQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZUMsQ0FBZixFQUFpQjtBQUFDSCxNQUFFbFMsbUJBQUYsR0FBc0JrUyxFQUFFbFMsbUJBQUYsQ0FBc0JtUyxDQUF0QixFQUF3QkMsQ0FBeEIsRUFBMEJDLENBQTFCLENBQXRCLEdBQW1ESCxFQUFFcUksV0FBRixJQUFlckksRUFBRXFJLFdBQUYsQ0FBYyxPQUFLcEksQ0FBbkIsRUFBcUJDLENBQXJCLENBQWxFO0FBQTBGLEdBQWwyaUIsRUFBbTJpQjlpQixFQUFFa0MsU0FBRixDQUFZOUUsT0FBWixHQUFvQixVQUFTeWxCLENBQVQsRUFBV0MsQ0FBWCxFQUFhQyxDQUFiLEVBQWUwRSxDQUFmLEVBQWlCRSxDQUFqQixFQUFtQjtBQUFDLFFBQUlDLElBQUUsRUFBQ3NELE1BQUssRUFBQ0MsT0FBTSxLQUFLMUgsTUFBTCxDQUFZNWtCLE1BQW5CLEVBQTBCcWUsT0FBTSxLQUFLL1MsT0FBTCxFQUFoQyxFQUFOLEVBQU47QUFBQSxRQUE2RDVLLElBQUVxakIsRUFBRXdJLFNBQUYsQ0FBWXhJLEVBQUVxRyxJQUFGLENBQU8sQ0FBQyxJQUFELEVBQU1wRyxDQUFOLEVBQVFFLENBQVIsQ0FBUCxFQUFrQixVQUFTSCxDQUFULEVBQVc7QUFBQyxhQUFPQSxDQUFQO0FBQVMsS0FBdkMsRUFBeUNoUCxJQUF6QyxDQUE4QyxHQUE5QyxFQUFtRDdXLFdBQW5ELEVBQVosQ0FBL0Q7QUFBQSxRQUE2SXN1QixJQUFFekksRUFBRXdFLEtBQUYsQ0FBUSxDQUFDdkUsQ0FBRCxFQUFHLEtBQUgsRUFBU0UsS0FBRyxVQUFaLEVBQXdCblAsSUFBeEIsQ0FBNkIsR0FBN0IsRUFBa0M3VyxXQUFsQyxFQUFSLEVBQXdENmxCLEVBQUVyYSxNQUFGLENBQVMsRUFBQytpQixlQUFjLElBQWYsRUFBVCxFQUE4QjFELENBQTlCLEVBQWdDOUUsQ0FBaEMsQ0FBeEQsQ0FBL0ksQ0FBMk8sT0FBTyxLQUFLSyxRQUFMLENBQWNOLENBQWQsTUFBbUJELEVBQUU3a0IsSUFBRixDQUFPLEtBQUs3QixRQUFaLEVBQXFCLFVBQVMwbUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQ0EsUUFBRTBJLFNBQUYsSUFBYTFJLEVBQUUwSSxTQUFGLENBQVlGLENBQVosQ0FBYjtBQUE0QixLQUEvRCxHQUFpRSxLQUFLdmlCLFFBQUwsQ0FBYyxFQUFDN0ssTUFBSytCLEVBQUVtbkIsSUFBRixDQUFPQyxLQUFiLEVBQW1CN3FCLE1BQUtzbUIsQ0FBeEIsRUFBZCxDQUFqRSxFQUEyRyxLQUFLM2xCLFFBQUwsQ0FBY0UsT0FBZCxDQUFzQml1QixDQUF0QixDQUEzRyxFQUFvSSxLQUFLckksUUFBTCxJQUFlLGNBQVksT0FBTyxLQUFLQSxRQUFMLENBQWN6akIsQ0FBZCxDQUFsQyxJQUFvRCxLQUFLeWpCLFFBQUwsQ0FBY3pqQixDQUFkLEVBQWlCNEMsSUFBakIsQ0FBc0IsSUFBdEIsRUFBMkJrcEIsQ0FBM0IsQ0FBM00sR0FBME9BLENBQWpQO0FBQW1QLEdBQXoyakIsRUFBMDJqQnJyQixFQUFFa0MsU0FBRixDQUFZaW1CLEtBQVosR0FBa0IsVUFBU3RGLENBQVQsRUFBVztBQUFDRCxNQUFFN2tCLElBQUYsQ0FBTyxDQUFDOGtCLENBQUQsRUFBSTNlLE1BQUosQ0FBVyxLQUFLaWdCLE9BQUwsQ0FBYUMsSUFBYixDQUFrQnZCLENBQWxCLEtBQXNCLEVBQWpDLENBQVAsRUFBNENELEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsV0FBS3NCLE9BQUwsQ0FBYWhhLE9BQWIsQ0FBcUIwWSxDQUFyQixNQUEwQkUsQ0FBMUIsS0FBOEIsS0FBS29CLE9BQUwsQ0FBYWhhLE9BQWIsQ0FBcUIwWSxDQUFyQixJQUF3QixDQUF0RCxHQUF5RCxLQUFLc0IsT0FBTCxDQUFhaGEsT0FBYixDQUFxQjBZLENBQXJCLEdBQXpEO0FBQW1GLEtBQXpHLEVBQTBHLElBQTFHLENBQTVDO0FBQTZKLEdBQXJpa0IsRUFBc2lrQjdpQixFQUFFa0MsU0FBRixDQUFZc21CLEtBQVosR0FBa0IsVUFBUzNGLENBQVQsRUFBVztBQUFDRCxNQUFFN2tCLElBQUYsQ0FBTyxDQUFDOGtCLENBQUQsRUFBSTNlLE1BQUosQ0FBVyxLQUFLaWdCLE9BQUwsQ0FBYUMsSUFBYixDQUFrQnZCLENBQWxCLEtBQXNCLEVBQWpDLENBQVAsRUFBNENELEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsV0FBS3NCLE9BQUwsQ0FBYWhhLE9BQWIsQ0FBcUIwWSxDQUFyQjtBQUEwQixLQUFoRCxFQUFpRCxJQUFqRCxDQUE1QztBQUFvRyxHQUF4cWtCLEVBQXlxa0I3aUIsRUFBRWtDLFNBQUYsQ0FBWTRHLFFBQVosR0FBcUIsVUFBUytaLENBQVQsRUFBVztBQUFDLFFBQUdBLEVBQUU1a0IsSUFBRixLQUFTK0IsRUFBRW1uQixJQUFGLENBQU9DLEtBQW5CLEVBQXlCO0FBQUMsVUFBR3hFLEVBQUV0YixLQUFGLENBQVFtSyxPQUFSLENBQWdCb1IsRUFBRXRtQixJQUFsQixNQUEwQnFtQixFQUFFdGIsS0FBRixDQUFRbUssT0FBUixDQUFnQm9SLEVBQUV0bUIsSUFBbEIsSUFBd0IsRUFBbEQsR0FBc0QsQ0FBQ3FtQixFQUFFdGIsS0FBRixDQUFRbUssT0FBUixDQUFnQm9SLEVBQUV0bUIsSUFBbEIsRUFBd0JpdkIsR0FBbEYsRUFBc0Y7QUFBQyxZQUFJMUksSUFBRUYsRUFBRXRiLEtBQUYsQ0FBUW1LLE9BQVIsQ0FBZ0JvUixFQUFFdG1CLElBQWxCLEVBQXdCa3ZCLFFBQTlCLENBQXVDN0ksRUFBRXRiLEtBQUYsQ0FBUW1LLE9BQVIsQ0FBZ0JvUixFQUFFdG1CLElBQWxCLEVBQXdCa3ZCLFFBQXhCLEdBQWlDLFVBQVM3SSxDQUFULEVBQVc7QUFBQyxpQkFBTSxDQUFDRSxDQUFELElBQUksQ0FBQ0EsRUFBRXJoQixLQUFQLElBQWNtaEIsRUFBRTlqQixTQUFGLElBQWE4akIsRUFBRTlqQixTQUFGLENBQVl0QixPQUFaLENBQW9CLEtBQXBCLE1BQTZCLENBQUMsQ0FBekQsR0FBMkRvbEIsRUFBRTlqQixTQUFGLElBQWE4akIsRUFBRTlqQixTQUFGLENBQVl0QixPQUFaLENBQW9CLEtBQXBCLElBQTJCLENBQUMsQ0FBcEcsR0FBc0dzbEIsRUFBRXJoQixLQUFGLENBQVEsSUFBUixFQUFhRCxTQUFiLENBQTVHO0FBQW9JLFNBQWpMLEVBQWtMb2hCLEVBQUV0YixLQUFGLENBQVFtSyxPQUFSLENBQWdCb1IsRUFBRXRtQixJQUFsQixFQUF3Qml2QixHQUF4QixHQUE0QixDQUFDLENBQS9NO0FBQWlOO0FBQUMsS0FBMVcsTUFBK1czSSxFQUFFNWtCLElBQUYsS0FBUytCLEVBQUVtbkIsSUFBRixDQUFPRSxLQUFoQixLQUF3QixLQUFLbEQsT0FBTCxDQUFhQyxJQUFiLENBQWtCdkIsRUFBRXRtQixJQUFwQixJQUEwQixLQUFLNG5CLE9BQUwsQ0FBYUMsSUFBYixDQUFrQnZCLEVBQUV0bUIsSUFBcEIsSUFBMEIsS0FBSzRuQixPQUFMLENBQWFDLElBQWIsQ0FBa0J2QixFQUFFdG1CLElBQXBCLEVBQTBCMkgsTUFBMUIsQ0FBaUMyZSxFQUFFdUIsSUFBbkMsQ0FBcEQsR0FBNkYsS0FBS0QsT0FBTCxDQUFhQyxJQUFiLENBQWtCdkIsRUFBRXRtQixJQUFwQixJQUEwQnNtQixFQUFFdUIsSUFBekgsRUFBOEgsS0FBS0QsT0FBTCxDQUFhQyxJQUFiLENBQWtCdkIsRUFBRXRtQixJQUFwQixJQUEwQnFtQixFQUFFcUcsSUFBRixDQUFPLEtBQUs5RSxPQUFMLENBQWFDLElBQWIsQ0FBa0J2QixFQUFFdG1CLElBQXBCLENBQVAsRUFBaUNxbUIsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTMUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxhQUFPSCxFQUFFOEksT0FBRixDQUFVNUksQ0FBVixFQUFZLEtBQUtxQixPQUFMLENBQWFDLElBQWIsQ0FBa0J2QixFQUFFdG1CLElBQXBCLENBQVosTUFBeUN3bUIsQ0FBaEQ7QUFBa0QsS0FBeEUsRUFBeUUsSUFBekUsQ0FBakMsQ0FBaEw7QUFBa1MsR0FBMzFsQixFQUE0MWxCL2lCLEVBQUVrQyxTQUFGLENBQVk2bkIsUUFBWixHQUFxQixVQUFTbEgsQ0FBVCxFQUFXO0FBQUNELE1BQUU3a0IsSUFBRixDQUFPOGtCLENBQVAsRUFBU0QsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxXQUFLTSxRQUFMLENBQWNOLENBQWQsSUFBaUIsQ0FBQyxDQUFsQjtBQUFvQixLQUExQyxFQUEyQyxJQUEzQyxDQUFUO0FBQTJELEdBQXg3bEIsRUFBeTdsQjdpQixFQUFFa0MsU0FBRixDQUFZOG5CLE9BQVosR0FBb0IsVUFBU25ILENBQVQsRUFBVztBQUFDRCxNQUFFN2tCLElBQUYsQ0FBTzhrQixDQUFQLEVBQVNELEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsYUFBTyxLQUFLTSxRQUFMLENBQWNOLENBQWQsQ0FBUDtBQUF3QixLQUE5QyxFQUErQyxJQUEvQyxDQUFUO0FBQStELEdBQXhobUIsRUFBeWhtQjdpQixFQUFFa0MsU0FBRixDQUFZK2hCLE9BQVosR0FBb0IsVUFBU3JCLENBQVQsRUFBVztBQUFDLFFBQUlFLElBQUUsRUFBQ2xTLEdBQUUsSUFBSCxFQUFRRyxHQUFFLElBQVYsRUFBTixDQUFzQixPQUFPNlIsSUFBRUEsRUFBRStJLGFBQUYsSUFBaUIvSSxDQUFqQixJQUFvQkMsRUFBRXZiLEtBQXhCLEVBQThCc2IsSUFBRUEsRUFBRS9SLE9BQUYsSUFBVytSLEVBQUUvUixPQUFGLENBQVVoUyxNQUFyQixHQUE0QitqQixFQUFFL1IsT0FBRixDQUFVLENBQVYsQ0FBNUIsR0FBeUMrUixFQUFFN1EsY0FBRixJQUFrQjZRLEVBQUU3USxjQUFGLENBQWlCbFQsTUFBbkMsR0FBMEMrakIsRUFBRTdRLGNBQUYsQ0FBaUIsQ0FBakIsQ0FBMUMsR0FBOEQ2USxDQUF2SSxFQUF5SUEsRUFBRTlSLEtBQUYsSUFBU2dTLEVBQUVsUyxDQUFGLEdBQUlnUyxFQUFFOVIsS0FBTixFQUFZZ1MsRUFBRS9SLENBQUYsR0FBSTZSLEVBQUU1UixLQUEzQixLQUFtQzhSLEVBQUVsUyxDQUFGLEdBQUlnUyxFQUFFblEsT0FBTixFQUFjcVEsRUFBRS9SLENBQUYsR0FBSTZSLEVBQUVsUSxPQUF2RCxDQUF6SSxFQUF5TW9RLENBQWhOO0FBQWtOLEdBQWp5bUIsRUFBa3ltQjlpQixFQUFFa0MsU0FBRixDQUFZK25CLFNBQVosR0FBc0IsVUFBU3JILENBQVQsRUFBVztBQUFDLFdBQU0sQ0FBQ3JlLE1BQU1DLFdBQVdvZSxDQUFYLENBQU4sQ0FBUDtBQUE0QixHQUFoMm1CLEVBQWkybUI1aUIsRUFBRWtDLFNBQUYsQ0FBWTBuQixVQUFaLEdBQXVCLFVBQVNoSCxDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFdBQU0sRUFBQ2pTLEdBQUVnUyxFQUFFaFMsQ0FBRixHQUFJaVMsRUFBRWpTLENBQVQsRUFBV0csR0FBRTZSLEVBQUU3UixDQUFGLEdBQUk4UixFQUFFOVIsQ0FBbkIsRUFBTjtBQUE0QixHQUFsNm1CLEVBQW02bUI2UixFQUFFbmdCLEVBQUYsQ0FBS21wQixXQUFMLEdBQWlCLFVBQVMvSSxDQUFULEVBQVc7QUFBQyxRQUFJQyxJQUFFN2dCLE1BQU1DLFNBQU4sQ0FBZ0I5QyxLQUFoQixDQUFzQitDLElBQXRCLENBQTJCWCxTQUEzQixFQUFxQyxDQUFyQyxDQUFOLENBQThDLE9BQU8sS0FBS3pELElBQUwsQ0FBVSxZQUFVO0FBQUMsVUFBSWdsQixJQUFFSCxFQUFFLElBQUYsQ0FBTjtBQUFBLFVBQWM2RSxJQUFFMUUsRUFBRTVsQixJQUFGLENBQU8sY0FBUCxDQUFoQixDQUF1Q3NxQixNQUFJQSxJQUFFLElBQUl6bkIsQ0FBSixDQUFNLElBQU4sRUFBVyxvQkFBaUI2aUIsQ0FBakIseUNBQWlCQSxDQUFqQixNQUFvQkEsQ0FBL0IsQ0FBRixFQUFvQ0UsRUFBRTVsQixJQUFGLENBQU8sY0FBUCxFQUFzQnNxQixDQUF0QixDQUFwQyxFQUE2RDdFLEVBQUU3a0IsSUFBRixDQUFPLENBQUMsTUFBRCxFQUFRLE1BQVIsRUFBZSxJQUFmLEVBQW9CLFNBQXBCLEVBQThCLFNBQTlCLEVBQXdDLFNBQXhDLEVBQWtELEtBQWxELEVBQXdELFFBQXhELENBQVAsRUFBeUUsVUFBUzhrQixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDMkUsVUFBRTNlLFFBQUYsQ0FBVyxFQUFDN0ssTUFBSytCLEVBQUVtbkIsSUFBRixDQUFPQyxLQUFiLEVBQW1CN3FCLE1BQUt1bUIsQ0FBeEIsRUFBWCxHQUF1QzJFLEVBQUV2cUIsUUFBRixDQUFXbU0sRUFBWCxDQUFjeVosSUFBRSxvQkFBaEIsRUFBcUNGLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxZQUFFOWpCLFNBQUYsSUFBYThqQixFQUFFMEksYUFBRixLQUFrQixJQUEvQixLQUFzQyxLQUFLdkIsUUFBTCxDQUFjLENBQUNqSCxDQUFELENBQWQsR0FBbUIyRSxFQUFFM0UsQ0FBRixFQUFLcmhCLEtBQUwsQ0FBVyxJQUFYLEVBQWdCLEdBQUdyQyxLQUFILENBQVMrQyxJQUFULENBQWNYLFNBQWQsRUFBd0IsQ0FBeEIsQ0FBaEIsQ0FBbkIsRUFBK0QsS0FBS3dvQixPQUFMLENBQWEsQ0FBQ2xILENBQUQsQ0FBYixDQUFyRztBQUF3SCxTQUE1SSxFQUE2STJFLENBQTdJLENBQXJDLENBQXZDO0FBQTZOLE9BQXBULENBQWpFLEdBQXdYLFlBQVUsT0FBTzVFLENBQWpCLElBQW9CLFFBQU1BLEVBQUU2QixNQUFGLENBQVMsQ0FBVCxDQUExQixJQUF1QytDLEVBQUU1RSxDQUFGLEVBQUtwaEIsS0FBTCxDQUFXZ21CLENBQVgsRUFBYTNFLENBQWIsQ0FBL1o7QUFBK2EsS0FBM2UsQ0FBUDtBQUFvZixHQUFsK25CLEVBQW0rbkJGLEVBQUVuZ0IsRUFBRixDQUFLbXBCLFdBQUwsQ0FBaUJDLFdBQWpCLEdBQTZCN3JCLENBQWhnb0I7QUFBa2dvQixDQUFoNXBCLENBQWk1cEJ3QyxPQUFPc3BCLEtBQVAsSUFBY3RwQixPQUFPa0MsTUFBdDZwQixFQUE2NnBCbEMsTUFBNzZwQixFQUFvN3BCOUIsUUFBcDdwQixDQUFELEVBQSs3cEIsVUFBU2tpQixDQUFULEVBQVdDLENBQVgsRUFBYUMsQ0FBYixFQUFlQyxDQUFmLEVBQWlCO0FBQUMsTUFBSS9pQixJQUFFLFNBQUZBLENBQUUsQ0FBUzZpQixDQUFULEVBQVc7QUFBQyxTQUFLa0osS0FBTCxHQUFXbEosQ0FBWCxFQUFhLEtBQUttSixTQUFMLEdBQWUsSUFBNUIsRUFBaUMsS0FBS0MsUUFBTCxHQUFjLElBQS9DLEVBQW9ELEtBQUsvSSxTQUFMLEdBQWUsRUFBQyw0QkFBMkJOLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsSUFBYSxLQUFLaXRCLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0JrSixXQUFqQyxJQUE4QyxLQUFLQyxLQUFMLEVBQTlDO0FBQTJELE9BQS9FLEVBQWdGLElBQWhGLENBQTVCLEVBQW5FLEVBQXNMLEtBQUtKLEtBQUwsQ0FBVzljLE9BQVgsR0FBbUIyVCxFQUFFcmEsTUFBRixDQUFTLEVBQVQsRUFBWXZJLEVBQUVpakIsUUFBZCxFQUF1QixLQUFLOEksS0FBTCxDQUFXOWMsT0FBbEMsQ0FBek0sRUFBb1AsS0FBSzhjLEtBQUwsQ0FBVzd1QixRQUFYLENBQW9CbU0sRUFBcEIsQ0FBdUIsS0FBSzZaLFNBQTVCLENBQXBQO0FBQTJSLEdBQTdTLENBQThTbGpCLEVBQUVpakIsUUFBRixHQUFXLEVBQUNpSixhQUFZLENBQUMsQ0FBZCxFQUFnQkUscUJBQW9CLEdBQXBDLEVBQVgsRUFBb0Rwc0IsRUFBRWtDLFNBQUYsQ0FBWWlxQixLQUFaLEdBQWtCLFlBQVU7QUFBQyxTQUFLSCxTQUFMLEtBQWlCLEtBQUtDLFFBQUwsR0FBYyxLQUFLRixLQUFMLENBQVc3dUIsUUFBWCxDQUFvQjJMLEVBQXBCLENBQXVCLFVBQXZCLENBQWQsRUFBaUQsS0FBS21qQixTQUFMLEdBQWVuSixFQUFFd0osV0FBRixDQUFjekosRUFBRTRCLEtBQUYsQ0FBUSxLQUFLNkQsT0FBYixFQUFxQixJQUFyQixDQUFkLEVBQXlDLEtBQUswRCxLQUFMLENBQVcvSSxRQUFYLENBQW9Cb0osbUJBQTdELENBQWpGO0FBQW9LLEdBQXJQLEVBQXNQcHNCLEVBQUVrQyxTQUFGLENBQVltbUIsT0FBWixHQUFvQixZQUFVO0FBQUMsU0FBSzBELEtBQUwsQ0FBVzd1QixRQUFYLENBQW9CMkwsRUFBcEIsQ0FBdUIsVUFBdkIsTUFBcUMsS0FBS29qQixRQUExQyxLQUFxRCxLQUFLQSxRQUFMLEdBQWMsQ0FBQyxLQUFLQSxRQUFwQixFQUE2QixLQUFLRixLQUFMLENBQVc3dUIsUUFBWCxDQUFvQmtrQixXQUFwQixDQUFnQyxZQUFoQyxFQUE2QyxDQUFDLEtBQUs2SyxRQUFuRCxDQUE3QixFQUEwRixLQUFLQSxRQUFMLElBQWUsS0FBS0YsS0FBTCxDQUFXekQsVUFBWCxDQUFzQixPQUF0QixDQUFmLElBQStDLEtBQUt5RCxLQUFMLENBQVcxRCxPQUFYLEVBQTlMO0FBQW9OLEdBQXplLEVBQTBlcm9CLEVBQUVrQyxTQUFGLENBQVlrZSxPQUFaLEdBQW9CLFlBQVU7QUFBQyxRQUFJd0MsQ0FBSixFQUFNRSxDQUFOLENBQVFELEVBQUV5SixhQUFGLENBQWdCLEtBQUtOLFNBQXJCLEVBQWdDLEtBQUlwSixDQUFKLElBQVMsS0FBS00sU0FBZDtBQUF3QixXQUFLNkksS0FBTCxDQUFXN3VCLFFBQVgsQ0FBb0J3TSxHQUFwQixDQUF3QmtaLENBQXhCLEVBQTBCLEtBQUtNLFNBQUwsQ0FBZU4sQ0FBZixDQUExQjtBQUF4QixLQUFxRSxLQUFJRSxDQUFKLElBQVN0a0IsT0FBTyt0QixtQkFBUCxDQUEyQixJQUEzQixDQUFUO0FBQTBDLG9CQUFZLE9BQU8sS0FBS3pKLENBQUwsQ0FBbkIsS0FBNkIsS0FBS0EsQ0FBTCxJQUFRLElBQXJDO0FBQTFDO0FBQXFGLEdBQTNzQixFQUE0c0JGLEVBQUVuZ0IsRUFBRixDQUFLbXBCLFdBQUwsQ0FBaUJDLFdBQWpCLENBQTZCcEgsT0FBN0IsQ0FBcUMrSCxXQUFyQyxHQUFpRHhzQixDQUE3dkI7QUFBK3ZCLENBQS9qQyxDQUFna0N3QyxPQUFPc3BCLEtBQVAsSUFBY3RwQixPQUFPa0MsTUFBcmxDLEVBQTRsQ2xDLE1BQTVsQyxFQUFtbUM5QixRQUFubUMsQ0FBLzdwQixFQUE0aXNCLFVBQVNraUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZUMsQ0FBZixFQUFpQjtBQUFDLE1BQUkvaUIsSUFBRSxTQUFGQSxDQUFFLENBQVM2aUIsQ0FBVCxFQUFXO0FBQUMsU0FBS2tKLEtBQUwsR0FBV2xKLENBQVgsRUFBYSxLQUFLNEosT0FBTCxHQUFhLEVBQTFCLEVBQTZCLEtBQUt2SixTQUFMLEdBQWUsRUFBQyxxRUFBb0VOLEVBQUU0QixLQUFGLENBQVEsVUFBUzNCLENBQVQsRUFBVztBQUFDLFlBQUdBLEVBQUUvakIsU0FBRixJQUFhLEtBQUtpdEIsS0FBTCxDQUFXL0ksUUFBeEIsSUFBa0MsS0FBSytJLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0IwSixRQUF0RCxLQUFpRTdKLEVBQUU4RixRQUFGLElBQVksY0FBWTlGLEVBQUU4RixRQUFGLENBQVdwc0IsSUFBbkMsSUFBeUMsaUJBQWVzbUIsRUFBRTVrQixJQUEzSCxDQUFILEVBQW9JLEtBQUksSUFBSTZrQixJQUFFLEtBQUtpSixLQUFMLENBQVcvSSxRQUFqQixFQUEwQmhqQixJQUFFOGlCLEVBQUVpQyxNQUFGLElBQVVobUIsS0FBSzJvQixJQUFMLENBQVU1RSxFQUFFdFUsS0FBRixHQUFRLENBQWxCLENBQVYsSUFBZ0NzVSxFQUFFdFUsS0FBOUQsRUFBb0VpWixJQUFFM0UsRUFBRWlDLE1BQUYsSUFBVS9rQixJQUFFLENBQUMsQ0FBYixJQUFnQixDQUF0RixFQUF3RjJuQixJQUFFLENBQUM5RSxFQUFFOEYsUUFBRixJQUFZOUYsRUFBRThGLFFBQUYsQ0FBV2plLEtBQVgsS0FBbUJxWSxDQUEvQixHQUFpQ0YsRUFBRThGLFFBQUYsQ0FBV2plLEtBQTVDLEdBQWtELEtBQUtxaEIsS0FBTCxDQUFXNWhCLE9BQVgsRUFBbkQsSUFBeUVzZCxDQUFuSyxFQUFxS0csSUFBRSxLQUFLbUUsS0FBTCxDQUFXNUIsTUFBWCxHQUFvQnRyQixNQUEzTCxFQUFrTVUsSUFBRXFqQixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLGVBQUs4SixJQUFMLENBQVU5SixDQUFWO0FBQWEsU0FBbkMsRUFBb0MsSUFBcEMsQ0FBeE0sRUFBa1A0RSxNQUFJem5CLENBQXRQO0FBQXlQLGVBQUsyc0IsSUFBTCxDQUFVL0UsSUFBRSxDQUFGLEdBQUksS0FBS21FLEtBQUwsQ0FBV3pFLFFBQVgsQ0FBb0JLLENBQXBCLENBQWQsR0FBc0NDLEtBQUdoRixFQUFFN2tCLElBQUYsQ0FBTyxLQUFLZ3VCLEtBQUwsQ0FBVzVCLE1BQVgsQ0FBa0IsS0FBSzRCLEtBQUwsQ0FBV3pFLFFBQVgsQ0FBb0JLLENBQXBCLENBQWxCLENBQVAsRUFBaURwb0IsQ0FBakQsQ0FBekMsRUFBNkZvb0IsR0FBN0Y7QUFBelA7QUFBMFYsT0FBbGYsRUFBbWYsSUFBbmYsQ0FBckUsRUFBNUMsRUFBMm1CLEtBQUtvRSxLQUFMLENBQVc5YyxPQUFYLEdBQW1CMlQsRUFBRXJhLE1BQUYsQ0FBUyxFQUFULEVBQVl2SSxFQUFFaWpCLFFBQWQsRUFBdUIsS0FBSzhJLEtBQUwsQ0FBVzljLE9BQWxDLENBQTluQixFQUF5cUIsS0FBSzhjLEtBQUwsQ0FBVzd1QixRQUFYLENBQW9CbU0sRUFBcEIsQ0FBdUIsS0FBSzZaLFNBQTVCLENBQXpxQjtBQUFndEIsR0FBbHVCLENBQW11QmxqQixFQUFFaWpCLFFBQUYsR0FBVyxFQUFDeUosVUFBUyxDQUFDLENBQVgsRUFBWCxFQUF5QjFzQixFQUFFa0MsU0FBRixDQUFZeXFCLElBQVosR0FBaUIsVUFBUzdKLENBQVQsRUFBVztBQUFDLFFBQUlDLElBQUUsS0FBS2dKLEtBQUwsQ0FBV3hFLE1BQVgsQ0FBa0J6WSxRQUFsQixHQUE2QjNGLEVBQTdCLENBQWdDMlosQ0FBaEMsQ0FBTjtBQUFBLFFBQXlDOWlCLElBQUUraUIsS0FBR0EsRUFBRXRqQixJQUFGLENBQU8sV0FBUCxDQUE5QyxDQUFrRSxDQUFDTyxDQUFELElBQUk0aUIsRUFBRThJLE9BQUYsQ0FBVTNJLEVBQUUvWCxHQUFGLENBQU0sQ0FBTixDQUFWLEVBQW1CLEtBQUt5aEIsT0FBeEIsSUFBaUMsQ0FBQyxDQUF0QyxLQUEwQ3pzQixFQUFFakMsSUFBRixDQUFPNmtCLEVBQUU0QixLQUFGLENBQVEsVUFBUzFCLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsVUFBSS9pQixDQUFKO0FBQUEsVUFBTXluQixJQUFFN0UsRUFBRUcsQ0FBRixDQUFSO0FBQUEsVUFBYTRFLElBQUU5RSxFQUFFK0osZ0JBQUYsR0FBbUIsQ0FBbkIsSUFBc0JuRixFQUFFcHJCLElBQUYsQ0FBTyxpQkFBUCxDQUF0QixJQUFpRG9yQixFQUFFcHJCLElBQUYsQ0FBTyxVQUFQLENBQWhFLENBQW1GLEtBQUswdkIsS0FBTCxDQUFXM3VCLE9BQVgsQ0FBbUIsTUFBbkIsRUFBMEIsRUFBQzJILFNBQVEwaUIsQ0FBVCxFQUFXb0YsS0FBSWxGLENBQWYsRUFBMUIsRUFBNEMsTUFBNUMsR0FBb0RGLEVBQUU1ZSxFQUFGLENBQUssS0FBTCxJQUFZNGUsRUFBRXhaLEdBQUYsQ0FBTSxlQUFOLEVBQXNCMlUsRUFBRTRCLEtBQUYsQ0FBUSxZQUFVO0FBQUNpRCxVQUFFbmQsR0FBRixDQUFNLFNBQU4sRUFBZ0IsQ0FBaEIsR0FBbUIsS0FBS3loQixLQUFMLENBQVczdUIsT0FBWCxDQUFtQixRQUFuQixFQUE0QixFQUFDMkgsU0FBUTBpQixDQUFULEVBQVdvRixLQUFJbEYsQ0FBZixFQUE1QixFQUE4QyxNQUE5QyxDQUFuQjtBQUF5RSxPQUE1RixFQUE2RixJQUE3RixDQUF0QixFQUEwSHRyQixJQUExSCxDQUErSCxLQUEvSCxFQUFxSXNyQixDQUFySSxDQUFaLElBQXFKM25CLElBQUUsSUFBSThxQixLQUFKLEVBQUYsRUFBWTlxQixFQUFFOHNCLE1BQUYsR0FBU2xLLEVBQUU0QixLQUFGLENBQVEsWUFBVTtBQUFDaUQsVUFBRW5kLEdBQUYsQ0FBTSxFQUFDLG9CQUFtQixVQUFRcWQsQ0FBUixHQUFVLElBQTlCLEVBQW1Db0YsU0FBUSxHQUEzQyxFQUFOLEdBQXVELEtBQUtoQixLQUFMLENBQVczdUIsT0FBWCxDQUFtQixRQUFuQixFQUE0QixFQUFDMkgsU0FBUTBpQixDQUFULEVBQVdvRixLQUFJbEYsQ0FBZixFQUE1QixFQUE4QyxNQUE5QyxDQUF2RDtBQUE2RyxPQUFoSSxFQUFpSSxJQUFqSSxDQUFyQixFQUE0SjNuQixFQUFFOFAsR0FBRixHQUFNNlgsQ0FBdlQsQ0FBcEQ7QUFBOFcsS0FBdmQsRUFBd2QsSUFBeGQsQ0FBUCxHQUFzZSxLQUFLOEUsT0FBTCxDQUFhcHZCLElBQWIsQ0FBa0IwbEIsRUFBRS9YLEdBQUYsQ0FBTSxDQUFOLENBQWxCLENBQWhoQjtBQUE2aUIsR0FBcnFCLEVBQXNxQmhMLEVBQUVrQyxTQUFGLENBQVlrZSxPQUFaLEdBQW9CLFlBQVU7QUFBQyxRQUFJd0MsQ0FBSixFQUFNQyxDQUFOLENBQVEsS0FBSUQsQ0FBSixJQUFTLEtBQUtvSyxRQUFkO0FBQXVCLFdBQUtqQixLQUFMLENBQVc3dUIsUUFBWCxDQUFvQndNLEdBQXBCLENBQXdCa1osQ0FBeEIsRUFBMEIsS0FBS29LLFFBQUwsQ0FBY3BLLENBQWQsQ0FBMUI7QUFBdkIsS0FBbUUsS0FBSUMsQ0FBSixJQUFTcmtCLE9BQU8rdEIsbUJBQVAsQ0FBMkIsSUFBM0IsQ0FBVDtBQUEwQyxvQkFBWSxPQUFPLEtBQUsxSixDQUFMLENBQW5CLEtBQTZCLEtBQUtBLENBQUwsSUFBUSxJQUFyQztBQUExQztBQUFxRixHQUFyMkIsRUFBczJCRCxFQUFFbmdCLEVBQUYsQ0FBS21wQixXQUFMLENBQWlCQyxXQUFqQixDQUE2QnBILE9BQTdCLENBQXFDd0ksSUFBckMsR0FBMENqdEIsQ0FBaDVCO0FBQWs1QixDQUF2b0QsQ0FBd29Ed0MsT0FBT3NwQixLQUFQLElBQWN0cEIsT0FBT2tDLE1BQTdwRCxFQUFvcURsQyxNQUFwcUQsRUFBMnFEOUIsUUFBM3FELENBQTVpc0IsRUFBaXV2QixVQUFTa2lCLENBQVQsRUFBV0MsQ0FBWCxFQUFhQyxDQUFiLEVBQWVDLENBQWYsRUFBaUI7QUFBQyxNQUFJL2lCLElBQUUsU0FBRkEsQ0FBRSxDQUFTNmlCLENBQVQsRUFBVztBQUFDLFNBQUtrSixLQUFMLEdBQVdsSixDQUFYLEVBQWEsS0FBS0ssU0FBTCxHQUFlLEVBQUMsbURBQWtETixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0EsVUFBRTlqQixTQUFGLElBQWEsS0FBS2l0QixLQUFMLENBQVcvSSxRQUFYLENBQW9COUssVUFBakMsSUFBNkMsS0FBSzZRLE1BQUwsRUFBN0M7QUFBMkQsT0FBL0UsRUFBZ0YsSUFBaEYsQ0FBbkQsRUFBeUksd0JBQXVCbkcsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLEtBQUtpdEIsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQjlLLFVBQWpDLElBQTZDLGNBQVkwSyxFQUFFK0YsUUFBRixDQUFXcHNCLElBQXBFLElBQTBFLEtBQUt3c0IsTUFBTCxFQUExRTtBQUF3RixPQUE1RyxFQUE2RyxJQUE3RyxDQUFoSyxFQUFtUixtQkFBa0JuRyxFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0EsVUFBRTlqQixTQUFGLElBQWEsS0FBS2l0QixLQUFMLENBQVcvSSxRQUFYLENBQW9COUssVUFBakMsSUFBNkMwSyxFQUFFN2QsT0FBRixDQUFVd1AsT0FBVixDQUFrQixNQUFJLEtBQUt3WCxLQUFMLENBQVcvSSxRQUFYLENBQW9CMkQsU0FBMUMsRUFBcUR6SixLQUFyRCxPQUErRCxLQUFLNk8sS0FBTCxDQUFXNWhCLE9BQVgsRUFBNUcsSUFBa0ksS0FBSzRlLE1BQUwsRUFBbEk7QUFBZ0osT0FBcEssRUFBcUssSUFBckssQ0FBclMsRUFBNUIsRUFBNmUsS0FBS2dELEtBQUwsQ0FBVzljLE9BQVgsR0FBbUIyVCxFQUFFcmEsTUFBRixDQUFTLEVBQVQsRUFBWXZJLEVBQUVpakIsUUFBZCxFQUF1QixLQUFLOEksS0FBTCxDQUFXOWMsT0FBbEMsQ0FBaGdCLEVBQTJpQixLQUFLOGMsS0FBTCxDQUFXN3VCLFFBQVgsQ0FBb0JtTSxFQUFwQixDQUF1QixLQUFLNlosU0FBNUIsQ0FBM2lCO0FBQWtsQixHQUFwbUIsQ0FBcW1CbGpCLEVBQUVpakIsUUFBRixHQUFXLEVBQUMvSyxZQUFXLENBQUMsQ0FBYixFQUFlZ1YsaUJBQWdCLFlBQS9CLEVBQVgsRUFBd0RsdEIsRUFBRWtDLFNBQUYsQ0FBWTZtQixNQUFaLEdBQW1CLFlBQVU7QUFBQyxRQUFJbEcsSUFBRSxLQUFLa0osS0FBTCxDQUFXM0ksUUFBakI7QUFBQSxRQUEwQk4sSUFBRUQsSUFBRSxLQUFLa0osS0FBTCxDQUFXL0ksUUFBWCxDQUFvQnhVLEtBQWxEO0FBQUEsUUFBd0R1VSxJQUFFLEtBQUtnSixLQUFMLENBQVd4RSxNQUFYLENBQWtCelksUUFBbEIsR0FBNkJxZSxPQUE3QixHQUF1Qy90QixLQUF2QyxDQUE2Q3lqQixDQUE3QyxFQUErQ0MsQ0FBL0MsQ0FBMUQ7QUFBQSxRQUE0RzlpQixJQUFFLEVBQTlHO0FBQUEsUUFBaUh5bkIsSUFBRSxDQUFuSCxDQUFxSDdFLEVBQUU3a0IsSUFBRixDQUFPZ2xCLENBQVAsRUFBUyxVQUFTRixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDOWlCLFFBQUUzQyxJQUFGLENBQU91bEIsRUFBRUUsQ0FBRixFQUFLcGQsTUFBTCxFQUFQO0FBQXNCLEtBQTdDLEdBQStDK2hCLElBQUUxb0IsS0FBS3dFLEdBQUwsQ0FBUzlCLEtBQVQsQ0FBZSxJQUFmLEVBQW9CekIsQ0FBcEIsQ0FBakQsRUFBd0UsS0FBSytyQixLQUFMLENBQVd4RSxNQUFYLENBQWtCdmlCLE1BQWxCLEdBQTJCVSxNQUEzQixDQUFrQytoQixDQUFsQyxFQUFxQzNaLFFBQXJDLENBQThDLEtBQUtpZSxLQUFMLENBQVcvSSxRQUFYLENBQW9Ca0ssZUFBbEUsQ0FBeEU7QUFBMkosR0FBdFcsRUFBdVdsdEIsRUFBRWtDLFNBQUYsQ0FBWWtlLE9BQVosR0FBb0IsWUFBVTtBQUFDLFFBQUl3QyxDQUFKLEVBQU1DLENBQU4sQ0FBUSxLQUFJRCxDQUFKLElBQVMsS0FBS00sU0FBZDtBQUF3QixXQUFLNkksS0FBTCxDQUFXN3VCLFFBQVgsQ0FBb0J3TSxHQUFwQixDQUF3QmtaLENBQXhCLEVBQTBCLEtBQUtNLFNBQUwsQ0FBZU4sQ0FBZixDQUExQjtBQUF4QixLQUFxRSxLQUFJQyxDQUFKLElBQVNya0IsT0FBTyt0QixtQkFBUCxDQUEyQixJQUEzQixDQUFUO0FBQTBDLG9CQUFZLE9BQU8sS0FBSzFKLENBQUwsQ0FBbkIsS0FBNkIsS0FBS0EsQ0FBTCxJQUFRLElBQXJDO0FBQTFDO0FBQXFGLEdBQXhpQixFQUF5aUJELEVBQUVuZ0IsRUFBRixDQUFLbXBCLFdBQUwsQ0FBaUJDLFdBQWpCLENBQTZCcEgsT0FBN0IsQ0FBcUMySSxVQUFyQyxHQUFnRHB0QixDQUF6bEI7QUFBMmxCLENBQWx0QyxDQUFtdEN3QyxPQUFPc3BCLEtBQVAsSUFBY3RwQixPQUFPa0MsTUFBeHVDLEVBQSt1Q2xDLE1BQS91QyxFQUFzdkM5QixRQUF0dkMsQ0FBanV2QixFQUFpK3hCLFVBQVNraUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZUMsQ0FBZixFQUFpQjtBQUFDLE1BQUkvaUIsSUFBRSxTQUFGQSxDQUFFLENBQVM2aUIsQ0FBVCxFQUFXO0FBQUMsU0FBS2tKLEtBQUwsR0FBV2xKLENBQVgsRUFBYSxLQUFLd0ssT0FBTCxHQUFhLEVBQTFCLEVBQTZCLEtBQUtDLFFBQUwsR0FBYyxJQUEzQyxFQUFnRCxLQUFLcEssU0FBTCxHQUFlLEVBQUMsNEJBQTJCTixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0EsVUFBRTlqQixTQUFGLElBQWEsS0FBS2l0QixLQUFMLENBQVdqakIsUUFBWCxDQUFvQixFQUFDN0ssTUFBSyxPQUFOLEVBQWMxQixNQUFLLFNBQW5CLEVBQTZCNm5CLE1BQUssQ0FBQyxhQUFELENBQWxDLEVBQXBCLENBQWI7QUFBcUYsT0FBekcsRUFBMEcsSUFBMUcsQ0FBNUIsRUFBNEksdUJBQXNCeEIsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLEtBQUtpdEIsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQnVLLEtBQWpDLElBQXdDLEtBQUtDLGNBQUwsRUFBeEMsSUFBK0Q1SyxFQUFFclosY0FBRixFQUEvRDtBQUFrRixPQUF0RyxFQUF1RyxJQUF2RyxDQUFsSyxFQUErUSwwQkFBeUJxWixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0EsVUFBRTlqQixTQUFGLElBQWEsS0FBS2l0QixLQUFMLENBQVdsakIsRUFBWCxDQUFjLFVBQWQsQ0FBYixJQUF3QyxLQUFLa2pCLEtBQUwsQ0FBV3hFLE1BQVgsQ0FBa0I5bkIsSUFBbEIsQ0FBdUIsMEJBQXZCLEVBQW1EdWEsTUFBbkQsRUFBeEM7QUFBb0csT0FBeEgsRUFBeUgsSUFBekgsQ0FBeFMsRUFBdWEsd0JBQXVCNEksRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLGVBQWE4akIsRUFBRStGLFFBQUYsQ0FBV3BzQixJQUFyQyxJQUEyQyxLQUFLK3dCLFFBQWhELElBQTBELEtBQUtqVSxJQUFMLEVBQTFEO0FBQXNFLE9BQTFGLEVBQTJGLElBQTNGLENBQTliLEVBQStoQix5QkFBd0J1SixFQUFFNEIsS0FBRixDQUFRLFVBQVMzQixDQUFULEVBQVc7QUFBQyxZQUFHQSxFQUFFL2pCLFNBQUwsRUFBZTtBQUFDLGNBQUlna0IsSUFBRUYsRUFBRUMsRUFBRWlHLE9BQUosRUFBYXJwQixJQUFiLENBQWtCLFlBQWxCLENBQU4sQ0FBc0NxakIsRUFBRWprQixNQUFGLEtBQVdpa0IsRUFBRXhZLEdBQUYsQ0FBTSxTQUFOLEVBQWdCLE1BQWhCLEdBQXdCLEtBQUttakIsS0FBTCxDQUFXM0ssQ0FBWCxFQUFhRixFQUFFQyxFQUFFaUcsT0FBSixDQUFiLENBQW5DO0FBQStEO0FBQUMsT0FBMUksRUFBMkksSUFBM0ksQ0FBdmpCLEVBQS9ELEVBQXd3QixLQUFLaUQsS0FBTCxDQUFXOWMsT0FBWCxHQUFtQjJULEVBQUVyYSxNQUFGLENBQVMsRUFBVCxFQUFZdkksRUFBRWlqQixRQUFkLEVBQXVCLEtBQUs4SSxLQUFMLENBQVc5YyxPQUFsQyxDQUEzeEIsRUFBczBCLEtBQUs4YyxLQUFMLENBQVc3dUIsUUFBWCxDQUFvQm1NLEVBQXBCLENBQXVCLEtBQUs2WixTQUE1QixDQUF0MEIsRUFBNjJCLEtBQUs2SSxLQUFMLENBQVc3dUIsUUFBWCxDQUFvQm1NLEVBQXBCLENBQXVCLGlCQUF2QixFQUF5QyxzQkFBekMsRUFBZ0V1WixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQyxXQUFLOEssSUFBTCxDQUFVOUssQ0FBVjtBQUFhLEtBQWpDLEVBQWtDLElBQWxDLENBQWhFLENBQTcyQjtBQUFzOUIsR0FBeCtCLENBQXkrQjVpQixFQUFFaWpCLFFBQUYsR0FBVyxFQUFDc0ssT0FBTSxDQUFDLENBQVIsRUFBVUksYUFBWSxDQUFDLENBQXZCLEVBQXlCQyxZQUFXLENBQUMsQ0FBckMsRUFBWCxFQUFtRDV0QixFQUFFa0MsU0FBRixDQUFZdXJCLEtBQVosR0FBa0IsVUFBUzdLLENBQVQsRUFBV0MsQ0FBWCxFQUFhO0FBQUMsUUFBSUMsSUFBRSxZQUFVO0FBQUMsYUFBT0YsRUFBRXZtQixJQUFGLENBQU8sZUFBUCxJQUF3QixPQUF4QixHQUFnQ3VtQixFQUFFdm1CLElBQUYsQ0FBTyxlQUFQLElBQXdCLE9BQXhCLEdBQWdDLFNBQXZFO0FBQWlGLEtBQTVGLEVBQU47QUFBQSxRQUFxRzBtQixJQUFFSCxFQUFFdm1CLElBQUYsQ0FBTyxlQUFQLEtBQXlCdW1CLEVBQUV2bUIsSUFBRixDQUFPLGlCQUFQLENBQXpCLElBQW9EdW1CLEVBQUV2bUIsSUFBRixDQUFPLGVBQVAsQ0FBM0o7QUFBQSxRQUFtTDJELElBQUU0aUIsRUFBRXZtQixJQUFGLENBQU8sWUFBUCxLQUFzQixLQUFLMHZCLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0I0SyxVQUEvTjtBQUFBLFFBQTBPbkcsSUFBRTdFLEVBQUV2bUIsSUFBRixDQUFPLGFBQVAsS0FBdUIsS0FBSzB2QixLQUFMLENBQVcvSSxRQUFYLENBQW9CMkssV0FBdlI7QUFBQSxRQUFtU2hHLElBQUUvRSxFQUFFdm1CLElBQUYsQ0FBTyxNQUFQLENBQXJTLENBQW9ULElBQUcsQ0FBQ3NyQixDQUFKLEVBQU0sTUFBTSxJQUFJN2hCLEtBQUosQ0FBVSxvQkFBVixDQUFOLENBQXNDLElBQUdpZCxJQUFFNEUsRUFBRWhOLEtBQUYsQ0FBUSx5TUFBUixDQUFGLEVBQXFOb0ksRUFBRSxDQUFGLEVBQUt2bEIsT0FBTCxDQUFhLE9BQWIsSUFBc0IsQ0FBQyxDQUEvTyxFQUFpUHNsQixJQUFFLFNBQUYsQ0FBalAsS0FBa1EsSUFBR0MsRUFBRSxDQUFGLEVBQUt2bEIsT0FBTCxDQUFhLE9BQWIsSUFBc0IsQ0FBQyxDQUExQixFQUE0QnNsQixJQUFFLE9BQUYsQ0FBNUIsS0FBMEM7QUFBQyxVQUFHLEVBQUVDLEVBQUUsQ0FBRixFQUFLdmxCLE9BQUwsQ0FBYSxPQUFiLElBQXNCLENBQUMsQ0FBekIsQ0FBSCxFQUErQixNQUFNLElBQUlzSSxLQUFKLENBQVUsMEJBQVYsQ0FBTixDQUE0Q2dkLElBQUUsT0FBRjtBQUFVLFNBQUVDLEVBQUUsQ0FBRixDQUFGLEVBQU8sS0FBS3NLLE9BQUwsQ0FBYTFGLENBQWIsSUFBZ0IsRUFBQzFwQixNQUFLNmtCLENBQU4sRUFBUW5YLElBQUdvWCxDQUFYLEVBQWFwZCxPQUFNM0YsQ0FBbkIsRUFBcUIwRixRQUFPK2hCLENBQTVCLEVBQXZCLEVBQXNENUUsRUFBRXhtQixJQUFGLENBQU8sWUFBUCxFQUFvQnNyQixDQUFwQixDQUF0RCxFQUE2RSxLQUFLa0csU0FBTCxDQUFlakwsQ0FBZixFQUFpQixLQUFLeUssT0FBTCxDQUFhMUYsQ0FBYixDQUFqQixDQUE3RTtBQUErRyxHQUFwNkIsRUFBcTZCM25CLEVBQUVrQyxTQUFGLENBQVkyckIsU0FBWixHQUFzQixVQUFTaEwsQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxRQUFJQyxDQUFKO0FBQUEsUUFBTS9pQixDQUFOO0FBQUEsUUFBUXluQixDQUFSO0FBQUEsUUFBVUUsSUFBRTdFLEVBQUVuZCxLQUFGLElBQVNtZCxFQUFFcGQsTUFBWCxHQUFrQixrQkFBZ0JvZCxFQUFFbmQsS0FBbEIsR0FBd0IsWUFBeEIsR0FBcUNtZCxFQUFFcGQsTUFBdkMsR0FBOEMsTUFBaEUsR0FBdUUsRUFBbkY7QUFBQSxRQUFzRmtpQixJQUFFL0UsRUFBRXBqQixJQUFGLENBQU8sS0FBUCxDQUF4RjtBQUFBLFFBQXNHRixJQUFFLEtBQXhHO0FBQUEsUUFBOEc4ckIsSUFBRSxFQUFoSDtBQUFBLFFBQW1IemhCLElBQUUsS0FBS21pQixLQUFMLENBQVcvSSxRQUFoSTtBQUFBLFFBQXlJOEssSUFBRSxTQUFGQSxDQUFFLENBQVNsTCxDQUFULEVBQVc7QUFBQzVpQixVQUFFLHlDQUFGLEVBQTRDK2lCLElBQUVuWixFQUFFOGlCLFFBQUYsR0FBVyw4QkFBNEJyQixDQUE1QixHQUE4QixJQUE5QixHQUFtQzlyQixDQUFuQyxHQUFxQyxJQUFyQyxHQUEwQ3FqQixDQUExQyxHQUE0QyxVQUF2RCxHQUFrRSxxRUFBbUVBLENBQW5FLEdBQXFFLFdBQXJMLEVBQWlNQyxFQUFFK0gsS0FBRixDQUFRN0gsQ0FBUixDQUFqTSxFQUE0TUYsRUFBRStILEtBQUYsQ0FBUTVxQixDQUFSLENBQTVNO0FBQXVOLEtBQTlXLENBQStXLElBQUc2aUIsRUFBRW5MLElBQUYsQ0FBTyxtQ0FBaUNpUSxDQUFqQyxHQUFtQyxTQUExQyxHQUFxRCxLQUFLb0UsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQjBKLFFBQXBCLEtBQStCbnRCLElBQUUsVUFBRixFQUFhOHJCLElBQUUsVUFBOUMsQ0FBckQsRUFBK0d6RCxFQUFFL29CLE1BQXBILEVBQTJILE9BQU9pdkIsRUFBRWxHLEVBQUV2ckIsSUFBRixDQUFPa0QsQ0FBUCxDQUFGLEdBQWFxb0IsRUFBRTVOLE1BQUYsRUFBYixFQUF3QixDQUFDLENBQWhDLENBQWtDLGNBQVk4SSxFQUFFN2tCLElBQWQsSUFBb0J3cEIsSUFBRSwwQkFBd0IzRSxFQUFFblgsRUFBMUIsR0FBNkIsZ0JBQS9CLEVBQWdEbWlCLEVBQUVyRyxDQUFGLENBQXBFLElBQTBFLFlBQVUzRSxFQUFFN2tCLElBQVosR0FBaUIya0IsRUFBRW1MLElBQUYsQ0FBTyxFQUFDOXZCLE1BQUssS0FBTixFQUFZNHVCLEtBQUksOEJBQTRCL0osRUFBRW5YLEVBQTlCLEdBQWlDLE9BQWpELEVBQXlEcWlCLE9BQU0sVUFBL0QsRUFBMEVDLFVBQVMsT0FBbkYsRUFBMkZDLFNBQVEsaUJBQVN0TCxDQUFULEVBQVc7QUFBQzZFLFlBQUU3RSxFQUFFLENBQUYsRUFBS3VMLGVBQVAsRUFBdUJMLEVBQUVyRyxDQUFGLENBQXZCO0FBQTRCLE9BQTNJLEVBQVAsQ0FBakIsR0FBc0ssWUFBVTNFLEVBQUU3a0IsSUFBWixJQUFrQjJrQixFQUFFbUwsSUFBRixDQUFPLEVBQUM5dkIsTUFBSyxLQUFOLEVBQVk0dUIsS0FBSSw0QkFBMEIvSixFQUFFblgsRUFBNUIsR0FBK0IsT0FBL0MsRUFBdURxaUIsT0FBTSxVQUE3RCxFQUF3RUMsVUFBUyxPQUFqRixFQUF5RkMsU0FBUSxpQkFBU3RMLENBQVQsRUFBVztBQUFDNkUsWUFBRTdFLEVBQUV3TCxhQUFKLEVBQWtCTixFQUFFckcsQ0FBRixDQUFsQjtBQUF1QixPQUFwSSxFQUFQLENBQWxRO0FBQWdaLEdBQXIyRCxFQUFzMkR6bkIsRUFBRWtDLFNBQUYsQ0FBWW1YLElBQVosR0FBaUIsWUFBVTtBQUFDLFNBQUswUyxLQUFMLENBQVczdUIsT0FBWCxDQUFtQixNQUFuQixFQUEwQixJQUExQixFQUErQixPQUEvQixHQUF3QyxLQUFLa3dCLFFBQUwsQ0FBYzd0QixJQUFkLENBQW1CLGtCQUFuQixFQUF1Q3VhLE1BQXZDLEVBQXhDLEVBQXdGLEtBQUtzVCxRQUFMLENBQWN2ckIsV0FBZCxDQUEwQixtQkFBMUIsQ0FBeEYsRUFBdUksS0FBS3VyQixRQUFMLEdBQWMsSUFBckosRUFBMEosS0FBS3ZCLEtBQUwsQ0FBV3ZELEtBQVgsQ0FBaUIsU0FBakIsQ0FBMUosRUFBc0wsS0FBS3VELEtBQUwsQ0FBVzN1QixPQUFYLENBQW1CLFNBQW5CLEVBQTZCLElBQTdCLEVBQWtDLE9BQWxDLENBQXRMO0FBQWlPLEdBQW5tRSxFQUFvbUU0QyxFQUFFa0MsU0FBRixDQUFZd3JCLElBQVosR0FBaUIsVUFBUzdLLENBQVQsRUFBVztBQUFDLFFBQUlDLENBQUo7QUFBQSxRQUFNQyxJQUFFSCxFQUFFQyxFQUFFdlosTUFBSixDQUFSO0FBQUEsUUFBb0J0SixJQUFFK2lCLEVBQUV4TyxPQUFGLENBQVUsTUFBSSxLQUFLd1gsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQjJELFNBQWxDLENBQXRCO0FBQUEsUUFBbUVjLElBQUUsS0FBSzRGLE9BQUwsQ0FBYXJ0QixFQUFFM0QsSUFBRixDQUFPLFlBQVAsQ0FBYixDQUFyRTtBQUFBLFFBQXdHc3JCLElBQUVGLEVBQUU5aEIsS0FBRixJQUFTLE1BQW5IO0FBQUEsUUFBMEhpaUIsSUFBRUgsRUFBRS9oQixNQUFGLElBQVUsS0FBS3FtQixLQUFMLENBQVd4RSxNQUFYLENBQWtCN2hCLE1BQWxCLEVBQXRJLENBQWlLLEtBQUs0bkIsUUFBTCxLQUFnQixLQUFLdkIsS0FBTCxDQUFXNUQsS0FBWCxDQUFpQixTQUFqQixHQUE0QixLQUFLNEQsS0FBTCxDQUFXM3VCLE9BQVgsQ0FBbUIsTUFBbkIsRUFBMEIsSUFBMUIsRUFBK0IsT0FBL0IsQ0FBNUIsRUFBb0U0QyxJQUFFLEtBQUsrckIsS0FBTCxDQUFXdmQsS0FBWCxDQUFpQixLQUFLdWQsS0FBTCxDQUFXekUsUUFBWCxDQUFvQnRuQixFQUFFa2QsS0FBRixFQUFwQixDQUFqQixDQUF0RSxFQUF1SCxLQUFLNk8sS0FBTCxDQUFXbGUsS0FBWCxDQUFpQjdOLEVBQUVrZCxLQUFGLEVBQWpCLENBQXZILEVBQW1KLGNBQVl1SyxFQUFFeHBCLElBQWQsR0FBbUI2a0IsSUFBRSxvQkFBa0I2RSxDQUFsQixHQUFvQixZQUFwQixHQUFpQ0MsQ0FBakMsR0FBbUMsaUNBQW5DLEdBQXFFSCxFQUFFOWIsRUFBdkUsR0FBMEUsc0JBQTFFLEdBQWlHOGIsRUFBRTliLEVBQW5HLEdBQXNHLDZDQUEzSCxHQUF5SyxZQUFVOGIsRUFBRXhwQixJQUFaLEdBQWlCNmtCLElBQUUsMkNBQXlDMkUsRUFBRTliLEVBQTNDLEdBQThDLHNCQUE5QyxHQUFxRWdjLENBQXJFLEdBQXVFLFlBQXZFLEdBQW9GQyxDQUFwRixHQUFzRixzRkFBekcsR0FBZ00sWUFBVUgsRUFBRXhwQixJQUFaLEtBQW1CNmtCLElBQUUsb0NBQWtDOEUsQ0FBbEMsR0FBb0MsVUFBcEMsR0FBK0NELENBQS9DLEdBQWlELG1GQUFqRCxHQUFxSUYsRUFBRTliLEVBQXZJLEdBQTBJLGtDQUEvSixDQUE1ZixFQUErckJpWCxFQUFFLGtDQUFnQ0UsQ0FBaEMsR0FBa0MsUUFBcEMsRUFBOEN1TCxXQUE5QyxDQUEwRHJ1QixFQUFFUCxJQUFGLENBQU8sWUFBUCxDQUExRCxDQUEvckIsRUFBK3dCLEtBQUs2dEIsUUFBTCxHQUFjdHRCLEVBQUU4TixRQUFGLENBQVcsbUJBQVgsQ0FBN3lCO0FBQTgwQixHQUFobkcsRUFBaW5HOU4sRUFBRWtDLFNBQUYsQ0FBWXNyQixjQUFaLEdBQTJCLFlBQVU7QUFBQyxRQUFJM0ssSUFBRUMsRUFBRXdMLGlCQUFGLElBQXFCeEwsRUFBRXlMLG9CQUF2QixJQUE2Q3pMLEVBQUUwTCx1QkFBckQsQ0FBNkUsT0FBTzNMLEtBQUdELEVBQUVDLENBQUYsRUFBSzdkLE1BQUwsR0FBY3dRLFFBQWQsQ0FBdUIsaUJBQXZCLENBQVY7QUFBb0QsR0FBeHhHLEVBQXl4R3hWLEVBQUVrQyxTQUFGLENBQVlrZSxPQUFaLEdBQW9CLFlBQVU7QUFBQyxRQUFJd0MsQ0FBSixFQUFNQyxDQUFOLENBQVEsS0FBS2tKLEtBQUwsQ0FBVzd1QixRQUFYLENBQW9Cd00sR0FBcEIsQ0FBd0IsaUJBQXhCLEVBQTJDLEtBQUlrWixDQUFKLElBQVMsS0FBS00sU0FBZDtBQUF3QixXQUFLNkksS0FBTCxDQUFXN3VCLFFBQVgsQ0FBb0J3TSxHQUFwQixDQUF3QmtaLENBQXhCLEVBQTBCLEtBQUtNLFNBQUwsQ0FBZU4sQ0FBZixDQUExQjtBQUF4QixLQUFxRSxLQUFJQyxDQUFKLElBQVNya0IsT0FBTyt0QixtQkFBUCxDQUEyQixJQUEzQixDQUFUO0FBQTBDLG9CQUFZLE9BQU8sS0FBSzFKLENBQUwsQ0FBbkIsS0FBNkIsS0FBS0EsQ0FBTCxJQUFRLElBQXJDO0FBQTFDO0FBQXFGLEdBQXJnSCxFQUFzZ0hELEVBQUVuZ0IsRUFBRixDQUFLbXBCLFdBQUwsQ0FBaUJDLFdBQWpCLENBQTZCcEgsT0FBN0IsQ0FBcUNnSyxLQUFyQyxHQUEyQ3p1QixDQUFqakg7QUFBbWpILENBQTlpSixDQUEraUp3QyxPQUFPc3BCLEtBQVAsSUFBY3RwQixPQUFPa0MsTUFBcGtKLEVBQTJrSmxDLE1BQTNrSixFQUFrbEo5QixRQUFsbEosQ0FBait4QixFQUE2ajdCLFVBQVNraUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZUMsQ0FBZixFQUFpQjtBQUFDLE1BQUkvaUIsSUFBRSxTQUFGQSxDQUFFLENBQVM2aUIsQ0FBVCxFQUFXO0FBQUMsU0FBSzZMLElBQUwsR0FBVTdMLENBQVYsRUFBWSxLQUFLNkwsSUFBTCxDQUFVemYsT0FBVixHQUFrQjJULEVBQUVyYSxNQUFGLENBQVMsRUFBVCxFQUFZdkksRUFBRWlqQixRQUFkLEVBQXVCLEtBQUt5TCxJQUFMLENBQVV6ZixPQUFqQyxDQUE5QixFQUF3RSxLQUFLMGYsUUFBTCxHQUFjLENBQUMsQ0FBdkYsRUFBeUYsS0FBS25WLFFBQUwsR0FBY3VKLENBQXZHLEVBQXlHLEtBQUs1TSxJQUFMLEdBQVU0TSxDQUFuSCxFQUFxSCxLQUFLaUssUUFBTCxHQUFjLEVBQUMsdUJBQXNCcEssRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLGNBQVk4akIsRUFBRStGLFFBQUYsQ0FBV3BzQixJQUFwQyxLQUEyQyxLQUFLaWQsUUFBTCxHQUFjLEtBQUtrVixJQUFMLENBQVV2a0IsT0FBVixFQUFkLEVBQWtDLEtBQUtnTSxJQUFMLEdBQVV5TSxFQUFFK0YsUUFBRixDQUFXamUsS0FBbEc7QUFBeUcsT0FBN0gsRUFBOEgsSUFBOUgsQ0FBdkIsRUFBMkosa0VBQWlFa1ksRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixLQUFjLEtBQUs2dkIsUUFBTCxHQUFjLGdCQUFjL0wsRUFBRTNrQixJQUE1QztBQUFrRCxPQUF0RSxFQUF1RSxJQUF2RSxDQUE1TixFQUF5UywwQkFBeUIya0IsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLEtBQUs2dkIsUUFBbEIsS0FBNkIsS0FBS0QsSUFBTCxDQUFVemYsT0FBVixDQUFrQjlCLFVBQWxCLElBQThCLEtBQUt1aEIsSUFBTCxDQUFVemYsT0FBVixDQUFrQmxDLFNBQTdFLEtBQXlGLEtBQUs2aEIsSUFBTCxFQUF6RjtBQUFxRyxPQUF6SCxFQUEwSCxJQUExSCxDQUFsVSxFQUFuSSxFQUFza0IsS0FBS0YsSUFBTCxDQUFVeHhCLFFBQVYsQ0FBbUJtTSxFQUFuQixDQUFzQixLQUFLMmpCLFFBQTNCLENBQXRrQjtBQUEybUIsR0FBN25CLENBQThuQmh0QixFQUFFaWpCLFFBQUYsR0FBVyxFQUFDOVYsWUFBVyxDQUFDLENBQWIsRUFBZUosV0FBVSxDQUFDLENBQTFCLEVBQVgsRUFBd0MvTSxFQUFFa0MsU0FBRixDQUFZMHNCLElBQVosR0FBaUIsWUFBVTtBQUFDLFFBQUcsTUFBSSxLQUFLRixJQUFMLENBQVUxTCxRQUFWLENBQW1CeFUsS0FBdkIsSUFBOEJvVSxFQUFFMEcsT0FBRixDQUFVdGMsU0FBeEMsSUFBbUQ0VixFQUFFMEcsT0FBRixDQUFVbkwsVUFBaEUsRUFBMkU7QUFBQyxXQUFLdVEsSUFBTCxDQUFVL0UsS0FBVixDQUFnQixDQUFoQixFQUFtQixJQUFJOUcsQ0FBSjtBQUFBLFVBQU1DLElBQUVGLEVBQUU0QixLQUFGLENBQVEsS0FBSzdHLEtBQWIsRUFBbUIsSUFBbkIsQ0FBUjtBQUFBLFVBQWlDb0YsSUFBRSxLQUFLMkwsSUFBTCxDQUFVbkgsTUFBVixDQUFpQnpZLFFBQWpCLEdBQTRCM0YsRUFBNUIsQ0FBK0IsS0FBS3FRLFFBQXBDLENBQW5DO0FBQUEsVUFBaUZ4WixJQUFFLEtBQUswdUIsSUFBTCxDQUFVbkgsTUFBVixDQUFpQnpZLFFBQWpCLEdBQTRCM0YsRUFBNUIsQ0FBK0IsS0FBS2dOLElBQXBDLENBQW5GO0FBQUEsVUFBNkhzUixJQUFFLEtBQUtpSCxJQUFMLENBQVUxTCxRQUFWLENBQW1CalcsU0FBbEo7QUFBQSxVQUE0SjRhLElBQUUsS0FBSytHLElBQUwsQ0FBVTFMLFFBQVYsQ0FBbUI3VixVQUFqTCxDQUE0TCxLQUFLdWhCLElBQUwsQ0FBVXZrQixPQUFWLE9BQXNCLEtBQUtxUCxRQUEzQixLQUFzQ21PLE1BQUk5RSxJQUFFLEtBQUs2TCxJQUFMLENBQVV6RyxXQUFWLENBQXNCLEtBQUt6TyxRQUEzQixJQUFxQyxLQUFLa1YsSUFBTCxDQUFVekcsV0FBVixDQUFzQixLQUFLOVIsSUFBM0IsQ0FBdkMsRUFBd0U0TSxFQUFFOVUsR0FBRixDQUFNMlUsRUFBRTBHLE9BQUYsQ0FBVXRjLFNBQVYsQ0FBb0JwTSxHQUExQixFQUE4QmtpQixDQUE5QixFQUFpQ3hZLEdBQWpDLENBQXFDLEVBQUNoRixNQUFLdWQsSUFBRSxJQUFSLEVBQXJDLEVBQW9EL1UsUUFBcEQsQ0FBNkQsMkJBQTdELEVBQTBGQSxRQUExRixDQUFtRzZaLENBQW5HLENBQTVFLEdBQW1MRixLQUFHem5CLEVBQUVpTyxHQUFGLENBQU0yVSxFQUFFMEcsT0FBRixDQUFVdGMsU0FBVixDQUFvQnBNLEdBQTFCLEVBQThCa2lCLENBQTlCLEVBQWlDaFYsUUFBakMsQ0FBMEMsMEJBQTFDLEVBQXNFQSxRQUF0RSxDQUErRTJaLENBQS9FLENBQTVOO0FBQStTO0FBQUMsR0FBL29CLEVBQWdwQnpuQixFQUFFa0MsU0FBRixDQUFZeWIsS0FBWixHQUFrQixVQUFTa0YsQ0FBVCxFQUFXO0FBQUNELE1BQUVDLEVBQUV2WixNQUFKLEVBQVlnQixHQUFaLENBQWdCLEVBQUNoRixNQUFLLEVBQU4sRUFBaEIsRUFBMkJ2RCxXQUEzQixDQUF1QywyQ0FBdkMsRUFBb0ZBLFdBQXBGLENBQWdHLEtBQUsyc0IsSUFBTCxDQUFVMUwsUUFBVixDQUFtQmpXLFNBQW5ILEVBQThIaEwsV0FBOUgsQ0FBMEksS0FBSzJzQixJQUFMLENBQVUxTCxRQUFWLENBQW1CN1YsVUFBN0osR0FBeUssS0FBS3VoQixJQUFMLENBQVVuRixlQUFWLEVBQXpLO0FBQXFNLEdBQW4zQixFQUFvM0J2cEIsRUFBRWtDLFNBQUYsQ0FBWWtlLE9BQVosR0FBb0IsWUFBVTtBQUFDLFFBQUl3QyxDQUFKLEVBQU1DLENBQU4sQ0FBUSxLQUFJRCxDQUFKLElBQVMsS0FBS29LLFFBQWQ7QUFBdUIsV0FBSzBCLElBQUwsQ0FBVXh4QixRQUFWLENBQW1Cd00sR0FBbkIsQ0FBdUJrWixDQUF2QixFQUF5QixLQUFLb0ssUUFBTCxDQUFjcEssQ0FBZCxDQUF6QjtBQUF2QixLQUFrRSxLQUFJQyxDQUFKLElBQVNya0IsT0FBTyt0QixtQkFBUCxDQUEyQixJQUEzQixDQUFUO0FBQTBDLG9CQUFZLE9BQU8sS0FBSzFKLENBQUwsQ0FBbkIsS0FBNkIsS0FBS0EsQ0FBTCxJQUFRLElBQXJDO0FBQTFDO0FBQXFGLEdBQWxqQyxFQUM3czhCRCxFQUFFbmdCLEVBQUYsQ0FBS21wQixXQUFMLENBQWlCQyxXQUFqQixDQUE2QnBILE9BQTdCLENBQXFDb0ssT0FBckMsR0FBNkM3dUIsQ0FEZ3E4QjtBQUM5cDhCLENBRDhnN0IsQ0FDN2c3QndDLE9BQU9zcEIsS0FBUCxJQUFjdHBCLE9BQU9rQyxNQUR3LzZCLEVBQ2ovNkJsQyxNQURpLzZCLEVBQzErNkI5QixRQUQwKzZCLENBQTdqN0IsRUFDNkYsVUFBU2tpQixDQUFULEVBQVdDLENBQVgsRUFBYUMsQ0FBYixFQUFlQyxDQUFmLEVBQWlCO0FBQUMsTUFBSS9pQixJQUFFLFNBQUZBLENBQUUsQ0FBUzZpQixDQUFULEVBQVc7QUFBQyxTQUFLa0osS0FBTCxHQUFXbEosQ0FBWCxFQUFhLEtBQUtpTSxRQUFMLEdBQWMsSUFBM0IsRUFBZ0MsS0FBS0MsT0FBTCxHQUFhLENBQUMsQ0FBOUMsRUFBZ0QsS0FBSzdMLFNBQUwsR0FBZSxFQUFDLHdCQUF1Qk4sRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLGVBQWE4akIsRUFBRStGLFFBQUYsQ0FBV3BzQixJQUFyQyxHQUEwQyxLQUFLd3ZCLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0JnTSxRQUFwQixHQUE2QixLQUFLdEIsSUFBTCxFQUE3QixHQUF5QyxLQUFLclUsSUFBTCxFQUFuRixHQUErRnVKLEVBQUU5akIsU0FBRixJQUFhLGVBQWE4akIsRUFBRStGLFFBQUYsQ0FBV3BzQixJQUFyQyxJQUEyQyxLQUFLd3ZCLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0JnTSxRQUEvRCxJQUF5RSxLQUFLQyxvQkFBTCxFQUF4SztBQUFvTSxPQUF4TixFQUF5TixJQUF6TixDQUF4QixFQUF1UCw0QkFBMkJyTSxFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0EsVUFBRTlqQixTQUFGLElBQWEsS0FBS2l0QixLQUFMLENBQVcvSSxRQUFYLENBQW9CZ00sUUFBakMsSUFBMkMsS0FBS3RCLElBQUwsRUFBM0M7QUFBdUQsT0FBM0UsRUFBNEUsSUFBNUUsQ0FBbFIsRUFBb1cscUJBQW9COUssRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZTtBQUFDRixVQUFFOWpCLFNBQUYsSUFBYSxLQUFLNHVCLElBQUwsQ0FBVTdLLENBQVYsRUFBWUMsQ0FBWixDQUFiO0FBQTRCLE9BQXBELEVBQXFELElBQXJELENBQXhYLEVBQW1iLHFCQUFvQkYsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLEtBQUt1YSxJQUFMLEVBQWI7QUFBeUIsT0FBN0MsRUFBOEMsSUFBOUMsQ0FBdmMsRUFBMmYsMEJBQXlCdUosRUFBRTRCLEtBQUYsQ0FBUSxZQUFVO0FBQUMsYUFBS3VILEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0JrTSxrQkFBcEIsSUFBd0MsS0FBS25ELEtBQUwsQ0FBV2xqQixFQUFYLENBQWMsVUFBZCxDQUF4QyxJQUFtRSxLQUFLMEcsS0FBTCxFQUFuRTtBQUFnRixPQUFuRyxFQUFvRyxJQUFwRyxDQUFwaEIsRUFBOG5CLDJCQUEwQnFULEVBQUU0QixLQUFGLENBQVEsWUFBVTtBQUFDLGFBQUt1SCxLQUFMLENBQVcvSSxRQUFYLENBQW9Ca00sa0JBQXBCLElBQXdDLEtBQUtuRCxLQUFMLENBQVdsakIsRUFBWCxDQUFjLFVBQWQsQ0FBeEMsSUFBbUUsS0FBSzZrQixJQUFMLEVBQW5FO0FBQStFLE9BQWxHLEVBQW1HLElBQW5HLENBQXhwQixFQUFpd0IsdUJBQXNCOUssRUFBRTRCLEtBQUYsQ0FBUSxZQUFVO0FBQUMsYUFBS3VILEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0JrTSxrQkFBcEIsSUFBd0MsS0FBS25ELEtBQUwsQ0FBV2xqQixFQUFYLENBQWMsVUFBZCxDQUF4QyxJQUFtRSxLQUFLMEcsS0FBTCxFQUFuRTtBQUFnRixPQUFuRyxFQUFvRyxJQUFwRyxDQUF2eEIsRUFBaTRCLHFCQUFvQnFULEVBQUU0QixLQUFGLENBQVEsWUFBVTtBQUFDLGFBQUt1SCxLQUFMLENBQVcvSSxRQUFYLENBQW9Ca00sa0JBQXBCLElBQXdDLEtBQUt4QixJQUFMLEVBQXhDO0FBQW9ELE9BQXZFLEVBQXdFLElBQXhFLENBQXI1QixFQUEvRCxFQUFtaUMsS0FBSzNCLEtBQUwsQ0FBVzd1QixRQUFYLENBQW9CbU0sRUFBcEIsQ0FBdUIsS0FBSzZaLFNBQTVCLENBQW5pQyxFQUEwa0MsS0FBSzZJLEtBQUwsQ0FBVzljLE9BQVgsR0FBbUIyVCxFQUFFcmEsTUFBRixDQUFTLEVBQVQsRUFBWXZJLEVBQUVpakIsUUFBZCxFQUF1QixLQUFLOEksS0FBTCxDQUFXOWMsT0FBbEMsQ0FBN2xDO0FBQXdvQyxHQUExcEMsQ0FBMnBDalAsRUFBRWlqQixRQUFGLEdBQVcsRUFBQytMLFVBQVMsQ0FBQyxDQUFYLEVBQWFHLGlCQUFnQixHQUE3QixFQUFpQ0Qsb0JBQW1CLENBQUMsQ0FBckQsRUFBdURFLGVBQWMsQ0FBQyxDQUF0RSxFQUFYLEVBQW9GcHZCLEVBQUVrQyxTQUFGLENBQVl3ckIsSUFBWixHQUFpQixVQUFTOUssQ0FBVCxFQUFXQyxDQUFYLEVBQWE7QUFBQyxTQUFLa00sT0FBTCxHQUFhLENBQUMsQ0FBZCxFQUFnQixLQUFLaEQsS0FBTCxDQUFXbGpCLEVBQVgsQ0FBYyxVQUFkLE1BQTRCLEtBQUtrakIsS0FBTCxDQUFXNUQsS0FBWCxDQUFpQixVQUFqQixHQUE2QixLQUFLOEcsb0JBQUwsRUFBekQsQ0FBaEI7QUFBc0csR0FBek4sRUFBME5qdkIsRUFBRWtDLFNBQUYsQ0FBWW10QixlQUFaLEdBQTRCLFVBQVN0TSxDQUFULEVBQVcvaUIsQ0FBWCxFQUFhO0FBQUMsV0FBTyxLQUFLOHVCLFFBQUwsSUFBZWpNLEVBQUVyZixZQUFGLENBQWUsS0FBS3NyQixRQUFwQixDQUFmLEVBQTZDak0sRUFBRTloQixVQUFGLENBQWE2aEIsRUFBRTRCLEtBQUYsQ0FBUSxZQUFVO0FBQUMsV0FBS3VLLE9BQUwsSUFBYyxLQUFLaEQsS0FBTCxDQUFXbGpCLEVBQVgsQ0FBYyxNQUFkLENBQWQsSUFBcUMsS0FBS2tqQixLQUFMLENBQVdsakIsRUFBWCxDQUFjLGFBQWQsQ0FBckMsSUFBbUVpYSxFQUFFd00sTUFBckUsSUFBNkUsS0FBS3ZELEtBQUwsQ0FBVzVWLElBQVgsQ0FBZ0JuVyxLQUFHLEtBQUsrckIsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQm9NLGFBQXZDLENBQTdFO0FBQW1JLEtBQXRKLEVBQXVKLElBQXZKLENBQWIsRUFBMEtyTSxLQUFHLEtBQUtnSixLQUFMLENBQVcvSSxRQUFYLENBQW9CbU0sZUFBak0sQ0FBcEQ7QUFBc1EsR0FBMWdCLEVBQTJnQm52QixFQUFFa0MsU0FBRixDQUFZK3NCLG9CQUFaLEdBQWlDLFlBQVU7QUFBQyxTQUFLSCxRQUFMLEdBQWMsS0FBS08sZUFBTCxFQUFkO0FBQXFDLEdBQTVsQixFQUE2bEJydkIsRUFBRWtDLFNBQUYsQ0FBWW1YLElBQVosR0FBaUIsWUFBVTtBQUFDLFNBQUswUyxLQUFMLENBQVdsakIsRUFBWCxDQUFjLFVBQWQsTUFBNEJnYSxFQUFFcmYsWUFBRixDQUFlLEtBQUtzckIsUUFBcEIsR0FBOEIsS0FBSy9DLEtBQUwsQ0FBV3ZELEtBQVgsQ0FBaUIsVUFBakIsQ0FBMUQ7QUFBd0YsR0FBanRCLEVBQWt0QnhvQixFQUFFa0MsU0FBRixDQUFZcU4sS0FBWixHQUFrQixZQUFVO0FBQUMsU0FBS3djLEtBQUwsQ0FBV2xqQixFQUFYLENBQWMsVUFBZCxNQUE0QixLQUFLa21CLE9BQUwsR0FBYSxDQUFDLENBQTFDO0FBQTZDLEdBQTV4QixFQUE2eEIvdUIsRUFBRWtDLFNBQUYsQ0FBWWtlLE9BQVosR0FBb0IsWUFBVTtBQUFDLFFBQUl3QyxDQUFKLEVBQU1DLENBQU4sQ0FBUSxLQUFLeEosSUFBTCxHQUFZLEtBQUl1SixDQUFKLElBQVMsS0FBS00sU0FBZDtBQUF3QixXQUFLNkksS0FBTCxDQUFXN3VCLFFBQVgsQ0FBb0J3TSxHQUFwQixDQUF3QmtaLENBQXhCLEVBQTBCLEtBQUtNLFNBQUwsQ0FBZU4sQ0FBZixDQUExQjtBQUF4QixLQUFxRSxLQUFJQyxDQUFKLElBQVNya0IsT0FBTyt0QixtQkFBUCxDQUEyQixJQUEzQixDQUFUO0FBQTBDLG9CQUFZLE9BQU8sS0FBSzFKLENBQUwsQ0FBbkIsS0FBNkIsS0FBS0EsQ0FBTCxJQUFRLElBQXJDO0FBQTFDO0FBQXFGLEdBQTErQixFQUEyK0JELEVBQUVuZ0IsRUFBRixDQUFLbXBCLFdBQUwsQ0FBaUJDLFdBQWpCLENBQTZCcEgsT0FBN0IsQ0FBcUN1SyxRQUFyQyxHQUE4Q2h2QixDQUF6aEM7QUFBMmhDLENBQXhzRSxDQUF5c0V3QyxPQUFPc3BCLEtBQVAsSUFBY3RwQixPQUFPa0MsTUFBOXRFLEVBQXF1RWxDLE1BQXJ1RSxFQUE0dUU5QixRQUE1dUUsQ0FEN0YsRUFDbTFFLFVBQVNraUIsQ0FBVCxFQUFXQyxDQUFYLEVBQWFDLENBQWIsRUFBZUMsQ0FBZixFQUFpQjtBQUFDO0FBQWEsTUFBSS9pQixJQUFFLFNBQUZBLENBQUUsQ0FBUzZpQixDQUFULEVBQVc7QUFBQyxTQUFLa0osS0FBTCxHQUFXbEosQ0FBWCxFQUFhLEtBQUswTSxZQUFMLEdBQWtCLENBQUMsQ0FBaEMsRUFBa0MsS0FBS0MsTUFBTCxHQUFZLEVBQTlDLEVBQWlELEtBQUtDLFNBQUwsR0FBZSxFQUFoRSxFQUFtRSxLQUFLQyxVQUFMLEdBQWdCLEVBQW5GLEVBQXNGLEtBQUt4eUIsUUFBTCxHQUFjLEtBQUs2dUIsS0FBTCxDQUFXN3VCLFFBQS9HLEVBQXdILEtBQUt5eUIsVUFBTCxHQUFnQixFQUFDeFosTUFBSyxLQUFLNFYsS0FBTCxDQUFXNVYsSUFBakIsRUFBc0JrVSxNQUFLLEtBQUswQixLQUFMLENBQVcxQixJQUF0QyxFQUEyQ0QsSUFBRyxLQUFLMkIsS0FBTCxDQUFXM0IsRUFBekQsRUFBeEksRUFBcU0sS0FBS2xILFNBQUwsR0FBZSxFQUFDLHlCQUF3Qk4sRUFBRTRCLEtBQUYsQ0FBUSxVQUFTM0IsQ0FBVCxFQUFXO0FBQUNBLFVBQUUvakIsU0FBRixJQUFhLEtBQUtpdEIsS0FBTCxDQUFXL0ksUUFBWCxDQUFvQjRNLFFBQWpDLElBQTJDLEtBQUtGLFVBQUwsQ0FBZ0JyeUIsSUFBaEIsQ0FBcUIsaUJBQWUsS0FBSzB1QixLQUFMLENBQVcvSSxRQUFYLENBQW9CNk0sUUFBbkMsR0FBNEMsSUFBNUMsR0FBaURqTixFQUFFQyxFQUFFaUcsT0FBSixFQUFhcnBCLElBQWIsQ0FBa0IsWUFBbEIsRUFBZ0NDLE9BQWhDLENBQXdDLFlBQXhDLEVBQXNEckQsSUFBdEQsQ0FBMkQsVUFBM0QsQ0FBakQsR0FBd0gsUUFBN0ksQ0FBM0M7QUFBa00sT0FBdE4sRUFBdU4sSUFBdk4sQ0FBekIsRUFBc1Asc0JBQXFCdW1CLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsSUFBYSxLQUFLaXRCLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0I0TSxRQUFqQyxJQUEyQyxLQUFLRixVQUFMLENBQWdCbnlCLE1BQWhCLENBQXVCcWxCLEVBQUVqYyxRQUF6QixFQUFrQyxDQUFsQyxFQUFvQyxLQUFLK29CLFVBQUwsQ0FBZ0JJLEdBQWhCLEVBQXBDLENBQTNDO0FBQXNHLE9BQTFILEVBQTJILElBQTNILENBQTNRLEVBQTRZLHVCQUFzQmxOLEVBQUU0QixLQUFGLENBQVEsVUFBUzVCLENBQVQsRUFBVztBQUFDQSxVQUFFOWpCLFNBQUYsSUFBYSxLQUFLaXRCLEtBQUwsQ0FBVy9JLFFBQVgsQ0FBb0I0TSxRQUFqQyxJQUEyQyxLQUFLRixVQUFMLENBQWdCbnlCLE1BQWhCLENBQXVCcWxCLEVBQUVqYyxRQUF6QixFQUFrQyxDQUFsQyxDQUEzQztBQUFnRixPQUFwRyxFQUFxRyxJQUFyRyxDQUFsYSxFQUE2Z0Isd0JBQXVCaWMsRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUU5akIsU0FBRixJQUFhLGNBQVk4akIsRUFBRStGLFFBQUYsQ0FBV3BzQixJQUFwQyxJQUEwQyxLQUFLd3pCLElBQUwsRUFBMUM7QUFBc0QsT0FBMUUsRUFBMkUsSUFBM0UsQ0FBcGlCLEVBQXFuQiw0QkFBMkJuTixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0EsVUFBRTlqQixTQUFGLElBQWEsQ0FBQyxLQUFLeXdCLFlBQW5CLEtBQWtDLEtBQUt4RCxLQUFMLENBQVczdUIsT0FBWCxDQUFtQixZQUFuQixFQUFnQyxJQUFoQyxFQUFxQyxZQUFyQyxHQUFtRCxLQUFLeW5CLFVBQUwsRUFBbkQsRUFBcUUsS0FBS2tFLE1BQUwsRUFBckUsRUFBbUYsS0FBS2dILElBQUwsRUFBbkYsRUFBK0YsS0FBS1IsWUFBTCxHQUFrQixDQUFDLENBQWxILEVBQW9ILEtBQUt4RCxLQUFMLENBQVczdUIsT0FBWCxDQUFtQixhQUFuQixFQUFpQyxJQUFqQyxFQUFzQyxZQUF0QyxDQUF0SjtBQUEyTSxPQUEvTixFQUFnTyxJQUFoTyxDQUFocEIsRUFBczNCLDBCQUF5QndsQixFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVc7QUFBQ0EsVUFBRTlqQixTQUFGLElBQWEsS0FBS3l3QixZQUFsQixLQUFpQyxLQUFLeEQsS0FBTCxDQUFXM3VCLE9BQVgsQ0FBbUIsU0FBbkIsRUFBNkIsSUFBN0IsRUFBa0MsWUFBbEMsR0FBZ0QsS0FBSzJyQixNQUFMLEVBQWhELEVBQThELEtBQUtnSCxJQUFMLEVBQTlELEVBQTBFLEtBQUtoRSxLQUFMLENBQVczdUIsT0FBWCxDQUFtQixXQUFuQixFQUErQixJQUEvQixFQUFvQyxZQUFwQyxDQUEzRztBQUE4SixPQUFsTCxFQUFtTCxJQUFuTCxDQUEvNEIsRUFBcE4sRUFBNnhDLEtBQUsydUIsS0FBTCxDQUFXOWMsT0FBWCxHQUFtQjJULEVBQUVyYSxNQUFGLENBQVMsRUFBVCxFQUFZdkksRUFBRWlqQixRQUFkLEVBQXVCLEtBQUs4SSxLQUFMLENBQVc5YyxPQUFsQyxDQUFoekMsRUFBMjFDLEtBQUsvUixRQUFMLENBQWNtTSxFQUFkLENBQWlCLEtBQUs2WixTQUF0QixDQUEzMUM7QUFBNDNDLEdBQTk0QyxDQUErNENsakIsRUFBRWlqQixRQUFGLEdBQVcsRUFBQytNLEtBQUksQ0FBQyxDQUFOLEVBQVFDLFNBQVEsQ0FBQyxNQUFELEVBQVEsTUFBUixDQUFoQixFQUFnQ0MsVUFBUyxDQUFDLENBQTFDLEVBQTRDQyxZQUFXLEtBQXZELEVBQTZEQyxjQUFhLENBQUMsQ0FBM0UsRUFBNkVDLG1CQUFrQixTQUEvRixFQUF5R0MsVUFBUyxDQUFDLFVBQUQsRUFBWSxVQUFaLENBQWxILEVBQTBJQyxTQUFRLENBQWxKLEVBQW9KVixVQUFTLFNBQTdKLEVBQXVLVyxXQUFVLFVBQWpMLEVBQTRMQyxNQUFLLENBQUMsQ0FBbE0sRUFBb01DLFVBQVMsQ0FBQyxDQUE5TSxFQUFnTmQsVUFBUyxDQUFDLENBQTFOLEVBQTROZSxXQUFVLENBQUMsQ0FBdk8sRUFBeU9DLGVBQWMsQ0FBQyxDQUF4UCxFQUFYLEVBQXNRNXdCLEVBQUVrQyxTQUFGLENBQVkyaUIsVUFBWixHQUF1QixZQUFVO0FBQUMsUUFBSWhDLENBQUo7QUFBQSxRQUFNQyxJQUFFLEtBQUtpSixLQUFMLENBQVcvSSxRQUFuQixDQUE0QixLQUFLeU0sU0FBTCxDQUFlb0IsU0FBZixHQUF5QixDQUFDL04sRUFBRXNOLFlBQUYsR0FBZXhOLEVBQUVFLEVBQUVzTixZQUFKLENBQWYsR0FBaUN4TixFQUFFLE9BQUYsRUFBVzlVLFFBQVgsQ0FBb0JnVixFQUFFdU4saUJBQXRCLEVBQXlDeHVCLFFBQXpDLENBQWtELEtBQUszRSxRQUF2RCxDQUFsQyxFQUFvRzRRLFFBQXBHLENBQTZHLFVBQTdHLENBQXpCLEVBQWtKLEtBQUsyaEIsU0FBTCxDQUFlcUIsU0FBZixHQUF5QmxPLEVBQUUsTUFBSUUsRUFBRXFOLFVBQU4sR0FBaUIsR0FBbkIsRUFBd0JyaUIsUUFBeEIsQ0FBaUNnVixFQUFFd04sUUFBRixDQUFXLENBQVgsQ0FBakMsRUFBZ0R2TyxJQUFoRCxDQUFxRGUsRUFBRW1OLE9BQUYsQ0FBVSxDQUFWLENBQXJELEVBQW1FeFksU0FBbkUsQ0FBNkUsS0FBS2dZLFNBQUwsQ0FBZW9CLFNBQTVGLEVBQXVHeG5CLEVBQXZHLENBQTBHLE9BQTFHLEVBQWtIdVosRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUMsV0FBS3lILElBQUwsQ0FBVXZILEVBQUVvTixRQUFaO0FBQXNCLEtBQTFDLEVBQTJDLElBQTNDLENBQWxILENBQTNLLEVBQStVLEtBQUtULFNBQUwsQ0FBZXNCLEtBQWYsR0FBcUJuTyxFQUFFLE1BQUlFLEVBQUVxTixVQUFOLEdBQWlCLEdBQW5CLEVBQXdCcmlCLFFBQXhCLENBQWlDZ1YsRUFBRXdOLFFBQUYsQ0FBVyxDQUFYLENBQWpDLEVBQWdEdk8sSUFBaEQsQ0FBcURlLEVBQUVtTixPQUFGLENBQVUsQ0FBVixDQUFyRCxFQUFtRXB1QixRQUFuRSxDQUE0RSxLQUFLNHRCLFNBQUwsQ0FBZW9CLFNBQTNGLEVBQXNHeG5CLEVBQXRHLENBQXlHLE9BQXpHLEVBQWlIdVosRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUMsV0FBS3pNLElBQUwsQ0FBVTJNLEVBQUVvTixRQUFaO0FBQXNCLEtBQTFDLEVBQTJDLElBQTNDLENBQWpILENBQXBXLEVBQXVnQnBOLEVBQUU4TSxRQUFGLEtBQWEsS0FBS0YsVUFBTCxHQUFnQixDQUFDOU0sRUFBRSxPQUFGLEVBQVc5VSxRQUFYLENBQW9CZ1YsRUFBRStNLFFBQXRCLEVBQWdDL1gsTUFBaEMsQ0FBdUM4SyxFQUFFLFFBQUYsQ0FBdkMsRUFBb0RqbEIsSUFBcEQsQ0FBeUQsV0FBekQsQ0FBRCxDQUE3QixDQUF2Z0IsRUFBNm1CLEtBQUs4eEIsU0FBTCxDQUFldUIsU0FBZixHQUF5QixDQUFDbE8sRUFBRThOLGFBQUYsR0FBZ0JoTyxFQUFFRSxFQUFFOE4sYUFBSixDQUFoQixHQUFtQ2hPLEVBQUUsT0FBRixFQUFXOVUsUUFBWCxDQUFvQmdWLEVBQUUwTixTQUF0QixFQUFpQzN1QixRQUFqQyxDQUEwQyxLQUFLM0UsUUFBL0MsQ0FBcEMsRUFBOEY0USxRQUE5RixDQUF1RyxVQUF2RyxDQUF0b0IsRUFBeXZCLEtBQUsyaEIsU0FBTCxDQUFldUIsU0FBZixDQUF5QjNuQixFQUF6QixDQUE0QixPQUE1QixFQUFvQyxLQUFwQyxFQUEwQ3VaLEVBQUU0QixLQUFGLENBQVEsVUFBUzNCLENBQVQsRUFBVztBQUFDLFVBQUlFLElBQUVILEVBQUVDLEVBQUV2WixNQUFKLEVBQVl0RSxNQUFaLEdBQXFCNkQsRUFBckIsQ0FBd0IsS0FBSzRtQixTQUFMLENBQWV1QixTQUF2QyxJQUFrRHBPLEVBQUVDLEVBQUV2WixNQUFKLEVBQVk0VCxLQUFaLEVBQWxELEdBQXNFMEYsRUFBRUMsRUFBRXZaLE1BQUosRUFBWXRFLE1BQVosR0FBcUJrWSxLQUFyQixFQUE1RSxDQUF5RzJGLEVBQUV0WixjQUFGLElBQW1CLEtBQUs2Z0IsRUFBTCxDQUFRckgsQ0FBUixFQUFVRCxFQUFFNk4sU0FBWixDQUFuQjtBQUEwQyxLQUF2SyxFQUF3SyxJQUF4SyxDQUExQyxDQUF6dkIsQ0FBazlCLEtBQUk5TixDQUFKLElBQVMsS0FBSzhNLFVBQWQ7QUFBeUIsV0FBSzVELEtBQUwsQ0FBV2xKLENBQVgsSUFBY0QsRUFBRTRCLEtBQUYsQ0FBUSxLQUFLM0IsQ0FBTCxDQUFSLEVBQWdCLElBQWhCLENBQWQ7QUFBekI7QUFBNkQsR0FBbjFDLEVBQW8xQzdpQixFQUFFa0MsU0FBRixDQUFZa2UsT0FBWixHQUFvQixZQUFVO0FBQUMsUUFBSXdDLENBQUosRUFBTUMsQ0FBTixFQUFRQyxDQUFSLEVBQVVDLENBQVYsQ0FBWSxLQUFJSCxDQUFKLElBQVMsS0FBS00sU0FBZDtBQUF3QixXQUFLaG1CLFFBQUwsQ0FBY3dNLEdBQWQsQ0FBa0JrWixDQUFsQixFQUFvQixLQUFLTSxTQUFMLENBQWVOLENBQWYsQ0FBcEI7QUFBeEIsS0FBK0QsS0FBSUMsQ0FBSixJQUFTLEtBQUs0TSxTQUFkO0FBQXdCLFdBQUtBLFNBQUwsQ0FBZTVNLENBQWYsRUFBa0I3SSxNQUFsQjtBQUF4QixLQUFtRCxLQUFJK0ksQ0FBSixJQUFTLEtBQUtrTyxRQUFkO0FBQXVCLFdBQUtsRixLQUFMLENBQVdoSixDQUFYLElBQWMsS0FBSzRNLFVBQUwsQ0FBZ0I1TSxDQUFoQixDQUFkO0FBQXZCLEtBQXdELEtBQUlELENBQUosSUFBU3RrQixPQUFPK3RCLG1CQUFQLENBQTJCLElBQTNCLENBQVQ7QUFBMEMsb0JBQVksT0FBTyxLQUFLekosQ0FBTCxDQUFuQixLQUE2QixLQUFLQSxDQUFMLElBQVEsSUFBckM7QUFBMUM7QUFBcUYsR0FBOW5ELEVBQStuRDlpQixFQUFFa0MsU0FBRixDQUFZNm1CLE1BQVosR0FBbUIsWUFBVTtBQUFDLFFBQUluRyxDQUFKO0FBQUEsUUFBTUMsQ0FBTjtBQUFBLFFBQVFDLENBQVI7QUFBQSxRQUFVQyxJQUFFLEtBQUtnSixLQUFMLENBQVc1QixNQUFYLEdBQW9CdHJCLE1BQXBCLEdBQTJCLENBQXZDO0FBQUEsUUFBeUNtQixJQUFFK2lCLElBQUUsS0FBS2dKLEtBQUwsQ0FBV3ZkLEtBQVgsR0FBbUIzUCxNQUFoRTtBQUFBLFFBQXVFNG9CLElBQUUsS0FBS3NFLEtBQUwsQ0FBVy9ELE9BQVgsQ0FBbUIsQ0FBQyxDQUFwQixDQUF6RTtBQUFBLFFBQWdHTCxJQUFFLEtBQUtvRSxLQUFMLENBQVcvSSxRQUE3RztBQUFBLFFBQXNINEUsSUFBRUQsRUFBRTVDLE1BQUYsSUFBVTRDLEVBQUVsQyxTQUFaLElBQXVCa0MsRUFBRWlJLFFBQXpCLEdBQWtDLENBQWxDLEdBQW9DakksRUFBRStJLFFBQUYsSUFBWS9JLEVBQUVuWixLQUExSyxDQUFnTCxJQUFHLFdBQVNtWixFQUFFNEksT0FBWCxLQUFxQjVJLEVBQUU0SSxPQUFGLEdBQVV4eEIsS0FBS2tYLEdBQUwsQ0FBUzBSLEVBQUU0SSxPQUFYLEVBQW1CNUksRUFBRW5aLEtBQXJCLENBQS9CLEdBQTREbVosRUFBRThJLElBQUYsSUFBUSxVQUFROUksRUFBRTRJLE9BQWpGLEVBQXlGLEtBQUksS0FBS2YsTUFBTCxHQUFZLEVBQVosRUFBZTVNLElBQUVHLENBQWpCLEVBQW1CRixJQUFFLENBQXJCLEVBQXVCQyxJQUFFLENBQTdCLEVBQStCRixJQUFFNWlCLENBQWpDLEVBQW1DNGlCLEdBQW5DLEVBQXVDO0FBQUMsVUFBR0MsS0FBRytFLENBQUgsSUFBTSxNQUFJL0UsQ0FBYixFQUFlO0FBQUMsWUFBRyxLQUFLMk0sTUFBTCxDQUFZbnlCLElBQVosQ0FBaUIsRUFBQ3FHLE9BQU0zRSxLQUFLa1gsR0FBTCxDQUFTd1IsQ0FBVCxFQUFXN0UsSUFBRUcsQ0FBYixDQUFQLEVBQXVCbmlCLEtBQUlnaUIsSUFBRUcsQ0FBRixHQUFJNkUsQ0FBSixHQUFNLENBQWpDLEVBQWpCLEdBQXNEN29CLEtBQUtrWCxHQUFMLENBQVN3UixDQUFULEVBQVc3RSxJQUFFRyxDQUFiLE1BQWtCMEUsQ0FBM0UsRUFBNkUsTUFBTTVFLElBQUUsQ0FBRixFQUFJLEVBQUVDLENBQU47QUFBUSxZQUFHLEtBQUtpSixLQUFMLENBQVc3QixPQUFYLENBQW1CLEtBQUs2QixLQUFMLENBQVd6RSxRQUFYLENBQW9CMUUsQ0FBcEIsQ0FBbkIsQ0FBSDtBQUE4QztBQUFDLEdBQXhtRSxFQUF5bUU1aUIsRUFBRWtDLFNBQUYsQ0FBWTZ0QixJQUFaLEdBQWlCLFlBQVU7QUFBQyxRQUFJbE4sQ0FBSjtBQUFBLFFBQU1DLElBQUUsS0FBS2lKLEtBQUwsQ0FBVy9JLFFBQW5CO0FBQUEsUUFBNEJELElBQUUsS0FBS2dKLEtBQUwsQ0FBV3ZkLEtBQVgsR0FBbUIzUCxNQUFuQixJQUEyQmlrQixFQUFFdFUsS0FBM0Q7QUFBQSxRQUFpRXhPLElBQUUsS0FBSytyQixLQUFMLENBQVd6RSxRQUFYLENBQW9CLEtBQUt5RSxLQUFMLENBQVc1aEIsT0FBWCxFQUFwQixDQUFuRTtBQUFBLFFBQTZHc2QsSUFBRTNFLEVBQUVnQyxJQUFGLElBQVFoQyxFQUFFa0MsTUFBekgsQ0FBZ0ksS0FBS3lLLFNBQUwsQ0FBZW9CLFNBQWYsQ0FBeUJ6UCxXQUF6QixDQUFxQyxVQUFyQyxFQUFnRCxDQUFDMEIsRUFBRWtOLEdBQUgsSUFBUWpOLENBQXhELEdBQTJERCxFQUFFa04sR0FBRixLQUFRLEtBQUtQLFNBQUwsQ0FBZXFCLFNBQWYsQ0FBeUIxUCxXQUF6QixDQUFxQyxVQUFyQyxFQUFnRCxDQUFDcUcsQ0FBRCxJQUFJem5CLEtBQUcsS0FBSytyQixLQUFMLENBQVdoRSxPQUFYLENBQW1CLENBQUMsQ0FBcEIsQ0FBdkQsR0FBK0UsS0FBSzBILFNBQUwsQ0FBZXNCLEtBQWYsQ0FBcUIzUCxXQUFyQixDQUFpQyxVQUFqQyxFQUE0QyxDQUFDcUcsQ0FBRCxJQUFJem5CLEtBQUcsS0FBSytyQixLQUFMLENBQVcvRCxPQUFYLENBQW1CLENBQUMsQ0FBcEIsQ0FBbkQsQ0FBdkYsQ0FBM0QsRUFBOE4sS0FBS3lILFNBQUwsQ0FBZXVCLFNBQWYsQ0FBeUI1UCxXQUF6QixDQUFxQyxVQUFyQyxFQUFnRCxDQUFDMEIsRUFBRTJOLElBQUgsSUFBUzFOLENBQXpELENBQTlOLEVBQTBSRCxFQUFFMk4sSUFBRixLQUFTNU4sSUFBRSxLQUFLMk0sTUFBTCxDQUFZM3dCLE1BQVosR0FBbUIsS0FBSzR3QixTQUFMLENBQWV1QixTQUFmLENBQXlCbGlCLFFBQXpCLEdBQW9DalEsTUFBekQsRUFBZ0Vpa0IsRUFBRThNLFFBQUYsSUFBWSxNQUFJL00sQ0FBaEIsR0FBa0IsS0FBSzRNLFNBQUwsQ0FBZXVCLFNBQWYsQ0FBeUJqUCxJQUF6QixDQUE4QixLQUFLMk4sVUFBTCxDQUFnQjliLElBQWhCLENBQXFCLEVBQXJCLENBQTlCLENBQWxCLEdBQTBFaVAsSUFBRSxDQUFGLEdBQUksS0FBSzRNLFNBQUwsQ0FBZXVCLFNBQWYsQ0FBeUJsWixNQUF6QixDQUFnQyxJQUFJN1YsS0FBSixDQUFVNGdCLElBQUUsQ0FBWixFQUFlalAsSUFBZixDQUFvQixLQUFLOGIsVUFBTCxDQUFnQixDQUFoQixDQUFwQixDQUFoQyxDQUFKLEdBQTZFN00sSUFBRSxDQUFGLElBQUssS0FBSzRNLFNBQUwsQ0FBZXVCLFNBQWYsQ0FBeUJsaUIsUUFBekIsR0FBb0MxUCxLQUFwQyxDQUEwQ3lqQixDQUExQyxFQUE2QzdJLE1BQTdDLEVBQTVOLEVBQWtSLEtBQUt5VixTQUFMLENBQWV1QixTQUFmLENBQXlCdnhCLElBQXpCLENBQThCLFNBQTlCLEVBQXlDc0MsV0FBekMsQ0FBcUQsUUFBckQsQ0FBbFIsRUFBaVYsS0FBSzB0QixTQUFMLENBQWV1QixTQUFmLENBQXlCbGlCLFFBQXpCLEdBQW9DM0YsRUFBcEMsQ0FBdUN5WixFQUFFOEksT0FBRixDQUFVLEtBQUt2aEIsT0FBTCxFQUFWLEVBQXlCLEtBQUtxbEIsTUFBOUIsQ0FBdkMsRUFBOEUxaEIsUUFBOUUsQ0FBdUYsUUFBdkYsQ0FBMVYsQ0FBMVI7QUFBc3RCLEdBQTM5RixFQUE0OUY5TixFQUFFa0MsU0FBRixDQUFZcXBCLFNBQVosR0FBc0IsVUFBUzFJLENBQVQsRUFBVztBQUFDLFFBQUlDLElBQUUsS0FBS2lKLEtBQUwsQ0FBVy9JLFFBQWpCLENBQTBCSCxFQUFFcU8sSUFBRixHQUFPLEVBQUNoVSxPQUFNMEYsRUFBRThJLE9BQUYsQ0FBVSxLQUFLdmhCLE9BQUwsRUFBVixFQUF5QixLQUFLcWxCLE1BQTlCLENBQVAsRUFBNkNyRSxPQUFNLEtBQUtxRSxNQUFMLENBQVkzd0IsTUFBL0QsRUFBc0VpTSxNQUFLZ1ksTUFBSUEsRUFBRWlDLE1BQUYsSUFBVWpDLEVBQUUyQyxTQUFaLElBQXVCM0MsRUFBRThNLFFBQXpCLEdBQWtDLENBQWxDLEdBQW9DOU0sRUFBRTROLFFBQUYsSUFBWTVOLEVBQUV0VSxLQUF0RCxDQUEzRSxFQUFQO0FBQWdKLEdBQXhxRyxFQUF5cUd4TyxFQUFFa0MsU0FBRixDQUFZaUksT0FBWixHQUFvQixZQUFVO0FBQUMsUUFBSTBZLElBQUUsS0FBS2tKLEtBQUwsQ0FBV3pFLFFBQVgsQ0FBb0IsS0FBS3lFLEtBQUwsQ0FBVzVoQixPQUFYLEVBQXBCLENBQU4sQ0FBZ0QsT0FBT3lZLEVBQUVxRyxJQUFGLENBQU8sS0FBS3VHLE1BQVosRUFBbUI1TSxFQUFFNEIsS0FBRixDQUFRLFVBQVM1QixDQUFULEVBQVdFLENBQVgsRUFBYTtBQUFDLGFBQU9GLEVBQUVsZixLQUFGLElBQVNtZixDQUFULElBQVlELEVBQUVoaUIsR0FBRixJQUFPaWlCLENBQTFCO0FBQTRCLEtBQWxELEVBQW1ELElBQW5ELENBQW5CLEVBQTZFaU4sR0FBN0UsRUFBUDtBQUEwRixHQUFsMUcsRUFBbTFHOXZCLEVBQUVrQyxTQUFGLENBQVlpdkIsV0FBWixHQUF3QixVQUFTdE8sQ0FBVCxFQUFXO0FBQUMsUUFBSUMsQ0FBSjtBQUFBLFFBQU1DLENBQU47QUFBQSxRQUFRL2lCLElBQUUsS0FBSytyQixLQUFMLENBQVcvSSxRQUFyQixDQUE4QixPQUFNLFVBQVFoakIsRUFBRXV3QixPQUFWLElBQW1Cek4sSUFBRUYsRUFBRThJLE9BQUYsQ0FBVSxLQUFLdmhCLE9BQUwsRUFBVixFQUF5QixLQUFLcWxCLE1BQTlCLENBQUYsRUFBd0N6TSxJQUFFLEtBQUt5TSxNQUFMLENBQVkzd0IsTUFBdEQsRUFBNkRna0IsSUFBRSxFQUFFQyxDQUFKLEdBQU0sRUFBRUEsQ0FBckUsRUFBdUVBLElBQUUsS0FBSzBNLE1BQUwsQ0FBWSxDQUFDMU0sSUFBRUMsQ0FBRixHQUFJQSxDQUFMLElBQVFBLENBQXBCLEVBQXVCcmYsS0FBbkgsS0FBMkhvZixJQUFFLEtBQUtpSixLQUFMLENBQVd6RSxRQUFYLENBQW9CLEtBQUt5RSxLQUFMLENBQVc1aEIsT0FBWCxFQUFwQixDQUFGLEVBQTRDNFksSUFBRSxLQUFLZ0osS0FBTCxDQUFXdmQsS0FBWCxHQUFtQjNQLE1BQWpFLEVBQXdFZ2tCLElBQUVDLEtBQUc5aUIsRUFBRXV3QixPQUFQLEdBQWV6TixLQUFHOWlCLEVBQUV1d0IsT0FBdk4sR0FBZ096TixDQUF0TztBQUF3TyxHQUE3bkgsRUFBOG5IOWlCLEVBQUVrQyxTQUFGLENBQVlpVSxJQUFaLEdBQWlCLFVBQVMwTSxDQUFULEVBQVc7QUFBQ0QsTUFBRTRCLEtBQUYsQ0FBUSxLQUFLbUwsVUFBTCxDQUFnQnZGLEVBQXhCLEVBQTJCLEtBQUsyQixLQUFoQyxFQUF1QyxLQUFLb0YsV0FBTCxDQUFpQixDQUFDLENBQWxCLENBQXZDLEVBQTREdE8sQ0FBNUQ7QUFBK0QsR0FBMXRILEVBQTJ0SDdpQixFQUFFa0MsU0FBRixDQUFZbW9CLElBQVosR0FBaUIsVUFBU3hILENBQVQsRUFBVztBQUFDRCxNQUFFNEIsS0FBRixDQUFRLEtBQUttTCxVQUFMLENBQWdCdkYsRUFBeEIsRUFBMkIsS0FBSzJCLEtBQWhDLEVBQXVDLEtBQUtvRixXQUFMLENBQWlCLENBQUMsQ0FBbEIsQ0FBdkMsRUFBNER0TyxDQUE1RDtBQUErRCxHQUF2ekgsRUFBd3pIN2lCLEVBQUVrQyxTQUFGLENBQVlrb0IsRUFBWixHQUFlLFVBQVN2SCxDQUFULEVBQVdDLENBQVgsRUFBYUMsQ0FBYixFQUFlO0FBQUMsUUFBSS9pQixDQUFKLENBQU0sQ0FBQytpQixDQUFELElBQUksS0FBS3lNLE1BQUwsQ0FBWTN3QixNQUFoQixJQUF3Qm1CLElBQUUsS0FBS3d2QixNQUFMLENBQVkzd0IsTUFBZCxFQUFxQitqQixFQUFFNEIsS0FBRixDQUFRLEtBQUttTCxVQUFMLENBQWdCdkYsRUFBeEIsRUFBMkIsS0FBSzJCLEtBQWhDLEVBQXVDLEtBQUt5RCxNQUFMLENBQVksQ0FBQzNNLElBQUU3aUIsQ0FBRixHQUFJQSxDQUFMLElBQVFBLENBQXBCLEVBQXVCMEQsS0FBOUQsRUFBb0VvZixDQUFwRSxDQUE3QyxJQUFxSEYsRUFBRTRCLEtBQUYsQ0FBUSxLQUFLbUwsVUFBTCxDQUFnQnZGLEVBQXhCLEVBQTJCLEtBQUsyQixLQUFoQyxFQUF1Q2xKLENBQXZDLEVBQXlDQyxDQUF6QyxDQUFySDtBQUFpSyxHQUE5L0gsRUFBKy9IRixFQUFFbmdCLEVBQUYsQ0FBS21wQixXQUFMLENBQWlCQyxXQUFqQixDQUE2QnBILE9BQTdCLENBQXFDMk0sVUFBckMsR0FBZ0RweEIsQ0FBL2lJO0FBQWlqSSxDQUEvOUssQ0FBZytLd0MsT0FBT3NwQixLQUFQLElBQWN0cEIsT0FBT2tDLE1BQXIvSyxFQUE0L0tsQyxNQUE1L0ssRUFBbWdMOUIsUUFBbmdMLENBRG4xRSxFQUNnMlAsVUFBU2tpQixDQUFULEVBQVdDLENBQVgsRUFBYUMsQ0FBYixFQUFlQyxDQUFmLEVBQWlCO0FBQUM7QUFBYSxNQUFJL2lCLElBQUUsU0FBRkEsQ0FBRSxDQUFTOGlCLENBQVQsRUFBVztBQUFDLFNBQUtpSixLQUFMLEdBQVdqSixDQUFYLEVBQWEsS0FBS3VPLE9BQUwsR0FBYSxFQUExQixFQUE2QixLQUFLbjBCLFFBQUwsR0FBYyxLQUFLNnVCLEtBQUwsQ0FBVzd1QixRQUF0RCxFQUErRCxLQUFLZ21CLFNBQUwsR0FBZSxFQUFDLDRCQUEyQk4sRUFBRTRCLEtBQUYsQ0FBUSxVQUFTMUIsQ0FBVCxFQUFXO0FBQUNBLFVBQUVoa0IsU0FBRixJQUFhLGNBQVksS0FBS2l0QixLQUFMLENBQVcvSSxRQUFYLENBQW9CMEMsYUFBN0MsSUFBNEQ5QyxFQUFFQyxDQUFGLEVBQUt6bEIsT0FBTCxDQUFhLDJCQUFiLENBQTVEO0FBQXNHLE9BQTFILEVBQTJILElBQTNILENBQTVCLEVBQTZKLHlCQUF3QndsQixFQUFFNEIsS0FBRixDQUFRLFVBQVMzQixDQUFULEVBQVc7QUFBQyxZQUFHQSxFQUFFL2pCLFNBQUwsRUFBZTtBQUFDLGNBQUlna0IsSUFBRUYsRUFBRUMsRUFBRWlHLE9BQUosRUFBYXJwQixJQUFiLENBQWtCLGFBQWxCLEVBQWlDQyxPQUFqQyxDQUF5QyxhQUF6QyxFQUF3RHJELElBQXhELENBQTZELFdBQTdELENBQU4sQ0FBZ0YsSUFBRyxDQUFDeW1CLENBQUosRUFBTSxPQUFPLEtBQUt1TyxPQUFMLENBQWF2TyxDQUFiLElBQWdCRCxFQUFFaUcsT0FBbEI7QUFBMEI7QUFBQyxPQUE1SixFQUE2SixJQUE3SixDQUFyTCxFQUF3Vix3QkFBdUJsRyxFQUFFNEIsS0FBRixDQUFRLFVBQVMxQixDQUFULEVBQVc7QUFBQyxZQUFHQSxFQUFFaGtCLFNBQUYsSUFBYSxlQUFhZ2tCLEVBQUU2RixRQUFGLENBQVdwc0IsSUFBeEMsRUFBNkM7QUFBQyxjQUFJd21CLElBQUUsS0FBS2dKLEtBQUwsQ0FBV3ZkLEtBQVgsQ0FBaUIsS0FBS3VkLEtBQUwsQ0FBV3pFLFFBQVgsQ0FBb0IsS0FBS3lFLEtBQUwsQ0FBVzVoQixPQUFYLEVBQXBCLENBQWpCLENBQU47QUFBQSxjQUFrRW5LLElBQUU0aUIsRUFBRTFpQixHQUFGLENBQU0sS0FBS214QixPQUFYLEVBQW1CLFVBQVN6TyxDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLG1CQUFPRCxNQUFJRyxDQUFKLEdBQU1GLENBQU4sR0FBUSxJQUFmO0FBQW9CLFdBQXJELEVBQXVEalAsSUFBdkQsRUFBcEUsQ0FBa0ksSUFBRyxDQUFDNVQsQ0FBRCxJQUFJNmlCLEVBQUV5TyxRQUFGLENBQVdDLElBQVgsQ0FBZ0JueUIsS0FBaEIsQ0FBc0IsQ0FBdEIsTUFBMkJZLENBQWxDLEVBQW9DLE9BQU82aUIsRUFBRXlPLFFBQUYsQ0FBV0MsSUFBWCxHQUFnQnZ4QixDQUFoQjtBQUFrQjtBQUFDLE9BQWxRLEVBQW1RLElBQW5RLENBQS9XLEVBQTlFLEVBQXVzQixLQUFLK3JCLEtBQUwsQ0FBVzljLE9BQVgsR0FBbUIyVCxFQUFFcmEsTUFBRixDQUFTLEVBQVQsRUFBWXZJLEVBQUVpakIsUUFBZCxFQUF1QixLQUFLOEksS0FBTCxDQUFXOWMsT0FBbEMsQ0FBMXRCLEVBQXF3QixLQUFLL1IsUUFBTCxDQUFjbU0sRUFBZCxDQUFpQixLQUFLNlosU0FBdEIsQ0FBcndCLEVBQXN5Qk4sRUFBRUMsQ0FBRixFQUFLeFosRUFBTCxDQUFRLDJCQUFSLEVBQW9DdVosRUFBRTRCLEtBQUYsQ0FBUSxVQUFTNUIsQ0FBVCxFQUFXO0FBQUMsVUFBSUUsSUFBRUQsRUFBRXlPLFFBQUYsQ0FBV0MsSUFBWCxDQUFnQkMsU0FBaEIsQ0FBMEIsQ0FBMUIsQ0FBTjtBQUFBLFVBQW1DeHhCLElBQUUsS0FBSytyQixLQUFMLENBQVd4RSxNQUFYLENBQWtCelksUUFBbEIsRUFBckM7QUFBQSxVQUFrRTJZLElBQUUsS0FBSzRKLE9BQUwsQ0FBYXZPLENBQWIsS0FBaUI5aUIsRUFBRWtkLEtBQUYsQ0FBUSxLQUFLbVUsT0FBTCxDQUFhdk8sQ0FBYixDQUFSLENBQXJGLENBQThHMkUsTUFBSTFFLENBQUosSUFBTzBFLE1BQUksS0FBS3NFLEtBQUwsQ0FBVzVoQixPQUFYLEVBQVgsSUFBaUMsS0FBSzRoQixLQUFMLENBQVczQixFQUFYLENBQWMsS0FBSzJCLEtBQUwsQ0FBV3pFLFFBQVgsQ0FBb0JHLENBQXBCLENBQWQsRUFBcUMsQ0FBQyxDQUF0QyxFQUF3QyxDQUFDLENBQXpDLENBQWpDO0FBQTZFLEtBQS9NLEVBQWdOLElBQWhOLENBQXBDLENBQXR5QjtBQUFpaUMsR0FBbmpDLENBQW9qQ3puQixFQUFFaWpCLFFBQUYsR0FBVyxFQUFDd08saUJBQWdCLENBQUMsQ0FBbEIsRUFBWCxFQUFnQ3p4QixFQUFFa0MsU0FBRixDQUFZa2UsT0FBWixHQUFvQixZQUFVO0FBQUMsUUFBSTBDLENBQUosRUFBTUMsQ0FBTixDQUFRSCxFQUFFQyxDQUFGLEVBQUtuWixHQUFMLENBQVMsMkJBQVQsRUFBc0MsS0FBSW9aLENBQUosSUFBUyxLQUFLSSxTQUFkO0FBQXdCLFdBQUs2SSxLQUFMLENBQVc3dUIsUUFBWCxDQUFvQndNLEdBQXBCLENBQXdCb1osQ0FBeEIsRUFBMEIsS0FBS0ksU0FBTCxDQUFlSixDQUFmLENBQTFCO0FBQXhCLEtBQXFFLEtBQUlDLENBQUosSUFBU3ZrQixPQUFPK3RCLG1CQUFQLENBQTJCLElBQTNCLENBQVQ7QUFBMEMsb0JBQVksT0FBTyxLQUFLeEosQ0FBTCxDQUFuQixLQUE2QixLQUFLQSxDQUFMLElBQVEsSUFBckM7QUFBMUM7QUFBcUYsR0FBdlEsRUFBd1FILEVBQUVuZ0IsRUFBRixDQUFLbXBCLFdBQUwsQ0FBaUJDLFdBQWpCLENBQTZCcEgsT0FBN0IsQ0FBcUNpTixJQUFyQyxHQUEwQzF4QixDQUFsVDtBQUFvVCxDQUF2NEMsQ0FBdzRDd0MsT0FBT3NwQixLQUFQLElBQWN0cEIsT0FBT2tDLE1BQTc1QyxFQUFvNkNsQyxNQUFwNkMsRUFBMjZDOUIsUUFBMzZDLENBRGgyUCxFQUNxeFMsVUFBU2tpQixDQUFULEVBQVdDLENBQVgsRUFBYUMsQ0FBYixFQUFlQyxDQUFmLEVBQWlCO0FBQUMsV0FBUy9pQixDQUFULENBQVc2aUIsQ0FBWCxFQUFhQyxDQUFiLEVBQWU7QUFBQyxRQUFJOWlCLElBQUUsQ0FBQyxDQUFQO0FBQUEsUUFBU3luQixJQUFFNUUsRUFBRTZCLE1BQUYsQ0FBUyxDQUFULEVBQVk5YyxXQUFaLEtBQTBCaWIsRUFBRXpqQixLQUFGLENBQVEsQ0FBUixDQUFyQyxDQUFnRCxPQUFPd2pCLEVBQUU3a0IsSUFBRixDQUFPLENBQUM4a0IsSUFBRSxHQUFGLEdBQU0rRSxFQUFFaFUsSUFBRixDQUFPNlQsSUFBRSxHQUFULENBQU4sR0FBb0JBLENBQXJCLEVBQXdCMW5CLEtBQXhCLENBQThCLEdBQTlCLENBQVAsRUFBMEMsVUFBUzZpQixDQUFULEVBQVdDLENBQVgsRUFBYTtBQUFDLFVBQUc4RSxFQUFFOUUsQ0FBRixNQUFPRSxDQUFWLEVBQVksT0FBTy9pQixJQUFFLENBQUM4aUIsQ0FBRCxJQUFJRCxDQUFOLEVBQVEsQ0FBQyxDQUFoQjtBQUFrQixLQUF0RixHQUF3RjdpQixDQUEvRjtBQUFpRyxZQUFTeW5CLENBQVQsQ0FBVzdFLENBQVgsRUFBYTtBQUFDLFdBQU81aUIsRUFBRTRpQixDQUFGLEVBQUksQ0FBQyxDQUFMLENBQVA7QUFBZSxPQUFJK0UsSUFBRS9FLEVBQUUsV0FBRixFQUFlNVgsR0FBZixDQUFtQixDQUFuQixFQUFzQmxLLEtBQTVCO0FBQUEsTUFBa0M4bUIsSUFBRSxrQkFBa0I3bkIsS0FBbEIsQ0FBd0IsR0FBeEIsQ0FBcEM7QUFBQSxNQUFpRVIsSUFBRSxFQUFDNGUsWUFBVyxFQUFDdmQsS0FBSSxFQUFDK3dCLGtCQUFpQixxQkFBbEIsRUFBd0NDLGVBQWMsZUFBdEQsRUFBc0VDLGFBQVksZ0JBQWxGLEVBQW1HMVQsWUFBVyxlQUE5RyxFQUFMLEVBQVosRUFBaUpuUixXQUFVLEVBQUNwTSxLQUFJLEVBQUNreEIsaUJBQWdCLG9CQUFqQixFQUFzQ0MsY0FBYSxjQUFuRCxFQUFrRUMsWUFBVyxlQUE3RSxFQUE2RmhsQixXQUFVLGNBQXZHLEVBQUwsRUFBM0osRUFBbkU7QUFBQSxNQUE0VnFlLElBQUUsRUFBQzRHLGVBQWMseUJBQVU7QUFBQyxhQUFNLENBQUMsQ0FBQ2p5QixFQUFFLFdBQUYsQ0FBUjtBQUF1QixLQUFqRCxFQUFrRGt5QixpQkFBZ0IsMkJBQVU7QUFBQyxhQUFNLENBQUMsQ0FBQ2x5QixFQUFFLGFBQUYsQ0FBUjtBQUF5QixLQUF0RyxFQUF1R215QixnQkFBZSwwQkFBVTtBQUFDLGFBQU0sQ0FBQyxDQUFDbnlCLEVBQUUsWUFBRixDQUFSO0FBQXdCLEtBQXpKLEVBQTBKb3lCLGVBQWMseUJBQVU7QUFBQyxhQUFNLENBQUMsQ0FBQ3B5QixFQUFFLFdBQUYsQ0FBUjtBQUF1QixLQUExTSxFQUE5VixDQUEwaUJxckIsRUFBRThHLGNBQUYsT0FBcUJ2UCxFQUFFMEcsT0FBRixDQUFVbkwsVUFBVixHQUFxQixJQUFJelcsTUFBSixDQUFXK2YsRUFBRSxZQUFGLENBQVgsQ0FBckIsRUFBaUQ3RSxFQUFFMEcsT0FBRixDQUFVbkwsVUFBVixDQUFxQnZkLEdBQXJCLEdBQXlCckIsRUFBRTRlLFVBQUYsQ0FBYXZkLEdBQWIsQ0FBaUJnaUIsRUFBRTBHLE9BQUYsQ0FBVW5MLFVBQTNCLENBQS9GLEdBQXVJa04sRUFBRStHLGFBQUYsT0FBb0J4UCxFQUFFMEcsT0FBRixDQUFVdGMsU0FBVixHQUFvQixJQUFJdEYsTUFBSixDQUFXK2YsRUFBRSxXQUFGLENBQVgsQ0FBcEIsRUFBK0M3RSxFQUFFMEcsT0FBRixDQUFVdGMsU0FBVixDQUFvQnBNLEdBQXBCLEdBQXdCckIsRUFBRXlOLFNBQUYsQ0FBWXBNLEdBQVosQ0FBZ0JnaUIsRUFBRTBHLE9BQUYsQ0FBVXRjLFNBQTFCLENBQTNGLENBQXZJLEVBQXdRcWUsRUFBRTRHLGFBQUYsT0FBb0JyUCxFQUFFMEcsT0FBRixDQUFVSSxTQUFWLEdBQW9CLElBQUloaUIsTUFBSixDQUFXK2YsRUFBRSxXQUFGLENBQVgsQ0FBcEIsRUFBK0M3RSxFQUFFMEcsT0FBRixDQUFVUSxXQUFWLEdBQXNCdUIsRUFBRTZHLGVBQUYsRUFBekYsQ0FBeFE7QUFBc1gsQ0FBaG5DLENBQWluQzF2QixPQUFPc3BCLEtBQVAsSUFBY3RwQixPQUFPa0MsTUFBdG9DLEVBQTZvQ2xDLE1BQTdvQyxFQUFvcEM5QixRQUFwcEMsQ0FEcnhTOzs7QUNMQSxJQUFJMnhCLFVBQVU3dkIsT0FBTzh1QixRQUFQLENBQWdCZ0IsTUFBOUI7QUFDQSxJQUFJQyxjQUFjQyxTQUFTRCxXQUEzQjtBQUNBO0FBQ0EsSUFBR0YsWUFBWSx1QkFBWixJQUF1Q0EsWUFBWSx1QkFBdEQsRUFBK0U7QUFDN0VBLFlBQVVBLFVBQVUsYUFBcEI7QUFDRCxDQUZELE1BRUs7QUFDSEEsWUFBVTd2QixPQUFPOHVCLFFBQVAsQ0FBZ0JnQixNQUExQjtBQUNEO0NDUEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0NDaklBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7OztBQzlCQXgyQixFQUFFLE9BQUYsRUFBVzIyQixTQUFYLENBQ0E7QUFDR0MsYUFBVSxrQkFBU0MsS0FBVCxFQUNWO0FBQ0csVUFBSUMsT0FBT0QsTUFBTSxDQUFOLENBQVg7QUFDQSxVQUFJdkksS0FBS3VJLE1BQU0sQ0FBTixDQUFUO0FBQ0E7QUFDRjtBQU5KLENBREE7OztBQ0FBOztBQUVFOztBQUVGNzJCLEVBQUUrMkIsT0FBRixDQUFXTixjQUFZLDZCQUF2QixFQUFzRCxVQUFVcDFCLElBQVYsRUFBaUI7QUFDckVyQixJQUFFLG1CQUFGLEVBQXVCdU4sRUFBdkIsQ0FBMEIsT0FBMUIsRUFBbUMsWUFBVTs7QUFFM0MsUUFBSXlwQixnQkFBZ0JoM0IsRUFBRSxJQUFGLEVBQVEyUSxHQUFSLEVBQXBCO0FBQ0EsUUFBSXNtQixTQUFTLEVBQWI7QUFDQTs7QUFFQSxRQUFJQyxRQUFRLEVBQVo7QUFDQSxRQUFJQyxlQUFlLEVBQW5CO0FBQ0EsUUFBSUMsa0JBQWtCLEVBQXRCO0FBQ0EsUUFBSUMsU0FBUyxFQUFiO0FBQ0EsUUFBSUMsZ0JBQWdCLEVBQXBCO0FBQ0EsUUFBSUMsUUFBUWwyQixLQUFLazJCLEtBQWpCO0FBQ0EsUUFBSUMsc0JBQXNCLEVBQTFCO0FBQ0E7QUFDQSxTQUFLLElBQUkvekIsSUFBSSxDQUFiLEVBQWdCQSxJQUFJOHpCLE1BQU14MEIsTUFBMUIsRUFBa0NVLEdBQWxDLEVBQXVDO0FBQ3JDeXpCLGNBQVFLLE1BQU05ekIsQ0FBTixFQUFTeXpCLEtBQVQsQ0FBZWoyQixXQUFmLEVBQVI7QUFDQW0yQix3QkFBa0JHLE1BQU05ekIsQ0FBTixFQUFTZzBCLFdBQVQsQ0FBcUJ4MkIsV0FBckIsRUFBbEI7QUFDQWsyQixxQkFBZUksTUFBTTl6QixDQUFOLEVBQVNpMEIsa0JBQVQsQ0FBNEIsQ0FBNUIsQ0FBZjtBQUNBSixzQkFBZ0JDLE1BQU05ekIsQ0FBTixFQUFTaTBCLGtCQUF6QjtBQUNBTCxlQUFTRSxNQUFNOXpCLENBQU4sRUFBUzR6QixNQUFULENBQWdCcDJCLFdBQWhCLEVBQVQ7QUFDQSxVQUFJMDJCLGdCQUFnQixFQUFwQjtBQUNBQyx1QkFBaUJDLFNBQWpCLEdBQTZCLEVBQTdCOztBQUVBLFVBQUlDLGlCQUFrQlosTUFBTWEsUUFBTixDQUFlZixjQUFjLzFCLFdBQWQsRUFBZixLQUNsQm0yQixnQkFBZ0JXLFFBQWhCLENBQXlCZixjQUFjLzFCLFdBQWQsRUFBekIsQ0FEa0I7QUFFbEI7QUFDQW8yQixhQUFPVSxRQUFQLENBQWdCZixjQUFjLzFCLFdBQWQsRUFBaEIsQ0FISjs7QUFLQSxVQUFJNjJCLGtCQUFrQixDQUFDZCxjQUFjajBCLE1BQWYsR0FBd0IsQ0FBOUMsRUFDQTtBQUNFO0FBQ0E2MEIseUJBQWlCSSxTQUFqQixDQUEyQm5kLEdBQTNCLENBQStCLGNBQS9CO0FBQ0FvYyxlQUFPMTFCLElBQVAsQ0FBWWcyQixNQUFNOXpCLENBQU4sQ0FBWjtBQUNBazBCLHdCQUFnQlYsT0FBT25xQixNQUFQLENBQWMsVUFBU3NpQixJQUFULEVBQWU2SSxHQUFmLEVBQW1CO0FBQy9DLGlCQUFPaEIsT0FBT3YxQixPQUFQLENBQWUwdEIsSUFBZixLQUF3QjZJLEdBQS9CO0FBQ0QsU0FGZSxDQUFoQjs7QUFJQSxZQUFJQyxjQUFjLEVBQWxCO0FBQ0EsWUFBSUMsaUJBQWlCLEVBQXJCO0FBQ0EsWUFBSUMsZ0JBQWdCLEVBQXBCO0FBQ0E7QUFDQSxhQUFLLElBQUk3SSxJQUFJLENBQWIsRUFBZ0JBLElBQUlvSSxjQUFjNTBCLE1BQWxDLEVBQTBDd3NCLEdBQTFDLEVBQStDO0FBQzdDO0FBQ0EySSx3QkFBY1AsY0FBY3BJLENBQWQsRUFBaUIySCxLQUEvQjtBQUNBaUIsMkJBQWlCUixjQUFjcEksQ0FBZCxFQUFpQjhILE1BQWxDO0FBQ0FlLDJCQUFpQiwwQ0FBd0NULGNBQWNwSSxDQUFkLEVBQWlCMWYsRUFBekQsR0FBNEQsMENBQTVELEdBQXVHcW9CLFdBQXZHLEdBQW1ILGdEQUFuSCxHQUFvS0MsZUFBZXh2QixPQUFmLENBQXVCLElBQXZCLEVBQTZCLEdBQTdCLENBQXBLLEdBQXNNLGVBQXZOO0FBQ0Q7QUFDRGl2Qix5QkFBaUJDLFNBQWpCLEdBQTZCTyxhQUE3QjtBQUVELE9BckJELE1Bc0JLO0FBQ0h2MUIsZ0JBQVF3MUIsR0FBUixDQUFZckIsY0FBY2owQixNQUExQjtBQUNBNjBCLHlCQUFpQkksU0FBakIsQ0FBMkI5WixNQUEzQixDQUFrQyxjQUFsQztBQUNBMFoseUJBQWlCQyxTQUFqQixHQUE2QixFQUE3QjtBQUNEOztBQUdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQUVEOzs7QUFHQTtBQUNBaDFCLFlBQVF3MUIsR0FBUixDQUFZVixhQUFaO0FBQ0QsR0FsRkQ7QUFtRkQsQ0FwRkQ7O0FBc0ZBLFNBQVNXLFlBQVQsQ0FBc0JwdkIsTUFBdEIsRUFBOEJxdkIsS0FBOUIsRUFBcUM7QUFDbkMsTUFBSUMsT0FBT0QsTUFBTW51QixVQUFqQjtBQUNBLFNBQU9vdUIsUUFBUSxJQUFmLEVBQXFCO0FBQ25CLFFBQUlBLFFBQVF0dkIsTUFBWixFQUFvQjtBQUNsQixhQUFPLElBQVA7QUFDRDtBQUNEc3ZCLFdBQU9BLEtBQUtwdUIsVUFBWjtBQUNEO0FBQ0QsU0FBTyxLQUFQO0FBQ0Q7QUFDRCxJQUFJcXVCLFNBQVMsQ0FBYjtBQUNBN3pCLFNBQVM0USxnQkFBVCxDQUEwQixPQUExQixFQUFtQyxVQUFTdFIsQ0FBVCxFQUFXO0FBQzVDLE1BQUl3MEIsY0FBWSxFQUFoQjtBQUNBLE1BQUlDLGdCQUFnQixFQUFwQjtBQUNBLE1BQUd6MEIsRUFBRXNKLE1BQUYsQ0FBU3dxQixTQUFULENBQW1CcGIsUUFBbkIsQ0FBNEIsWUFBNUIsQ0FBSCxFQUE2QztBQUMzQztBQUNBOGIsa0JBQWN4MEIsRUFBRXNKLE1BQUYsQ0FBU3dGLFFBQVQsQ0FBa0IsQ0FBbEIsRUFBcUI2a0IsU0FBbkM7QUFDQWUscUJBQWlCaHFCLEtBQWpCLEdBQXlCOHBCLFdBQXpCO0FBQ0FkLHFCQUFpQkksU0FBakIsQ0FBMkI5WixNQUEzQixDQUFrQyxjQUFsQztBQUVEO0FBQ0QsTUFBR2hhLEVBQUVzSixNQUFGLENBQVN3cUIsU0FBVCxDQUFtQnBiLFFBQW5CLENBQTRCLGVBQTVCLENBQUgsRUFBZ0Q7QUFDOUM7QUFDQThiLGtCQUFjeDBCLEVBQUVzSixNQUFGLENBQVNxckIsc0JBQVQsQ0FBZ0NoQixTQUE5QztBQUNBO0FBQ0FlLHFCQUFpQmhxQixLQUFqQixHQUF5QjhwQixXQUF6QjtBQUNBZCxxQkFBaUJJLFNBQWpCLENBQTJCOVosTUFBM0IsQ0FBa0MsY0FBbEM7QUFDRDtBQUNELE1BQUdoYSxFQUFFc0osTUFBRixDQUFTd3FCLFNBQVQsQ0FBbUJwYixRQUFuQixDQUE0QixjQUE1QixDQUFILEVBQStDO0FBQzdDO0FBQ0E4YixrQkFBY3gwQixFQUFFc0osTUFBRixDQUFTcXFCLFNBQXZCO0FBQ0FlLHFCQUFpQmhxQixLQUFqQixHQUF5QjhwQixXQUF6QjtBQUNBZCxxQkFBaUJJLFNBQWpCLENBQTJCOVosTUFBM0IsQ0FBa0MsY0FBbEM7QUFDRDtBQUNEO0FBQ0EsTUFBSWhhLEVBQUVzSixNQUFGLENBQVN3cUIsU0FBVCxDQUFtQnBiLFFBQW5CLENBQTRCLFlBQTVCLENBQUosRUFBK0M7QUFDN0M7QUFDQSxRQUFJa2MsV0FBVzUwQixFQUFFc0osTUFBRixDQUFTdXJCLGFBQVQsQ0FBdUJDLFlBQXZCLENBQW9DLGFBQXBDLENBQWY7QUFDQTtBQUNBQyxjQUFVcnFCLEtBQVYsR0FBa0JrcUIsUUFBbEI7QUFDQTtBQUNEO0FBQ0Q7QUFDQSxNQUFJNTBCLEVBQUVzSixNQUFGLENBQVNxQyxFQUFULElBQWUsU0FBbkIsRUFBOEI7QUFDNUI7QUFDRXFwQixxQkFBaUJsQixTQUFqQixDQUEyQm5kLEdBQTNCLENBQStCLFNBQS9CO0FBQ0g7QUFDRCxNQUFHM1csRUFBRXNKLE1BQUYsQ0FBU3dxQixTQUFULENBQW1CcGIsUUFBbkIsQ0FBNEIsZUFBNUIsQ0FBSCxFQUFrRDtBQUNoRHNjLHFCQUFpQmxCLFNBQWpCLENBQTJCOVosTUFBM0IsQ0FBa0MsU0FBbEM7QUFDRDs7QUFFRjtBQUNDLE1BQUlpYixrQkFBa0J2MEIsU0FBU3cwQixhQUFULENBQXVCLFVBQXZCLENBQXRCO0FBQ0EsTUFBR0QsZUFBSCxFQUNBO0FBQ0UsUUFBSUUsZUFBZUYsZ0JBQWdCdmMsUUFBaEIsQ0FBeUIxWSxFQUFFc0osTUFBM0IsS0FBc0M4cUIsYUFBYVksZ0JBQWIsRUFBK0JoMUIsRUFBRXNKLE1BQWpDLENBQXpEO0FBQ0EsUUFBSSxDQUFDNnJCLFlBQUQsSUFBaUJILGlCQUFpQmxCLFNBQWpCLENBQTJCcGIsUUFBM0IsQ0FBb0MsU0FBcEMsQ0FBckIsRUFBb0U7QUFDbkVzYyx1QkFBaUJsQixTQUFqQixDQUEyQmplLE1BQTNCLENBQWtDLFNBQWxDO0FBQ0E7QUFDRjtBQUNELE1BQUl1ZixhQUFhLEVBQWpCO0FBQ0EsTUFBR3AxQixFQUFFc0osTUFBRixDQUFTd3FCLFNBQVQsQ0FBbUJwYixRQUFuQixDQUE0QixTQUE1QixDQUFILEVBQTJDO0FBQ3pDMGMsaUJBQWFwMUIsRUFBRXNKLE1BQUYsQ0FBU3BELFVBQVQsQ0FBb0JBLFVBQXBCLENBQStCNEksUUFBL0IsQ0FBd0MsQ0FBeEMsRUFBMkNBLFFBQTNDLENBQW9ELENBQXBELENBQWI7QUFDQXlsQixhQUFTN0wsT0FBTzBNLFdBQVcxcUIsS0FBbEIsSUFBMEIsQ0FBbkM7QUFDQSxRQUFJZ2UsT0FBTzBNLFdBQVcxcUIsS0FBbEIsSUFBMkIsQ0FBL0IsRUFBa0M7QUFDaEMwcUIsaUJBQVcxcUIsS0FBWCxHQUFtQjZwQixNQUFuQjtBQUNEO0FBRUY7QUFDRCxNQUFHdjBCLEVBQUVzSixNQUFGLENBQVN3cUIsU0FBVCxDQUFtQnBiLFFBQW5CLENBQTRCLFVBQTVCLENBQUgsRUFBNEM7QUFDMUMwYyxpQkFBYXAxQixFQUFFc0osTUFBRixDQUFTcEQsVUFBVCxDQUFvQkEsVUFBcEIsQ0FBK0I0SSxRQUEvQixDQUF3QyxDQUF4QyxFQUEyQ0EsUUFBM0MsQ0FBb0QsQ0FBcEQsQ0FBYjtBQUNBeWxCLGFBQVM3TCxPQUFPME0sV0FBVzFxQixLQUFsQixJQUEwQixDQUFuQztBQUNBLFFBQUdnZSxPQUFPME0sV0FBVzFxQixLQUFsQixJQUEyQixDQUE5QixFQUFrQztBQUNoQzBxQixpQkFBVzFxQixLQUFYLEdBQW1CNnBCLE1BQW5CO0FBQ0Q7QUFDRjtBQUNGLENBakVEOztBQW1FQXo0QixFQUFFLG1CQUFGLEVBQXVCdTVCLEtBQXZCLENBQTZCLFlBQVU7QUFDckN2NUIsSUFBRXc1QixJQUFGLENBQU8vQyxjQUFZLG1DQUFuQixFQUF3RHoyQixFQUFHLFdBQUgsRUFBaUJ5NUIsU0FBakIsRUFBeEQsRUFBc0YsVUFBU3A0QixJQUFULEVBQWM7QUFDbEd3QixZQUFRdzFCLEdBQVIsQ0FBWWgzQixJQUFaO0FBQ0QsR0FGRDtBQUdELENBSkQ7OztBQ3pLQXVILE9BQU9oRSxRQUFQLEVBQWlCbkMsVUFBakI7OztBQ0FBO0FBQ0F6QyxFQUFFLFdBQUYsRUFBZXVOLEVBQWYsQ0FBa0IsT0FBbEIsRUFBMkIsWUFBVztBQUNwQ3ZOLElBQUU0RSxRQUFGLEVBQVluQyxVQUFaLENBQXVCLFNBQXZCLEVBQWlDLE9BQWpDO0FBQ0QsQ0FGRDs7O0FDREEsU0FBU2kzQixNQUFULENBQWdCbHVCLEtBQWhCLEVBQXVCO0FBQ3JCO0FBQ0Fra0IsTUFBSXB1QixPQUFKLENBQVksc0JBQVo7QUFDRDtBQUNELElBQUdvRixPQUFPZ29CLFVBQVAsSUFBcUIsSUFBeEIsRUFBNkI7QUFDM0IsTUFBSWdCLE1BQU0xdkIsRUFBRSxRQUFGLENBQVY7QUFDQTB2QixNQUFJSSxXQUFKLENBQWdCO0FBQ2Q2RSxVQUFNLEtBRFE7QUFFZDNLLGdCQUFXO0FBQ1AsU0FBRTtBQUNBdFgsZUFBTSxDQUROO0FBRUF3aEIsYUFBSSxLQUZKO0FBR0FsTCxjQUFNLElBSE47QUFJQVEsc0JBQWMsRUFKZDtBQUtBbUwsY0FBTTtBQUxOLE9BREs7QUFRUCxXQUFJO0FBQ0ZqaUIsZUFBTSxDQURKO0FBRUZ3aEIsYUFBSSxLQUZGO0FBR0ZsTCxjQUFNLElBSEo7QUFJRlEsc0JBQWMsRUFKWjtBQUtGbUwsY0FBTTtBQUxKLE9BUkc7QUFlUCxZQUFLO0FBQ0hqaUIsZUFBTSxDQURIO0FBRUh3aEIsYUFBSSxLQUZEO0FBR0hsTCxjQUFNLElBSEg7QUFJSFEsc0JBQWMsRUFKWDtBQUtIbUwsY0FBTSxLQUxIO0FBTUhySCxrQkFBVW9NO0FBTlA7QUFmRTtBQUZHLEdBQWhCO0FBNEJEOztBQUVELElBQUlDLFVBQVUzNUIsRUFBRSxZQUFGLENBQWQ7QUFDQTI1QixRQUFRN0osV0FBUixDQUFvQjtBQUNsQnBkLFNBQU0sQ0FEWTtBQUVsQndoQixPQUFJLEtBRmM7QUFHbEJsTCxRQUFNLElBSFk7QUFJbEJRLGdCQUFjLEVBSkk7QUFLbEJtTCxRQUFNLEtBTFk7QUFNbEJ6QixZQUFVLElBTlE7O0FBUWxCbEosY0FBVztBQUNQLE9BQUU7QUFDQXRYLGFBQU0sQ0FETjtBQUVBd2hCLFdBQUksS0FGSjtBQUdBbEwsWUFBTSxJQUhOO0FBSUFRLG9CQUFjLEVBSmQ7QUFLQW1MLFlBQU07QUFMTixLQURLO0FBUVAsU0FBSTtBQUNGamlCLGFBQU0sQ0FESjtBQUVGd2hCLFdBQUksS0FGRjtBQUdGbEwsWUFBTSxJQUhKO0FBSUZRLG9CQUFjLEVBSlo7QUFLRm1MLFlBQU07QUFMSixLQVJHO0FBZVAsVUFBSztBQUNIamlCLGFBQU0sQ0FESDtBQUVId2hCLFdBQUksS0FGRDtBQUdIbEwsWUFBTSxJQUhIO0FBSUhRLG9CQUFjLEVBSlg7QUFLSG1MLFlBQU07QUFDTjtBQU5HLEtBZkU7QUF1QlAsVUFBSztBQUNIamlCLGFBQU0sQ0FESDtBQUVId2hCLFdBQUksS0FGRDtBQUdIbEwsWUFBTSxJQUhIO0FBSUhRLG9CQUFjLEVBSlg7QUFLSG1MLFlBQU07QUFDTjtBQU5HO0FBdkJFO0FBUk8sQ0FBcEI7O0FBOENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0NDekZBOzs7QUNBQTMwQixFQUFFNEUsUUFBRixFQUFZZzFCLEtBQVosQ0FBa0IsWUFBWTtBQUMxQixRQUFJQyxTQUFTNzVCLEVBQUUsc0RBQUYsQ0FBYjs7QUFFQTY1QixXQUFPNTNCLElBQVAsQ0FBWSxZQUFZO0FBQ3BCLFlBQUlvQyxLQUFLckUsRUFBRSxJQUFGLENBQVQ7QUFDQXFFLFdBQUd1WCxJQUFILENBQVEsNENBQVI7QUFDSCxLQUhEO0FBSUgsQ0FQRDs7O0FDQUEsSUFBSWtlLFdBQVcsU0FBWEEsUUFBVyxDQUFTQyxTQUFULEVBQW9CQyxRQUFwQixFQUE4QkMsTUFBOUIsRUFBc0M7QUFDbkQsS0FBSXJlLE9BQU81YixFQUFFKzVCLFNBQUYsQ0FBWDtBQUNBLzVCLEdBQUUwRyxNQUFGLEVBQVV3ekIsTUFBVixDQUFpQixZQUFVO0FBQzFCLE1BQUlsNkIsRUFBRTRFLFFBQUYsRUFBWW1ZLFNBQVosS0FBMEJrZCxNQUE5QixFQUFzQztBQUNyQ3JlLFFBQUs1SixRQUFMLENBQWNnb0IsUUFBZDtBQUNBLEdBRkQsTUFFTztBQUNMcGUsUUFBSzNWLFdBQUwsQ0FBaUIrekIsUUFBakI7QUFDRDtBQUNELEVBTkQ7QUFPQSxDQVRGOztBQVdBRixTQUFTLHFCQUFULEVBQStCLGtCQUEvQixFQUFtRCxDQUFuRDs7QUFFQTk1QixFQUFFLE9BQUYsRUFBV3U1QixLQUFYLENBQWlCLFlBQVU7QUFDMUJ2NUIsR0FBRSxTQUFGLEVBQWFzbEIsV0FBYixDQUF5QixNQUF6QjtBQUNBdGxCLEdBQUUsTUFBRixFQUFVc2xCLFdBQVYsQ0FBc0IsZ0JBQXRCO0FBQ0E7QUFDQTtBQUNBLENBTEQ7O0FBT0F0bEIsRUFBRSw4QkFBRixFQUFrQ3U1QixLQUFsQyxDQUF3QyxZQUFVO0FBQ2pEO0FBQ0EsQ0FGRDs7QUFJQXY1QixFQUFFLDZCQUFGLEVBQWlDbTZCLFNBQWpDLENBQTJDLFlBQVU7QUFDcERuNkIsR0FBRSxZQUFGLEVBQWdCc2xCLFdBQWhCLENBQTRCLGdCQUE1QjtBQUNBLENBRkQ7O0FBSUF0bEIsRUFBRSxlQUFGLEVBQW1CdU4sRUFBbkIsQ0FBc0IsT0FBdEIsRUFBK0IsWUFBVTtBQUN4Q3ZOLEdBQUUsY0FBRixFQUFrQmdTLFFBQWxCLENBQTJCLGlCQUEzQjtBQUNBaFMsR0FBRSxNQUFGLEVBQVVnUyxRQUFWLENBQW1CLGdCQUFuQjtBQUNBLENBSEQ7O0FBS0FoUyxFQUFFLG1CQUFGLEVBQXVCdU4sRUFBdkIsQ0FBMEIsT0FBMUIsRUFBbUMsWUFBVTtBQUM1Q3ZOLEdBQUUsY0FBRixFQUFrQmlHLFdBQWxCLENBQThCLGlCQUE5QjtBQUNBakcsR0FBRSxNQUFGLEVBQVVpRyxXQUFWLENBQXNCLGdCQUF0QjtBQUNBLENBSEQ7OztBQ2hDQWpHLEVBQUUwRyxNQUFGLEVBQVVvQixJQUFWLENBQWUsaUNBQWYsRUFBa0QsWUFBWTtBQUMzRCxNQUFJc3lCLFNBQVNwNkIsRUFBRSxtQkFBRixDQUFiO0FBQ0EsTUFBSWk0QixNQUFNbUMsT0FBT3Z2QixRQUFQLEVBQVY7QUFDQSxNQUFJakIsU0FBUzVKLEVBQUUwRyxNQUFGLEVBQVVrRCxNQUFWLEVBQWI7QUFDQUEsV0FBU0EsU0FBU3F1QixJQUFJM3VCLEdBQXRCO0FBQ0FNLFdBQVNBLFNBQVN3d0IsT0FBT3h3QixNQUFQLEVBQVQsR0FBMEIsQ0FBbkM7O0FBRUEsV0FBU3l3QixZQUFULEdBQXdCO0FBQ3RCRCxXQUFPNXJCLEdBQVAsQ0FBVztBQUNQLG9CQUFjNUUsU0FBUztBQURoQixLQUFYO0FBR0Q7O0FBRUQsTUFBSUEsU0FBUyxDQUFiLEVBQWdCO0FBQ2R5d0I7QUFDRDtBQUNILENBaEJEIiwiZmlsZSI6ImZvdW5kYXRpb24uanMiLCJzb3VyY2VzQ29udGVudCI6WyIhZnVuY3Rpb24oJCkge1xuXG5cInVzZSBzdHJpY3RcIjtcblxudmFyIEZPVU5EQVRJT05fVkVSU0lPTiA9ICc2LjMuMCc7XG5cbi8vIEdsb2JhbCBGb3VuZGF0aW9uIG9iamVjdFxuLy8gVGhpcyBpcyBhdHRhY2hlZCB0byB0aGUgd2luZG93LCBvciB1c2VkIGFzIGEgbW9kdWxlIGZvciBBTUQvQnJvd3NlcmlmeVxudmFyIEZvdW5kYXRpb24gPSB7XG4gIHZlcnNpb246IEZPVU5EQVRJT05fVkVSU0lPTixcblxuICAvKipcbiAgICogU3RvcmVzIGluaXRpYWxpemVkIHBsdWdpbnMuXG4gICAqL1xuICBfcGx1Z2luczoge30sXG5cbiAgLyoqXG4gICAqIFN0b3JlcyBnZW5lcmF0ZWQgdW5pcXVlIGlkcyBmb3IgcGx1Z2luIGluc3RhbmNlc1xuICAgKi9cbiAgX3V1aWRzOiBbXSxcblxuICAvKipcbiAgICogUmV0dXJucyBhIGJvb2xlYW4gZm9yIFJUTCBzdXBwb3J0XG4gICAqL1xuICBydGw6IGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuICQoJ2h0bWwnKS5hdHRyKCdkaXInKSA9PT0gJ3J0bCc7XG4gIH0sXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgRm91bmRhdGlvbiBwbHVnaW4sIGFkZGluZyBpdCB0byB0aGUgYEZvdW5kYXRpb25gIG5hbWVzcGFjZSBhbmQgdGhlIGxpc3Qgb2YgcGx1Z2lucyB0byBpbml0aWFsaXplIHdoZW4gcmVmbG93aW5nLlxuICAgKiBAcGFyYW0ge09iamVjdH0gcGx1Z2luIC0gVGhlIGNvbnN0cnVjdG9yIG9mIHRoZSBwbHVnaW4uXG4gICAqL1xuICBwbHVnaW46IGZ1bmN0aW9uKHBsdWdpbiwgbmFtZSkge1xuICAgIC8vIE9iamVjdCBrZXkgdG8gdXNlIHdoZW4gYWRkaW5nIHRvIGdsb2JhbCBGb3VuZGF0aW9uIG9iamVjdFxuICAgIC8vIEV4YW1wbGVzOiBGb3VuZGF0aW9uLlJldmVhbCwgRm91bmRhdGlvbi5PZmZDYW52YXNcbiAgICB2YXIgY2xhc3NOYW1lID0gKG5hbWUgfHwgZnVuY3Rpb25OYW1lKHBsdWdpbikpO1xuICAgIC8vIE9iamVjdCBrZXkgdG8gdXNlIHdoZW4gc3RvcmluZyB0aGUgcGx1Z2luLCBhbHNvIHVzZWQgdG8gY3JlYXRlIHRoZSBpZGVudGlmeWluZyBkYXRhIGF0dHJpYnV0ZSBmb3IgdGhlIHBsdWdpblxuICAgIC8vIEV4YW1wbGVzOiBkYXRhLXJldmVhbCwgZGF0YS1vZmYtY2FudmFzXG4gICAgdmFyIGF0dHJOYW1lICA9IGh5cGhlbmF0ZShjbGFzc05hbWUpO1xuXG4gICAgLy8gQWRkIHRvIHRoZSBGb3VuZGF0aW9uIG9iamVjdCBhbmQgdGhlIHBsdWdpbnMgbGlzdCAoZm9yIHJlZmxvd2luZylcbiAgICB0aGlzLl9wbHVnaW5zW2F0dHJOYW1lXSA9IHRoaXNbY2xhc3NOYW1lXSA9IHBsdWdpbjtcbiAgfSxcbiAgLyoqXG4gICAqIEBmdW5jdGlvblxuICAgKiBQb3B1bGF0ZXMgdGhlIF91dWlkcyBhcnJheSB3aXRoIHBvaW50ZXJzIHRvIGVhY2ggaW5kaXZpZHVhbCBwbHVnaW4gaW5zdGFuY2UuXG4gICAqIEFkZHMgdGhlIGB6ZlBsdWdpbmAgZGF0YS1hdHRyaWJ1dGUgdG8gcHJvZ3JhbW1hdGljYWxseSBjcmVhdGVkIHBsdWdpbnMgdG8gYWxsb3cgdXNlIG9mICQoc2VsZWN0b3IpLmZvdW5kYXRpb24obWV0aG9kKSBjYWxscy5cbiAgICogQWxzbyBmaXJlcyB0aGUgaW5pdGlhbGl6YXRpb24gZXZlbnQgZm9yIGVhY2ggcGx1Z2luLCBjb25zb2xpZGF0aW5nIHJlcGV0aXRpdmUgY29kZS5cbiAgICogQHBhcmFtIHtPYmplY3R9IHBsdWdpbiAtIGFuIGluc3RhbmNlIG9mIGEgcGx1Z2luLCB1c3VhbGx5IGB0aGlzYCBpbiBjb250ZXh0LlxuICAgKiBAcGFyYW0ge1N0cmluZ30gbmFtZSAtIHRoZSBuYW1lIG9mIHRoZSBwbHVnaW4sIHBhc3NlZCBhcyBhIGNhbWVsQ2FzZWQgc3RyaW5nLlxuICAgKiBAZmlyZXMgUGx1Z2luI2luaXRcbiAgICovXG4gIHJlZ2lzdGVyUGx1Z2luOiBmdW5jdGlvbihwbHVnaW4sIG5hbWUpe1xuICAgIHZhciBwbHVnaW5OYW1lID0gbmFtZSA/IGh5cGhlbmF0ZShuYW1lKSA6IGZ1bmN0aW9uTmFtZShwbHVnaW4uY29uc3RydWN0b3IpLnRvTG93ZXJDYXNlKCk7XG4gICAgcGx1Z2luLnV1aWQgPSB0aGlzLkdldFlvRGlnaXRzKDYsIHBsdWdpbk5hbWUpO1xuXG4gICAgaWYoIXBsdWdpbi4kZWxlbWVudC5hdHRyKGBkYXRhLSR7cGx1Z2luTmFtZX1gKSl7IHBsdWdpbi4kZWxlbWVudC5hdHRyKGBkYXRhLSR7cGx1Z2luTmFtZX1gLCBwbHVnaW4udXVpZCk7IH1cbiAgICBpZighcGx1Z2luLiRlbGVtZW50LmRhdGEoJ3pmUGx1Z2luJykpeyBwbHVnaW4uJGVsZW1lbnQuZGF0YSgnemZQbHVnaW4nLCBwbHVnaW4pOyB9XG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogRmlyZXMgd2hlbiB0aGUgcGx1Z2luIGhhcyBpbml0aWFsaXplZC5cbiAgICAgICAgICAgKiBAZXZlbnQgUGx1Z2luI2luaXRcbiAgICAgICAgICAgKi9cbiAgICBwbHVnaW4uJGVsZW1lbnQudHJpZ2dlcihgaW5pdC56Zi4ke3BsdWdpbk5hbWV9YCk7XG5cbiAgICB0aGlzLl91dWlkcy5wdXNoKHBsdWdpbi51dWlkKTtcblxuICAgIHJldHVybjtcbiAgfSxcbiAgLyoqXG4gICAqIEBmdW5jdGlvblxuICAgKiBSZW1vdmVzIHRoZSBwbHVnaW5zIHV1aWQgZnJvbSB0aGUgX3V1aWRzIGFycmF5LlxuICAgKiBSZW1vdmVzIHRoZSB6ZlBsdWdpbiBkYXRhIGF0dHJpYnV0ZSwgYXMgd2VsbCBhcyB0aGUgZGF0YS1wbHVnaW4tbmFtZSBhdHRyaWJ1dGUuXG4gICAqIEFsc28gZmlyZXMgdGhlIGRlc3Ryb3llZCBldmVudCBmb3IgdGhlIHBsdWdpbiwgY29uc29saWRhdGluZyByZXBldGl0aXZlIGNvZGUuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBwbHVnaW4gLSBhbiBpbnN0YW5jZSBvZiBhIHBsdWdpbiwgdXN1YWxseSBgdGhpc2AgaW4gY29udGV4dC5cbiAgICogQGZpcmVzIFBsdWdpbiNkZXN0cm95ZWRcbiAgICovXG4gIHVucmVnaXN0ZXJQbHVnaW46IGZ1bmN0aW9uKHBsdWdpbil7XG4gICAgdmFyIHBsdWdpbk5hbWUgPSBoeXBoZW5hdGUoZnVuY3Rpb25OYW1lKHBsdWdpbi4kZWxlbWVudC5kYXRhKCd6ZlBsdWdpbicpLmNvbnN0cnVjdG9yKSk7XG5cbiAgICB0aGlzLl91dWlkcy5zcGxpY2UodGhpcy5fdXVpZHMuaW5kZXhPZihwbHVnaW4udXVpZCksIDEpO1xuICAgIHBsdWdpbi4kZWxlbWVudC5yZW1vdmVBdHRyKGBkYXRhLSR7cGx1Z2luTmFtZX1gKS5yZW1vdmVEYXRhKCd6ZlBsdWdpbicpXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogRmlyZXMgd2hlbiB0aGUgcGx1Z2luIGhhcyBiZWVuIGRlc3Ryb3llZC5cbiAgICAgICAgICAgKiBAZXZlbnQgUGx1Z2luI2Rlc3Ryb3llZFxuICAgICAgICAgICAqL1xuICAgICAgICAgIC50cmlnZ2VyKGBkZXN0cm95ZWQuemYuJHtwbHVnaW5OYW1lfWApO1xuICAgIGZvcih2YXIgcHJvcCBpbiBwbHVnaW4pe1xuICAgICAgcGx1Z2luW3Byb3BdID0gbnVsbDsvL2NsZWFuIHVwIHNjcmlwdCB0byBwcmVwIGZvciBnYXJiYWdlIGNvbGxlY3Rpb24uXG4gICAgfVxuICAgIHJldHVybjtcbiAgfSxcblxuICAvKipcbiAgICogQGZ1bmN0aW9uXG4gICAqIENhdXNlcyBvbmUgb3IgbW9yZSBhY3RpdmUgcGx1Z2lucyB0byByZS1pbml0aWFsaXplLCByZXNldHRpbmcgZXZlbnQgbGlzdGVuZXJzLCByZWNhbGN1bGF0aW5nIHBvc2l0aW9ucywgZXRjLlxuICAgKiBAcGFyYW0ge1N0cmluZ30gcGx1Z2lucyAtIG9wdGlvbmFsIHN0cmluZyBvZiBhbiBpbmRpdmlkdWFsIHBsdWdpbiBrZXksIGF0dGFpbmVkIGJ5IGNhbGxpbmcgYCQoZWxlbWVudCkuZGF0YSgncGx1Z2luTmFtZScpYCwgb3Igc3RyaW5nIG9mIGEgcGx1Z2luIGNsYXNzIGkuZS4gYCdkcm9wZG93bidgXG4gICAqIEBkZWZhdWx0IElmIG5vIGFyZ3VtZW50IGlzIHBhc3NlZCwgcmVmbG93IGFsbCBjdXJyZW50bHkgYWN0aXZlIHBsdWdpbnMuXG4gICAqL1xuICAgcmVJbml0OiBmdW5jdGlvbihwbHVnaW5zKXtcbiAgICAgdmFyIGlzSlEgPSBwbHVnaW5zIGluc3RhbmNlb2YgJDtcbiAgICAgdHJ5e1xuICAgICAgIGlmKGlzSlEpe1xuICAgICAgICAgcGx1Z2lucy5lYWNoKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICQodGhpcykuZGF0YSgnemZQbHVnaW4nKS5faW5pdCgpO1xuICAgICAgICAgfSk7XG4gICAgICAgfWVsc2V7XG4gICAgICAgICB2YXIgdHlwZSA9IHR5cGVvZiBwbHVnaW5zLFxuICAgICAgICAgX3RoaXMgPSB0aGlzLFxuICAgICAgICAgZm5zID0ge1xuICAgICAgICAgICAnb2JqZWN0JzogZnVuY3Rpb24ocGxncyl7XG4gICAgICAgICAgICAgcGxncy5mb3JFYWNoKGZ1bmN0aW9uKHApe1xuICAgICAgICAgICAgICAgcCA9IGh5cGhlbmF0ZShwKTtcbiAgICAgICAgICAgICAgICQoJ1tkYXRhLScrIHAgKyddJykuZm91bmRhdGlvbignX2luaXQnKTtcbiAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgfSxcbiAgICAgICAgICAgJ3N0cmluZyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgcGx1Z2lucyA9IGh5cGhlbmF0ZShwbHVnaW5zKTtcbiAgICAgICAgICAgICAkKCdbZGF0YS0nKyBwbHVnaW5zICsnXScpLmZvdW5kYXRpb24oJ19pbml0Jyk7XG4gICAgICAgICAgIH0sXG4gICAgICAgICAgICd1bmRlZmluZWQnOiBmdW5jdGlvbigpe1xuICAgICAgICAgICAgIHRoaXNbJ29iamVjdCddKE9iamVjdC5rZXlzKF90aGlzLl9wbHVnaW5zKSk7XG4gICAgICAgICAgIH1cbiAgICAgICAgIH07XG4gICAgICAgICBmbnNbdHlwZV0ocGx1Z2lucyk7XG4gICAgICAgfVxuICAgICB9Y2F0Y2goZXJyKXtcbiAgICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgIH1maW5hbGx5e1xuICAgICAgIHJldHVybiBwbHVnaW5zO1xuICAgICB9XG4gICB9LFxuXG4gIC8qKlxuICAgKiByZXR1cm5zIGEgcmFuZG9tIGJhc2UtMzYgdWlkIHdpdGggbmFtZXNwYWNpbmdcbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBsZW5ndGggLSBudW1iZXIgb2YgcmFuZG9tIGJhc2UtMzYgZGlnaXRzIGRlc2lyZWQuIEluY3JlYXNlIGZvciBtb3JlIHJhbmRvbSBzdHJpbmdzLlxuICAgKiBAcGFyYW0ge1N0cmluZ30gbmFtZXNwYWNlIC0gbmFtZSBvZiBwbHVnaW4gdG8gYmUgaW5jb3Jwb3JhdGVkIGluIHVpZCwgb3B0aW9uYWwuXG4gICAqIEBkZWZhdWx0IHtTdHJpbmd9ICcnIC0gaWYgbm8gcGx1Z2luIG5hbWUgaXMgcHJvdmlkZWQsIG5vdGhpbmcgaXMgYXBwZW5kZWQgdG8gdGhlIHVpZC5cbiAgICogQHJldHVybnMge1N0cmluZ30gLSB1bmlxdWUgaWRcbiAgICovXG4gIEdldFlvRGlnaXRzOiBmdW5jdGlvbihsZW5ndGgsIG5hbWVzcGFjZSl7XG4gICAgbGVuZ3RoID0gbGVuZ3RoIHx8IDY7XG4gICAgcmV0dXJuIE1hdGgucm91bmQoKE1hdGgucG93KDM2LCBsZW5ndGggKyAxKSAtIE1hdGgucmFuZG9tKCkgKiBNYXRoLnBvdygzNiwgbGVuZ3RoKSkpLnRvU3RyaW5nKDM2KS5zbGljZSgxKSArIChuYW1lc3BhY2UgPyBgLSR7bmFtZXNwYWNlfWAgOiAnJyk7XG4gIH0sXG4gIC8qKlxuICAgKiBJbml0aWFsaXplIHBsdWdpbnMgb24gYW55IGVsZW1lbnRzIHdpdGhpbiBgZWxlbWAgKGFuZCBgZWxlbWAgaXRzZWxmKSB0aGF0IGFyZW4ndCBhbHJlYWR5IGluaXRpYWxpemVkLlxuICAgKiBAcGFyYW0ge09iamVjdH0gZWxlbSAtIGpRdWVyeSBvYmplY3QgY29udGFpbmluZyB0aGUgZWxlbWVudCB0byBjaGVjayBpbnNpZGUuIEFsc28gY2hlY2tzIHRoZSBlbGVtZW50IGl0c2VsZiwgdW5sZXNzIGl0J3MgdGhlIGBkb2N1bWVudGAgb2JqZWN0LlxuICAgKiBAcGFyYW0ge1N0cmluZ3xBcnJheX0gcGx1Z2lucyAtIEEgbGlzdCBvZiBwbHVnaW5zIHRvIGluaXRpYWxpemUuIExlYXZlIHRoaXMgb3V0IHRvIGluaXRpYWxpemUgZXZlcnl0aGluZy5cbiAgICovXG4gIHJlZmxvdzogZnVuY3Rpb24oZWxlbSwgcGx1Z2lucykge1xuXG4gICAgLy8gSWYgcGx1Z2lucyBpcyB1bmRlZmluZWQsIGp1c3QgZ3JhYiBldmVyeXRoaW5nXG4gICAgaWYgKHR5cGVvZiBwbHVnaW5zID09PSAndW5kZWZpbmVkJykge1xuICAgICAgcGx1Z2lucyA9IE9iamVjdC5rZXlzKHRoaXMuX3BsdWdpbnMpO1xuICAgIH1cbiAgICAvLyBJZiBwbHVnaW5zIGlzIGEgc3RyaW5nLCBjb252ZXJ0IGl0IHRvIGFuIGFycmF5IHdpdGggb25lIGl0ZW1cbiAgICBlbHNlIGlmICh0eXBlb2YgcGx1Z2lucyA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHBsdWdpbnMgPSBbcGx1Z2luc107XG4gICAgfVxuXG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIC8vIEl0ZXJhdGUgdGhyb3VnaCBlYWNoIHBsdWdpblxuICAgICQuZWFjaChwbHVnaW5zLCBmdW5jdGlvbihpLCBuYW1lKSB7XG4gICAgICAvLyBHZXQgdGhlIGN1cnJlbnQgcGx1Z2luXG4gICAgICB2YXIgcGx1Z2luID0gX3RoaXMuX3BsdWdpbnNbbmFtZV07XG5cbiAgICAgIC8vIExvY2FsaXplIHRoZSBzZWFyY2ggdG8gYWxsIGVsZW1lbnRzIGluc2lkZSBlbGVtLCBhcyB3ZWxsIGFzIGVsZW0gaXRzZWxmLCB1bmxlc3MgZWxlbSA9PT0gZG9jdW1lbnRcbiAgICAgIHZhciAkZWxlbSA9ICQoZWxlbSkuZmluZCgnW2RhdGEtJytuYW1lKyddJykuYWRkQmFjaygnW2RhdGEtJytuYW1lKyddJyk7XG5cbiAgICAgIC8vIEZvciBlYWNoIHBsdWdpbiBmb3VuZCwgaW5pdGlhbGl6ZSBpdFxuICAgICAgJGVsZW0uZWFjaChmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyICRlbCA9ICQodGhpcyksXG4gICAgICAgICAgICBvcHRzID0ge307XG4gICAgICAgIC8vIERvbid0IGRvdWJsZS1kaXAgb24gcGx1Z2luc1xuICAgICAgICBpZiAoJGVsLmRhdGEoJ3pmUGx1Z2luJykpIHtcbiAgICAgICAgICBjb25zb2xlLndhcm4oXCJUcmllZCB0byBpbml0aWFsaXplIFwiK25hbWUrXCIgb24gYW4gZWxlbWVudCB0aGF0IGFscmVhZHkgaGFzIGEgRm91bmRhdGlvbiBwbHVnaW4uXCIpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmKCRlbC5hdHRyKCdkYXRhLW9wdGlvbnMnKSl7XG4gICAgICAgICAgdmFyIHRoaW5nID0gJGVsLmF0dHIoJ2RhdGEtb3B0aW9ucycpLnNwbGl0KCc7JykuZm9yRWFjaChmdW5jdGlvbihlLCBpKXtcbiAgICAgICAgICAgIHZhciBvcHQgPSBlLnNwbGl0KCc6JykubWFwKGZ1bmN0aW9uKGVsKXsgcmV0dXJuIGVsLnRyaW0oKTsgfSk7XG4gICAgICAgICAgICBpZihvcHRbMF0pIG9wdHNbb3B0WzBdXSA9IHBhcnNlVmFsdWUob3B0WzFdKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICB0cnl7XG4gICAgICAgICAgJGVsLmRhdGEoJ3pmUGx1Z2luJywgbmV3IHBsdWdpbigkKHRoaXMpLCBvcHRzKSk7XG4gICAgICAgIH1jYXRjaChlcil7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihlcik7XG4gICAgICAgIH1maW5hbGx5e1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG4gIH0sXG4gIGdldEZuTmFtZTogZnVuY3Rpb25OYW1lLFxuICB0cmFuc2l0aW9uZW5kOiBmdW5jdGlvbigkZWxlbSl7XG4gICAgdmFyIHRyYW5zaXRpb25zID0ge1xuICAgICAgJ3RyYW5zaXRpb24nOiAndHJhbnNpdGlvbmVuZCcsXG4gICAgICAnV2Via2l0VHJhbnNpdGlvbic6ICd3ZWJraXRUcmFuc2l0aW9uRW5kJyxcbiAgICAgICdNb3pUcmFuc2l0aW9uJzogJ3RyYW5zaXRpb25lbmQnLFxuICAgICAgJ09UcmFuc2l0aW9uJzogJ290cmFuc2l0aW9uZW5kJ1xuICAgIH07XG4gICAgdmFyIGVsZW0gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKSxcbiAgICAgICAgZW5kO1xuXG4gICAgZm9yICh2YXIgdCBpbiB0cmFuc2l0aW9ucyl7XG4gICAgICBpZiAodHlwZW9mIGVsZW0uc3R5bGVbdF0gIT09ICd1bmRlZmluZWQnKXtcbiAgICAgICAgZW5kID0gdHJhbnNpdGlvbnNbdF07XG4gICAgICB9XG4gICAgfVxuICAgIGlmKGVuZCl7XG4gICAgICByZXR1cm4gZW5kO1xuICAgIH1lbHNle1xuICAgICAgZW5kID0gc2V0VGltZW91dChmdW5jdGlvbigpe1xuICAgICAgICAkZWxlbS50cmlnZ2VySGFuZGxlcigndHJhbnNpdGlvbmVuZCcsIFskZWxlbV0pO1xuICAgICAgfSwgMSk7XG4gICAgICByZXR1cm4gJ3RyYW5zaXRpb25lbmQnO1xuICAgIH1cbiAgfVxufTtcblxuRm91bmRhdGlvbi51dGlsID0ge1xuICAvKipcbiAgICogRnVuY3Rpb24gZm9yIGFwcGx5aW5nIGEgZGVib3VuY2UgZWZmZWN0IHRvIGEgZnVuY3Rpb24gY2FsbC5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGZ1bmMgLSBGdW5jdGlvbiB0byBiZSBjYWxsZWQgYXQgZW5kIG9mIHRpbWVvdXQuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBkZWxheSAtIFRpbWUgaW4gbXMgdG8gZGVsYXkgdGhlIGNhbGwgb2YgYGZ1bmNgLlxuICAgKiBAcmV0dXJucyBmdW5jdGlvblxuICAgKi9cbiAgdGhyb3R0bGU6IGZ1bmN0aW9uIChmdW5jLCBkZWxheSkge1xuICAgIHZhciB0aW1lciA9IG51bGw7XG5cbiAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIGNvbnRleHQgPSB0aGlzLCBhcmdzID0gYXJndW1lbnRzO1xuXG4gICAgICBpZiAodGltZXIgPT09IG51bGwpIHtcbiAgICAgICAgdGltZXIgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBmdW5jLmFwcGx5KGNvbnRleHQsIGFyZ3MpO1xuICAgICAgICAgIHRpbWVyID0gbnVsbDtcbiAgICAgICAgfSwgZGVsYXkpO1xuICAgICAgfVxuICAgIH07XG4gIH1cbn07XG5cbi8vIFRPRE86IGNvbnNpZGVyIG5vdCBtYWtpbmcgdGhpcyBhIGpRdWVyeSBmdW5jdGlvblxuLy8gVE9ETzogbmVlZCB3YXkgdG8gcmVmbG93IHZzLiByZS1pbml0aWFsaXplXG4vKipcbiAqIFRoZSBGb3VuZGF0aW9uIGpRdWVyeSBtZXRob2QuXG4gKiBAcGFyYW0ge1N0cmluZ3xBcnJheX0gbWV0aG9kIC0gQW4gYWN0aW9uIHRvIHBlcmZvcm0gb24gdGhlIGN1cnJlbnQgalF1ZXJ5IG9iamVjdC5cbiAqL1xudmFyIGZvdW5kYXRpb24gPSBmdW5jdGlvbihtZXRob2QpIHtcbiAgdmFyIHR5cGUgPSB0eXBlb2YgbWV0aG9kLFxuICAgICAgJG1ldGEgPSAkKCdtZXRhLmZvdW5kYXRpb24tbXEnKSxcbiAgICAgICRub0pTID0gJCgnLm5vLWpzJyk7XG5cbiAgaWYoISRtZXRhLmxlbmd0aCl7XG4gICAgJCgnPG1ldGEgY2xhc3M9XCJmb3VuZGF0aW9uLW1xXCI+JykuYXBwZW5kVG8oZG9jdW1lbnQuaGVhZCk7XG4gIH1cbiAgaWYoJG5vSlMubGVuZ3RoKXtcbiAgICAkbm9KUy5yZW1vdmVDbGFzcygnbm8tanMnKTtcbiAgfVxuXG4gIGlmKHR5cGUgPT09ICd1bmRlZmluZWQnKXsvL25lZWRzIHRvIGluaXRpYWxpemUgdGhlIEZvdW5kYXRpb24gb2JqZWN0LCBvciBhbiBpbmRpdmlkdWFsIHBsdWdpbi5cbiAgICBGb3VuZGF0aW9uLk1lZGlhUXVlcnkuX2luaXQoKTtcbiAgICBGb3VuZGF0aW9uLnJlZmxvdyh0aGlzKTtcbiAgfWVsc2UgaWYodHlwZSA9PT0gJ3N0cmluZycpey8vYW4gaW5kaXZpZHVhbCBtZXRob2QgdG8gaW52b2tlIG9uIGEgcGx1Z2luIG9yIGdyb3VwIG9mIHBsdWdpbnNcbiAgICB2YXIgYXJncyA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cywgMSk7Ly9jb2xsZWN0IGFsbCB0aGUgYXJndW1lbnRzLCBpZiBuZWNlc3NhcnlcbiAgICB2YXIgcGx1Z0NsYXNzID0gdGhpcy5kYXRhKCd6ZlBsdWdpbicpOy8vZGV0ZXJtaW5lIHRoZSBjbGFzcyBvZiBwbHVnaW5cblxuICAgIGlmKHBsdWdDbGFzcyAhPT0gdW5kZWZpbmVkICYmIHBsdWdDbGFzc1ttZXRob2RdICE9PSB1bmRlZmluZWQpey8vbWFrZSBzdXJlIGJvdGggdGhlIGNsYXNzIGFuZCBtZXRob2QgZXhpc3RcbiAgICAgIGlmKHRoaXMubGVuZ3RoID09PSAxKXsvL2lmIHRoZXJlJ3Mgb25seSBvbmUsIGNhbGwgaXQgZGlyZWN0bHkuXG4gICAgICAgICAgcGx1Z0NsYXNzW21ldGhvZF0uYXBwbHkocGx1Z0NsYXNzLCBhcmdzKTtcbiAgICAgIH1lbHNle1xuICAgICAgICB0aGlzLmVhY2goZnVuY3Rpb24oaSwgZWwpey8vb3RoZXJ3aXNlIGxvb3AgdGhyb3VnaCB0aGUgalF1ZXJ5IGNvbGxlY3Rpb24gYW5kIGludm9rZSB0aGUgbWV0aG9kIG9uIGVhY2hcbiAgICAgICAgICBwbHVnQ2xhc3NbbWV0aG9kXS5hcHBseSgkKGVsKS5kYXRhKCd6ZlBsdWdpbicpLCBhcmdzKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfWVsc2V7Ly9lcnJvciBmb3Igbm8gY2xhc3Mgb3Igbm8gbWV0aG9kXG4gICAgICB0aHJvdyBuZXcgUmVmZXJlbmNlRXJyb3IoXCJXZSdyZSBzb3JyeSwgJ1wiICsgbWV0aG9kICsgXCInIGlzIG5vdCBhbiBhdmFpbGFibGUgbWV0aG9kIGZvciBcIiArIChwbHVnQ2xhc3MgPyBmdW5jdGlvbk5hbWUocGx1Z0NsYXNzKSA6ICd0aGlzIGVsZW1lbnQnKSArICcuJyk7XG4gICAgfVxuICB9ZWxzZXsvL2Vycm9yIGZvciBpbnZhbGlkIGFyZ3VtZW50IHR5cGVcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBXZSdyZSBzb3JyeSwgJHt0eXBlfSBpcyBub3QgYSB2YWxpZCBwYXJhbWV0ZXIuIFlvdSBtdXN0IHVzZSBhIHN0cmluZyByZXByZXNlbnRpbmcgdGhlIG1ldGhvZCB5b3Ugd2lzaCB0byBpbnZva2UuYCk7XG4gIH1cbiAgcmV0dXJuIHRoaXM7XG59O1xuXG53aW5kb3cuRm91bmRhdGlvbiA9IEZvdW5kYXRpb247XG4kLmZuLmZvdW5kYXRpb24gPSBmb3VuZGF0aW9uO1xuXG4vLyBQb2x5ZmlsbCBmb3IgcmVxdWVzdEFuaW1hdGlvbkZyYW1lXG4oZnVuY3Rpb24oKSB7XG4gIGlmICghRGF0ZS5ub3cgfHwgIXdpbmRvdy5EYXRlLm5vdylcbiAgICB3aW5kb3cuRGF0ZS5ub3cgPSBEYXRlLm5vdyA9IGZ1bmN0aW9uKCkgeyByZXR1cm4gbmV3IERhdGUoKS5nZXRUaW1lKCk7IH07XG5cbiAgdmFyIHZlbmRvcnMgPSBbJ3dlYmtpdCcsICdtb3onXTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCB2ZW5kb3JzLmxlbmd0aCAmJiAhd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZTsgKytpKSB7XG4gICAgICB2YXIgdnAgPSB2ZW5kb3JzW2ldO1xuICAgICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSA9IHdpbmRvd1t2cCsnUmVxdWVzdEFuaW1hdGlvbkZyYW1lJ107XG4gICAgICB3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUgPSAod2luZG93W3ZwKydDYW5jZWxBbmltYXRpb25GcmFtZSddXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8fCB3aW5kb3dbdnArJ0NhbmNlbFJlcXVlc3RBbmltYXRpb25GcmFtZSddKTtcbiAgfVxuICBpZiAoL2lQKGFkfGhvbmV8b2QpLipPUyA2Ly50ZXN0KHdpbmRvdy5uYXZpZ2F0b3IudXNlckFnZW50KVxuICAgIHx8ICF3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lIHx8ICF3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUpIHtcbiAgICB2YXIgbGFzdFRpbWUgPSAwO1xuICAgIHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUgPSBmdW5jdGlvbihjYWxsYmFjaykge1xuICAgICAgICB2YXIgbm93ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgdmFyIG5leHRUaW1lID0gTWF0aC5tYXgobGFzdFRpbWUgKyAxNiwgbm93KTtcbiAgICAgICAgcmV0dXJuIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7IGNhbGxiYWNrKGxhc3RUaW1lID0gbmV4dFRpbWUpOyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBuZXh0VGltZSAtIG5vdyk7XG4gICAgfTtcbiAgICB3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUgPSBjbGVhclRpbWVvdXQ7XG4gIH1cbiAgLyoqXG4gICAqIFBvbHlmaWxsIGZvciBwZXJmb3JtYW5jZS5ub3csIHJlcXVpcmVkIGJ5IHJBRlxuICAgKi9cbiAgaWYoIXdpbmRvdy5wZXJmb3JtYW5jZSB8fCAhd2luZG93LnBlcmZvcm1hbmNlLm5vdyl7XG4gICAgd2luZG93LnBlcmZvcm1hbmNlID0ge1xuICAgICAgc3RhcnQ6IERhdGUubm93KCksXG4gICAgICBub3c6IGZ1bmN0aW9uKCl7IHJldHVybiBEYXRlLm5vdygpIC0gdGhpcy5zdGFydDsgfVxuICAgIH07XG4gIH1cbn0pKCk7XG5pZiAoIUZ1bmN0aW9uLnByb3RvdHlwZS5iaW5kKSB7XG4gIEZ1bmN0aW9uLnByb3RvdHlwZS5iaW5kID0gZnVuY3Rpb24ob1RoaXMpIHtcbiAgICBpZiAodHlwZW9mIHRoaXMgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgIC8vIGNsb3Nlc3QgdGhpbmcgcG9zc2libGUgdG8gdGhlIEVDTUFTY3JpcHQgNVxuICAgICAgLy8gaW50ZXJuYWwgSXNDYWxsYWJsZSBmdW5jdGlvblxuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignRnVuY3Rpb24ucHJvdG90eXBlLmJpbmQgLSB3aGF0IGlzIHRyeWluZyB0byBiZSBib3VuZCBpcyBub3QgY2FsbGFibGUnKTtcbiAgICB9XG5cbiAgICB2YXIgYUFyZ3MgICA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cywgMSksXG4gICAgICAgIGZUb0JpbmQgPSB0aGlzLFxuICAgICAgICBmTk9QICAgID0gZnVuY3Rpb24oKSB7fSxcbiAgICAgICAgZkJvdW5kICA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHJldHVybiBmVG9CaW5kLmFwcGx5KHRoaXMgaW5zdGFuY2VvZiBmTk9QXG4gICAgICAgICAgICAgICAgID8gdGhpc1xuICAgICAgICAgICAgICAgICA6IG9UaGlzLFxuICAgICAgICAgICAgICAgICBhQXJncy5jb25jYXQoQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzKSkpO1xuICAgICAgICB9O1xuXG4gICAgaWYgKHRoaXMucHJvdG90eXBlKSB7XG4gICAgICAvLyBuYXRpdmUgZnVuY3Rpb25zIGRvbid0IGhhdmUgYSBwcm90b3R5cGVcbiAgICAgIGZOT1AucHJvdG90eXBlID0gdGhpcy5wcm90b3R5cGU7XG4gICAgfVxuICAgIGZCb3VuZC5wcm90b3R5cGUgPSBuZXcgZk5PUCgpO1xuXG4gICAgcmV0dXJuIGZCb3VuZDtcbiAgfTtcbn1cbi8vIFBvbHlmaWxsIHRvIGdldCB0aGUgbmFtZSBvZiBhIGZ1bmN0aW9uIGluIElFOVxuZnVuY3Rpb24gZnVuY3Rpb25OYW1lKGZuKSB7XG4gIGlmIChGdW5jdGlvbi5wcm90b3R5cGUubmFtZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdmFyIGZ1bmNOYW1lUmVnZXggPSAvZnVuY3Rpb25cXHMoW14oXXsxLH0pXFwoLztcbiAgICB2YXIgcmVzdWx0cyA9IChmdW5jTmFtZVJlZ2V4KS5leGVjKChmbikudG9TdHJpbmcoKSk7XG4gICAgcmV0dXJuIChyZXN1bHRzICYmIHJlc3VsdHMubGVuZ3RoID4gMSkgPyByZXN1bHRzWzFdLnRyaW0oKSA6IFwiXCI7XG4gIH1cbiAgZWxzZSBpZiAoZm4ucHJvdG90eXBlID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gZm4uY29uc3RydWN0b3IubmFtZTtcbiAgfVxuICBlbHNlIHtcbiAgICByZXR1cm4gZm4ucHJvdG90eXBlLmNvbnN0cnVjdG9yLm5hbWU7XG4gIH1cbn1cbmZ1bmN0aW9uIHBhcnNlVmFsdWUoc3RyKXtcbiAgaWYgKCd0cnVlJyA9PT0gc3RyKSByZXR1cm4gdHJ1ZTtcbiAgZWxzZSBpZiAoJ2ZhbHNlJyA9PT0gc3RyKSByZXR1cm4gZmFsc2U7XG4gIGVsc2UgaWYgKCFpc05hTihzdHIgKiAxKSkgcmV0dXJuIHBhcnNlRmxvYXQoc3RyKTtcbiAgcmV0dXJuIHN0cjtcbn1cbi8vIENvbnZlcnQgUGFzY2FsQ2FzZSB0byBrZWJhYi1jYXNlXG4vLyBUaGFuayB5b3U6IGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9hLzg5NTU1ODBcbmZ1bmN0aW9uIGh5cGhlbmF0ZShzdHIpIHtcbiAgcmV0dXJuIHN0ci5yZXBsYWNlKC8oW2Etel0pKFtBLVpdKS9nLCAnJDEtJDInKS50b0xvd2VyQ2FzZSgpO1xufVxuXG59KGpRdWVyeSk7XG4iLCIndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbkZvdW5kYXRpb24uQm94ID0ge1xuICBJbU5vdFRvdWNoaW5nWW91OiBJbU5vdFRvdWNoaW5nWW91LFxuICBHZXREaW1lbnNpb25zOiBHZXREaW1lbnNpb25zLFxuICBHZXRPZmZzZXRzOiBHZXRPZmZzZXRzXG59XG5cbi8qKlxuICogQ29tcGFyZXMgdGhlIGRpbWVuc2lvbnMgb2YgYW4gZWxlbWVudCB0byBhIGNvbnRhaW5lciBhbmQgZGV0ZXJtaW5lcyBjb2xsaXNpb24gZXZlbnRzIHdpdGggY29udGFpbmVyLlxuICogQGZ1bmN0aW9uXG4gKiBAcGFyYW0ge2pRdWVyeX0gZWxlbWVudCAtIGpRdWVyeSBvYmplY3QgdG8gdGVzdCBmb3IgY29sbGlzaW9ucy5cbiAqIEBwYXJhbSB7alF1ZXJ5fSBwYXJlbnQgLSBqUXVlcnkgb2JqZWN0IHRvIHVzZSBhcyBib3VuZGluZyBjb250YWluZXIuXG4gKiBAcGFyYW0ge0Jvb2xlYW59IGxyT25seSAtIHNldCB0byB0cnVlIHRvIGNoZWNrIGxlZnQgYW5kIHJpZ2h0IHZhbHVlcyBvbmx5LlxuICogQHBhcmFtIHtCb29sZWFufSB0Yk9ubHkgLSBzZXQgdG8gdHJ1ZSB0byBjaGVjayB0b3AgYW5kIGJvdHRvbSB2YWx1ZXMgb25seS5cbiAqIEBkZWZhdWx0IGlmIG5vIHBhcmVudCBvYmplY3QgcGFzc2VkLCBkZXRlY3RzIGNvbGxpc2lvbnMgd2l0aCBgd2luZG93YC5cbiAqIEByZXR1cm5zIHtCb29sZWFufSAtIHRydWUgaWYgY29sbGlzaW9uIGZyZWUsIGZhbHNlIGlmIGEgY29sbGlzaW9uIGluIGFueSBkaXJlY3Rpb24uXG4gKi9cbmZ1bmN0aW9uIEltTm90VG91Y2hpbmdZb3UoZWxlbWVudCwgcGFyZW50LCBsck9ubHksIHRiT25seSkge1xuICB2YXIgZWxlRGltcyA9IEdldERpbWVuc2lvbnMoZWxlbWVudCksXG4gICAgICB0b3AsIGJvdHRvbSwgbGVmdCwgcmlnaHQ7XG5cbiAgaWYgKHBhcmVudCkge1xuICAgIHZhciBwYXJEaW1zID0gR2V0RGltZW5zaW9ucyhwYXJlbnQpO1xuXG4gICAgYm90dG9tID0gKGVsZURpbXMub2Zmc2V0LnRvcCArIGVsZURpbXMuaGVpZ2h0IDw9IHBhckRpbXMuaGVpZ2h0ICsgcGFyRGltcy5vZmZzZXQudG9wKTtcbiAgICB0b3AgICAgPSAoZWxlRGltcy5vZmZzZXQudG9wID49IHBhckRpbXMub2Zmc2V0LnRvcCk7XG4gICAgbGVmdCAgID0gKGVsZURpbXMub2Zmc2V0LmxlZnQgPj0gcGFyRGltcy5vZmZzZXQubGVmdCk7XG4gICAgcmlnaHQgID0gKGVsZURpbXMub2Zmc2V0LmxlZnQgKyBlbGVEaW1zLndpZHRoIDw9IHBhckRpbXMud2lkdGggKyBwYXJEaW1zLm9mZnNldC5sZWZ0KTtcbiAgfVxuICBlbHNlIHtcbiAgICBib3R0b20gPSAoZWxlRGltcy5vZmZzZXQudG9wICsgZWxlRGltcy5oZWlnaHQgPD0gZWxlRGltcy53aW5kb3dEaW1zLmhlaWdodCArIGVsZURpbXMud2luZG93RGltcy5vZmZzZXQudG9wKTtcbiAgICB0b3AgICAgPSAoZWxlRGltcy5vZmZzZXQudG9wID49IGVsZURpbXMud2luZG93RGltcy5vZmZzZXQudG9wKTtcbiAgICBsZWZ0ICAgPSAoZWxlRGltcy5vZmZzZXQubGVmdCA+PSBlbGVEaW1zLndpbmRvd0RpbXMub2Zmc2V0LmxlZnQpO1xuICAgIHJpZ2h0ICA9IChlbGVEaW1zLm9mZnNldC5sZWZ0ICsgZWxlRGltcy53aWR0aCA8PSBlbGVEaW1zLndpbmRvd0RpbXMud2lkdGgpO1xuICB9XG5cbiAgdmFyIGFsbERpcnMgPSBbYm90dG9tLCB0b3AsIGxlZnQsIHJpZ2h0XTtcblxuICBpZiAobHJPbmx5KSB7XG4gICAgcmV0dXJuIGxlZnQgPT09IHJpZ2h0ID09PSB0cnVlO1xuICB9XG5cbiAgaWYgKHRiT25seSkge1xuICAgIHJldHVybiB0b3AgPT09IGJvdHRvbSA9PT0gdHJ1ZTtcbiAgfVxuXG4gIHJldHVybiBhbGxEaXJzLmluZGV4T2YoZmFsc2UpID09PSAtMTtcbn07XG5cbi8qKlxuICogVXNlcyBuYXRpdmUgbWV0aG9kcyB0byByZXR1cm4gYW4gb2JqZWN0IG9mIGRpbWVuc2lvbiB2YWx1ZXMuXG4gKiBAZnVuY3Rpb25cbiAqIEBwYXJhbSB7alF1ZXJ5IHx8IEhUTUx9IGVsZW1lbnQgLSBqUXVlcnkgb2JqZWN0IG9yIERPTSBlbGVtZW50IGZvciB3aGljaCB0byBnZXQgdGhlIGRpbWVuc2lvbnMuIENhbiBiZSBhbnkgZWxlbWVudCBvdGhlciB0aGF0IGRvY3VtZW50IG9yIHdpbmRvdy5cbiAqIEByZXR1cm5zIHtPYmplY3R9IC0gbmVzdGVkIG9iamVjdCBvZiBpbnRlZ2VyIHBpeGVsIHZhbHVlc1xuICogVE9ETyAtIGlmIGVsZW1lbnQgaXMgd2luZG93LCByZXR1cm4gb25seSB0aG9zZSB2YWx1ZXMuXG4gKi9cbmZ1bmN0aW9uIEdldERpbWVuc2lvbnMoZWxlbSwgdGVzdCl7XG4gIGVsZW0gPSBlbGVtLmxlbmd0aCA/IGVsZW1bMF0gOiBlbGVtO1xuXG4gIGlmIChlbGVtID09PSB3aW5kb3cgfHwgZWxlbSA9PT0gZG9jdW1lbnQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJJJ20gc29ycnksIERhdmUuIEknbSBhZnJhaWQgSSBjYW4ndCBkbyB0aGF0LlwiKTtcbiAgfVxuXG4gIHZhciByZWN0ID0gZWxlbS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxcbiAgICAgIHBhclJlY3QgPSBlbGVtLnBhcmVudE5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksXG4gICAgICB3aW5SZWN0ID0gZG9jdW1lbnQuYm9keS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxcbiAgICAgIHdpblkgPSB3aW5kb3cucGFnZVlPZmZzZXQsXG4gICAgICB3aW5YID0gd2luZG93LnBhZ2VYT2Zmc2V0O1xuXG4gIHJldHVybiB7XG4gICAgd2lkdGg6IHJlY3Qud2lkdGgsXG4gICAgaGVpZ2h0OiByZWN0LmhlaWdodCxcbiAgICBvZmZzZXQ6IHtcbiAgICAgIHRvcDogcmVjdC50b3AgKyB3aW5ZLFxuICAgICAgbGVmdDogcmVjdC5sZWZ0ICsgd2luWFxuICAgIH0sXG4gICAgcGFyZW50RGltczoge1xuICAgICAgd2lkdGg6IHBhclJlY3Qud2lkdGgsXG4gICAgICBoZWlnaHQ6IHBhclJlY3QuaGVpZ2h0LFxuICAgICAgb2Zmc2V0OiB7XG4gICAgICAgIHRvcDogcGFyUmVjdC50b3AgKyB3aW5ZLFxuICAgICAgICBsZWZ0OiBwYXJSZWN0LmxlZnQgKyB3aW5YXG4gICAgICB9XG4gICAgfSxcbiAgICB3aW5kb3dEaW1zOiB7XG4gICAgICB3aWR0aDogd2luUmVjdC53aWR0aCxcbiAgICAgIGhlaWdodDogd2luUmVjdC5oZWlnaHQsXG4gICAgICBvZmZzZXQ6IHtcbiAgICAgICAgdG9wOiB3aW5ZLFxuICAgICAgICBsZWZ0OiB3aW5YXG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogUmV0dXJucyBhbiBvYmplY3Qgb2YgdG9wIGFuZCBsZWZ0IGludGVnZXIgcGl4ZWwgdmFsdWVzIGZvciBkeW5hbWljYWxseSByZW5kZXJlZCBlbGVtZW50cyxcbiAqIHN1Y2ggYXM6IFRvb2x0aXAsIFJldmVhbCwgYW5kIERyb3Bkb3duXG4gKiBAZnVuY3Rpb25cbiAqIEBwYXJhbSB7alF1ZXJ5fSBlbGVtZW50IC0galF1ZXJ5IG9iamVjdCBmb3IgdGhlIGVsZW1lbnQgYmVpbmcgcG9zaXRpb25lZC5cbiAqIEBwYXJhbSB7alF1ZXJ5fSBhbmNob3IgLSBqUXVlcnkgb2JqZWN0IGZvciB0aGUgZWxlbWVudCdzIGFuY2hvciBwb2ludC5cbiAqIEBwYXJhbSB7U3RyaW5nfSBwb3NpdGlvbiAtIGEgc3RyaW5nIHJlbGF0aW5nIHRvIHRoZSBkZXNpcmVkIHBvc2l0aW9uIG9mIHRoZSBlbGVtZW50LCByZWxhdGl2ZSB0byBpdCdzIGFuY2hvclxuICogQHBhcmFtIHtOdW1iZXJ9IHZPZmZzZXQgLSBpbnRlZ2VyIHBpeGVsIHZhbHVlIG9mIGRlc2lyZWQgdmVydGljYWwgc2VwYXJhdGlvbiBiZXR3ZWVuIGFuY2hvciBhbmQgZWxlbWVudC5cbiAqIEBwYXJhbSB7TnVtYmVyfSBoT2Zmc2V0IC0gaW50ZWdlciBwaXhlbCB2YWx1ZSBvZiBkZXNpcmVkIGhvcml6b250YWwgc2VwYXJhdGlvbiBiZXR3ZWVuIGFuY2hvciBhbmQgZWxlbWVudC5cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gaXNPdmVyZmxvdyAtIGlmIGEgY29sbGlzaW9uIGV2ZW50IGlzIGRldGVjdGVkLCBzZXRzIHRvIHRydWUgdG8gZGVmYXVsdCB0aGUgZWxlbWVudCB0byBmdWxsIHdpZHRoIC0gYW55IGRlc2lyZWQgb2Zmc2V0LlxuICogVE9ETyBhbHRlci9yZXdyaXRlIHRvIHdvcmsgd2l0aCBgZW1gIHZhbHVlcyBhcyB3ZWxsL2luc3RlYWQgb2YgcGl4ZWxzXG4gKi9cbmZ1bmN0aW9uIEdldE9mZnNldHMoZWxlbWVudCwgYW5jaG9yLCBwb3NpdGlvbiwgdk9mZnNldCwgaE9mZnNldCwgaXNPdmVyZmxvdykge1xuICB2YXIgJGVsZURpbXMgPSBHZXREaW1lbnNpb25zKGVsZW1lbnQpLFxuICAgICAgJGFuY2hvckRpbXMgPSBhbmNob3IgPyBHZXREaW1lbnNpb25zKGFuY2hvcikgOiBudWxsO1xuXG4gIHN3aXRjaCAocG9zaXRpb24pIHtcbiAgICBjYXNlICd0b3AnOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogKEZvdW5kYXRpb24ucnRsKCkgPyAkYW5jaG9yRGltcy5vZmZzZXQubGVmdCAtICRlbGVEaW1zLndpZHRoICsgJGFuY2hvckRpbXMud2lkdGggOiAkYW5jaG9yRGltcy5vZmZzZXQubGVmdCksXG4gICAgICAgIHRvcDogJGFuY2hvckRpbXMub2Zmc2V0LnRvcCAtICgkZWxlRGltcy5oZWlnaHQgKyB2T2Zmc2V0KVxuICAgICAgfVxuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbGVmdCc6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsZWZ0OiAkYW5jaG9yRGltcy5vZmZzZXQubGVmdCAtICgkZWxlRGltcy53aWR0aCArIGhPZmZzZXQpLFxuICAgICAgICB0b3A6ICRhbmNob3JEaW1zLm9mZnNldC50b3BcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3JpZ2h0JzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxlZnQ6ICRhbmNob3JEaW1zLm9mZnNldC5sZWZ0ICsgJGFuY2hvckRpbXMud2lkdGggKyBoT2Zmc2V0LFxuICAgICAgICB0b3A6ICRhbmNob3JEaW1zLm9mZnNldC50b3BcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2NlbnRlciB0b3AnOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogKCRhbmNob3JEaW1zLm9mZnNldC5sZWZ0ICsgKCRhbmNob3JEaW1zLndpZHRoIC8gMikpIC0gKCRlbGVEaW1zLndpZHRoIC8gMiksXG4gICAgICAgIHRvcDogJGFuY2hvckRpbXMub2Zmc2V0LnRvcCAtICgkZWxlRGltcy5oZWlnaHQgKyB2T2Zmc2V0KVxuICAgICAgfVxuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnY2VudGVyIGJvdHRvbSc6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsZWZ0OiBpc092ZXJmbG93ID8gaE9mZnNldCA6ICgoJGFuY2hvckRpbXMub2Zmc2V0LmxlZnQgKyAoJGFuY2hvckRpbXMud2lkdGggLyAyKSkgLSAoJGVsZURpbXMud2lkdGggLyAyKSksXG4gICAgICAgIHRvcDogJGFuY2hvckRpbXMub2Zmc2V0LnRvcCArICRhbmNob3JEaW1zLmhlaWdodCArIHZPZmZzZXRcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2NlbnRlciBsZWZ0JzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxlZnQ6ICRhbmNob3JEaW1zLm9mZnNldC5sZWZ0IC0gKCRlbGVEaW1zLndpZHRoICsgaE9mZnNldCksXG4gICAgICAgIHRvcDogKCRhbmNob3JEaW1zLm9mZnNldC50b3AgKyAoJGFuY2hvckRpbXMuaGVpZ2h0IC8gMikpIC0gKCRlbGVEaW1zLmhlaWdodCAvIDIpXG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICBjYXNlICdjZW50ZXIgcmlnaHQnOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogJGFuY2hvckRpbXMub2Zmc2V0LmxlZnQgKyAkYW5jaG9yRGltcy53aWR0aCArIGhPZmZzZXQgKyAxLFxuICAgICAgICB0b3A6ICgkYW5jaG9yRGltcy5vZmZzZXQudG9wICsgKCRhbmNob3JEaW1zLmhlaWdodCAvIDIpKSAtICgkZWxlRGltcy5oZWlnaHQgLyAyKVxuICAgICAgfVxuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnY2VudGVyJzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGxlZnQ6ICgkZWxlRGltcy53aW5kb3dEaW1zLm9mZnNldC5sZWZ0ICsgKCRlbGVEaW1zLndpbmRvd0RpbXMud2lkdGggLyAyKSkgLSAoJGVsZURpbXMud2lkdGggLyAyKSxcbiAgICAgICAgdG9wOiAoJGVsZURpbXMud2luZG93RGltcy5vZmZzZXQudG9wICsgKCRlbGVEaW1zLndpbmRvd0RpbXMuaGVpZ2h0IC8gMikpIC0gKCRlbGVEaW1zLmhlaWdodCAvIDIpXG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICBjYXNlICdyZXZlYWwnOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogKCRlbGVEaW1zLndpbmRvd0RpbXMud2lkdGggLSAkZWxlRGltcy53aWR0aCkgLyAyLFxuICAgICAgICB0b3A6ICRlbGVEaW1zLndpbmRvd0RpbXMub2Zmc2V0LnRvcCArIHZPZmZzZXRcbiAgICAgIH1cbiAgICBjYXNlICdyZXZlYWwgZnVsbCc6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsZWZ0OiAkZWxlRGltcy53aW5kb3dEaW1zLm9mZnNldC5sZWZ0LFxuICAgICAgICB0b3A6ICRlbGVEaW1zLndpbmRvd0RpbXMub2Zmc2V0LnRvcFxuICAgICAgfVxuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbGVmdCBib3R0b20nOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogJGFuY2hvckRpbXMub2Zmc2V0LmxlZnQsXG4gICAgICAgIHRvcDogJGFuY2hvckRpbXMub2Zmc2V0LnRvcCArICRhbmNob3JEaW1zLmhlaWdodCArIHZPZmZzZXRcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgICBjYXNlICdyaWdodCBib3R0b20nOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogJGFuY2hvckRpbXMub2Zmc2V0LmxlZnQgKyAkYW5jaG9yRGltcy53aWR0aCArIGhPZmZzZXQgLSAkZWxlRGltcy53aWR0aCxcbiAgICAgICAgdG9wOiAkYW5jaG9yRGltcy5vZmZzZXQudG9wICsgJGFuY2hvckRpbXMuaGVpZ2h0ICsgdk9mZnNldFxuICAgICAgfTtcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsZWZ0OiAoRm91bmRhdGlvbi5ydGwoKSA/ICRhbmNob3JEaW1zLm9mZnNldC5sZWZ0IC0gJGVsZURpbXMud2lkdGggKyAkYW5jaG9yRGltcy53aWR0aCA6ICRhbmNob3JEaW1zLm9mZnNldC5sZWZ0ICsgaE9mZnNldCksXG4gICAgICAgIHRvcDogJGFuY2hvckRpbXMub2Zmc2V0LnRvcCArICRhbmNob3JEaW1zLmhlaWdodCArIHZPZmZzZXRcbiAgICAgIH1cbiAgfVxufVxuXG59KGpRdWVyeSk7XG4iLCIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICpcbiAqIFRoaXMgdXRpbCB3YXMgY3JlYXRlZCBieSBNYXJpdXMgT2xiZXJ0eiAqXG4gKiBQbGVhc2UgdGhhbmsgTWFyaXVzIG9uIEdpdEh1YiAvb3dsYmVydHogKlxuICogb3IgdGhlIHdlYiBodHRwOi8vd3d3Lm1hcml1c29sYmVydHouZGUvICpcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAqXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG4ndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbmNvbnN0IGtleUNvZGVzID0ge1xuICA5OiAnVEFCJyxcbiAgMTM6ICdFTlRFUicsXG4gIDI3OiAnRVNDQVBFJyxcbiAgMzI6ICdTUEFDRScsXG4gIDM3OiAnQVJST1dfTEVGVCcsXG4gIDM4OiAnQVJST1dfVVAnLFxuICAzOTogJ0FSUk9XX1JJR0hUJyxcbiAgNDA6ICdBUlJPV19ET1dOJ1xufVxuXG52YXIgY29tbWFuZHMgPSB7fVxuXG52YXIgS2V5Ym9hcmQgPSB7XG4gIGtleXM6IGdldEtleUNvZGVzKGtleUNvZGVzKSxcblxuICAvKipcbiAgICogUGFyc2VzIHRoZSAoa2V5Ym9hcmQpIGV2ZW50IGFuZCByZXR1cm5zIGEgU3RyaW5nIHRoYXQgcmVwcmVzZW50cyBpdHMga2V5XG4gICAqIENhbiBiZSB1c2VkIGxpa2UgRm91bmRhdGlvbi5wYXJzZUtleShldmVudCkgPT09IEZvdW5kYXRpb24ua2V5cy5TUEFDRVxuICAgKiBAcGFyYW0ge0V2ZW50fSBldmVudCAtIHRoZSBldmVudCBnZW5lcmF0ZWQgYnkgdGhlIGV2ZW50IGhhbmRsZXJcbiAgICogQHJldHVybiBTdHJpbmcga2V5IC0gU3RyaW5nIHRoYXQgcmVwcmVzZW50cyB0aGUga2V5IHByZXNzZWRcbiAgICovXG4gIHBhcnNlS2V5KGV2ZW50KSB7XG4gICAgdmFyIGtleSA9IGtleUNvZGVzW2V2ZW50LndoaWNoIHx8IGV2ZW50LmtleUNvZGVdIHx8IFN0cmluZy5mcm9tQ2hhckNvZGUoZXZlbnQud2hpY2gpLnRvVXBwZXJDYXNlKCk7XG5cbiAgICAvLyBSZW1vdmUgdW4tcHJpbnRhYmxlIGNoYXJhY3RlcnMsIGUuZy4gZm9yIGBmcm9tQ2hhckNvZGVgIGNhbGxzIGZvciBDVFJMIG9ubHkgZXZlbnRzXG4gICAga2V5ID0ga2V5LnJlcGxhY2UoL1xcVysvLCAnJyk7XG5cbiAgICBpZiAoZXZlbnQuc2hpZnRLZXkpIGtleSA9IGBTSElGVF8ke2tleX1gO1xuICAgIGlmIChldmVudC5jdHJsS2V5KSBrZXkgPSBgQ1RSTF8ke2tleX1gO1xuICAgIGlmIChldmVudC5hbHRLZXkpIGtleSA9IGBBTFRfJHtrZXl9YDtcblxuICAgIC8vIFJlbW92ZSB0cmFpbGluZyB1bmRlcnNjb3JlLCBpbiBjYXNlIG9ubHkgbW9kaWZpZXJzIHdlcmUgdXNlZCAoZS5nLiBvbmx5IGBDVFJMX0FMVGApXG4gICAga2V5ID0ga2V5LnJlcGxhY2UoL18kLywgJycpO1xuXG4gICAgcmV0dXJuIGtleTtcbiAgfSxcblxuICAvKipcbiAgICogSGFuZGxlcyB0aGUgZ2l2ZW4gKGtleWJvYXJkKSBldmVudFxuICAgKiBAcGFyYW0ge0V2ZW50fSBldmVudCAtIHRoZSBldmVudCBnZW5lcmF0ZWQgYnkgdGhlIGV2ZW50IGhhbmRsZXJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNvbXBvbmVudCAtIEZvdW5kYXRpb24gY29tcG9uZW50J3MgbmFtZSwgZS5nLiBTbGlkZXIgb3IgUmV2ZWFsXG4gICAqIEBwYXJhbSB7T2JqZWN0c30gZnVuY3Rpb25zIC0gY29sbGVjdGlvbiBvZiBmdW5jdGlvbnMgdGhhdCBhcmUgdG8gYmUgZXhlY3V0ZWRcbiAgICovXG4gIGhhbmRsZUtleShldmVudCwgY29tcG9uZW50LCBmdW5jdGlvbnMpIHtcbiAgICB2YXIgY29tbWFuZExpc3QgPSBjb21tYW5kc1tjb21wb25lbnRdLFxuICAgICAga2V5Q29kZSA9IHRoaXMucGFyc2VLZXkoZXZlbnQpLFxuICAgICAgY21kcyxcbiAgICAgIGNvbW1hbmQsXG4gICAgICBmbjtcblxuICAgIGlmICghY29tbWFuZExpc3QpIHJldHVybiBjb25zb2xlLndhcm4oJ0NvbXBvbmVudCBub3QgZGVmaW5lZCEnKTtcblxuICAgIGlmICh0eXBlb2YgY29tbWFuZExpc3QubHRyID09PSAndW5kZWZpbmVkJykgeyAvLyB0aGlzIGNvbXBvbmVudCBkb2VzIG5vdCBkaWZmZXJlbnRpYXRlIGJldHdlZW4gbHRyIGFuZCBydGxcbiAgICAgICAgY21kcyA9IGNvbW1hbmRMaXN0OyAvLyB1c2UgcGxhaW4gbGlzdFxuICAgIH0gZWxzZSB7IC8vIG1lcmdlIGx0ciBhbmQgcnRsOiBpZiBkb2N1bWVudCBpcyBydGwsIHJ0bCBvdmVyd3JpdGVzIGx0ciBhbmQgdmljZSB2ZXJzYVxuICAgICAgICBpZiAoRm91bmRhdGlvbi5ydGwoKSkgY21kcyA9ICQuZXh0ZW5kKHt9LCBjb21tYW5kTGlzdC5sdHIsIGNvbW1hbmRMaXN0LnJ0bCk7XG5cbiAgICAgICAgZWxzZSBjbWRzID0gJC5leHRlbmQoe30sIGNvbW1hbmRMaXN0LnJ0bCwgY29tbWFuZExpc3QubHRyKTtcbiAgICB9XG4gICAgY29tbWFuZCA9IGNtZHNba2V5Q29kZV07XG5cbiAgICBmbiA9IGZ1bmN0aW9uc1tjb21tYW5kXTtcbiAgICBpZiAoZm4gJiYgdHlwZW9mIGZuID09PSAnZnVuY3Rpb24nKSB7IC8vIGV4ZWN1dGUgZnVuY3Rpb24gIGlmIGV4aXN0c1xuICAgICAgdmFyIHJldHVyblZhbHVlID0gZm4uYXBwbHkoKTtcbiAgICAgIGlmIChmdW5jdGlvbnMuaGFuZGxlZCB8fCB0eXBlb2YgZnVuY3Rpb25zLmhhbmRsZWQgPT09ICdmdW5jdGlvbicpIHsgLy8gZXhlY3V0ZSBmdW5jdGlvbiB3aGVuIGV2ZW50IHdhcyBoYW5kbGVkXG4gICAgICAgICAgZnVuY3Rpb25zLmhhbmRsZWQocmV0dXJuVmFsdWUpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoZnVuY3Rpb25zLnVuaGFuZGxlZCB8fCB0eXBlb2YgZnVuY3Rpb25zLnVuaGFuZGxlZCA9PT0gJ2Z1bmN0aW9uJykgeyAvLyBleGVjdXRlIGZ1bmN0aW9uIHdoZW4gZXZlbnQgd2FzIG5vdCBoYW5kbGVkXG4gICAgICAgICAgZnVuY3Rpb25zLnVuaGFuZGxlZCgpO1xuICAgICAgfVxuICAgIH1cbiAgfSxcblxuICAvKipcbiAgICogRmluZHMgYWxsIGZvY3VzYWJsZSBlbGVtZW50cyB3aXRoaW4gdGhlIGdpdmVuIGAkZWxlbWVudGBcbiAgICogQHBhcmFtIHtqUXVlcnl9ICRlbGVtZW50IC0galF1ZXJ5IG9iamVjdCB0byBzZWFyY2ggd2l0aGluXG4gICAqIEByZXR1cm4ge2pRdWVyeX0gJGZvY3VzYWJsZSAtIGFsbCBmb2N1c2FibGUgZWxlbWVudHMgd2l0aGluIGAkZWxlbWVudGBcbiAgICovXG4gIGZpbmRGb2N1c2FibGUoJGVsZW1lbnQpIHtcbiAgICBpZighJGVsZW1lbnQpIHtyZXR1cm4gZmFsc2U7IH1cbiAgICByZXR1cm4gJGVsZW1lbnQuZmluZCgnYVtocmVmXSwgYXJlYVtocmVmXSwgaW5wdXQ6bm90KFtkaXNhYmxlZF0pLCBzZWxlY3Q6bm90KFtkaXNhYmxlZF0pLCB0ZXh0YXJlYTpub3QoW2Rpc2FibGVkXSksIGJ1dHRvbjpub3QoW2Rpc2FibGVkXSksIGlmcmFtZSwgb2JqZWN0LCBlbWJlZCwgKlt0YWJpbmRleF0sICpbY29udGVudGVkaXRhYmxlXScpLmZpbHRlcihmdW5jdGlvbigpIHtcbiAgICAgIGlmICghJCh0aGlzKS5pcygnOnZpc2libGUnKSB8fCAkKHRoaXMpLmF0dHIoJ3RhYmluZGV4JykgPCAwKSB7IHJldHVybiBmYWxzZTsgfSAvL29ubHkgaGF2ZSB2aXNpYmxlIGVsZW1lbnRzIGFuZCB0aG9zZSB0aGF0IGhhdmUgYSB0YWJpbmRleCBncmVhdGVyIG9yIGVxdWFsIDBcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0pO1xuICB9LFxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBjb21wb25lbnQgbmFtZSBuYW1lXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb21wb25lbnQgLSBGb3VuZGF0aW9uIGNvbXBvbmVudCwgZS5nLiBTbGlkZXIgb3IgUmV2ZWFsXG4gICAqIEByZXR1cm4gU3RyaW5nIGNvbXBvbmVudE5hbWVcbiAgICovXG5cbiAgcmVnaXN0ZXIoY29tcG9uZW50TmFtZSwgY21kcykge1xuICAgIGNvbW1hbmRzW2NvbXBvbmVudE5hbWVdID0gY21kcztcbiAgfSwgIFxuXG4gIC8qKlxuICAgKiBUcmFwcyB0aGUgZm9jdXMgaW4gdGhlIGdpdmVuIGVsZW1lbnQuXG4gICAqIEBwYXJhbSAge2pRdWVyeX0gJGVsZW1lbnQgIGpRdWVyeSBvYmplY3QgdG8gdHJhcCB0aGUgZm91Y3MgaW50by5cbiAgICovXG4gIHRyYXBGb2N1cygkZWxlbWVudCkge1xuICAgIHZhciAkZm9jdXNhYmxlID0gRm91bmRhdGlvbi5LZXlib2FyZC5maW5kRm9jdXNhYmxlKCRlbGVtZW50KSxcbiAgICAgICAgJGZpcnN0Rm9jdXNhYmxlID0gJGZvY3VzYWJsZS5lcSgwKSxcbiAgICAgICAgJGxhc3RGb2N1c2FibGUgPSAkZm9jdXNhYmxlLmVxKC0xKTtcblxuICAgICRlbGVtZW50Lm9uKCdrZXlkb3duLnpmLnRyYXBmb2N1cycsIGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgICBpZiAoZXZlbnQudGFyZ2V0ID09PSAkbGFzdEZvY3VzYWJsZVswXSAmJiBGb3VuZGF0aW9uLktleWJvYXJkLnBhcnNlS2V5KGV2ZW50KSA9PT0gJ1RBQicpIHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgJGZpcnN0Rm9jdXNhYmxlLmZvY3VzKCk7XG4gICAgICB9XG4gICAgICBlbHNlIGlmIChldmVudC50YXJnZXQgPT09ICRmaXJzdEZvY3VzYWJsZVswXSAmJiBGb3VuZGF0aW9uLktleWJvYXJkLnBhcnNlS2V5KGV2ZW50KSA9PT0gJ1NISUZUX1RBQicpIHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgJGxhc3RGb2N1c2FibGUuZm9jdXMoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSxcbiAgLyoqXG4gICAqIFJlbGVhc2VzIHRoZSB0cmFwcGVkIGZvY3VzIGZyb20gdGhlIGdpdmVuIGVsZW1lbnQuXG4gICAqIEBwYXJhbSAge2pRdWVyeX0gJGVsZW1lbnQgIGpRdWVyeSBvYmplY3QgdG8gcmVsZWFzZSB0aGUgZm9jdXMgZm9yLlxuICAgKi9cbiAgcmVsZWFzZUZvY3VzKCRlbGVtZW50KSB7XG4gICAgJGVsZW1lbnQub2ZmKCdrZXlkb3duLnpmLnRyYXBmb2N1cycpO1xuICB9XG59XG5cbi8qXG4gKiBDb25zdGFudHMgZm9yIGVhc2llciBjb21wYXJpbmcuXG4gKiBDYW4gYmUgdXNlZCBsaWtlIEZvdW5kYXRpb24ucGFyc2VLZXkoZXZlbnQpID09PSBGb3VuZGF0aW9uLmtleXMuU1BBQ0VcbiAqL1xuZnVuY3Rpb24gZ2V0S2V5Q29kZXMoa2NzKSB7XG4gIHZhciBrID0ge307XG4gIGZvciAodmFyIGtjIGluIGtjcykga1trY3Nba2NdXSA9IGtjc1trY107XG4gIHJldHVybiBrO1xufVxuXG5Gb3VuZGF0aW9uLktleWJvYXJkID0gS2V5Ym9hcmQ7XG5cbn0oalF1ZXJ5KTtcbiIsIid1c2Ugc3RyaWN0JztcblxuIWZ1bmN0aW9uKCQpIHtcblxuLy8gRGVmYXVsdCBzZXQgb2YgbWVkaWEgcXVlcmllc1xuY29uc3QgZGVmYXVsdFF1ZXJpZXMgPSB7XG4gICdkZWZhdWx0JyA6ICdvbmx5IHNjcmVlbicsXG4gIGxhbmRzY2FwZSA6ICdvbmx5IHNjcmVlbiBhbmQgKG9yaWVudGF0aW9uOiBsYW5kc2NhcGUpJyxcbiAgcG9ydHJhaXQgOiAnb25seSBzY3JlZW4gYW5kIChvcmllbnRhdGlvbjogcG9ydHJhaXQpJyxcbiAgcmV0aW5hIDogJ29ubHkgc2NyZWVuIGFuZCAoLXdlYmtpdC1taW4tZGV2aWNlLXBpeGVsLXJhdGlvOiAyKSwnICtcbiAgICAnb25seSBzY3JlZW4gYW5kIChtaW4tLW1vei1kZXZpY2UtcGl4ZWwtcmF0aW86IDIpLCcgK1xuICAgICdvbmx5IHNjcmVlbiBhbmQgKC1vLW1pbi1kZXZpY2UtcGl4ZWwtcmF0aW86IDIvMSksJyArXG4gICAgJ29ubHkgc2NyZWVuIGFuZCAobWluLWRldmljZS1waXhlbC1yYXRpbzogMiksJyArXG4gICAgJ29ubHkgc2NyZWVuIGFuZCAobWluLXJlc29sdXRpb246IDE5MmRwaSksJyArXG4gICAgJ29ubHkgc2NyZWVuIGFuZCAobWluLXJlc29sdXRpb246IDJkcHB4KSdcbn07XG5cbnZhciBNZWRpYVF1ZXJ5ID0ge1xuICBxdWVyaWVzOiBbXSxcblxuICBjdXJyZW50OiAnJyxcblxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgdGhlIG1lZGlhIHF1ZXJ5IGhlbHBlciwgYnkgZXh0cmFjdGluZyB0aGUgYnJlYWtwb2ludCBsaXN0IGZyb20gdGhlIENTUyBhbmQgYWN0aXZhdGluZyB0aGUgYnJlYWtwb2ludCB3YXRjaGVyLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9pbml0KCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICB2YXIgZXh0cmFjdGVkU3R5bGVzID0gJCgnLmZvdW5kYXRpb24tbXEnKS5jc3MoJ2ZvbnQtZmFtaWx5Jyk7XG4gICAgdmFyIG5hbWVkUXVlcmllcztcblxuICAgIG5hbWVkUXVlcmllcyA9IHBhcnNlU3R5bGVUb09iamVjdChleHRyYWN0ZWRTdHlsZXMpO1xuXG4gICAgZm9yICh2YXIga2V5IGluIG5hbWVkUXVlcmllcykge1xuICAgICAgaWYobmFtZWRRdWVyaWVzLmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgICAgc2VsZi5xdWVyaWVzLnB1c2goe1xuICAgICAgICAgIG5hbWU6IGtleSxcbiAgICAgICAgICB2YWx1ZTogYG9ubHkgc2NyZWVuIGFuZCAobWluLXdpZHRoOiAke25hbWVkUXVlcmllc1trZXldfSlgXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMuY3VycmVudCA9IHRoaXMuX2dldEN1cnJlbnRTaXplKCk7XG5cbiAgICB0aGlzLl93YXRjaGVyKCk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIENoZWNrcyBpZiB0aGUgc2NyZWVuIGlzIGF0IGxlYXN0IGFzIHdpZGUgYXMgYSBicmVha3BvaW50LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHBhcmFtIHtTdHJpbmd9IHNpemUgLSBOYW1lIG9mIHRoZSBicmVha3BvaW50IHRvIGNoZWNrLlxuICAgKiBAcmV0dXJucyB7Qm9vbGVhbn0gYHRydWVgIGlmIHRoZSBicmVha3BvaW50IG1hdGNoZXMsIGBmYWxzZWAgaWYgaXQncyBzbWFsbGVyLlxuICAgKi9cbiAgYXRMZWFzdChzaXplKSB7XG4gICAgdmFyIHF1ZXJ5ID0gdGhpcy5nZXQoc2l6ZSk7XG5cbiAgICBpZiAocXVlcnkpIHtcbiAgICAgIHJldHVybiB3aW5kb3cubWF0Y2hNZWRpYShxdWVyeSkubWF0Y2hlcztcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH0sXG5cbiAgLyoqXG4gICAqIENoZWNrcyBpZiB0aGUgc2NyZWVuIG1hdGNoZXMgdG8gYSBicmVha3BvaW50LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHBhcmFtIHtTdHJpbmd9IHNpemUgLSBOYW1lIG9mIHRoZSBicmVha3BvaW50IHRvIGNoZWNrLCBlaXRoZXIgJ3NtYWxsIG9ubHknIG9yICdzbWFsbCcuIE9taXR0aW5nICdvbmx5JyBmYWxscyBiYWNrIHRvIHVzaW5nIGF0TGVhc3QoKSBtZXRob2QuXG4gICAqIEByZXR1cm5zIHtCb29sZWFufSBgdHJ1ZWAgaWYgdGhlIGJyZWFrcG9pbnQgbWF0Y2hlcywgYGZhbHNlYCBpZiBpdCBkb2VzIG5vdC5cbiAgICovXG4gIGlzKHNpemUpIHtcbiAgICBzaXplID0gc2l6ZS50cmltKCkuc3BsaXQoJyAnKTtcbiAgICBpZihzaXplLmxlbmd0aCA+IDEgJiYgc2l6ZVsxXSA9PT0gJ29ubHknKSB7XG4gICAgICBpZihzaXplWzBdID09PSB0aGlzLl9nZXRDdXJyZW50U2l6ZSgpKSByZXR1cm4gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRoaXMuYXRMZWFzdChzaXplWzBdKTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9LFxuXG4gIC8qKlxuICAgKiBHZXRzIHRoZSBtZWRpYSBxdWVyeSBvZiBhIGJyZWFrcG9pbnQuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcGFyYW0ge1N0cmluZ30gc2l6ZSAtIE5hbWUgb2YgdGhlIGJyZWFrcG9pbnQgdG8gZ2V0LlxuICAgKiBAcmV0dXJucyB7U3RyaW5nfG51bGx9IC0gVGhlIG1lZGlhIHF1ZXJ5IG9mIHRoZSBicmVha3BvaW50LCBvciBgbnVsbGAgaWYgdGhlIGJyZWFrcG9pbnQgZG9lc24ndCBleGlzdC5cbiAgICovXG4gIGdldChzaXplKSB7XG4gICAgZm9yICh2YXIgaSBpbiB0aGlzLnF1ZXJpZXMpIHtcbiAgICAgIGlmKHRoaXMucXVlcmllcy5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICB2YXIgcXVlcnkgPSB0aGlzLnF1ZXJpZXNbaV07XG4gICAgICAgIGlmIChzaXplID09PSBxdWVyeS5uYW1lKSByZXR1cm4gcXVlcnkudmFsdWU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGw7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEdldHMgdGhlIGN1cnJlbnQgYnJlYWtwb2ludCBuYW1lIGJ5IHRlc3RpbmcgZXZlcnkgYnJlYWtwb2ludCBhbmQgcmV0dXJuaW5nIHRoZSBsYXN0IG9uZSB0byBtYXRjaCAodGhlIGJpZ2dlc3Qgb25lKS5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqIEByZXR1cm5zIHtTdHJpbmd9IE5hbWUgb2YgdGhlIGN1cnJlbnQgYnJlYWtwb2ludC5cbiAgICovXG4gIF9nZXRDdXJyZW50U2l6ZSgpIHtcbiAgICB2YXIgbWF0Y2hlZDtcblxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5xdWVyaWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgcXVlcnkgPSB0aGlzLnF1ZXJpZXNbaV07XG5cbiAgICAgIGlmICh3aW5kb3cubWF0Y2hNZWRpYShxdWVyeS52YWx1ZSkubWF0Y2hlcykge1xuICAgICAgICBtYXRjaGVkID0gcXVlcnk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHR5cGVvZiBtYXRjaGVkID09PSAnb2JqZWN0Jykge1xuICAgICAgcmV0dXJuIG1hdGNoZWQubmFtZTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG1hdGNoZWQ7XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBBY3RpdmF0ZXMgdGhlIGJyZWFrcG9pbnQgd2F0Y2hlciwgd2hpY2ggZmlyZXMgYW4gZXZlbnQgb24gdGhlIHdpbmRvdyB3aGVuZXZlciB0aGUgYnJlYWtwb2ludCBjaGFuZ2VzLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF93YXRjaGVyKCkge1xuICAgICQod2luZG93KS5vbigncmVzaXplLnpmLm1lZGlhcXVlcnknLCAoKSA9PiB7XG4gICAgICB2YXIgbmV3U2l6ZSA9IHRoaXMuX2dldEN1cnJlbnRTaXplKCksIGN1cnJlbnRTaXplID0gdGhpcy5jdXJyZW50O1xuXG4gICAgICBpZiAobmV3U2l6ZSAhPT0gY3VycmVudFNpemUpIHtcbiAgICAgICAgLy8gQ2hhbmdlIHRoZSBjdXJyZW50IG1lZGlhIHF1ZXJ5XG4gICAgICAgIHRoaXMuY3VycmVudCA9IG5ld1NpemU7XG5cbiAgICAgICAgLy8gQnJvYWRjYXN0IHRoZSBtZWRpYSBxdWVyeSBjaGFuZ2Ugb24gdGhlIHdpbmRvd1xuICAgICAgICAkKHdpbmRvdykudHJpZ2dlcignY2hhbmdlZC56Zi5tZWRpYXF1ZXJ5JywgW25ld1NpemUsIGN1cnJlbnRTaXplXSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbn07XG5cbkZvdW5kYXRpb24uTWVkaWFRdWVyeSA9IE1lZGlhUXVlcnk7XG5cbi8vIG1hdGNoTWVkaWEoKSBwb2x5ZmlsbCAtIFRlc3QgYSBDU1MgbWVkaWEgdHlwZS9xdWVyeSBpbiBKUy5cbi8vIEF1dGhvcnMgJiBjb3B5cmlnaHQgKGMpIDIwMTI6IFNjb3R0IEplaGwsIFBhdWwgSXJpc2gsIE5pY2hvbGFzIFpha2FzLCBEYXZpZCBLbmlnaHQuIER1YWwgTUlUL0JTRCBsaWNlbnNlXG53aW5kb3cubWF0Y2hNZWRpYSB8fCAod2luZG93Lm1hdGNoTWVkaWEgPSBmdW5jdGlvbigpIHtcbiAgJ3VzZSBzdHJpY3QnO1xuXG4gIC8vIEZvciBicm93c2VycyB0aGF0IHN1cHBvcnQgbWF0Y2hNZWRpdW0gYXBpIHN1Y2ggYXMgSUUgOSBhbmQgd2Via2l0XG4gIHZhciBzdHlsZU1lZGlhID0gKHdpbmRvdy5zdHlsZU1lZGlhIHx8IHdpbmRvdy5tZWRpYSk7XG5cbiAgLy8gRm9yIHRob3NlIHRoYXQgZG9uJ3Qgc3VwcG9ydCBtYXRjaE1lZGl1bVxuICBpZiAoIXN0eWxlTWVkaWEpIHtcbiAgICB2YXIgc3R5bGUgICA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyksXG4gICAgc2NyaXB0ICAgICAgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZSgnc2NyaXB0JylbMF0sXG4gICAgaW5mbyAgICAgICAgPSBudWxsO1xuXG4gICAgc3R5bGUudHlwZSAgPSAndGV4dC9jc3MnO1xuICAgIHN0eWxlLmlkICAgID0gJ21hdGNobWVkaWFqcy10ZXN0JztcblxuICAgIHNjcmlwdCAmJiBzY3JpcHQucGFyZW50Tm9kZSAmJiBzY3JpcHQucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoc3R5bGUsIHNjcmlwdCk7XG5cbiAgICAvLyAnc3R5bGUuY3VycmVudFN0eWxlJyBpcyB1c2VkIGJ5IElFIDw9IDggYW5kICd3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZScgZm9yIGFsbCBvdGhlciBicm93c2Vyc1xuICAgIGluZm8gPSAoJ2dldENvbXB1dGVkU3R5bGUnIGluIHdpbmRvdykgJiYgd2luZG93LmdldENvbXB1dGVkU3R5bGUoc3R5bGUsIG51bGwpIHx8IHN0eWxlLmN1cnJlbnRTdHlsZTtcblxuICAgIHN0eWxlTWVkaWEgPSB7XG4gICAgICBtYXRjaE1lZGl1bShtZWRpYSkge1xuICAgICAgICB2YXIgdGV4dCA9IGBAbWVkaWEgJHttZWRpYX17ICNtYXRjaG1lZGlhanMtdGVzdCB7IHdpZHRoOiAxcHg7IH0gfWA7XG5cbiAgICAgICAgLy8gJ3N0eWxlLnN0eWxlU2hlZXQnIGlzIHVzZWQgYnkgSUUgPD0gOCBhbmQgJ3N0eWxlLnRleHRDb250ZW50JyBmb3IgYWxsIG90aGVyIGJyb3dzZXJzXG4gICAgICAgIGlmIChzdHlsZS5zdHlsZVNoZWV0KSB7XG4gICAgICAgICAgc3R5bGUuc3R5bGVTaGVldC5jc3NUZXh0ID0gdGV4dDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzdHlsZS50ZXh0Q29udGVudCA9IHRleHQ7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBUZXN0IGlmIG1lZGlhIHF1ZXJ5IGlzIHRydWUgb3IgZmFsc2VcbiAgICAgICAgcmV0dXJuIGluZm8ud2lkdGggPT09ICcxcHgnO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBmdW5jdGlvbihtZWRpYSkge1xuICAgIHJldHVybiB7XG4gICAgICBtYXRjaGVzOiBzdHlsZU1lZGlhLm1hdGNoTWVkaXVtKG1lZGlhIHx8ICdhbGwnKSxcbiAgICAgIG1lZGlhOiBtZWRpYSB8fCAnYWxsJ1xuICAgIH07XG4gIH1cbn0oKSk7XG5cbi8vIFRoYW5rIHlvdTogaHR0cHM6Ly9naXRodWIuY29tL3NpbmRyZXNvcmh1cy9xdWVyeS1zdHJpbmdcbmZ1bmN0aW9uIHBhcnNlU3R5bGVUb09iamVjdChzdHIpIHtcbiAgdmFyIHN0eWxlT2JqZWN0ID0ge307XG5cbiAgaWYgKHR5cGVvZiBzdHIgIT09ICdzdHJpbmcnKSB7XG4gICAgcmV0dXJuIHN0eWxlT2JqZWN0O1xuICB9XG5cbiAgc3RyID0gc3RyLnRyaW0oKS5zbGljZSgxLCAtMSk7IC8vIGJyb3dzZXJzIHJlLXF1b3RlIHN0cmluZyBzdHlsZSB2YWx1ZXNcblxuICBpZiAoIXN0cikge1xuICAgIHJldHVybiBzdHlsZU9iamVjdDtcbiAgfVxuXG4gIHN0eWxlT2JqZWN0ID0gc3RyLnNwbGl0KCcmJykucmVkdWNlKGZ1bmN0aW9uKHJldCwgcGFyYW0pIHtcbiAgICB2YXIgcGFydHMgPSBwYXJhbS5yZXBsYWNlKC9cXCsvZywgJyAnKS5zcGxpdCgnPScpO1xuICAgIHZhciBrZXkgPSBwYXJ0c1swXTtcbiAgICB2YXIgdmFsID0gcGFydHNbMV07XG4gICAga2V5ID0gZGVjb2RlVVJJQ29tcG9uZW50KGtleSk7XG5cbiAgICAvLyBtaXNzaW5nIGA9YCBzaG91bGQgYmUgYG51bGxgOlxuICAgIC8vIGh0dHA6Ly93My5vcmcvVFIvMjAxMi9XRC11cmwtMjAxMjA1MjQvI2NvbGxlY3QtdXJsLXBhcmFtZXRlcnNcbiAgICB2YWwgPSB2YWwgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBkZWNvZGVVUklDb21wb25lbnQodmFsKTtcblxuICAgIGlmICghcmV0Lmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgIHJldFtrZXldID0gdmFsO1xuICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShyZXRba2V5XSkpIHtcbiAgICAgIHJldFtrZXldLnB1c2godmFsKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0W2tleV0gPSBbcmV0W2tleV0sIHZhbF07XG4gICAgfVxuICAgIHJldHVybiByZXQ7XG4gIH0sIHt9KTtcblxuICByZXR1cm4gc3R5bGVPYmplY3Q7XG59XG5cbkZvdW5kYXRpb24uTWVkaWFRdWVyeSA9IE1lZGlhUXVlcnk7XG5cbn0oalF1ZXJ5KTtcbiIsIid1c2Ugc3RyaWN0JztcblxuIWZ1bmN0aW9uKCQpIHtcblxuLyoqXG4gKiBNb3Rpb24gbW9kdWxlLlxuICogQG1vZHVsZSBmb3VuZGF0aW9uLm1vdGlvblxuICovXG5cbmNvbnN0IGluaXRDbGFzc2VzICAgPSBbJ211aS1lbnRlcicsICdtdWktbGVhdmUnXTtcbmNvbnN0IGFjdGl2ZUNsYXNzZXMgPSBbJ211aS1lbnRlci1hY3RpdmUnLCAnbXVpLWxlYXZlLWFjdGl2ZSddO1xuXG5jb25zdCBNb3Rpb24gPSB7XG4gIGFuaW1hdGVJbjogZnVuY3Rpb24oZWxlbWVudCwgYW5pbWF0aW9uLCBjYikge1xuICAgIGFuaW1hdGUodHJ1ZSwgZWxlbWVudCwgYW5pbWF0aW9uLCBjYik7XG4gIH0sXG5cbiAgYW5pbWF0ZU91dDogZnVuY3Rpb24oZWxlbWVudCwgYW5pbWF0aW9uLCBjYikge1xuICAgIGFuaW1hdGUoZmFsc2UsIGVsZW1lbnQsIGFuaW1hdGlvbiwgY2IpO1xuICB9XG59XG5cbmZ1bmN0aW9uIE1vdmUoZHVyYXRpb24sIGVsZW0sIGZuKXtcbiAgdmFyIGFuaW0sIHByb2csIHN0YXJ0ID0gbnVsbDtcbiAgLy8gY29uc29sZS5sb2coJ2NhbGxlZCcpO1xuXG4gIGlmIChkdXJhdGlvbiA9PT0gMCkge1xuICAgIGZuLmFwcGx5KGVsZW0pO1xuICAgIGVsZW0udHJpZ2dlcignZmluaXNoZWQuemYuYW5pbWF0ZScsIFtlbGVtXSkudHJpZ2dlckhhbmRsZXIoJ2ZpbmlzaGVkLnpmLmFuaW1hdGUnLCBbZWxlbV0pO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGZ1bmN0aW9uIG1vdmUodHMpe1xuICAgIGlmKCFzdGFydCkgc3RhcnQgPSB0cztcbiAgICAvLyBjb25zb2xlLmxvZyhzdGFydCwgdHMpO1xuICAgIHByb2cgPSB0cyAtIHN0YXJ0O1xuICAgIGZuLmFwcGx5KGVsZW0pO1xuXG4gICAgaWYocHJvZyA8IGR1cmF0aW9uKXsgYW5pbSA9IHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUobW92ZSwgZWxlbSk7IH1cbiAgICBlbHNle1xuICAgICAgd2luZG93LmNhbmNlbEFuaW1hdGlvbkZyYW1lKGFuaW0pO1xuICAgICAgZWxlbS50cmlnZ2VyKCdmaW5pc2hlZC56Zi5hbmltYXRlJywgW2VsZW1dKS50cmlnZ2VySGFuZGxlcignZmluaXNoZWQuemYuYW5pbWF0ZScsIFtlbGVtXSk7XG4gICAgfVxuICB9XG4gIGFuaW0gPSB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKG1vdmUpO1xufVxuXG4vKipcbiAqIEFuaW1hdGVzIGFuIGVsZW1lbnQgaW4gb3Igb3V0IHVzaW5nIGEgQ1NTIHRyYW5zaXRpb24gY2xhc3MuXG4gKiBAZnVuY3Rpb25cbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0ge0Jvb2xlYW59IGlzSW4gLSBEZWZpbmVzIGlmIHRoZSBhbmltYXRpb24gaXMgaW4gb3Igb3V0LlxuICogQHBhcmFtIHtPYmplY3R9IGVsZW1lbnQgLSBqUXVlcnkgb3IgSFRNTCBvYmplY3QgdG8gYW5pbWF0ZS5cbiAqIEBwYXJhbSB7U3RyaW5nfSBhbmltYXRpb24gLSBDU1MgY2xhc3MgdG8gdXNlLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gY2IgLSBDYWxsYmFjayB0byBydW4gd2hlbiBhbmltYXRpb24gaXMgZmluaXNoZWQuXG4gKi9cbmZ1bmN0aW9uIGFuaW1hdGUoaXNJbiwgZWxlbWVudCwgYW5pbWF0aW9uLCBjYikge1xuICBlbGVtZW50ID0gJChlbGVtZW50KS5lcSgwKTtcblxuICBpZiAoIWVsZW1lbnQubGVuZ3RoKSByZXR1cm47XG5cbiAgdmFyIGluaXRDbGFzcyA9IGlzSW4gPyBpbml0Q2xhc3Nlc1swXSA6IGluaXRDbGFzc2VzWzFdO1xuICB2YXIgYWN0aXZlQ2xhc3MgPSBpc0luID8gYWN0aXZlQ2xhc3Nlc1swXSA6IGFjdGl2ZUNsYXNzZXNbMV07XG5cbiAgLy8gU2V0IHVwIHRoZSBhbmltYXRpb25cbiAgcmVzZXQoKTtcblxuICBlbGVtZW50XG4gICAgLmFkZENsYXNzKGFuaW1hdGlvbilcbiAgICAuY3NzKCd0cmFuc2l0aW9uJywgJ25vbmUnKTtcblxuICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgIGVsZW1lbnQuYWRkQ2xhc3MoaW5pdENsYXNzKTtcbiAgICBpZiAoaXNJbikgZWxlbWVudC5zaG93KCk7XG4gIH0pO1xuXG4gIC8vIFN0YXJ0IHRoZSBhbmltYXRpb25cbiAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICBlbGVtZW50WzBdLm9mZnNldFdpZHRoO1xuICAgIGVsZW1lbnRcbiAgICAgIC5jc3MoJ3RyYW5zaXRpb24nLCAnJylcbiAgICAgIC5hZGRDbGFzcyhhY3RpdmVDbGFzcyk7XG4gIH0pO1xuXG4gIC8vIENsZWFuIHVwIHRoZSBhbmltYXRpb24gd2hlbiBpdCBmaW5pc2hlc1xuICBlbGVtZW50Lm9uZShGb3VuZGF0aW9uLnRyYW5zaXRpb25lbmQoZWxlbWVudCksIGZpbmlzaCk7XG5cbiAgLy8gSGlkZXMgdGhlIGVsZW1lbnQgKGZvciBvdXQgYW5pbWF0aW9ucyksIHJlc2V0cyB0aGUgZWxlbWVudCwgYW5kIHJ1bnMgYSBjYWxsYmFja1xuICBmdW5jdGlvbiBmaW5pc2goKSB7XG4gICAgaWYgKCFpc0luKSBlbGVtZW50LmhpZGUoKTtcbiAgICByZXNldCgpO1xuICAgIGlmIChjYikgY2IuYXBwbHkoZWxlbWVudCk7XG4gIH1cblxuICAvLyBSZXNldHMgdHJhbnNpdGlvbnMgYW5kIHJlbW92ZXMgbW90aW9uLXNwZWNpZmljIGNsYXNzZXNcbiAgZnVuY3Rpb24gcmVzZXQoKSB7XG4gICAgZWxlbWVudFswXS5zdHlsZS50cmFuc2l0aW9uRHVyYXRpb24gPSAwO1xuICAgIGVsZW1lbnQucmVtb3ZlQ2xhc3MoYCR7aW5pdENsYXNzfSAke2FjdGl2ZUNsYXNzfSAke2FuaW1hdGlvbn1gKTtcbiAgfVxufVxuXG5Gb3VuZGF0aW9uLk1vdmUgPSBNb3ZlO1xuRm91bmRhdGlvbi5Nb3Rpb24gPSBNb3Rpb247XG5cbn0oalF1ZXJ5KTtcbiIsIid1c2Ugc3RyaWN0JztcblxuIWZ1bmN0aW9uKCQpIHtcblxuY29uc3QgTmVzdCA9IHtcbiAgRmVhdGhlcihtZW51LCB0eXBlID0gJ3pmJykge1xuICAgIG1lbnUuYXR0cigncm9sZScsICdtZW51YmFyJyk7XG5cbiAgICB2YXIgaXRlbXMgPSBtZW51LmZpbmQoJ2xpJykuYXR0cih7J3JvbGUnOiAnbWVudWl0ZW0nfSksXG4gICAgICAgIHN1Yk1lbnVDbGFzcyA9IGBpcy0ke3R5cGV9LXN1Ym1lbnVgLFxuICAgICAgICBzdWJJdGVtQ2xhc3MgPSBgJHtzdWJNZW51Q2xhc3N9LWl0ZW1gLFxuICAgICAgICBoYXNTdWJDbGFzcyA9IGBpcy0ke3R5cGV9LXN1Ym1lbnUtcGFyZW50YDtcblxuICAgIGl0ZW1zLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICB2YXIgJGl0ZW0gPSAkKHRoaXMpLFxuICAgICAgICAgICRzdWIgPSAkaXRlbS5jaGlsZHJlbigndWwnKTtcblxuICAgICAgaWYgKCRzdWIubGVuZ3RoKSB7XG4gICAgICAgICRpdGVtXG4gICAgICAgICAgLmFkZENsYXNzKGhhc1N1YkNsYXNzKVxuICAgICAgICAgIC5hdHRyKHtcbiAgICAgICAgICAgICdhcmlhLWhhc3BvcHVwJzogdHJ1ZSxcbiAgICAgICAgICAgICdhcmlhLWxhYmVsJzogJGl0ZW0uY2hpbGRyZW4oJ2E6Zmlyc3QnKS50ZXh0KClcbiAgICAgICAgICB9KTtcbiAgICAgICAgICAvLyBOb3RlOiAgRHJpbGxkb3ducyBiZWhhdmUgZGlmZmVyZW50bHkgaW4gaG93IHRoZXkgaGlkZSwgYW5kIHNvIG5lZWRcbiAgICAgICAgICAvLyBhZGRpdGlvbmFsIGF0dHJpYnV0ZXMuICBXZSBzaG91bGQgbG9vayBpZiB0aGlzIHBvc3NpYmx5IG92ZXItZ2VuZXJhbGl6ZWRcbiAgICAgICAgICAvLyB1dGlsaXR5IChOZXN0KSBpcyBhcHByb3ByaWF0ZSB3aGVuIHdlIHJld29yayBtZW51cyBpbiA2LjRcbiAgICAgICAgICBpZih0eXBlID09PSAnZHJpbGxkb3duJykge1xuICAgICAgICAgICAgJGl0ZW0uYXR0cih7J2FyaWEtZXhwYW5kZWQnOiBmYWxzZX0pO1xuICAgICAgICAgIH1cblxuICAgICAgICAkc3ViXG4gICAgICAgICAgLmFkZENsYXNzKGBzdWJtZW51ICR7c3ViTWVudUNsYXNzfWApXG4gICAgICAgICAgLmF0dHIoe1xuICAgICAgICAgICAgJ2RhdGEtc3VibWVudSc6ICcnLFxuICAgICAgICAgICAgJ3JvbGUnOiAnbWVudSdcbiAgICAgICAgICB9KTtcbiAgICAgICAgaWYodHlwZSA9PT0gJ2RyaWxsZG93bicpIHtcbiAgICAgICAgICAkc3ViLmF0dHIoeydhcmlhLWhpZGRlbic6IHRydWV9KTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoJGl0ZW0ucGFyZW50KCdbZGF0YS1zdWJtZW51XScpLmxlbmd0aCkge1xuICAgICAgICAkaXRlbS5hZGRDbGFzcyhgaXMtc3VibWVudS1pdGVtICR7c3ViSXRlbUNsYXNzfWApO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgcmV0dXJuO1xuICB9LFxuXG4gIEJ1cm4obWVudSwgdHlwZSkge1xuICAgIHZhciAvL2l0ZW1zID0gbWVudS5maW5kKCdsaScpLFxuICAgICAgICBzdWJNZW51Q2xhc3MgPSBgaXMtJHt0eXBlfS1zdWJtZW51YCxcbiAgICAgICAgc3ViSXRlbUNsYXNzID0gYCR7c3ViTWVudUNsYXNzfS1pdGVtYCxcbiAgICAgICAgaGFzU3ViQ2xhc3MgPSBgaXMtJHt0eXBlfS1zdWJtZW51LXBhcmVudGA7XG5cbiAgICBtZW51XG4gICAgICAuZmluZCgnPmxpLCAubWVudSwgLm1lbnUgPiBsaScpXG4gICAgICAucmVtb3ZlQ2xhc3MoYCR7c3ViTWVudUNsYXNzfSAke3N1Ykl0ZW1DbGFzc30gJHtoYXNTdWJDbGFzc30gaXMtc3VibWVudS1pdGVtIHN1Ym1lbnUgaXMtYWN0aXZlYClcbiAgICAgIC5yZW1vdmVBdHRyKCdkYXRhLXN1Ym1lbnUnKS5jc3MoJ2Rpc3BsYXknLCAnJyk7XG5cbiAgICAvLyBjb25zb2xlLmxvZyggICAgICBtZW51LmZpbmQoJy4nICsgc3ViTWVudUNsYXNzICsgJywgLicgKyBzdWJJdGVtQ2xhc3MgKyAnLCAuaGFzLXN1Ym1lbnUsIC5pcy1zdWJtZW51LWl0ZW0sIC5zdWJtZW51LCBbZGF0YS1zdWJtZW51XScpXG4gICAgLy8gICAgICAgICAgIC5yZW1vdmVDbGFzcyhzdWJNZW51Q2xhc3MgKyAnICcgKyBzdWJJdGVtQ2xhc3MgKyAnIGhhcy1zdWJtZW51IGlzLXN1Ym1lbnUtaXRlbSBzdWJtZW51JylcbiAgICAvLyAgICAgICAgICAgLnJlbW92ZUF0dHIoJ2RhdGEtc3VibWVudScpKTtcbiAgICAvLyBpdGVtcy5lYWNoKGZ1bmN0aW9uKCl7XG4gICAgLy8gICB2YXIgJGl0ZW0gPSAkKHRoaXMpLFxuICAgIC8vICAgICAgICRzdWIgPSAkaXRlbS5jaGlsZHJlbigndWwnKTtcbiAgICAvLyAgIGlmKCRpdGVtLnBhcmVudCgnW2RhdGEtc3VibWVudV0nKS5sZW5ndGgpe1xuICAgIC8vICAgICAkaXRlbS5yZW1vdmVDbGFzcygnaXMtc3VibWVudS1pdGVtICcgKyBzdWJJdGVtQ2xhc3MpO1xuICAgIC8vICAgfVxuICAgIC8vICAgaWYoJHN1Yi5sZW5ndGgpe1xuICAgIC8vICAgICAkaXRlbS5yZW1vdmVDbGFzcygnaGFzLXN1Ym1lbnUnKTtcbiAgICAvLyAgICAgJHN1Yi5yZW1vdmVDbGFzcygnc3VibWVudSAnICsgc3ViTWVudUNsYXNzKS5yZW1vdmVBdHRyKCdkYXRhLXN1Ym1lbnUnKTtcbiAgICAvLyAgIH1cbiAgICAvLyB9KTtcbiAgfVxufVxuXG5Gb3VuZGF0aW9uLk5lc3QgPSBOZXN0O1xuXG59KGpRdWVyeSk7XG4iLCIndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbmZ1bmN0aW9uIFRpbWVyKGVsZW0sIG9wdGlvbnMsIGNiKSB7XG4gIHZhciBfdGhpcyA9IHRoaXMsXG4gICAgICBkdXJhdGlvbiA9IG9wdGlvbnMuZHVyYXRpb24sLy9vcHRpb25zIGlzIGFuIG9iamVjdCBmb3IgZWFzaWx5IGFkZGluZyBmZWF0dXJlcyBsYXRlci5cbiAgICAgIG5hbWVTcGFjZSA9IE9iamVjdC5rZXlzKGVsZW0uZGF0YSgpKVswXSB8fCAndGltZXInLFxuICAgICAgcmVtYWluID0gLTEsXG4gICAgICBzdGFydCxcbiAgICAgIHRpbWVyO1xuXG4gIHRoaXMuaXNQYXVzZWQgPSBmYWxzZTtcblxuICB0aGlzLnJlc3RhcnQgPSBmdW5jdGlvbigpIHtcbiAgICByZW1haW4gPSAtMTtcbiAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgIHRoaXMuc3RhcnQoKTtcbiAgfVxuXG4gIHRoaXMuc3RhcnQgPSBmdW5jdGlvbigpIHtcbiAgICB0aGlzLmlzUGF1c2VkID0gZmFsc2U7XG4gICAgLy8gaWYoIWVsZW0uZGF0YSgncGF1c2VkJykpeyByZXR1cm4gZmFsc2U7IH0vL21heWJlIGltcGxlbWVudCB0aGlzIHNhbml0eSBjaGVjayBpZiB1c2VkIGZvciBvdGhlciB0aGluZ3MuXG4gICAgY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICByZW1haW4gPSByZW1haW4gPD0gMCA/IGR1cmF0aW9uIDogcmVtYWluO1xuICAgIGVsZW0uZGF0YSgncGF1c2VkJywgZmFsc2UpO1xuICAgIHN0YXJ0ID0gRGF0ZS5ub3coKTtcbiAgICB0aW1lciA9IHNldFRpbWVvdXQoZnVuY3Rpb24oKXtcbiAgICAgIGlmKG9wdGlvbnMuaW5maW5pdGUpe1xuICAgICAgICBfdGhpcy5yZXN0YXJ0KCk7Ly9yZXJ1biB0aGUgdGltZXIuXG4gICAgICB9XG4gICAgICBpZiAoY2IgJiYgdHlwZW9mIGNiID09PSAnZnVuY3Rpb24nKSB7IGNiKCk7IH1cbiAgICB9LCByZW1haW4pO1xuICAgIGVsZW0udHJpZ2dlcihgdGltZXJzdGFydC56Zi4ke25hbWVTcGFjZX1gKTtcbiAgfVxuXG4gIHRoaXMucGF1c2UgPSBmdW5jdGlvbigpIHtcbiAgICB0aGlzLmlzUGF1c2VkID0gdHJ1ZTtcbiAgICAvL2lmKGVsZW0uZGF0YSgncGF1c2VkJykpeyByZXR1cm4gZmFsc2U7IH0vL21heWJlIGltcGxlbWVudCB0aGlzIHNhbml0eSBjaGVjayBpZiB1c2VkIGZvciBvdGhlciB0aGluZ3MuXG4gICAgY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICBlbGVtLmRhdGEoJ3BhdXNlZCcsIHRydWUpO1xuICAgIHZhciBlbmQgPSBEYXRlLm5vdygpO1xuICAgIHJlbWFpbiA9IHJlbWFpbiAtIChlbmQgLSBzdGFydCk7XG4gICAgZWxlbS50cmlnZ2VyKGB0aW1lcnBhdXNlZC56Zi4ke25hbWVTcGFjZX1gKTtcbiAgfVxufVxuXG4vKipcbiAqIFJ1bnMgYSBjYWxsYmFjayBmdW5jdGlvbiB3aGVuIGltYWdlcyBhcmUgZnVsbHkgbG9hZGVkLlxuICogQHBhcmFtIHtPYmplY3R9IGltYWdlcyAtIEltYWdlKHMpIHRvIGNoZWNrIGlmIGxvYWRlZC5cbiAqIEBwYXJhbSB7RnVuY30gY2FsbGJhY2sgLSBGdW5jdGlvbiB0byBleGVjdXRlIHdoZW4gaW1hZ2UgaXMgZnVsbHkgbG9hZGVkLlxuICovXG5mdW5jdGlvbiBvbkltYWdlc0xvYWRlZChpbWFnZXMsIGNhbGxiYWNrKXtcbiAgdmFyIHNlbGYgPSB0aGlzLFxuICAgICAgdW5sb2FkZWQgPSBpbWFnZXMubGVuZ3RoO1xuXG4gIGlmICh1bmxvYWRlZCA9PT0gMCkge1xuICAgIGNhbGxiYWNrKCk7XG4gIH1cblxuICBpbWFnZXMuZWFjaChmdW5jdGlvbigpIHtcbiAgICAvLyBDaGVjayBpZiBpbWFnZSBpcyBsb2FkZWRcbiAgICBpZiAodGhpcy5jb21wbGV0ZSB8fCAodGhpcy5yZWFkeVN0YXRlID09PSA0KSB8fCAodGhpcy5yZWFkeVN0YXRlID09PSAnY29tcGxldGUnKSkge1xuICAgICAgc2luZ2xlSW1hZ2VMb2FkZWQoKTtcbiAgICB9XG4gICAgLy8gRm9yY2UgbG9hZCB0aGUgaW1hZ2VcbiAgICBlbHNlIHtcbiAgICAgIC8vIGZpeCBmb3IgSUUuIFNlZSBodHRwczovL2Nzcy10cmlja3MuY29tL3NuaXBwZXRzL2pxdWVyeS9maXhpbmctbG9hZC1pbi1pZS1mb3ItY2FjaGVkLWltYWdlcy9cbiAgICAgIHZhciBzcmMgPSAkKHRoaXMpLmF0dHIoJ3NyYycpO1xuICAgICAgJCh0aGlzKS5hdHRyKCdzcmMnLCBzcmMgKyAnPycgKyAobmV3IERhdGUoKS5nZXRUaW1lKCkpKTtcbiAgICAgICQodGhpcykub25lKCdsb2FkJywgZnVuY3Rpb24oKSB7XG4gICAgICAgIHNpbmdsZUltYWdlTG9hZGVkKCk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIHNpbmdsZUltYWdlTG9hZGVkKCkge1xuICAgIHVubG9hZGVkLS07XG4gICAgaWYgKHVubG9hZGVkID09PSAwKSB7XG4gICAgICBjYWxsYmFjaygpO1xuICAgIH1cbiAgfVxufVxuXG5Gb3VuZGF0aW9uLlRpbWVyID0gVGltZXI7XG5Gb3VuZGF0aW9uLm9uSW1hZ2VzTG9hZGVkID0gb25JbWFnZXNMb2FkZWQ7XG5cbn0oalF1ZXJ5KTtcbiIsIi8vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbi8vKipXb3JrIGluc3BpcmVkIGJ5IG11bHRpcGxlIGpxdWVyeSBzd2lwZSBwbHVnaW5zKipcbi8vKipEb25lIGJ5IFlvaGFpIEFyYXJhdCAqKioqKioqKioqKioqKioqKioqKioqKioqKipcbi8vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbihmdW5jdGlvbigkKSB7XG5cbiAgJC5zcG90U3dpcGUgPSB7XG4gICAgdmVyc2lvbjogJzEuMC4wJyxcbiAgICBlbmFibGVkOiAnb250b3VjaHN0YXJ0JyBpbiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQsXG4gICAgcHJldmVudERlZmF1bHQ6IGZhbHNlLFxuICAgIG1vdmVUaHJlc2hvbGQ6IDc1LFxuICAgIHRpbWVUaHJlc2hvbGQ6IDIwMFxuICB9O1xuXG4gIHZhciAgIHN0YXJ0UG9zWCxcbiAgICAgICAgc3RhcnRQb3NZLFxuICAgICAgICBzdGFydFRpbWUsXG4gICAgICAgIGVsYXBzZWRUaW1lLFxuICAgICAgICBpc01vdmluZyA9IGZhbHNlO1xuXG4gIGZ1bmN0aW9uIG9uVG91Y2hFbmQoKSB7XG4gICAgLy8gIGFsZXJ0KHRoaXMpO1xuICAgIHRoaXMucmVtb3ZlRXZlbnRMaXN0ZW5lcigndG91Y2htb3ZlJywgb25Ub3VjaE1vdmUpO1xuICAgIHRoaXMucmVtb3ZlRXZlbnRMaXN0ZW5lcigndG91Y2hlbmQnLCBvblRvdWNoRW5kKTtcbiAgICBpc01vdmluZyA9IGZhbHNlO1xuICB9XG5cbiAgZnVuY3Rpb24gb25Ub3VjaE1vdmUoZSkge1xuICAgIGlmICgkLnNwb3RTd2lwZS5wcmV2ZW50RGVmYXVsdCkgeyBlLnByZXZlbnREZWZhdWx0KCk7IH1cbiAgICBpZihpc01vdmluZykge1xuICAgICAgdmFyIHggPSBlLnRvdWNoZXNbMF0ucGFnZVg7XG4gICAgICB2YXIgeSA9IGUudG91Y2hlc1swXS5wYWdlWTtcbiAgICAgIHZhciBkeCA9IHN0YXJ0UG9zWCAtIHg7XG4gICAgICB2YXIgZHkgPSBzdGFydFBvc1kgLSB5O1xuICAgICAgdmFyIGRpcjtcbiAgICAgIGVsYXBzZWRUaW1lID0gbmV3IERhdGUoKS5nZXRUaW1lKCkgLSBzdGFydFRpbWU7XG4gICAgICBpZihNYXRoLmFicyhkeCkgPj0gJC5zcG90U3dpcGUubW92ZVRocmVzaG9sZCAmJiBlbGFwc2VkVGltZSA8PSAkLnNwb3RTd2lwZS50aW1lVGhyZXNob2xkKSB7XG4gICAgICAgIGRpciA9IGR4ID4gMCA/ICdsZWZ0JyA6ICdyaWdodCc7XG4gICAgICB9XG4gICAgICAvLyBlbHNlIGlmKE1hdGguYWJzKGR5KSA+PSAkLnNwb3RTd2lwZS5tb3ZlVGhyZXNob2xkICYmIGVsYXBzZWRUaW1lIDw9ICQuc3BvdFN3aXBlLnRpbWVUaHJlc2hvbGQpIHtcbiAgICAgIC8vICAgZGlyID0gZHkgPiAwID8gJ2Rvd24nIDogJ3VwJztcbiAgICAgIC8vIH1cbiAgICAgIGlmKGRpcikge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIG9uVG91Y2hFbmQuY2FsbCh0aGlzKTtcbiAgICAgICAgJCh0aGlzKS50cmlnZ2VyKCdzd2lwZScsIGRpcikudHJpZ2dlcihgc3dpcGUke2Rpcn1gKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBvblRvdWNoU3RhcnQoZSkge1xuICAgIGlmIChlLnRvdWNoZXMubGVuZ3RoID09IDEpIHtcbiAgICAgIHN0YXJ0UG9zWCA9IGUudG91Y2hlc1swXS5wYWdlWDtcbiAgICAgIHN0YXJ0UG9zWSA9IGUudG91Y2hlc1swXS5wYWdlWTtcbiAgICAgIGlzTW92aW5nID0gdHJ1ZTtcbiAgICAgIHN0YXJ0VGltZSA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgdGhpcy5hZGRFdmVudExpc3RlbmVyKCd0b3VjaG1vdmUnLCBvblRvdWNoTW92ZSwgZmFsc2UpO1xuICAgICAgdGhpcy5hZGRFdmVudExpc3RlbmVyKCd0b3VjaGVuZCcsIG9uVG91Y2hFbmQsIGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBpbml0KCkge1xuICAgIHRoaXMuYWRkRXZlbnRMaXN0ZW5lciAmJiB0aGlzLmFkZEV2ZW50TGlzdGVuZXIoJ3RvdWNoc3RhcnQnLCBvblRvdWNoU3RhcnQsIGZhbHNlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHRlYXJkb3duKCkge1xuICAgIHRoaXMucmVtb3ZlRXZlbnRMaXN0ZW5lcigndG91Y2hzdGFydCcsIG9uVG91Y2hTdGFydCk7XG4gIH1cblxuICAkLmV2ZW50LnNwZWNpYWwuc3dpcGUgPSB7IHNldHVwOiBpbml0IH07XG5cbiAgJC5lYWNoKFsnbGVmdCcsICd1cCcsICdkb3duJywgJ3JpZ2h0J10sIGZ1bmN0aW9uICgpIHtcbiAgICAkLmV2ZW50LnNwZWNpYWxbYHN3aXBlJHt0aGlzfWBdID0geyBzZXR1cDogZnVuY3Rpb24oKXtcbiAgICAgICQodGhpcykub24oJ3N3aXBlJywgJC5ub29wKTtcbiAgICB9IH07XG4gIH0pO1xufSkoalF1ZXJ5KTtcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiBNZXRob2QgZm9yIGFkZGluZyBwc3VlZG8gZHJhZyBldmVudHMgdG8gZWxlbWVudHMgKlxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbiFmdW5jdGlvbigkKXtcbiAgJC5mbi5hZGRUb3VjaCA9IGZ1bmN0aW9uKCl7XG4gICAgdGhpcy5lYWNoKGZ1bmN0aW9uKGksZWwpe1xuICAgICAgJChlbCkuYmluZCgndG91Y2hzdGFydCB0b3VjaG1vdmUgdG91Y2hlbmQgdG91Y2hjYW5jZWwnLGZ1bmN0aW9uKCl7XG4gICAgICAgIC8vd2UgcGFzcyB0aGUgb3JpZ2luYWwgZXZlbnQgb2JqZWN0IGJlY2F1c2UgdGhlIGpRdWVyeSBldmVudFxuICAgICAgICAvL29iamVjdCBpcyBub3JtYWxpemVkIHRvIHczYyBzcGVjcyBhbmQgZG9lcyBub3QgcHJvdmlkZSB0aGUgVG91Y2hMaXN0XG4gICAgICAgIGhhbmRsZVRvdWNoKGV2ZW50KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgdmFyIGhhbmRsZVRvdWNoID0gZnVuY3Rpb24oZXZlbnQpe1xuICAgICAgdmFyIHRvdWNoZXMgPSBldmVudC5jaGFuZ2VkVG91Y2hlcyxcbiAgICAgICAgICBmaXJzdCA9IHRvdWNoZXNbMF0sXG4gICAgICAgICAgZXZlbnRUeXBlcyA9IHtcbiAgICAgICAgICAgIHRvdWNoc3RhcnQ6ICdtb3VzZWRvd24nLFxuICAgICAgICAgICAgdG91Y2htb3ZlOiAnbW91c2Vtb3ZlJyxcbiAgICAgICAgICAgIHRvdWNoZW5kOiAnbW91c2V1cCdcbiAgICAgICAgICB9LFxuICAgICAgICAgIHR5cGUgPSBldmVudFR5cGVzW2V2ZW50LnR5cGVdLFxuICAgICAgICAgIHNpbXVsYXRlZEV2ZW50XG4gICAgICAgIDtcblxuICAgICAgaWYoJ01vdXNlRXZlbnQnIGluIHdpbmRvdyAmJiB0eXBlb2Ygd2luZG93Lk1vdXNlRXZlbnQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgc2ltdWxhdGVkRXZlbnQgPSBuZXcgd2luZG93Lk1vdXNlRXZlbnQodHlwZSwge1xuICAgICAgICAgICdidWJibGVzJzogdHJ1ZSxcbiAgICAgICAgICAnY2FuY2VsYWJsZSc6IHRydWUsXG4gICAgICAgICAgJ3NjcmVlblgnOiBmaXJzdC5zY3JlZW5YLFxuICAgICAgICAgICdzY3JlZW5ZJzogZmlyc3Quc2NyZWVuWSxcbiAgICAgICAgICAnY2xpZW50WCc6IGZpcnN0LmNsaWVudFgsXG4gICAgICAgICAgJ2NsaWVudFknOiBmaXJzdC5jbGllbnRZXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2ltdWxhdGVkRXZlbnQgPSBkb2N1bWVudC5jcmVhdGVFdmVudCgnTW91c2VFdmVudCcpO1xuICAgICAgICBzaW11bGF0ZWRFdmVudC5pbml0TW91c2VFdmVudCh0eXBlLCB0cnVlLCB0cnVlLCB3aW5kb3csIDEsIGZpcnN0LnNjcmVlblgsIGZpcnN0LnNjcmVlblksIGZpcnN0LmNsaWVudFgsIGZpcnN0LmNsaWVudFksIGZhbHNlLCBmYWxzZSwgZmFsc2UsIGZhbHNlLCAwLypsZWZ0Ki8sIG51bGwpO1xuICAgICAgfVxuICAgICAgZmlyc3QudGFyZ2V0LmRpc3BhdGNoRXZlbnQoc2ltdWxhdGVkRXZlbnQpO1xuICAgIH07XG4gIH07XG59KGpRdWVyeSk7XG5cblxuLy8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4vLyoqRnJvbSB0aGUgalF1ZXJ5IE1vYmlsZSBMaWJyYXJ5Kipcbi8vKipuZWVkIHRvIHJlY3JlYXRlIGZ1bmN0aW9uYWxpdHkqKlxuLy8qKmFuZCB0cnkgdG8gaW1wcm92ZSBpZiBwb3NzaWJsZSoqXG4vLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcblxuLyogUmVtb3ZpbmcgdGhlIGpRdWVyeSBmdW5jdGlvbiAqKioqXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcblxuKGZ1bmN0aW9uKCAkLCB3aW5kb3csIHVuZGVmaW5lZCApIHtcblxuXHR2YXIgJGRvY3VtZW50ID0gJCggZG9jdW1lbnQgKSxcblx0XHQvLyBzdXBwb3J0VG91Y2ggPSAkLm1vYmlsZS5zdXBwb3J0LnRvdWNoLFxuXHRcdHRvdWNoU3RhcnRFdmVudCA9ICd0b3VjaHN0YXJ0Jy8vc3VwcG9ydFRvdWNoID8gXCJ0b3VjaHN0YXJ0XCIgOiBcIm1vdXNlZG93blwiLFxuXHRcdHRvdWNoU3RvcEV2ZW50ID0gJ3RvdWNoZW5kJy8vc3VwcG9ydFRvdWNoID8gXCJ0b3VjaGVuZFwiIDogXCJtb3VzZXVwXCIsXG5cdFx0dG91Y2hNb3ZlRXZlbnQgPSAndG91Y2htb3ZlJy8vc3VwcG9ydFRvdWNoID8gXCJ0b3VjaG1vdmVcIiA6IFwibW91c2Vtb3ZlXCI7XG5cblx0Ly8gc2V0dXAgbmV3IGV2ZW50IHNob3J0Y3V0c1xuXHQkLmVhY2goICggXCJ0b3VjaHN0YXJ0IHRvdWNobW92ZSB0b3VjaGVuZCBcIiArXG5cdFx0XCJzd2lwZSBzd2lwZWxlZnQgc3dpcGVyaWdodFwiICkuc3BsaXQoIFwiIFwiICksIGZ1bmN0aW9uKCBpLCBuYW1lICkge1xuXG5cdFx0JC5mblsgbmFtZSBdID0gZnVuY3Rpb24oIGZuICkge1xuXHRcdFx0cmV0dXJuIGZuID8gdGhpcy5iaW5kKCBuYW1lLCBmbiApIDogdGhpcy50cmlnZ2VyKCBuYW1lICk7XG5cdFx0fTtcblxuXHRcdC8vIGpRdWVyeSA8IDEuOFxuXHRcdGlmICggJC5hdHRyRm4gKSB7XG5cdFx0XHQkLmF0dHJGblsgbmFtZSBdID0gdHJ1ZTtcblx0XHR9XG5cdH0pO1xuXG5cdGZ1bmN0aW9uIHRyaWdnZXJDdXN0b21FdmVudCggb2JqLCBldmVudFR5cGUsIGV2ZW50LCBidWJibGUgKSB7XG5cdFx0dmFyIG9yaWdpbmFsVHlwZSA9IGV2ZW50LnR5cGU7XG5cdFx0ZXZlbnQudHlwZSA9IGV2ZW50VHlwZTtcblx0XHRpZiAoIGJ1YmJsZSApIHtcblx0XHRcdCQuZXZlbnQudHJpZ2dlciggZXZlbnQsIHVuZGVmaW5lZCwgb2JqICk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdCQuZXZlbnQuZGlzcGF0Y2guY2FsbCggb2JqLCBldmVudCApO1xuXHRcdH1cblx0XHRldmVudC50eXBlID0gb3JpZ2luYWxUeXBlO1xuXHR9XG5cblx0Ly8gYWxzbyBoYW5kbGVzIHRhcGhvbGRcblxuXHQvLyBBbHNvIGhhbmRsZXMgc3dpcGVsZWZ0LCBzd2lwZXJpZ2h0XG5cdCQuZXZlbnQuc3BlY2lhbC5zd2lwZSA9IHtcblxuXHRcdC8vIE1vcmUgdGhhbiB0aGlzIGhvcml6b250YWwgZGlzcGxhY2VtZW50LCBhbmQgd2Ugd2lsbCBzdXBwcmVzcyBzY3JvbGxpbmcuXG5cdFx0c2Nyb2xsU3VwcmVzc2lvblRocmVzaG9sZDogMzAsXG5cblx0XHQvLyBNb3JlIHRpbWUgdGhhbiB0aGlzLCBhbmQgaXQgaXNuJ3QgYSBzd2lwZS5cblx0XHRkdXJhdGlvblRocmVzaG9sZDogMTAwMCxcblxuXHRcdC8vIFN3aXBlIGhvcml6b250YWwgZGlzcGxhY2VtZW50IG11c3QgYmUgbW9yZSB0aGFuIHRoaXMuXG5cdFx0aG9yaXpvbnRhbERpc3RhbmNlVGhyZXNob2xkOiB3aW5kb3cuZGV2aWNlUGl4ZWxSYXRpbyA+PSAyID8gMTUgOiAzMCxcblxuXHRcdC8vIFN3aXBlIHZlcnRpY2FsIGRpc3BsYWNlbWVudCBtdXN0IGJlIGxlc3MgdGhhbiB0aGlzLlxuXHRcdHZlcnRpY2FsRGlzdGFuY2VUaHJlc2hvbGQ6IHdpbmRvdy5kZXZpY2VQaXhlbFJhdGlvID49IDIgPyAxNSA6IDMwLFxuXG5cdFx0Z2V0TG9jYXRpb246IGZ1bmN0aW9uICggZXZlbnQgKSB7XG5cdFx0XHR2YXIgd2luUGFnZVggPSB3aW5kb3cucGFnZVhPZmZzZXQsXG5cdFx0XHRcdHdpblBhZ2VZID0gd2luZG93LnBhZ2VZT2Zmc2V0LFxuXHRcdFx0XHR4ID0gZXZlbnQuY2xpZW50WCxcblx0XHRcdFx0eSA9IGV2ZW50LmNsaWVudFk7XG5cblx0XHRcdGlmICggZXZlbnQucGFnZVkgPT09IDAgJiYgTWF0aC5mbG9vciggeSApID4gTWF0aC5mbG9vciggZXZlbnQucGFnZVkgKSB8fFxuXHRcdFx0XHRldmVudC5wYWdlWCA9PT0gMCAmJiBNYXRoLmZsb29yKCB4ICkgPiBNYXRoLmZsb29yKCBldmVudC5wYWdlWCApICkge1xuXG5cdFx0XHRcdC8vIGlPUzQgY2xpZW50WC9jbGllbnRZIGhhdmUgdGhlIHZhbHVlIHRoYXQgc2hvdWxkIGhhdmUgYmVlblxuXHRcdFx0XHQvLyBpbiBwYWdlWC9wYWdlWS4gV2hpbGUgcGFnZVgvcGFnZS8gaGF2ZSB0aGUgdmFsdWUgMFxuXHRcdFx0XHR4ID0geCAtIHdpblBhZ2VYO1xuXHRcdFx0XHR5ID0geSAtIHdpblBhZ2VZO1xuXHRcdFx0fSBlbHNlIGlmICggeSA8ICggZXZlbnQucGFnZVkgLSB3aW5QYWdlWSkgfHwgeCA8ICggZXZlbnQucGFnZVggLSB3aW5QYWdlWCApICkge1xuXG5cdFx0XHRcdC8vIFNvbWUgQW5kcm9pZCBicm93c2VycyBoYXZlIHRvdGFsbHkgYm9ndXMgdmFsdWVzIGZvciBjbGllbnRYL1lcblx0XHRcdFx0Ly8gd2hlbiBzY3JvbGxpbmcvem9vbWluZyBhIHBhZ2UuIERldGVjdGFibGUgc2luY2UgY2xpZW50WC9jbGllbnRZXG5cdFx0XHRcdC8vIHNob3VsZCBuZXZlciBiZSBzbWFsbGVyIHRoYW4gcGFnZVgvcGFnZVkgbWludXMgcGFnZSBzY3JvbGxcblx0XHRcdFx0eCA9IGV2ZW50LnBhZ2VYIC0gd2luUGFnZVg7XG5cdFx0XHRcdHkgPSBldmVudC5wYWdlWSAtIHdpblBhZ2VZO1xuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHR4OiB4LFxuXHRcdFx0XHR5OiB5XG5cdFx0XHR9O1xuXHRcdH0sXG5cblx0XHRzdGFydDogZnVuY3Rpb24oIGV2ZW50ICkge1xuXHRcdFx0dmFyIGRhdGEgPSBldmVudC5vcmlnaW5hbEV2ZW50LnRvdWNoZXMgP1xuXHRcdFx0XHRcdGV2ZW50Lm9yaWdpbmFsRXZlbnQudG91Y2hlc1sgMCBdIDogZXZlbnQsXG5cdFx0XHRcdGxvY2F0aW9uID0gJC5ldmVudC5zcGVjaWFsLnN3aXBlLmdldExvY2F0aW9uKCBkYXRhICk7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0dGltZTogKCBuZXcgRGF0ZSgpICkuZ2V0VGltZSgpLFxuXHRcdFx0XHRcdFx0Y29vcmRzOiBbIGxvY2F0aW9uLngsIGxvY2F0aW9uLnkgXSxcblx0XHRcdFx0XHRcdG9yaWdpbjogJCggZXZlbnQudGFyZ2V0IClcblx0XHRcdFx0XHR9O1xuXHRcdH0sXG5cblx0XHRzdG9wOiBmdW5jdGlvbiggZXZlbnQgKSB7XG5cdFx0XHR2YXIgZGF0YSA9IGV2ZW50Lm9yaWdpbmFsRXZlbnQudG91Y2hlcyA/XG5cdFx0XHRcdFx0ZXZlbnQub3JpZ2luYWxFdmVudC50b3VjaGVzWyAwIF0gOiBldmVudCxcblx0XHRcdFx0bG9jYXRpb24gPSAkLmV2ZW50LnNwZWNpYWwuc3dpcGUuZ2V0TG9jYXRpb24oIGRhdGEgKTtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0XHR0aW1lOiAoIG5ldyBEYXRlKCkgKS5nZXRUaW1lKCksXG5cdFx0XHRcdFx0XHRjb29yZHM6IFsgbG9jYXRpb24ueCwgbG9jYXRpb24ueSBdXG5cdFx0XHRcdFx0fTtcblx0XHR9LFxuXG5cdFx0aGFuZGxlU3dpcGU6IGZ1bmN0aW9uKCBzdGFydCwgc3RvcCwgdGhpc09iamVjdCwgb3JpZ1RhcmdldCApIHtcblx0XHRcdGlmICggc3RvcC50aW1lIC0gc3RhcnQudGltZSA8ICQuZXZlbnQuc3BlY2lhbC5zd2lwZS5kdXJhdGlvblRocmVzaG9sZCAmJlxuXHRcdFx0XHRNYXRoLmFicyggc3RhcnQuY29vcmRzWyAwIF0gLSBzdG9wLmNvb3Jkc1sgMCBdICkgPiAkLmV2ZW50LnNwZWNpYWwuc3dpcGUuaG9yaXpvbnRhbERpc3RhbmNlVGhyZXNob2xkICYmXG5cdFx0XHRcdE1hdGguYWJzKCBzdGFydC5jb29yZHNbIDEgXSAtIHN0b3AuY29vcmRzWyAxIF0gKSA8ICQuZXZlbnQuc3BlY2lhbC5zd2lwZS52ZXJ0aWNhbERpc3RhbmNlVGhyZXNob2xkICkge1xuXHRcdFx0XHR2YXIgZGlyZWN0aW9uID0gc3RhcnQuY29vcmRzWzBdID4gc3RvcC5jb29yZHNbIDAgXSA/IFwic3dpcGVsZWZ0XCIgOiBcInN3aXBlcmlnaHRcIjtcblxuXHRcdFx0XHR0cmlnZ2VyQ3VzdG9tRXZlbnQoIHRoaXNPYmplY3QsIFwic3dpcGVcIiwgJC5FdmVudCggXCJzd2lwZVwiLCB7IHRhcmdldDogb3JpZ1RhcmdldCwgc3dpcGVzdGFydDogc3RhcnQsIHN3aXBlc3RvcDogc3RvcCB9KSwgdHJ1ZSApO1xuXHRcdFx0XHR0cmlnZ2VyQ3VzdG9tRXZlbnQoIHRoaXNPYmplY3QsIGRpcmVjdGlvbiwkLkV2ZW50KCBkaXJlY3Rpb24sIHsgdGFyZ2V0OiBvcmlnVGFyZ2V0LCBzd2lwZXN0YXJ0OiBzdGFydCwgc3dpcGVzdG9wOiBzdG9wIH0gKSwgdHJ1ZSApO1xuXHRcdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBmYWxzZTtcblxuXHRcdH0sXG5cblx0XHQvLyBUaGlzIHNlcnZlcyBhcyBhIGZsYWcgdG8gZW5zdXJlIHRoYXQgYXQgbW9zdCBvbmUgc3dpcGUgZXZlbnQgZXZlbnQgaXNcblx0XHQvLyBpbiB3b3JrIGF0IGFueSBnaXZlbiB0aW1lXG5cdFx0ZXZlbnRJblByb2dyZXNzOiBmYWxzZSxcblxuXHRcdHNldHVwOiBmdW5jdGlvbigpIHtcblx0XHRcdHZhciBldmVudHMsXG5cdFx0XHRcdHRoaXNPYmplY3QgPSB0aGlzLFxuXHRcdFx0XHQkdGhpcyA9ICQoIHRoaXNPYmplY3QgKSxcblx0XHRcdFx0Y29udGV4dCA9IHt9O1xuXG5cdFx0XHQvLyBSZXRyaWV2ZSB0aGUgZXZlbnRzIGRhdGEgZm9yIHRoaXMgZWxlbWVudCBhbmQgYWRkIHRoZSBzd2lwZSBjb250ZXh0XG5cdFx0XHRldmVudHMgPSAkLmRhdGEoIHRoaXMsIFwibW9iaWxlLWV2ZW50c1wiICk7XG5cdFx0XHRpZiAoICFldmVudHMgKSB7XG5cdFx0XHRcdGV2ZW50cyA9IHsgbGVuZ3RoOiAwIH07XG5cdFx0XHRcdCQuZGF0YSggdGhpcywgXCJtb2JpbGUtZXZlbnRzXCIsIGV2ZW50cyApO1xuXHRcdFx0fVxuXHRcdFx0ZXZlbnRzLmxlbmd0aCsrO1xuXHRcdFx0ZXZlbnRzLnN3aXBlID0gY29udGV4dDtcblxuXHRcdFx0Y29udGV4dC5zdGFydCA9IGZ1bmN0aW9uKCBldmVudCApIHtcblxuXHRcdFx0XHQvLyBCYWlsIGlmIHdlJ3JlIGFscmVhZHkgd29ya2luZyBvbiBhIHN3aXBlIGV2ZW50XG5cdFx0XHRcdGlmICggJC5ldmVudC5zcGVjaWFsLnN3aXBlLmV2ZW50SW5Qcm9ncmVzcyApIHtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblx0XHRcdFx0JC5ldmVudC5zcGVjaWFsLnN3aXBlLmV2ZW50SW5Qcm9ncmVzcyA9IHRydWU7XG5cblx0XHRcdFx0dmFyIHN0b3AsXG5cdFx0XHRcdFx0c3RhcnQgPSAkLmV2ZW50LnNwZWNpYWwuc3dpcGUuc3RhcnQoIGV2ZW50ICksXG5cdFx0XHRcdFx0b3JpZ1RhcmdldCA9IGV2ZW50LnRhcmdldCxcblx0XHRcdFx0XHRlbWl0dGVkID0gZmFsc2U7XG5cblx0XHRcdFx0Y29udGV4dC5tb3ZlID0gZnVuY3Rpb24oIGV2ZW50ICkge1xuXHRcdFx0XHRcdGlmICggIXN0YXJ0IHx8IGV2ZW50LmlzRGVmYXVsdFByZXZlbnRlZCgpICkge1xuXHRcdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHN0b3AgPSAkLmV2ZW50LnNwZWNpYWwuc3dpcGUuc3RvcCggZXZlbnQgKTtcblx0XHRcdFx0XHRpZiAoICFlbWl0dGVkICkge1xuXHRcdFx0XHRcdFx0ZW1pdHRlZCA9ICQuZXZlbnQuc3BlY2lhbC5zd2lwZS5oYW5kbGVTd2lwZSggc3RhcnQsIHN0b3AsIHRoaXNPYmplY3QsIG9yaWdUYXJnZXQgKTtcblx0XHRcdFx0XHRcdGlmICggZW1pdHRlZCApIHtcblxuXHRcdFx0XHRcdFx0XHQvLyBSZXNldCB0aGUgY29udGV4dCB0byBtYWtlIHdheSBmb3IgdGhlIG5leHQgc3dpcGUgZXZlbnRcblx0XHRcdFx0XHRcdFx0JC5ldmVudC5zcGVjaWFsLnN3aXBlLmV2ZW50SW5Qcm9ncmVzcyA9IGZhbHNlO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHQvLyBwcmV2ZW50IHNjcm9sbGluZ1xuXHRcdFx0XHRcdGlmICggTWF0aC5hYnMoIHN0YXJ0LmNvb3Jkc1sgMCBdIC0gc3RvcC5jb29yZHNbIDAgXSApID4gJC5ldmVudC5zcGVjaWFsLnN3aXBlLnNjcm9sbFN1cHJlc3Npb25UaHJlc2hvbGQgKSB7XG5cdFx0XHRcdFx0XHRldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fTtcblxuXHRcdFx0XHRjb250ZXh0LnN0b3AgPSBmdW5jdGlvbigpIHtcblx0XHRcdFx0XHRcdGVtaXR0ZWQgPSB0cnVlO1xuXG5cdFx0XHRcdFx0XHQvLyBSZXNldCB0aGUgY29udGV4dCB0byBtYWtlIHdheSBmb3IgdGhlIG5leHQgc3dpcGUgZXZlbnRcblx0XHRcdFx0XHRcdCQuZXZlbnQuc3BlY2lhbC5zd2lwZS5ldmVudEluUHJvZ3Jlc3MgPSBmYWxzZTtcblx0XHRcdFx0XHRcdCRkb2N1bWVudC5vZmYoIHRvdWNoTW92ZUV2ZW50LCBjb250ZXh0Lm1vdmUgKTtcblx0XHRcdFx0XHRcdGNvbnRleHQubW92ZSA9IG51bGw7XG5cdFx0XHRcdH07XG5cblx0XHRcdFx0JGRvY3VtZW50Lm9uKCB0b3VjaE1vdmVFdmVudCwgY29udGV4dC5tb3ZlIClcblx0XHRcdFx0XHQub25lKCB0b3VjaFN0b3BFdmVudCwgY29udGV4dC5zdG9wICk7XG5cdFx0XHR9O1xuXHRcdFx0JHRoaXMub24oIHRvdWNoU3RhcnRFdmVudCwgY29udGV4dC5zdGFydCApO1xuXHRcdH0sXG5cblx0XHR0ZWFyZG93bjogZnVuY3Rpb24oKSB7XG5cdFx0XHR2YXIgZXZlbnRzLCBjb250ZXh0O1xuXG5cdFx0XHRldmVudHMgPSAkLmRhdGEoIHRoaXMsIFwibW9iaWxlLWV2ZW50c1wiICk7XG5cdFx0XHRpZiAoIGV2ZW50cyApIHtcblx0XHRcdFx0Y29udGV4dCA9IGV2ZW50cy5zd2lwZTtcblx0XHRcdFx0ZGVsZXRlIGV2ZW50cy5zd2lwZTtcblx0XHRcdFx0ZXZlbnRzLmxlbmd0aC0tO1xuXHRcdFx0XHRpZiAoIGV2ZW50cy5sZW5ndGggPT09IDAgKSB7XG5cdFx0XHRcdFx0JC5yZW1vdmVEYXRhKCB0aGlzLCBcIm1vYmlsZS1ldmVudHNcIiApO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdGlmICggY29udGV4dCApIHtcblx0XHRcdFx0aWYgKCBjb250ZXh0LnN0YXJ0ICkge1xuXHRcdFx0XHRcdCQoIHRoaXMgKS5vZmYoIHRvdWNoU3RhcnRFdmVudCwgY29udGV4dC5zdGFydCApO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmICggY29udGV4dC5tb3ZlICkge1xuXHRcdFx0XHRcdCRkb2N1bWVudC5vZmYoIHRvdWNoTW92ZUV2ZW50LCBjb250ZXh0Lm1vdmUgKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIGNvbnRleHQuc3RvcCApIHtcblx0XHRcdFx0XHQkZG9jdW1lbnQub2ZmKCB0b3VjaFN0b3BFdmVudCwgY29udGV4dC5zdG9wICk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH07XG5cdCQuZWFjaCh7XG5cdFx0c3dpcGVsZWZ0OiBcInN3aXBlLmxlZnRcIixcblx0XHRzd2lwZXJpZ2h0OiBcInN3aXBlLnJpZ2h0XCJcblx0fSwgZnVuY3Rpb24oIGV2ZW50LCBzb3VyY2VFdmVudCApIHtcblxuXHRcdCQuZXZlbnQuc3BlY2lhbFsgZXZlbnQgXSA9IHtcblx0XHRcdHNldHVwOiBmdW5jdGlvbigpIHtcblx0XHRcdFx0JCggdGhpcyApLmJpbmQoIHNvdXJjZUV2ZW50LCAkLm5vb3AgKTtcblx0XHRcdH0sXG5cdFx0XHR0ZWFyZG93bjogZnVuY3Rpb24oKSB7XG5cdFx0XHRcdCQoIHRoaXMgKS51bmJpbmQoIHNvdXJjZUV2ZW50ICk7XG5cdFx0XHR9XG5cdFx0fTtcblx0fSk7XG59KSggalF1ZXJ5LCB0aGlzICk7XG4qL1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4hZnVuY3Rpb24oJCkge1xuXG5jb25zdCBNdXRhdGlvbk9ic2VydmVyID0gKGZ1bmN0aW9uICgpIHtcbiAgdmFyIHByZWZpeGVzID0gWydXZWJLaXQnLCAnTW96JywgJ08nLCAnTXMnLCAnJ107XG4gIGZvciAodmFyIGk9MDsgaSA8IHByZWZpeGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKGAke3ByZWZpeGVzW2ldfU11dGF0aW9uT2JzZXJ2ZXJgIGluIHdpbmRvdykge1xuICAgICAgcmV0dXJuIHdpbmRvd1tgJHtwcmVmaXhlc1tpXX1NdXRhdGlvbk9ic2VydmVyYF07XG4gICAgfVxuICB9XG4gIHJldHVybiBmYWxzZTtcbn0oKSk7XG5cbmNvbnN0IHRyaWdnZXJzID0gKGVsLCB0eXBlKSA9PiB7XG4gIGVsLmRhdGEodHlwZSkuc3BsaXQoJyAnKS5mb3JFYWNoKGlkID0+IHtcbiAgICAkKGAjJHtpZH1gKVsgdHlwZSA9PT0gJ2Nsb3NlJyA/ICd0cmlnZ2VyJyA6ICd0cmlnZ2VySGFuZGxlciddKGAke3R5cGV9LnpmLnRyaWdnZXJgLCBbZWxdKTtcbiAgfSk7XG59O1xuLy8gRWxlbWVudHMgd2l0aCBbZGF0YS1vcGVuXSB3aWxsIHJldmVhbCBhIHBsdWdpbiB0aGF0IHN1cHBvcnRzIGl0IHdoZW4gY2xpY2tlZC5cbiQoZG9jdW1lbnQpLm9uKCdjbGljay56Zi50cmlnZ2VyJywgJ1tkYXRhLW9wZW5dJywgZnVuY3Rpb24oKSB7XG4gIHRyaWdnZXJzKCQodGhpcyksICdvcGVuJyk7XG59KTtcblxuLy8gRWxlbWVudHMgd2l0aCBbZGF0YS1jbG9zZV0gd2lsbCBjbG9zZSBhIHBsdWdpbiB0aGF0IHN1cHBvcnRzIGl0IHdoZW4gY2xpY2tlZC5cbi8vIElmIHVzZWQgd2l0aG91dCBhIHZhbHVlIG9uIFtkYXRhLWNsb3NlXSwgdGhlIGV2ZW50IHdpbGwgYnViYmxlLCBhbGxvd2luZyBpdCB0byBjbG9zZSBhIHBhcmVudCBjb21wb25lbnQuXG4kKGRvY3VtZW50KS5vbignY2xpY2suemYudHJpZ2dlcicsICdbZGF0YS1jbG9zZV0nLCBmdW5jdGlvbigpIHtcbiAgbGV0IGlkID0gJCh0aGlzKS5kYXRhKCdjbG9zZScpO1xuICBpZiAoaWQpIHtcbiAgICB0cmlnZ2VycygkKHRoaXMpLCAnY2xvc2UnKTtcbiAgfVxuICBlbHNlIHtcbiAgICAkKHRoaXMpLnRyaWdnZXIoJ2Nsb3NlLnpmLnRyaWdnZXInKTtcbiAgfVxufSk7XG5cbi8vIEVsZW1lbnRzIHdpdGggW2RhdGEtdG9nZ2xlXSB3aWxsIHRvZ2dsZSBhIHBsdWdpbiB0aGF0IHN1cHBvcnRzIGl0IHdoZW4gY2xpY2tlZC5cbiQoZG9jdW1lbnQpLm9uKCdjbGljay56Zi50cmlnZ2VyJywgJ1tkYXRhLXRvZ2dsZV0nLCBmdW5jdGlvbigpIHtcbiAgbGV0IGlkID0gJCh0aGlzKS5kYXRhKCd0b2dnbGUnKTtcbiAgaWYgKGlkKSB7XG4gICAgdHJpZ2dlcnMoJCh0aGlzKSwgJ3RvZ2dsZScpO1xuICB9IGVsc2Uge1xuICAgICQodGhpcykudHJpZ2dlcigndG9nZ2xlLnpmLnRyaWdnZXInKTtcbiAgfVxufSk7XG5cbi8vIEVsZW1lbnRzIHdpdGggW2RhdGEtY2xvc2FibGVdIHdpbGwgcmVzcG9uZCB0byBjbG9zZS56Zi50cmlnZ2VyIGV2ZW50cy5cbiQoZG9jdW1lbnQpLm9uKCdjbG9zZS56Zi50cmlnZ2VyJywgJ1tkYXRhLWNsb3NhYmxlXScsIGZ1bmN0aW9uKGUpe1xuICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICBsZXQgYW5pbWF0aW9uID0gJCh0aGlzKS5kYXRhKCdjbG9zYWJsZScpO1xuXG4gIGlmKGFuaW1hdGlvbiAhPT0gJycpe1xuICAgIEZvdW5kYXRpb24uTW90aW9uLmFuaW1hdGVPdXQoJCh0aGlzKSwgYW5pbWF0aW9uLCBmdW5jdGlvbigpIHtcbiAgICAgICQodGhpcykudHJpZ2dlcignY2xvc2VkLnpmJyk7XG4gICAgfSk7XG4gIH1lbHNle1xuICAgICQodGhpcykuZmFkZU91dCgpLnRyaWdnZXIoJ2Nsb3NlZC56ZicpO1xuICB9XG59KTtcblxuJChkb2N1bWVudCkub24oJ2ZvY3VzLnpmLnRyaWdnZXIgYmx1ci56Zi50cmlnZ2VyJywgJ1tkYXRhLXRvZ2dsZS1mb2N1c10nLCBmdW5jdGlvbigpIHtcbiAgbGV0IGlkID0gJCh0aGlzKS5kYXRhKCd0b2dnbGUtZm9jdXMnKTtcbiAgJChgIyR7aWR9YCkudHJpZ2dlckhhbmRsZXIoJ3RvZ2dsZS56Zi50cmlnZ2VyJywgWyQodGhpcyldKTtcbn0pO1xuXG4vKipcbiogRmlyZXMgb25jZSBhZnRlciBhbGwgb3RoZXIgc2NyaXB0cyBoYXZlIGxvYWRlZFxuKiBAZnVuY3Rpb25cbiogQHByaXZhdGVcbiovXG4kKHdpbmRvdykub24oJ2xvYWQnLCAoKSA9PiB7XG4gIGNoZWNrTGlzdGVuZXJzKCk7XG59KTtcblxuZnVuY3Rpb24gY2hlY2tMaXN0ZW5lcnMoKSB7XG4gIGV2ZW50c0xpc3RlbmVyKCk7XG4gIHJlc2l6ZUxpc3RlbmVyKCk7XG4gIHNjcm9sbExpc3RlbmVyKCk7XG4gIG11dGF0ZUxpc3RlbmVyKCk7XG4gIGNsb3NlbWVMaXN0ZW5lcigpO1xufVxuXG4vLyoqKioqKioqIG9ubHkgZmlyZXMgdGhpcyBmdW5jdGlvbiBvbmNlIG9uIGxvYWQsIGlmIHRoZXJlJ3Mgc29tZXRoaW5nIHRvIHdhdGNoICoqKioqKioqXG5mdW5jdGlvbiBjbG9zZW1lTGlzdGVuZXIocGx1Z2luTmFtZSkge1xuICB2YXIgeWV0aUJveGVzID0gJCgnW2RhdGEteWV0aS1ib3hdJyksXG4gICAgICBwbHVnTmFtZXMgPSBbJ2Ryb3Bkb3duJywgJ3Rvb2x0aXAnLCAncmV2ZWFsJ107XG5cbiAgaWYocGx1Z2luTmFtZSl7XG4gICAgaWYodHlwZW9mIHBsdWdpbk5hbWUgPT09ICdzdHJpbmcnKXtcbiAgICAgIHBsdWdOYW1lcy5wdXNoKHBsdWdpbk5hbWUpO1xuICAgIH1lbHNlIGlmKHR5cGVvZiBwbHVnaW5OYW1lID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgcGx1Z2luTmFtZVswXSA9PT0gJ3N0cmluZycpe1xuICAgICAgcGx1Z05hbWVzLmNvbmNhdChwbHVnaW5OYW1lKTtcbiAgICB9ZWxzZXtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1BsdWdpbiBuYW1lcyBtdXN0IGJlIHN0cmluZ3MnKTtcbiAgICB9XG4gIH1cbiAgaWYoeWV0aUJveGVzLmxlbmd0aCl7XG4gICAgbGV0IGxpc3RlbmVycyA9IHBsdWdOYW1lcy5tYXAoKG5hbWUpID0+IHtcbiAgICAgIHJldHVybiBgY2xvc2VtZS56Zi4ke25hbWV9YDtcbiAgICB9KS5qb2luKCcgJyk7XG5cbiAgICAkKHdpbmRvdykub2ZmKGxpc3RlbmVycykub24obGlzdGVuZXJzLCBmdW5jdGlvbihlLCBwbHVnaW5JZCl7XG4gICAgICBsZXQgcGx1Z2luID0gZS5uYW1lc3BhY2Uuc3BsaXQoJy4nKVswXTtcbiAgICAgIGxldCBwbHVnaW5zID0gJChgW2RhdGEtJHtwbHVnaW59XWApLm5vdChgW2RhdGEteWV0aS1ib3g9XCIke3BsdWdpbklkfVwiXWApO1xuXG4gICAgICBwbHVnaW5zLmVhY2goZnVuY3Rpb24oKXtcbiAgICAgICAgbGV0IF90aGlzID0gJCh0aGlzKTtcblxuICAgICAgICBfdGhpcy50cmlnZ2VySGFuZGxlcignY2xvc2UuemYudHJpZ2dlcicsIFtfdGhpc10pO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVzaXplTGlzdGVuZXIoZGVib3VuY2Upe1xuICBsZXQgdGltZXIsXG4gICAgICAkbm9kZXMgPSAkKCdbZGF0YS1yZXNpemVdJyk7XG4gIGlmKCRub2Rlcy5sZW5ndGgpe1xuICAgICQod2luZG93KS5vZmYoJ3Jlc2l6ZS56Zi50cmlnZ2VyJylcbiAgICAub24oJ3Jlc2l6ZS56Zi50cmlnZ2VyJywgZnVuY3Rpb24oZSkge1xuICAgICAgaWYgKHRpbWVyKSB7IGNsZWFyVGltZW91dCh0aW1lcik7IH1cblxuICAgICAgdGltZXIgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7XG5cbiAgICAgICAgaWYoIU11dGF0aW9uT2JzZXJ2ZXIpey8vZmFsbGJhY2sgZm9yIElFIDlcbiAgICAgICAgICAkbm9kZXMuZWFjaChmdW5jdGlvbigpe1xuICAgICAgICAgICAgJCh0aGlzKS50cmlnZ2VySGFuZGxlcigncmVzaXplbWUuemYudHJpZ2dlcicpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIC8vdHJpZ2dlciBhbGwgbGlzdGVuaW5nIGVsZW1lbnRzIGFuZCBzaWduYWwgYSByZXNpemUgZXZlbnRcbiAgICAgICAgJG5vZGVzLmF0dHIoJ2RhdGEtZXZlbnRzJywgXCJyZXNpemVcIik7XG4gICAgICB9LCBkZWJvdW5jZSB8fCAxMCk7Ly9kZWZhdWx0IHRpbWUgdG8gZW1pdCByZXNpemUgZXZlbnRcbiAgICB9KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzY3JvbGxMaXN0ZW5lcihkZWJvdW5jZSl7XG4gIGxldCB0aW1lcixcbiAgICAgICRub2RlcyA9ICQoJ1tkYXRhLXNjcm9sbF0nKTtcbiAgaWYoJG5vZGVzLmxlbmd0aCl7XG4gICAgJCh3aW5kb3cpLm9mZignc2Nyb2xsLnpmLnRyaWdnZXInKVxuICAgIC5vbignc2Nyb2xsLnpmLnRyaWdnZXInLCBmdW5jdGlvbihlKXtcbiAgICAgIGlmKHRpbWVyKXsgY2xlYXJUaW1lb3V0KHRpbWVyKTsgfVxuXG4gICAgICB0aW1lciA9IHNldFRpbWVvdXQoZnVuY3Rpb24oKXtcblxuICAgICAgICBpZighTXV0YXRpb25PYnNlcnZlcil7Ly9mYWxsYmFjayBmb3IgSUUgOVxuICAgICAgICAgICRub2Rlcy5lYWNoKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAkKHRoaXMpLnRyaWdnZXJIYW5kbGVyKCdzY3JvbGxtZS56Zi50cmlnZ2VyJyk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgLy90cmlnZ2VyIGFsbCBsaXN0ZW5pbmcgZWxlbWVudHMgYW5kIHNpZ25hbCBhIHNjcm9sbCBldmVudFxuICAgICAgICAkbm9kZXMuYXR0cignZGF0YS1ldmVudHMnLCBcInNjcm9sbFwiKTtcbiAgICAgIH0sIGRlYm91bmNlIHx8IDEwKTsvL2RlZmF1bHQgdGltZSB0byBlbWl0IHNjcm9sbCBldmVudFxuICAgIH0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIG11dGF0ZUxpc3RlbmVyKGRlYm91bmNlKSB7XG4gICAgbGV0ICRub2RlcyA9ICQoJ1tkYXRhLW11dGF0ZV0nKTtcbiAgICBpZiAoJG5vZGVzLmxlbmd0aCAmJiBNdXRhdGlvbk9ic2VydmVyKXtcblx0XHRcdC8vdHJpZ2dlciBhbGwgbGlzdGVuaW5nIGVsZW1lbnRzIGFuZCBzaWduYWwgYSBtdXRhdGUgZXZlbnRcbiAgICAgIC8vbm8gSUUgOSBvciAxMFxuXHRcdFx0JG5vZGVzLmVhY2goZnVuY3Rpb24gKCkge1xuXHRcdFx0ICAkKHRoaXMpLnRyaWdnZXJIYW5kbGVyKCdtdXRhdGVtZS56Zi50cmlnZ2VyJyk7XG5cdFx0XHR9KTtcbiAgICB9XG4gfVxuXG5mdW5jdGlvbiBldmVudHNMaXN0ZW5lcigpIHtcbiAgaWYoIU11dGF0aW9uT2JzZXJ2ZXIpeyByZXR1cm4gZmFsc2U7IH1cbiAgbGV0IG5vZGVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnW2RhdGEtcmVzaXplXSwgW2RhdGEtc2Nyb2xsXSwgW2RhdGEtbXV0YXRlXScpO1xuXG4gIC8vZWxlbWVudCBjYWxsYmFja1xuICB2YXIgbGlzdGVuaW5nRWxlbWVudHNNdXRhdGlvbiA9IGZ1bmN0aW9uIChtdXRhdGlvblJlY29yZHNMaXN0KSB7XG4gICAgICB2YXIgJHRhcmdldCA9ICQobXV0YXRpb25SZWNvcmRzTGlzdFswXS50YXJnZXQpO1xuXG5cdCAgLy90cmlnZ2VyIHRoZSBldmVudCBoYW5kbGVyIGZvciB0aGUgZWxlbWVudCBkZXBlbmRpbmcgb24gdHlwZVxuICAgICAgc3dpdGNoIChtdXRhdGlvblJlY29yZHNMaXN0WzBdLnR5cGUpIHtcblxuICAgICAgICBjYXNlIFwiYXR0cmlidXRlc1wiOlxuICAgICAgICAgIGlmICgkdGFyZ2V0LmF0dHIoXCJkYXRhLWV2ZW50c1wiKSA9PT0gXCJzY3JvbGxcIiAmJiBtdXRhdGlvblJlY29yZHNMaXN0WzBdLmF0dHJpYnV0ZU5hbWUgPT09IFwiZGF0YS1ldmVudHNcIikge1xuXHRcdCAgXHQkdGFyZ2V0LnRyaWdnZXJIYW5kbGVyKCdzY3JvbGxtZS56Zi50cmlnZ2VyJywgWyR0YXJnZXQsIHdpbmRvdy5wYWdlWU9mZnNldF0pO1xuXHRcdCAgfVxuXHRcdCAgaWYgKCR0YXJnZXQuYXR0cihcImRhdGEtZXZlbnRzXCIpID09PSBcInJlc2l6ZVwiICYmIG11dGF0aW9uUmVjb3Jkc0xpc3RbMF0uYXR0cmlidXRlTmFtZSA9PT0gXCJkYXRhLWV2ZW50c1wiKSB7XG5cdFx0ICBcdCR0YXJnZXQudHJpZ2dlckhhbmRsZXIoJ3Jlc2l6ZW1lLnpmLnRyaWdnZXInLCBbJHRhcmdldF0pO1xuXHRcdCAgIH1cblx0XHQgIGlmIChtdXRhdGlvblJlY29yZHNMaXN0WzBdLmF0dHJpYnV0ZU5hbWUgPT09IFwic3R5bGVcIikge1xuXHRcdFx0ICAkdGFyZ2V0LmNsb3Nlc3QoXCJbZGF0YS1tdXRhdGVdXCIpLmF0dHIoXCJkYXRhLWV2ZW50c1wiLFwibXV0YXRlXCIpO1xuXHRcdFx0ICAkdGFyZ2V0LmNsb3Nlc3QoXCJbZGF0YS1tdXRhdGVdXCIpLnRyaWdnZXJIYW5kbGVyKCdtdXRhdGVtZS56Zi50cmlnZ2VyJywgWyR0YXJnZXQuY2xvc2VzdChcIltkYXRhLW11dGF0ZV1cIildKTtcblx0XHQgIH1cblx0XHQgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgXCJjaGlsZExpc3RcIjpcblx0XHQgICR0YXJnZXQuY2xvc2VzdChcIltkYXRhLW11dGF0ZV1cIikuYXR0cihcImRhdGEtZXZlbnRzXCIsXCJtdXRhdGVcIik7XG5cdFx0ICAkdGFyZ2V0LmNsb3Nlc3QoXCJbZGF0YS1tdXRhdGVdXCIpLnRyaWdnZXJIYW5kbGVyKCdtdXRhdGVtZS56Zi50cmlnZ2VyJywgWyR0YXJnZXQuY2xvc2VzdChcIltkYXRhLW11dGF0ZV1cIildKTtcbiAgICAgICAgICBicmVhaztcblxuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgLy9ub3RoaW5nXG4gICAgICB9XG4gICAgfTtcblxuICAgIGlmIChub2Rlcy5sZW5ndGgpIHtcbiAgICAgIC8vZm9yIGVhY2ggZWxlbWVudCB0aGF0IG5lZWRzIHRvIGxpc3RlbiBmb3IgcmVzaXppbmcsIHNjcm9sbGluZywgb3IgbXV0YXRpb24gYWRkIGEgc2luZ2xlIG9ic2VydmVyXG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8PSBub2Rlcy5sZW5ndGggLSAxOyBpKyspIHtcbiAgICAgICAgdmFyIGVsZW1lbnRPYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGxpc3RlbmluZ0VsZW1lbnRzTXV0YXRpb24pO1xuICAgICAgICBlbGVtZW50T2JzZXJ2ZXIub2JzZXJ2ZShub2Rlc1tpXSwgeyBhdHRyaWJ1dGVzOiB0cnVlLCBjaGlsZExpc3Q6IHRydWUsIGNoYXJhY3RlckRhdGE6IGZhbHNlLCBzdWJ0cmVlOiB0cnVlLCBhdHRyaWJ1dGVGaWx0ZXI6IFtcImRhdGEtZXZlbnRzXCIsIFwic3R5bGVcIl0gfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4vLyBbUEhdXG4vLyBGb3VuZGF0aW9uLkNoZWNrV2F0Y2hlcnMgPSBjaGVja1dhdGNoZXJzO1xuRm91bmRhdGlvbi5JSGVhcllvdSA9IGNoZWNrTGlzdGVuZXJzO1xuLy8gRm91bmRhdGlvbi5JU2VlWW91ID0gc2Nyb2xsTGlzdGVuZXI7XG4vLyBGb3VuZGF0aW9uLklGZWVsWW91ID0gY2xvc2VtZUxpc3RlbmVyO1xuXG59KGpRdWVyeSk7XG5cbi8vIGZ1bmN0aW9uIGRvbU11dGF0aW9uT2JzZXJ2ZXIoZGVib3VuY2UpIHtcbi8vICAgLy8gISEhIFRoaXMgaXMgY29taW5nIHNvb24gYW5kIG5lZWRzIG1vcmUgd29yazsgbm90IGFjdGl2ZSAgISEhIC8vXG4vLyAgIHZhciB0aW1lcixcbi8vICAgbm9kZXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdbZGF0YS1tdXRhdGVdJyk7XG4vLyAgIC8vXG4vLyAgIGlmIChub2Rlcy5sZW5ndGgpIHtcbi8vICAgICAvLyB2YXIgTXV0YXRpb25PYnNlcnZlciA9IChmdW5jdGlvbiAoKSB7XG4vLyAgICAgLy8gICB2YXIgcHJlZml4ZXMgPSBbJ1dlYktpdCcsICdNb3onLCAnTycsICdNcycsICcnXTtcbi8vICAgICAvLyAgIGZvciAodmFyIGk9MDsgaSA8IHByZWZpeGVzLmxlbmd0aDsgaSsrKSB7XG4vLyAgICAgLy8gICAgIGlmIChwcmVmaXhlc1tpXSArICdNdXRhdGlvbk9ic2VydmVyJyBpbiB3aW5kb3cpIHtcbi8vICAgICAvLyAgICAgICByZXR1cm4gd2luZG93W3ByZWZpeGVzW2ldICsgJ011dGF0aW9uT2JzZXJ2ZXInXTtcbi8vICAgICAvLyAgICAgfVxuLy8gICAgIC8vICAgfVxuLy8gICAgIC8vICAgcmV0dXJuIGZhbHNlO1xuLy8gICAgIC8vIH0oKSk7XG4vL1xuLy9cbi8vICAgICAvL2ZvciB0aGUgYm9keSwgd2UgbmVlZCB0byBsaXN0ZW4gZm9yIGFsbCBjaGFuZ2VzIGVmZmVjdGluZyB0aGUgc3R5bGUgYW5kIGNsYXNzIGF0dHJpYnV0ZXNcbi8vICAgICB2YXIgYm9keU9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoYm9keU11dGF0aW9uKTtcbi8vICAgICBib2R5T2JzZXJ2ZXIub2JzZXJ2ZShkb2N1bWVudC5ib2R5LCB7IGF0dHJpYnV0ZXM6IHRydWUsIGNoaWxkTGlzdDogdHJ1ZSwgY2hhcmFjdGVyRGF0YTogZmFsc2UsIHN1YnRyZWU6dHJ1ZSwgYXR0cmlidXRlRmlsdGVyOltcInN0eWxlXCIsIFwiY2xhc3NcIl19KTtcbi8vXG4vL1xuLy8gICAgIC8vYm9keSBjYWxsYmFja1xuLy8gICAgIGZ1bmN0aW9uIGJvZHlNdXRhdGlvbihtdXRhdGUpIHtcbi8vICAgICAgIC8vdHJpZ2dlciBhbGwgbGlzdGVuaW5nIGVsZW1lbnRzIGFuZCBzaWduYWwgYSBtdXRhdGlvbiBldmVudFxuLy8gICAgICAgaWYgKHRpbWVyKSB7IGNsZWFyVGltZW91dCh0aW1lcik7IH1cbi8vXG4vLyAgICAgICB0aW1lciA9IHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4vLyAgICAgICAgIGJvZHlPYnNlcnZlci5kaXNjb25uZWN0KCk7XG4vLyAgICAgICAgICQoJ1tkYXRhLW11dGF0ZV0nKS5hdHRyKCdkYXRhLWV2ZW50cycsXCJtdXRhdGVcIik7XG4vLyAgICAgICB9LCBkZWJvdW5jZSB8fCAxNTApO1xuLy8gICAgIH1cbi8vICAgfVxuLy8gfVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG4hZnVuY3Rpb24oJCkge1xuXG4vKipcbiAqIEFjY29yZGlvbk1lbnUgbW9kdWxlLlxuICogQG1vZHVsZSBmb3VuZGF0aW9uLmFjY29yZGlvbk1lbnVcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwua2V5Ym9hcmRcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwubW90aW9uXG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLm5lc3RcbiAqL1xuXG5jbGFzcyBBY2NvcmRpb25NZW51IHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgaW5zdGFuY2Ugb2YgYW4gYWNjb3JkaW9uIG1lbnUuXG4gICAqIEBjbGFzc1xuICAgKiBAZmlyZXMgQWNjb3JkaW9uTWVudSNpbml0XG4gICAqIEBwYXJhbSB7alF1ZXJ5fSBlbGVtZW50IC0galF1ZXJ5IG9iamVjdCB0byBtYWtlIGludG8gYW4gYWNjb3JkaW9uIG1lbnUuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zIC0gT3ZlcnJpZGVzIHRvIHRoZSBkZWZhdWx0IHBsdWdpbiBzZXR0aW5ncy5cbiAgICovXG4gIGNvbnN0cnVjdG9yKGVsZW1lbnQsIG9wdGlvbnMpIHtcbiAgICB0aGlzLiRlbGVtZW50ID0gZWxlbWVudDtcbiAgICB0aGlzLm9wdGlvbnMgPSAkLmV4dGVuZCh7fSwgQWNjb3JkaW9uTWVudS5kZWZhdWx0cywgdGhpcy4kZWxlbWVudC5kYXRhKCksIG9wdGlvbnMpO1xuXG4gICAgRm91bmRhdGlvbi5OZXN0LkZlYXRoZXIodGhpcy4kZWxlbWVudCwgJ2FjY29yZGlvbicpO1xuXG4gICAgdGhpcy5faW5pdCgpO1xuXG4gICAgRm91bmRhdGlvbi5yZWdpc3RlclBsdWdpbih0aGlzLCAnQWNjb3JkaW9uTWVudScpO1xuICAgIEZvdW5kYXRpb24uS2V5Ym9hcmQucmVnaXN0ZXIoJ0FjY29yZGlvbk1lbnUnLCB7XG4gICAgICAnRU5URVInOiAndG9nZ2xlJyxcbiAgICAgICdTUEFDRSc6ICd0b2dnbGUnLFxuICAgICAgJ0FSUk9XX1JJR0hUJzogJ29wZW4nLFxuICAgICAgJ0FSUk9XX1VQJzogJ3VwJyxcbiAgICAgICdBUlJPV19ET1dOJzogJ2Rvd24nLFxuICAgICAgJ0FSUk9XX0xFRlQnOiAnY2xvc2UnLFxuICAgICAgJ0VTQ0FQRSc6ICdjbG9zZUFsbCdcbiAgICB9KTtcbiAgfVxuXG5cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgdGhlIGFjY29yZGlvbiBtZW51IGJ5IGhpZGluZyBhbGwgbmVzdGVkIG1lbnVzLlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2luaXQoKSB7XG4gICAgdGhpcy4kZWxlbWVudC5maW5kKCdbZGF0YS1zdWJtZW51XScpLm5vdCgnLmlzLWFjdGl2ZScpLnNsaWRlVXAoMCk7Ly8uZmluZCgnYScpLmNzcygncGFkZGluZy1sZWZ0JywgJzFyZW0nKTtcbiAgICB0aGlzLiRlbGVtZW50LmF0dHIoe1xuICAgICAgJ3JvbGUnOiAnbWVudScsXG4gICAgICAnYXJpYS1tdWx0aXNlbGVjdGFibGUnOiB0aGlzLm9wdGlvbnMubXVsdGlPcGVuXG4gICAgfSk7XG5cbiAgICB0aGlzLiRtZW51TGlua3MgPSB0aGlzLiRlbGVtZW50LmZpbmQoJy5pcy1hY2NvcmRpb24tc3VibWVudS1wYXJlbnQnKTtcbiAgICB0aGlzLiRtZW51TGlua3MuZWFjaChmdW5jdGlvbigpe1xuICAgICAgdmFyIGxpbmtJZCA9IHRoaXMuaWQgfHwgRm91bmRhdGlvbi5HZXRZb0RpZ2l0cyg2LCAnYWNjLW1lbnUtbGluaycpLFxuICAgICAgICAgICRlbGVtID0gJCh0aGlzKSxcbiAgICAgICAgICAkc3ViID0gJGVsZW0uY2hpbGRyZW4oJ1tkYXRhLXN1Ym1lbnVdJyksXG4gICAgICAgICAgc3ViSWQgPSAkc3ViWzBdLmlkIHx8IEZvdW5kYXRpb24uR2V0WW9EaWdpdHMoNiwgJ2FjYy1tZW51JyksXG4gICAgICAgICAgaXNBY3RpdmUgPSAkc3ViLmhhc0NsYXNzKCdpcy1hY3RpdmUnKTtcbiAgICAgICRlbGVtLmF0dHIoe1xuICAgICAgICAnYXJpYS1jb250cm9scyc6IHN1YklkLFxuICAgICAgICAnYXJpYS1leHBhbmRlZCc6IGlzQWN0aXZlLFxuICAgICAgICAncm9sZSc6ICdtZW51aXRlbScsXG4gICAgICAgICdpZCc6IGxpbmtJZFxuICAgICAgfSk7XG4gICAgICAkc3ViLmF0dHIoe1xuICAgICAgICAnYXJpYS1sYWJlbGxlZGJ5JzogbGlua0lkLFxuICAgICAgICAnYXJpYS1oaWRkZW4nOiAhaXNBY3RpdmUsXG4gICAgICAgICdyb2xlJzogJ21lbnUnLFxuICAgICAgICAnaWQnOiBzdWJJZFxuICAgICAgfSk7XG4gICAgfSk7XG4gICAgdmFyIGluaXRQYW5lcyA9IHRoaXMuJGVsZW1lbnQuZmluZCgnLmlzLWFjdGl2ZScpO1xuICAgIGlmKGluaXRQYW5lcy5sZW5ndGgpe1xuICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgIGluaXRQYW5lcy5lYWNoKGZ1bmN0aW9uKCl7XG4gICAgICAgIF90aGlzLmRvd24oJCh0aGlzKSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgdGhpcy5fZXZlbnRzKCk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBldmVudCBoYW5kbGVycyBmb3IgaXRlbXMgd2l0aGluIHRoZSBtZW51LlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2V2ZW50cygpIHtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgdGhpcy4kZWxlbWVudC5maW5kKCdsaScpLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICB2YXIgJHN1Ym1lbnUgPSAkKHRoaXMpLmNoaWxkcmVuKCdbZGF0YS1zdWJtZW51XScpO1xuXG4gICAgICBpZiAoJHN1Ym1lbnUubGVuZ3RoKSB7XG4gICAgICAgICQodGhpcykuY2hpbGRyZW4oJ2EnKS5vZmYoJ2NsaWNrLnpmLmFjY29yZGlvbk1lbnUnKS5vbignY2xpY2suemYuYWNjb3JkaW9uTWVudScsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG5cbiAgICAgICAgICBfdGhpcy50b2dnbGUoJHN1Ym1lbnUpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KS5vbigna2V5ZG93bi56Zi5hY2NvcmRpb25tZW51JywgZnVuY3Rpb24oZSl7XG4gICAgICB2YXIgJGVsZW1lbnQgPSAkKHRoaXMpLFxuICAgICAgICAgICRlbGVtZW50cyA9ICRlbGVtZW50LnBhcmVudCgndWwnKS5jaGlsZHJlbignbGknKSxcbiAgICAgICAgICAkcHJldkVsZW1lbnQsXG4gICAgICAgICAgJG5leHRFbGVtZW50LFxuICAgICAgICAgICR0YXJnZXQgPSAkZWxlbWVudC5jaGlsZHJlbignW2RhdGEtc3VibWVudV0nKTtcblxuICAgICAgJGVsZW1lbnRzLmVhY2goZnVuY3Rpb24oaSkge1xuICAgICAgICBpZiAoJCh0aGlzKS5pcygkZWxlbWVudCkpIHtcbiAgICAgICAgICAkcHJldkVsZW1lbnQgPSAkZWxlbWVudHMuZXEoTWF0aC5tYXgoMCwgaS0xKSkuZmluZCgnYScpLmZpcnN0KCk7XG4gICAgICAgICAgJG5leHRFbGVtZW50ID0gJGVsZW1lbnRzLmVxKE1hdGgubWluKGkrMSwgJGVsZW1lbnRzLmxlbmd0aC0xKSkuZmluZCgnYScpLmZpcnN0KCk7XG5cbiAgICAgICAgICBpZiAoJCh0aGlzKS5jaGlsZHJlbignW2RhdGEtc3VibWVudV06dmlzaWJsZScpLmxlbmd0aCkgeyAvLyBoYXMgb3BlbiBzdWIgbWVudVxuICAgICAgICAgICAgJG5leHRFbGVtZW50ID0gJGVsZW1lbnQuZmluZCgnbGk6Zmlyc3QtY2hpbGQnKS5maW5kKCdhJykuZmlyc3QoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCQodGhpcykuaXMoJzpmaXJzdC1jaGlsZCcpKSB7IC8vIGlzIGZpcnN0IGVsZW1lbnQgb2Ygc3ViIG1lbnVcbiAgICAgICAgICAgICRwcmV2RWxlbWVudCA9ICRlbGVtZW50LnBhcmVudHMoJ2xpJykuZmlyc3QoKS5maW5kKCdhJykuZmlyc3QoKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKCRwcmV2RWxlbWVudC5wYXJlbnRzKCdsaScpLmZpcnN0KCkuY2hpbGRyZW4oJ1tkYXRhLXN1Ym1lbnVdOnZpc2libGUnKS5sZW5ndGgpIHsgLy8gaWYgcHJldmlvdXMgZWxlbWVudCBoYXMgb3BlbiBzdWIgbWVudVxuICAgICAgICAgICAgJHByZXZFbGVtZW50ID0gJHByZXZFbGVtZW50LnBhcmVudHMoJ2xpJykuZmluZCgnbGk6bGFzdC1jaGlsZCcpLmZpbmQoJ2EnKS5maXJzdCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoJCh0aGlzKS5pcygnOmxhc3QtY2hpbGQnKSkgeyAvLyBpcyBsYXN0IGVsZW1lbnQgb2Ygc3ViIG1lbnVcbiAgICAgICAgICAgICRuZXh0RWxlbWVudCA9ICRlbGVtZW50LnBhcmVudHMoJ2xpJykuZmlyc3QoKS5uZXh0KCdsaScpLmZpbmQoJ2EnKS5maXJzdCgpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIEZvdW5kYXRpb24uS2V5Ym9hcmQuaGFuZGxlS2V5KGUsICdBY2NvcmRpb25NZW51Jywge1xuICAgICAgICBvcGVuOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICBpZiAoJHRhcmdldC5pcygnOmhpZGRlbicpKSB7XG4gICAgICAgICAgICBfdGhpcy5kb3duKCR0YXJnZXQpO1xuICAgICAgICAgICAgJHRhcmdldC5maW5kKCdsaScpLmZpcnN0KCkuZmluZCgnYScpLmZpcnN0KCkuZm9jdXMoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIGNsb3NlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICBpZiAoJHRhcmdldC5sZW5ndGggJiYgISR0YXJnZXQuaXMoJzpoaWRkZW4nKSkgeyAvLyBjbG9zZSBhY3RpdmUgc3ViIG9mIHRoaXMgaXRlbVxuICAgICAgICAgICAgX3RoaXMudXAoJHRhcmdldCk7XG4gICAgICAgICAgfSBlbHNlIGlmICgkZWxlbWVudC5wYXJlbnQoJ1tkYXRhLXN1Ym1lbnVdJykubGVuZ3RoKSB7IC8vIGNsb3NlIGN1cnJlbnRseSBvcGVuIHN1YlxuICAgICAgICAgICAgX3RoaXMudXAoJGVsZW1lbnQucGFyZW50KCdbZGF0YS1zdWJtZW51XScpKTtcbiAgICAgICAgICAgICRlbGVtZW50LnBhcmVudHMoJ2xpJykuZmlyc3QoKS5maW5kKCdhJykuZmlyc3QoKS5mb2N1cygpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgdXA6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICRwcmV2RWxlbWVudC5mb2N1cygpO1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9LFxuICAgICAgICBkb3duOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAkbmV4dEVsZW1lbnQuZm9jdXMoKTtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSxcbiAgICAgICAgdG9nZ2xlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICBpZiAoJGVsZW1lbnQuY2hpbGRyZW4oJ1tkYXRhLXN1Ym1lbnVdJykubGVuZ3RoKSB7XG4gICAgICAgICAgICBfdGhpcy50b2dnbGUoJGVsZW1lbnQuY2hpbGRyZW4oJ1tkYXRhLXN1Ym1lbnVdJykpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgY2xvc2VBbGw6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIF90aGlzLmhpZGVBbGwoKTtcbiAgICAgICAgfSxcbiAgICAgICAgaGFuZGxlZDogZnVuY3Rpb24ocHJldmVudERlZmF1bHQpIHtcbiAgICAgICAgICBpZiAocHJldmVudERlZmF1bHQpIHtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZS5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7Ly8uYXR0cigndGFiaW5kZXgnLCAwKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDbG9zZXMgYWxsIHBhbmVzIG9mIHRoZSBtZW51LlxuICAgKiBAZnVuY3Rpb25cbiAgICovXG4gIGhpZGVBbGwoKSB7XG4gICAgdGhpcy51cCh0aGlzLiRlbGVtZW50LmZpbmQoJ1tkYXRhLXN1Ym1lbnVdJykpO1xuICB9XG5cbiAgLyoqXG4gICAqIE9wZW5zIGFsbCBwYW5lcyBvZiB0aGUgbWVudS5cbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICBzaG93QWxsKCkge1xuICAgIHRoaXMuZG93bih0aGlzLiRlbGVtZW50LmZpbmQoJ1tkYXRhLXN1Ym1lbnVdJykpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRvZ2dsZXMgdGhlIG9wZW4vY2xvc2Ugc3RhdGUgb2YgYSBzdWJtZW51LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHBhcmFtIHtqUXVlcnl9ICR0YXJnZXQgLSB0aGUgc3VibWVudSB0byB0b2dnbGVcbiAgICovXG4gIHRvZ2dsZSgkdGFyZ2V0KXtcbiAgICBpZighJHRhcmdldC5pcygnOmFuaW1hdGVkJykpIHtcbiAgICAgIGlmICghJHRhcmdldC5pcygnOmhpZGRlbicpKSB7XG4gICAgICAgIHRoaXMudXAoJHRhcmdldCk7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgdGhpcy5kb3duKCR0YXJnZXQpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBPcGVucyB0aGUgc3ViLW1lbnUgZGVmaW5lZCBieSBgJHRhcmdldGAuXG4gICAqIEBwYXJhbSB7alF1ZXJ5fSAkdGFyZ2V0IC0gU3ViLW1lbnUgdG8gb3Blbi5cbiAgICogQGZpcmVzIEFjY29yZGlvbk1lbnUjZG93blxuICAgKi9cbiAgZG93bigkdGFyZ2V0KSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIGlmKCF0aGlzLm9wdGlvbnMubXVsdGlPcGVuKSB7XG4gICAgICB0aGlzLnVwKHRoaXMuJGVsZW1lbnQuZmluZCgnLmlzLWFjdGl2ZScpLm5vdCgkdGFyZ2V0LnBhcmVudHNVbnRpbCh0aGlzLiRlbGVtZW50KS5hZGQoJHRhcmdldCkpKTtcbiAgICB9XG5cbiAgICAkdGFyZ2V0LmFkZENsYXNzKCdpcy1hY3RpdmUnKS5hdHRyKHsnYXJpYS1oaWRkZW4nOiBmYWxzZX0pXG4gICAgICAucGFyZW50KCcuaXMtYWNjb3JkaW9uLXN1Ym1lbnUtcGFyZW50JykuYXR0cih7J2FyaWEtZXhwYW5kZWQnOiB0cnVlfSk7XG5cbiAgICAgIC8vRm91bmRhdGlvbi5Nb3ZlKHRoaXMub3B0aW9ucy5zbGlkZVNwZWVkLCAkdGFyZ2V0LCBmdW5jdGlvbigpIHtcbiAgICAgICAgJHRhcmdldC5zbGlkZURvd24oX3RoaXMub3B0aW9ucy5zbGlkZVNwZWVkLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogRmlyZXMgd2hlbiB0aGUgbWVudSBpcyBkb25lIG9wZW5pbmcuXG4gICAgICAgICAgICogQGV2ZW50IEFjY29yZGlvbk1lbnUjZG93blxuICAgICAgICAgICAqL1xuICAgICAgICAgIF90aGlzLiRlbGVtZW50LnRyaWdnZXIoJ2Rvd24uemYuYWNjb3JkaW9uTWVudScsIFskdGFyZ2V0XSk7XG4gICAgICAgIH0pO1xuICAgICAgLy99KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDbG9zZXMgdGhlIHN1Yi1tZW51IGRlZmluZWQgYnkgYCR0YXJnZXRgLiBBbGwgc3ViLW1lbnVzIGluc2lkZSB0aGUgdGFyZ2V0IHdpbGwgYmUgY2xvc2VkIGFzIHdlbGwuXG4gICAqIEBwYXJhbSB7alF1ZXJ5fSAkdGFyZ2V0IC0gU3ViLW1lbnUgdG8gY2xvc2UuXG4gICAqIEBmaXJlcyBBY2NvcmRpb25NZW51I3VwXG4gICAqL1xuICB1cCgkdGFyZ2V0KSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAvL0ZvdW5kYXRpb24uTW92ZSh0aGlzLm9wdGlvbnMuc2xpZGVTcGVlZCwgJHRhcmdldCwgZnVuY3Rpb24oKXtcbiAgICAgICR0YXJnZXQuc2xpZGVVcChfdGhpcy5vcHRpb25zLnNsaWRlU3BlZWQsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIEZpcmVzIHdoZW4gdGhlIG1lbnUgaXMgZG9uZSBjb2xsYXBzaW5nIHVwLlxuICAgICAgICAgKiBAZXZlbnQgQWNjb3JkaW9uTWVudSN1cFxuICAgICAgICAgKi9cbiAgICAgICAgX3RoaXMuJGVsZW1lbnQudHJpZ2dlcigndXAuemYuYWNjb3JkaW9uTWVudScsIFskdGFyZ2V0XSk7XG4gICAgICB9KTtcbiAgICAvL30pO1xuXG4gICAgdmFyICRtZW51cyA9ICR0YXJnZXQuZmluZCgnW2RhdGEtc3VibWVudV0nKS5zbGlkZVVwKDApLmFkZEJhY2soKS5hdHRyKCdhcmlhLWhpZGRlbicsIHRydWUpO1xuXG4gICAgJG1lbnVzLnBhcmVudCgnLmlzLWFjY29yZGlvbi1zdWJtZW51LXBhcmVudCcpLmF0dHIoJ2FyaWEtZXhwYW5kZWQnLCBmYWxzZSk7XG4gIH1cblxuICAvKipcbiAgICogRGVzdHJveXMgYW4gaW5zdGFuY2Ugb2YgYWNjb3JkaW9uIG1lbnUuXG4gICAqIEBmaXJlcyBBY2NvcmRpb25NZW51I2Rlc3Ryb3llZFxuICAgKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLiRlbGVtZW50LmZpbmQoJ1tkYXRhLXN1Ym1lbnVdJykuc2xpZGVEb3duKDApLmNzcygnZGlzcGxheScsICcnKTtcbiAgICB0aGlzLiRlbGVtZW50LmZpbmQoJ2EnKS5vZmYoJ2NsaWNrLnpmLmFjY29yZGlvbk1lbnUnKTtcblxuICAgIEZvdW5kYXRpb24uTmVzdC5CdXJuKHRoaXMuJGVsZW1lbnQsICdhY2NvcmRpb24nKTtcbiAgICBGb3VuZGF0aW9uLnVucmVnaXN0ZXJQbHVnaW4odGhpcyk7XG4gIH1cbn1cblxuQWNjb3JkaW9uTWVudS5kZWZhdWx0cyA9IHtcbiAgLyoqXG4gICAqIEFtb3VudCBvZiB0aW1lIHRvIGFuaW1hdGUgdGhlIG9wZW5pbmcgb2YgYSBzdWJtZW51IGluIG1zLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIDI1MFxuICAgKi9cbiAgc2xpZGVTcGVlZDogMjUwLFxuICAvKipcbiAgICogQWxsb3cgdGhlIG1lbnUgdG8gaGF2ZSBtdWx0aXBsZSBvcGVuIHBhbmVzLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIHRydWVcbiAgICovXG4gIG11bHRpT3BlbjogdHJ1ZVxufTtcblxuLy8gV2luZG93IGV4cG9ydHNcbkZvdW5kYXRpb24ucGx1Z2luKEFjY29yZGlvbk1lbnUsICdBY2NvcmRpb25NZW51Jyk7XG5cbn0oalF1ZXJ5KTtcbiIsIid1c2Ugc3RyaWN0JztcblxuIWZ1bmN0aW9uKCQpIHtcblxuLyoqXG4gKiBEcmlsbGRvd24gbW9kdWxlLlxuICogQG1vZHVsZSBmb3VuZGF0aW9uLmRyaWxsZG93blxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC5rZXlib2FyZFxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC5tb3Rpb25cbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwubmVzdFxuICovXG5cbmNsYXNzIERyaWxsZG93biB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IGluc3RhbmNlIG9mIGEgZHJpbGxkb3duIG1lbnUuXG4gICAqIEBjbGFzc1xuICAgKiBAcGFyYW0ge2pRdWVyeX0gZWxlbWVudCAtIGpRdWVyeSBvYmplY3QgdG8gbWFrZSBpbnRvIGFuIGFjY29yZGlvbiBtZW51LlxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyAtIE92ZXJyaWRlcyB0byB0aGUgZGVmYXVsdCBwbHVnaW4gc2V0dGluZ3MuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihlbGVtZW50LCBvcHRpb25zKSB7XG4gICAgdGhpcy4kZWxlbWVudCA9IGVsZW1lbnQ7XG4gICAgdGhpcy5vcHRpb25zID0gJC5leHRlbmQoe30sIERyaWxsZG93bi5kZWZhdWx0cywgdGhpcy4kZWxlbWVudC5kYXRhKCksIG9wdGlvbnMpO1xuXG4gICAgRm91bmRhdGlvbi5OZXN0LkZlYXRoZXIodGhpcy4kZWxlbWVudCwgJ2RyaWxsZG93bicpO1xuXG4gICAgdGhpcy5faW5pdCgpO1xuXG4gICAgRm91bmRhdGlvbi5yZWdpc3RlclBsdWdpbih0aGlzLCAnRHJpbGxkb3duJyk7XG4gICAgRm91bmRhdGlvbi5LZXlib2FyZC5yZWdpc3RlcignRHJpbGxkb3duJywge1xuICAgICAgJ0VOVEVSJzogJ29wZW4nLFxuICAgICAgJ1NQQUNFJzogJ29wZW4nLFxuICAgICAgJ0FSUk9XX1JJR0hUJzogJ25leHQnLFxuICAgICAgJ0FSUk9XX1VQJzogJ3VwJyxcbiAgICAgICdBUlJPV19ET1dOJzogJ2Rvd24nLFxuICAgICAgJ0FSUk9XX0xFRlQnOiAncHJldmlvdXMnLFxuICAgICAgJ0VTQ0FQRSc6ICdjbG9zZScsXG4gICAgICAnVEFCJzogJ2Rvd24nLFxuICAgICAgJ1NISUZUX1RBQic6ICd1cCdcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyB0aGUgZHJpbGxkb3duIGJ5IGNyZWF0aW5nIGpRdWVyeSBjb2xsZWN0aW9ucyBvZiBlbGVtZW50c1xuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2luaXQoKSB7XG4gICAgdGhpcy4kc3VibWVudUFuY2hvcnMgPSB0aGlzLiRlbGVtZW50LmZpbmQoJ2xpLmlzLWRyaWxsZG93bi1zdWJtZW51LXBhcmVudCcpLmNoaWxkcmVuKCdhJyk7XG4gICAgdGhpcy4kc3VibWVudXMgPSB0aGlzLiRzdWJtZW51QW5jaG9ycy5wYXJlbnQoJ2xpJykuY2hpbGRyZW4oJ1tkYXRhLXN1Ym1lbnVdJyk7XG4gICAgdGhpcy4kbWVudUl0ZW1zID0gdGhpcy4kZWxlbWVudC5maW5kKCdsaScpLm5vdCgnLmpzLWRyaWxsZG93bi1iYWNrJykuYXR0cigncm9sZScsICdtZW51aXRlbScpLmZpbmQoJ2EnKTtcbiAgICB0aGlzLiRlbGVtZW50LmF0dHIoJ2RhdGEtbXV0YXRlJywgKHRoaXMuJGVsZW1lbnQuYXR0cignZGF0YS1kcmlsbGRvd24nKSB8fCBGb3VuZGF0aW9uLkdldFlvRGlnaXRzKDYsICdkcmlsbGRvd24nKSkpO1xuXG4gICAgdGhpcy5fcHJlcGFyZU1lbnUoKTtcbiAgICB0aGlzLl9yZWdpc3RlckV2ZW50cygpO1xuXG4gICAgdGhpcy5fa2V5Ym9hcmRFdmVudHMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBwcmVwYXJlcyBkcmlsbGRvd24gbWVudSBieSBzZXR0aW5nIGF0dHJpYnV0ZXMgdG8gbGlua3MgYW5kIGVsZW1lbnRzXG4gICAqIHNldHMgYSBtaW4gaGVpZ2h0IHRvIHByZXZlbnQgY29udGVudCBqdW1waW5nXG4gICAqIHdyYXBzIHRoZSBlbGVtZW50IGlmIG5vdCBhbHJlYWR5IHdyYXBwZWRcbiAgICogQHByaXZhdGVcbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICBfcHJlcGFyZU1lbnUoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAvLyBpZighdGhpcy5vcHRpb25zLmhvbGRPcGVuKXtcbiAgICAvLyAgIHRoaXMuX21lbnVMaW5rRXZlbnRzKCk7XG4gICAgLy8gfVxuICAgIHRoaXMuJHN1Ym1lbnVBbmNob3JzLmVhY2goZnVuY3Rpb24oKXtcbiAgICAgIHZhciAkbGluayA9ICQodGhpcyk7XG4gICAgICB2YXIgJHN1YiA9ICRsaW5rLnBhcmVudCgpO1xuICAgICAgaWYoX3RoaXMub3B0aW9ucy5wYXJlbnRMaW5rKXtcbiAgICAgICAgJGxpbmsuY2xvbmUoKS5wcmVwZW5kVG8oJHN1Yi5jaGlsZHJlbignW2RhdGEtc3VibWVudV0nKSkud3JhcCgnPGxpIGNsYXNzPVwiaXMtc3VibWVudS1wYXJlbnQtaXRlbSBpcy1zdWJtZW51LWl0ZW0gaXMtZHJpbGxkb3duLXN1Ym1lbnUtaXRlbVwiIHJvbGU9XCJtZW51LWl0ZW1cIj48L2xpPicpO1xuICAgICAgfVxuICAgICAgJGxpbmsuZGF0YSgnc2F2ZWRIcmVmJywgJGxpbmsuYXR0cignaHJlZicpKS5yZW1vdmVBdHRyKCdocmVmJykuYXR0cigndGFiaW5kZXgnLCAwKTtcbiAgICAgICRsaW5rLmNoaWxkcmVuKCdbZGF0YS1zdWJtZW51XScpXG4gICAgICAgICAgLmF0dHIoe1xuICAgICAgICAgICAgJ2FyaWEtaGlkZGVuJzogdHJ1ZSxcbiAgICAgICAgICAgICd0YWJpbmRleCc6IDAsXG4gICAgICAgICAgICAncm9sZSc6ICdtZW51J1xuICAgICAgICAgIH0pO1xuICAgICAgX3RoaXMuX2V2ZW50cygkbGluayk7XG4gICAgfSk7XG4gICAgdGhpcy4kc3VibWVudXMuZWFjaChmdW5jdGlvbigpe1xuICAgICAgdmFyICRtZW51ID0gJCh0aGlzKSxcbiAgICAgICAgICAkYmFjayA9ICRtZW51LmZpbmQoJy5qcy1kcmlsbGRvd24tYmFjaycpO1xuICAgICAgaWYoISRiYWNrLmxlbmd0aCl7XG4gICAgICAgIHN3aXRjaCAoX3RoaXMub3B0aW9ucy5iYWNrQnV0dG9uUG9zaXRpb24pIHtcbiAgICAgICAgICBjYXNlIFwiYm90dG9tXCI6XG4gICAgICAgICAgICAkbWVudS5hcHBlbmQoX3RoaXMub3B0aW9ucy5iYWNrQnV0dG9uKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgXCJ0b3BcIjpcbiAgICAgICAgICAgICRtZW51LnByZXBlbmQoX3RoaXMub3B0aW9ucy5iYWNrQnV0dG9uKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiVW5zdXBwb3J0ZWQgYmFja0J1dHRvblBvc2l0aW9uIHZhbHVlICdcIiArIF90aGlzLm9wdGlvbnMuYmFja0J1dHRvblBvc2l0aW9uICsgXCInXCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBfdGhpcy5fYmFjaygkbWVudSk7XG4gICAgfSk7XG5cbiAgICBpZighdGhpcy5vcHRpb25zLmF1dG9IZWlnaHQpIHtcbiAgICAgIHRoaXMuJHN1Ym1lbnVzLmFkZENsYXNzKCdkcmlsbGRvd24tc3VibWVudS1jb3Zlci1wcmV2aW91cycpO1xuICAgIH1cblxuICAgIGlmKCF0aGlzLiRlbGVtZW50LnBhcmVudCgpLmhhc0NsYXNzKCdpcy1kcmlsbGRvd24nKSl7XG4gICAgICB0aGlzLiR3cmFwcGVyID0gJCh0aGlzLm9wdGlvbnMud3JhcHBlcikuYWRkQ2xhc3MoJ2lzLWRyaWxsZG93bicpO1xuICAgICAgaWYodGhpcy5vcHRpb25zLmFuaW1hdGVIZWlnaHQpIHRoaXMuJHdyYXBwZXIuYWRkQ2xhc3MoJ2FuaW1hdGUtaGVpZ2h0Jyk7XG4gICAgICB0aGlzLiR3cmFwcGVyID0gdGhpcy4kZWxlbWVudC53cmFwKHRoaXMuJHdyYXBwZXIpLnBhcmVudCgpLmNzcyh0aGlzLl9nZXRNYXhEaW1zKCkpO1xuICAgIH1cbiAgfVxuXG4gIF9yZXNpemUoKSB7XG4gICAgdGhpcy4kd3JhcHBlci5jc3MoeydtYXgtd2lkdGgnOiAnbm9uZScsICdtaW4taGVpZ2h0JzogJ25vbmUnfSk7XG4gICAgLy8gX2dldE1heERpbXMgaGFzIHNpZGUgZWZmZWN0cyAoYm9vKSBidXQgY2FsbGluZyBpdCBzaG91bGQgdXBkYXRlIGFsbCBvdGhlciBuZWNlc3NhcnkgaGVpZ2h0cyAmIHdpZHRoc1xuICAgIHRoaXMuJHdyYXBwZXIuY3NzKHRoaXMuX2dldE1heERpbXMoKSk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBldmVudCBoYW5kbGVycyB0byBlbGVtZW50cyBpbiB0aGUgbWVudS5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqIEBwYXJhbSB7alF1ZXJ5fSAkZWxlbSAtIHRoZSBjdXJyZW50IG1lbnUgaXRlbSB0byBhZGQgaGFuZGxlcnMgdG8uXG4gICAqL1xuICBfZXZlbnRzKCRlbGVtKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICRlbGVtLm9mZignY2xpY2suemYuZHJpbGxkb3duJylcbiAgICAub24oJ2NsaWNrLnpmLmRyaWxsZG93bicsIGZ1bmN0aW9uKGUpe1xuICAgICAgaWYoJChlLnRhcmdldCkucGFyZW50c1VudGlsKCd1bCcsICdsaScpLmhhc0NsYXNzKCdpcy1kcmlsbGRvd24tc3VibWVudS1wYXJlbnQnKSl7XG4gICAgICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH1cblxuICAgICAgLy8gaWYoZS50YXJnZXQgIT09IGUuY3VycmVudFRhcmdldC5maXJzdEVsZW1lbnRDaGlsZCl7XG4gICAgICAvLyAgIHJldHVybiBmYWxzZTtcbiAgICAgIC8vIH1cbiAgICAgIF90aGlzLl9zaG93KCRlbGVtLnBhcmVudCgnbGknKSk7XG5cbiAgICAgIGlmKF90aGlzLm9wdGlvbnMuY2xvc2VPbkNsaWNrKXtcbiAgICAgICAgdmFyICRib2R5ID0gJCgnYm9keScpO1xuICAgICAgICAkYm9keS5vZmYoJy56Zi5kcmlsbGRvd24nKS5vbignY2xpY2suemYuZHJpbGxkb3duJywgZnVuY3Rpb24oZSl7XG4gICAgICAgICAgaWYgKGUudGFyZ2V0ID09PSBfdGhpcy4kZWxlbWVudFswXSB8fCAkLmNvbnRhaW5zKF90aGlzLiRlbGVtZW50WzBdLCBlLnRhcmdldCkpIHsgcmV0dXJuOyB9XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIF90aGlzLl9oaWRlQWxsKCk7XG4gICAgICAgICAgJGJvZHkub2ZmKCcuemYuZHJpbGxkb3duJyk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuXHQgIHRoaXMuJGVsZW1lbnQub24oJ211dGF0ZW1lLnpmLnRyaWdnZXInLCB0aGlzLl9yZXNpemUuYmluZCh0aGlzKSk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBldmVudCBoYW5kbGVycyB0byB0aGUgbWVudSBlbGVtZW50LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9yZWdpc3RlckV2ZW50cygpIHtcbiAgICBpZih0aGlzLm9wdGlvbnMuc2Nyb2xsVG9wKXtcbiAgICAgIHRoaXMuX2JpbmRIYW5kbGVyID0gdGhpcy5fc2Nyb2xsVG9wLmJpbmQodGhpcyk7XG4gICAgICB0aGlzLiRlbGVtZW50Lm9uKCdvcGVuLnpmLmRyaWxsZG93biBoaWRlLnpmLmRyaWxsZG93biBjbG9zZWQuemYuZHJpbGxkb3duJyx0aGlzLl9iaW5kSGFuZGxlcik7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFNjcm9sbCB0byBUb3Agb2YgRWxlbWVudCBvciBkYXRhLXNjcm9sbC10b3AtZWxlbWVudFxuICAgKiBAZnVuY3Rpb25cbiAgICogQGZpcmVzIERyaWxsZG93biNzY3JvbGxtZVxuICAgKi9cbiAgX3Njcm9sbFRvcCgpIHtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgIHZhciAkc2Nyb2xsVG9wRWxlbWVudCA9IF90aGlzLm9wdGlvbnMuc2Nyb2xsVG9wRWxlbWVudCE9Jyc/JChfdGhpcy5vcHRpb25zLnNjcm9sbFRvcEVsZW1lbnQpOl90aGlzLiRlbGVtZW50LFxuICAgICAgICBzY3JvbGxQb3MgPSBwYXJzZUludCgkc2Nyb2xsVG9wRWxlbWVudC5vZmZzZXQoKS50b3ArX3RoaXMub3B0aW9ucy5zY3JvbGxUb3BPZmZzZXQpO1xuICAgICQoJ2h0bWwsIGJvZHknKS5zdG9wKHRydWUpLmFuaW1hdGUoeyBzY3JvbGxUb3A6IHNjcm9sbFBvcyB9LCBfdGhpcy5vcHRpb25zLmFuaW1hdGlvbkR1cmF0aW9uLCBfdGhpcy5vcHRpb25zLmFuaW1hdGlvbkVhc2luZyxmdW5jdGlvbigpe1xuICAgICAgLyoqXG4gICAgICAgICogRmlyZXMgYWZ0ZXIgdGhlIG1lbnUgaGFzIHNjcm9sbGVkXG4gICAgICAgICogQGV2ZW50IERyaWxsZG93biNzY3JvbGxtZVxuICAgICAgICAqL1xuICAgICAgaWYodGhpcz09PSQoJ2h0bWwnKVswXSlfdGhpcy4kZWxlbWVudC50cmlnZ2VyKCdzY3JvbGxtZS56Zi5kcmlsbGRvd24nKTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGtleWRvd24gZXZlbnQgbGlzdGVuZXIgdG8gYGxpYCdzIGluIHRoZSBtZW51LlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2tleWJvYXJkRXZlbnRzKCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICB0aGlzLiRtZW51SXRlbXMuYWRkKHRoaXMuJGVsZW1lbnQuZmluZCgnLmpzLWRyaWxsZG93bi1iYWNrID4gYSwgLmlzLXN1Ym1lbnUtcGFyZW50LWl0ZW0gPiBhJykpLm9uKCdrZXlkb3duLnpmLmRyaWxsZG93bicsIGZ1bmN0aW9uKGUpe1xuICAgICAgdmFyICRlbGVtZW50ID0gJCh0aGlzKSxcbiAgICAgICAgICAkZWxlbWVudHMgPSAkZWxlbWVudC5wYXJlbnQoJ2xpJykucGFyZW50KCd1bCcpLmNoaWxkcmVuKCdsaScpLmNoaWxkcmVuKCdhJyksXG4gICAgICAgICAgJHByZXZFbGVtZW50LFxuICAgICAgICAgICRuZXh0RWxlbWVudDtcblxuICAgICAgJGVsZW1lbnRzLmVhY2goZnVuY3Rpb24oaSkge1xuICAgICAgICBpZiAoJCh0aGlzKS5pcygkZWxlbWVudCkpIHtcbiAgICAgICAgICAkcHJldkVsZW1lbnQgPSAkZWxlbWVudHMuZXEoTWF0aC5tYXgoMCwgaS0xKSk7XG4gICAgICAgICAgJG5leHRFbGVtZW50ID0gJGVsZW1lbnRzLmVxKE1hdGgubWluKGkrMSwgJGVsZW1lbnRzLmxlbmd0aC0xKSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgRm91bmRhdGlvbi5LZXlib2FyZC5oYW5kbGVLZXkoZSwgJ0RyaWxsZG93bicsIHtcbiAgICAgICAgbmV4dDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgaWYgKCRlbGVtZW50LmlzKF90aGlzLiRzdWJtZW51QW5jaG9ycykpIHtcbiAgICAgICAgICAgIF90aGlzLl9zaG93KCRlbGVtZW50LnBhcmVudCgnbGknKSk7XG4gICAgICAgICAgICAkZWxlbWVudC5wYXJlbnQoJ2xpJykub25lKEZvdW5kYXRpb24udHJhbnNpdGlvbmVuZCgkZWxlbWVudCksIGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICRlbGVtZW50LnBhcmVudCgnbGknKS5maW5kKCd1bCBsaSBhJykuZmlsdGVyKF90aGlzLiRtZW51SXRlbXMpLmZpcnN0KCkuZm9jdXMoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBwcmV2aW91czogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgX3RoaXMuX2hpZGUoJGVsZW1lbnQucGFyZW50KCdsaScpLnBhcmVudCgndWwnKSk7XG4gICAgICAgICAgJGVsZW1lbnQucGFyZW50KCdsaScpLnBhcmVudCgndWwnKS5vbmUoRm91bmRhdGlvbi50cmFuc2l0aW9uZW5kKCRlbGVtZW50KSwgZnVuY3Rpb24oKXtcbiAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICRlbGVtZW50LnBhcmVudCgnbGknKS5wYXJlbnQoJ3VsJykucGFyZW50KCdsaScpLmNoaWxkcmVuKCdhJykuZmlyc3QoKS5mb2N1cygpO1xuICAgICAgICAgICAgfSwgMSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH0sXG4gICAgICAgIHVwOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAkcHJldkVsZW1lbnQuZm9jdXMoKTtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSxcbiAgICAgICAgZG93bjogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgJG5leHRFbGVtZW50LmZvY3VzKCk7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH0sXG4gICAgICAgIGNsb3NlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICBfdGhpcy5fYmFjaygpO1xuICAgICAgICAgIC8vX3RoaXMuJG1lbnVJdGVtcy5maXJzdCgpLmZvY3VzKCk7IC8vIGZvY3VzIHRvIGZpcnN0IGVsZW1lbnRcbiAgICAgICAgfSxcbiAgICAgICAgb3BlbjogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgaWYgKCEkZWxlbWVudC5pcyhfdGhpcy4kbWVudUl0ZW1zKSkgeyAvLyBub3QgbWVudSBpdGVtIG1lYW5zIGJhY2sgYnV0dG9uXG4gICAgICAgICAgICBfdGhpcy5faGlkZSgkZWxlbWVudC5wYXJlbnQoJ2xpJykucGFyZW50KCd1bCcpKTtcbiAgICAgICAgICAgICRlbGVtZW50LnBhcmVudCgnbGknKS5wYXJlbnQoJ3VsJykub25lKEZvdW5kYXRpb24udHJhbnNpdGlvbmVuZCgkZWxlbWVudCksIGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgJGVsZW1lbnQucGFyZW50KCdsaScpLnBhcmVudCgndWwnKS5wYXJlbnQoJ2xpJykuY2hpbGRyZW4oJ2EnKS5maXJzdCgpLmZvY3VzKCk7XG4gICAgICAgICAgICAgIH0sIDEpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICB9IGVsc2UgaWYgKCRlbGVtZW50LmlzKF90aGlzLiRzdWJtZW51QW5jaG9ycykpIHtcbiAgICAgICAgICAgIF90aGlzLl9zaG93KCRlbGVtZW50LnBhcmVudCgnbGknKSk7XG4gICAgICAgICAgICAkZWxlbWVudC5wYXJlbnQoJ2xpJykub25lKEZvdW5kYXRpb24udHJhbnNpdGlvbmVuZCgkZWxlbWVudCksIGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICRlbGVtZW50LnBhcmVudCgnbGknKS5maW5kKCd1bCBsaSBhJykuZmlsdGVyKF90aGlzLiRtZW51SXRlbXMpLmZpcnN0KCkuZm9jdXMoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBoYW5kbGVkOiBmdW5jdGlvbihwcmV2ZW50RGVmYXVsdCkge1xuICAgICAgICAgIGlmIChwcmV2ZW50RGVmYXVsdCkge1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTsgLy8gZW5kIGtleWJvYXJkQWNjZXNzXG4gIH1cblxuICAvKipcbiAgICogQ2xvc2VzIGFsbCBvcGVuIGVsZW1lbnRzLCBhbmQgcmV0dXJucyB0byByb290IG1lbnUuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAZmlyZXMgRHJpbGxkb3duI2Nsb3NlZFxuICAgKi9cbiAgX2hpZGVBbGwoKSB7XG4gICAgdmFyICRlbGVtID0gdGhpcy4kZWxlbWVudC5maW5kKCcuaXMtZHJpbGxkb3duLXN1Ym1lbnUuaXMtYWN0aXZlJykuYWRkQ2xhc3MoJ2lzLWNsb3NpbmcnKTtcbiAgICBpZih0aGlzLm9wdGlvbnMuYXV0b0hlaWdodCkgdGhpcy4kd3JhcHBlci5jc3Moe2hlaWdodDokZWxlbS5wYXJlbnQoKS5jbG9zZXN0KCd1bCcpLmRhdGEoJ2NhbGNIZWlnaHQnKX0pO1xuICAgICRlbGVtLm9uZShGb3VuZGF0aW9uLnRyYW5zaXRpb25lbmQoJGVsZW0pLCBmdW5jdGlvbihlKXtcbiAgICAgICRlbGVtLnJlbW92ZUNsYXNzKCdpcy1hY3RpdmUgaXMtY2xvc2luZycpO1xuICAgIH0pO1xuICAgICAgICAvKipcbiAgICAgICAgICogRmlyZXMgd2hlbiB0aGUgbWVudSBpcyBmdWxseSBjbG9zZWQuXG4gICAgICAgICAqIEBldmVudCBEcmlsbGRvd24jY2xvc2VkXG4gICAgICAgICAqL1xuICAgIHRoaXMuJGVsZW1lbnQudHJpZ2dlcignY2xvc2VkLnpmLmRyaWxsZG93bicpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgZXZlbnQgbGlzdGVuZXIgZm9yIGVhY2ggYGJhY2tgIGJ1dHRvbiwgYW5kIGNsb3NlcyBvcGVuIG1lbnVzLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQGZpcmVzIERyaWxsZG93biNiYWNrXG4gICAqIEBwYXJhbSB7alF1ZXJ5fSAkZWxlbSAtIHRoZSBjdXJyZW50IHN1Yi1tZW51IHRvIGFkZCBgYmFja2AgZXZlbnQuXG4gICAqL1xuICBfYmFjaygkZWxlbSkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgJGVsZW0ub2ZmKCdjbGljay56Zi5kcmlsbGRvd24nKTtcbiAgICAkZWxlbS5jaGlsZHJlbignLmpzLWRyaWxsZG93bi1iYWNrJylcbiAgICAgIC5vbignY2xpY2suemYuZHJpbGxkb3duJywgZnVuY3Rpb24oZSl7XG4gICAgICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdtb3VzZXVwIG9uIGJhY2snKTtcbiAgICAgICAgX3RoaXMuX2hpZGUoJGVsZW0pO1xuXG4gICAgICAgIC8vIElmIHRoZXJlIGlzIGEgcGFyZW50IHN1Ym1lbnUsIGNhbGwgc2hvd1xuICAgICAgICBsZXQgcGFyZW50U3ViTWVudSA9ICRlbGVtLnBhcmVudCgnbGknKS5wYXJlbnQoJ3VsJykucGFyZW50KCdsaScpO1xuICAgICAgICBpZiAocGFyZW50U3ViTWVudS5sZW5ndGgpIHtcbiAgICAgICAgICBfdGhpcy5fc2hvdyhwYXJlbnRTdWJNZW51KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBldmVudCBsaXN0ZW5lciB0byBtZW51IGl0ZW1zIHcvbyBzdWJtZW51cyB0byBjbG9zZSBvcGVuIG1lbnVzIG9uIGNsaWNrLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9tZW51TGlua0V2ZW50cygpIHtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgIHRoaXMuJG1lbnVJdGVtcy5ub3QoJy5pcy1kcmlsbGRvd24tc3VibWVudS1wYXJlbnQnKVxuICAgICAgICAub2ZmKCdjbGljay56Zi5kcmlsbGRvd24nKVxuICAgICAgICAub24oJ2NsaWNrLnpmLmRyaWxsZG93bicsIGZ1bmN0aW9uKGUpe1xuICAgICAgICAgIC8vIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpe1xuICAgICAgICAgICAgX3RoaXMuX2hpZGVBbGwoKTtcbiAgICAgICAgICB9LCAwKTtcbiAgICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIE9wZW5zIGEgc3VibWVudS5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBmaXJlcyBEcmlsbGRvd24jb3BlblxuICAgKiBAcGFyYW0ge2pRdWVyeX0gJGVsZW0gLSB0aGUgY3VycmVudCBlbGVtZW50IHdpdGggYSBzdWJtZW51IHRvIG9wZW4sIGkuZS4gdGhlIGBsaWAgdGFnLlxuICAgKi9cbiAgX3Nob3coJGVsZW0pIHtcbiAgICBpZih0aGlzLm9wdGlvbnMuYXV0b0hlaWdodCkgdGhpcy4kd3JhcHBlci5jc3Moe2hlaWdodDokZWxlbS5jaGlsZHJlbignW2RhdGEtc3VibWVudV0nKS5kYXRhKCdjYWxjSGVpZ2h0Jyl9KTtcbiAgICAkZWxlbS5hdHRyKCdhcmlhLWV4cGFuZGVkJywgdHJ1ZSk7XG4gICAgJGVsZW0uY2hpbGRyZW4oJ1tkYXRhLXN1Ym1lbnVdJykuYWRkQ2xhc3MoJ2lzLWFjdGl2ZScpLmF0dHIoJ2FyaWEtaGlkZGVuJywgZmFsc2UpO1xuICAgIC8qKlxuICAgICAqIEZpcmVzIHdoZW4gdGhlIHN1Ym1lbnUgaGFzIG9wZW5lZC5cbiAgICAgKiBAZXZlbnQgRHJpbGxkb3duI29wZW5cbiAgICAgKi9cbiAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ29wZW4uemYuZHJpbGxkb3duJywgWyRlbGVtXSk7XG4gIH07XG5cbiAgLyoqXG4gICAqIEhpZGVzIGEgc3VibWVudVxuICAgKiBAZnVuY3Rpb25cbiAgICogQGZpcmVzIERyaWxsZG93biNoaWRlXG4gICAqIEBwYXJhbSB7alF1ZXJ5fSAkZWxlbSAtIHRoZSBjdXJyZW50IHN1Yi1tZW51IHRvIGhpZGUsIGkuZS4gdGhlIGB1bGAgdGFnLlxuICAgKi9cbiAgX2hpZGUoJGVsZW0pIHtcbiAgICBpZih0aGlzLm9wdGlvbnMuYXV0b0hlaWdodCkgdGhpcy4kd3JhcHBlci5jc3Moe2hlaWdodDokZWxlbS5wYXJlbnQoKS5jbG9zZXN0KCd1bCcpLmRhdGEoJ2NhbGNIZWlnaHQnKX0pO1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgJGVsZW0ucGFyZW50KCdsaScpLmF0dHIoJ2FyaWEtZXhwYW5kZWQnLCBmYWxzZSk7XG4gICAgJGVsZW0uYXR0cignYXJpYS1oaWRkZW4nLCB0cnVlKS5hZGRDbGFzcygnaXMtY2xvc2luZycpXG4gICAgJGVsZW0uYWRkQ2xhc3MoJ2lzLWNsb3NpbmcnKVxuICAgICAgICAgLm9uZShGb3VuZGF0aW9uLnRyYW5zaXRpb25lbmQoJGVsZW0pLCBmdW5jdGlvbigpe1xuICAgICAgICAgICAkZWxlbS5yZW1vdmVDbGFzcygnaXMtYWN0aXZlIGlzLWNsb3NpbmcnKTtcbiAgICAgICAgICAgJGVsZW0uYmx1cigpO1xuICAgICAgICAgfSk7XG4gICAgLyoqXG4gICAgICogRmlyZXMgd2hlbiB0aGUgc3VibWVudSBoYXMgY2xvc2VkLlxuICAgICAqIEBldmVudCBEcmlsbGRvd24jaGlkZVxuICAgICAqL1xuICAgICRlbGVtLnRyaWdnZXIoJ2hpZGUuemYuZHJpbGxkb3duJywgWyRlbGVtXSk7XG4gIH1cblxuICAvKipcbiAgICogSXRlcmF0ZXMgdGhyb3VnaCB0aGUgbmVzdGVkIG1lbnVzIHRvIGNhbGN1bGF0ZSB0aGUgbWluLWhlaWdodCwgYW5kIG1heC13aWR0aCBmb3IgdGhlIG1lbnUuXG4gICAqIFByZXZlbnRzIGNvbnRlbnQganVtcGluZy5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfZ2V0TWF4RGltcygpIHtcbiAgICB2YXIgIG1heEhlaWdodCA9IDAsIHJlc3VsdCA9IHt9LCBfdGhpcyA9IHRoaXM7XG4gICAgdGhpcy4kc3VibWVudXMuYWRkKHRoaXMuJGVsZW1lbnQpLmVhY2goZnVuY3Rpb24oKXtcbiAgICAgIHZhciBudW1PZkVsZW1zID0gJCh0aGlzKS5jaGlsZHJlbignbGknKS5sZW5ndGg7XG4gICAgICB2YXIgaGVpZ2h0ID0gRm91bmRhdGlvbi5Cb3guR2V0RGltZW5zaW9ucyh0aGlzKS5oZWlnaHQ7XG4gICAgICBtYXhIZWlnaHQgPSBoZWlnaHQgPiBtYXhIZWlnaHQgPyBoZWlnaHQgOiBtYXhIZWlnaHQ7XG4gICAgICBpZihfdGhpcy5vcHRpb25zLmF1dG9IZWlnaHQpIHtcbiAgICAgICAgJCh0aGlzKS5kYXRhKCdjYWxjSGVpZ2h0JyxoZWlnaHQpO1xuICAgICAgICBpZiAoISQodGhpcykuaGFzQ2xhc3MoJ2lzLWRyaWxsZG93bi1zdWJtZW51JykpIHJlc3VsdFsnaGVpZ2h0J10gPSBoZWlnaHQ7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBpZighdGhpcy5vcHRpb25zLmF1dG9IZWlnaHQpIHJlc3VsdFsnbWluLWhlaWdodCddID0gYCR7bWF4SGVpZ2h0fXB4YDtcblxuICAgIHJlc3VsdFsnbWF4LXdpZHRoJ10gPSBgJHt0aGlzLiRlbGVtZW50WzBdLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRofXB4YDtcblxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICAvKipcbiAgICogRGVzdHJveXMgdGhlIERyaWxsZG93biBNZW51XG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgZGVzdHJveSgpIHtcbiAgICBpZih0aGlzLm9wdGlvbnMuc2Nyb2xsVG9wKSB0aGlzLiRlbGVtZW50Lm9mZignLnpmLmRyaWxsZG93bicsdGhpcy5fYmluZEhhbmRsZXIpO1xuICAgIHRoaXMuX2hpZGVBbGwoKTtcblx0ICB0aGlzLiRlbGVtZW50Lm9mZignbXV0YXRlbWUuemYudHJpZ2dlcicpO1xuICAgIEZvdW5kYXRpb24uTmVzdC5CdXJuKHRoaXMuJGVsZW1lbnQsICdkcmlsbGRvd24nKTtcbiAgICB0aGlzLiRlbGVtZW50LnVud3JhcCgpXG4gICAgICAgICAgICAgICAgIC5maW5kKCcuanMtZHJpbGxkb3duLWJhY2ssIC5pcy1zdWJtZW51LXBhcmVudC1pdGVtJykucmVtb3ZlKClcbiAgICAgICAgICAgICAgICAgLmVuZCgpLmZpbmQoJy5pcy1hY3RpdmUsIC5pcy1jbG9zaW5nLCAuaXMtZHJpbGxkb3duLXN1Ym1lbnUnKS5yZW1vdmVDbGFzcygnaXMtYWN0aXZlIGlzLWNsb3NpbmcgaXMtZHJpbGxkb3duLXN1Ym1lbnUnKVxuICAgICAgICAgICAgICAgICAuZW5kKCkuZmluZCgnW2RhdGEtc3VibWVudV0nKS5yZW1vdmVBdHRyKCdhcmlhLWhpZGRlbiB0YWJpbmRleCByb2xlJyk7XG4gICAgdGhpcy4kc3VibWVudUFuY2hvcnMuZWFjaChmdW5jdGlvbigpIHtcbiAgICAgICQodGhpcykub2ZmKCcuemYuZHJpbGxkb3duJyk7XG4gICAgfSk7XG5cbiAgICB0aGlzLiRzdWJtZW51cy5yZW1vdmVDbGFzcygnZHJpbGxkb3duLXN1Ym1lbnUtY292ZXItcHJldmlvdXMnKTtcblxuICAgIHRoaXMuJGVsZW1lbnQuZmluZCgnYScpLmVhY2goZnVuY3Rpb24oKXtcbiAgICAgIHZhciAkbGluayA9ICQodGhpcyk7XG4gICAgICAkbGluay5yZW1vdmVBdHRyKCd0YWJpbmRleCcpO1xuICAgICAgaWYoJGxpbmsuZGF0YSgnc2F2ZWRIcmVmJykpe1xuICAgICAgICAkbGluay5hdHRyKCdocmVmJywgJGxpbmsuZGF0YSgnc2F2ZWRIcmVmJykpLnJlbW92ZURhdGEoJ3NhdmVkSHJlZicpO1xuICAgICAgfWVsc2V7IHJldHVybjsgfVxuICAgIH0pO1xuICAgIEZvdW5kYXRpb24udW5yZWdpc3RlclBsdWdpbih0aGlzKTtcbiAgfTtcbn1cblxuRHJpbGxkb3duLmRlZmF1bHRzID0ge1xuICAvKipcbiAgICogTWFya3VwIHVzZWQgZm9yIEpTIGdlbmVyYXRlZCBiYWNrIGJ1dHRvbi4gUHJlcGVuZGVkICBvciBhcHBlbmRlZCAoc2VlIGJhY2tCdXR0b25Qb3NpdGlvbikgdG8gc3VibWVudSBsaXN0cyBhbmQgZGVsZXRlZCBvbiBgZGVzdHJveWAgbWV0aG9kLCAnanMtZHJpbGxkb3duLWJhY2snIGNsYXNzIHJlcXVpcmVkLiBSZW1vdmUgdGhlIGJhY2tzbGFzaCAoYFxcYCkgaWYgY29weSBhbmQgcGFzdGluZy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnPFxcbGk+PFxcYT5CYWNrPFxcL2E+PFxcL2xpPidcbiAgICovXG4gIGJhY2tCdXR0b246ICc8bGkgY2xhc3M9XCJqcy1kcmlsbGRvd24tYmFja1wiPjxhIHRhYmluZGV4PVwiMFwiPkJhY2s8L2E+PC9saT4nLFxuICAvKipcbiAgICogUG9zaXRpb24gdGhlIGJhY2sgYnV0dG9uIGVpdGhlciBhdCB0aGUgdG9wIG9yIGJvdHRvbSBvZiBkcmlsbGRvd24gc3VibWVudXMuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgYm90dG9tXG4gICAqL1xuICBiYWNrQnV0dG9uUG9zaXRpb246ICd0b3AnLFxuICAvKipcbiAgICogTWFya3VwIHVzZWQgdG8gd3JhcCBkcmlsbGRvd24gbWVudS4gVXNlIGEgY2xhc3MgbmFtZSBmb3IgaW5kZXBlbmRlbnQgc3R5bGluZzsgdGhlIEpTIGFwcGxpZWQgY2xhc3M6IGBpcy1kcmlsbGRvd25gIGlzIHJlcXVpcmVkLiBSZW1vdmUgdGhlIGJhY2tzbGFzaCAoYFxcYCkgaWYgY29weSBhbmQgcGFzdGluZy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnPFxcZGl2IGNsYXNzPVwiaXMtZHJpbGxkb3duXCI+PFxcL2Rpdj4nXG4gICAqL1xuICB3cmFwcGVyOiAnPGRpdj48L2Rpdj4nLFxuICAvKipcbiAgICogQWRkcyB0aGUgcGFyZW50IGxpbmsgdG8gdGhlIHN1Ym1lbnUuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgZmFsc2VcbiAgICovXG4gIHBhcmVudExpbms6IGZhbHNlLFxuICAvKipcbiAgICogQWxsb3cgdGhlIG1lbnUgdG8gcmV0dXJuIHRvIHJvb3QgbGlzdCBvbiBib2R5IGNsaWNrLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICBjbG9zZU9uQ2xpY2s6IGZhbHNlLFxuICAvKipcbiAgICogQWxsb3cgdGhlIG1lbnUgdG8gYXV0byBhZGp1c3QgaGVpZ2h0LlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICBhdXRvSGVpZ2h0OiBmYWxzZSxcbiAgLyoqXG4gICAqIEFuaW1hdGUgdGhlIGF1dG8gYWRqdXN0IGhlaWdodC5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBmYWxzZVxuICAgKi9cbiAgYW5pbWF0ZUhlaWdodDogZmFsc2UsXG4gIC8qKlxuICAgKiBTY3JvbGwgdG8gdGhlIHRvcCBvZiB0aGUgbWVudSBhZnRlciBvcGVuaW5nIGEgc3VibWVudSBvciBuYXZpZ2F0aW5nIGJhY2sgdXNpbmcgdGhlIG1lbnUgYmFjayBidXR0b25cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBmYWxzZVxuICAgKi9cbiAgc2Nyb2xsVG9wOiBmYWxzZSxcbiAgLyoqXG4gICAqIFN0cmluZyBqcXVlcnkgc2VsZWN0b3IgKGZvciBleGFtcGxlICdib2R5Jykgb2YgZWxlbWVudCB0byB0YWtlIG9mZnNldCgpLnRvcCBmcm9tLCBpZiBlbXB0eSBzdHJpbmcgdGhlIGRyaWxsZG93biBtZW51IG9mZnNldCgpLnRvcCBpcyB0YWtlblxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlICcnXG4gICAqL1xuICBzY3JvbGxUb3BFbGVtZW50OiAnJyxcbiAgLyoqXG4gICAqIFNjcm9sbFRvcCBvZmZzZXRcbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAxMDBcbiAgICovXG4gIHNjcm9sbFRvcE9mZnNldDogMCxcbiAgLyoqXG4gICAqIFNjcm9sbCBhbmltYXRpb24gZHVyYXRpb25cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSA1MDBcbiAgICovXG4gIGFuaW1hdGlvbkR1cmF0aW9uOiA1MDAsXG4gIC8qKlxuICAgKiBTY3JvbGwgYW5pbWF0aW9uIGVhc2luZ1xuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlICdzd2luZydcbiAgICovXG4gIGFuaW1hdGlvbkVhc2luZzogJ3N3aW5nJ1xuICAvLyBob2xkT3BlbjogZmFsc2Vcbn07XG5cbi8vIFdpbmRvdyBleHBvcnRzXG5Gb3VuZGF0aW9uLnBsdWdpbihEcmlsbGRvd24sICdEcmlsbGRvd24nKTtcblxufShqUXVlcnkpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4hZnVuY3Rpb24oJCkge1xuXG4vKipcbiAqIERyb3Bkb3duIG1vZHVsZS5cbiAqIEBtb2R1bGUgZm91bmRhdGlvbi5kcm9wZG93blxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC5rZXlib2FyZFxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC5ib3hcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwudHJpZ2dlcnNcbiAqL1xuXG5jbGFzcyBEcm9wZG93biB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IGluc3RhbmNlIG9mIGEgZHJvcGRvd24uXG4gICAqIEBjbGFzc1xuICAgKiBAcGFyYW0ge2pRdWVyeX0gZWxlbWVudCAtIGpRdWVyeSBvYmplY3QgdG8gbWFrZSBpbnRvIGEgZHJvcGRvd24uXG4gICAqICAgICAgICBPYmplY3Qgc2hvdWxkIGJlIG9mIHRoZSBkcm9wZG93biBwYW5lbCwgcmF0aGVyIHRoYW4gaXRzIGFuY2hvci5cbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMgLSBPdmVycmlkZXMgdG8gdGhlIGRlZmF1bHQgcGx1Z2luIHNldHRpbmdzLlxuICAgKi9cbiAgY29uc3RydWN0b3IoZWxlbWVudCwgb3B0aW9ucykge1xuICAgIHRoaXMuJGVsZW1lbnQgPSBlbGVtZW50O1xuICAgIHRoaXMub3B0aW9ucyA9ICQuZXh0ZW5kKHt9LCBEcm9wZG93bi5kZWZhdWx0cywgdGhpcy4kZWxlbWVudC5kYXRhKCksIG9wdGlvbnMpO1xuICAgIHRoaXMuX2luaXQoKTtcblxuICAgIEZvdW5kYXRpb24ucmVnaXN0ZXJQbHVnaW4odGhpcywgJ0Ryb3Bkb3duJyk7XG4gICAgRm91bmRhdGlvbi5LZXlib2FyZC5yZWdpc3RlcignRHJvcGRvd24nLCB7XG4gICAgICAnRU5URVInOiAnb3BlbicsXG4gICAgICAnU1BBQ0UnOiAnb3BlbicsXG4gICAgICAnRVNDQVBFJzogJ2Nsb3NlJ1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEluaXRpYWxpemVzIHRoZSBwbHVnaW4gYnkgc2V0dGluZy9jaGVja2luZyBvcHRpb25zIGFuZCBhdHRyaWJ1dGVzLCBhZGRpbmcgaGVscGVyIHZhcmlhYmxlcywgYW5kIHNhdmluZyB0aGUgYW5jaG9yLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9pbml0KCkge1xuICAgIHZhciAkaWQgPSB0aGlzLiRlbGVtZW50LmF0dHIoJ2lkJyk7XG5cbiAgICB0aGlzLiRhbmNob3IgPSAkKGBbZGF0YS10b2dnbGU9XCIkeyRpZH1cIl1gKS5sZW5ndGggPyAkKGBbZGF0YS10b2dnbGU9XCIkeyRpZH1cIl1gKSA6ICQoYFtkYXRhLW9wZW49XCIkeyRpZH1cIl1gKTtcbiAgICB0aGlzLiRhbmNob3IuYXR0cih7XG4gICAgICAnYXJpYS1jb250cm9scyc6ICRpZCxcbiAgICAgICdkYXRhLWlzLWZvY3VzJzogZmFsc2UsXG4gICAgICAnZGF0YS15ZXRpLWJveCc6ICRpZCxcbiAgICAgICdhcmlhLWhhc3BvcHVwJzogdHJ1ZSxcbiAgICAgICdhcmlhLWV4cGFuZGVkJzogZmFsc2VcblxuICAgIH0pO1xuXG4gICAgaWYodGhpcy5vcHRpb25zLnBhcmVudENsYXNzKXtcbiAgICAgIHRoaXMuJHBhcmVudCA9IHRoaXMuJGVsZW1lbnQucGFyZW50cygnLicgKyB0aGlzLm9wdGlvbnMucGFyZW50Q2xhc3MpO1xuICAgIH1lbHNle1xuICAgICAgdGhpcy4kcGFyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgdGhpcy5vcHRpb25zLnBvc2l0aW9uQ2xhc3MgPSB0aGlzLmdldFBvc2l0aW9uQ2xhc3MoKTtcbiAgICB0aGlzLmNvdW50ZXIgPSA0O1xuICAgIHRoaXMudXNlZFBvc2l0aW9ucyA9IFtdO1xuICAgIHRoaXMuJGVsZW1lbnQuYXR0cih7XG4gICAgICAnYXJpYS1oaWRkZW4nOiAndHJ1ZScsXG4gICAgICAnZGF0YS15ZXRpLWJveCc6ICRpZCxcbiAgICAgICdkYXRhLXJlc2l6ZSc6ICRpZCxcbiAgICAgICdhcmlhLWxhYmVsbGVkYnknOiB0aGlzLiRhbmNob3JbMF0uaWQgfHwgRm91bmRhdGlvbi5HZXRZb0RpZ2l0cyg2LCAnZGQtYW5jaG9yJylcbiAgICB9KTtcbiAgICB0aGlzLl9ldmVudHMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBIZWxwZXIgZnVuY3Rpb24gdG8gZGV0ZXJtaW5lIGN1cnJlbnQgb3JpZW50YXRpb24gb2YgZHJvcGRvd24gcGFuZS5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEByZXR1cm5zIHtTdHJpbmd9IHBvc2l0aW9uIC0gc3RyaW5nIHZhbHVlIG9mIGEgcG9zaXRpb24gY2xhc3MuXG4gICAqL1xuICBnZXRQb3NpdGlvbkNsYXNzKCkge1xuICAgIHZhciB2ZXJ0aWNhbFBvc2l0aW9uID0gdGhpcy4kZWxlbWVudFswXS5jbGFzc05hbWUubWF0Y2goLyh0b3B8bGVmdHxyaWdodHxib3R0b20pL2cpO1xuICAgICAgICB2ZXJ0aWNhbFBvc2l0aW9uID0gdmVydGljYWxQb3NpdGlvbiA/IHZlcnRpY2FsUG9zaXRpb25bMF0gOiAnJztcbiAgICB2YXIgaG9yaXpvbnRhbFBvc2l0aW9uID0gL2Zsb2F0LShcXFMrKS8uZXhlYyh0aGlzLiRhbmNob3JbMF0uY2xhc3NOYW1lKTtcbiAgICAgICAgaG9yaXpvbnRhbFBvc2l0aW9uID0gaG9yaXpvbnRhbFBvc2l0aW9uID8gaG9yaXpvbnRhbFBvc2l0aW9uWzFdIDogJyc7XG4gICAgdmFyIHBvc2l0aW9uID0gaG9yaXpvbnRhbFBvc2l0aW9uID8gaG9yaXpvbnRhbFBvc2l0aW9uICsgJyAnICsgdmVydGljYWxQb3NpdGlvbiA6IHZlcnRpY2FsUG9zaXRpb247XG5cbiAgICByZXR1cm4gcG9zaXRpb247XG4gIH1cblxuICAvKipcbiAgICogQWRqdXN0cyB0aGUgZHJvcGRvd24gcGFuZXMgb3JpZW50YXRpb24gYnkgYWRkaW5nL3JlbW92aW5nIHBvc2l0aW9uaW5nIGNsYXNzZXMuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKiBAcGFyYW0ge1N0cmluZ30gcG9zaXRpb24gLSBwb3NpdGlvbiBjbGFzcyB0byByZW1vdmUuXG4gICAqL1xuICBfcmVwb3NpdGlvbihwb3NpdGlvbikge1xuICAgIHRoaXMudXNlZFBvc2l0aW9ucy5wdXNoKHBvc2l0aW9uID8gcG9zaXRpb24gOiAnYm90dG9tJyk7XG4gICAgLy9kZWZhdWx0LCB0cnkgc3dpdGNoaW5nIHRvIG9wcG9zaXRlIHNpZGVcbiAgICBpZighcG9zaXRpb24gJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCd0b3AnKSA8IDApKXtcbiAgICAgIHRoaXMuJGVsZW1lbnQuYWRkQ2xhc3MoJ3RvcCcpO1xuICAgIH1lbHNlIGlmKHBvc2l0aW9uID09PSAndG9wJyAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2JvdHRvbScpIDwgMCkpe1xuICAgICAgdGhpcy4kZWxlbWVudC5yZW1vdmVDbGFzcyhwb3NpdGlvbik7XG4gICAgfWVsc2UgaWYocG9zaXRpb24gPT09ICdsZWZ0JyAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ3JpZ2h0JykgPCAwKSl7XG4gICAgICB0aGlzLiRlbGVtZW50LnJlbW92ZUNsYXNzKHBvc2l0aW9uKVxuICAgICAgICAgIC5hZGRDbGFzcygncmlnaHQnKTtcbiAgICB9ZWxzZSBpZihwb3NpdGlvbiA9PT0gJ3JpZ2h0JyAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2xlZnQnKSA8IDApKXtcbiAgICAgIHRoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3MocG9zaXRpb24pXG4gICAgICAgICAgLmFkZENsYXNzKCdsZWZ0Jyk7XG4gICAgfVxuXG4gICAgLy9pZiBkZWZhdWx0IGNoYW5nZSBkaWRuJ3Qgd29yaywgdHJ5IGJvdHRvbSBvciBsZWZ0IGZpcnN0XG4gICAgZWxzZSBpZighcG9zaXRpb24gJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCd0b3AnKSA+IC0xKSAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2xlZnQnKSA8IDApKXtcbiAgICAgIHRoaXMuJGVsZW1lbnQuYWRkQ2xhc3MoJ2xlZnQnKTtcbiAgICB9ZWxzZSBpZihwb3NpdGlvbiA9PT0gJ3RvcCcgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdib3R0b20nKSA+IC0xKSAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2xlZnQnKSA8IDApKXtcbiAgICAgIHRoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3MocG9zaXRpb24pXG4gICAgICAgICAgLmFkZENsYXNzKCdsZWZ0Jyk7XG4gICAgfWVsc2UgaWYocG9zaXRpb24gPT09ICdsZWZ0JyAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ3JpZ2h0JykgPiAtMSkgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdib3R0b20nKSA8IDApKXtcbiAgICAgIHRoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3MocG9zaXRpb24pO1xuICAgIH1lbHNlIGlmKHBvc2l0aW9uID09PSAncmlnaHQnICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZignbGVmdCcpID4gLTEpICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZignYm90dG9tJykgPCAwKSl7XG4gICAgICB0aGlzLiRlbGVtZW50LnJlbW92ZUNsYXNzKHBvc2l0aW9uKTtcbiAgICB9XG4gICAgLy9pZiBub3RoaW5nIGNsZWFyZWQsIHNldCB0byBib3R0b21cbiAgICBlbHNle1xuICAgICAgdGhpcy4kZWxlbWVudC5yZW1vdmVDbGFzcyhwb3NpdGlvbik7XG4gICAgfVxuICAgIHRoaXMuY2xhc3NDaGFuZ2VkID0gdHJ1ZTtcbiAgICB0aGlzLmNvdW50ZXItLTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXRzIHRoZSBwb3NpdGlvbiBhbmQgb3JpZW50YXRpb24gb2YgdGhlIGRyb3Bkb3duIHBhbmUsIGNoZWNrcyBmb3IgY29sbGlzaW9ucy5cbiAgICogUmVjdXJzaXZlbHkgY2FsbHMgaXRzZWxmIGlmIGEgY29sbGlzaW9uIGlzIGRldGVjdGVkLCB3aXRoIGEgbmV3IHBvc2l0aW9uIGNsYXNzLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9zZXRQb3NpdGlvbigpIHtcbiAgICBpZih0aGlzLiRhbmNob3IuYXR0cignYXJpYS1leHBhbmRlZCcpID09PSAnZmFsc2UnKXsgcmV0dXJuIGZhbHNlOyB9XG4gICAgdmFyIHBvc2l0aW9uID0gdGhpcy5nZXRQb3NpdGlvbkNsYXNzKCksXG4gICAgICAgICRlbGVEaW1zID0gRm91bmRhdGlvbi5Cb3guR2V0RGltZW5zaW9ucyh0aGlzLiRlbGVtZW50KSxcbiAgICAgICAgJGFuY2hvckRpbXMgPSBGb3VuZGF0aW9uLkJveC5HZXREaW1lbnNpb25zKHRoaXMuJGFuY2hvciksXG4gICAgICAgIF90aGlzID0gdGhpcyxcbiAgICAgICAgZGlyZWN0aW9uID0gKHBvc2l0aW9uID09PSAnbGVmdCcgPyAnbGVmdCcgOiAoKHBvc2l0aW9uID09PSAncmlnaHQnKSA/ICdsZWZ0JyA6ICd0b3AnKSksXG4gICAgICAgIHBhcmFtID0gKGRpcmVjdGlvbiA9PT0gJ3RvcCcpID8gJ2hlaWdodCcgOiAnd2lkdGgnLFxuICAgICAgICBvZmZzZXQgPSAocGFyYW0gPT09ICdoZWlnaHQnKSA/IHRoaXMub3B0aW9ucy52T2Zmc2V0IDogdGhpcy5vcHRpb25zLmhPZmZzZXQ7XG5cbiAgICBpZigoJGVsZURpbXMud2lkdGggPj0gJGVsZURpbXMud2luZG93RGltcy53aWR0aCkgfHwgKCF0aGlzLmNvdW50ZXIgJiYgIUZvdW5kYXRpb24uQm94LkltTm90VG91Y2hpbmdZb3UodGhpcy4kZWxlbWVudCwgdGhpcy4kcGFyZW50KSkpe1xuICAgICAgdmFyIG5ld1dpZHRoID0gJGVsZURpbXMud2luZG93RGltcy53aWR0aCxcbiAgICAgICAgICBwYXJlbnRIT2Zmc2V0ID0gMDtcbiAgICAgIGlmKHRoaXMuJHBhcmVudCl7XG4gICAgICAgIHZhciAkcGFyZW50RGltcyA9IEZvdW5kYXRpb24uQm94LkdldERpbWVuc2lvbnModGhpcy4kcGFyZW50KSxcbiAgICAgICAgICAgIHBhcmVudEhPZmZzZXQgPSAkcGFyZW50RGltcy5vZmZzZXQubGVmdDtcbiAgICAgICAgaWYgKCRwYXJlbnREaW1zLndpZHRoIDwgbmV3V2lkdGgpe1xuICAgICAgICAgIG5ld1dpZHRoID0gJHBhcmVudERpbXMud2lkdGg7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgdGhpcy4kZWxlbWVudC5vZmZzZXQoRm91bmRhdGlvbi5Cb3guR2V0T2Zmc2V0cyh0aGlzLiRlbGVtZW50LCB0aGlzLiRhbmNob3IsICdjZW50ZXIgYm90dG9tJywgdGhpcy5vcHRpb25zLnZPZmZzZXQsIHRoaXMub3B0aW9ucy5oT2Zmc2V0ICsgcGFyZW50SE9mZnNldCwgdHJ1ZSkpLmNzcyh7XG4gICAgICAgICd3aWR0aCc6IG5ld1dpZHRoIC0gKHRoaXMub3B0aW9ucy5oT2Zmc2V0ICogMiksXG4gICAgICAgICdoZWlnaHQnOiAnYXV0bydcbiAgICAgIH0pO1xuICAgICAgdGhpcy5jbGFzc0NoYW5nZWQgPSB0cnVlO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIHRoaXMuJGVsZW1lbnQub2Zmc2V0KEZvdW5kYXRpb24uQm94LkdldE9mZnNldHModGhpcy4kZWxlbWVudCwgdGhpcy4kYW5jaG9yLCBwb3NpdGlvbiwgdGhpcy5vcHRpb25zLnZPZmZzZXQsIHRoaXMub3B0aW9ucy5oT2Zmc2V0KSk7XG5cbiAgICB3aGlsZSghRm91bmRhdGlvbi5Cb3guSW1Ob3RUb3VjaGluZ1lvdSh0aGlzLiRlbGVtZW50LCB0aGlzLiRwYXJlbnQsIHRydWUpICYmIHRoaXMuY291bnRlcil7XG4gICAgICB0aGlzLl9yZXBvc2l0aW9uKHBvc2l0aW9uKTtcbiAgICAgIHRoaXMuX3NldFBvc2l0aW9uKCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgZXZlbnQgbGlzdGVuZXJzIHRvIHRoZSBlbGVtZW50IHV0aWxpemluZyB0aGUgdHJpZ2dlcnMgdXRpbGl0eSBsaWJyYXJ5LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9ldmVudHMoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcbiAgICB0aGlzLiRlbGVtZW50Lm9uKHtcbiAgICAgICdvcGVuLnpmLnRyaWdnZXInOiB0aGlzLm9wZW4uYmluZCh0aGlzKSxcbiAgICAgICdjbG9zZS56Zi50cmlnZ2VyJzogdGhpcy5jbG9zZS5iaW5kKHRoaXMpLFxuICAgICAgJ3RvZ2dsZS56Zi50cmlnZ2VyJzogdGhpcy50b2dnbGUuYmluZCh0aGlzKSxcbiAgICAgICdyZXNpemVtZS56Zi50cmlnZ2VyJzogdGhpcy5fc2V0UG9zaXRpb24uYmluZCh0aGlzKVxuICAgIH0pO1xuXG4gICAgaWYodGhpcy5vcHRpb25zLmhvdmVyKXtcbiAgICAgIHRoaXMuJGFuY2hvci5vZmYoJ21vdXNlZW50ZXIuemYuZHJvcGRvd24gbW91c2VsZWF2ZS56Zi5kcm9wZG93bicpXG4gICAgICAub24oJ21vdXNlZW50ZXIuemYuZHJvcGRvd24nLCBmdW5jdGlvbigpe1xuICAgICAgICB2YXIgYm9keURhdGEgPSAkKCdib2R5JykuZGF0YSgpO1xuICAgICAgICBpZih0eXBlb2YoYm9keURhdGEud2hhdGlucHV0KSA9PT0gJ3VuZGVmaW5lZCcgfHwgYm9keURhdGEud2hhdGlucHV0ID09PSAnbW91c2UnKSB7XG4gICAgICAgICAgY2xlYXJUaW1lb3V0KF90aGlzLnRpbWVvdXQpO1xuICAgICAgICAgIF90aGlzLnRpbWVvdXQgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICBfdGhpcy5vcGVuKCk7XG4gICAgICAgICAgICBfdGhpcy4kYW5jaG9yLmRhdGEoJ2hvdmVyJywgdHJ1ZSk7XG4gICAgICAgICAgfSwgX3RoaXMub3B0aW9ucy5ob3ZlckRlbGF5KTtcbiAgICAgICAgfVxuICAgICAgfSkub24oJ21vdXNlbGVhdmUuemYuZHJvcGRvd24nLCBmdW5jdGlvbigpe1xuICAgICAgICBjbGVhclRpbWVvdXQoX3RoaXMudGltZW91dCk7XG4gICAgICAgIF90aGlzLnRpbWVvdXQgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7XG4gICAgICAgICAgX3RoaXMuY2xvc2UoKTtcbiAgICAgICAgICBfdGhpcy4kYW5jaG9yLmRhdGEoJ2hvdmVyJywgZmFsc2UpO1xuICAgICAgICB9LCBfdGhpcy5vcHRpb25zLmhvdmVyRGVsYXkpO1xuICAgICAgfSk7XG4gICAgICBpZih0aGlzLm9wdGlvbnMuaG92ZXJQYW5lKXtcbiAgICAgICAgdGhpcy4kZWxlbWVudC5vZmYoJ21vdXNlZW50ZXIuemYuZHJvcGRvd24gbW91c2VsZWF2ZS56Zi5kcm9wZG93bicpXG4gICAgICAgICAgICAub24oJ21vdXNlZW50ZXIuemYuZHJvcGRvd24nLCBmdW5jdGlvbigpe1xuICAgICAgICAgICAgICBjbGVhclRpbWVvdXQoX3RoaXMudGltZW91dCk7XG4gICAgICAgICAgICB9KS5vbignbW91c2VsZWF2ZS56Zi5kcm9wZG93bicsIGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgIGNsZWFyVGltZW91dChfdGhpcy50aW1lb3V0KTtcbiAgICAgICAgICAgICAgX3RoaXMudGltZW91dCA9IHNldFRpbWVvdXQoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICBfdGhpcy5jbG9zZSgpO1xuICAgICAgICAgICAgICAgIF90aGlzLiRhbmNob3IuZGF0YSgnaG92ZXInLCBmYWxzZSk7XG4gICAgICAgICAgICAgIH0sIF90aGlzLm9wdGlvbnMuaG92ZXJEZWxheSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy4kYW5jaG9yLmFkZCh0aGlzLiRlbGVtZW50KS5vbigna2V5ZG93bi56Zi5kcm9wZG93bicsIGZ1bmN0aW9uKGUpIHtcblxuICAgICAgdmFyICR0YXJnZXQgPSAkKHRoaXMpLFxuICAgICAgICB2aXNpYmxlRm9jdXNhYmxlRWxlbWVudHMgPSBGb3VuZGF0aW9uLktleWJvYXJkLmZpbmRGb2N1c2FibGUoX3RoaXMuJGVsZW1lbnQpO1xuXG4gICAgICBGb3VuZGF0aW9uLktleWJvYXJkLmhhbmRsZUtleShlLCAnRHJvcGRvd24nLCB7XG4gICAgICAgIG9wZW46IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIGlmICgkdGFyZ2V0LmlzKF90aGlzLiRhbmNob3IpKSB7XG4gICAgICAgICAgICBfdGhpcy5vcGVuKCk7XG4gICAgICAgICAgICBfdGhpcy4kZWxlbWVudC5hdHRyKCd0YWJpbmRleCcsIC0xKS5mb2N1cygpO1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgY2xvc2U6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIF90aGlzLmNsb3NlKCk7XG4gICAgICAgICAgX3RoaXMuJGFuY2hvci5mb2N1cygpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGFuIGV2ZW50IGhhbmRsZXIgdG8gdGhlIGJvZHkgdG8gY2xvc2UgYW55IGRyb3Bkb3ducyBvbiBhIGNsaWNrLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9hZGRCb2R5SGFuZGxlcigpIHtcbiAgICAgdmFyICRib2R5ID0gJChkb2N1bWVudC5ib2R5KS5ub3QodGhpcy4kZWxlbWVudCksXG4gICAgICAgICBfdGhpcyA9IHRoaXM7XG4gICAgICRib2R5Lm9mZignY2xpY2suemYuZHJvcGRvd24nKVxuICAgICAgICAgIC5vbignY2xpY2suemYuZHJvcGRvd24nLCBmdW5jdGlvbihlKXtcbiAgICAgICAgICAgIGlmKF90aGlzLiRhbmNob3IuaXMoZS50YXJnZXQpIHx8IF90aGlzLiRhbmNob3IuZmluZChlLnRhcmdldCkubGVuZ3RoKSB7XG4gICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmKF90aGlzLiRlbGVtZW50LmZpbmQoZS50YXJnZXQpLmxlbmd0aCkge1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfdGhpcy5jbG9zZSgpO1xuICAgICAgICAgICAgJGJvZHkub2ZmKCdjbGljay56Zi5kcm9wZG93bicpO1xuICAgICAgICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIE9wZW5zIHRoZSBkcm9wZG93biBwYW5lLCBhbmQgZmlyZXMgYSBidWJibGluZyBldmVudCB0byBjbG9zZSBvdGhlciBkcm9wZG93bnMuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAZmlyZXMgRHJvcGRvd24jY2xvc2VtZVxuICAgKiBAZmlyZXMgRHJvcGRvd24jc2hvd1xuICAgKi9cbiAgb3BlbigpIHtcbiAgICAvLyB2YXIgX3RoaXMgPSB0aGlzO1xuICAgIC8qKlxuICAgICAqIEZpcmVzIHRvIGNsb3NlIG90aGVyIG9wZW4gZHJvcGRvd25zXG4gICAgICogQGV2ZW50IERyb3Bkb3duI2Nsb3NlbWVcbiAgICAgKi9cbiAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ2Nsb3NlbWUuemYuZHJvcGRvd24nLCB0aGlzLiRlbGVtZW50LmF0dHIoJ2lkJykpO1xuICAgIHRoaXMuJGFuY2hvci5hZGRDbGFzcygnaG92ZXInKVxuICAgICAgICAuYXR0cih7J2FyaWEtZXhwYW5kZWQnOiB0cnVlfSk7XG4gICAgLy8gdGhpcy4kZWxlbWVudC8qLnNob3coKSovO1xuICAgIHRoaXMuX3NldFBvc2l0aW9uKCk7XG4gICAgdGhpcy4kZWxlbWVudC5hZGRDbGFzcygnaXMtb3BlbicpXG4gICAgICAgIC5hdHRyKHsnYXJpYS1oaWRkZW4nOiBmYWxzZX0pO1xuXG4gICAgaWYodGhpcy5vcHRpb25zLmF1dG9Gb2N1cyl7XG4gICAgICB2YXIgJGZvY3VzYWJsZSA9IEZvdW5kYXRpb24uS2V5Ym9hcmQuZmluZEZvY3VzYWJsZSh0aGlzLiRlbGVtZW50KTtcbiAgICAgIGlmKCRmb2N1c2FibGUubGVuZ3RoKXtcbiAgICAgICAgJGZvY3VzYWJsZS5lcSgwKS5mb2N1cygpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmKHRoaXMub3B0aW9ucy5jbG9zZU9uQ2xpY2speyB0aGlzLl9hZGRCb2R5SGFuZGxlcigpOyB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLnRyYXBGb2N1cykge1xuICAgICAgRm91bmRhdGlvbi5LZXlib2FyZC50cmFwRm9jdXModGhpcy4kZWxlbWVudCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRmlyZXMgb25jZSB0aGUgZHJvcGRvd24gaXMgdmlzaWJsZS5cbiAgICAgKiBAZXZlbnQgRHJvcGRvd24jc2hvd1xuICAgICAqL1xuICAgIHRoaXMuJGVsZW1lbnQudHJpZ2dlcignc2hvdy56Zi5kcm9wZG93bicsIFt0aGlzLiRlbGVtZW50XSk7XG4gIH1cblxuICAvKipcbiAgICogQ2xvc2VzIHRoZSBvcGVuIGRyb3Bkb3duIHBhbmUuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAZmlyZXMgRHJvcGRvd24jaGlkZVxuICAgKi9cbiAgY2xvc2UoKSB7XG4gICAgaWYoIXRoaXMuJGVsZW1lbnQuaGFzQ2xhc3MoJ2lzLW9wZW4nKSl7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHRoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3MoJ2lzLW9wZW4nKVxuICAgICAgICAuYXR0cih7J2FyaWEtaGlkZGVuJzogdHJ1ZX0pO1xuXG4gICAgdGhpcy4kYW5jaG9yLnJlbW92ZUNsYXNzKCdob3ZlcicpXG4gICAgICAgIC5hdHRyKCdhcmlhLWV4cGFuZGVkJywgZmFsc2UpO1xuXG4gICAgaWYodGhpcy5jbGFzc0NoYW5nZWQpe1xuICAgICAgdmFyIGN1clBvc2l0aW9uQ2xhc3MgPSB0aGlzLmdldFBvc2l0aW9uQ2xhc3MoKTtcbiAgICAgIGlmKGN1clBvc2l0aW9uQ2xhc3Mpe1xuICAgICAgICB0aGlzLiRlbGVtZW50LnJlbW92ZUNsYXNzKGN1clBvc2l0aW9uQ2xhc3MpO1xuICAgICAgfVxuICAgICAgdGhpcy4kZWxlbWVudC5hZGRDbGFzcyh0aGlzLm9wdGlvbnMucG9zaXRpb25DbGFzcylcbiAgICAgICAgICAvKi5oaWRlKCkqLy5jc3Moe2hlaWdodDogJycsIHdpZHRoOiAnJ30pO1xuICAgICAgdGhpcy5jbGFzc0NoYW5nZWQgPSBmYWxzZTtcbiAgICAgIHRoaXMuY291bnRlciA9IDQ7XG4gICAgICB0aGlzLnVzZWRQb3NpdGlvbnMubGVuZ3RoID0gMDtcbiAgICB9XG4gICAgdGhpcy4kZWxlbWVudC50cmlnZ2VyKCdoaWRlLnpmLmRyb3Bkb3duJywgW3RoaXMuJGVsZW1lbnRdKTtcblxuICAgIGlmICh0aGlzLm9wdGlvbnMudHJhcEZvY3VzKSB7XG4gICAgICBGb3VuZGF0aW9uLktleWJvYXJkLnJlbGVhc2VGb2N1cyh0aGlzLiRlbGVtZW50KTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVG9nZ2xlcyB0aGUgZHJvcGRvd24gcGFuZSdzIHZpc2liaWxpdHkuXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgdG9nZ2xlKCkge1xuICAgIGlmKHRoaXMuJGVsZW1lbnQuaGFzQ2xhc3MoJ2lzLW9wZW4nKSl7XG4gICAgICBpZih0aGlzLiRhbmNob3IuZGF0YSgnaG92ZXInKSkgcmV0dXJuO1xuICAgICAgdGhpcy5jbG9zZSgpO1xuICAgIH1lbHNle1xuICAgICAgdGhpcy5vcGVuKCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIERlc3Ryb3lzIHRoZSBkcm9wZG93bi5cbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICBkZXN0cm95KCkge1xuICAgIHRoaXMuJGVsZW1lbnQub2ZmKCcuemYudHJpZ2dlcicpLmhpZGUoKTtcbiAgICB0aGlzLiRhbmNob3Iub2ZmKCcuemYuZHJvcGRvd24nKTtcblxuICAgIEZvdW5kYXRpb24udW5yZWdpc3RlclBsdWdpbih0aGlzKTtcbiAgfVxufVxuXG5Ecm9wZG93bi5kZWZhdWx0cyA9IHtcbiAgLyoqXG4gICAqIENsYXNzIHRoYXQgZGVzaWduYXRlcyBib3VuZGluZyBjb250YWluZXIgb2YgRHJvcGRvd24gKERlZmF1bHQ6IHdpbmRvdylcbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnZHJvcGRvd24tcGFyZW50J1xuICAgKi9cbiAgcGFyZW50Q2xhc3M6IG51bGwsXG4gIC8qKlxuICAgKiBBbW91bnQgb2YgdGltZSB0byBkZWxheSBvcGVuaW5nIGEgc3VibWVudSBvbiBob3ZlciBldmVudC5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAyNTBcbiAgICovXG4gIGhvdmVyRGVsYXk6IDI1MCxcbiAgLyoqXG4gICAqIEFsbG93IHN1Ym1lbnVzIHRvIG9wZW4gb24gaG92ZXIgZXZlbnRzXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgZmFsc2VcbiAgICovXG4gIGhvdmVyOiBmYWxzZSxcbiAgLyoqXG4gICAqIERvbid0IGNsb3NlIGRyb3Bkb3duIHdoZW4gaG92ZXJpbmcgb3ZlciBkcm9wZG93biBwYW5lXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgdHJ1ZVxuICAgKi9cbiAgaG92ZXJQYW5lOiBmYWxzZSxcbiAgLyoqXG4gICAqIE51bWJlciBvZiBwaXhlbHMgYmV0d2VlbiB0aGUgZHJvcGRvd24gcGFuZSBhbmQgdGhlIHRyaWdnZXJpbmcgZWxlbWVudCBvbiBvcGVuLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIDFcbiAgICovXG4gIHZPZmZzZXQ6IDEsXG4gIC8qKlxuICAgKiBOdW1iZXIgb2YgcGl4ZWxzIGJldHdlZW4gdGhlIGRyb3Bkb3duIHBhbmUgYW5kIHRoZSB0cmlnZ2VyaW5nIGVsZW1lbnQgb24gb3Blbi5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAxXG4gICAqL1xuICBoT2Zmc2V0OiAxLFxuICAvKipcbiAgICogQ2xhc3MgYXBwbGllZCB0byBhZGp1c3Qgb3BlbiBwb3NpdGlvbi4gSlMgd2lsbCB0ZXN0IGFuZCBmaWxsIHRoaXMgaW4uXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgJ3RvcCdcbiAgICovXG4gIHBvc2l0aW9uQ2xhc3M6ICcnLFxuICAvKipcbiAgICogQWxsb3cgdGhlIHBsdWdpbiB0byB0cmFwIGZvY3VzIHRvIHRoZSBkcm9wZG93biBwYW5lIGlmIG9wZW5lZCB3aXRoIGtleWJvYXJkIGNvbW1hbmRzLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICB0cmFwRm9jdXM6IGZhbHNlLFxuICAvKipcbiAgICogQWxsb3cgdGhlIHBsdWdpbiB0byBzZXQgZm9jdXMgdG8gdGhlIGZpcnN0IGZvY3VzYWJsZSBlbGVtZW50IHdpdGhpbiB0aGUgcGFuZSwgcmVnYXJkbGVzcyBvZiBtZXRob2Qgb2Ygb3BlbmluZy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSB0cnVlXG4gICAqL1xuICBhdXRvRm9jdXM6IGZhbHNlLFxuICAvKipcbiAgICogQWxsb3dzIGEgY2xpY2sgb24gdGhlIGJvZHkgdG8gY2xvc2UgdGhlIGRyb3Bkb3duLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICBjbG9zZU9uQ2xpY2s6IGZhbHNlXG59XG5cbi8vIFdpbmRvdyBleHBvcnRzXG5Gb3VuZGF0aW9uLnBsdWdpbihEcm9wZG93biwgJ0Ryb3Bkb3duJyk7XG5cbn0oalF1ZXJ5KTtcbiIsIid1c2Ugc3RyaWN0JztcblxuIWZ1bmN0aW9uKCQpIHtcblxuLyoqXG4gKiBEcm9wZG93bk1lbnUgbW9kdWxlLlxuICogQG1vZHVsZSBmb3VuZGF0aW9uLmRyb3Bkb3duLW1lbnVcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwua2V5Ym9hcmRcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwuYm94XG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLm5lc3RcbiAqL1xuXG5jbGFzcyBEcm9wZG93bk1lbnUge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBpbnN0YW5jZSBvZiBEcm9wZG93bk1lbnUuXG4gICAqIEBjbGFzc1xuICAgKiBAZmlyZXMgRHJvcGRvd25NZW51I2luaXRcbiAgICogQHBhcmFtIHtqUXVlcnl9IGVsZW1lbnQgLSBqUXVlcnkgb2JqZWN0IHRvIG1ha2UgaW50byBhIGRyb3Bkb3duIG1lbnUuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zIC0gT3ZlcnJpZGVzIHRvIHRoZSBkZWZhdWx0IHBsdWdpbiBzZXR0aW5ncy5cbiAgICovXG4gIGNvbnN0cnVjdG9yKGVsZW1lbnQsIG9wdGlvbnMpIHtcbiAgICB0aGlzLiRlbGVtZW50ID0gZWxlbWVudDtcbiAgICB0aGlzLm9wdGlvbnMgPSAkLmV4dGVuZCh7fSwgRHJvcGRvd25NZW51LmRlZmF1bHRzLCB0aGlzLiRlbGVtZW50LmRhdGEoKSwgb3B0aW9ucyk7XG5cbiAgICBGb3VuZGF0aW9uLk5lc3QuRmVhdGhlcih0aGlzLiRlbGVtZW50LCAnZHJvcGRvd24nKTtcbiAgICB0aGlzLl9pbml0KCk7XG5cbiAgICBGb3VuZGF0aW9uLnJlZ2lzdGVyUGx1Z2luKHRoaXMsICdEcm9wZG93bk1lbnUnKTtcbiAgICBGb3VuZGF0aW9uLktleWJvYXJkLnJlZ2lzdGVyKCdEcm9wZG93bk1lbnUnLCB7XG4gICAgICAnRU5URVInOiAnb3BlbicsXG4gICAgICAnU1BBQ0UnOiAnb3BlbicsXG4gICAgICAnQVJST1dfUklHSFQnOiAnbmV4dCcsXG4gICAgICAnQVJST1dfVVAnOiAndXAnLFxuICAgICAgJ0FSUk9XX0RPV04nOiAnZG93bicsXG4gICAgICAnQVJST1dfTEVGVCc6ICdwcmV2aW91cycsXG4gICAgICAnRVNDQVBFJzogJ2Nsb3NlJ1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEluaXRpYWxpemVzIHRoZSBwbHVnaW4sIGFuZCBjYWxscyBfcHJlcGFyZU1lbnVcbiAgICogQHByaXZhdGVcbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICBfaW5pdCgpIHtcbiAgICB2YXIgc3VicyA9IHRoaXMuJGVsZW1lbnQuZmluZCgnbGkuaXMtZHJvcGRvd24tc3VibWVudS1wYXJlbnQnKTtcbiAgICB0aGlzLiRlbGVtZW50LmNoaWxkcmVuKCcuaXMtZHJvcGRvd24tc3VibWVudS1wYXJlbnQnKS5jaGlsZHJlbignLmlzLWRyb3Bkb3duLXN1Ym1lbnUnKS5hZGRDbGFzcygnZmlyc3Qtc3ViJyk7XG5cbiAgICB0aGlzLiRtZW51SXRlbXMgPSB0aGlzLiRlbGVtZW50LmZpbmQoJ1tyb2xlPVwibWVudWl0ZW1cIl0nKTtcbiAgICB0aGlzLiR0YWJzID0gdGhpcy4kZWxlbWVudC5jaGlsZHJlbignW3JvbGU9XCJtZW51aXRlbVwiXScpO1xuICAgIHRoaXMuJHRhYnMuZmluZCgndWwuaXMtZHJvcGRvd24tc3VibWVudScpLmFkZENsYXNzKHRoaXMub3B0aW9ucy52ZXJ0aWNhbENsYXNzKTtcblxuICAgIGlmICh0aGlzLiRlbGVtZW50Lmhhc0NsYXNzKHRoaXMub3B0aW9ucy5yaWdodENsYXNzKSB8fCB0aGlzLm9wdGlvbnMuYWxpZ25tZW50ID09PSAncmlnaHQnIHx8IEZvdW5kYXRpb24ucnRsKCkgfHwgdGhpcy4kZWxlbWVudC5wYXJlbnRzKCcudG9wLWJhci1yaWdodCcpLmlzKCcqJykpIHtcbiAgICAgIHRoaXMub3B0aW9ucy5hbGlnbm1lbnQgPSAncmlnaHQnO1xuICAgICAgc3Vicy5hZGRDbGFzcygnb3BlbnMtbGVmdCcpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdWJzLmFkZENsYXNzKCdvcGVucy1yaWdodCcpO1xuICAgIH1cbiAgICB0aGlzLmNoYW5nZWQgPSBmYWxzZTtcbiAgICB0aGlzLl9ldmVudHMoKTtcbiAgfTtcblxuICBfaXNWZXJ0aWNhbCgpIHtcbiAgICByZXR1cm4gdGhpcy4kdGFicy5jc3MoJ2Rpc3BsYXknKSA9PT0gJ2Jsb2NrJztcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGV2ZW50IGxpc3RlbmVycyB0byBlbGVtZW50cyB3aXRoaW4gdGhlIG1lbnVcbiAgICogQHByaXZhdGVcbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICBfZXZlbnRzKCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXMsXG4gICAgICAgIGhhc1RvdWNoID0gJ29udG91Y2hzdGFydCcgaW4gd2luZG93IHx8ICh0eXBlb2Ygd2luZG93Lm9udG91Y2hzdGFydCAhPT0gJ3VuZGVmaW5lZCcpLFxuICAgICAgICBwYXJDbGFzcyA9ICdpcy1kcm9wZG93bi1zdWJtZW51LXBhcmVudCc7XG5cbiAgICAvLyB1c2VkIGZvciBvbkNsaWNrIGFuZCBpbiB0aGUga2V5Ym9hcmQgaGFuZGxlcnNcbiAgICB2YXIgaGFuZGxlQ2xpY2tGbiA9IGZ1bmN0aW9uKGUpIHtcbiAgICAgIHZhciAkZWxlbSA9ICQoZS50YXJnZXQpLnBhcmVudHNVbnRpbCgndWwnLCBgLiR7cGFyQ2xhc3N9YCksXG4gICAgICAgICAgaGFzU3ViID0gJGVsZW0uaGFzQ2xhc3MocGFyQ2xhc3MpLFxuICAgICAgICAgIGhhc0NsaWNrZWQgPSAkZWxlbS5hdHRyKCdkYXRhLWlzLWNsaWNrJykgPT09ICd0cnVlJyxcbiAgICAgICAgICAkc3ViID0gJGVsZW0uY2hpbGRyZW4oJy5pcy1kcm9wZG93bi1zdWJtZW51Jyk7XG5cbiAgICAgIGlmIChoYXNTdWIpIHtcbiAgICAgICAgaWYgKGhhc0NsaWNrZWQpIHtcbiAgICAgICAgICBpZiAoIV90aGlzLm9wdGlvbnMuY2xvc2VPbkNsaWNrIHx8ICghX3RoaXMub3B0aW9ucy5jbGlja09wZW4gJiYgIWhhc1RvdWNoKSB8fCAoX3RoaXMub3B0aW9ucy5mb3JjZUZvbGxvdyAmJiBoYXNUb3VjaCkpIHsgcmV0dXJuOyB9XG4gICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgX3RoaXMuX2hpZGUoJGVsZW0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgZS5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICBfdGhpcy5fc2hvdygkc3ViKTtcbiAgICAgICAgICAkZWxlbS5hZGQoJGVsZW0ucGFyZW50c1VudGlsKF90aGlzLiRlbGVtZW50LCBgLiR7cGFyQ2xhc3N9YCkpLmF0dHIoJ2RhdGEtaXMtY2xpY2snLCB0cnVlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmNsaWNrT3BlbiB8fCBoYXNUb3VjaCkge1xuICAgICAgdGhpcy4kbWVudUl0ZW1zLm9uKCdjbGljay56Zi5kcm9wZG93bm1lbnUgdG91Y2hzdGFydC56Zi5kcm9wZG93bm1lbnUnLCBoYW5kbGVDbGlja0ZuKTtcbiAgICB9XG5cbiAgICAvLyBIYW5kbGUgTGVhZiBlbGVtZW50IENsaWNrc1xuICAgIGlmKF90aGlzLm9wdGlvbnMuY2xvc2VPbkNsaWNrSW5zaWRlKXtcbiAgICAgIHRoaXMuJG1lbnVJdGVtcy5vbignY2xpY2suemYuZHJvcGRvd25tZW51IHRvdWNoZW5kLnpmLmRyb3Bkb3dubWVudScsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdmFyICRlbGVtID0gJCh0aGlzKSxcbiAgICAgICAgICAgIGhhc1N1YiA9ICRlbGVtLmhhc0NsYXNzKHBhckNsYXNzKTtcbiAgICAgICAgaWYoIWhhc1N1Yil7XG4gICAgICAgICAgX3RoaXMuX2hpZGUoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgaWYgKCF0aGlzLm9wdGlvbnMuZGlzYWJsZUhvdmVyKSB7XG4gICAgICB0aGlzLiRtZW51SXRlbXMub24oJ21vdXNlZW50ZXIuemYuZHJvcGRvd25tZW51JywgZnVuY3Rpb24oZSkge1xuICAgICAgICB2YXIgJGVsZW0gPSAkKHRoaXMpLFxuICAgICAgICAgICAgaGFzU3ViID0gJGVsZW0uaGFzQ2xhc3MocGFyQ2xhc3MpO1xuXG4gICAgICAgIGlmIChoYXNTdWIpIHtcbiAgICAgICAgICBjbGVhclRpbWVvdXQoJGVsZW0uZGF0YSgnX2RlbGF5JykpO1xuICAgICAgICAgICRlbGVtLmRhdGEoJ19kZWxheScsIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBfdGhpcy5fc2hvdygkZWxlbS5jaGlsZHJlbignLmlzLWRyb3Bkb3duLXN1Ym1lbnUnKSk7XG4gICAgICAgICAgfSwgX3RoaXMub3B0aW9ucy5ob3ZlckRlbGF5KSk7XG4gICAgICAgIH1cbiAgICAgIH0pLm9uKCdtb3VzZWxlYXZlLnpmLmRyb3Bkb3dubWVudScsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgdmFyICRlbGVtID0gJCh0aGlzKSxcbiAgICAgICAgICAgIGhhc1N1YiA9ICRlbGVtLmhhc0NsYXNzKHBhckNsYXNzKTtcbiAgICAgICAgaWYgKGhhc1N1YiAmJiBfdGhpcy5vcHRpb25zLmF1dG9jbG9zZSkge1xuICAgICAgICAgIGlmICgkZWxlbS5hdHRyKCdkYXRhLWlzLWNsaWNrJykgPT09ICd0cnVlJyAmJiBfdGhpcy5vcHRpb25zLmNsaWNrT3BlbikgeyByZXR1cm4gZmFsc2U7IH1cblxuICAgICAgICAgIGNsZWFyVGltZW91dCgkZWxlbS5kYXRhKCdfZGVsYXknKSk7XG4gICAgICAgICAgJGVsZW0uZGF0YSgnX2RlbGF5Jywgc2V0VGltZW91dChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIF90aGlzLl9oaWRlKCRlbGVtKTtcbiAgICAgICAgICB9LCBfdGhpcy5vcHRpb25zLmNsb3NpbmdUaW1lKSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgICB0aGlzLiRtZW51SXRlbXMub24oJ2tleWRvd24uemYuZHJvcGRvd25tZW51JywgZnVuY3Rpb24oZSkge1xuICAgICAgdmFyICRlbGVtZW50ID0gJChlLnRhcmdldCkucGFyZW50c1VudGlsKCd1bCcsICdbcm9sZT1cIm1lbnVpdGVtXCJdJyksXG4gICAgICAgICAgaXNUYWIgPSBfdGhpcy4kdGFicy5pbmRleCgkZWxlbWVudCkgPiAtMSxcbiAgICAgICAgICAkZWxlbWVudHMgPSBpc1RhYiA/IF90aGlzLiR0YWJzIDogJGVsZW1lbnQuc2libGluZ3MoJ2xpJykuYWRkKCRlbGVtZW50KSxcbiAgICAgICAgICAkcHJldkVsZW1lbnQsXG4gICAgICAgICAgJG5leHRFbGVtZW50O1xuXG4gICAgICAkZWxlbWVudHMuZWFjaChmdW5jdGlvbihpKSB7XG4gICAgICAgIGlmICgkKHRoaXMpLmlzKCRlbGVtZW50KSkge1xuICAgICAgICAgICRwcmV2RWxlbWVudCA9ICRlbGVtZW50cy5lcShpLTEpO1xuICAgICAgICAgICRuZXh0RWxlbWVudCA9ICRlbGVtZW50cy5lcShpKzEpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIHZhciBuZXh0U2libGluZyA9IGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAoISRlbGVtZW50LmlzKCc6bGFzdC1jaGlsZCcpKSB7XG4gICAgICAgICAgJG5leHRFbGVtZW50LmNoaWxkcmVuKCdhOmZpcnN0JykuZm9jdXMoKTtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIH1cbiAgICAgIH0sIHByZXZTaWJsaW5nID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICRwcmV2RWxlbWVudC5jaGlsZHJlbignYTpmaXJzdCcpLmZvY3VzKCk7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH0sIG9wZW5TdWIgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyICRzdWIgPSAkZWxlbWVudC5jaGlsZHJlbigndWwuaXMtZHJvcGRvd24tc3VibWVudScpO1xuICAgICAgICBpZiAoJHN1Yi5sZW5ndGgpIHtcbiAgICAgICAgICBfdGhpcy5fc2hvdygkc3ViKTtcbiAgICAgICAgICAkZWxlbWVudC5maW5kKCdsaSA+IGE6Zmlyc3QnKS5mb2N1cygpO1xuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgfSBlbHNlIHsgcmV0dXJuOyB9XG4gICAgICB9LCBjbG9zZVN1YiA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAvL2lmICgkZWxlbWVudC5pcygnOmZpcnN0LWNoaWxkJykpIHtcbiAgICAgICAgdmFyIGNsb3NlID0gJGVsZW1lbnQucGFyZW50KCd1bCcpLnBhcmVudCgnbGknKTtcbiAgICAgICAgY2xvc2UuY2hpbGRyZW4oJ2E6Zmlyc3QnKS5mb2N1cygpO1xuICAgICAgICBfdGhpcy5faGlkZShjbG9zZSk7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgLy99XG4gICAgICB9O1xuICAgICAgdmFyIGZ1bmN0aW9ucyA9IHtcbiAgICAgICAgb3Blbjogb3BlblN1YixcbiAgICAgICAgY2xvc2U6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIF90aGlzLl9oaWRlKF90aGlzLiRlbGVtZW50KTtcbiAgICAgICAgICBfdGhpcy4kbWVudUl0ZW1zLmZpbmQoJ2E6Zmlyc3QnKS5mb2N1cygpOyAvLyBmb2N1cyB0byBmaXJzdCBlbGVtZW50XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB9LFxuICAgICAgICBoYW5kbGVkOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICBpZiAoaXNUYWIpIHtcbiAgICAgICAgaWYgKF90aGlzLl9pc1ZlcnRpY2FsKCkpIHsgLy8gdmVydGljYWwgbWVudVxuICAgICAgICAgIGlmIChGb3VuZGF0aW9uLnJ0bCgpKSB7IC8vIHJpZ2h0IGFsaWduZWRcbiAgICAgICAgICAgICQuZXh0ZW5kKGZ1bmN0aW9ucywge1xuICAgICAgICAgICAgICBkb3duOiBuZXh0U2libGluZyxcbiAgICAgICAgICAgICAgdXA6IHByZXZTaWJsaW5nLFxuICAgICAgICAgICAgICBuZXh0OiBjbG9zZVN1YixcbiAgICAgICAgICAgICAgcHJldmlvdXM6IG9wZW5TdWJcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0gZWxzZSB7IC8vIGxlZnQgYWxpZ25lZFxuICAgICAgICAgICAgJC5leHRlbmQoZnVuY3Rpb25zLCB7XG4gICAgICAgICAgICAgIGRvd246IG5leHRTaWJsaW5nLFxuICAgICAgICAgICAgICB1cDogcHJldlNpYmxpbmcsXG4gICAgICAgICAgICAgIG5leHQ6IG9wZW5TdWIsXG4gICAgICAgICAgICAgIHByZXZpb3VzOiBjbG9zZVN1YlxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgeyAvLyBob3Jpem9udGFsIG1lbnVcbiAgICAgICAgICBpZiAoRm91bmRhdGlvbi5ydGwoKSkgeyAvLyByaWdodCBhbGlnbmVkXG4gICAgICAgICAgICAkLmV4dGVuZChmdW5jdGlvbnMsIHtcbiAgICAgICAgICAgICAgbmV4dDogcHJldlNpYmxpbmcsXG4gICAgICAgICAgICAgIHByZXZpb3VzOiBuZXh0U2libGluZyxcbiAgICAgICAgICAgICAgZG93bjogb3BlblN1YixcbiAgICAgICAgICAgICAgdXA6IGNsb3NlU3ViXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9IGVsc2UgeyAvLyBsZWZ0IGFsaWduZWRcbiAgICAgICAgICAgICQuZXh0ZW5kKGZ1bmN0aW9ucywge1xuICAgICAgICAgICAgICBuZXh0OiBuZXh0U2libGluZyxcbiAgICAgICAgICAgICAgcHJldmlvdXM6IHByZXZTaWJsaW5nLFxuICAgICAgICAgICAgICBkb3duOiBvcGVuU3ViLFxuICAgICAgICAgICAgICB1cDogY2xvc2VTdWJcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHsgLy8gbm90IHRhYnMgLT4gb25lIHN1YlxuICAgICAgICBpZiAoRm91bmRhdGlvbi5ydGwoKSkgeyAvLyByaWdodCBhbGlnbmVkXG4gICAgICAgICAgJC5leHRlbmQoZnVuY3Rpb25zLCB7XG4gICAgICAgICAgICBuZXh0OiBjbG9zZVN1YixcbiAgICAgICAgICAgIHByZXZpb3VzOiBvcGVuU3ViLFxuICAgICAgICAgICAgZG93bjogbmV4dFNpYmxpbmcsXG4gICAgICAgICAgICB1cDogcHJldlNpYmxpbmdcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHsgLy8gbGVmdCBhbGlnbmVkXG4gICAgICAgICAgJC5leHRlbmQoZnVuY3Rpb25zLCB7XG4gICAgICAgICAgICBuZXh0OiBvcGVuU3ViLFxuICAgICAgICAgICAgcHJldmlvdXM6IGNsb3NlU3ViLFxuICAgICAgICAgICAgZG93bjogbmV4dFNpYmxpbmcsXG4gICAgICAgICAgICB1cDogcHJldlNpYmxpbmdcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgRm91bmRhdGlvbi5LZXlib2FyZC5oYW5kbGVLZXkoZSwgJ0Ryb3Bkb3duTWVudScsIGZ1bmN0aW9ucyk7XG5cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGFuIGV2ZW50IGhhbmRsZXIgdG8gdGhlIGJvZHkgdG8gY2xvc2UgYW55IGRyb3Bkb3ducyBvbiBhIGNsaWNrLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9hZGRCb2R5SGFuZGxlcigpIHtcbiAgICB2YXIgJGJvZHkgPSAkKGRvY3VtZW50LmJvZHkpLFxuICAgICAgICBfdGhpcyA9IHRoaXM7XG4gICAgJGJvZHkub2ZmKCdtb3VzZXVwLnpmLmRyb3Bkb3dubWVudSB0b3VjaGVuZC56Zi5kcm9wZG93bm1lbnUnKVxuICAgICAgICAgLm9uKCdtb3VzZXVwLnpmLmRyb3Bkb3dubWVudSB0b3VjaGVuZC56Zi5kcm9wZG93bm1lbnUnLCBmdW5jdGlvbihlKSB7XG4gICAgICAgICAgIHZhciAkbGluayA9IF90aGlzLiRlbGVtZW50LmZpbmQoZS50YXJnZXQpO1xuICAgICAgICAgICBpZiAoJGxpbmsubGVuZ3RoKSB7IHJldHVybjsgfVxuXG4gICAgICAgICAgIF90aGlzLl9oaWRlKCk7XG4gICAgICAgICAgICRib2R5Lm9mZignbW91c2V1cC56Zi5kcm9wZG93bm1lbnUgdG91Y2hlbmQuemYuZHJvcGRvd25tZW51Jyk7XG4gICAgICAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBPcGVucyBhIGRyb3Bkb3duIHBhbmUsIGFuZCBjaGVja3MgZm9yIGNvbGxpc2lvbnMgZmlyc3QuXG4gICAqIEBwYXJhbSB7alF1ZXJ5fSAkc3ViIC0gdWwgZWxlbWVudCB0aGF0IGlzIGEgc3VibWVudSB0byBzaG93XG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKiBAZmlyZXMgRHJvcGRvd25NZW51I3Nob3dcbiAgICovXG4gIF9zaG93KCRzdWIpIHtcbiAgICB2YXIgaWR4ID0gdGhpcy4kdGFicy5pbmRleCh0aGlzLiR0YWJzLmZpbHRlcihmdW5jdGlvbihpLCBlbCkge1xuICAgICAgcmV0dXJuICQoZWwpLmZpbmQoJHN1YikubGVuZ3RoID4gMDtcbiAgICB9KSk7XG4gICAgdmFyICRzaWJzID0gJHN1Yi5wYXJlbnQoJ2xpLmlzLWRyb3Bkb3duLXN1Ym1lbnUtcGFyZW50Jykuc2libGluZ3MoJ2xpLmlzLWRyb3Bkb3duLXN1Ym1lbnUtcGFyZW50Jyk7XG4gICAgdGhpcy5faGlkZSgkc2licywgaWR4KTtcbiAgICAkc3ViLmNzcygndmlzaWJpbGl0eScsICdoaWRkZW4nKS5hZGRDbGFzcygnanMtZHJvcGRvd24tYWN0aXZlJylcbiAgICAgICAgLnBhcmVudCgnbGkuaXMtZHJvcGRvd24tc3VibWVudS1wYXJlbnQnKS5hZGRDbGFzcygnaXMtYWN0aXZlJyk7XG4gICAgdmFyIGNsZWFyID0gRm91bmRhdGlvbi5Cb3guSW1Ob3RUb3VjaGluZ1lvdSgkc3ViLCBudWxsLCB0cnVlKTtcbiAgICBpZiAoIWNsZWFyKSB7XG4gICAgICB2YXIgb2xkQ2xhc3MgPSB0aGlzLm9wdGlvbnMuYWxpZ25tZW50ID09PSAnbGVmdCcgPyAnLXJpZ2h0JyA6ICctbGVmdCcsXG4gICAgICAgICAgJHBhcmVudExpID0gJHN1Yi5wYXJlbnQoJy5pcy1kcm9wZG93bi1zdWJtZW51LXBhcmVudCcpO1xuICAgICAgJHBhcmVudExpLnJlbW92ZUNsYXNzKGBvcGVucyR7b2xkQ2xhc3N9YCkuYWRkQ2xhc3MoYG9wZW5zLSR7dGhpcy5vcHRpb25zLmFsaWdubWVudH1gKTtcbiAgICAgIGNsZWFyID0gRm91bmRhdGlvbi5Cb3guSW1Ob3RUb3VjaGluZ1lvdSgkc3ViLCBudWxsLCB0cnVlKTtcbiAgICAgIGlmICghY2xlYXIpIHtcbiAgICAgICAgJHBhcmVudExpLnJlbW92ZUNsYXNzKGBvcGVucy0ke3RoaXMub3B0aW9ucy5hbGlnbm1lbnR9YCkuYWRkQ2xhc3MoJ29wZW5zLWlubmVyJyk7XG4gICAgICB9XG4gICAgICB0aGlzLmNoYW5nZWQgPSB0cnVlO1xuICAgIH1cbiAgICAkc3ViLmNzcygndmlzaWJpbGl0eScsICcnKTtcbiAgICBpZiAodGhpcy5vcHRpb25zLmNsb3NlT25DbGljaykgeyB0aGlzLl9hZGRCb2R5SGFuZGxlcigpOyB9XG4gICAgLyoqXG4gICAgICogRmlyZXMgd2hlbiB0aGUgbmV3IGRyb3Bkb3duIHBhbmUgaXMgdmlzaWJsZS5cbiAgICAgKiBAZXZlbnQgRHJvcGRvd25NZW51I3Nob3dcbiAgICAgKi9cbiAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ3Nob3cuemYuZHJvcGRvd25tZW51JywgWyRzdWJdKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBIaWRlcyBhIHNpbmdsZSwgY3VycmVudGx5IG9wZW4gZHJvcGRvd24gcGFuZSwgaWYgcGFzc2VkIGEgcGFyYW1ldGVyLCBvdGhlcndpc2UsIGhpZGVzIGV2ZXJ5dGhpbmcuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcGFyYW0ge2pRdWVyeX0gJGVsZW0gLSBlbGVtZW50IHdpdGggYSBzdWJtZW51IHRvIGhpZGVcbiAgICogQHBhcmFtIHtOdW1iZXJ9IGlkeCAtIGluZGV4IG9mIHRoZSAkdGFicyBjb2xsZWN0aW9uIHRvIGhpZGVcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9oaWRlKCRlbGVtLCBpZHgpIHtcbiAgICB2YXIgJHRvQ2xvc2U7XG4gICAgaWYgKCRlbGVtICYmICRlbGVtLmxlbmd0aCkge1xuICAgICAgJHRvQ2xvc2UgPSAkZWxlbTtcbiAgICB9IGVsc2UgaWYgKGlkeCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAkdG9DbG9zZSA9IHRoaXMuJHRhYnMubm90KGZ1bmN0aW9uKGksIGVsKSB7XG4gICAgICAgIHJldHVybiBpID09PSBpZHg7XG4gICAgICB9KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAkdG9DbG9zZSA9IHRoaXMuJGVsZW1lbnQ7XG4gICAgfVxuICAgIHZhciBzb21ldGhpbmdUb0Nsb3NlID0gJHRvQ2xvc2UuaGFzQ2xhc3MoJ2lzLWFjdGl2ZScpIHx8ICR0b0Nsb3NlLmZpbmQoJy5pcy1hY3RpdmUnKS5sZW5ndGggPiAwO1xuXG4gICAgaWYgKHNvbWV0aGluZ1RvQ2xvc2UpIHtcbiAgICAgICR0b0Nsb3NlLmZpbmQoJ2xpLmlzLWFjdGl2ZScpLmFkZCgkdG9DbG9zZSkuYXR0cih7XG4gICAgICAgICdkYXRhLWlzLWNsaWNrJzogZmFsc2VcbiAgICAgIH0pLnJlbW92ZUNsYXNzKCdpcy1hY3RpdmUnKTtcblxuICAgICAgJHRvQ2xvc2UuZmluZCgndWwuanMtZHJvcGRvd24tYWN0aXZlJykucmVtb3ZlQ2xhc3MoJ2pzLWRyb3Bkb3duLWFjdGl2ZScpO1xuXG4gICAgICBpZiAodGhpcy5jaGFuZ2VkIHx8ICR0b0Nsb3NlLmZpbmQoJ29wZW5zLWlubmVyJykubGVuZ3RoKSB7XG4gICAgICAgIHZhciBvbGRDbGFzcyA9IHRoaXMub3B0aW9ucy5hbGlnbm1lbnQgPT09ICdsZWZ0JyA/ICdyaWdodCcgOiAnbGVmdCc7XG4gICAgICAgICR0b0Nsb3NlLmZpbmQoJ2xpLmlzLWRyb3Bkb3duLXN1Ym1lbnUtcGFyZW50JykuYWRkKCR0b0Nsb3NlKVxuICAgICAgICAgICAgICAgIC5yZW1vdmVDbGFzcyhgb3BlbnMtaW5uZXIgb3BlbnMtJHt0aGlzLm9wdGlvbnMuYWxpZ25tZW50fWApXG4gICAgICAgICAgICAgICAgLmFkZENsYXNzKGBvcGVucy0ke29sZENsYXNzfWApO1xuICAgICAgICB0aGlzLmNoYW5nZWQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogRmlyZXMgd2hlbiB0aGUgb3BlbiBtZW51cyBhcmUgY2xvc2VkLlxuICAgICAgICogQGV2ZW50IERyb3Bkb3duTWVudSNoaWRlXG4gICAgICAgKi9cbiAgICAgIHRoaXMuJGVsZW1lbnQudHJpZ2dlcignaGlkZS56Zi5kcm9wZG93bm1lbnUnLCBbJHRvQ2xvc2VdKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRGVzdHJveXMgdGhlIHBsdWdpbi5cbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICBkZXN0cm95KCkge1xuICAgIHRoaXMuJG1lbnVJdGVtcy5vZmYoJy56Zi5kcm9wZG93bm1lbnUnKS5yZW1vdmVBdHRyKCdkYXRhLWlzLWNsaWNrJylcbiAgICAgICAgLnJlbW92ZUNsYXNzKCdpcy1yaWdodC1hcnJvdyBpcy1sZWZ0LWFycm93IGlzLWRvd24tYXJyb3cgb3BlbnMtcmlnaHQgb3BlbnMtbGVmdCBvcGVucy1pbm5lcicpO1xuICAgICQoZG9jdW1lbnQuYm9keSkub2ZmKCcuemYuZHJvcGRvd25tZW51Jyk7XG4gICAgRm91bmRhdGlvbi5OZXN0LkJ1cm4odGhpcy4kZWxlbWVudCwgJ2Ryb3Bkb3duJyk7XG4gICAgRm91bmRhdGlvbi51bnJlZ2lzdGVyUGx1Z2luKHRoaXMpO1xuICB9XG59XG5cbi8qKlxuICogRGVmYXVsdCBzZXR0aW5ncyBmb3IgcGx1Z2luXG4gKi9cbkRyb3Bkb3duTWVudS5kZWZhdWx0cyA9IHtcbiAgLyoqXG4gICAqIERpc2FsbG93cyBob3ZlciBldmVudHMgZnJvbSBvcGVuaW5nIHN1Ym1lbnVzXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgZmFsc2VcbiAgICovXG4gIGRpc2FibGVIb3ZlcjogZmFsc2UsXG4gIC8qKlxuICAgKiBBbGxvdyBhIHN1Ym1lbnUgdG8gYXV0b21hdGljYWxseSBjbG9zZSBvbiBhIG1vdXNlbGVhdmUgZXZlbnQsIGlmIG5vdCBjbGlja2VkIG9wZW4uXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgdHJ1ZVxuICAgKi9cbiAgYXV0b2Nsb3NlOiB0cnVlLFxuICAvKipcbiAgICogQW1vdW50IG9mIHRpbWUgdG8gZGVsYXkgb3BlbmluZyBhIHN1Ym1lbnUgb24gaG92ZXIgZXZlbnQuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgNTBcbiAgICovXG4gIGhvdmVyRGVsYXk6IDUwLFxuICAvKipcbiAgICogQWxsb3cgYSBzdWJtZW51IHRvIG9wZW4vcmVtYWluIG9wZW4gb24gcGFyZW50IGNsaWNrIGV2ZW50LiBBbGxvd3MgY3Vyc29yIHRvIG1vdmUgYXdheSBmcm9tIG1lbnUuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgdHJ1ZVxuICAgKi9cbiAgY2xpY2tPcGVuOiBmYWxzZSxcbiAgLyoqXG4gICAqIEFtb3VudCBvZiB0aW1lIHRvIGRlbGF5IGNsb3NpbmcgYSBzdWJtZW51IG9uIGEgbW91c2VsZWF2ZSBldmVudC5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSA1MDBcbiAgICovXG5cbiAgY2xvc2luZ1RpbWU6IDUwMCxcbiAgLyoqXG4gICAqIFBvc2l0aW9uIG9mIHRoZSBtZW51IHJlbGF0aXZlIHRvIHdoYXQgZGlyZWN0aW9uIHRoZSBzdWJtZW51cyBzaG91bGQgb3Blbi4gSGFuZGxlZCBieSBKUy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnbGVmdCdcbiAgICovXG4gIGFsaWdubWVudDogJ2xlZnQnLFxuICAvKipcbiAgICogQWxsb3cgY2xpY2tzIG9uIHRoZSBib2R5IHRvIGNsb3NlIGFueSBvcGVuIHN1Ym1lbnVzLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIHRydWVcbiAgICovXG4gIGNsb3NlT25DbGljazogdHJ1ZSxcbiAgLyoqXG4gICAqIEFsbG93IGNsaWNrcyBvbiBsZWFmIGFuY2hvciBsaW5rcyB0byBjbG9zZSBhbnkgb3BlbiBzdWJtZW51cy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSB0cnVlXG4gICAqL1xuICBjbG9zZU9uQ2xpY2tJbnNpZGU6IHRydWUsXG4gIC8qKlxuICAgKiBDbGFzcyBhcHBsaWVkIHRvIHZlcnRpY2FsIG9yaWVudGVkIG1lbnVzLCBGb3VuZGF0aW9uIGRlZmF1bHQgaXMgYHZlcnRpY2FsYC4gVXBkYXRlIHRoaXMgaWYgdXNpbmcgeW91ciBvd24gY2xhc3MuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgJ3ZlcnRpY2FsJ1xuICAgKi9cbiAgdmVydGljYWxDbGFzczogJ3ZlcnRpY2FsJyxcbiAgLyoqXG4gICAqIENsYXNzIGFwcGxpZWQgdG8gcmlnaHQtc2lkZSBvcmllbnRlZCBtZW51cywgRm91bmRhdGlvbiBkZWZhdWx0IGlzIGBhbGlnbi1yaWdodGAuIFVwZGF0ZSB0aGlzIGlmIHVzaW5nIHlvdXIgb3duIGNsYXNzLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlICdhbGlnbi1yaWdodCdcbiAgICovXG4gIHJpZ2h0Q2xhc3M6ICdhbGlnbi1yaWdodCcsXG4gIC8qKlxuICAgKiBCb29sZWFuIHRvIGZvcmNlIG92ZXJpZGUgdGhlIGNsaWNraW5nIG9mIGxpbmtzIHRvIHBlcmZvcm0gZGVmYXVsdCBhY3Rpb24sIG9uIHNlY29uZCB0b3VjaCBldmVudCBmb3IgbW9iaWxlLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICBmb3JjZUZvbGxvdzogdHJ1ZVxufTtcblxuLy8gV2luZG93IGV4cG9ydHNcbkZvdW5kYXRpb24ucGx1Z2luKERyb3Bkb3duTWVudSwgJ0Ryb3Bkb3duTWVudScpO1xuXG59KGpRdWVyeSk7XG4iLCIndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbi8qKlxuICogT2ZmQ2FudmFzIG1vZHVsZS5cbiAqIEBtb2R1bGUgZm91bmRhdGlvbi5vZmZjYW52YXNcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwubWVkaWFRdWVyeVxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC50cmlnZ2Vyc1xuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC5tb3Rpb25cbiAqL1xuXG5jbGFzcyBPZmZDYW52YXMge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBpbnN0YW5jZSBvZiBhbiBvZmYtY2FudmFzIHdyYXBwZXIuXG4gICAqIEBjbGFzc1xuICAgKiBAZmlyZXMgT2ZmQ2FudmFzI2luaXRcbiAgICogQHBhcmFtIHtPYmplY3R9IGVsZW1lbnQgLSBqUXVlcnkgb2JqZWN0IHRvIGluaXRpYWxpemUuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zIC0gT3ZlcnJpZGVzIHRvIHRoZSBkZWZhdWx0IHBsdWdpbiBzZXR0aW5ncy5cbiAgICovXG4gIGNvbnN0cnVjdG9yKGVsZW1lbnQsIG9wdGlvbnMpIHtcbiAgICB0aGlzLiRlbGVtZW50ID0gZWxlbWVudDtcbiAgICB0aGlzLm9wdGlvbnMgPSAkLmV4dGVuZCh7fSwgT2ZmQ2FudmFzLmRlZmF1bHRzLCB0aGlzLiRlbGVtZW50LmRhdGEoKSwgb3B0aW9ucyk7XG4gICAgdGhpcy4kbGFzdFRyaWdnZXIgPSAkKCk7XG4gICAgdGhpcy4kdHJpZ2dlcnMgPSAkKCk7XG5cbiAgICB0aGlzLl9pbml0KCk7XG4gICAgdGhpcy5fZXZlbnRzKCk7XG5cbiAgICBGb3VuZGF0aW9uLnJlZ2lzdGVyUGx1Z2luKHRoaXMsICdPZmZDYW52YXMnKVxuICAgIEZvdW5kYXRpb24uS2V5Ym9hcmQucmVnaXN0ZXIoJ09mZkNhbnZhcycsIHtcbiAgICAgICdFU0NBUEUnOiAnY2xvc2UnXG4gICAgfSk7XG5cbiAgfVxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyB0aGUgb2ZmLWNhbnZhcyB3cmFwcGVyIGJ5IGFkZGluZyB0aGUgZXhpdCBvdmVybGF5IChpZiBuZWVkZWQpLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9pbml0KCkge1xuICAgIHZhciBpZCA9IHRoaXMuJGVsZW1lbnQuYXR0cignaWQnKTtcblxuICAgIHRoaXMuJGVsZW1lbnQuYXR0cignYXJpYS1oaWRkZW4nLCAndHJ1ZScpO1xuXG4gICAgdGhpcy4kZWxlbWVudC5hZGRDbGFzcyhgaXMtdHJhbnNpdGlvbi0ke3RoaXMub3B0aW9ucy50cmFuc2l0aW9ufWApO1xuXG4gICAgLy8gRmluZCB0cmlnZ2VycyB0aGF0IGFmZmVjdCB0aGlzIGVsZW1lbnQgYW5kIGFkZCBhcmlhLWV4cGFuZGVkIHRvIHRoZW1cbiAgICB0aGlzLiR0cmlnZ2VycyA9ICQoZG9jdW1lbnQpXG4gICAgICAuZmluZCgnW2RhdGEtb3Blbj1cIicraWQrJ1wiXSwgW2RhdGEtY2xvc2U9XCInK2lkKydcIl0sIFtkYXRhLXRvZ2dsZT1cIicraWQrJ1wiXScpXG4gICAgICAuYXR0cignYXJpYS1leHBhbmRlZCcsICdmYWxzZScpXG4gICAgICAuYXR0cignYXJpYS1jb250cm9scycsIGlkKTtcblxuICAgIC8vIEFkZCBhbiBvdmVybGF5IG92ZXIgdGhlIGNvbnRlbnQgaWYgbmVjZXNzYXJ5XG4gICAgaWYgKHRoaXMub3B0aW9ucy5jb250ZW50T3ZlcmxheSA9PT0gdHJ1ZSkge1xuICAgICAgdmFyIG92ZXJsYXkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIHZhciBvdmVybGF5UG9zaXRpb24gPSAkKHRoaXMuJGVsZW1lbnQpLmNzcyhcInBvc2l0aW9uXCIpID09PSAnZml4ZWQnID8gJ2lzLW92ZXJsYXktZml4ZWQnIDogJ2lzLW92ZXJsYXktYWJzb2x1dGUnO1xuICAgICAgb3ZlcmxheS5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ2pzLW9mZi1jYW52YXMtb3ZlcmxheSAnICsgb3ZlcmxheVBvc2l0aW9uKTtcbiAgICAgIHRoaXMuJG92ZXJsYXkgPSAkKG92ZXJsYXkpO1xuICAgICAgaWYob3ZlcmxheVBvc2l0aW9uID09PSAnaXMtb3ZlcmxheS1maXhlZCcpIHtcbiAgICAgICAgJCgnYm9keScpLmFwcGVuZCh0aGlzLiRvdmVybGF5KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuJGVsZW1lbnQuc2libGluZ3MoJ1tkYXRhLW9mZi1jYW52YXMtY29udGVudF0nKS5hcHBlbmQodGhpcy4kb3ZlcmxheSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgdGhpcy5vcHRpb25zLmlzUmV2ZWFsZWQgPSB0aGlzLm9wdGlvbnMuaXNSZXZlYWxlZCB8fCBuZXcgUmVnRXhwKHRoaXMub3B0aW9ucy5yZXZlYWxDbGFzcywgJ2cnKS50ZXN0KHRoaXMuJGVsZW1lbnRbMF0uY2xhc3NOYW1lKTtcblxuICAgIGlmICh0aGlzLm9wdGlvbnMuaXNSZXZlYWxlZCA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy5vcHRpb25zLnJldmVhbE9uID0gdGhpcy5vcHRpb25zLnJldmVhbE9uIHx8IHRoaXMuJGVsZW1lbnRbMF0uY2xhc3NOYW1lLm1hdGNoKC8ocmV2ZWFsLWZvci1tZWRpdW18cmV2ZWFsLWZvci1sYXJnZSkvZylbMF0uc3BsaXQoJy0nKVsyXTtcbiAgICAgIHRoaXMuX3NldE1RQ2hlY2tlcigpO1xuICAgIH1cbiAgICBpZiAoIXRoaXMub3B0aW9ucy50cmFuc2l0aW9uVGltZSA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy5vcHRpb25zLnRyYW5zaXRpb25UaW1lID0gcGFyc2VGbG9hdCh3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZSgkKCdbZGF0YS1vZmYtY2FudmFzXScpWzBdKS50cmFuc2l0aW9uRHVyYXRpb24pICogMTAwMDtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBldmVudCBoYW5kbGVycyB0byB0aGUgb2ZmLWNhbnZhcyB3cmFwcGVyIGFuZCB0aGUgZXhpdCBvdmVybGF5LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9ldmVudHMoKSB7XG4gICAgdGhpcy4kZWxlbWVudC5vZmYoJy56Zi50cmlnZ2VyIC56Zi5vZmZjYW52YXMnKS5vbih7XG4gICAgICAnb3Blbi56Zi50cmlnZ2VyJzogdGhpcy5vcGVuLmJpbmQodGhpcyksXG4gICAgICAnY2xvc2UuemYudHJpZ2dlcic6IHRoaXMuY2xvc2UuYmluZCh0aGlzKSxcbiAgICAgICd0b2dnbGUuemYudHJpZ2dlcic6IHRoaXMudG9nZ2xlLmJpbmQodGhpcyksXG4gICAgICAna2V5ZG93bi56Zi5vZmZjYW52YXMnOiB0aGlzLl9oYW5kbGVLZXlib2FyZC5iaW5kKHRoaXMpXG4gICAgfSk7XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmNsb3NlT25DbGljayA9PT0gdHJ1ZSkge1xuICAgICAgdmFyICR0YXJnZXQgPSB0aGlzLm9wdGlvbnMuY29udGVudE92ZXJsYXkgPyB0aGlzLiRvdmVybGF5IDogJCgnW2RhdGEtb2ZmLWNhbnZhcy1jb250ZW50XScpO1xuICAgICAgJHRhcmdldC5vbih7J2NsaWNrLnpmLm9mZmNhbnZhcyc6IHRoaXMuY2xvc2UuYmluZCh0aGlzKX0pO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBBcHBsaWVzIGV2ZW50IGxpc3RlbmVyIGZvciBlbGVtZW50cyB0aGF0IHdpbGwgcmV2ZWFsIGF0IGNlcnRhaW4gYnJlYWtwb2ludHMuXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfc2V0TVFDaGVja2VyKCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAkKHdpbmRvdykub24oJ2NoYW5nZWQuemYubWVkaWFxdWVyeScsIGZ1bmN0aW9uKCkge1xuICAgICAgaWYgKEZvdW5kYXRpb24uTWVkaWFRdWVyeS5hdExlYXN0KF90aGlzLm9wdGlvbnMucmV2ZWFsT24pKSB7XG4gICAgICAgIF90aGlzLnJldmVhbCh0cnVlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIF90aGlzLnJldmVhbChmYWxzZSk7XG4gICAgICB9XG4gICAgfSkub25lKCdsb2FkLnpmLm9mZmNhbnZhcycsIGZ1bmN0aW9uKCkge1xuICAgICAgaWYgKEZvdW5kYXRpb24uTWVkaWFRdWVyeS5hdExlYXN0KF90aGlzLm9wdGlvbnMucmV2ZWFsT24pKSB7XG4gICAgICAgIF90aGlzLnJldmVhbCh0cnVlKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBIYW5kbGVzIHRoZSByZXZlYWxpbmcvaGlkaW5nIHRoZSBvZmYtY2FudmFzIGF0IGJyZWFrcG9pbnRzLCBub3QgdGhlIHNhbWUgYXMgb3Blbi5cbiAgICogQHBhcmFtIHtCb29sZWFufSBpc1JldmVhbGVkIC0gdHJ1ZSBpZiBlbGVtZW50IHNob3VsZCBiZSByZXZlYWxlZC5cbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICByZXZlYWwoaXNSZXZlYWxlZCkge1xuICAgIHZhciAkY2xvc2VyID0gdGhpcy4kZWxlbWVudC5maW5kKCdbZGF0YS1jbG9zZV0nKTtcbiAgICBpZiAoaXNSZXZlYWxlZCkge1xuICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgdGhpcy5pc1JldmVhbGVkID0gdHJ1ZTtcbiAgICAgIHRoaXMuJGVsZW1lbnQuYXR0cignYXJpYS1oaWRkZW4nLCAnZmFsc2UnKTtcbiAgICAgIHRoaXMuJGVsZW1lbnQub2ZmKCdvcGVuLnpmLnRyaWdnZXIgdG9nZ2xlLnpmLnRyaWdnZXInKTtcbiAgICAgIGlmICgkY2xvc2VyLmxlbmd0aCkgeyAkY2xvc2VyLmhpZGUoKTsgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmlzUmV2ZWFsZWQgPSBmYWxzZTtcbiAgICAgIHRoaXMuJGVsZW1lbnQuYXR0cignYXJpYS1oaWRkZW4nLCAndHJ1ZScpO1xuICAgICAgdGhpcy4kZWxlbWVudC5vbih7XG4gICAgICAgICdvcGVuLnpmLnRyaWdnZXInOiB0aGlzLm9wZW4uYmluZCh0aGlzKSxcbiAgICAgICAgJ3RvZ2dsZS56Zi50cmlnZ2VyJzogdGhpcy50b2dnbGUuYmluZCh0aGlzKVxuICAgICAgfSk7XG4gICAgICBpZiAoJGNsb3Nlci5sZW5ndGgpIHtcbiAgICAgICAgJGNsb3Nlci5zaG93KCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFN0b3BzIHNjcm9sbGluZyBvZiB0aGUgYm9keSB3aGVuIG9mZmNhbnZhcyBpcyBvcGVuIG9uIG1vYmlsZSBTYWZhcmkgYW5kIG90aGVyIHRyb3VibGVzb21lIGJyb3dzZXJzLlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX3N0b3BTY3JvbGxpbmcoZXZlbnQpIHtcbiAgXHRyZXR1cm4gZmFsc2U7XG4gIH1cblxuICAvKipcbiAgICogT3BlbnMgdGhlIG9mZi1jYW52YXMgbWVudS5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBldmVudCAtIEV2ZW50IG9iamVjdCBwYXNzZWQgZnJvbSBsaXN0ZW5lci5cbiAgICogQHBhcmFtIHtqUXVlcnl9IHRyaWdnZXIgLSBlbGVtZW50IHRoYXQgdHJpZ2dlcmVkIHRoZSBvZmYtY2FudmFzIHRvIG9wZW4uXG4gICAqIEBmaXJlcyBPZmZDYW52YXMjb3BlbmVkXG4gICAqL1xuICBvcGVuKGV2ZW50LCB0cmlnZ2VyKSB7XG4gICAgaWYgKHRoaXMuJGVsZW1lbnQuaGFzQ2xhc3MoJ2lzLW9wZW4nKSB8fCB0aGlzLmlzUmV2ZWFsZWQpIHsgcmV0dXJuOyB9XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIGlmICh0cmlnZ2VyKSB7XG4gICAgICB0aGlzLiRsYXN0VHJpZ2dlciA9IHRyaWdnZXI7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5mb3JjZVRvID09PSAndG9wJykge1xuICAgICAgd2luZG93LnNjcm9sbFRvKDAsIDApO1xuICAgIH0gZWxzZSBpZiAodGhpcy5vcHRpb25zLmZvcmNlVG8gPT09ICdib3R0b20nKSB7XG4gICAgICB3aW5kb3cuc2Nyb2xsVG8oMCxkb2N1bWVudC5ib2R5LnNjcm9sbEhlaWdodCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRmlyZXMgd2hlbiB0aGUgb2ZmLWNhbnZhcyBtZW51IG9wZW5zLlxuICAgICAqIEBldmVudCBPZmZDYW52YXMjb3BlbmVkXG4gICAgICovXG4gICAgX3RoaXMuJGVsZW1lbnQuYWRkQ2xhc3MoJ2lzLW9wZW4nKVxuXG4gICAgdGhpcy4kdHJpZ2dlcnMuYXR0cignYXJpYS1leHBhbmRlZCcsICd0cnVlJyk7XG4gICAgdGhpcy4kZWxlbWVudC5hdHRyKCdhcmlhLWhpZGRlbicsICdmYWxzZScpXG4gICAgICAgIC50cmlnZ2VyKCdvcGVuZWQuemYub2ZmY2FudmFzJyk7XG5cbiAgICAvLyBJZiBgY29udGVudFNjcm9sbGAgaXMgc2V0IHRvIGZhbHNlLCBhZGQgY2xhc3MgYW5kIGRpc2FibGUgc2Nyb2xsaW5nIG9uIHRvdWNoIGRldmljZXMuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5jb250ZW50U2Nyb2xsID09PSBmYWxzZSkge1xuICAgICAgJCgnYm9keScpLmFkZENsYXNzKCdpcy1vZmYtY2FudmFzLW9wZW4nKS5vbigndG91Y2htb3ZlJywgdGhpcy5fc3RvcFNjcm9sbGluZyk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5jb250ZW50T3ZlcmxheSA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy4kb3ZlcmxheS5hZGRDbGFzcygnaXMtdmlzaWJsZScpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLm9wdGlvbnMuY2xvc2VPbkNsaWNrID09PSB0cnVlICYmIHRoaXMub3B0aW9ucy5jb250ZW50T3ZlcmxheSA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy4kb3ZlcmxheS5hZGRDbGFzcygnaXMtY2xvc2FibGUnKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmF1dG9Gb2N1cyA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy4kZWxlbWVudC5vbmUoRm91bmRhdGlvbi50cmFuc2l0aW9uZW5kKHRoaXMuJGVsZW1lbnQpLCBmdW5jdGlvbigpIHtcbiAgICAgICAgX3RoaXMuJGVsZW1lbnQuZmluZCgnYSwgYnV0dG9uJykuZXEoMCkuZm9jdXMoKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGlmICh0aGlzLm9wdGlvbnMudHJhcEZvY3VzID09PSB0cnVlKSB7XG4gICAgICB0aGlzLiRlbGVtZW50LnNpYmxpbmdzKCdbZGF0YS1vZmYtY2FudmFzLWNvbnRlbnRdJykuYXR0cigndGFiaW5kZXgnLCAnLTEnKTtcbiAgICAgIEZvdW5kYXRpb24uS2V5Ym9hcmQudHJhcEZvY3VzKHRoaXMuJGVsZW1lbnQpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBDbG9zZXMgdGhlIG9mZi1jYW52YXMgbWVudS5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGNiIC0gb3B0aW9uYWwgY2IgdG8gZmlyZSBhZnRlciBjbG9zdXJlLlxuICAgKiBAZmlyZXMgT2ZmQ2FudmFzI2Nsb3NlZFxuICAgKi9cbiAgY2xvc2UoY2IpIHtcbiAgICBpZiAoIXRoaXMuJGVsZW1lbnQuaGFzQ2xhc3MoJ2lzLW9wZW4nKSB8fCB0aGlzLmlzUmV2ZWFsZWQpIHsgcmV0dXJuOyB9XG5cbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgX3RoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3MoJ2lzLW9wZW4nKTtcblxuICAgIHRoaXMuJGVsZW1lbnQuYXR0cignYXJpYS1oaWRkZW4nLCAndHJ1ZScpXG4gICAgICAvKipcbiAgICAgICAqIEZpcmVzIHdoZW4gdGhlIG9mZi1jYW52YXMgbWVudSBvcGVucy5cbiAgICAgICAqIEBldmVudCBPZmZDYW52YXMjY2xvc2VkXG4gICAgICAgKi9cbiAgICAgICAgLnRyaWdnZXIoJ2Nsb3NlZC56Zi5vZmZjYW52YXMnKTtcblxuICAgIC8vIElmIGBjb250ZW50U2Nyb2xsYCBpcyBzZXQgdG8gZmFsc2UsIHJlbW92ZSBjbGFzcyBhbmQgcmUtZW5hYmxlIHNjcm9sbGluZyBvbiB0b3VjaCBkZXZpY2VzLlxuICAgIGlmICh0aGlzLm9wdGlvbnMuY29udGVudFNjcm9sbCA9PT0gZmFsc2UpIHtcbiAgICAgICQoJ2JvZHknKS5yZW1vdmVDbGFzcygnaXMtb2ZmLWNhbnZhcy1vcGVuJykub2ZmKCd0b3VjaG1vdmUnLCB0aGlzLl9zdG9wU2Nyb2xsaW5nKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmNvbnRlbnRPdmVybGF5ID09PSB0cnVlKSB7XG4gICAgICB0aGlzLiRvdmVybGF5LnJlbW92ZUNsYXNzKCdpcy12aXNpYmxlJyk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5jbG9zZU9uQ2xpY2sgPT09IHRydWUgJiYgdGhpcy5vcHRpb25zLmNvbnRlbnRPdmVybGF5ID09PSB0cnVlKSB7XG4gICAgICB0aGlzLiRvdmVybGF5LnJlbW92ZUNsYXNzKCdpcy1jbG9zYWJsZScpO1xuICAgIH1cblxuICAgIHRoaXMuJHRyaWdnZXJzLmF0dHIoJ2FyaWEtZXhwYW5kZWQnLCAnZmFsc2UnKTtcblxuICAgIGlmICh0aGlzLm9wdGlvbnMudHJhcEZvY3VzID09PSB0cnVlKSB7XG4gICAgICB0aGlzLiRlbGVtZW50LnNpYmxpbmdzKCdbZGF0YS1vZmYtY2FudmFzLWNvbnRlbnRdJykucmVtb3ZlQXR0cigndGFiaW5kZXgnKTtcbiAgICAgIEZvdW5kYXRpb24uS2V5Ym9hcmQucmVsZWFzZUZvY3VzKHRoaXMuJGVsZW1lbnQpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBUb2dnbGVzIHRoZSBvZmYtY2FudmFzIG1lbnUgb3BlbiBvciBjbG9zZWQuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcGFyYW0ge09iamVjdH0gZXZlbnQgLSBFdmVudCBvYmplY3QgcGFzc2VkIGZyb20gbGlzdGVuZXIuXG4gICAqIEBwYXJhbSB7alF1ZXJ5fSB0cmlnZ2VyIC0gZWxlbWVudCB0aGF0IHRyaWdnZXJlZCB0aGUgb2ZmLWNhbnZhcyB0byBvcGVuLlxuICAgKi9cbiAgdG9nZ2xlKGV2ZW50LCB0cmlnZ2VyKSB7XG4gICAgaWYgKHRoaXMuJGVsZW1lbnQuaGFzQ2xhc3MoJ2lzLW9wZW4nKSkge1xuICAgICAgdGhpcy5jbG9zZShldmVudCwgdHJpZ2dlcik7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgdGhpcy5vcGVuKGV2ZW50LCB0cmlnZ2VyKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogSGFuZGxlcyBrZXlib2FyZCBpbnB1dCB3aGVuIGRldGVjdGVkLiBXaGVuIHRoZSBlc2NhcGUga2V5IGlzIHByZXNzZWQsIHRoZSBvZmYtY2FudmFzIG1lbnUgY2xvc2VzLCBhbmQgZm9jdXMgaXMgcmVzdG9yZWQgdG8gdGhlIGVsZW1lbnQgdGhhdCBvcGVuZWQgdGhlIG1lbnUuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2hhbmRsZUtleWJvYXJkKGUpIHtcbiAgICBGb3VuZGF0aW9uLktleWJvYXJkLmhhbmRsZUtleShlLCAnT2ZmQ2FudmFzJywge1xuICAgICAgY2xvc2U6ICgpID0+IHtcbiAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICB0aGlzLiRsYXN0VHJpZ2dlci5mb2N1cygpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH0sXG4gICAgICBoYW5kbGVkOiAoKSA9PiB7XG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXN0cm95cyB0aGUgb2ZmY2FudmFzIHBsdWdpbi5cbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICBkZXN0cm95KCkge1xuICAgIHRoaXMuY2xvc2UoKTtcbiAgICB0aGlzLiRlbGVtZW50Lm9mZignLnpmLnRyaWdnZXIgLnpmLm9mZmNhbnZhcycpO1xuICAgIHRoaXMuJG92ZXJsYXkub2ZmKCcuemYub2ZmY2FudmFzJyk7XG5cbiAgICBGb3VuZGF0aW9uLnVucmVnaXN0ZXJQbHVnaW4odGhpcyk7XG4gIH1cbn1cblxuT2ZmQ2FudmFzLmRlZmF1bHRzID0ge1xuICAvKipcbiAgICogQWxsb3cgdGhlIHVzZXIgdG8gY2xpY2sgb3V0c2lkZSBvZiB0aGUgbWVudSB0byBjbG9zZSBpdC5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSB0cnVlXG4gICAqL1xuICBjbG9zZU9uQ2xpY2s6IHRydWUsXG5cbiAgLyoqXG4gICAqIEFkZHMgYW4gb3ZlcmxheSBvbiB0b3Agb2YgYFtkYXRhLW9mZi1jYW52YXMtY29udGVudF1gLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIHRydWVcbiAgICovXG4gIGNvbnRlbnRPdmVybGF5OiB0cnVlLFxuXG4gIC8qKlxuICAgKiBFbmFibGUvZGlzYWJsZSBzY3JvbGxpbmcgb2YgdGhlIG1haW4gY29udGVudCB3aGVuIGFuIG9mZiBjYW52YXMgcGFuZWwgaXMgb3Blbi5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSB0cnVlXG4gICAqL1xuICBjb250ZW50U2Nyb2xsOiB0cnVlLFxuXG4gIC8qKlxuICAgKiBBbW91bnQgb2YgdGltZSBpbiBtcyB0aGUgb3BlbiBhbmQgY2xvc2UgdHJhbnNpdGlvbiByZXF1aXJlcy4gSWYgbm9uZSBzZWxlY3RlZCwgcHVsbHMgZnJvbSBib2R5IHN0eWxlLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIDUwMFxuICAgKi9cbiAgdHJhbnNpdGlvblRpbWU6IDAsXG5cbiAgLyoqXG4gICAqIFR5cGUgb2YgdHJhbnNpdGlvbiBmb3IgdGhlIG9mZmNhbnZhcyBtZW51LiBPcHRpb25zIGFyZSAncHVzaCcsICdkZXRhY2hlZCcgb3IgJ3NsaWRlJy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBwdXNoXG4gICAqL1xuICB0cmFuc2l0aW9uOiAncHVzaCcsXG5cbiAgLyoqXG4gICAqIEZvcmNlIHRoZSBwYWdlIHRvIHNjcm9sbCB0byB0b3Agb3IgYm90dG9tIG9uIG9wZW4uXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgdG9wXG4gICAqL1xuICBmb3JjZVRvOiBudWxsLFxuXG4gIC8qKlxuICAgKiBBbGxvdyB0aGUgb2ZmY2FudmFzIHRvIHJlbWFpbiBvcGVuIGZvciBjZXJ0YWluIGJyZWFrcG9pbnRzLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICBpc1JldmVhbGVkOiBmYWxzZSxcblxuICAvKipcbiAgICogQnJlYWtwb2ludCBhdCB3aGljaCB0byByZXZlYWwuIEpTIHdpbGwgdXNlIGEgUmVnRXhwIHRvIHRhcmdldCBzdGFuZGFyZCBjbGFzc2VzLCBpZiBjaGFuZ2luZyBjbGFzc25hbWVzLCBwYXNzIHlvdXIgY2xhc3Mgd2l0aCB0aGUgYHJldmVhbENsYXNzYCBvcHRpb24uXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgcmV2ZWFsLWZvci1sYXJnZVxuICAgKi9cbiAgcmV2ZWFsT246IG51bGwsXG5cbiAgLyoqXG4gICAqIEZvcmNlIGZvY3VzIHRvIHRoZSBvZmZjYW52YXMgb24gb3Blbi4gSWYgdHJ1ZSwgd2lsbCBmb2N1cyB0aGUgb3BlbmluZyB0cmlnZ2VyIG9uIGNsb3NlLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIHRydWVcbiAgICovXG4gIGF1dG9Gb2N1czogdHJ1ZSxcblxuICAvKipcbiAgICogQ2xhc3MgdXNlZCB0byBmb3JjZSBhbiBvZmZjYW52YXMgdG8gcmVtYWluIG9wZW4uIEZvdW5kYXRpb24gZGVmYXVsdHMgZm9yIHRoaXMgYXJlIGByZXZlYWwtZm9yLWxhcmdlYCAmIGByZXZlYWwtZm9yLW1lZGl1bWAuXG4gICAqIEBvcHRpb25cbiAgICogVE9ETyBpbXByb3ZlIHRoZSByZWdleCB0ZXN0aW5nIGZvciB0aGlzLlxuICAgKiBAZXhhbXBsZSByZXZlYWwtZm9yLWxhcmdlXG4gICAqL1xuICByZXZlYWxDbGFzczogJ3JldmVhbC1mb3ItJyxcblxuICAvKipcbiAgICogVHJpZ2dlcnMgb3B0aW9uYWwgZm9jdXMgdHJhcHBpbmcgd2hlbiBvcGVuaW5nIGFuIG9mZmNhbnZhcy4gU2V0cyB0YWJpbmRleCBvZiBbZGF0YS1vZmYtY2FudmFzLWNvbnRlbnRdIHRvIC0xIGZvciBhY2Nlc3NpYmlsaXR5IHB1cnBvc2VzLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIHRydWVcbiAgICovXG4gIHRyYXBGb2N1czogZmFsc2Vcbn1cblxuLy8gV2luZG93IGV4cG9ydHNcbkZvdW5kYXRpb24ucGx1Z2luKE9mZkNhbnZhcywgJ09mZkNhbnZhcycpO1xuXG59KGpRdWVyeSk7XG4iLCIndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbi8qKlxuICogUmVzcG9uc2l2ZU1lbnUgbW9kdWxlLlxuICogQG1vZHVsZSBmb3VuZGF0aW9uLnJlc3BvbnNpdmVNZW51XG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLnRyaWdnZXJzXG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLm1lZGlhUXVlcnlcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwuYWNjb3JkaW9uTWVudVxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC5kcmlsbGRvd25cbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwuZHJvcGRvd24tbWVudVxuICovXG5cbmNsYXNzIFJlc3BvbnNpdmVNZW51IHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgaW5zdGFuY2Ugb2YgYSByZXNwb25zaXZlIG1lbnUuXG4gICAqIEBjbGFzc1xuICAgKiBAZmlyZXMgUmVzcG9uc2l2ZU1lbnUjaW5pdFxuICAgKiBAcGFyYW0ge2pRdWVyeX0gZWxlbWVudCAtIGpRdWVyeSBvYmplY3QgdG8gbWFrZSBpbnRvIGEgZHJvcGRvd24gbWVudS5cbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMgLSBPdmVycmlkZXMgdG8gdGhlIGRlZmF1bHQgcGx1Z2luIHNldHRpbmdzLlxuICAgKi9cbiAgY29uc3RydWN0b3IoZWxlbWVudCwgb3B0aW9ucykge1xuICAgIHRoaXMuJGVsZW1lbnQgPSAkKGVsZW1lbnQpO1xuICAgIHRoaXMucnVsZXMgPSB0aGlzLiRlbGVtZW50LmRhdGEoJ3Jlc3BvbnNpdmUtbWVudScpO1xuICAgIHRoaXMuY3VycmVudE1xID0gbnVsbDtcbiAgICB0aGlzLmN1cnJlbnRQbHVnaW4gPSBudWxsO1xuXG4gICAgdGhpcy5faW5pdCgpO1xuICAgIHRoaXMuX2V2ZW50cygpO1xuXG4gICAgRm91bmRhdGlvbi5yZWdpc3RlclBsdWdpbih0aGlzLCAnUmVzcG9uc2l2ZU1lbnUnKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyB0aGUgTWVudSBieSBwYXJzaW5nIHRoZSBjbGFzc2VzIGZyb20gdGhlICdkYXRhLVJlc3BvbnNpdmVNZW51JyBhdHRyaWJ1dGUgb24gdGhlIGVsZW1lbnQuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2luaXQoKSB7XG4gICAgLy8gVGhlIGZpcnN0IHRpbWUgYW4gSW50ZXJjaGFuZ2UgcGx1Z2luIGlzIGluaXRpYWxpemVkLCB0aGlzLnJ1bGVzIGlzIGNvbnZlcnRlZCBmcm9tIGEgc3RyaW5nIG9mIFwiY2xhc3Nlc1wiIHRvIGFuIG9iamVjdCBvZiBydWxlc1xuICAgIGlmICh0eXBlb2YgdGhpcy5ydWxlcyA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGxldCBydWxlc1RyZWUgPSB7fTtcblxuICAgICAgLy8gUGFyc2UgcnVsZXMgZnJvbSBcImNsYXNzZXNcIiBwdWxsZWQgZnJvbSBkYXRhIGF0dHJpYnV0ZVxuICAgICAgbGV0IHJ1bGVzID0gdGhpcy5ydWxlcy5zcGxpdCgnICcpO1xuXG4gICAgICAvLyBJdGVyYXRlIHRocm91Z2ggZXZlcnkgcnVsZSBmb3VuZFxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBydWxlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBsZXQgcnVsZSA9IHJ1bGVzW2ldLnNwbGl0KCctJyk7XG4gICAgICAgIGxldCBydWxlU2l6ZSA9IHJ1bGUubGVuZ3RoID4gMSA/IHJ1bGVbMF0gOiAnc21hbGwnO1xuICAgICAgICBsZXQgcnVsZVBsdWdpbiA9IHJ1bGUubGVuZ3RoID4gMSA/IHJ1bGVbMV0gOiBydWxlWzBdO1xuXG4gICAgICAgIGlmIChNZW51UGx1Z2luc1tydWxlUGx1Z2luXSAhPT0gbnVsbCkge1xuICAgICAgICAgIHJ1bGVzVHJlZVtydWxlU2l6ZV0gPSBNZW51UGx1Z2luc1tydWxlUGx1Z2luXTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICB0aGlzLnJ1bGVzID0gcnVsZXNUcmVlO1xuICAgIH1cblxuICAgIGlmICghJC5pc0VtcHR5T2JqZWN0KHRoaXMucnVsZXMpKSB7XG4gICAgICB0aGlzLl9jaGVja01lZGlhUXVlcmllcygpO1xuICAgIH1cbiAgICAvLyBBZGQgZGF0YS1tdXRhdGUgc2luY2UgY2hpbGRyZW4gbWF5IG5lZWQgaXQuXG4gICAgdGhpcy4kZWxlbWVudC5hdHRyKCdkYXRhLW11dGF0ZScsICh0aGlzLiRlbGVtZW50LmF0dHIoJ2RhdGEtbXV0YXRlJykgfHwgRm91bmRhdGlvbi5HZXRZb0RpZ2l0cyg2LCAncmVzcG9uc2l2ZS1tZW51JykpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyBldmVudHMgZm9yIHRoZSBNZW51LlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9ldmVudHMoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICQod2luZG93KS5vbignY2hhbmdlZC56Zi5tZWRpYXF1ZXJ5JywgZnVuY3Rpb24oKSB7XG4gICAgICBfdGhpcy5fY2hlY2tNZWRpYVF1ZXJpZXMoKTtcbiAgICB9KTtcbiAgICAvLyAkKHdpbmRvdykub24oJ3Jlc2l6ZS56Zi5SZXNwb25zaXZlTWVudScsIGZ1bmN0aW9uKCkge1xuICAgIC8vICAgX3RoaXMuX2NoZWNrTWVkaWFRdWVyaWVzKCk7XG4gICAgLy8gfSk7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2tzIHRoZSBjdXJyZW50IHNjcmVlbiB3aWR0aCBhZ2FpbnN0IGF2YWlsYWJsZSBtZWRpYSBxdWVyaWVzLiBJZiB0aGUgbWVkaWEgcXVlcnkgaGFzIGNoYW5nZWQsIGFuZCB0aGUgcGx1Z2luIG5lZWRlZCBoYXMgY2hhbmdlZCwgdGhlIHBsdWdpbnMgd2lsbCBzd2FwIG91dC5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfY2hlY2tNZWRpYVF1ZXJpZXMoKSB7XG4gICAgdmFyIG1hdGNoZWRNcSwgX3RoaXMgPSB0aGlzO1xuICAgIC8vIEl0ZXJhdGUgdGhyb3VnaCBlYWNoIHJ1bGUgYW5kIGZpbmQgdGhlIGxhc3QgbWF0Y2hpbmcgcnVsZVxuICAgICQuZWFjaCh0aGlzLnJ1bGVzLCBmdW5jdGlvbihrZXkpIHtcbiAgICAgIGlmIChGb3VuZGF0aW9uLk1lZGlhUXVlcnkuYXRMZWFzdChrZXkpKSB7XG4gICAgICAgIG1hdGNoZWRNcSA9IGtleTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIE5vIG1hdGNoPyBObyBkaWNlXG4gICAgaWYgKCFtYXRjaGVkTXEpIHJldHVybjtcblxuICAgIC8vIFBsdWdpbiBhbHJlYWR5IGluaXRpYWxpemVkPyBXZSBnb29kXG4gICAgaWYgKHRoaXMuY3VycmVudFBsdWdpbiBpbnN0YW5jZW9mIHRoaXMucnVsZXNbbWF0Y2hlZE1xXS5wbHVnaW4pIHJldHVybjtcblxuICAgIC8vIFJlbW92ZSBleGlzdGluZyBwbHVnaW4tc3BlY2lmaWMgQ1NTIGNsYXNzZXNcbiAgICAkLmVhY2goTWVudVBsdWdpbnMsIGZ1bmN0aW9uKGtleSwgdmFsdWUpIHtcbiAgICAgIF90aGlzLiRlbGVtZW50LnJlbW92ZUNsYXNzKHZhbHVlLmNzc0NsYXNzKTtcbiAgICB9KTtcblxuICAgIC8vIEFkZCB0aGUgQ1NTIGNsYXNzIGZvciB0aGUgbmV3IHBsdWdpblxuICAgIHRoaXMuJGVsZW1lbnQuYWRkQ2xhc3ModGhpcy5ydWxlc1ttYXRjaGVkTXFdLmNzc0NsYXNzKTtcblxuICAgIC8vIENyZWF0ZSBhbiBpbnN0YW5jZSBvZiB0aGUgbmV3IHBsdWdpblxuICAgIGlmICh0aGlzLmN1cnJlbnRQbHVnaW4pIHRoaXMuY3VycmVudFBsdWdpbi5kZXN0cm95KCk7XG4gICAgdGhpcy5jdXJyZW50UGx1Z2luID0gbmV3IHRoaXMucnVsZXNbbWF0Y2hlZE1xXS5wbHVnaW4odGhpcy4kZWxlbWVudCwge30pO1xuICB9XG5cbiAgLyoqXG4gICAqIERlc3Ryb3lzIHRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBwbHVnaW4gb24gdGhpcyBlbGVtZW50LCBhcyB3ZWxsIGFzIHRoZSB3aW5kb3cgcmVzaXplIGhhbmRsZXIgdGhhdCBzd2l0Y2hlcyB0aGUgcGx1Z2lucyBvdXQuXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLmN1cnJlbnRQbHVnaW4uZGVzdHJveSgpO1xuICAgICQod2luZG93KS5vZmYoJy56Zi5SZXNwb25zaXZlTWVudScpO1xuICAgIEZvdW5kYXRpb24udW5yZWdpc3RlclBsdWdpbih0aGlzKTtcbiAgfVxufVxuXG5SZXNwb25zaXZlTWVudS5kZWZhdWx0cyA9IHt9O1xuXG4vLyBUaGUgcGx1Z2luIG1hdGNoZXMgdGhlIHBsdWdpbiBjbGFzc2VzIHdpdGggdGhlc2UgcGx1Z2luIGluc3RhbmNlcy5cbnZhciBNZW51UGx1Z2lucyA9IHtcbiAgZHJvcGRvd246IHtcbiAgICBjc3NDbGFzczogJ2Ryb3Bkb3duJyxcbiAgICBwbHVnaW46IEZvdW5kYXRpb24uX3BsdWdpbnNbJ2Ryb3Bkb3duLW1lbnUnXSB8fCBudWxsXG4gIH0sXG4gZHJpbGxkb3duOiB7XG4gICAgY3NzQ2xhc3M6ICdkcmlsbGRvd24nLFxuICAgIHBsdWdpbjogRm91bmRhdGlvbi5fcGx1Z2luc1snZHJpbGxkb3duJ10gfHwgbnVsbFxuICB9LFxuICBhY2NvcmRpb246IHtcbiAgICBjc3NDbGFzczogJ2FjY29yZGlvbi1tZW51JyxcbiAgICBwbHVnaW46IEZvdW5kYXRpb24uX3BsdWdpbnNbJ2FjY29yZGlvbi1tZW51J10gfHwgbnVsbFxuICB9XG59O1xuXG4vLyBXaW5kb3cgZXhwb3J0c1xuRm91bmRhdGlvbi5wbHVnaW4oUmVzcG9uc2l2ZU1lbnUsICdSZXNwb25zaXZlTWVudScpO1xuXG59KGpRdWVyeSk7XG4iLCIndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbi8qKlxuICogUmVzcG9uc2l2ZVRvZ2dsZSBtb2R1bGUuXG4gKiBAbW9kdWxlIGZvdW5kYXRpb24ucmVzcG9uc2l2ZVRvZ2dsZVxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC5tZWRpYVF1ZXJ5XG4gKi9cblxuY2xhc3MgUmVzcG9uc2l2ZVRvZ2dsZSB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IGluc3RhbmNlIG9mIFRhYiBCYXIuXG4gICAqIEBjbGFzc1xuICAgKiBAZmlyZXMgUmVzcG9uc2l2ZVRvZ2dsZSNpbml0XG4gICAqIEBwYXJhbSB7alF1ZXJ5fSBlbGVtZW50IC0galF1ZXJ5IG9iamVjdCB0byBhdHRhY2ggdGFiIGJhciBmdW5jdGlvbmFsaXR5IHRvLlxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyAtIE92ZXJyaWRlcyB0byB0aGUgZGVmYXVsdCBwbHVnaW4gc2V0dGluZ3MuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihlbGVtZW50LCBvcHRpb25zKSB7XG4gICAgdGhpcy4kZWxlbWVudCA9ICQoZWxlbWVudCk7XG4gICAgdGhpcy5vcHRpb25zID0gJC5leHRlbmQoe30sIFJlc3BvbnNpdmVUb2dnbGUuZGVmYXVsdHMsIHRoaXMuJGVsZW1lbnQuZGF0YSgpLCBvcHRpb25zKTtcblxuICAgIHRoaXMuX2luaXQoKTtcbiAgICB0aGlzLl9ldmVudHMoKTtcblxuICAgIEZvdW5kYXRpb24ucmVnaXN0ZXJQbHVnaW4odGhpcywgJ1Jlc3BvbnNpdmVUb2dnbGUnKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyB0aGUgdGFiIGJhciBieSBmaW5kaW5nIHRoZSB0YXJnZXQgZWxlbWVudCwgdG9nZ2xpbmcgZWxlbWVudCwgYW5kIHJ1bm5pbmcgdXBkYXRlKCkuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2luaXQoKSB7XG4gICAgdmFyIHRhcmdldElEID0gdGhpcy4kZWxlbWVudC5kYXRhKCdyZXNwb25zaXZlLXRvZ2dsZScpO1xuICAgIGlmICghdGFyZ2V0SUQpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1lvdXIgdGFiIGJhciBuZWVkcyBhbiBJRCBvZiBhIE1lbnUgYXMgdGhlIHZhbHVlIG9mIGRhdGEtdGFiLWJhci4nKTtcbiAgICB9XG5cbiAgICB0aGlzLiR0YXJnZXRNZW51ID0gJChgIyR7dGFyZ2V0SUR9YCk7XG4gICAgdGhpcy4kdG9nZ2xlciA9IHRoaXMuJGVsZW1lbnQuZmluZCgnW2RhdGEtdG9nZ2xlXScpO1xuICAgIHRoaXMub3B0aW9ucyA9ICQuZXh0ZW5kKHt9LCB0aGlzLm9wdGlvbnMsIHRoaXMuJHRhcmdldE1lbnUuZGF0YSgpKTtcblxuICAgIC8vIElmIHRoZXkgd2VyZSBzZXQsIHBhcnNlIHRoZSBhbmltYXRpb24gY2xhc3Nlc1xuICAgIGlmKHRoaXMub3B0aW9ucy5hbmltYXRlKSB7XG4gICAgICBsZXQgaW5wdXQgPSB0aGlzLm9wdGlvbnMuYW5pbWF0ZS5zcGxpdCgnICcpO1xuXG4gICAgICB0aGlzLmFuaW1hdGlvbkluID0gaW5wdXRbMF07XG4gICAgICB0aGlzLmFuaW1hdGlvbk91dCA9IGlucHV0WzFdIHx8IG51bGw7XG4gICAgfVxuXG4gICAgdGhpcy5fdXBkYXRlKCk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBuZWNlc3NhcnkgZXZlbnQgaGFuZGxlcnMgZm9yIHRoZSB0YWIgYmFyIHRvIHdvcmsuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2V2ZW50cygpIHtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgdGhpcy5fdXBkYXRlTXFIYW5kbGVyID0gdGhpcy5fdXBkYXRlLmJpbmQodGhpcyk7XG5cbiAgICAkKHdpbmRvdykub24oJ2NoYW5nZWQuemYubWVkaWFxdWVyeScsIHRoaXMuX3VwZGF0ZU1xSGFuZGxlcik7XG5cbiAgICB0aGlzLiR0b2dnbGVyLm9uKCdjbGljay56Zi5yZXNwb25zaXZlVG9nZ2xlJywgdGhpcy50b2dnbGVNZW51LmJpbmQodGhpcykpO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrcyB0aGUgY3VycmVudCBtZWRpYSBxdWVyeSB0byBkZXRlcm1pbmUgaWYgdGhlIHRhYiBiYXIgc2hvdWxkIGJlIHZpc2libGUgb3IgaGlkZGVuLlxuICAgKiBAZnVuY3Rpb25cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF91cGRhdGUoKSB7XG4gICAgLy8gTW9iaWxlXG4gICAgaWYgKCFGb3VuZGF0aW9uLk1lZGlhUXVlcnkuYXRMZWFzdCh0aGlzLm9wdGlvbnMuaGlkZUZvcikpIHtcbiAgICAgIHRoaXMuJGVsZW1lbnQuc2hvdygpO1xuICAgICAgdGhpcy4kdGFyZ2V0TWVudS5oaWRlKCk7XG4gICAgfVxuXG4gICAgLy8gRGVza3RvcFxuICAgIGVsc2Uge1xuICAgICAgdGhpcy4kZWxlbWVudC5oaWRlKCk7XG4gICAgICB0aGlzLiR0YXJnZXRNZW51LnNob3coKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVG9nZ2xlcyB0aGUgZWxlbWVudCBhdHRhY2hlZCB0byB0aGUgdGFiIGJhci4gVGhlIHRvZ2dsZSBvbmx5IGhhcHBlbnMgaWYgdGhlIHNjcmVlbiBpcyBzbWFsbCBlbm91Z2ggdG8gYWxsb3cgaXQuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAZmlyZXMgUmVzcG9uc2l2ZVRvZ2dsZSN0b2dnbGVkXG4gICAqL1xuICB0b2dnbGVNZW51KCkge1xuICAgIGlmICghRm91bmRhdGlvbi5NZWRpYVF1ZXJ5LmF0TGVhc3QodGhpcy5vcHRpb25zLmhpZGVGb3IpKSB7XG4gICAgICBpZih0aGlzLm9wdGlvbnMuYW5pbWF0ZSkge1xuICAgICAgICBpZiAodGhpcy4kdGFyZ2V0TWVudS5pcygnOmhpZGRlbicpKSB7XG4gICAgICAgICAgRm91bmRhdGlvbi5Nb3Rpb24uYW5pbWF0ZUluKHRoaXMuJHRhcmdldE1lbnUsIHRoaXMuYW5pbWF0aW9uSW4sICgpID0+IHtcbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogRmlyZXMgd2hlbiB0aGUgZWxlbWVudCBhdHRhY2hlZCB0byB0aGUgdGFiIGJhciB0b2dnbGVzLlxuICAgICAgICAgICAgICogQGV2ZW50IFJlc3BvbnNpdmVUb2dnbGUjdG9nZ2xlZFxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ3RvZ2dsZWQuemYucmVzcG9uc2l2ZVRvZ2dsZScpO1xuICAgICAgICAgICAgdGhpcy4kdGFyZ2V0TWVudS5maW5kKCdbZGF0YS1tdXRhdGVdJykudHJpZ2dlckhhbmRsZXIoJ211dGF0ZW1lLnpmLnRyaWdnZXInKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICBGb3VuZGF0aW9uLk1vdGlvbi5hbmltYXRlT3V0KHRoaXMuJHRhcmdldE1lbnUsIHRoaXMuYW5pbWF0aW9uT3V0LCAoKSA9PiB7XG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIEZpcmVzIHdoZW4gdGhlIGVsZW1lbnQgYXR0YWNoZWQgdG8gdGhlIHRhYiBiYXIgdG9nZ2xlcy5cbiAgICAgICAgICAgICAqIEBldmVudCBSZXNwb25zaXZlVG9nZ2xlI3RvZ2dsZWRcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgdGhpcy4kZWxlbWVudC50cmlnZ2VyKCd0b2dnbGVkLnpmLnJlc3BvbnNpdmVUb2dnbGUnKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgIHRoaXMuJHRhcmdldE1lbnUudG9nZ2xlKDApO1xuICAgICAgICB0aGlzLiR0YXJnZXRNZW51LmZpbmQoJ1tkYXRhLW11dGF0ZV0nKS50cmlnZ2VyKCdtdXRhdGVtZS56Zi50cmlnZ2VyJyk7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEZpcmVzIHdoZW4gdGhlIGVsZW1lbnQgYXR0YWNoZWQgdG8gdGhlIHRhYiBiYXIgdG9nZ2xlcy5cbiAgICAgICAgICogQGV2ZW50IFJlc3BvbnNpdmVUb2dnbGUjdG9nZ2xlZFxuICAgICAgICAgKi9cbiAgICAgICAgdGhpcy4kZWxlbWVudC50cmlnZ2VyKCd0b2dnbGVkLnpmLnJlc3BvbnNpdmVUb2dnbGUnKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLiRlbGVtZW50Lm9mZignLnpmLnJlc3BvbnNpdmVUb2dnbGUnKTtcbiAgICB0aGlzLiR0b2dnbGVyLm9mZignLnpmLnJlc3BvbnNpdmVUb2dnbGUnKTtcblxuICAgICQod2luZG93KS5vZmYoJ2NoYW5nZWQuemYubWVkaWFxdWVyeScsIHRoaXMuX3VwZGF0ZU1xSGFuZGxlcik7XG5cbiAgICBGb3VuZGF0aW9uLnVucmVnaXN0ZXJQbHVnaW4odGhpcyk7XG4gIH1cbn1cblxuUmVzcG9uc2l2ZVRvZ2dsZS5kZWZhdWx0cyA9IHtcbiAgLyoqXG4gICAqIFRoZSBicmVha3BvaW50IGFmdGVyIHdoaWNoIHRoZSBtZW51IGlzIGFsd2F5cyBzaG93biwgYW5kIHRoZSB0YWIgYmFyIGlzIGhpZGRlbi5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnbWVkaXVtJ1xuICAgKi9cbiAgaGlkZUZvcjogJ21lZGl1bScsXG5cbiAgLyoqXG4gICAqIFRvIGRlY2lkZSBpZiB0aGUgdG9nZ2xlIHNob3VsZCBiZSBhbmltYXRlZCBvciBub3QuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgZmFsc2VcbiAgICovXG4gIGFuaW1hdGU6IGZhbHNlXG59O1xuXG4vLyBXaW5kb3cgZXhwb3J0c1xuRm91bmRhdGlvbi5wbHVnaW4oUmVzcG9uc2l2ZVRvZ2dsZSwgJ1Jlc3BvbnNpdmVUb2dnbGUnKTtcblxufShqUXVlcnkpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4hZnVuY3Rpb24oJCkge1xuXG4vKipcbiAqIFRvZ2dsZXIgbW9kdWxlLlxuICogQG1vZHVsZSBmb3VuZGF0aW9uLnRvZ2dsZXJcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwubW90aW9uXG4gKiBAcmVxdWlyZXMgZm91bmRhdGlvbi51dGlsLnRyaWdnZXJzXG4gKi9cblxuY2xhc3MgVG9nZ2xlciB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IGluc3RhbmNlIG9mIFRvZ2dsZXIuXG4gICAqIEBjbGFzc1xuICAgKiBAZmlyZXMgVG9nZ2xlciNpbml0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSBlbGVtZW50IC0galF1ZXJ5IG9iamVjdCB0byBhZGQgdGhlIHRyaWdnZXIgdG8uXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zIC0gT3ZlcnJpZGVzIHRvIHRoZSBkZWZhdWx0IHBsdWdpbiBzZXR0aW5ncy5cbiAgICovXG4gIGNvbnN0cnVjdG9yKGVsZW1lbnQsIG9wdGlvbnMpIHtcbiAgICB0aGlzLiRlbGVtZW50ID0gZWxlbWVudDtcbiAgICB0aGlzLm9wdGlvbnMgPSAkLmV4dGVuZCh7fSwgVG9nZ2xlci5kZWZhdWx0cywgZWxlbWVudC5kYXRhKCksIG9wdGlvbnMpO1xuICAgIHRoaXMuY2xhc3NOYW1lID0gJyc7XG5cbiAgICB0aGlzLl9pbml0KCk7XG4gICAgdGhpcy5fZXZlbnRzKCk7XG5cbiAgICBGb3VuZGF0aW9uLnJlZ2lzdGVyUGx1Z2luKHRoaXMsICdUb2dnbGVyJyk7XG4gIH1cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgdGhlIFRvZ2dsZXIgcGx1Z2luIGJ5IHBhcnNpbmcgdGhlIHRvZ2dsZSBjbGFzcyBmcm9tIGRhdGEtdG9nZ2xlciwgb3IgYW5pbWF0aW9uIGNsYXNzZXMgZnJvbSBkYXRhLWFuaW1hdGUuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2luaXQoKSB7XG4gICAgdmFyIGlucHV0O1xuICAgIC8vIFBhcnNlIGFuaW1hdGlvbiBjbGFzc2VzIGlmIHRoZXkgd2VyZSBzZXRcbiAgICBpZiAodGhpcy5vcHRpb25zLmFuaW1hdGUpIHtcbiAgICAgIGlucHV0ID0gdGhpcy5vcHRpb25zLmFuaW1hdGUuc3BsaXQoJyAnKTtcblxuICAgICAgdGhpcy5hbmltYXRpb25JbiA9IGlucHV0WzBdO1xuICAgICAgdGhpcy5hbmltYXRpb25PdXQgPSBpbnB1dFsxXSB8fCBudWxsO1xuICAgIH1cbiAgICAvLyBPdGhlcndpc2UsIHBhcnNlIHRvZ2dsZSBjbGFzc1xuICAgIGVsc2Uge1xuICAgICAgaW5wdXQgPSB0aGlzLiRlbGVtZW50LmRhdGEoJ3RvZ2dsZXInKTtcbiAgICAgIC8vIEFsbG93IGZvciBhIC4gYXQgdGhlIGJlZ2lubmluZyBvZiB0aGUgc3RyaW5nXG4gICAgICB0aGlzLmNsYXNzTmFtZSA9IGlucHV0WzBdID09PSAnLicgPyBpbnB1dC5zbGljZSgxKSA6IGlucHV0O1xuICAgIH1cblxuICAgIC8vIEFkZCBBUklBIGF0dHJpYnV0ZXMgdG8gdHJpZ2dlcnNcbiAgICB2YXIgaWQgPSB0aGlzLiRlbGVtZW50WzBdLmlkO1xuICAgICQoYFtkYXRhLW9wZW49XCIke2lkfVwiXSwgW2RhdGEtY2xvc2U9XCIke2lkfVwiXSwgW2RhdGEtdG9nZ2xlPVwiJHtpZH1cIl1gKVxuICAgICAgLmF0dHIoJ2FyaWEtY29udHJvbHMnLCBpZCk7XG4gICAgLy8gSWYgdGhlIHRhcmdldCBpcyBoaWRkZW4sIGFkZCBhcmlhLWhpZGRlblxuICAgIHRoaXMuJGVsZW1lbnQuYXR0cignYXJpYS1leHBhbmRlZCcsIHRoaXMuJGVsZW1lbnQuaXMoJzpoaWRkZW4nKSA/IGZhbHNlIDogdHJ1ZSk7XG4gIH1cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgZXZlbnRzIGZvciB0aGUgdG9nZ2xlIHRyaWdnZXIuXG4gICAqIEBmdW5jdGlvblxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2V2ZW50cygpIHtcbiAgICB0aGlzLiRlbGVtZW50Lm9mZigndG9nZ2xlLnpmLnRyaWdnZXInKS5vbigndG9nZ2xlLnpmLnRyaWdnZXInLCB0aGlzLnRvZ2dsZS5iaW5kKHRoaXMpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUb2dnbGVzIHRoZSB0YXJnZXQgY2xhc3Mgb24gdGhlIHRhcmdldCBlbGVtZW50LiBBbiBldmVudCBpcyBmaXJlZCBmcm9tIHRoZSBvcmlnaW5hbCB0cmlnZ2VyIGRlcGVuZGluZyBvbiBpZiB0aGUgcmVzdWx0YW50IHN0YXRlIHdhcyBcIm9uXCIgb3IgXCJvZmZcIi5cbiAgICogQGZ1bmN0aW9uXG4gICAqIEBmaXJlcyBUb2dnbGVyI29uXG4gICAqIEBmaXJlcyBUb2dnbGVyI29mZlxuICAgKi9cbiAgdG9nZ2xlKCkge1xuICAgIHRoaXNbIHRoaXMub3B0aW9ucy5hbmltYXRlID8gJ190b2dnbGVBbmltYXRlJyA6ICdfdG9nZ2xlQ2xhc3MnXSgpO1xuICB9XG5cbiAgX3RvZ2dsZUNsYXNzKCkge1xuICAgIHRoaXMuJGVsZW1lbnQudG9nZ2xlQ2xhc3ModGhpcy5jbGFzc05hbWUpO1xuXG4gICAgdmFyIGlzT24gPSB0aGlzLiRlbGVtZW50Lmhhc0NsYXNzKHRoaXMuY2xhc3NOYW1lKTtcbiAgICBpZiAoaXNPbikge1xuICAgICAgLyoqXG4gICAgICAgKiBGaXJlcyBpZiB0aGUgdGFyZ2V0IGVsZW1lbnQgaGFzIHRoZSBjbGFzcyBhZnRlciBhIHRvZ2dsZS5cbiAgICAgICAqIEBldmVudCBUb2dnbGVyI29uXG4gICAgICAgKi9cbiAgICAgIHRoaXMuJGVsZW1lbnQudHJpZ2dlcignb24uemYudG9nZ2xlcicpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIC8qKlxuICAgICAgICogRmlyZXMgaWYgdGhlIHRhcmdldCBlbGVtZW50IGRvZXMgbm90IGhhdmUgdGhlIGNsYXNzIGFmdGVyIGEgdG9nZ2xlLlxuICAgICAgICogQGV2ZW50IFRvZ2dsZXIjb2ZmXG4gICAgICAgKi9cbiAgICAgIHRoaXMuJGVsZW1lbnQudHJpZ2dlcignb2ZmLnpmLnRvZ2dsZXInKTtcbiAgICB9XG5cbiAgICB0aGlzLl91cGRhdGVBUklBKGlzT24pO1xuICAgIHRoaXMuJGVsZW1lbnQuZmluZCgnW2RhdGEtbXV0YXRlXScpLnRyaWdnZXIoJ211dGF0ZW1lLnpmLnRyaWdnZXInKTtcbiAgfVxuXG4gIF90b2dnbGVBbmltYXRlKCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICBpZiAodGhpcy4kZWxlbWVudC5pcygnOmhpZGRlbicpKSB7XG4gICAgICBGb3VuZGF0aW9uLk1vdGlvbi5hbmltYXRlSW4odGhpcy4kZWxlbWVudCwgdGhpcy5hbmltYXRpb25JbiwgZnVuY3Rpb24oKSB7XG4gICAgICAgIF90aGlzLl91cGRhdGVBUklBKHRydWUpO1xuICAgICAgICB0aGlzLnRyaWdnZXIoJ29uLnpmLnRvZ2dsZXInKTtcbiAgICAgICAgdGhpcy5maW5kKCdbZGF0YS1tdXRhdGVdJykudHJpZ2dlcignbXV0YXRlbWUuemYudHJpZ2dlcicpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgRm91bmRhdGlvbi5Nb3Rpb24uYW5pbWF0ZU91dCh0aGlzLiRlbGVtZW50LCB0aGlzLmFuaW1hdGlvbk91dCwgZnVuY3Rpb24oKSB7XG4gICAgICAgIF90aGlzLl91cGRhdGVBUklBKGZhbHNlKTtcbiAgICAgICAgdGhpcy50cmlnZ2VyKCdvZmYuemYudG9nZ2xlcicpO1xuICAgICAgICB0aGlzLmZpbmQoJ1tkYXRhLW11dGF0ZV0nKS50cmlnZ2VyKCdtdXRhdGVtZS56Zi50cmlnZ2VyJyk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICBfdXBkYXRlQVJJQShpc09uKSB7XG4gICAgdGhpcy4kZWxlbWVudC5hdHRyKCdhcmlhLWV4cGFuZGVkJywgaXNPbiA/IHRydWUgOiBmYWxzZSk7XG4gIH1cblxuICAvKipcbiAgICogRGVzdHJveXMgdGhlIGluc3RhbmNlIG9mIFRvZ2dsZXIgb24gdGhlIGVsZW1lbnQuXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLiRlbGVtZW50Lm9mZignLnpmLnRvZ2dsZXInKTtcbiAgICBGb3VuZGF0aW9uLnVucmVnaXN0ZXJQbHVnaW4odGhpcyk7XG4gIH1cbn1cblxuVG9nZ2xlci5kZWZhdWx0cyA9IHtcbiAgLyoqXG4gICAqIFRlbGxzIHRoZSBwbHVnaW4gaWYgdGhlIGVsZW1lbnQgc2hvdWxkIGFuaW1hdGVkIHdoZW4gdG9nZ2xlZC5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSBmYWxzZVxuICAgKi9cbiAgYW5pbWF0ZTogZmFsc2Vcbn07XG5cbi8vIFdpbmRvdyBleHBvcnRzXG5Gb3VuZGF0aW9uLnBsdWdpbihUb2dnbGVyLCAnVG9nZ2xlcicpO1xuXG59KGpRdWVyeSk7XG4iLCIndXNlIHN0cmljdCc7XG5cbiFmdW5jdGlvbigkKSB7XG5cbi8qKlxuICogVG9vbHRpcCBtb2R1bGUuXG4gKiBAbW9kdWxlIGZvdW5kYXRpb24udG9vbHRpcFxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC5ib3hcbiAqIEByZXF1aXJlcyBmb3VuZGF0aW9uLnV0aWwubWVkaWFRdWVyeVxuICogQHJlcXVpcmVzIGZvdW5kYXRpb24udXRpbC50cmlnZ2Vyc1xuICovXG5cbmNsYXNzIFRvb2x0aXAge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBpbnN0YW5jZSBvZiBhIFRvb2x0aXAuXG4gICAqIEBjbGFzc1xuICAgKiBAZmlyZXMgVG9vbHRpcCNpbml0XG4gICAqIEBwYXJhbSB7alF1ZXJ5fSBlbGVtZW50IC0galF1ZXJ5IG9iamVjdCB0byBhdHRhY2ggYSB0b29sdGlwIHRvLlxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyAtIG9iamVjdCB0byBleHRlbmQgdGhlIGRlZmF1bHQgY29uZmlndXJhdGlvbi5cbiAgICovXG4gIGNvbnN0cnVjdG9yKGVsZW1lbnQsIG9wdGlvbnMpIHtcbiAgICB0aGlzLiRlbGVtZW50ID0gZWxlbWVudDtcbiAgICB0aGlzLm9wdGlvbnMgPSAkLmV4dGVuZCh7fSwgVG9vbHRpcC5kZWZhdWx0cywgdGhpcy4kZWxlbWVudC5kYXRhKCksIG9wdGlvbnMpO1xuXG4gICAgdGhpcy5pc0FjdGl2ZSA9IGZhbHNlO1xuICAgIHRoaXMuaXNDbGljayA9IGZhbHNlO1xuICAgIHRoaXMuX2luaXQoKTtcblxuICAgIEZvdW5kYXRpb24ucmVnaXN0ZXJQbHVnaW4odGhpcywgJ1Rvb2x0aXAnKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyB0aGUgdG9vbHRpcCBieSBzZXR0aW5nIHRoZSBjcmVhdGluZyB0aGUgdGlwIGVsZW1lbnQsIGFkZGluZyBpdCdzIHRleHQsIHNldHRpbmcgcHJpdmF0ZSB2YXJpYWJsZXMgYW5kIHNldHRpbmcgYXR0cmlidXRlcyBvbiB0aGUgYW5jaG9yLlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2luaXQoKSB7XG4gICAgdmFyIGVsZW1JZCA9IHRoaXMuJGVsZW1lbnQuYXR0cignYXJpYS1kZXNjcmliZWRieScpIHx8IEZvdW5kYXRpb24uR2V0WW9EaWdpdHMoNiwgJ3Rvb2x0aXAnKTtcblxuICAgIHRoaXMub3B0aW9ucy5wb3NpdGlvbkNsYXNzID0gdGhpcy5vcHRpb25zLnBvc2l0aW9uQ2xhc3MgfHwgdGhpcy5fZ2V0UG9zaXRpb25DbGFzcyh0aGlzLiRlbGVtZW50KTtcbiAgICB0aGlzLm9wdGlvbnMudGlwVGV4dCA9IHRoaXMub3B0aW9ucy50aXBUZXh0IHx8IHRoaXMuJGVsZW1lbnQuYXR0cigndGl0bGUnKTtcbiAgICB0aGlzLnRlbXBsYXRlID0gdGhpcy5vcHRpb25zLnRlbXBsYXRlID8gJCh0aGlzLm9wdGlvbnMudGVtcGxhdGUpIDogdGhpcy5fYnVpbGRUZW1wbGF0ZShlbGVtSWQpO1xuXG4gICAgaWYgKHRoaXMub3B0aW9ucy5hbGxvd0h0bWwpIHtcbiAgICAgIHRoaXMudGVtcGxhdGUuYXBwZW5kVG8oZG9jdW1lbnQuYm9keSlcbiAgICAgICAgLmh0bWwodGhpcy5vcHRpb25zLnRpcFRleHQpXG4gICAgICAgIC5oaWRlKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMudGVtcGxhdGUuYXBwZW5kVG8oZG9jdW1lbnQuYm9keSlcbiAgICAgICAgLnRleHQodGhpcy5vcHRpb25zLnRpcFRleHQpXG4gICAgICAgIC5oaWRlKCk7XG4gICAgfVxuXG4gICAgdGhpcy4kZWxlbWVudC5hdHRyKHtcbiAgICAgICd0aXRsZSc6ICcnLFxuICAgICAgJ2FyaWEtZGVzY3JpYmVkYnknOiBlbGVtSWQsXG4gICAgICAnZGF0YS15ZXRpLWJveCc6IGVsZW1JZCxcbiAgICAgICdkYXRhLXRvZ2dsZSc6IGVsZW1JZCxcbiAgICAgICdkYXRhLXJlc2l6ZSc6IGVsZW1JZFxuICAgIH0pLmFkZENsYXNzKHRoaXMub3B0aW9ucy50cmlnZ2VyQ2xhc3MpO1xuXG4gICAgLy9oZWxwZXIgdmFyaWFibGVzIHRvIHRyYWNrIG1vdmVtZW50IG9uIGNvbGxpc2lvbnNcbiAgICB0aGlzLnVzZWRQb3NpdGlvbnMgPSBbXTtcbiAgICB0aGlzLmNvdW50ZXIgPSA0O1xuICAgIHRoaXMuY2xhc3NDaGFuZ2VkID0gZmFsc2U7XG5cbiAgICB0aGlzLl9ldmVudHMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHcmFicyB0aGUgY3VycmVudCBwb3NpdGlvbmluZyBjbGFzcywgaWYgcHJlc2VudCwgYW5kIHJldHVybnMgdGhlIHZhbHVlIG9yIGFuIGVtcHR5IHN0cmluZy5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9nZXRQb3NpdGlvbkNsYXNzKGVsZW1lbnQpIHtcbiAgICBpZiAoIWVsZW1lbnQpIHsgcmV0dXJuICcnOyB9XG4gICAgLy8gdmFyIHBvc2l0aW9uID0gZWxlbWVudC5hdHRyKCdjbGFzcycpLm1hdGNoKC90b3B8bGVmdHxyaWdodC9nKTtcbiAgICB2YXIgcG9zaXRpb24gPSBlbGVtZW50WzBdLmNsYXNzTmFtZS5tYXRjaCgvXFxiKHRvcHxsZWZ0fHJpZ2h0KVxcYi9nKTtcbiAgICAgICAgcG9zaXRpb24gPSBwb3NpdGlvbiA/IHBvc2l0aW9uWzBdIDogJyc7XG4gICAgcmV0dXJuIHBvc2l0aW9uO1xuICB9O1xuICAvKipcbiAgICogYnVpbGRzIHRoZSB0b29sdGlwIGVsZW1lbnQsIGFkZHMgYXR0cmlidXRlcywgYW5kIHJldHVybnMgdGhlIHRlbXBsYXRlLlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2J1aWxkVGVtcGxhdGUoaWQpIHtcbiAgICB2YXIgdGVtcGxhdGVDbGFzc2VzID0gKGAke3RoaXMub3B0aW9ucy50b29sdGlwQ2xhc3N9ICR7dGhpcy5vcHRpb25zLnBvc2l0aW9uQ2xhc3N9ICR7dGhpcy5vcHRpb25zLnRlbXBsYXRlQ2xhc3Nlc31gKS50cmltKCk7XG4gICAgdmFyICR0ZW1wbGF0ZSA9ICAkKCc8ZGl2PjwvZGl2PicpLmFkZENsYXNzKHRlbXBsYXRlQ2xhc3NlcykuYXR0cih7XG4gICAgICAncm9sZSc6ICd0b29sdGlwJyxcbiAgICAgICdhcmlhLWhpZGRlbic6IHRydWUsXG4gICAgICAnZGF0YS1pcy1hY3RpdmUnOiBmYWxzZSxcbiAgICAgICdkYXRhLWlzLWZvY3VzJzogZmFsc2UsXG4gICAgICAnaWQnOiBpZFxuICAgIH0pO1xuICAgIHJldHVybiAkdGVtcGxhdGU7XG4gIH1cblxuICAvKipcbiAgICogRnVuY3Rpb24gdGhhdCBnZXRzIGNhbGxlZCBpZiBhIGNvbGxpc2lvbiBldmVudCBpcyBkZXRlY3RlZC5cbiAgICogQHBhcmFtIHtTdHJpbmd9IHBvc2l0aW9uIC0gcG9zaXRpb25pbmcgY2xhc3MgdG8gdHJ5XG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfcmVwb3NpdGlvbihwb3NpdGlvbikge1xuICAgIHRoaXMudXNlZFBvc2l0aW9ucy5wdXNoKHBvc2l0aW9uID8gcG9zaXRpb24gOiAnYm90dG9tJyk7XG5cbiAgICAvL2RlZmF1bHQsIHRyeSBzd2l0Y2hpbmcgdG8gb3Bwb3NpdGUgc2lkZVxuICAgIGlmICghcG9zaXRpb24gJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCd0b3AnKSA8IDApKSB7XG4gICAgICB0aGlzLnRlbXBsYXRlLmFkZENsYXNzKCd0b3AnKTtcbiAgICB9IGVsc2UgaWYgKHBvc2l0aW9uID09PSAndG9wJyAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2JvdHRvbScpIDwgMCkpIHtcbiAgICAgIHRoaXMudGVtcGxhdGUucmVtb3ZlQ2xhc3MocG9zaXRpb24pO1xuICAgIH0gZWxzZSBpZiAocG9zaXRpb24gPT09ICdsZWZ0JyAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ3JpZ2h0JykgPCAwKSkge1xuICAgICAgdGhpcy50ZW1wbGF0ZS5yZW1vdmVDbGFzcyhwb3NpdGlvbilcbiAgICAgICAgICAuYWRkQ2xhc3MoJ3JpZ2h0Jyk7XG4gICAgfSBlbHNlIGlmIChwb3NpdGlvbiA9PT0gJ3JpZ2h0JyAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2xlZnQnKSA8IDApKSB7XG4gICAgICB0aGlzLnRlbXBsYXRlLnJlbW92ZUNsYXNzKHBvc2l0aW9uKVxuICAgICAgICAgIC5hZGRDbGFzcygnbGVmdCcpO1xuICAgIH1cblxuICAgIC8vaWYgZGVmYXVsdCBjaGFuZ2UgZGlkbid0IHdvcmssIHRyeSBib3R0b20gb3IgbGVmdCBmaXJzdFxuICAgIGVsc2UgaWYgKCFwb3NpdGlvbiAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ3RvcCcpID4gLTEpICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZignbGVmdCcpIDwgMCkpIHtcbiAgICAgIHRoaXMudGVtcGxhdGUuYWRkQ2xhc3MoJ2xlZnQnKTtcbiAgICB9IGVsc2UgaWYgKHBvc2l0aW9uID09PSAndG9wJyAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2JvdHRvbScpID4gLTEpICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZignbGVmdCcpIDwgMCkpIHtcbiAgICAgIHRoaXMudGVtcGxhdGUucmVtb3ZlQ2xhc3MocG9zaXRpb24pXG4gICAgICAgICAgLmFkZENsYXNzKCdsZWZ0Jyk7XG4gICAgfSBlbHNlIGlmIChwb3NpdGlvbiA9PT0gJ2xlZnQnICYmICh0aGlzLnVzZWRQb3NpdGlvbnMuaW5kZXhPZigncmlnaHQnKSA+IC0xKSAmJiAodGhpcy51c2VkUG9zaXRpb25zLmluZGV4T2YoJ2JvdHRvbScpIDwgMCkpIHtcbiAgICAgIHRoaXMudGVtcGxhdGUucmVtb3ZlQ2xhc3MocG9zaXRpb24pO1xuICAgIH0gZWxzZSBpZiAocG9zaXRpb24gPT09ICdyaWdodCcgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdsZWZ0JykgPiAtMSkgJiYgKHRoaXMudXNlZFBvc2l0aW9ucy5pbmRleE9mKCdib3R0b20nKSA8IDApKSB7XG4gICAgICB0aGlzLnRlbXBsYXRlLnJlbW92ZUNsYXNzKHBvc2l0aW9uKTtcbiAgICB9XG4gICAgLy9pZiBub3RoaW5nIGNsZWFyZWQsIHNldCB0byBib3R0b21cbiAgICBlbHNlIHtcbiAgICAgIHRoaXMudGVtcGxhdGUucmVtb3ZlQ2xhc3MocG9zaXRpb24pO1xuICAgIH1cbiAgICB0aGlzLmNsYXNzQ2hhbmdlZCA9IHRydWU7XG4gICAgdGhpcy5jb3VudGVyLS07XG4gIH1cblxuICAvKipcbiAgICogc2V0cyB0aGUgcG9zaXRpb24gY2xhc3Mgb2YgYW4gZWxlbWVudCBhbmQgcmVjdXJzaXZlbHkgY2FsbHMgaXRzZWxmIHVudGlsIHRoZXJlIGFyZSBubyBtb3JlIHBvc3NpYmxlIHBvc2l0aW9ucyB0byBhdHRlbXB0LCBvciB0aGUgdG9vbHRpcCBlbGVtZW50IGlzIG5vIGxvbmdlciBjb2xsaWRpbmcuXG4gICAqIGlmIHRoZSB0b29sdGlwIGlzIGxhcmdlciB0aGFuIHRoZSBzY3JlZW4gd2lkdGgsIGRlZmF1bHQgdG8gZnVsbCB3aWR0aCAtIGFueSB1c2VyIHNlbGVjdGVkIG1hcmdpblxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX3NldFBvc2l0aW9uKCkge1xuICAgIHZhciBwb3NpdGlvbiA9IHRoaXMuX2dldFBvc2l0aW9uQ2xhc3ModGhpcy50ZW1wbGF0ZSksXG4gICAgICAgICR0aXBEaW1zID0gRm91bmRhdGlvbi5Cb3guR2V0RGltZW5zaW9ucyh0aGlzLnRlbXBsYXRlKSxcbiAgICAgICAgJGFuY2hvckRpbXMgPSBGb3VuZGF0aW9uLkJveC5HZXREaW1lbnNpb25zKHRoaXMuJGVsZW1lbnQpLFxuICAgICAgICBkaXJlY3Rpb24gPSAocG9zaXRpb24gPT09ICdsZWZ0JyA/ICdsZWZ0JyA6ICgocG9zaXRpb24gPT09ICdyaWdodCcpID8gJ2xlZnQnIDogJ3RvcCcpKSxcbiAgICAgICAgcGFyYW0gPSAoZGlyZWN0aW9uID09PSAndG9wJykgPyAnaGVpZ2h0JyA6ICd3aWR0aCcsXG4gICAgICAgIG9mZnNldCA9IChwYXJhbSA9PT0gJ2hlaWdodCcpID8gdGhpcy5vcHRpb25zLnZPZmZzZXQgOiB0aGlzLm9wdGlvbnMuaE9mZnNldCxcbiAgICAgICAgX3RoaXMgPSB0aGlzO1xuXG4gICAgaWYgKCgkdGlwRGltcy53aWR0aCA+PSAkdGlwRGltcy53aW5kb3dEaW1zLndpZHRoKSB8fCAoIXRoaXMuY291bnRlciAmJiAhRm91bmRhdGlvbi5Cb3guSW1Ob3RUb3VjaGluZ1lvdSh0aGlzLnRlbXBsYXRlKSkpIHtcbiAgICAgIHRoaXMudGVtcGxhdGUub2Zmc2V0KEZvdW5kYXRpb24uQm94LkdldE9mZnNldHModGhpcy50ZW1wbGF0ZSwgdGhpcy4kZWxlbWVudCwgJ2NlbnRlciBib3R0b20nLCB0aGlzLm9wdGlvbnMudk9mZnNldCwgdGhpcy5vcHRpb25zLmhPZmZzZXQsIHRydWUpKS5jc3Moe1xuICAgICAgLy8gdGhpcy4kZWxlbWVudC5vZmZzZXQoRm91bmRhdGlvbi5HZXRPZmZzZXRzKHRoaXMudGVtcGxhdGUsIHRoaXMuJGVsZW1lbnQsICdjZW50ZXIgYm90dG9tJywgdGhpcy5vcHRpb25zLnZPZmZzZXQsIHRoaXMub3B0aW9ucy5oT2Zmc2V0LCB0cnVlKSkuY3NzKHtcbiAgICAgICAgJ3dpZHRoJzogJGFuY2hvckRpbXMud2luZG93RGltcy53aWR0aCAtICh0aGlzLm9wdGlvbnMuaE9mZnNldCAqIDIpLFxuICAgICAgICAnaGVpZ2h0JzogJ2F1dG8nXG4gICAgICB9KTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICB0aGlzLnRlbXBsYXRlLm9mZnNldChGb3VuZGF0aW9uLkJveC5HZXRPZmZzZXRzKHRoaXMudGVtcGxhdGUsIHRoaXMuJGVsZW1lbnQsJ2NlbnRlciAnICsgKHBvc2l0aW9uIHx8ICdib3R0b20nKSwgdGhpcy5vcHRpb25zLnZPZmZzZXQsIHRoaXMub3B0aW9ucy5oT2Zmc2V0KSk7XG5cbiAgICB3aGlsZSghRm91bmRhdGlvbi5Cb3guSW1Ob3RUb3VjaGluZ1lvdSh0aGlzLnRlbXBsYXRlKSAmJiB0aGlzLmNvdW50ZXIpIHtcbiAgICAgIHRoaXMuX3JlcG9zaXRpb24ocG9zaXRpb24pO1xuICAgICAgdGhpcy5fc2V0UG9zaXRpb24oKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogcmV2ZWFscyB0aGUgdG9vbHRpcCwgYW5kIGZpcmVzIGFuIGV2ZW50IHRvIGNsb3NlIGFueSBvdGhlciBvcGVuIHRvb2x0aXBzIG9uIHRoZSBwYWdlXG4gICAqIEBmaXJlcyBUb29sdGlwI2Nsb3NlbWVcbiAgICogQGZpcmVzIFRvb2x0aXAjc2hvd1xuICAgKiBAZnVuY3Rpb25cbiAgICovXG4gIHNob3coKSB7XG4gICAgaWYgKHRoaXMub3B0aW9ucy5zaG93T24gIT09ICdhbGwnICYmICFGb3VuZGF0aW9uLk1lZGlhUXVlcnkuaXModGhpcy5vcHRpb25zLnNob3dPbikpIHtcbiAgICAgIC8vIGNvbnNvbGUuZXJyb3IoJ1RoZSBzY3JlZW4gaXMgdG9vIHNtYWxsIHRvIGRpc3BsYXkgdGhpcyB0b29sdGlwJyk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgdmFyIF90aGlzID0gdGhpcztcbiAgICB0aGlzLnRlbXBsYXRlLmNzcygndmlzaWJpbGl0eScsICdoaWRkZW4nKS5zaG93KCk7XG4gICAgdGhpcy5fc2V0UG9zaXRpb24oKTtcblxuICAgIC8qKlxuICAgICAqIEZpcmVzIHRvIGNsb3NlIGFsbCBvdGhlciBvcGVuIHRvb2x0aXBzIG9uIHRoZSBwYWdlXG4gICAgICogQGV2ZW50IENsb3NlbWUjdG9vbHRpcFxuICAgICAqL1xuICAgIHRoaXMuJGVsZW1lbnQudHJpZ2dlcignY2xvc2VtZS56Zi50b29sdGlwJywgdGhpcy50ZW1wbGF0ZS5hdHRyKCdpZCcpKTtcblxuXG4gICAgdGhpcy50ZW1wbGF0ZS5hdHRyKHtcbiAgICAgICdkYXRhLWlzLWFjdGl2ZSc6IHRydWUsXG4gICAgICAnYXJpYS1oaWRkZW4nOiBmYWxzZVxuICAgIH0pO1xuICAgIF90aGlzLmlzQWN0aXZlID0gdHJ1ZTtcbiAgICAvLyBjb25zb2xlLmxvZyh0aGlzLnRlbXBsYXRlKTtcbiAgICB0aGlzLnRlbXBsYXRlLnN0b3AoKS5oaWRlKCkuY3NzKCd2aXNpYmlsaXR5JywgJycpLmZhZGVJbih0aGlzLm9wdGlvbnMuZmFkZUluRHVyYXRpb24sIGZ1bmN0aW9uKCkge1xuICAgICAgLy9tYXliZSBkbyBzdHVmZj9cbiAgICB9KTtcbiAgICAvKipcbiAgICAgKiBGaXJlcyB3aGVuIHRoZSB0b29sdGlwIGlzIHNob3duXG4gICAgICogQGV2ZW50IFRvb2x0aXAjc2hvd1xuICAgICAqL1xuICAgIHRoaXMuJGVsZW1lbnQudHJpZ2dlcignc2hvdy56Zi50b29sdGlwJyk7XG4gIH1cblxuICAvKipcbiAgICogSGlkZXMgdGhlIGN1cnJlbnQgdG9vbHRpcCwgYW5kIHJlc2V0cyB0aGUgcG9zaXRpb25pbmcgY2xhc3MgaWYgaXQgd2FzIGNoYW5nZWQgZHVlIHRvIGNvbGxpc2lvblxuICAgKiBAZmlyZXMgVG9vbHRpcCNoaWRlXG4gICAqIEBmdW5jdGlvblxuICAgKi9cbiAgaGlkZSgpIHtcbiAgICAvLyBjb25zb2xlLmxvZygnaGlkaW5nJywgdGhpcy4kZWxlbWVudC5kYXRhKCd5ZXRpLWJveCcpKTtcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgIHRoaXMudGVtcGxhdGUuc3RvcCgpLmF0dHIoe1xuICAgICAgJ2FyaWEtaGlkZGVuJzogdHJ1ZSxcbiAgICAgICdkYXRhLWlzLWFjdGl2ZSc6IGZhbHNlXG4gICAgfSkuZmFkZU91dCh0aGlzLm9wdGlvbnMuZmFkZU91dER1cmF0aW9uLCBmdW5jdGlvbigpIHtcbiAgICAgIF90aGlzLmlzQWN0aXZlID0gZmFsc2U7XG4gICAgICBfdGhpcy5pc0NsaWNrID0gZmFsc2U7XG4gICAgICBpZiAoX3RoaXMuY2xhc3NDaGFuZ2VkKSB7XG4gICAgICAgIF90aGlzLnRlbXBsYXRlXG4gICAgICAgICAgICAgLnJlbW92ZUNsYXNzKF90aGlzLl9nZXRQb3NpdGlvbkNsYXNzKF90aGlzLnRlbXBsYXRlKSlcbiAgICAgICAgICAgICAuYWRkQ2xhc3MoX3RoaXMub3B0aW9ucy5wb3NpdGlvbkNsYXNzKTtcblxuICAgICAgIF90aGlzLnVzZWRQb3NpdGlvbnMgPSBbXTtcbiAgICAgICBfdGhpcy5jb3VudGVyID0gNDtcbiAgICAgICBfdGhpcy5jbGFzc0NoYW5nZWQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICAvKipcbiAgICAgKiBmaXJlcyB3aGVuIHRoZSB0b29sdGlwIGlzIGhpZGRlblxuICAgICAqIEBldmVudCBUb29sdGlwI2hpZGVcbiAgICAgKi9cbiAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoJ2hpZGUuemYudG9vbHRpcCcpO1xuICB9XG5cbiAgLyoqXG4gICAqIGFkZHMgZXZlbnQgbGlzdGVuZXJzIGZvciB0aGUgdG9vbHRpcCBhbmQgaXRzIGFuY2hvclxuICAgKiBUT0RPIGNvbWJpbmUgc29tZSBvZiB0aGUgbGlzdGVuZXJzIGxpa2UgZm9jdXMgYW5kIG1vdXNlZW50ZXIsIGV0Yy5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9ldmVudHMoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcbiAgICB2YXIgJHRlbXBsYXRlID0gdGhpcy50ZW1wbGF0ZTtcbiAgICB2YXIgaXNGb2N1cyA9IGZhbHNlO1xuXG4gICAgaWYgKCF0aGlzLm9wdGlvbnMuZGlzYWJsZUhvdmVyKSB7XG5cbiAgICAgIHRoaXMuJGVsZW1lbnRcbiAgICAgIC5vbignbW91c2VlbnRlci56Zi50b29sdGlwJywgZnVuY3Rpb24oZSkge1xuICAgICAgICBpZiAoIV90aGlzLmlzQWN0aXZlKSB7XG4gICAgICAgICAgX3RoaXMudGltZW91dCA9IHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBfdGhpcy5zaG93KCk7XG4gICAgICAgICAgfSwgX3RoaXMub3B0aW9ucy5ob3ZlckRlbGF5KTtcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICAgIC5vbignbW91c2VsZWF2ZS56Zi50b29sdGlwJywgZnVuY3Rpb24oZSkge1xuICAgICAgICBjbGVhclRpbWVvdXQoX3RoaXMudGltZW91dCk7XG4gICAgICAgIGlmICghaXNGb2N1cyB8fCAoX3RoaXMuaXNDbGljayAmJiAhX3RoaXMub3B0aW9ucy5jbGlja09wZW4pKSB7XG4gICAgICAgICAgX3RoaXMuaGlkZSgpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcHRpb25zLmNsaWNrT3Blbikge1xuICAgICAgdGhpcy4kZWxlbWVudC5vbignbW91c2Vkb3duLnpmLnRvb2x0aXAnLCBmdW5jdGlvbihlKSB7XG4gICAgICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gICAgICAgIGlmIChfdGhpcy5pc0NsaWNrKSB7XG4gICAgICAgICAgLy9fdGhpcy5oaWRlKCk7XG4gICAgICAgICAgLy8gX3RoaXMuaXNDbGljayA9IGZhbHNlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIF90aGlzLmlzQ2xpY2sgPSB0cnVlO1xuICAgICAgICAgIGlmICgoX3RoaXMub3B0aW9ucy5kaXNhYmxlSG92ZXIgfHwgIV90aGlzLiRlbGVtZW50LmF0dHIoJ3RhYmluZGV4JykpICYmICFfdGhpcy5pc0FjdGl2ZSkge1xuICAgICAgICAgICAgX3RoaXMuc2hvdygpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuJGVsZW1lbnQub24oJ21vdXNlZG93bi56Zi50b29sdGlwJywgZnVuY3Rpb24oZSkge1xuICAgICAgICBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICAgICAgICBfdGhpcy5pc0NsaWNrID0gdHJ1ZTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGlmICghdGhpcy5vcHRpb25zLmRpc2FibGVGb3JUb3VjaCkge1xuICAgICAgdGhpcy4kZWxlbWVudFxuICAgICAgLm9uKCd0YXAuemYudG9vbHRpcCB0b3VjaGVuZC56Zi50b29sdGlwJywgZnVuY3Rpb24oZSkge1xuICAgICAgICBfdGhpcy5pc0FjdGl2ZSA/IF90aGlzLmhpZGUoKSA6IF90aGlzLnNob3coKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHRoaXMuJGVsZW1lbnQub24oe1xuICAgICAgLy8gJ3RvZ2dsZS56Zi50cmlnZ2VyJzogdGhpcy50b2dnbGUuYmluZCh0aGlzKSxcbiAgICAgIC8vICdjbG9zZS56Zi50cmlnZ2VyJzogdGhpcy5oaWRlLmJpbmQodGhpcylcbiAgICAgICdjbG9zZS56Zi50cmlnZ2VyJzogdGhpcy5oaWRlLmJpbmQodGhpcylcbiAgICB9KTtcblxuICAgIHRoaXMuJGVsZW1lbnRcbiAgICAgIC5vbignZm9jdXMuemYudG9vbHRpcCcsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgaXNGb2N1cyA9IHRydWU7XG4gICAgICAgIGlmIChfdGhpcy5pc0NsaWNrKSB7XG4gICAgICAgICAgLy8gSWYgd2UncmUgbm90IHNob3dpbmcgb3BlbiBvbiBjbGlja3MsIHdlIG5lZWQgdG8gcHJldGVuZCBhIGNsaWNrLWxhdW5jaGVkIGZvY3VzIGlzbid0XG4gICAgICAgICAgLy8gYSByZWFsIGZvY3VzLCBvdGhlcndpc2Ugb24gaG92ZXIgYW5kIGNvbWUgYmFjayB3ZSBnZXQgYmFkIGJlaGF2aW9yXG4gICAgICAgICAgaWYoIV90aGlzLm9wdGlvbnMuY2xpY2tPcGVuKSB7IGlzRm9jdXMgPSBmYWxzZTsgfVxuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBfdGhpcy5zaG93KCk7XG4gICAgICAgIH1cbiAgICAgIH0pXG5cbiAgICAgIC5vbignZm9jdXNvdXQuemYudG9vbHRpcCcsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgaXNGb2N1cyA9IGZhbHNlO1xuICAgICAgICBfdGhpcy5pc0NsaWNrID0gZmFsc2U7XG4gICAgICAgIF90aGlzLmhpZGUoKTtcbiAgICAgIH0pXG5cbiAgICAgIC5vbigncmVzaXplbWUuemYudHJpZ2dlcicsIGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAoX3RoaXMuaXNBY3RpdmUpIHtcbiAgICAgICAgICBfdGhpcy5fc2V0UG9zaXRpb24oKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogYWRkcyBhIHRvZ2dsZSBtZXRob2QsIGluIGFkZGl0aW9uIHRvIHRoZSBzdGF0aWMgc2hvdygpICYgaGlkZSgpIGZ1bmN0aW9uc1xuICAgKiBAZnVuY3Rpb25cbiAgICovXG4gIHRvZ2dsZSgpIHtcbiAgICBpZiAodGhpcy5pc0FjdGl2ZSkge1xuICAgICAgdGhpcy5oaWRlKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuc2hvdygpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBEZXN0cm95cyBhbiBpbnN0YW5jZSBvZiB0b29sdGlwLCByZW1vdmVzIHRlbXBsYXRlIGVsZW1lbnQgZnJvbSB0aGUgdmlldy5cbiAgICogQGZ1bmN0aW9uXG4gICAqL1xuICBkZXN0cm95KCkge1xuICAgIHRoaXMuJGVsZW1lbnQuYXR0cigndGl0bGUnLCB0aGlzLnRlbXBsYXRlLnRleHQoKSlcbiAgICAgICAgICAgICAgICAgLm9mZignLnpmLnRyaWdnZXIgLnpmLnRvb2x0aXAnKVxuICAgICAgICAgICAgICAgICAucmVtb3ZlQ2xhc3MoJ2hhcy10aXAgdG9wIHJpZ2h0IGxlZnQnKVxuICAgICAgICAgICAgICAgICAucmVtb3ZlQXR0cignYXJpYS1kZXNjcmliZWRieSBhcmlhLWhhc3BvcHVwIGRhdGEtZGlzYWJsZS1ob3ZlciBkYXRhLXJlc2l6ZSBkYXRhLXRvZ2dsZSBkYXRhLXRvb2x0aXAgZGF0YS15ZXRpLWJveCcpO1xuXG4gICAgdGhpcy50ZW1wbGF0ZS5yZW1vdmUoKTtcblxuICAgIEZvdW5kYXRpb24udW5yZWdpc3RlclBsdWdpbih0aGlzKTtcbiAgfVxufVxuXG5Ub29sdGlwLmRlZmF1bHRzID0ge1xuICBkaXNhYmxlRm9yVG91Y2g6IGZhbHNlLFxuICAvKipcbiAgICogVGltZSwgaW4gbXMsIGJlZm9yZSBhIHRvb2x0aXAgc2hvdWxkIG9wZW4gb24gaG92ZXIuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgMjAwXG4gICAqL1xuICBob3ZlckRlbGF5OiAyMDAsXG4gIC8qKlxuICAgKiBUaW1lLCBpbiBtcywgYSB0b29sdGlwIHNob3VsZCB0YWtlIHRvIGZhZGUgaW50byB2aWV3LlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIDE1MFxuICAgKi9cbiAgZmFkZUluRHVyYXRpb246IDE1MCxcbiAgLyoqXG4gICAqIFRpbWUsIGluIG1zLCBhIHRvb2x0aXAgc2hvdWxkIHRha2UgdG8gZmFkZSBvdXQgb2Ygdmlldy5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAxNTBcbiAgICovXG4gIGZhZGVPdXREdXJhdGlvbjogMTUwLFxuICAvKipcbiAgICogRGlzYWJsZXMgaG92ZXIgZXZlbnRzIGZyb20gb3BlbmluZyB0aGUgdG9vbHRpcCBpZiBzZXQgdG8gdHJ1ZVxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICBkaXNhYmxlSG92ZXI6IGZhbHNlLFxuICAvKipcbiAgICogT3B0aW9uYWwgYWRkdGlvbmFsIGNsYXNzZXMgdG8gYXBwbHkgdG8gdGhlIHRvb2x0aXAgdGVtcGxhdGUgb24gaW5pdC5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnbXktY29vbC10aXAtY2xhc3MnXG4gICAqL1xuICB0ZW1wbGF0ZUNsYXNzZXM6ICcnLFxuICAvKipcbiAgICogTm9uLW9wdGlvbmFsIGNsYXNzIGFkZGVkIHRvIHRvb2x0aXAgdGVtcGxhdGVzLiBGb3VuZGF0aW9uIGRlZmF1bHQgaXMgJ3Rvb2x0aXAnLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlICd0b29sdGlwJ1xuICAgKi9cbiAgdG9vbHRpcENsYXNzOiAndG9vbHRpcCcsXG4gIC8qKlxuICAgKiBDbGFzcyBhcHBsaWVkIHRvIHRoZSB0b29sdGlwIGFuY2hvciBlbGVtZW50LlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlICdoYXMtdGlwJ1xuICAgKi9cbiAgdHJpZ2dlckNsYXNzOiAnaGFzLXRpcCcsXG4gIC8qKlxuICAgKiBNaW5pbXVtIGJyZWFrcG9pbnQgc2l6ZSBhdCB3aGljaCB0byBvcGVuIHRoZSB0b29sdGlwLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlICdzbWFsbCdcbiAgICovXG4gIHNob3dPbjogJ3NtYWxsJyxcbiAgLyoqXG4gICAqIEN1c3RvbSB0ZW1wbGF0ZSB0byBiZSB1c2VkIHRvIGdlbmVyYXRlIG1hcmt1cCBmb3IgdG9vbHRpcC5cbiAgICogQG9wdGlvblxuICAgKiBAZXhhbXBsZSAnJmx0O2RpdiBjbGFzcz1cInRvb2x0aXBcIiZndDsmbHQ7L2RpdiZndDsnXG4gICAqL1xuICB0ZW1wbGF0ZTogJycsXG4gIC8qKlxuICAgKiBUZXh0IGRpc3BsYXllZCBpbiB0aGUgdG9vbHRpcCB0ZW1wbGF0ZSBvbiBvcGVuLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlICdTb21lIGNvb2wgc3BhY2UgZmFjdCBoZXJlLidcbiAgICovXG4gIHRpcFRleHQ6ICcnLFxuICB0b3VjaENsb3NlVGV4dDogJ1RhcCB0byBjbG9zZS4nLFxuICAvKipcbiAgICogQWxsb3dzIHRoZSB0b29sdGlwIHRvIHJlbWFpbiBvcGVuIGlmIHRyaWdnZXJlZCB3aXRoIGEgY2xpY2sgb3IgdG91Y2ggZXZlbnQuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgdHJ1ZVxuICAgKi9cbiAgY2xpY2tPcGVuOiB0cnVlLFxuICAvKipcbiAgICogQWRkaXRpb25hbCBwb3NpdGlvbmluZyBjbGFzc2VzLCBzZXQgYnkgdGhlIEpTXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgJ3RvcCdcbiAgICovXG4gIHBvc2l0aW9uQ2xhc3M6ICcnLFxuICAvKipcbiAgICogRGlzdGFuY2UsIGluIHBpeGVscywgdGhlIHRlbXBsYXRlIHNob3VsZCBwdXNoIGF3YXkgZnJvbSB0aGUgYW5jaG9yIG9uIHRoZSBZIGF4aXMuXG4gICAqIEBvcHRpb25cbiAgICogQGV4YW1wbGUgMTBcbiAgICovXG4gIHZPZmZzZXQ6IDEwLFxuICAvKipcbiAgICogRGlzdGFuY2UsIGluIHBpeGVscywgdGhlIHRlbXBsYXRlIHNob3VsZCBwdXNoIGF3YXkgZnJvbSB0aGUgYW5jaG9yIG9uIHRoZSBYIGF4aXMsIGlmIGFsaWduZWQgdG8gYSBzaWRlLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIDEyXG4gICAqL1xuICBoT2Zmc2V0OiAxMixcbiAgICAvKipcbiAgICogQWxsb3cgSFRNTCBpbiB0b29sdGlwLiBXYXJuaW5nOiBJZiB5b3UgYXJlIGxvYWRpbmcgdXNlci1nZW5lcmF0ZWQgY29udGVudCBpbnRvIHRvb2x0aXBzLFxuICAgKiBhbGxvd2luZyBIVE1MIG1heSBvcGVuIHlvdXJzZWxmIHVwIHRvIFhTUyBhdHRhY2tzLlxuICAgKiBAb3B0aW9uXG4gICAqIEBleGFtcGxlIGZhbHNlXG4gICAqL1xuICBhbGxvd0h0bWw6IGZhbHNlXG59O1xuXG4vKipcbiAqIFRPRE8gdXRpbGl6ZSByZXNpemUgZXZlbnQgdHJpZ2dlclxuICovXG5cbi8vIFdpbmRvdyBleHBvcnRzXG5Gb3VuZGF0aW9uLnBsdWdpbihUb29sdGlwLCAnVG9vbHRpcCcpO1xuXG59KGpRdWVyeSk7XG4iLCIvKipcbiAqIE93bCBDYXJvdXNlbCB2Mi4yLjFcbiAqIENvcHlyaWdodCAyMDEzLTIwMTcgRGF2aWQgRGV1dHNjaFxuICogTGljZW5zZWQgdW5kZXIgICgpXG4gKi9cbiFmdW5jdGlvbihhLGIsYyxkKXtmdW5jdGlvbiBlKGIsYyl7dGhpcy5zZXR0aW5ncz1udWxsLHRoaXMub3B0aW9ucz1hLmV4dGVuZCh7fSxlLkRlZmF1bHRzLGMpLHRoaXMuJGVsZW1lbnQ9YShiKSx0aGlzLl9oYW5kbGVycz17fSx0aGlzLl9wbHVnaW5zPXt9LHRoaXMuX3N1cHJlc3M9e30sdGhpcy5fY3VycmVudD1udWxsLHRoaXMuX3NwZWVkPW51bGwsdGhpcy5fY29vcmRpbmF0ZXM9W10sdGhpcy5fYnJlYWtwb2ludD1udWxsLHRoaXMuX3dpZHRoPW51bGwsdGhpcy5faXRlbXM9W10sdGhpcy5fY2xvbmVzPVtdLHRoaXMuX21lcmdlcnM9W10sdGhpcy5fd2lkdGhzPVtdLHRoaXMuX2ludmFsaWRhdGVkPXt9LHRoaXMuX3BpcGU9W10sdGhpcy5fZHJhZz17dGltZTpudWxsLHRhcmdldDpudWxsLHBvaW50ZXI6bnVsbCxzdGFnZTp7c3RhcnQ6bnVsbCxjdXJyZW50Om51bGx9LGRpcmVjdGlvbjpudWxsfSx0aGlzLl9zdGF0ZXM9e2N1cnJlbnQ6e30sdGFnczp7aW5pdGlhbGl6aW5nOltcImJ1c3lcIl0sYW5pbWF0aW5nOltcImJ1c3lcIl0sZHJhZ2dpbmc6W1wiaW50ZXJhY3RpbmdcIl19fSxhLmVhY2goW1wib25SZXNpemVcIixcIm9uVGhyb3R0bGVkUmVzaXplXCJdLGEucHJveHkoZnVuY3Rpb24oYixjKXt0aGlzLl9oYW5kbGVyc1tjXT1hLnByb3h5KHRoaXNbY10sdGhpcyl9LHRoaXMpKSxhLmVhY2goZS5QbHVnaW5zLGEucHJveHkoZnVuY3Rpb24oYSxiKXt0aGlzLl9wbHVnaW5zW2EuY2hhckF0KDApLnRvTG93ZXJDYXNlKCkrYS5zbGljZSgxKV09bmV3IGIodGhpcyl9LHRoaXMpKSxhLmVhY2goZS5Xb3JrZXJzLGEucHJveHkoZnVuY3Rpb24oYixjKXt0aGlzLl9waXBlLnB1c2goe2ZpbHRlcjpjLmZpbHRlcixydW46YS5wcm94eShjLnJ1bix0aGlzKX0pfSx0aGlzKSksdGhpcy5zZXR1cCgpLHRoaXMuaW5pdGlhbGl6ZSgpfWUuRGVmYXVsdHM9e2l0ZW1zOjMsbG9vcDohMSxjZW50ZXI6ITEscmV3aW5kOiExLG1vdXNlRHJhZzohMCx0b3VjaERyYWc6ITAscHVsbERyYWc6ITAsZnJlZURyYWc6ITEsbWFyZ2luOjAsc3RhZ2VQYWRkaW5nOjAsbWVyZ2U6ITEsbWVyZ2VGaXQ6ITAsYXV0b1dpZHRoOiExLHN0YXJ0UG9zaXRpb246MCxydGw6ITEsc21hcnRTcGVlZDoyNTAsZmx1aWRTcGVlZDohMSxkcmFnRW5kU3BlZWQ6ITEscmVzcG9uc2l2ZTp7fSxyZXNwb25zaXZlUmVmcmVzaFJhdGU6MjAwLHJlc3BvbnNpdmVCYXNlRWxlbWVudDpiLGZhbGxiYWNrRWFzaW5nOlwic3dpbmdcIixpbmZvOiExLG5lc3RlZEl0ZW1TZWxlY3RvcjohMSxpdGVtRWxlbWVudDpcImRpdlwiLHN0YWdlRWxlbWVudDpcImRpdlwiLHJlZnJlc2hDbGFzczpcIm93bC1yZWZyZXNoXCIsbG9hZGVkQ2xhc3M6XCJvd2wtbG9hZGVkXCIsbG9hZGluZ0NsYXNzOlwib3dsLWxvYWRpbmdcIixydGxDbGFzczpcIm93bC1ydGxcIixyZXNwb25zaXZlQ2xhc3M6XCJvd2wtcmVzcG9uc2l2ZVwiLGRyYWdDbGFzczpcIm93bC1kcmFnXCIsaXRlbUNsYXNzOlwib3dsLWl0ZW1cIixzdGFnZUNsYXNzOlwib3dsLXN0YWdlXCIsc3RhZ2VPdXRlckNsYXNzOlwib3dsLXN0YWdlLW91dGVyXCIsZ3JhYkNsYXNzOlwib3dsLWdyYWJcIn0sZS5XaWR0aD17RGVmYXVsdDpcImRlZmF1bHRcIixJbm5lcjpcImlubmVyXCIsT3V0ZXI6XCJvdXRlclwifSxlLlR5cGU9e0V2ZW50OlwiZXZlbnRcIixTdGF0ZTpcInN0YXRlXCJ9LGUuUGx1Z2lucz17fSxlLldvcmtlcnM9W3tmaWx0ZXI6W1wid2lkdGhcIixcInNldHRpbmdzXCJdLHJ1bjpmdW5jdGlvbigpe3RoaXMuX3dpZHRoPXRoaXMuJGVsZW1lbnQud2lkdGgoKX19LHtmaWx0ZXI6W1wid2lkdGhcIixcIml0ZW1zXCIsXCJzZXR0aW5nc1wiXSxydW46ZnVuY3Rpb24oYSl7YS5jdXJyZW50PXRoaXMuX2l0ZW1zJiZ0aGlzLl9pdGVtc1t0aGlzLnJlbGF0aXZlKHRoaXMuX2N1cnJlbnQpXX19LHtmaWx0ZXI6W1wiaXRlbXNcIixcInNldHRpbmdzXCJdLHJ1bjpmdW5jdGlvbigpe3RoaXMuJHN0YWdlLmNoaWxkcmVuKFwiLmNsb25lZFwiKS5yZW1vdmUoKX19LHtmaWx0ZXI6W1wid2lkdGhcIixcIml0ZW1zXCIsXCJzZXR0aW5nc1wiXSxydW46ZnVuY3Rpb24oYSl7dmFyIGI9dGhpcy5zZXR0aW5ncy5tYXJnaW58fFwiXCIsYz0hdGhpcy5zZXR0aW5ncy5hdXRvV2lkdGgsZD10aGlzLnNldHRpbmdzLnJ0bCxlPXt3aWR0aDpcImF1dG9cIixcIm1hcmdpbi1sZWZ0XCI6ZD9iOlwiXCIsXCJtYXJnaW4tcmlnaHRcIjpkP1wiXCI6Yn07IWMmJnRoaXMuJHN0YWdlLmNoaWxkcmVuKCkuY3NzKGUpLGEuY3NzPWV9fSx7ZmlsdGVyOltcIndpZHRoXCIsXCJpdGVtc1wiLFwic2V0dGluZ3NcIl0scnVuOmZ1bmN0aW9uKGEpe3ZhciBiPSh0aGlzLndpZHRoKCkvdGhpcy5zZXR0aW5ncy5pdGVtcykudG9GaXhlZCgzKS10aGlzLnNldHRpbmdzLm1hcmdpbixjPW51bGwsZD10aGlzLl9pdGVtcy5sZW5ndGgsZT0hdGhpcy5zZXR0aW5ncy5hdXRvV2lkdGgsZj1bXTtmb3IoYS5pdGVtcz17bWVyZ2U6ITEsd2lkdGg6Yn07ZC0tOyljPXRoaXMuX21lcmdlcnNbZF0sYz10aGlzLnNldHRpbmdzLm1lcmdlRml0JiZNYXRoLm1pbihjLHRoaXMuc2V0dGluZ3MuaXRlbXMpfHxjLGEuaXRlbXMubWVyZ2U9Yz4xfHxhLml0ZW1zLm1lcmdlLGZbZF09ZT9iKmM6dGhpcy5faXRlbXNbZF0ud2lkdGgoKTt0aGlzLl93aWR0aHM9Zn19LHtmaWx0ZXI6W1wiaXRlbXNcIixcInNldHRpbmdzXCJdLHJ1bjpmdW5jdGlvbigpe3ZhciBiPVtdLGM9dGhpcy5faXRlbXMsZD10aGlzLnNldHRpbmdzLGU9TWF0aC5tYXgoMipkLml0ZW1zLDQpLGY9MipNYXRoLmNlaWwoYy5sZW5ndGgvMiksZz1kLmxvb3AmJmMubGVuZ3RoP2QucmV3aW5kP2U6TWF0aC5tYXgoZSxmKTowLGg9XCJcIixpPVwiXCI7Zm9yKGcvPTI7Zy0tOyliLnB1c2godGhpcy5ub3JtYWxpemUoYi5sZW5ndGgvMiwhMCkpLGgrPWNbYltiLmxlbmd0aC0xXV1bMF0ub3V0ZXJIVE1MLGIucHVzaCh0aGlzLm5vcm1hbGl6ZShjLmxlbmd0aC0xLShiLmxlbmd0aC0xKS8yLCEwKSksaT1jW2JbYi5sZW5ndGgtMV1dWzBdLm91dGVySFRNTCtpO3RoaXMuX2Nsb25lcz1iLGEoaCkuYWRkQ2xhc3MoXCJjbG9uZWRcIikuYXBwZW5kVG8odGhpcy4kc3RhZ2UpLGEoaSkuYWRkQ2xhc3MoXCJjbG9uZWRcIikucHJlcGVuZFRvKHRoaXMuJHN0YWdlKX19LHtmaWx0ZXI6W1wid2lkdGhcIixcIml0ZW1zXCIsXCJzZXR0aW5nc1wiXSxydW46ZnVuY3Rpb24oKXtmb3IodmFyIGE9dGhpcy5zZXR0aW5ncy5ydGw/MTotMSxiPXRoaXMuX2Nsb25lcy5sZW5ndGgrdGhpcy5faXRlbXMubGVuZ3RoLGM9LTEsZD0wLGU9MCxmPVtdOysrYzxiOylkPWZbYy0xXXx8MCxlPXRoaXMuX3dpZHRoc1t0aGlzLnJlbGF0aXZlKGMpXSt0aGlzLnNldHRpbmdzLm1hcmdpbixmLnB1c2goZCtlKmEpO3RoaXMuX2Nvb3JkaW5hdGVzPWZ9fSx7ZmlsdGVyOltcIndpZHRoXCIsXCJpdGVtc1wiLFwic2V0dGluZ3NcIl0scnVuOmZ1bmN0aW9uKCl7dmFyIGE9dGhpcy5zZXR0aW5ncy5zdGFnZVBhZGRpbmcsYj10aGlzLl9jb29yZGluYXRlcyxjPXt3aWR0aDpNYXRoLmNlaWwoTWF0aC5hYnMoYltiLmxlbmd0aC0xXSkpKzIqYSxcInBhZGRpbmctbGVmdFwiOmF8fFwiXCIsXCJwYWRkaW5nLXJpZ2h0XCI6YXx8XCJcIn07dGhpcy4kc3RhZ2UuY3NzKGMpfX0se2ZpbHRlcjpbXCJ3aWR0aFwiLFwiaXRlbXNcIixcInNldHRpbmdzXCJdLHJ1bjpmdW5jdGlvbihhKXt2YXIgYj10aGlzLl9jb29yZGluYXRlcy5sZW5ndGgsYz0hdGhpcy5zZXR0aW5ncy5hdXRvV2lkdGgsZD10aGlzLiRzdGFnZS5jaGlsZHJlbigpO2lmKGMmJmEuaXRlbXMubWVyZ2UpZm9yKDtiLS07KWEuY3NzLndpZHRoPXRoaXMuX3dpZHRoc1t0aGlzLnJlbGF0aXZlKGIpXSxkLmVxKGIpLmNzcyhhLmNzcyk7ZWxzZSBjJiYoYS5jc3Mud2lkdGg9YS5pdGVtcy53aWR0aCxkLmNzcyhhLmNzcykpfX0se2ZpbHRlcjpbXCJpdGVtc1wiXSxydW46ZnVuY3Rpb24oKXt0aGlzLl9jb29yZGluYXRlcy5sZW5ndGg8MSYmdGhpcy4kc3RhZ2UucmVtb3ZlQXR0cihcInN0eWxlXCIpfX0se2ZpbHRlcjpbXCJ3aWR0aFwiLFwiaXRlbXNcIixcInNldHRpbmdzXCJdLHJ1bjpmdW5jdGlvbihhKXthLmN1cnJlbnQ9YS5jdXJyZW50P3RoaXMuJHN0YWdlLmNoaWxkcmVuKCkuaW5kZXgoYS5jdXJyZW50KTowLGEuY3VycmVudD1NYXRoLm1heCh0aGlzLm1pbmltdW0oKSxNYXRoLm1pbih0aGlzLm1heGltdW0oKSxhLmN1cnJlbnQpKSx0aGlzLnJlc2V0KGEuY3VycmVudCl9fSx7ZmlsdGVyOltcInBvc2l0aW9uXCJdLHJ1bjpmdW5jdGlvbigpe3RoaXMuYW5pbWF0ZSh0aGlzLmNvb3JkaW5hdGVzKHRoaXMuX2N1cnJlbnQpKX19LHtmaWx0ZXI6W1wid2lkdGhcIixcInBvc2l0aW9uXCIsXCJpdGVtc1wiLFwic2V0dGluZ3NcIl0scnVuOmZ1bmN0aW9uKCl7dmFyIGEsYixjLGQsZT10aGlzLnNldHRpbmdzLnJ0bD8xOi0xLGY9Mip0aGlzLnNldHRpbmdzLnN0YWdlUGFkZGluZyxnPXRoaXMuY29vcmRpbmF0ZXModGhpcy5jdXJyZW50KCkpK2YsaD1nK3RoaXMud2lkdGgoKSplLGk9W107Zm9yKGM9MCxkPXRoaXMuX2Nvb3JkaW5hdGVzLmxlbmd0aDtjPGQ7YysrKWE9dGhpcy5fY29vcmRpbmF0ZXNbYy0xXXx8MCxiPU1hdGguYWJzKHRoaXMuX2Nvb3JkaW5hdGVzW2NdKStmKmUsKHRoaXMub3AoYSxcIjw9XCIsZykmJnRoaXMub3AoYSxcIj5cIixoKXx8dGhpcy5vcChiLFwiPFwiLGcpJiZ0aGlzLm9wKGIsXCI+XCIsaCkpJiZpLnB1c2goYyk7dGhpcy4kc3RhZ2UuY2hpbGRyZW4oXCIuYWN0aXZlXCIpLnJlbW92ZUNsYXNzKFwiYWN0aXZlXCIpLHRoaXMuJHN0YWdlLmNoaWxkcmVuKFwiOmVxKFwiK2kuam9pbihcIiksIDplcShcIikrXCIpXCIpLmFkZENsYXNzKFwiYWN0aXZlXCIpLHRoaXMuc2V0dGluZ3MuY2VudGVyJiYodGhpcy4kc3RhZ2UuY2hpbGRyZW4oXCIuY2VudGVyXCIpLnJlbW92ZUNsYXNzKFwiY2VudGVyXCIpLHRoaXMuJHN0YWdlLmNoaWxkcmVuKCkuZXEodGhpcy5jdXJyZW50KCkpLmFkZENsYXNzKFwiY2VudGVyXCIpKX19XSxlLnByb3RvdHlwZS5pbml0aWFsaXplPWZ1bmN0aW9uKCl7aWYodGhpcy5lbnRlcihcImluaXRpYWxpemluZ1wiKSx0aGlzLnRyaWdnZXIoXCJpbml0aWFsaXplXCIpLHRoaXMuJGVsZW1lbnQudG9nZ2xlQ2xhc3ModGhpcy5zZXR0aW5ncy5ydGxDbGFzcyx0aGlzLnNldHRpbmdzLnJ0bCksdGhpcy5zZXR0aW5ncy5hdXRvV2lkdGgmJiF0aGlzLmlzKFwicHJlLWxvYWRpbmdcIikpe3ZhciBiLGMsZTtiPXRoaXMuJGVsZW1lbnQuZmluZChcImltZ1wiKSxjPXRoaXMuc2V0dGluZ3MubmVzdGVkSXRlbVNlbGVjdG9yP1wiLlwiK3RoaXMuc2V0dGluZ3MubmVzdGVkSXRlbVNlbGVjdG9yOmQsZT10aGlzLiRlbGVtZW50LmNoaWxkcmVuKGMpLndpZHRoKCksYi5sZW5ndGgmJmU8PTAmJnRoaXMucHJlbG9hZEF1dG9XaWR0aEltYWdlcyhiKX10aGlzLiRlbGVtZW50LmFkZENsYXNzKHRoaXMub3B0aW9ucy5sb2FkaW5nQ2xhc3MpLHRoaXMuJHN0YWdlPWEoXCI8XCIrdGhpcy5zZXR0aW5ncy5zdGFnZUVsZW1lbnQrJyBjbGFzcz1cIicrdGhpcy5zZXR0aW5ncy5zdGFnZUNsYXNzKydcIi8+Jykud3JhcCgnPGRpdiBjbGFzcz1cIicrdGhpcy5zZXR0aW5ncy5zdGFnZU91dGVyQ2xhc3MrJ1wiLz4nKSx0aGlzLiRlbGVtZW50LmFwcGVuZCh0aGlzLiRzdGFnZS5wYXJlbnQoKSksdGhpcy5yZXBsYWNlKHRoaXMuJGVsZW1lbnQuY2hpbGRyZW4oKS5ub3QodGhpcy4kc3RhZ2UucGFyZW50KCkpKSx0aGlzLiRlbGVtZW50LmlzKFwiOnZpc2libGVcIik/dGhpcy5yZWZyZXNoKCk6dGhpcy5pbnZhbGlkYXRlKFwid2lkdGhcIiksdGhpcy4kZWxlbWVudC5yZW1vdmVDbGFzcyh0aGlzLm9wdGlvbnMubG9hZGluZ0NsYXNzKS5hZGRDbGFzcyh0aGlzLm9wdGlvbnMubG9hZGVkQ2xhc3MpLHRoaXMucmVnaXN0ZXJFdmVudEhhbmRsZXJzKCksdGhpcy5sZWF2ZShcImluaXRpYWxpemluZ1wiKSx0aGlzLnRyaWdnZXIoXCJpbml0aWFsaXplZFwiKX0sZS5wcm90b3R5cGUuc2V0dXA9ZnVuY3Rpb24oKXt2YXIgYj10aGlzLnZpZXdwb3J0KCksYz10aGlzLm9wdGlvbnMucmVzcG9uc2l2ZSxkPS0xLGU9bnVsbDtjPyhhLmVhY2goYyxmdW5jdGlvbihhKXthPD1iJiZhPmQmJihkPU51bWJlcihhKSl9KSxlPWEuZXh0ZW5kKHt9LHRoaXMub3B0aW9ucyxjW2RdKSxcImZ1bmN0aW9uXCI9PXR5cGVvZiBlLnN0YWdlUGFkZGluZyYmKGUuc3RhZ2VQYWRkaW5nPWUuc3RhZ2VQYWRkaW5nKCkpLGRlbGV0ZSBlLnJlc3BvbnNpdmUsZS5yZXNwb25zaXZlQ2xhc3MmJnRoaXMuJGVsZW1lbnQuYXR0cihcImNsYXNzXCIsdGhpcy4kZWxlbWVudC5hdHRyKFwiY2xhc3NcIikucmVwbGFjZShuZXcgUmVnRXhwKFwiKFwiK3RoaXMub3B0aW9ucy5yZXNwb25zaXZlQ2xhc3MrXCItKVxcXFxTK1xcXFxzXCIsXCJnXCIpLFwiJDFcIitkKSkpOmU9YS5leHRlbmQoe30sdGhpcy5vcHRpb25zKSx0aGlzLnRyaWdnZXIoXCJjaGFuZ2VcIix7cHJvcGVydHk6e25hbWU6XCJzZXR0aW5nc1wiLHZhbHVlOmV9fSksdGhpcy5fYnJlYWtwb2ludD1kLHRoaXMuc2V0dGluZ3M9ZSx0aGlzLmludmFsaWRhdGUoXCJzZXR0aW5nc1wiKSx0aGlzLnRyaWdnZXIoXCJjaGFuZ2VkXCIse3Byb3BlcnR5OntuYW1lOlwic2V0dGluZ3NcIix2YWx1ZTp0aGlzLnNldHRpbmdzfX0pfSxlLnByb3RvdHlwZS5vcHRpb25zTG9naWM9ZnVuY3Rpb24oKXt0aGlzLnNldHRpbmdzLmF1dG9XaWR0aCYmKHRoaXMuc2V0dGluZ3Muc3RhZ2VQYWRkaW5nPSExLHRoaXMuc2V0dGluZ3MubWVyZ2U9ITEpfSxlLnByb3RvdHlwZS5wcmVwYXJlPWZ1bmN0aW9uKGIpe3ZhciBjPXRoaXMudHJpZ2dlcihcInByZXBhcmVcIix7Y29udGVudDpifSk7cmV0dXJuIGMuZGF0YXx8KGMuZGF0YT1hKFwiPFwiK3RoaXMuc2V0dGluZ3MuaXRlbUVsZW1lbnQrXCIvPlwiKS5hZGRDbGFzcyh0aGlzLm9wdGlvbnMuaXRlbUNsYXNzKS5hcHBlbmQoYikpLHRoaXMudHJpZ2dlcihcInByZXBhcmVkXCIse2NvbnRlbnQ6Yy5kYXRhfSksYy5kYXRhfSxlLnByb3RvdHlwZS51cGRhdGU9ZnVuY3Rpb24oKXtmb3IodmFyIGI9MCxjPXRoaXMuX3BpcGUubGVuZ3RoLGQ9YS5wcm94eShmdW5jdGlvbihhKXtyZXR1cm4gdGhpc1thXX0sdGhpcy5faW52YWxpZGF0ZWQpLGU9e307YjxjOykodGhpcy5faW52YWxpZGF0ZWQuYWxsfHxhLmdyZXAodGhpcy5fcGlwZVtiXS5maWx0ZXIsZCkubGVuZ3RoPjApJiZ0aGlzLl9waXBlW2JdLnJ1bihlKSxiKys7dGhpcy5faW52YWxpZGF0ZWQ9e30sIXRoaXMuaXMoXCJ2YWxpZFwiKSYmdGhpcy5lbnRlcihcInZhbGlkXCIpfSxlLnByb3RvdHlwZS53aWR0aD1mdW5jdGlvbihhKXtzd2l0Y2goYT1hfHxlLldpZHRoLkRlZmF1bHQpe2Nhc2UgZS5XaWR0aC5Jbm5lcjpjYXNlIGUuV2lkdGguT3V0ZXI6cmV0dXJuIHRoaXMuX3dpZHRoO2RlZmF1bHQ6cmV0dXJuIHRoaXMuX3dpZHRoLTIqdGhpcy5zZXR0aW5ncy5zdGFnZVBhZGRpbmcrdGhpcy5zZXR0aW5ncy5tYXJnaW59fSxlLnByb3RvdHlwZS5yZWZyZXNoPWZ1bmN0aW9uKCl7dGhpcy5lbnRlcihcInJlZnJlc2hpbmdcIiksdGhpcy50cmlnZ2VyKFwicmVmcmVzaFwiKSx0aGlzLnNldHVwKCksdGhpcy5vcHRpb25zTG9naWMoKSx0aGlzLiRlbGVtZW50LmFkZENsYXNzKHRoaXMub3B0aW9ucy5yZWZyZXNoQ2xhc3MpLHRoaXMudXBkYXRlKCksdGhpcy4kZWxlbWVudC5yZW1vdmVDbGFzcyh0aGlzLm9wdGlvbnMucmVmcmVzaENsYXNzKSx0aGlzLmxlYXZlKFwicmVmcmVzaGluZ1wiKSx0aGlzLnRyaWdnZXIoXCJyZWZyZXNoZWRcIil9LGUucHJvdG90eXBlLm9uVGhyb3R0bGVkUmVzaXplPWZ1bmN0aW9uKCl7Yi5jbGVhclRpbWVvdXQodGhpcy5yZXNpemVUaW1lciksdGhpcy5yZXNpemVUaW1lcj1iLnNldFRpbWVvdXQodGhpcy5faGFuZGxlcnMub25SZXNpemUsdGhpcy5zZXR0aW5ncy5yZXNwb25zaXZlUmVmcmVzaFJhdGUpfSxlLnByb3RvdHlwZS5vblJlc2l6ZT1mdW5jdGlvbigpe3JldHVybiEhdGhpcy5faXRlbXMubGVuZ3RoJiYodGhpcy5fd2lkdGghPT10aGlzLiRlbGVtZW50LndpZHRoKCkmJighIXRoaXMuJGVsZW1lbnQuaXMoXCI6dmlzaWJsZVwiKSYmKHRoaXMuZW50ZXIoXCJyZXNpemluZ1wiKSx0aGlzLnRyaWdnZXIoXCJyZXNpemVcIikuaXNEZWZhdWx0UHJldmVudGVkKCk/KHRoaXMubGVhdmUoXCJyZXNpemluZ1wiKSwhMSk6KHRoaXMuaW52YWxpZGF0ZShcIndpZHRoXCIpLHRoaXMucmVmcmVzaCgpLHRoaXMubGVhdmUoXCJyZXNpemluZ1wiKSx2b2lkIHRoaXMudHJpZ2dlcihcInJlc2l6ZWRcIikpKSkpfSxlLnByb3RvdHlwZS5yZWdpc3RlckV2ZW50SGFuZGxlcnM9ZnVuY3Rpb24oKXthLnN1cHBvcnQudHJhbnNpdGlvbiYmdGhpcy4kc3RhZ2Uub24oYS5zdXBwb3J0LnRyYW5zaXRpb24uZW5kK1wiLm93bC5jb3JlXCIsYS5wcm94eSh0aGlzLm9uVHJhbnNpdGlvbkVuZCx0aGlzKSksdGhpcy5zZXR0aW5ncy5yZXNwb25zaXZlIT09ITEmJnRoaXMub24oYixcInJlc2l6ZVwiLHRoaXMuX2hhbmRsZXJzLm9uVGhyb3R0bGVkUmVzaXplKSx0aGlzLnNldHRpbmdzLm1vdXNlRHJhZyYmKHRoaXMuJGVsZW1lbnQuYWRkQ2xhc3ModGhpcy5vcHRpb25zLmRyYWdDbGFzcyksdGhpcy4kc3RhZ2Uub24oXCJtb3VzZWRvd24ub3dsLmNvcmVcIixhLnByb3h5KHRoaXMub25EcmFnU3RhcnQsdGhpcykpLHRoaXMuJHN0YWdlLm9uKFwiZHJhZ3N0YXJ0Lm93bC5jb3JlIHNlbGVjdHN0YXJ0Lm93bC5jb3JlXCIsZnVuY3Rpb24oKXtyZXR1cm4hMX0pKSx0aGlzLnNldHRpbmdzLnRvdWNoRHJhZyYmKHRoaXMuJHN0YWdlLm9uKFwidG91Y2hzdGFydC5vd2wuY29yZVwiLGEucHJveHkodGhpcy5vbkRyYWdTdGFydCx0aGlzKSksdGhpcy4kc3RhZ2Uub24oXCJ0b3VjaGNhbmNlbC5vd2wuY29yZVwiLGEucHJveHkodGhpcy5vbkRyYWdFbmQsdGhpcykpKX0sZS5wcm90b3R5cGUub25EcmFnU3RhcnQ9ZnVuY3Rpb24oYil7dmFyIGQ9bnVsbDszIT09Yi53aGljaCYmKGEuc3VwcG9ydC50cmFuc2Zvcm0/KGQ9dGhpcy4kc3RhZ2UuY3NzKFwidHJhbnNmb3JtXCIpLnJlcGxhY2UoLy4qXFwofFxcKXwgL2csXCJcIikuc3BsaXQoXCIsXCIpLGQ9e3g6ZFsxNj09PWQubGVuZ3RoPzEyOjRdLHk6ZFsxNj09PWQubGVuZ3RoPzEzOjVdfSk6KGQ9dGhpcy4kc3RhZ2UucG9zaXRpb24oKSxkPXt4OnRoaXMuc2V0dGluZ3MucnRsP2QubGVmdCt0aGlzLiRzdGFnZS53aWR0aCgpLXRoaXMud2lkdGgoKSt0aGlzLnNldHRpbmdzLm1hcmdpbjpkLmxlZnQseTpkLnRvcH0pLHRoaXMuaXMoXCJhbmltYXRpbmdcIikmJihhLnN1cHBvcnQudHJhbnNmb3JtP3RoaXMuYW5pbWF0ZShkLngpOnRoaXMuJHN0YWdlLnN0b3AoKSx0aGlzLmludmFsaWRhdGUoXCJwb3NpdGlvblwiKSksdGhpcy4kZWxlbWVudC50b2dnbGVDbGFzcyh0aGlzLm9wdGlvbnMuZ3JhYkNsYXNzLFwibW91c2Vkb3duXCI9PT1iLnR5cGUpLHRoaXMuc3BlZWQoMCksdGhpcy5fZHJhZy50aW1lPShuZXcgRGF0ZSkuZ2V0VGltZSgpLHRoaXMuX2RyYWcudGFyZ2V0PWEoYi50YXJnZXQpLHRoaXMuX2RyYWcuc3RhZ2Uuc3RhcnQ9ZCx0aGlzLl9kcmFnLnN0YWdlLmN1cnJlbnQ9ZCx0aGlzLl9kcmFnLnBvaW50ZXI9dGhpcy5wb2ludGVyKGIpLGEoYykub24oXCJtb3VzZXVwLm93bC5jb3JlIHRvdWNoZW5kLm93bC5jb3JlXCIsYS5wcm94eSh0aGlzLm9uRHJhZ0VuZCx0aGlzKSksYShjKS5vbmUoXCJtb3VzZW1vdmUub3dsLmNvcmUgdG91Y2htb3ZlLm93bC5jb3JlXCIsYS5wcm94eShmdW5jdGlvbihiKXt2YXIgZD10aGlzLmRpZmZlcmVuY2UodGhpcy5fZHJhZy5wb2ludGVyLHRoaXMucG9pbnRlcihiKSk7YShjKS5vbihcIm1vdXNlbW92ZS5vd2wuY29yZSB0b3VjaG1vdmUub3dsLmNvcmVcIixhLnByb3h5KHRoaXMub25EcmFnTW92ZSx0aGlzKSksTWF0aC5hYnMoZC54KTxNYXRoLmFicyhkLnkpJiZ0aGlzLmlzKFwidmFsaWRcIil8fChiLnByZXZlbnREZWZhdWx0KCksdGhpcy5lbnRlcihcImRyYWdnaW5nXCIpLHRoaXMudHJpZ2dlcihcImRyYWdcIikpfSx0aGlzKSkpfSxlLnByb3RvdHlwZS5vbkRyYWdNb3ZlPWZ1bmN0aW9uKGEpe3ZhciBiPW51bGwsYz1udWxsLGQ9bnVsbCxlPXRoaXMuZGlmZmVyZW5jZSh0aGlzLl9kcmFnLnBvaW50ZXIsdGhpcy5wb2ludGVyKGEpKSxmPXRoaXMuZGlmZmVyZW5jZSh0aGlzLl9kcmFnLnN0YWdlLnN0YXJ0LGUpO3RoaXMuaXMoXCJkcmFnZ2luZ1wiKSYmKGEucHJldmVudERlZmF1bHQoKSx0aGlzLnNldHRpbmdzLmxvb3A/KGI9dGhpcy5jb29yZGluYXRlcyh0aGlzLm1pbmltdW0oKSksYz10aGlzLmNvb3JkaW5hdGVzKHRoaXMubWF4aW11bSgpKzEpLWIsZi54PSgoZi54LWIpJWMrYyklYytiKTooYj10aGlzLnNldHRpbmdzLnJ0bD90aGlzLmNvb3JkaW5hdGVzKHRoaXMubWF4aW11bSgpKTp0aGlzLmNvb3JkaW5hdGVzKHRoaXMubWluaW11bSgpKSxjPXRoaXMuc2V0dGluZ3MucnRsP3RoaXMuY29vcmRpbmF0ZXModGhpcy5taW5pbXVtKCkpOnRoaXMuY29vcmRpbmF0ZXModGhpcy5tYXhpbXVtKCkpLGQ9dGhpcy5zZXR0aW5ncy5wdWxsRHJhZz8tMSplLngvNTowLGYueD1NYXRoLm1heChNYXRoLm1pbihmLngsYitkKSxjK2QpKSx0aGlzLl9kcmFnLnN0YWdlLmN1cnJlbnQ9Zix0aGlzLmFuaW1hdGUoZi54KSl9LGUucHJvdG90eXBlLm9uRHJhZ0VuZD1mdW5jdGlvbihiKXt2YXIgZD10aGlzLmRpZmZlcmVuY2UodGhpcy5fZHJhZy5wb2ludGVyLHRoaXMucG9pbnRlcihiKSksZT10aGlzLl9kcmFnLnN0YWdlLmN1cnJlbnQsZj1kLng+MF50aGlzLnNldHRpbmdzLnJ0bD9cImxlZnRcIjpcInJpZ2h0XCI7YShjKS5vZmYoXCIub3dsLmNvcmVcIiksdGhpcy4kZWxlbWVudC5yZW1vdmVDbGFzcyh0aGlzLm9wdGlvbnMuZ3JhYkNsYXNzKSwoMCE9PWQueCYmdGhpcy5pcyhcImRyYWdnaW5nXCIpfHwhdGhpcy5pcyhcInZhbGlkXCIpKSYmKHRoaXMuc3BlZWQodGhpcy5zZXR0aW5ncy5kcmFnRW5kU3BlZWR8fHRoaXMuc2V0dGluZ3Muc21hcnRTcGVlZCksdGhpcy5jdXJyZW50KHRoaXMuY2xvc2VzdChlLngsMCE9PWQueD9mOnRoaXMuX2RyYWcuZGlyZWN0aW9uKSksdGhpcy5pbnZhbGlkYXRlKFwicG9zaXRpb25cIiksdGhpcy51cGRhdGUoKSx0aGlzLl9kcmFnLmRpcmVjdGlvbj1mLChNYXRoLmFicyhkLngpPjN8fChuZXcgRGF0ZSkuZ2V0VGltZSgpLXRoaXMuX2RyYWcudGltZT4zMDApJiZ0aGlzLl9kcmFnLnRhcmdldC5vbmUoXCJjbGljay5vd2wuY29yZVwiLGZ1bmN0aW9uKCl7cmV0dXJuITF9KSksdGhpcy5pcyhcImRyYWdnaW5nXCIpJiYodGhpcy5sZWF2ZShcImRyYWdnaW5nXCIpLHRoaXMudHJpZ2dlcihcImRyYWdnZWRcIikpfSxlLnByb3RvdHlwZS5jbG9zZXN0PWZ1bmN0aW9uKGIsYyl7dmFyIGQ9LTEsZT0zMCxmPXRoaXMud2lkdGgoKSxnPXRoaXMuY29vcmRpbmF0ZXMoKTtyZXR1cm4gdGhpcy5zZXR0aW5ncy5mcmVlRHJhZ3x8YS5lYWNoKGcsYS5wcm94eShmdW5jdGlvbihhLGgpe3JldHVyblwibGVmdFwiPT09YyYmYj5oLWUmJmI8aCtlP2Q9YTpcInJpZ2h0XCI9PT1jJiZiPmgtZi1lJiZiPGgtZitlP2Q9YSsxOnRoaXMub3AoYixcIjxcIixoKSYmdGhpcy5vcChiLFwiPlwiLGdbYSsxXXx8aC1mKSYmKGQ9XCJsZWZ0XCI9PT1jP2ErMTphKSxkPT09LTF9LHRoaXMpKSx0aGlzLnNldHRpbmdzLmxvb3B8fCh0aGlzLm9wKGIsXCI+XCIsZ1t0aGlzLm1pbmltdW0oKV0pP2Q9Yj10aGlzLm1pbmltdW0oKTp0aGlzLm9wKGIsXCI8XCIsZ1t0aGlzLm1heGltdW0oKV0pJiYoZD1iPXRoaXMubWF4aW11bSgpKSksZH0sZS5wcm90b3R5cGUuYW5pbWF0ZT1mdW5jdGlvbihiKXt2YXIgYz10aGlzLnNwZWVkKCk+MDt0aGlzLmlzKFwiYW5pbWF0aW5nXCIpJiZ0aGlzLm9uVHJhbnNpdGlvbkVuZCgpLGMmJih0aGlzLmVudGVyKFwiYW5pbWF0aW5nXCIpLHRoaXMudHJpZ2dlcihcInRyYW5zbGF0ZVwiKSksYS5zdXBwb3J0LnRyYW5zZm9ybTNkJiZhLnN1cHBvcnQudHJhbnNpdGlvbj90aGlzLiRzdGFnZS5jc3Moe3RyYW5zZm9ybTpcInRyYW5zbGF0ZTNkKFwiK2IrXCJweCwwcHgsMHB4KVwiLHRyYW5zaXRpb246dGhpcy5zcGVlZCgpLzFlMytcInNcIn0pOmM/dGhpcy4kc3RhZ2UuYW5pbWF0ZSh7bGVmdDpiK1wicHhcIn0sdGhpcy5zcGVlZCgpLHRoaXMuc2V0dGluZ3MuZmFsbGJhY2tFYXNpbmcsYS5wcm94eSh0aGlzLm9uVHJhbnNpdGlvbkVuZCx0aGlzKSk6dGhpcy4kc3RhZ2UuY3NzKHtsZWZ0OmIrXCJweFwifSl9LGUucHJvdG90eXBlLmlzPWZ1bmN0aW9uKGEpe3JldHVybiB0aGlzLl9zdGF0ZXMuY3VycmVudFthXSYmdGhpcy5fc3RhdGVzLmN1cnJlbnRbYV0+MH0sZS5wcm90b3R5cGUuY3VycmVudD1mdW5jdGlvbihhKXtpZihhPT09ZClyZXR1cm4gdGhpcy5fY3VycmVudDtpZigwPT09dGhpcy5faXRlbXMubGVuZ3RoKXJldHVybiBkO2lmKGE9dGhpcy5ub3JtYWxpemUoYSksdGhpcy5fY3VycmVudCE9PWEpe3ZhciBiPXRoaXMudHJpZ2dlcihcImNoYW5nZVwiLHtwcm9wZXJ0eTp7bmFtZTpcInBvc2l0aW9uXCIsdmFsdWU6YX19KTtiLmRhdGEhPT1kJiYoYT10aGlzLm5vcm1hbGl6ZShiLmRhdGEpKSx0aGlzLl9jdXJyZW50PWEsdGhpcy5pbnZhbGlkYXRlKFwicG9zaXRpb25cIiksdGhpcy50cmlnZ2VyKFwiY2hhbmdlZFwiLHtwcm9wZXJ0eTp7bmFtZTpcInBvc2l0aW9uXCIsdmFsdWU6dGhpcy5fY3VycmVudH19KX1yZXR1cm4gdGhpcy5fY3VycmVudH0sZS5wcm90b3R5cGUuaW52YWxpZGF0ZT1mdW5jdGlvbihiKXtyZXR1cm5cInN0cmluZ1wiPT09YS50eXBlKGIpJiYodGhpcy5faW52YWxpZGF0ZWRbYl09ITAsdGhpcy5pcyhcInZhbGlkXCIpJiZ0aGlzLmxlYXZlKFwidmFsaWRcIikpLGEubWFwKHRoaXMuX2ludmFsaWRhdGVkLGZ1bmN0aW9uKGEsYil7cmV0dXJuIGJ9KX0sZS5wcm90b3R5cGUucmVzZXQ9ZnVuY3Rpb24oYSl7YT10aGlzLm5vcm1hbGl6ZShhKSxhIT09ZCYmKHRoaXMuX3NwZWVkPTAsdGhpcy5fY3VycmVudD1hLHRoaXMuc3VwcHJlc3MoW1widHJhbnNsYXRlXCIsXCJ0cmFuc2xhdGVkXCJdKSx0aGlzLmFuaW1hdGUodGhpcy5jb29yZGluYXRlcyhhKSksdGhpcy5yZWxlYXNlKFtcInRyYW5zbGF0ZVwiLFwidHJhbnNsYXRlZFwiXSkpfSxlLnByb3RvdHlwZS5ub3JtYWxpemU9ZnVuY3Rpb24oYSxiKXt2YXIgYz10aGlzLl9pdGVtcy5sZW5ndGgsZT1iPzA6dGhpcy5fY2xvbmVzLmxlbmd0aDtyZXR1cm4hdGhpcy5pc051bWVyaWMoYSl8fGM8MT9hPWQ6KGE8MHx8YT49YytlKSYmKGE9KChhLWUvMiklYytjKSVjK2UvMiksYX0sZS5wcm90b3R5cGUucmVsYXRpdmU9ZnVuY3Rpb24oYSl7cmV0dXJuIGEtPXRoaXMuX2Nsb25lcy5sZW5ndGgvMix0aGlzLm5vcm1hbGl6ZShhLCEwKX0sZS5wcm90b3R5cGUubWF4aW11bT1mdW5jdGlvbihhKXt2YXIgYixjLGQsZT10aGlzLnNldHRpbmdzLGY9dGhpcy5fY29vcmRpbmF0ZXMubGVuZ3RoO2lmKGUubG9vcClmPXRoaXMuX2Nsb25lcy5sZW5ndGgvMit0aGlzLl9pdGVtcy5sZW5ndGgtMTtlbHNlIGlmKGUuYXV0b1dpZHRofHxlLm1lcmdlKXtmb3IoYj10aGlzLl9pdGVtcy5sZW5ndGgsYz10aGlzLl9pdGVtc1stLWJdLndpZHRoKCksZD10aGlzLiRlbGVtZW50LndpZHRoKCk7Yi0tJiYoYys9dGhpcy5faXRlbXNbYl0ud2lkdGgoKSt0aGlzLnNldHRpbmdzLm1hcmdpbiwhKGM+ZCkpOyk7Zj1iKzF9ZWxzZSBmPWUuY2VudGVyP3RoaXMuX2l0ZW1zLmxlbmd0aC0xOnRoaXMuX2l0ZW1zLmxlbmd0aC1lLml0ZW1zO3JldHVybiBhJiYoZi09dGhpcy5fY2xvbmVzLmxlbmd0aC8yKSxNYXRoLm1heChmLDApfSxlLnByb3RvdHlwZS5taW5pbXVtPWZ1bmN0aW9uKGEpe3JldHVybiBhPzA6dGhpcy5fY2xvbmVzLmxlbmd0aC8yfSxlLnByb3RvdHlwZS5pdGVtcz1mdW5jdGlvbihhKXtyZXR1cm4gYT09PWQ/dGhpcy5faXRlbXMuc2xpY2UoKTooYT10aGlzLm5vcm1hbGl6ZShhLCEwKSx0aGlzLl9pdGVtc1thXSl9LGUucHJvdG90eXBlLm1lcmdlcnM9ZnVuY3Rpb24oYSl7cmV0dXJuIGE9PT1kP3RoaXMuX21lcmdlcnMuc2xpY2UoKTooYT10aGlzLm5vcm1hbGl6ZShhLCEwKSx0aGlzLl9tZXJnZXJzW2FdKX0sZS5wcm90b3R5cGUuY2xvbmVzPWZ1bmN0aW9uKGIpe3ZhciBjPXRoaXMuX2Nsb25lcy5sZW5ndGgvMixlPWMrdGhpcy5faXRlbXMubGVuZ3RoLGY9ZnVuY3Rpb24oYSl7cmV0dXJuIGElMj09PTA/ZSthLzI6Yy0oYSsxKS8yfTtyZXR1cm4gYj09PWQ/YS5tYXAodGhpcy5fY2xvbmVzLGZ1bmN0aW9uKGEsYil7cmV0dXJuIGYoYil9KTphLm1hcCh0aGlzLl9jbG9uZXMsZnVuY3Rpb24oYSxjKXtyZXR1cm4gYT09PWI/ZihjKTpudWxsfSl9LGUucHJvdG90eXBlLnNwZWVkPWZ1bmN0aW9uKGEpe3JldHVybiBhIT09ZCYmKHRoaXMuX3NwZWVkPWEpLHRoaXMuX3NwZWVkfSxlLnByb3RvdHlwZS5jb29yZGluYXRlcz1mdW5jdGlvbihiKXt2YXIgYyxlPTEsZj1iLTE7cmV0dXJuIGI9PT1kP2EubWFwKHRoaXMuX2Nvb3JkaW5hdGVzLGEucHJveHkoZnVuY3Rpb24oYSxiKXtyZXR1cm4gdGhpcy5jb29yZGluYXRlcyhiKX0sdGhpcykpOih0aGlzLnNldHRpbmdzLmNlbnRlcj8odGhpcy5zZXR0aW5ncy5ydGwmJihlPS0xLGY9YisxKSxjPXRoaXMuX2Nvb3JkaW5hdGVzW2JdLGMrPSh0aGlzLndpZHRoKCktYysodGhpcy5fY29vcmRpbmF0ZXNbZl18fDApKS8yKmUpOmM9dGhpcy5fY29vcmRpbmF0ZXNbZl18fDAsYz1NYXRoLmNlaWwoYykpfSxlLnByb3RvdHlwZS5kdXJhdGlvbj1mdW5jdGlvbihhLGIsYyl7cmV0dXJuIDA9PT1jPzA6TWF0aC5taW4oTWF0aC5tYXgoTWF0aC5hYnMoYi1hKSwxKSw2KSpNYXRoLmFicyhjfHx0aGlzLnNldHRpbmdzLnNtYXJ0U3BlZWQpfSxlLnByb3RvdHlwZS50bz1mdW5jdGlvbihhLGIpe3ZhciBjPXRoaXMuY3VycmVudCgpLGQ9bnVsbCxlPWEtdGhpcy5yZWxhdGl2ZShjKSxmPShlPjApLShlPDApLGc9dGhpcy5faXRlbXMubGVuZ3RoLGg9dGhpcy5taW5pbXVtKCksaT10aGlzLm1heGltdW0oKTt0aGlzLnNldHRpbmdzLmxvb3A/KCF0aGlzLnNldHRpbmdzLnJld2luZCYmTWF0aC5hYnMoZSk+Zy8yJiYoZSs9ZiotMSpnKSxhPWMrZSxkPSgoYS1oKSVnK2cpJWcraCxkIT09YSYmZC1lPD1pJiZkLWU+MCYmKGM9ZC1lLGE9ZCx0aGlzLnJlc2V0KGMpKSk6dGhpcy5zZXR0aW5ncy5yZXdpbmQ/KGkrPTEsYT0oYSVpK2kpJWkpOmE9TWF0aC5tYXgoaCxNYXRoLm1pbihpLGEpKSx0aGlzLnNwZWVkKHRoaXMuZHVyYXRpb24oYyxhLGIpKSx0aGlzLmN1cnJlbnQoYSksdGhpcy4kZWxlbWVudC5pcyhcIjp2aXNpYmxlXCIpJiZ0aGlzLnVwZGF0ZSgpfSxlLnByb3RvdHlwZS5uZXh0PWZ1bmN0aW9uKGEpe2E9YXx8ITEsdGhpcy50byh0aGlzLnJlbGF0aXZlKHRoaXMuY3VycmVudCgpKSsxLGEpfSxlLnByb3RvdHlwZS5wcmV2PWZ1bmN0aW9uKGEpe2E9YXx8ITEsdGhpcy50byh0aGlzLnJlbGF0aXZlKHRoaXMuY3VycmVudCgpKS0xLGEpfSxlLnByb3RvdHlwZS5vblRyYW5zaXRpb25FbmQ9ZnVuY3Rpb24oYSl7aWYoYSE9PWQmJihhLnN0b3BQcm9wYWdhdGlvbigpLChhLnRhcmdldHx8YS5zcmNFbGVtZW50fHxhLm9yaWdpbmFsVGFyZ2V0KSE9PXRoaXMuJHN0YWdlLmdldCgwKSkpcmV0dXJuITE7dGhpcy5sZWF2ZShcImFuaW1hdGluZ1wiKSx0aGlzLnRyaWdnZXIoXCJ0cmFuc2xhdGVkXCIpfSxlLnByb3RvdHlwZS52aWV3cG9ydD1mdW5jdGlvbigpe3ZhciBkO3JldHVybiB0aGlzLm9wdGlvbnMucmVzcG9uc2l2ZUJhc2VFbGVtZW50IT09Yj9kPWEodGhpcy5vcHRpb25zLnJlc3BvbnNpdmVCYXNlRWxlbWVudCkud2lkdGgoKTpiLmlubmVyV2lkdGg/ZD1iLmlubmVyV2lkdGg6Yy5kb2N1bWVudEVsZW1lbnQmJmMuZG9jdW1lbnRFbGVtZW50LmNsaWVudFdpZHRoP2Q9Yy5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGg6Y29uc29sZS53YXJuKFwiQ2FuIG5vdCBkZXRlY3Qgdmlld3BvcnQgd2lkdGguXCIpLGR9LGUucHJvdG90eXBlLnJlcGxhY2U9ZnVuY3Rpb24oYil7dGhpcy4kc3RhZ2UuZW1wdHkoKSx0aGlzLl9pdGVtcz1bXSxiJiYoYj1iIGluc3RhbmNlb2YgalF1ZXJ5P2I6YShiKSksdGhpcy5zZXR0aW5ncy5uZXN0ZWRJdGVtU2VsZWN0b3ImJihiPWIuZmluZChcIi5cIit0aGlzLnNldHRpbmdzLm5lc3RlZEl0ZW1TZWxlY3RvcikpLGIuZmlsdGVyKGZ1bmN0aW9uKCl7cmV0dXJuIDE9PT10aGlzLm5vZGVUeXBlfSkuZWFjaChhLnByb3h5KGZ1bmN0aW9uKGEsYil7Yj10aGlzLnByZXBhcmUoYiksdGhpcy4kc3RhZ2UuYXBwZW5kKGIpLHRoaXMuX2l0ZW1zLnB1c2goYiksdGhpcy5fbWVyZ2Vycy5wdXNoKDEqYi5maW5kKFwiW2RhdGEtbWVyZ2VdXCIpLmFkZEJhY2soXCJbZGF0YS1tZXJnZV1cIikuYXR0cihcImRhdGEtbWVyZ2VcIil8fDEpfSx0aGlzKSksdGhpcy5yZXNldCh0aGlzLmlzTnVtZXJpYyh0aGlzLnNldHRpbmdzLnN0YXJ0UG9zaXRpb24pP3RoaXMuc2V0dGluZ3Muc3RhcnRQb3NpdGlvbjowKSx0aGlzLmludmFsaWRhdGUoXCJpdGVtc1wiKX0sZS5wcm90b3R5cGUuYWRkPWZ1bmN0aW9uKGIsYyl7dmFyIGU9dGhpcy5yZWxhdGl2ZSh0aGlzLl9jdXJyZW50KTtjPWM9PT1kP3RoaXMuX2l0ZW1zLmxlbmd0aDp0aGlzLm5vcm1hbGl6ZShjLCEwKSxiPWIgaW5zdGFuY2VvZiBqUXVlcnk/YjphKGIpLHRoaXMudHJpZ2dlcihcImFkZFwiLHtjb250ZW50OmIscG9zaXRpb246Y30pLGI9dGhpcy5wcmVwYXJlKGIpLDA9PT10aGlzLl9pdGVtcy5sZW5ndGh8fGM9PT10aGlzLl9pdGVtcy5sZW5ndGg/KDA9PT10aGlzLl9pdGVtcy5sZW5ndGgmJnRoaXMuJHN0YWdlLmFwcGVuZChiKSwwIT09dGhpcy5faXRlbXMubGVuZ3RoJiZ0aGlzLl9pdGVtc1tjLTFdLmFmdGVyKGIpLHRoaXMuX2l0ZW1zLnB1c2goYiksdGhpcy5fbWVyZ2Vycy5wdXNoKDEqYi5maW5kKFwiW2RhdGEtbWVyZ2VdXCIpLmFkZEJhY2soXCJbZGF0YS1tZXJnZV1cIikuYXR0cihcImRhdGEtbWVyZ2VcIil8fDEpKToodGhpcy5faXRlbXNbY10uYmVmb3JlKGIpLHRoaXMuX2l0ZW1zLnNwbGljZShjLDAsYiksdGhpcy5fbWVyZ2Vycy5zcGxpY2UoYywwLDEqYi5maW5kKFwiW2RhdGEtbWVyZ2VdXCIpLmFkZEJhY2soXCJbZGF0YS1tZXJnZV1cIikuYXR0cihcImRhdGEtbWVyZ2VcIil8fDEpKSx0aGlzLl9pdGVtc1tlXSYmdGhpcy5yZXNldCh0aGlzLl9pdGVtc1tlXS5pbmRleCgpKSx0aGlzLmludmFsaWRhdGUoXCJpdGVtc1wiKSx0aGlzLnRyaWdnZXIoXCJhZGRlZFwiLHtjb250ZW50OmIscG9zaXRpb246Y30pfSxlLnByb3RvdHlwZS5yZW1vdmU9ZnVuY3Rpb24oYSl7YT10aGlzLm5vcm1hbGl6ZShhLCEwKSxhIT09ZCYmKHRoaXMudHJpZ2dlcihcInJlbW92ZVwiLHtjb250ZW50OnRoaXMuX2l0ZW1zW2FdLHBvc2l0aW9uOmF9KSx0aGlzLl9pdGVtc1thXS5yZW1vdmUoKSx0aGlzLl9pdGVtcy5zcGxpY2UoYSwxKSx0aGlzLl9tZXJnZXJzLnNwbGljZShhLDEpLHRoaXMuaW52YWxpZGF0ZShcIml0ZW1zXCIpLHRoaXMudHJpZ2dlcihcInJlbW92ZWRcIix7Y29udGVudDpudWxsLHBvc2l0aW9uOmF9KSl9LGUucHJvdG90eXBlLnByZWxvYWRBdXRvV2lkdGhJbWFnZXM9ZnVuY3Rpb24oYil7Yi5lYWNoKGEucHJveHkoZnVuY3Rpb24oYixjKXt0aGlzLmVudGVyKFwicHJlLWxvYWRpbmdcIiksYz1hKGMpLGEobmV3IEltYWdlKS5vbmUoXCJsb2FkXCIsYS5wcm94eShmdW5jdGlvbihhKXtjLmF0dHIoXCJzcmNcIixhLnRhcmdldC5zcmMpLGMuY3NzKFwib3BhY2l0eVwiLDEpLHRoaXMubGVhdmUoXCJwcmUtbG9hZGluZ1wiKSwhdGhpcy5pcyhcInByZS1sb2FkaW5nXCIpJiYhdGhpcy5pcyhcImluaXRpYWxpemluZ1wiKSYmdGhpcy5yZWZyZXNoKCl9LHRoaXMpKS5hdHRyKFwic3JjXCIsYy5hdHRyKFwic3JjXCIpfHxjLmF0dHIoXCJkYXRhLXNyY1wiKXx8Yy5hdHRyKFwiZGF0YS1zcmMtcmV0aW5hXCIpKX0sdGhpcykpfSxlLnByb3RvdHlwZS5kZXN0cm95PWZ1bmN0aW9uKCl7dGhpcy4kZWxlbWVudC5vZmYoXCIub3dsLmNvcmVcIiksdGhpcy4kc3RhZ2Uub2ZmKFwiLm93bC5jb3JlXCIpLGEoYykub2ZmKFwiLm93bC5jb3JlXCIpLHRoaXMuc2V0dGluZ3MucmVzcG9uc2l2ZSE9PSExJiYoYi5jbGVhclRpbWVvdXQodGhpcy5yZXNpemVUaW1lciksdGhpcy5vZmYoYixcInJlc2l6ZVwiLHRoaXMuX2hhbmRsZXJzLm9uVGhyb3R0bGVkUmVzaXplKSk7Zm9yKHZhciBkIGluIHRoaXMuX3BsdWdpbnMpdGhpcy5fcGx1Z2luc1tkXS5kZXN0cm95KCk7dGhpcy4kc3RhZ2UuY2hpbGRyZW4oXCIuY2xvbmVkXCIpLnJlbW92ZSgpLHRoaXMuJHN0YWdlLnVud3JhcCgpLHRoaXMuJHN0YWdlLmNoaWxkcmVuKCkuY29udGVudHMoKS51bndyYXAoKSx0aGlzLiRzdGFnZS5jaGlsZHJlbigpLnVud3JhcCgpLHRoaXMuJGVsZW1lbnQucmVtb3ZlQ2xhc3ModGhpcy5vcHRpb25zLnJlZnJlc2hDbGFzcykucmVtb3ZlQ2xhc3ModGhpcy5vcHRpb25zLmxvYWRpbmdDbGFzcykucmVtb3ZlQ2xhc3ModGhpcy5vcHRpb25zLmxvYWRlZENsYXNzKS5yZW1vdmVDbGFzcyh0aGlzLm9wdGlvbnMucnRsQ2xhc3MpLnJlbW92ZUNsYXNzKHRoaXMub3B0aW9ucy5kcmFnQ2xhc3MpLnJlbW92ZUNsYXNzKHRoaXMub3B0aW9ucy5ncmFiQ2xhc3MpLmF0dHIoXCJjbGFzc1wiLHRoaXMuJGVsZW1lbnQuYXR0cihcImNsYXNzXCIpLnJlcGxhY2UobmV3IFJlZ0V4cCh0aGlzLm9wdGlvbnMucmVzcG9uc2l2ZUNsYXNzK1wiLVxcXFxTK1xcXFxzXCIsXCJnXCIpLFwiXCIpKS5yZW1vdmVEYXRhKFwib3dsLmNhcm91c2VsXCIpfSxlLnByb3RvdHlwZS5vcD1mdW5jdGlvbihhLGIsYyl7dmFyIGQ9dGhpcy5zZXR0aW5ncy5ydGw7c3dpdGNoKGIpe2Nhc2VcIjxcIjpyZXR1cm4gZD9hPmM6YTxjO2Nhc2VcIj5cIjpyZXR1cm4gZD9hPGM6YT5jO2Nhc2VcIj49XCI6cmV0dXJuIGQ/YTw9YzphPj1jO2Nhc2VcIjw9XCI6cmV0dXJuIGQ/YT49YzphPD1jfX0sZS5wcm90b3R5cGUub249ZnVuY3Rpb24oYSxiLGMsZCl7YS5hZGRFdmVudExpc3RlbmVyP2EuYWRkRXZlbnRMaXN0ZW5lcihiLGMsZCk6YS5hdHRhY2hFdmVudCYmYS5hdHRhY2hFdmVudChcIm9uXCIrYixjKX0sZS5wcm90b3R5cGUub2ZmPWZ1bmN0aW9uKGEsYixjLGQpe2EucmVtb3ZlRXZlbnRMaXN0ZW5lcj9hLnJlbW92ZUV2ZW50TGlzdGVuZXIoYixjLGQpOmEuZGV0YWNoRXZlbnQmJmEuZGV0YWNoRXZlbnQoXCJvblwiK2IsYyl9LGUucHJvdG90eXBlLnRyaWdnZXI9ZnVuY3Rpb24oYixjLGQsZixnKXt2YXIgaD17aXRlbTp7Y291bnQ6dGhpcy5faXRlbXMubGVuZ3RoLGluZGV4OnRoaXMuY3VycmVudCgpfX0saT1hLmNhbWVsQ2FzZShhLmdyZXAoW1wib25cIixiLGRdLGZ1bmN0aW9uKGEpe3JldHVybiBhfSkuam9pbihcIi1cIikudG9Mb3dlckNhc2UoKSksaj1hLkV2ZW50KFtiLFwib3dsXCIsZHx8XCJjYXJvdXNlbFwiXS5qb2luKFwiLlwiKS50b0xvd2VyQ2FzZSgpLGEuZXh0ZW5kKHtyZWxhdGVkVGFyZ2V0OnRoaXN9LGgsYykpO3JldHVybiB0aGlzLl9zdXByZXNzW2JdfHwoYS5lYWNoKHRoaXMuX3BsdWdpbnMsZnVuY3Rpb24oYSxiKXtiLm9uVHJpZ2dlciYmYi5vblRyaWdnZXIoail9KSx0aGlzLnJlZ2lzdGVyKHt0eXBlOmUuVHlwZS5FdmVudCxuYW1lOmJ9KSx0aGlzLiRlbGVtZW50LnRyaWdnZXIoaiksdGhpcy5zZXR0aW5ncyYmXCJmdW5jdGlvblwiPT10eXBlb2YgdGhpcy5zZXR0aW5nc1tpXSYmdGhpcy5zZXR0aW5nc1tpXS5jYWxsKHRoaXMsaikpLGp9LGUucHJvdG90eXBlLmVudGVyPWZ1bmN0aW9uKGIpe2EuZWFjaChbYl0uY29uY2F0KHRoaXMuX3N0YXRlcy50YWdzW2JdfHxbXSksYS5wcm94eShmdW5jdGlvbihhLGIpe3RoaXMuX3N0YXRlcy5jdXJyZW50W2JdPT09ZCYmKHRoaXMuX3N0YXRlcy5jdXJyZW50W2JdPTApLHRoaXMuX3N0YXRlcy5jdXJyZW50W2JdKyt9LHRoaXMpKX0sZS5wcm90b3R5cGUubGVhdmU9ZnVuY3Rpb24oYil7YS5lYWNoKFtiXS5jb25jYXQodGhpcy5fc3RhdGVzLnRhZ3NbYl18fFtdKSxhLnByb3h5KGZ1bmN0aW9uKGEsYil7dGhpcy5fc3RhdGVzLmN1cnJlbnRbYl0tLX0sdGhpcykpfSxlLnByb3RvdHlwZS5yZWdpc3Rlcj1mdW5jdGlvbihiKXtpZihiLnR5cGU9PT1lLlR5cGUuRXZlbnQpe2lmKGEuZXZlbnQuc3BlY2lhbFtiLm5hbWVdfHwoYS5ldmVudC5zcGVjaWFsW2IubmFtZV09e30pLCFhLmV2ZW50LnNwZWNpYWxbYi5uYW1lXS5vd2wpe3ZhciBjPWEuZXZlbnQuc3BlY2lhbFtiLm5hbWVdLl9kZWZhdWx0O2EuZXZlbnQuc3BlY2lhbFtiLm5hbWVdLl9kZWZhdWx0PWZ1bmN0aW9uKGEpe3JldHVybiFjfHwhYy5hcHBseXx8YS5uYW1lc3BhY2UmJmEubmFtZXNwYWNlLmluZGV4T2YoXCJvd2xcIikhPT0tMT9hLm5hbWVzcGFjZSYmYS5uYW1lc3BhY2UuaW5kZXhPZihcIm93bFwiKT4tMTpjLmFwcGx5KHRoaXMsYXJndW1lbnRzKX0sYS5ldmVudC5zcGVjaWFsW2IubmFtZV0ub3dsPSEwfX1lbHNlIGIudHlwZT09PWUuVHlwZS5TdGF0ZSYmKHRoaXMuX3N0YXRlcy50YWdzW2IubmFtZV0/dGhpcy5fc3RhdGVzLnRhZ3NbYi5uYW1lXT10aGlzLl9zdGF0ZXMudGFnc1tiLm5hbWVdLmNvbmNhdChiLnRhZ3MpOnRoaXMuX3N0YXRlcy50YWdzW2IubmFtZV09Yi50YWdzLHRoaXMuX3N0YXRlcy50YWdzW2IubmFtZV09YS5ncmVwKHRoaXMuX3N0YXRlcy50YWdzW2IubmFtZV0sYS5wcm94eShmdW5jdGlvbihjLGQpe3JldHVybiBhLmluQXJyYXkoYyx0aGlzLl9zdGF0ZXMudGFnc1tiLm5hbWVdKT09PWR9LHRoaXMpKSl9LGUucHJvdG90eXBlLnN1cHByZXNzPWZ1bmN0aW9uKGIpe2EuZWFjaChiLGEucHJveHkoZnVuY3Rpb24oYSxiKXt0aGlzLl9zdXByZXNzW2JdPSEwfSx0aGlzKSl9LGUucHJvdG90eXBlLnJlbGVhc2U9ZnVuY3Rpb24oYil7YS5lYWNoKGIsYS5wcm94eShmdW5jdGlvbihhLGIpe2RlbGV0ZSB0aGlzLl9zdXByZXNzW2JdfSx0aGlzKSl9LGUucHJvdG90eXBlLnBvaW50ZXI9ZnVuY3Rpb24oYSl7dmFyIGM9e3g6bnVsbCx5Om51bGx9O3JldHVybiBhPWEub3JpZ2luYWxFdmVudHx8YXx8Yi5ldmVudCxhPWEudG91Y2hlcyYmYS50b3VjaGVzLmxlbmd0aD9hLnRvdWNoZXNbMF06YS5jaGFuZ2VkVG91Y2hlcyYmYS5jaGFuZ2VkVG91Y2hlcy5sZW5ndGg/YS5jaGFuZ2VkVG91Y2hlc1swXTphLGEucGFnZVg/KGMueD1hLnBhZ2VYLGMueT1hLnBhZ2VZKTooYy54PWEuY2xpZW50WCxjLnk9YS5jbGllbnRZKSxjfSxlLnByb3RvdHlwZS5pc051bWVyaWM9ZnVuY3Rpb24oYSl7cmV0dXJuIWlzTmFOKHBhcnNlRmxvYXQoYSkpfSxlLnByb3RvdHlwZS5kaWZmZXJlbmNlPWZ1bmN0aW9uKGEsYil7cmV0dXJue3g6YS54LWIueCx5OmEueS1iLnl9fSxhLmZuLm93bENhcm91c2VsPWZ1bmN0aW9uKGIpe3ZhciBjPUFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cywxKTtyZXR1cm4gdGhpcy5lYWNoKGZ1bmN0aW9uKCl7dmFyIGQ9YSh0aGlzKSxmPWQuZGF0YShcIm93bC5jYXJvdXNlbFwiKTtmfHwoZj1uZXcgZSh0aGlzLFwib2JqZWN0XCI9PXR5cGVvZiBiJiZiKSxkLmRhdGEoXCJvd2wuY2Fyb3VzZWxcIixmKSxhLmVhY2goW1wibmV4dFwiLFwicHJldlwiLFwidG9cIixcImRlc3Ryb3lcIixcInJlZnJlc2hcIixcInJlcGxhY2VcIixcImFkZFwiLFwicmVtb3ZlXCJdLGZ1bmN0aW9uKGIsYyl7Zi5yZWdpc3Rlcih7dHlwZTplLlR5cGUuRXZlbnQsbmFtZTpjfSksZi4kZWxlbWVudC5vbihjK1wiLm93bC5jYXJvdXNlbC5jb3JlXCIsYS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmYS5yZWxhdGVkVGFyZ2V0IT09dGhpcyYmKHRoaXMuc3VwcHJlc3MoW2NdKSxmW2NdLmFwcGx5KHRoaXMsW10uc2xpY2UuY2FsbChhcmd1bWVudHMsMSkpLHRoaXMucmVsZWFzZShbY10pKX0sZikpfSkpLFwic3RyaW5nXCI9PXR5cGVvZiBiJiZcIl9cIiE9PWIuY2hhckF0KDApJiZmW2JdLmFwcGx5KGYsYyl9KX0sYS5mbi5vd2xDYXJvdXNlbC5Db25zdHJ1Y3Rvcj1lfSh3aW5kb3cuWmVwdG98fHdpbmRvdy5qUXVlcnksd2luZG93LGRvY3VtZW50KSxmdW5jdGlvbihhLGIsYyxkKXt2YXIgZT1mdW5jdGlvbihiKXt0aGlzLl9jb3JlPWIsdGhpcy5faW50ZXJ2YWw9bnVsbCx0aGlzLl92aXNpYmxlPW51bGwsdGhpcy5faGFuZGxlcnM9e1wiaW5pdGlhbGl6ZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmdGhpcy5fY29yZS5zZXR0aW5ncy5hdXRvUmVmcmVzaCYmdGhpcy53YXRjaCgpfSx0aGlzKX0sdGhpcy5fY29yZS5vcHRpb25zPWEuZXh0ZW5kKHt9LGUuRGVmYXVsdHMsdGhpcy5fY29yZS5vcHRpb25zKSx0aGlzLl9jb3JlLiRlbGVtZW50Lm9uKHRoaXMuX2hhbmRsZXJzKX07ZS5EZWZhdWx0cz17YXV0b1JlZnJlc2g6ITAsYXV0b1JlZnJlc2hJbnRlcnZhbDo1MDB9LGUucHJvdG90eXBlLndhdGNoPWZ1bmN0aW9uKCl7dGhpcy5faW50ZXJ2YWx8fCh0aGlzLl92aXNpYmxlPXRoaXMuX2NvcmUuJGVsZW1lbnQuaXMoXCI6dmlzaWJsZVwiKSx0aGlzLl9pbnRlcnZhbD1iLnNldEludGVydmFsKGEucHJveHkodGhpcy5yZWZyZXNoLHRoaXMpLHRoaXMuX2NvcmUuc2V0dGluZ3MuYXV0b1JlZnJlc2hJbnRlcnZhbCkpfSxlLnByb3RvdHlwZS5yZWZyZXNoPWZ1bmN0aW9uKCl7dGhpcy5fY29yZS4kZWxlbWVudC5pcyhcIjp2aXNpYmxlXCIpIT09dGhpcy5fdmlzaWJsZSYmKHRoaXMuX3Zpc2libGU9IXRoaXMuX3Zpc2libGUsdGhpcy5fY29yZS4kZWxlbWVudC50b2dnbGVDbGFzcyhcIm93bC1oaWRkZW5cIiwhdGhpcy5fdmlzaWJsZSksdGhpcy5fdmlzaWJsZSYmdGhpcy5fY29yZS5pbnZhbGlkYXRlKFwid2lkdGhcIikmJnRoaXMuX2NvcmUucmVmcmVzaCgpKX0sZS5wcm90b3R5cGUuZGVzdHJveT1mdW5jdGlvbigpe3ZhciBhLGM7Yi5jbGVhckludGVydmFsKHRoaXMuX2ludGVydmFsKTtmb3IoYSBpbiB0aGlzLl9oYW5kbGVycyl0aGlzLl9jb3JlLiRlbGVtZW50Lm9mZihhLHRoaXMuX2hhbmRsZXJzW2FdKTtmb3IoYyBpbiBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh0aGlzKSlcImZ1bmN0aW9uXCIhPXR5cGVvZiB0aGlzW2NdJiYodGhpc1tjXT1udWxsKX0sYS5mbi5vd2xDYXJvdXNlbC5Db25zdHJ1Y3Rvci5QbHVnaW5zLkF1dG9SZWZyZXNoPWV9KHdpbmRvdy5aZXB0b3x8d2luZG93LmpRdWVyeSx3aW5kb3csZG9jdW1lbnQpLGZ1bmN0aW9uKGEsYixjLGQpe3ZhciBlPWZ1bmN0aW9uKGIpe3RoaXMuX2NvcmU9Yix0aGlzLl9sb2FkZWQ9W10sdGhpcy5faGFuZGxlcnM9e1wiaW5pdGlhbGl6ZWQub3dsLmNhcm91c2VsIGNoYW5nZS5vd2wuY2Fyb3VzZWwgcmVzaXplZC5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGIpe2lmKGIubmFtZXNwYWNlJiZ0aGlzLl9jb3JlLnNldHRpbmdzJiZ0aGlzLl9jb3JlLnNldHRpbmdzLmxhenlMb2FkJiYoYi5wcm9wZXJ0eSYmXCJwb3NpdGlvblwiPT1iLnByb3BlcnR5Lm5hbWV8fFwiaW5pdGlhbGl6ZWRcIj09Yi50eXBlKSlmb3IodmFyIGM9dGhpcy5fY29yZS5zZXR0aW5ncyxlPWMuY2VudGVyJiZNYXRoLmNlaWwoYy5pdGVtcy8yKXx8Yy5pdGVtcyxmPWMuY2VudGVyJiZlKi0xfHwwLGc9KGIucHJvcGVydHkmJmIucHJvcGVydHkudmFsdWUhPT1kP2IucHJvcGVydHkudmFsdWU6dGhpcy5fY29yZS5jdXJyZW50KCkpK2YsaD10aGlzLl9jb3JlLmNsb25lcygpLmxlbmd0aCxpPWEucHJveHkoZnVuY3Rpb24oYSxiKXt0aGlzLmxvYWQoYil9LHRoaXMpO2YrKzxlOyl0aGlzLmxvYWQoaC8yK3RoaXMuX2NvcmUucmVsYXRpdmUoZykpLGgmJmEuZWFjaCh0aGlzLl9jb3JlLmNsb25lcyh0aGlzLl9jb3JlLnJlbGF0aXZlKGcpKSxpKSxnKyt9LHRoaXMpfSx0aGlzLl9jb3JlLm9wdGlvbnM9YS5leHRlbmQoe30sZS5EZWZhdWx0cyx0aGlzLl9jb3JlLm9wdGlvbnMpLHRoaXMuX2NvcmUuJGVsZW1lbnQub24odGhpcy5faGFuZGxlcnMpfTtlLkRlZmF1bHRzPXtsYXp5TG9hZDohMX0sZS5wcm90b3R5cGUubG9hZD1mdW5jdGlvbihjKXt2YXIgZD10aGlzLl9jb3JlLiRzdGFnZS5jaGlsZHJlbigpLmVxKGMpLGU9ZCYmZC5maW5kKFwiLm93bC1sYXp5XCIpOyFlfHxhLmluQXJyYXkoZC5nZXQoMCksdGhpcy5fbG9hZGVkKT4tMXx8KGUuZWFjaChhLnByb3h5KGZ1bmN0aW9uKGMsZCl7dmFyIGUsZj1hKGQpLGc9Yi5kZXZpY2VQaXhlbFJhdGlvPjEmJmYuYXR0cihcImRhdGEtc3JjLXJldGluYVwiKXx8Zi5hdHRyKFwiZGF0YS1zcmNcIik7dGhpcy5fY29yZS50cmlnZ2VyKFwibG9hZFwiLHtlbGVtZW50OmYsdXJsOmd9LFwibGF6eVwiKSxmLmlzKFwiaW1nXCIpP2Yub25lKFwibG9hZC5vd2wubGF6eVwiLGEucHJveHkoZnVuY3Rpb24oKXtmLmNzcyhcIm9wYWNpdHlcIiwxKSx0aGlzLl9jb3JlLnRyaWdnZXIoXCJsb2FkZWRcIix7ZWxlbWVudDpmLHVybDpnfSxcImxhenlcIil9LHRoaXMpKS5hdHRyKFwic3JjXCIsZyk6KGU9bmV3IEltYWdlLGUub25sb2FkPWEucHJveHkoZnVuY3Rpb24oKXtmLmNzcyh7XCJiYWNrZ3JvdW5kLWltYWdlXCI6J3VybChcIicrZysnXCIpJyxvcGFjaXR5OlwiMVwifSksdGhpcy5fY29yZS50cmlnZ2VyKFwibG9hZGVkXCIse2VsZW1lbnQ6Zix1cmw6Z30sXCJsYXp5XCIpfSx0aGlzKSxlLnNyYz1nKX0sdGhpcykpLHRoaXMuX2xvYWRlZC5wdXNoKGQuZ2V0KDApKSl9LGUucHJvdG90eXBlLmRlc3Ryb3k9ZnVuY3Rpb24oKXt2YXIgYSxiO2ZvcihhIGluIHRoaXMuaGFuZGxlcnMpdGhpcy5fY29yZS4kZWxlbWVudC5vZmYoYSx0aGlzLmhhbmRsZXJzW2FdKTtmb3IoYiBpbiBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh0aGlzKSlcImZ1bmN0aW9uXCIhPXR5cGVvZiB0aGlzW2JdJiYodGhpc1tiXT1udWxsKX0sYS5mbi5vd2xDYXJvdXNlbC5Db25zdHJ1Y3Rvci5QbHVnaW5zLkxhenk9ZX0od2luZG93LlplcHRvfHx3aW5kb3cualF1ZXJ5LHdpbmRvdyxkb2N1bWVudCksZnVuY3Rpb24oYSxiLGMsZCl7dmFyIGU9ZnVuY3Rpb24oYil7dGhpcy5fY29yZT1iLHRoaXMuX2hhbmRsZXJzPXtcImluaXRpYWxpemVkLm93bC5jYXJvdXNlbCByZWZyZXNoZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmdGhpcy5fY29yZS5zZXR0aW5ncy5hdXRvSGVpZ2h0JiZ0aGlzLnVwZGF0ZSgpfSx0aGlzKSxcImNoYW5nZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmdGhpcy5fY29yZS5zZXR0aW5ncy5hdXRvSGVpZ2h0JiZcInBvc2l0aW9uXCI9PWEucHJvcGVydHkubmFtZSYmdGhpcy51cGRhdGUoKX0sdGhpcyksXCJsb2FkZWQub3dsLmxhenlcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiZ0aGlzLl9jb3JlLnNldHRpbmdzLmF1dG9IZWlnaHQmJmEuZWxlbWVudC5jbG9zZXN0KFwiLlwiK3RoaXMuX2NvcmUuc2V0dGluZ3MuaXRlbUNsYXNzKS5pbmRleCgpPT09dGhpcy5fY29yZS5jdXJyZW50KCkmJnRoaXMudXBkYXRlKCl9LHRoaXMpfSx0aGlzLl9jb3JlLm9wdGlvbnM9YS5leHRlbmQoe30sZS5EZWZhdWx0cyx0aGlzLl9jb3JlLm9wdGlvbnMpLHRoaXMuX2NvcmUuJGVsZW1lbnQub24odGhpcy5faGFuZGxlcnMpfTtlLkRlZmF1bHRzPXthdXRvSGVpZ2h0OiExLGF1dG9IZWlnaHRDbGFzczpcIm93bC1oZWlnaHRcIn0sZS5wcm90b3R5cGUudXBkYXRlPWZ1bmN0aW9uKCl7dmFyIGI9dGhpcy5fY29yZS5fY3VycmVudCxjPWIrdGhpcy5fY29yZS5zZXR0aW5ncy5pdGVtcyxkPXRoaXMuX2NvcmUuJHN0YWdlLmNoaWxkcmVuKCkudG9BcnJheSgpLnNsaWNlKGIsYyksZT1bXSxmPTA7YS5lYWNoKGQsZnVuY3Rpb24oYixjKXtlLnB1c2goYShjKS5oZWlnaHQoKSl9KSxmPU1hdGgubWF4LmFwcGx5KG51bGwsZSksdGhpcy5fY29yZS4kc3RhZ2UucGFyZW50KCkuaGVpZ2h0KGYpLmFkZENsYXNzKHRoaXMuX2NvcmUuc2V0dGluZ3MuYXV0b0hlaWdodENsYXNzKX0sZS5wcm90b3R5cGUuZGVzdHJveT1mdW5jdGlvbigpe3ZhciBhLGI7Zm9yKGEgaW4gdGhpcy5faGFuZGxlcnMpdGhpcy5fY29yZS4kZWxlbWVudC5vZmYoYSx0aGlzLl9oYW5kbGVyc1thXSk7Zm9yKGIgaW4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGhpcykpXCJmdW5jdGlvblwiIT10eXBlb2YgdGhpc1tiXSYmKHRoaXNbYl09bnVsbCl9LGEuZm4ub3dsQ2Fyb3VzZWwuQ29uc3RydWN0b3IuUGx1Z2lucy5BdXRvSGVpZ2h0PWV9KHdpbmRvdy5aZXB0b3x8d2luZG93LmpRdWVyeSx3aW5kb3csZG9jdW1lbnQpLGZ1bmN0aW9uKGEsYixjLGQpe3ZhciBlPWZ1bmN0aW9uKGIpe3RoaXMuX2NvcmU9Yix0aGlzLl92aWRlb3M9e30sdGhpcy5fcGxheWluZz1udWxsLHRoaXMuX2hhbmRsZXJzPXtcImluaXRpYWxpemVkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJnRoaXMuX2NvcmUucmVnaXN0ZXIoe3R5cGU6XCJzdGF0ZVwiLG5hbWU6XCJwbGF5aW5nXCIsdGFnczpbXCJpbnRlcmFjdGluZ1wiXX0pfSx0aGlzKSxcInJlc2l6ZS5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiZ0aGlzLl9jb3JlLnNldHRpbmdzLnZpZGVvJiZ0aGlzLmlzSW5GdWxsU2NyZWVuKCkmJmEucHJldmVudERlZmF1bHQoKX0sdGhpcyksXCJyZWZyZXNoZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmdGhpcy5fY29yZS5pcyhcInJlc2l6aW5nXCIpJiZ0aGlzLl9jb3JlLiRzdGFnZS5maW5kKFwiLmNsb25lZCAub3dsLXZpZGVvLWZyYW1lXCIpLnJlbW92ZSgpfSx0aGlzKSxcImNoYW5nZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmXCJwb3NpdGlvblwiPT09YS5wcm9wZXJ0eS5uYW1lJiZ0aGlzLl9wbGF5aW5nJiZ0aGlzLnN0b3AoKX0sdGhpcyksXCJwcmVwYXJlZC5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGIpe2lmKGIubmFtZXNwYWNlKXt2YXIgYz1hKGIuY29udGVudCkuZmluZChcIi5vd2wtdmlkZW9cIik7Yy5sZW5ndGgmJihjLmNzcyhcImRpc3BsYXlcIixcIm5vbmVcIiksdGhpcy5mZXRjaChjLGEoYi5jb250ZW50KSkpfX0sdGhpcyl9LHRoaXMuX2NvcmUub3B0aW9ucz1hLmV4dGVuZCh7fSxlLkRlZmF1bHRzLHRoaXMuX2NvcmUub3B0aW9ucyksdGhpcy5fY29yZS4kZWxlbWVudC5vbih0aGlzLl9oYW5kbGVycyksdGhpcy5fY29yZS4kZWxlbWVudC5vbihcImNsaWNrLm93bC52aWRlb1wiLFwiLm93bC12aWRlby1wbGF5LWljb25cIixhLnByb3h5KGZ1bmN0aW9uKGEpe3RoaXMucGxheShhKX0sdGhpcykpfTtlLkRlZmF1bHRzPXt2aWRlbzohMSx2aWRlb0hlaWdodDohMSx2aWRlb1dpZHRoOiExfSxlLnByb3RvdHlwZS5mZXRjaD1mdW5jdGlvbihhLGIpe3ZhciBjPWZ1bmN0aW9uKCl7cmV0dXJuIGEuYXR0cihcImRhdGEtdmltZW8taWRcIik/XCJ2aW1lb1wiOmEuYXR0cihcImRhdGEtdnphYXItaWRcIik/XCJ2emFhclwiOlwieW91dHViZVwifSgpLGQ9YS5hdHRyKFwiZGF0YS12aW1lby1pZFwiKXx8YS5hdHRyKFwiZGF0YS15b3V0dWJlLWlkXCIpfHxhLmF0dHIoXCJkYXRhLXZ6YWFyLWlkXCIpLGU9YS5hdHRyKFwiZGF0YS13aWR0aFwiKXx8dGhpcy5fY29yZS5zZXR0aW5ncy52aWRlb1dpZHRoLGY9YS5hdHRyKFwiZGF0YS1oZWlnaHRcIil8fHRoaXMuX2NvcmUuc2V0dGluZ3MudmlkZW9IZWlnaHQsZz1hLmF0dHIoXCJocmVmXCIpO2lmKCFnKXRocm93IG5ldyBFcnJvcihcIk1pc3NpbmcgdmlkZW8gVVJMLlwiKTtpZihkPWcubWF0Y2goLyhodHRwOnxodHRwczp8KVxcL1xcLyhwbGF5ZXIufHd3dy58YXBwLik/KHZpbWVvXFwuY29tfHlvdXR1KGJlXFwuY29tfFxcLmJlfGJlXFwuZ29vZ2xlYXBpc1xcLmNvbSl8dnphYXJcXC5jb20pXFwvKHZpZGVvXFwvfHZpZGVvc1xcL3xlbWJlZFxcL3xjaGFubmVsc1xcLy4rXFwvfGdyb3Vwc1xcLy4rXFwvfHdhdGNoXFw/dj18dlxcLyk/KFtBLVphLXowLTkuXyUtXSopKFxcJlxcUyspPy8pLGRbM10uaW5kZXhPZihcInlvdXR1XCIpPi0xKWM9XCJ5b3V0dWJlXCI7ZWxzZSBpZihkWzNdLmluZGV4T2YoXCJ2aW1lb1wiKT4tMSljPVwidmltZW9cIjtlbHNle2lmKCEoZFszXS5pbmRleE9mKFwidnphYXJcIik+LTEpKXRocm93IG5ldyBFcnJvcihcIlZpZGVvIFVSTCBub3Qgc3VwcG9ydGVkLlwiKTtjPVwidnphYXJcIn1kPWRbNl0sdGhpcy5fdmlkZW9zW2ddPXt0eXBlOmMsaWQ6ZCx3aWR0aDplLGhlaWdodDpmfSxiLmF0dHIoXCJkYXRhLXZpZGVvXCIsZyksdGhpcy50aHVtYm5haWwoYSx0aGlzLl92aWRlb3NbZ10pfSxlLnByb3RvdHlwZS50aHVtYm5haWw9ZnVuY3Rpb24oYixjKXt2YXIgZCxlLGYsZz1jLndpZHRoJiZjLmhlaWdodD8nc3R5bGU9XCJ3aWR0aDonK2Mud2lkdGgrXCJweDtoZWlnaHQ6XCIrYy5oZWlnaHQrJ3B4O1wiJzpcIlwiLGg9Yi5maW5kKFwiaW1nXCIpLGk9XCJzcmNcIixqPVwiXCIsaz10aGlzLl9jb3JlLnNldHRpbmdzLGw9ZnVuY3Rpb24oYSl7ZT0nPGRpdiBjbGFzcz1cIm93bC12aWRlby1wbGF5LWljb25cIj48L2Rpdj4nLGQ9ay5sYXp5TG9hZD8nPGRpdiBjbGFzcz1cIm93bC12aWRlby10biAnK2orJ1wiICcraSsnPVwiJythKydcIj48L2Rpdj4nOic8ZGl2IGNsYXNzPVwib3dsLXZpZGVvLXRuXCIgc3R5bGU9XCJvcGFjaXR5OjE7YmFja2dyb3VuZC1pbWFnZTp1cmwoJythKycpXCI+PC9kaXY+JyxiLmFmdGVyKGQpLGIuYWZ0ZXIoZSl9O2lmKGIud3JhcCgnPGRpdiBjbGFzcz1cIm93bC12aWRlby13cmFwcGVyXCInK2crXCI+PC9kaXY+XCIpLHRoaXMuX2NvcmUuc2V0dGluZ3MubGF6eUxvYWQmJihpPVwiZGF0YS1zcmNcIixqPVwib3dsLWxhenlcIiksaC5sZW5ndGgpcmV0dXJuIGwoaC5hdHRyKGkpKSxoLnJlbW92ZSgpLCExO1wieW91dHViZVwiPT09Yy50eXBlPyhmPVwiLy9pbWcueW91dHViZS5jb20vdmkvXCIrYy5pZCtcIi9ocWRlZmF1bHQuanBnXCIsbChmKSk6XCJ2aW1lb1wiPT09Yy50eXBlP2EuYWpheCh7dHlwZTpcIkdFVFwiLHVybDpcIi8vdmltZW8uY29tL2FwaS92Mi92aWRlby9cIitjLmlkK1wiLmpzb25cIixqc29ucDpcImNhbGxiYWNrXCIsZGF0YVR5cGU6XCJqc29ucFwiLHN1Y2Nlc3M6ZnVuY3Rpb24oYSl7Zj1hWzBdLnRodW1ibmFpbF9sYXJnZSxsKGYpfX0pOlwidnphYXJcIj09PWMudHlwZSYmYS5hamF4KHt0eXBlOlwiR0VUXCIsdXJsOlwiLy92emFhci5jb20vYXBpL3ZpZGVvcy9cIitjLmlkK1wiLmpzb25cIixqc29ucDpcImNhbGxiYWNrXCIsZGF0YVR5cGU6XCJqc29ucFwiLHN1Y2Nlc3M6ZnVuY3Rpb24oYSl7Zj1hLmZyYW1lZ3JhYl91cmwsbChmKX19KX0sZS5wcm90b3R5cGUuc3RvcD1mdW5jdGlvbigpe3RoaXMuX2NvcmUudHJpZ2dlcihcInN0b3BcIixudWxsLFwidmlkZW9cIiksdGhpcy5fcGxheWluZy5maW5kKFwiLm93bC12aWRlby1mcmFtZVwiKS5yZW1vdmUoKSx0aGlzLl9wbGF5aW5nLnJlbW92ZUNsYXNzKFwib3dsLXZpZGVvLXBsYXlpbmdcIiksdGhpcy5fcGxheWluZz1udWxsLHRoaXMuX2NvcmUubGVhdmUoXCJwbGF5aW5nXCIpLHRoaXMuX2NvcmUudHJpZ2dlcihcInN0b3BwZWRcIixudWxsLFwidmlkZW9cIil9LGUucHJvdG90eXBlLnBsYXk9ZnVuY3Rpb24oYil7dmFyIGMsZD1hKGIudGFyZ2V0KSxlPWQuY2xvc2VzdChcIi5cIit0aGlzLl9jb3JlLnNldHRpbmdzLml0ZW1DbGFzcyksZj10aGlzLl92aWRlb3NbZS5hdHRyKFwiZGF0YS12aWRlb1wiKV0sZz1mLndpZHRofHxcIjEwMCVcIixoPWYuaGVpZ2h0fHx0aGlzLl9jb3JlLiRzdGFnZS5oZWlnaHQoKTt0aGlzLl9wbGF5aW5nfHwodGhpcy5fY29yZS5lbnRlcihcInBsYXlpbmdcIiksdGhpcy5fY29yZS50cmlnZ2VyKFwicGxheVwiLG51bGwsXCJ2aWRlb1wiKSxlPXRoaXMuX2NvcmUuaXRlbXModGhpcy5fY29yZS5yZWxhdGl2ZShlLmluZGV4KCkpKSx0aGlzLl9jb3JlLnJlc2V0KGUuaW5kZXgoKSksXCJ5b3V0dWJlXCI9PT1mLnR5cGU/Yz0nPGlmcmFtZSB3aWR0aD1cIicrZysnXCIgaGVpZ2h0PVwiJytoKydcIiBzcmM9XCIvL3d3dy55b3V0dWJlLmNvbS9lbWJlZC8nK2YuaWQrXCI/YXV0b3BsYXk9MSZyZWw9MCZ2PVwiK2YuaWQrJ1wiIGZyYW1lYm9yZGVyPVwiMFwiIGFsbG93ZnVsbHNjcmVlbj48L2lmcmFtZT4nOlwidmltZW9cIj09PWYudHlwZT9jPSc8aWZyYW1lIHNyYz1cIi8vcGxheWVyLnZpbWVvLmNvbS92aWRlby8nK2YuaWQrJz9hdXRvcGxheT0xXCIgd2lkdGg9XCInK2crJ1wiIGhlaWdodD1cIicraCsnXCIgZnJhbWVib3JkZXI9XCIwXCIgd2Via2l0YWxsb3dmdWxsc2NyZWVuIG1vemFsbG93ZnVsbHNjcmVlbiBhbGxvd2Z1bGxzY3JlZW4+PC9pZnJhbWU+JzpcInZ6YWFyXCI9PT1mLnR5cGUmJihjPSc8aWZyYW1lIGZyYW1lYm9yZGVyPVwiMFwiaGVpZ2h0PVwiJytoKydcIndpZHRoPVwiJytnKydcIiBhbGxvd2Z1bGxzY3JlZW4gbW96YWxsb3dmdWxsc2NyZWVuIHdlYmtpdEFsbG93RnVsbFNjcmVlbiBzcmM9XCIvL3ZpZXcudnphYXIuY29tLycrZi5pZCsnL3BsYXllcj9hdXRvcGxheT10cnVlXCI+PC9pZnJhbWU+JyksYSgnPGRpdiBjbGFzcz1cIm93bC12aWRlby1mcmFtZVwiPicrYytcIjwvZGl2PlwiKS5pbnNlcnRBZnRlcihlLmZpbmQoXCIub3dsLXZpZGVvXCIpKSx0aGlzLl9wbGF5aW5nPWUuYWRkQ2xhc3MoXCJvd2wtdmlkZW8tcGxheWluZ1wiKSl9LGUucHJvdG90eXBlLmlzSW5GdWxsU2NyZWVuPWZ1bmN0aW9uKCl7dmFyIGI9Yy5mdWxsc2NyZWVuRWxlbWVudHx8Yy5tb3pGdWxsU2NyZWVuRWxlbWVudHx8Yy53ZWJraXRGdWxsc2NyZWVuRWxlbWVudDtyZXR1cm4gYiYmYShiKS5wYXJlbnQoKS5oYXNDbGFzcyhcIm93bC12aWRlby1mcmFtZVwiKX0sZS5wcm90b3R5cGUuZGVzdHJveT1mdW5jdGlvbigpe3ZhciBhLGI7dGhpcy5fY29yZS4kZWxlbWVudC5vZmYoXCJjbGljay5vd2wudmlkZW9cIik7Zm9yKGEgaW4gdGhpcy5faGFuZGxlcnMpdGhpcy5fY29yZS4kZWxlbWVudC5vZmYoYSx0aGlzLl9oYW5kbGVyc1thXSk7Zm9yKGIgaW4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGhpcykpXCJmdW5jdGlvblwiIT10eXBlb2YgdGhpc1tiXSYmKHRoaXNbYl09bnVsbCl9LGEuZm4ub3dsQ2Fyb3VzZWwuQ29uc3RydWN0b3IuUGx1Z2lucy5WaWRlbz1lfSh3aW5kb3cuWmVwdG98fHdpbmRvdy5qUXVlcnksd2luZG93LGRvY3VtZW50KSxmdW5jdGlvbihhLGIsYyxkKXt2YXIgZT1mdW5jdGlvbihiKXt0aGlzLmNvcmU9Yix0aGlzLmNvcmUub3B0aW9ucz1hLmV4dGVuZCh7fSxlLkRlZmF1bHRzLHRoaXMuY29yZS5vcHRpb25zKSx0aGlzLnN3YXBwaW5nPSEwLHRoaXMucHJldmlvdXM9ZCx0aGlzLm5leHQ9ZCx0aGlzLmhhbmRsZXJzPXtcImNoYW5nZS5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiZcInBvc2l0aW9uXCI9PWEucHJvcGVydHkubmFtZSYmKHRoaXMucHJldmlvdXM9dGhpcy5jb3JlLmN1cnJlbnQoKSx0aGlzLm5leHQ9YS5wcm9wZXJ0eS52YWx1ZSl9LHRoaXMpLFwiZHJhZy5vd2wuY2Fyb3VzZWwgZHJhZ2dlZC5vd2wuY2Fyb3VzZWwgdHJhbnNsYXRlZC5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiYodGhpcy5zd2FwcGluZz1cInRyYW5zbGF0ZWRcIj09YS50eXBlKX0sdGhpcyksXCJ0cmFuc2xhdGUub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmdGhpcy5zd2FwcGluZyYmKHRoaXMuY29yZS5vcHRpb25zLmFuaW1hdGVPdXR8fHRoaXMuY29yZS5vcHRpb25zLmFuaW1hdGVJbikmJnRoaXMuc3dhcCgpfSx0aGlzKX0sdGhpcy5jb3JlLiRlbGVtZW50Lm9uKHRoaXMuaGFuZGxlcnMpfTtlLkRlZmF1bHRzPXthbmltYXRlT3V0OiExLGFuaW1hdGVJbjohMX0sZS5wcm90b3R5cGUuc3dhcD1mdW5jdGlvbigpe2lmKDE9PT10aGlzLmNvcmUuc2V0dGluZ3MuaXRlbXMmJmEuc3VwcG9ydC5hbmltYXRpb24mJmEuc3VwcG9ydC50cmFuc2l0aW9uKXt0aGlzLmNvcmUuc3BlZWQoMCk7dmFyIGIsYz1hLnByb3h5KHRoaXMuY2xlYXIsdGhpcyksZD10aGlzLmNvcmUuJHN0YWdlLmNoaWxkcmVuKCkuZXEodGhpcy5wcmV2aW91cyksZT10aGlzLmNvcmUuJHN0YWdlLmNoaWxkcmVuKCkuZXEodGhpcy5uZXh0KSxmPXRoaXMuY29yZS5zZXR0aW5ncy5hbmltYXRlSW4sZz10aGlzLmNvcmUuc2V0dGluZ3MuYW5pbWF0ZU91dDt0aGlzLmNvcmUuY3VycmVudCgpIT09dGhpcy5wcmV2aW91cyYmKGcmJihiPXRoaXMuY29yZS5jb29yZGluYXRlcyh0aGlzLnByZXZpb3VzKS10aGlzLmNvcmUuY29vcmRpbmF0ZXModGhpcy5uZXh0KSxkLm9uZShhLnN1cHBvcnQuYW5pbWF0aW9uLmVuZCxjKS5jc3Moe2xlZnQ6YitcInB4XCJ9KS5hZGRDbGFzcyhcImFuaW1hdGVkIG93bC1hbmltYXRlZC1vdXRcIikuYWRkQ2xhc3MoZykpLGYmJmUub25lKGEuc3VwcG9ydC5hbmltYXRpb24uZW5kLGMpLmFkZENsYXNzKFwiYW5pbWF0ZWQgb3dsLWFuaW1hdGVkLWluXCIpLmFkZENsYXNzKGYpKX19LGUucHJvdG90eXBlLmNsZWFyPWZ1bmN0aW9uKGIpe2EoYi50YXJnZXQpLmNzcyh7bGVmdDpcIlwifSkucmVtb3ZlQ2xhc3MoXCJhbmltYXRlZCBvd2wtYW5pbWF0ZWQtb3V0IG93bC1hbmltYXRlZC1pblwiKS5yZW1vdmVDbGFzcyh0aGlzLmNvcmUuc2V0dGluZ3MuYW5pbWF0ZUluKS5yZW1vdmVDbGFzcyh0aGlzLmNvcmUuc2V0dGluZ3MuYW5pbWF0ZU91dCksdGhpcy5jb3JlLm9uVHJhbnNpdGlvbkVuZCgpfSxlLnByb3RvdHlwZS5kZXN0cm95PWZ1bmN0aW9uKCl7dmFyIGEsYjtmb3IoYSBpbiB0aGlzLmhhbmRsZXJzKXRoaXMuY29yZS4kZWxlbWVudC5vZmYoYSx0aGlzLmhhbmRsZXJzW2FdKTtmb3IoYiBpbiBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh0aGlzKSlcImZ1bmN0aW9uXCIhPXR5cGVvZiB0aGlzW2JdJiYodGhpc1tiXT1udWxsKX0sXG5hLmZuLm93bENhcm91c2VsLkNvbnN0cnVjdG9yLlBsdWdpbnMuQW5pbWF0ZT1lfSh3aW5kb3cuWmVwdG98fHdpbmRvdy5qUXVlcnksd2luZG93LGRvY3VtZW50KSxmdW5jdGlvbihhLGIsYyxkKXt2YXIgZT1mdW5jdGlvbihiKXt0aGlzLl9jb3JlPWIsdGhpcy5fdGltZW91dD1udWxsLHRoaXMuX3BhdXNlZD0hMSx0aGlzLl9oYW5kbGVycz17XCJjaGFuZ2VkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJlwic2V0dGluZ3NcIj09PWEucHJvcGVydHkubmFtZT90aGlzLl9jb3JlLnNldHRpbmdzLmF1dG9wbGF5P3RoaXMucGxheSgpOnRoaXMuc3RvcCgpOmEubmFtZXNwYWNlJiZcInBvc2l0aW9uXCI9PT1hLnByb3BlcnR5Lm5hbWUmJnRoaXMuX2NvcmUuc2V0dGluZ3MuYXV0b3BsYXkmJnRoaXMuX3NldEF1dG9QbGF5SW50ZXJ2YWwoKX0sdGhpcyksXCJpbml0aWFsaXplZC5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiZ0aGlzLl9jb3JlLnNldHRpbmdzLmF1dG9wbGF5JiZ0aGlzLnBsYXkoKX0sdGhpcyksXCJwbGF5Lm93bC5hdXRvcGxheVwiOmEucHJveHkoZnVuY3Rpb24oYSxiLGMpe2EubmFtZXNwYWNlJiZ0aGlzLnBsYXkoYixjKX0sdGhpcyksXCJzdG9wLm93bC5hdXRvcGxheVwiOmEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJnRoaXMuc3RvcCgpfSx0aGlzKSxcIm1vdXNlb3Zlci5vd2wuYXV0b3BsYXlcIjphLnByb3h5KGZ1bmN0aW9uKCl7dGhpcy5fY29yZS5zZXR0aW5ncy5hdXRvcGxheUhvdmVyUGF1c2UmJnRoaXMuX2NvcmUuaXMoXCJyb3RhdGluZ1wiKSYmdGhpcy5wYXVzZSgpfSx0aGlzKSxcIm1vdXNlbGVhdmUub3dsLmF1dG9wbGF5XCI6YS5wcm94eShmdW5jdGlvbigpe3RoaXMuX2NvcmUuc2V0dGluZ3MuYXV0b3BsYXlIb3ZlclBhdXNlJiZ0aGlzLl9jb3JlLmlzKFwicm90YXRpbmdcIikmJnRoaXMucGxheSgpfSx0aGlzKSxcInRvdWNoc3RhcnQub3dsLmNvcmVcIjphLnByb3h5KGZ1bmN0aW9uKCl7dGhpcy5fY29yZS5zZXR0aW5ncy5hdXRvcGxheUhvdmVyUGF1c2UmJnRoaXMuX2NvcmUuaXMoXCJyb3RhdGluZ1wiKSYmdGhpcy5wYXVzZSgpfSx0aGlzKSxcInRvdWNoZW5kLm93bC5jb3JlXCI6YS5wcm94eShmdW5jdGlvbigpe3RoaXMuX2NvcmUuc2V0dGluZ3MuYXV0b3BsYXlIb3ZlclBhdXNlJiZ0aGlzLnBsYXkoKX0sdGhpcyl9LHRoaXMuX2NvcmUuJGVsZW1lbnQub24odGhpcy5faGFuZGxlcnMpLHRoaXMuX2NvcmUub3B0aW9ucz1hLmV4dGVuZCh7fSxlLkRlZmF1bHRzLHRoaXMuX2NvcmUub3B0aW9ucyl9O2UuRGVmYXVsdHM9e2F1dG9wbGF5OiExLGF1dG9wbGF5VGltZW91dDo1ZTMsYXV0b3BsYXlIb3ZlclBhdXNlOiExLGF1dG9wbGF5U3BlZWQ6ITF9LGUucHJvdG90eXBlLnBsYXk9ZnVuY3Rpb24oYSxiKXt0aGlzLl9wYXVzZWQ9ITEsdGhpcy5fY29yZS5pcyhcInJvdGF0aW5nXCIpfHwodGhpcy5fY29yZS5lbnRlcihcInJvdGF0aW5nXCIpLHRoaXMuX3NldEF1dG9QbGF5SW50ZXJ2YWwoKSl9LGUucHJvdG90eXBlLl9nZXROZXh0VGltZW91dD1mdW5jdGlvbihkLGUpe3JldHVybiB0aGlzLl90aW1lb3V0JiZiLmNsZWFyVGltZW91dCh0aGlzLl90aW1lb3V0KSxiLnNldFRpbWVvdXQoYS5wcm94eShmdW5jdGlvbigpe3RoaXMuX3BhdXNlZHx8dGhpcy5fY29yZS5pcyhcImJ1c3lcIil8fHRoaXMuX2NvcmUuaXMoXCJpbnRlcmFjdGluZ1wiKXx8Yy5oaWRkZW58fHRoaXMuX2NvcmUubmV4dChlfHx0aGlzLl9jb3JlLnNldHRpbmdzLmF1dG9wbGF5U3BlZWQpfSx0aGlzKSxkfHx0aGlzLl9jb3JlLnNldHRpbmdzLmF1dG9wbGF5VGltZW91dCl9LGUucHJvdG90eXBlLl9zZXRBdXRvUGxheUludGVydmFsPWZ1bmN0aW9uKCl7dGhpcy5fdGltZW91dD10aGlzLl9nZXROZXh0VGltZW91dCgpfSxlLnByb3RvdHlwZS5zdG9wPWZ1bmN0aW9uKCl7dGhpcy5fY29yZS5pcyhcInJvdGF0aW5nXCIpJiYoYi5jbGVhclRpbWVvdXQodGhpcy5fdGltZW91dCksdGhpcy5fY29yZS5sZWF2ZShcInJvdGF0aW5nXCIpKX0sZS5wcm90b3R5cGUucGF1c2U9ZnVuY3Rpb24oKXt0aGlzLl9jb3JlLmlzKFwicm90YXRpbmdcIikmJih0aGlzLl9wYXVzZWQ9ITApfSxlLnByb3RvdHlwZS5kZXN0cm95PWZ1bmN0aW9uKCl7dmFyIGEsYjt0aGlzLnN0b3AoKTtmb3IoYSBpbiB0aGlzLl9oYW5kbGVycyl0aGlzLl9jb3JlLiRlbGVtZW50Lm9mZihhLHRoaXMuX2hhbmRsZXJzW2FdKTtmb3IoYiBpbiBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh0aGlzKSlcImZ1bmN0aW9uXCIhPXR5cGVvZiB0aGlzW2JdJiYodGhpc1tiXT1udWxsKX0sYS5mbi5vd2xDYXJvdXNlbC5Db25zdHJ1Y3Rvci5QbHVnaW5zLmF1dG9wbGF5PWV9KHdpbmRvdy5aZXB0b3x8d2luZG93LmpRdWVyeSx3aW5kb3csZG9jdW1lbnQpLGZ1bmN0aW9uKGEsYixjLGQpe1widXNlIHN0cmljdFwiO3ZhciBlPWZ1bmN0aW9uKGIpe3RoaXMuX2NvcmU9Yix0aGlzLl9pbml0aWFsaXplZD0hMSx0aGlzLl9wYWdlcz1bXSx0aGlzLl9jb250cm9scz17fSx0aGlzLl90ZW1wbGF0ZXM9W10sdGhpcy4kZWxlbWVudD10aGlzLl9jb3JlLiRlbGVtZW50LHRoaXMuX292ZXJyaWRlcz17bmV4dDp0aGlzLl9jb3JlLm5leHQscHJldjp0aGlzLl9jb3JlLnByZXYsdG86dGhpcy5fY29yZS50b30sdGhpcy5faGFuZGxlcnM9e1wicHJlcGFyZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihiKXtiLm5hbWVzcGFjZSYmdGhpcy5fY29yZS5zZXR0aW5ncy5kb3RzRGF0YSYmdGhpcy5fdGVtcGxhdGVzLnB1c2goJzxkaXYgY2xhc3M9XCInK3RoaXMuX2NvcmUuc2V0dGluZ3MuZG90Q2xhc3MrJ1wiPicrYShiLmNvbnRlbnQpLmZpbmQoXCJbZGF0YS1kb3RdXCIpLmFkZEJhY2soXCJbZGF0YS1kb3RdXCIpLmF0dHIoXCJkYXRhLWRvdFwiKStcIjwvZGl2PlwiKX0sdGhpcyksXCJhZGRlZC5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiZ0aGlzLl9jb3JlLnNldHRpbmdzLmRvdHNEYXRhJiZ0aGlzLl90ZW1wbGF0ZXMuc3BsaWNlKGEucG9zaXRpb24sMCx0aGlzLl90ZW1wbGF0ZXMucG9wKCkpfSx0aGlzKSxcInJlbW92ZS5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiZ0aGlzLl9jb3JlLnNldHRpbmdzLmRvdHNEYXRhJiZ0aGlzLl90ZW1wbGF0ZXMuc3BsaWNlKGEucG9zaXRpb24sMSl9LHRoaXMpLFwiY2hhbmdlZC5vd2wuY2Fyb3VzZWxcIjphLnByb3h5KGZ1bmN0aW9uKGEpe2EubmFtZXNwYWNlJiZcInBvc2l0aW9uXCI9PWEucHJvcGVydHkubmFtZSYmdGhpcy5kcmF3KCl9LHRoaXMpLFwiaW5pdGlhbGl6ZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihhKXthLm5hbWVzcGFjZSYmIXRoaXMuX2luaXRpYWxpemVkJiYodGhpcy5fY29yZS50cmlnZ2VyKFwiaW5pdGlhbGl6ZVwiLG51bGwsXCJuYXZpZ2F0aW9uXCIpLHRoaXMuaW5pdGlhbGl6ZSgpLHRoaXMudXBkYXRlKCksdGhpcy5kcmF3KCksdGhpcy5faW5pdGlhbGl6ZWQ9ITAsdGhpcy5fY29yZS50cmlnZ2VyKFwiaW5pdGlhbGl6ZWRcIixudWxsLFwibmF2aWdhdGlvblwiKSl9LHRoaXMpLFwicmVmcmVzaGVkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYSl7YS5uYW1lc3BhY2UmJnRoaXMuX2luaXRpYWxpemVkJiYodGhpcy5fY29yZS50cmlnZ2VyKFwicmVmcmVzaFwiLG51bGwsXCJuYXZpZ2F0aW9uXCIpLHRoaXMudXBkYXRlKCksdGhpcy5kcmF3KCksdGhpcy5fY29yZS50cmlnZ2VyKFwicmVmcmVzaGVkXCIsbnVsbCxcIm5hdmlnYXRpb25cIikpfSx0aGlzKX0sdGhpcy5fY29yZS5vcHRpb25zPWEuZXh0ZW5kKHt9LGUuRGVmYXVsdHMsdGhpcy5fY29yZS5vcHRpb25zKSx0aGlzLiRlbGVtZW50Lm9uKHRoaXMuX2hhbmRsZXJzKX07ZS5EZWZhdWx0cz17bmF2OiExLG5hdlRleHQ6W1wicHJldlwiLFwibmV4dFwiXSxuYXZTcGVlZDohMSxuYXZFbGVtZW50OlwiZGl2XCIsbmF2Q29udGFpbmVyOiExLG5hdkNvbnRhaW5lckNsYXNzOlwib3dsLW5hdlwiLG5hdkNsYXNzOltcIm93bC1wcmV2XCIsXCJvd2wtbmV4dFwiXSxzbGlkZUJ5OjEsZG90Q2xhc3M6XCJvd2wtZG90XCIsZG90c0NsYXNzOlwib3dsLWRvdHNcIixkb3RzOiEwLGRvdHNFYWNoOiExLGRvdHNEYXRhOiExLGRvdHNTcGVlZDohMSxkb3RzQ29udGFpbmVyOiExfSxlLnByb3RvdHlwZS5pbml0aWFsaXplPWZ1bmN0aW9uKCl7dmFyIGIsYz10aGlzLl9jb3JlLnNldHRpbmdzO3RoaXMuX2NvbnRyb2xzLiRyZWxhdGl2ZT0oYy5uYXZDb250YWluZXI/YShjLm5hdkNvbnRhaW5lcik6YShcIjxkaXY+XCIpLmFkZENsYXNzKGMubmF2Q29udGFpbmVyQ2xhc3MpLmFwcGVuZFRvKHRoaXMuJGVsZW1lbnQpKS5hZGRDbGFzcyhcImRpc2FibGVkXCIpLHRoaXMuX2NvbnRyb2xzLiRwcmV2aW91cz1hKFwiPFwiK2MubmF2RWxlbWVudCtcIj5cIikuYWRkQ2xhc3MoYy5uYXZDbGFzc1swXSkuaHRtbChjLm5hdlRleHRbMF0pLnByZXBlbmRUbyh0aGlzLl9jb250cm9scy4kcmVsYXRpdmUpLm9uKFwiY2xpY2tcIixhLnByb3h5KGZ1bmN0aW9uKGEpe3RoaXMucHJldihjLm5hdlNwZWVkKX0sdGhpcykpLHRoaXMuX2NvbnRyb2xzLiRuZXh0PWEoXCI8XCIrYy5uYXZFbGVtZW50K1wiPlwiKS5hZGRDbGFzcyhjLm5hdkNsYXNzWzFdKS5odG1sKGMubmF2VGV4dFsxXSkuYXBwZW5kVG8odGhpcy5fY29udHJvbHMuJHJlbGF0aXZlKS5vbihcImNsaWNrXCIsYS5wcm94eShmdW5jdGlvbihhKXt0aGlzLm5leHQoYy5uYXZTcGVlZCl9LHRoaXMpKSxjLmRvdHNEYXRhfHwodGhpcy5fdGVtcGxhdGVzPVthKFwiPGRpdj5cIikuYWRkQ2xhc3MoYy5kb3RDbGFzcykuYXBwZW5kKGEoXCI8c3Bhbj5cIikpLnByb3AoXCJvdXRlckhUTUxcIildKSx0aGlzLl9jb250cm9scy4kYWJzb2x1dGU9KGMuZG90c0NvbnRhaW5lcj9hKGMuZG90c0NvbnRhaW5lcik6YShcIjxkaXY+XCIpLmFkZENsYXNzKGMuZG90c0NsYXNzKS5hcHBlbmRUbyh0aGlzLiRlbGVtZW50KSkuYWRkQ2xhc3MoXCJkaXNhYmxlZFwiKSx0aGlzLl9jb250cm9scy4kYWJzb2x1dGUub24oXCJjbGlja1wiLFwiZGl2XCIsYS5wcm94eShmdW5jdGlvbihiKXt2YXIgZD1hKGIudGFyZ2V0KS5wYXJlbnQoKS5pcyh0aGlzLl9jb250cm9scy4kYWJzb2x1dGUpP2EoYi50YXJnZXQpLmluZGV4KCk6YShiLnRhcmdldCkucGFyZW50KCkuaW5kZXgoKTtiLnByZXZlbnREZWZhdWx0KCksdGhpcy50byhkLGMuZG90c1NwZWVkKX0sdGhpcykpO2ZvcihiIGluIHRoaXMuX292ZXJyaWRlcyl0aGlzLl9jb3JlW2JdPWEucHJveHkodGhpc1tiXSx0aGlzKX0sZS5wcm90b3R5cGUuZGVzdHJveT1mdW5jdGlvbigpe3ZhciBhLGIsYyxkO2ZvcihhIGluIHRoaXMuX2hhbmRsZXJzKXRoaXMuJGVsZW1lbnQub2ZmKGEsdGhpcy5faGFuZGxlcnNbYV0pO2ZvcihiIGluIHRoaXMuX2NvbnRyb2xzKXRoaXMuX2NvbnRyb2xzW2JdLnJlbW92ZSgpO2ZvcihkIGluIHRoaXMub3ZlcmlkZXMpdGhpcy5fY29yZVtkXT10aGlzLl9vdmVycmlkZXNbZF07Zm9yKGMgaW4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGhpcykpXCJmdW5jdGlvblwiIT10eXBlb2YgdGhpc1tjXSYmKHRoaXNbY109bnVsbCl9LGUucHJvdG90eXBlLnVwZGF0ZT1mdW5jdGlvbigpe3ZhciBhLGIsYyxkPXRoaXMuX2NvcmUuY2xvbmVzKCkubGVuZ3RoLzIsZT1kK3RoaXMuX2NvcmUuaXRlbXMoKS5sZW5ndGgsZj10aGlzLl9jb3JlLm1heGltdW0oITApLGc9dGhpcy5fY29yZS5zZXR0aW5ncyxoPWcuY2VudGVyfHxnLmF1dG9XaWR0aHx8Zy5kb3RzRGF0YT8xOmcuZG90c0VhY2h8fGcuaXRlbXM7aWYoXCJwYWdlXCIhPT1nLnNsaWRlQnkmJihnLnNsaWRlQnk9TWF0aC5taW4oZy5zbGlkZUJ5LGcuaXRlbXMpKSxnLmRvdHN8fFwicGFnZVwiPT1nLnNsaWRlQnkpZm9yKHRoaXMuX3BhZ2VzPVtdLGE9ZCxiPTAsYz0wO2E8ZTthKyspe2lmKGI+PWh8fDA9PT1iKXtpZih0aGlzLl9wYWdlcy5wdXNoKHtzdGFydDpNYXRoLm1pbihmLGEtZCksZW5kOmEtZCtoLTF9KSxNYXRoLm1pbihmLGEtZCk9PT1mKWJyZWFrO2I9MCwrK2N9Yis9dGhpcy5fY29yZS5tZXJnZXJzKHRoaXMuX2NvcmUucmVsYXRpdmUoYSkpfX0sZS5wcm90b3R5cGUuZHJhdz1mdW5jdGlvbigpe3ZhciBiLGM9dGhpcy5fY29yZS5zZXR0aW5ncyxkPXRoaXMuX2NvcmUuaXRlbXMoKS5sZW5ndGg8PWMuaXRlbXMsZT10aGlzLl9jb3JlLnJlbGF0aXZlKHRoaXMuX2NvcmUuY3VycmVudCgpKSxmPWMubG9vcHx8Yy5yZXdpbmQ7dGhpcy5fY29udHJvbHMuJHJlbGF0aXZlLnRvZ2dsZUNsYXNzKFwiZGlzYWJsZWRcIiwhYy5uYXZ8fGQpLGMubmF2JiYodGhpcy5fY29udHJvbHMuJHByZXZpb3VzLnRvZ2dsZUNsYXNzKFwiZGlzYWJsZWRcIiwhZiYmZTw9dGhpcy5fY29yZS5taW5pbXVtKCEwKSksdGhpcy5fY29udHJvbHMuJG5leHQudG9nZ2xlQ2xhc3MoXCJkaXNhYmxlZFwiLCFmJiZlPj10aGlzLl9jb3JlLm1heGltdW0oITApKSksdGhpcy5fY29udHJvbHMuJGFic29sdXRlLnRvZ2dsZUNsYXNzKFwiZGlzYWJsZWRcIiwhYy5kb3RzfHxkKSxjLmRvdHMmJihiPXRoaXMuX3BhZ2VzLmxlbmd0aC10aGlzLl9jb250cm9scy4kYWJzb2x1dGUuY2hpbGRyZW4oKS5sZW5ndGgsYy5kb3RzRGF0YSYmMCE9PWI/dGhpcy5fY29udHJvbHMuJGFic29sdXRlLmh0bWwodGhpcy5fdGVtcGxhdGVzLmpvaW4oXCJcIikpOmI+MD90aGlzLl9jb250cm9scy4kYWJzb2x1dGUuYXBwZW5kKG5ldyBBcnJheShiKzEpLmpvaW4odGhpcy5fdGVtcGxhdGVzWzBdKSk6YjwwJiZ0aGlzLl9jb250cm9scy4kYWJzb2x1dGUuY2hpbGRyZW4oKS5zbGljZShiKS5yZW1vdmUoKSx0aGlzLl9jb250cm9scy4kYWJzb2x1dGUuZmluZChcIi5hY3RpdmVcIikucmVtb3ZlQ2xhc3MoXCJhY3RpdmVcIiksdGhpcy5fY29udHJvbHMuJGFic29sdXRlLmNoaWxkcmVuKCkuZXEoYS5pbkFycmF5KHRoaXMuY3VycmVudCgpLHRoaXMuX3BhZ2VzKSkuYWRkQ2xhc3MoXCJhY3RpdmVcIikpfSxlLnByb3RvdHlwZS5vblRyaWdnZXI9ZnVuY3Rpb24oYil7dmFyIGM9dGhpcy5fY29yZS5zZXR0aW5ncztiLnBhZ2U9e2luZGV4OmEuaW5BcnJheSh0aGlzLmN1cnJlbnQoKSx0aGlzLl9wYWdlcyksY291bnQ6dGhpcy5fcGFnZXMubGVuZ3RoLHNpemU6YyYmKGMuY2VudGVyfHxjLmF1dG9XaWR0aHx8Yy5kb3RzRGF0YT8xOmMuZG90c0VhY2h8fGMuaXRlbXMpfX0sZS5wcm90b3R5cGUuY3VycmVudD1mdW5jdGlvbigpe3ZhciBiPXRoaXMuX2NvcmUucmVsYXRpdmUodGhpcy5fY29yZS5jdXJyZW50KCkpO3JldHVybiBhLmdyZXAodGhpcy5fcGFnZXMsYS5wcm94eShmdW5jdGlvbihhLGMpe3JldHVybiBhLnN0YXJ0PD1iJiZhLmVuZD49Yn0sdGhpcykpLnBvcCgpfSxlLnByb3RvdHlwZS5nZXRQb3NpdGlvbj1mdW5jdGlvbihiKXt2YXIgYyxkLGU9dGhpcy5fY29yZS5zZXR0aW5ncztyZXR1cm5cInBhZ2VcIj09ZS5zbGlkZUJ5PyhjPWEuaW5BcnJheSh0aGlzLmN1cnJlbnQoKSx0aGlzLl9wYWdlcyksZD10aGlzLl9wYWdlcy5sZW5ndGgsYj8rK2M6LS1jLGM9dGhpcy5fcGFnZXNbKGMlZCtkKSVkXS5zdGFydCk6KGM9dGhpcy5fY29yZS5yZWxhdGl2ZSh0aGlzLl9jb3JlLmN1cnJlbnQoKSksZD10aGlzLl9jb3JlLml0ZW1zKCkubGVuZ3RoLGI/Yys9ZS5zbGlkZUJ5OmMtPWUuc2xpZGVCeSksY30sZS5wcm90b3R5cGUubmV4dD1mdW5jdGlvbihiKXthLnByb3h5KHRoaXMuX292ZXJyaWRlcy50byx0aGlzLl9jb3JlKSh0aGlzLmdldFBvc2l0aW9uKCEwKSxiKX0sZS5wcm90b3R5cGUucHJldj1mdW5jdGlvbihiKXthLnByb3h5KHRoaXMuX292ZXJyaWRlcy50byx0aGlzLl9jb3JlKSh0aGlzLmdldFBvc2l0aW9uKCExKSxiKX0sZS5wcm90b3R5cGUudG89ZnVuY3Rpb24oYixjLGQpe3ZhciBlOyFkJiZ0aGlzLl9wYWdlcy5sZW5ndGg/KGU9dGhpcy5fcGFnZXMubGVuZ3RoLGEucHJveHkodGhpcy5fb3ZlcnJpZGVzLnRvLHRoaXMuX2NvcmUpKHRoaXMuX3BhZ2VzWyhiJWUrZSklZV0uc3RhcnQsYykpOmEucHJveHkodGhpcy5fb3ZlcnJpZGVzLnRvLHRoaXMuX2NvcmUpKGIsYyl9LGEuZm4ub3dsQ2Fyb3VzZWwuQ29uc3RydWN0b3IuUGx1Z2lucy5OYXZpZ2F0aW9uPWV9KHdpbmRvdy5aZXB0b3x8d2luZG93LmpRdWVyeSx3aW5kb3csZG9jdW1lbnQpLGZ1bmN0aW9uKGEsYixjLGQpe1widXNlIHN0cmljdFwiO3ZhciBlPWZ1bmN0aW9uKGMpe3RoaXMuX2NvcmU9Yyx0aGlzLl9oYXNoZXM9e30sdGhpcy4kZWxlbWVudD10aGlzLl9jb3JlLiRlbGVtZW50LHRoaXMuX2hhbmRsZXJzPXtcImluaXRpYWxpemVkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYyl7Yy5uYW1lc3BhY2UmJlwiVVJMSGFzaFwiPT09dGhpcy5fY29yZS5zZXR0aW5ncy5zdGFydFBvc2l0aW9uJiZhKGIpLnRyaWdnZXIoXCJoYXNoY2hhbmdlLm93bC5uYXZpZ2F0aW9uXCIpfSx0aGlzKSxcInByZXBhcmVkLm93bC5jYXJvdXNlbFwiOmEucHJveHkoZnVuY3Rpb24oYil7aWYoYi5uYW1lc3BhY2Upe3ZhciBjPWEoYi5jb250ZW50KS5maW5kKFwiW2RhdGEtaGFzaF1cIikuYWRkQmFjayhcIltkYXRhLWhhc2hdXCIpLmF0dHIoXCJkYXRhLWhhc2hcIik7aWYoIWMpcmV0dXJuO3RoaXMuX2hhc2hlc1tjXT1iLmNvbnRlbnR9fSx0aGlzKSxcImNoYW5nZWQub3dsLmNhcm91c2VsXCI6YS5wcm94eShmdW5jdGlvbihjKXtpZihjLm5hbWVzcGFjZSYmXCJwb3NpdGlvblwiPT09Yy5wcm9wZXJ0eS5uYW1lKXt2YXIgZD10aGlzLl9jb3JlLml0ZW1zKHRoaXMuX2NvcmUucmVsYXRpdmUodGhpcy5fY29yZS5jdXJyZW50KCkpKSxlPWEubWFwKHRoaXMuX2hhc2hlcyxmdW5jdGlvbihhLGIpe3JldHVybiBhPT09ZD9iOm51bGx9KS5qb2luKCk7aWYoIWV8fGIubG9jYXRpb24uaGFzaC5zbGljZSgxKT09PWUpcmV0dXJuO2IubG9jYXRpb24uaGFzaD1lfX0sdGhpcyl9LHRoaXMuX2NvcmUub3B0aW9ucz1hLmV4dGVuZCh7fSxlLkRlZmF1bHRzLHRoaXMuX2NvcmUub3B0aW9ucyksdGhpcy4kZWxlbWVudC5vbih0aGlzLl9oYW5kbGVycyksYShiKS5vbihcImhhc2hjaGFuZ2Uub3dsLm5hdmlnYXRpb25cIixhLnByb3h5KGZ1bmN0aW9uKGEpe3ZhciBjPWIubG9jYXRpb24uaGFzaC5zdWJzdHJpbmcoMSksZT10aGlzLl9jb3JlLiRzdGFnZS5jaGlsZHJlbigpLGY9dGhpcy5faGFzaGVzW2NdJiZlLmluZGV4KHRoaXMuX2hhc2hlc1tjXSk7ZiE9PWQmJmYhPT10aGlzLl9jb3JlLmN1cnJlbnQoKSYmdGhpcy5fY29yZS50byh0aGlzLl9jb3JlLnJlbGF0aXZlKGYpLCExLCEwKX0sdGhpcykpfTtlLkRlZmF1bHRzPXtVUkxoYXNoTGlzdGVuZXI6ITF9LGUucHJvdG90eXBlLmRlc3Ryb3k9ZnVuY3Rpb24oKXt2YXIgYyxkO2EoYikub2ZmKFwiaGFzaGNoYW5nZS5vd2wubmF2aWdhdGlvblwiKTtmb3IoYyBpbiB0aGlzLl9oYW5kbGVycyl0aGlzLl9jb3JlLiRlbGVtZW50Lm9mZihjLHRoaXMuX2hhbmRsZXJzW2NdKTtmb3IoZCBpbiBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh0aGlzKSlcImZ1bmN0aW9uXCIhPXR5cGVvZiB0aGlzW2RdJiYodGhpc1tkXT1udWxsKX0sYS5mbi5vd2xDYXJvdXNlbC5Db25zdHJ1Y3Rvci5QbHVnaW5zLkhhc2g9ZX0od2luZG93LlplcHRvfHx3aW5kb3cualF1ZXJ5LHdpbmRvdyxkb2N1bWVudCksZnVuY3Rpb24oYSxiLGMsZCl7ZnVuY3Rpb24gZShiLGMpe3ZhciBlPSExLGY9Yi5jaGFyQXQoMCkudG9VcHBlckNhc2UoKStiLnNsaWNlKDEpO3JldHVybiBhLmVhY2goKGIrXCIgXCIraC5qb2luKGYrXCIgXCIpK2YpLnNwbGl0KFwiIFwiKSxmdW5jdGlvbihhLGIpe2lmKGdbYl0hPT1kKXJldHVybiBlPSFjfHxiLCExfSksZX1mdW5jdGlvbiBmKGEpe3JldHVybiBlKGEsITApfXZhciBnPWEoXCI8c3VwcG9ydD5cIikuZ2V0KDApLnN0eWxlLGg9XCJXZWJraXQgTW96IE8gbXNcIi5zcGxpdChcIiBcIiksaT17dHJhbnNpdGlvbjp7ZW5kOntXZWJraXRUcmFuc2l0aW9uOlwid2Via2l0VHJhbnNpdGlvbkVuZFwiLE1velRyYW5zaXRpb246XCJ0cmFuc2l0aW9uZW5kXCIsT1RyYW5zaXRpb246XCJvVHJhbnNpdGlvbkVuZFwiLHRyYW5zaXRpb246XCJ0cmFuc2l0aW9uZW5kXCJ9fSxhbmltYXRpb246e2VuZDp7V2Via2l0QW5pbWF0aW9uOlwid2Via2l0QW5pbWF0aW9uRW5kXCIsTW96QW5pbWF0aW9uOlwiYW5pbWF0aW9uZW5kXCIsT0FuaW1hdGlvbjpcIm9BbmltYXRpb25FbmRcIixhbmltYXRpb246XCJhbmltYXRpb25lbmRcIn19fSxqPXtjc3N0cmFuc2Zvcm1zOmZ1bmN0aW9uKCl7cmV0dXJuISFlKFwidHJhbnNmb3JtXCIpfSxjc3N0cmFuc2Zvcm1zM2Q6ZnVuY3Rpb24oKXtyZXR1cm4hIWUoXCJwZXJzcGVjdGl2ZVwiKX0sY3NzdHJhbnNpdGlvbnM6ZnVuY3Rpb24oKXtyZXR1cm4hIWUoXCJ0cmFuc2l0aW9uXCIpfSxjc3NhbmltYXRpb25zOmZ1bmN0aW9uKCl7cmV0dXJuISFlKFwiYW5pbWF0aW9uXCIpfX07ai5jc3N0cmFuc2l0aW9ucygpJiYoYS5zdXBwb3J0LnRyYW5zaXRpb249bmV3IFN0cmluZyhmKFwidHJhbnNpdGlvblwiKSksYS5zdXBwb3J0LnRyYW5zaXRpb24uZW5kPWkudHJhbnNpdGlvbi5lbmRbYS5zdXBwb3J0LnRyYW5zaXRpb25dKSxqLmNzc2FuaW1hdGlvbnMoKSYmKGEuc3VwcG9ydC5hbmltYXRpb249bmV3IFN0cmluZyhmKFwiYW5pbWF0aW9uXCIpKSxhLnN1cHBvcnQuYW5pbWF0aW9uLmVuZD1pLmFuaW1hdGlvbi5lbmRbYS5zdXBwb3J0LmFuaW1hdGlvbl0pLGouY3NzdHJhbnNmb3JtcygpJiYoYS5zdXBwb3J0LnRyYW5zZm9ybT1uZXcgU3RyaW5nKGYoXCJ0cmFuc2Zvcm1cIikpLGEuc3VwcG9ydC50cmFuc2Zvcm0zZD1qLmNzc3RyYW5zZm9ybXMzZCgpKX0od2luZG93LlplcHRvfHx3aW5kb3cualF1ZXJ5LHdpbmRvdyxkb2N1bWVudCk7IiwidmFyIHJvb3RVcmwgPSB3aW5kb3cubG9jYXRpb24ub3JpZ2luO1xudmFyIHRlbXBsYXRlVXJsID0gdGhlbWVVcmwudGVtcGxhdGVVcmw7XG4vLyBjb25zb2xlLmxvZyh0ZW1wbGF0ZVVybCk7XG5pZihyb290VXJsID09PSBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMFwiIHx8IHJvb3RVcmwgPT09IFwiaHR0cDovL2xvY2FsaG9zdDo4ODg4XCIpIHtcbiAgcm9vdFVybCA9IHJvb3RVcmwgKyBcIi93ZXN0dG91cnMvXCI7XG59ZWxzZXtcbiAgcm9vdFVybCA9IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW47XG59XG4iLCIvLyAvL1xuLy8gdmFyIHJvb3RVcmwgPSB3aW5kb3cubG9jYXRpb24ub3JpZ2luO1xuLy8gaWYocm9vdFVybCA9PT0gXCJodHRwOi8vbG9jYWxob3N0OjMwMDBcIiB8fCByb290VXJsID09PSBcImh0dHA6Ly9sb2NhbGhvc3Q6ODg4OFwiKSB7XG4vLyAgIHJvb3RVcmwgPSByb290VXJsICsgXCIvd2VzdHRvdXJzL1wiO1xuLy8gfWVsc2V7XG4vLyAgIHJvb3RVcmwgPSBcInRlc3RcIit3aW5kb3cubG9jYXRpb24ub3JpZ2luO1xuLy8gfVxuLy9cbi8vIHZhciBjYXRlZ29yaWVzID0gcm9vdFVybCtcIi93cC1qc29uL3dwL3YyL2NhdGVnb3JpZXM/cGVyX3BhZ2U9NTBcIjtcbi8vIHZhciBiaWtlVG91cnNIdHRwID0gcm9vdFVybCtcIi93cC1qc29uL3dwL3YyL3RvdXJfcG9zdF90eXBlP3Blcl9wYWdlPTUwXCI7XG4vLyB2YXIgY3VzdG9tVGVzdCA9IHJvb3RVcmwrXCIvd3AtanNvbi93cC92Mi9jdXN0b21fYXBpXCI7XG4vLyB2YXIgbWVkaWEgPSByb290VXJsK1wiL3dwLWpzb24vd3AvdjIvbWVkaWE/cGVyX3BhZ2U9NTBcIjtcbi8vXG4vLyBjb25zb2xlLmxvZyhyb290VXJsKTtcbi8vIHZhciBjYXRlZ29yeSA9IFtdO1xuLy9cbi8vIGZ1bmN0aW9uIHNodWZmbGUgKGFycmF5KSB7XG4vLyAgIHZhciBpID0gMDtcbi8vICAgdmFyIGogPSAwO1xuLy8gICB2YXIgdGVtcCA9IG51bGw7XG4vL1xuLy8gICBmb3IgKGkgPSBhcnJheS5sZW5ndGggLSAxOyBpID4gMDsgaSAtPSAxKSB7XG4vLyAgICAgaiA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIChpICsgMSkpO1xuLy8gICAgIHRlbXAgPSBhcnJheVtpXTtcbi8vICAgICBhcnJheVtpXSA9IGFycmF5W2pdO1xuLy8gICAgIGFycmF5W2pdID0gdGVtcDtcbi8vICAgfVxuLy8gfVxuLy8gJC5nZXRKU09OKGNhdGVnb3JpZXMsIGZ1bmN0aW9uKHJlc3VsdCl7XG4vLyBjYXRlZ29yeSA9IHJlc3VsdDtcbi8vIC8vIGNvbnNvbGUubG9nKGNhdGVnb3J5KTtcbi8vIH0pO1xuLy9cbi8vIHZhciBtZWRpYU9iaiA9W107XG4vLyAkLmdldEpTT04obWVkaWEsIGZ1bmN0aW9uKHJlc3VsdCl7XG4vLyBtZWRpYU9iaiA9IHJlc3VsdDtcbi8vIH0pO1xuLy8gLy8gSlNPTmdldHRlciBpcyBhIHdheSBmb3IgbXVsdGlwbGUgY3VzdG9tIHBvc3QgY2FsbHMgZnJvbSB0aGUgd3AgcmVzdFxuLy8gdmFyIEpTT05nZXR0ZXIgPSBmdW5jdGlvbihodHRwLCByZXN1bHRuYW1lKXtcbi8vICAgJC5nZXRKU09OKGh0dHAsIGZ1bmN0aW9uKHJlc3VsdG5hbWUpe1xuLy8gICAgIHZhciBwb3B1bGFyID0gW107XG4vLyAgICAgdmFyIHNtYWxsQ2FyZHMgPSBbXTtcbi8vICAgICAkLmVhY2gocmVzdWx0bmFtZSwgZnVuY3Rpb24oaSwgZmllbGQpe1xuLy8gICAgICAgaWYgKGZpZWxkLmFjZi5pc19wb3B1bGFyKSB7XG4vLyAgICAgICAgIHBvcHVsYXIucHVzaChmaWVsZCk7XG4vLyAgICAgICB9XG4vLyAgICAgICBzbWFsbENhcmRzLnB1c2goZmllbGQpO1xuLy8gICAgICAgLy8gIGNvbnNvbGUubG9nKGZpZWxkKTtcbi8vXG4vLyAgICAgIHZhciBvcHRpb24gPSBcIjxvcHRpb24gdmFsdWU9J1wiK2ZpZWxkLnRpdGxlLnJlbmRlcmVkK1wiIFwiK2ZpZWxkLmFjZi5hY3RpdmV0eStcIic+PHA+XCIrZmllbGQudGl0bGUucmVuZGVyZWQrXCI8L3A+ICAgPHA+XCIrZmllbGQuYWNmLmFjdGl2ZXR5K1wiPC9wPjwvb3B0aW9uPlwiO1xuLy9cbi8vICAgICAgJCgnI2FjdGl2aXRpZXMtc2VhcmNoJykuYXBwZW5kKG9wdGlvbik7XG4vL1xuLy8gICAgICB9KTtcbi8vXG4vLyAgICAgc2h1ZmZsZShwb3B1bGFyKTtcbi8vICAgICAgICQuZWFjaChwb3B1bGFyLCBmdW5jdGlvbihpLCBwb3B1bGFyKXtcbi8vICAgICAgIHZhciBhY3RpdmV0eSA9IHBvcHVsYXIuYWNmLmFjdGl2ZXR5LnRvTG93ZXJDYXNlKCk7XG4vLyAgICAgICB2YXIgc2Vhc29uID0gcG9wdWxhci5hY2Yuc2Vhc29uLnRvTG93ZXJDYXNlKCk7XG4vLyAgICAgICB2YXIgY2FyZEljb24gPSBhY3RpdmV0eTtcbi8vICAgICAgIGlmIChjYXJkSWNvbiA9PSBcImFuaW1hbCBsaWZlXCIpIHtcbi8vICAgICAgICBjYXJkSWNvbiA9IFwiYW5pbWFsLWxpZmVcIjtcbi8vICAgICAgIH1cbi8vICAgICAgIC8vICBjb25zb2xlLmxvZygncG9wJyk7XG4vLyAgICAgICB2YXIgaWNvbkNsYXNzID0gYWN0aXZldHk7XG4vL1xuLy8gICAgICAgZnVuY3Rpb24gZ2V0V29yZHMocGFyYW1ldGVyKSB7XG4vLyAgICAgICAgICAgcmV0dXJuIHBhcmFtZXRlci5zcGxpdCgvXFxzKy8pLnNsaWNlKDAsNCkuam9pbihcIiBcIikrXCIuLlwiO1xuLy8gICAgICAgfVxuLy8gICAgICAgdmFyIGxhcmdlQ2FyZEhlYWRpbmcgPSBwb3B1bGFyLnRpdGxlLnJlbmRlcmVkO1xuLy9cbi8vICAgICAgIGdldFdvcmRzKGxhcmdlQ2FyZEhlYWRpbmcpO1xuLy9cbi8vICAgICAgIHZhciBTdHJpcHBlZFN0cmluZ0JpZyA9IHBvcHVsYXIuZXhjZXJwdC5yZW5kZXJlZC5yZXBsYWNlKC8oPChbXj5dKyk+KS9pZyxcIlwiKTtcbi8vICAgICAgIHZhciBzaG9ydGVyVGV4dEJpZyA9IFN0cmlwcGVkU3RyaW5nQmlnLnN1YnN0cigwLCAxMTIpICsgXCIuLi5cIjtcbi8vXG4vLyAgICAgICB2YXIgYmlnQ2FyZCA9IFwiPGRpdiBpZD0nJyBjbGFzcz0nY2FyZC1sYXJnZScgcm9sZT0nYXJ0aWNsZSc+PGEgaHJlZj0nXCIrcG9wdWxhci5saW5rK1wiJz48ZGl2IGNsYXNzPSdpbWFnZScgc3R5bGU9J2JhY2tncm91bmQtaW1hZ2U6dXJsKFwiK3BvcHVsYXIuYWNmLmluZm9faW1nLnNpemVzLmxhcmdlK1wiKTsnPjxpbWcgc3JjPScnIGFsdD0nJy8+PC9kaXY+PGRpdiBjbGFzcz0naWNvbicgc3R5bGU9J2JhY2tncm91bmQtaW1hZ2U6dXJsKFwiK3Jvb3RVcmwrXCIvd3AtY29udGVudC90aGVtZXMvZm91bmRhdGlvblByZXNzR2l0L2Fzc2V0cy9pbWFnZXMvaWNvbnMvY2F0SWNvbnMvXCIrY2FyZEljb24rXCIuc3ZnKTsnID48L2Rpdj48cCBjbGFzcz0nY2F0LXN0cmluZyc+IFwiK2FjdGl2ZXR5K1wiIC8gXCIrc2Vhc29uK1wiIDwvcD48aGVhZGVyIGNsYXNzPSdjYXJkLWNvbnRlbnQgYXJ0aWNsZS1oZWFkZXInPjxoMiBjbGFzcz0nZW50cnktdGl0bGUgc2luZ2xlLXRpdGxlJyBpdGVtcHJvcD0naGVhZGxpbmUnPlwiK3BvcHVsYXIudGl0bGUucmVuZGVyZWQrXCI8L2gyPjxwPlwiK3Nob3J0ZXJUZXh0QmlnK1wiPC9wPjwvaGVhZGVyPjxidXR0b24gdHlwZT0nYnV0dG9uJyBjbGFzcz0ncmVhZE1vcmVCdG4nPlJlYWQgbW9yZTwvYnV0dG9uPjwvYT48L2Rpdj5cIjtcbi8vXG4vLyAgICAgICBpZiAocG9wdWxhci5hY2YuaXNfcG9wdWxhcikge1xuLy8gICAgICAgICAkKFwiI2JpZy1jYXJkc1wiKS5hcHBlbmQoYmlnQ2FyZCk7XG4vLyAgICAgICB9XG4vL1xuLy8gICAgICAgcmV0dXJuIGkgPCAxO1xuLy8gICAgICB9KTtcbi8vICAgICAgIHNodWZmbGUoc21hbGxDYXJkcyk7XG4vLyAgICAgICAkLmVhY2goc21hbGxDYXJkcywgZnVuY3Rpb24oaSwgY2FyZCl7XG4vLyAgICAgICAgIHZhciBhY3RpdmV0eSA9IGNhcmQuYWNmLmFjdGl2ZXR5LnRvTG93ZXJDYXNlKCk7XG4vLyAgICAgICAgIHZhciBzZWFzb24gPSBjYXJkLmFjZi5zZWFzb24udG9Mb3dlckNhc2UoKTtcbi8vICAgICAgICAgdmFyIGNhcmRJY29uID0gYWN0aXZldHk7XG4vLyAgICAgICAgIGlmIChjYXJkSWNvbiA9PSBcImFuaW1hbCBsaWZlXCIpIHtcbi8vICAgICAgICAgIGNhcmRJY29uID0gXCJhbmltYWwtbGlmZVwiO1xuLy8gICAgICAgICB9XG4vLyAgICAgICAgIHZhciBpY29uQ2xhc3MgPSBhY3RpdmV0eTtcbi8vXG4vLyAgICAgICAgIHZhciBzbWFsbGVySDI7XG4vLyAgICAgICAgIC8vICBpZiAoY2FyZC50aXRsZS5yZW5kZXJlZC5sZW5ndGggPiAyMSkge1xuLy8gICAgICAgICAvLyAgICAgc21hbGxlckgyID0gJ3NtYWxsZXJIMic7XG4vLyAgICAgICAgIC8vICB9ZWxzZXtcbi8vICAgICAgICAgLy8gICAgc21hbGxlckgyID0gJyc7XG4vLyAgICAgICAgIC8vICB9XG4vLyAgICAgICAgIGZ1bmN0aW9uIGdldFdvcmRzKHBhcmFtZXRlciwgbnVtV29yZHMpIHtcbi8vICAgICAgICAgICByZXR1cm4gcGFyYW1ldGVyLnNwbGl0KC9cXHMrLykuc2xpY2UoMCxudW1Xb3Jkcykuam9pbihcIiBcIikrXCIuLlwiO1xuLy8gICAgICAgICB9XG4vL1xuLy8gICAgICAgICB2YXIgY2FyZEhlYWRpbmcgPSBjYXJkLnRpdGxlLnJlbmRlcmVkO1xuLy8gICAgICAgICB2YXIgaW5GZXdlcldvcmRzID0gY2FyZC5leGNlcnB0LnJlbmRlcmVkO1xuLy8gICAgICAgICBnZXRXb3JkcyhjYXJkSGVhZGluZywgMyk7XG4vL1xuLy8gICAgICAgICB2YXIgU3RyaXBwZWRTdHJpbmcgPSBjYXJkLmV4Y2VycHQucmVuZGVyZWQucmVwbGFjZSgvKDwoW14+XSspPikvaWcsXCJcIik7XG4vLyAgICAgICAgIHZhciBzaG9ydGVyVGV4dCA9IFN0cmlwcGVkU3RyaW5nLnN1YnN0cigwLCA0OCkgKyBcIi4uLlwiO1xuLy9cbi8vICAgICAgICAgdmFyIHNtYWxsQ2FyZCA9IFwiPGRpdiBjbGFzcz0nc21hbGwtMTIgbWVkaXVtLTYgbGFyZ2UtNCB4bGFyZ2UtMyBjYXJkLWNvbnRhaW5lciBoaWRkZW4nPjxkaXYgIGNsYXNzPSdjYXJkJyByb2xlPSdhcnRpY2xlJyA+PGEgaHJlZj0nXCIrY2FyZC5saW5rK1wiJz48ZGl2IGNsYXNzPSdpbWFnZScgc3R5bGU9J2JhY2tncm91bmQtaW1hZ2U6dXJsKFwiK2NhcmQuYWNmLmluZm9faW1nLnNpemVzLm1lZGl1bStcIik7Jz48aW1nIHNyYz0nJyBhbHQ9JycgLz48L2Rpdj48ZGl2IGNsYXNzPSdpY29uIGljb24tXCIraWNvbkNsYXNzK1wiJyBzdHlsZT0nYmFja2dyb3VuZC1pbWFnZTp1cmwoXCIrcm9vdFVybCtcIi93cC1jb250ZW50L3RoZW1lcy9mb3VuZGF0aW9uUHJlc3NHaXQvYXNzZXRzL2ltYWdlcy9pY29ucy9jYXRJY29ucy9cIitjYXJkSWNvbitcIi5zdmcpOycgPjwvZGl2PjxwIGNsYXNzPSdjYXQtc3RyaW5nJz4gXCIrYWN0aXZldHkrXCIgLyBcIitzZWFzb24rXCIgPC9wPjxoZWFkZXIgY2xhc3M9J2NhcmQtY29udGVudCBhcnRpY2xlLWhlYWRlcic+PGgyIGNsYXNzPSdlbnRyeS10aXRsZSBzaW5nbGUtdGl0bGUgXCIrc21hbGxlckgyK1wiJyBpdGVtcHJvcD0naGVhZGxpbmUnPlwiK2dldFdvcmRzKGNhcmRIZWFkaW5nLCAzKStcIjwvaDI+PHA+XCIrc2hvcnRlclRleHQrXCI8L3A+PC9oZWFkZXI+PGJ1dHRvbiB0eXBlPSdidXR0b24nIGNsYXNzPSdib29rQnRuJz5Cb29rPC9idXR0b24+PC9hPjwvZGl2PjwvZGl2PlwiO1xuLy9cbi8vXG4vLyAgICAgICAgIGlmKCFwb3B1bGFyLmFjZi5pc19wb3B1bGFyKVxuLy8gICAgICAgICB7XG4vLyAgICAgICAgICAgJChcIiNjYXJkc1wiKS5hcHBlbmQoc21hbGxDYXJkKTtcbi8vICAgICAgICAgfVxuLy8gICAgICAgfSk7XG4vLyAgIH0pO1xuLy8gfTtcbi8vIC8vIHNldFRpbWVvdXQoXCJKU09OZ2V0dGVyKGJpa2VUb3Vyc0h0dHAsICdiaWtlT2JqZWN0JylcIiwyMDApO1xuLy8gSlNPTmdldHRlcihiaWtlVG91cnNIdHRwLCAnYmlrZU9iamVjdCcpO1xuLy8gZnVuY3Rpb24gbG9hZE1vcmUoKXtcbi8vICAgICAgICAgJChcIiNjYXJkcyAuaGlkZGVuXCIpLnNsaWNlKDAsNCkucmVtb3ZlQ2xhc3MoXCJoaWRkZW5cIik7XG4vLyAgICAgfVxuLy8gc2V0VGltZW91dChmdW5jdGlvbigpIHsgbG9hZE1vcmUoKTsgfSwgMTUwMCk7XG4vLyAkKFwiLnNob3ctbW9yZVwiKS5vbihcImNsaWNrXCIsbG9hZE1vcmUpO1xuLy9cbi8vIC8vIEpTT05nZXR0ZXIoY3VzdG9tVGVzdCwgJ3Rlc3QnKTtcbiIsIi8vIGZ1bmN0aW9uIGFwaUNhbGwocGF0aCwgZGF0YSl7XG4vLyAgIGpRdWVyeS5wb3N0KHBhdGgsIGRhdGEsIGZ1bmN0aW9uKHJlcyl7XG4vLyAgICAgLy8gY29uc29sZS5sb2cocmVzKTtcbi8vICAgICB2YXIgalBvc3RSZXMgPSBKU09OLnBhcnNlKHJlcyk7XG4vLyAgICAgY29uc29sZS5sb2coalBvc3RSZXMpO1xuLy8gICB9KTtcbi8vIH1cbi8vXG4vLyB2YXIgZWxCb2R5ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keScpO1xuLy9cbi8vIGlmKGVsQm9keS5jbGFzc0xpc3QuY29udGFpbnMoJ3NpbmdsZS10b3VyX3Bvc3RfdHlwZScpKSB7XG4vLyAgIHZhciBwb3N0ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYXJ0aWNsZScpO1xuLy8gICB2YXIgcG9zdElkID0gcG9zdC5nZXRBdHRyaWJ1dGUoJ2RhdGEtdG91cmlkJyk7XG4vLyAgIHZhciBwb3N0RGF0YSA9IHtcImRhdGFcIjogcG9zdElkfTtcbi8vICAgLy8gY29uc29sZS5kaXIocG9zdElkKTtcbi8vICAgYXBpQ2FsbChyb290VXJsKyd3cC1jb250ZW50L3RoZW1lcy9mb3VuZGF0aW9uUHJlc3NHaXQvbGlicmFyeS9hcGkvY2FsbC1ieS1pZC5waHAnLCBwb3N0RGF0YSk7XG4vLyB9XG5cbi8vIGZ1bmN0aW9uIHNlbmRDYXJkSWQoKXtcbi8vICAgLy8gY29uc29sZS5sb2coJ3gnKTtcbi8vICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBmdW5jdGlvbihlKXtcbi8vICAgICAvLyBjb25zb2xlLmxvZyhlLnRhcmdldCk7XG4vLyAgICAgaWYoZS50YXJnZXQuY2xhc3NMaXN0LmNvbnRhaW5zKCdidG5DYXJkJykpIHtcbi8vICAgICAgIHZhciBzR2V0VG91cklkID0gZS50YXJnZXQuZ2V0QXR0cmlidXRlKCdkYXRhLXRyaXBpZCcpO1xuLy8gICAgICAgdmFyIGpTZW5kVG91cklEID0ge1wiZGF0YVwiOnNHZXRUb3VySWR9O1xuLy8gICAgICAgYXBpQ2FsbChyb290VXJsKyd3cC1jb250ZW50L3RoZW1lcy9mb3VuZGF0aW9uUHJlc3NHaXQvbGlicmFyeS9hcGkvY2FsbC1ieS1pZC5waHAnLCBqU2VuZFRvdXJJRCk7XG4vLyAgICAgICAvLyBjb25zb2xlLmxvZyhnZXRUb3VySWQpO1xuLy8gICAgIH1cbi8vICAgfSk7XG4vLyB9XG4vL1xuLy8gc2VuZENhcmRJZCgpO1xuIiwiXG4kKCcjZnJvbScpLmRhdGVSYW5nZShcbntcbiAgIHNlbGVjdGVkOiBmdW5jdGlvbihkYXRlcylcbiAgIHtcbiAgICAgIHZhciBmcm9tID0gZGF0ZXNbMF07XG4gICAgICB2YXIgdG8gPSBkYXRlc1sxXTtcbiAgICAgIC8vZG8gc29tZXRoaW5nIHNwZWNpYWxcbiAgIH1cbn0pXG4iLCJcbi8vIGNvbnNvbGUubG9nKHJvb3RVcmwpO1xuXG4gIC8vIGNvbnNvbGUubG9nKHNTZWFyY2hTdHJpbmcpO1xuXG4kLmdldEpTT04oIHRlbXBsYXRlVXJsK1wiL2xpYnJhcnkvZGV0YWlsZWR0cmlwcy5qc29uXCIsIGZ1bmN0aW9uKCBkYXRhICkge1xuICAkKCcjYWN0aXZpdGllc1NlYXJjaCcpLm9uKCdrZXl1cCcsIGZ1bmN0aW9uKCl7XG5cbiAgICB2YXIgc1NlYXJjaFN0cmluZyA9ICQodGhpcykudmFsKCk7XG4gICAgdmFyIGFJdGVtcyA9IFtdO1xuICAgIC8vIGNvbnNvbGUubG9nKHR5cGVvZiBzU2VhcmNoU3RyaW5nKTtcblxuICAgIHZhciB0aXRsZSA9ICcnO1xuICAgIHZhciBtYWluQWN0aXZldHkgPSBcIlwiO1xuICAgIHZhciB0cmlwRGVzY3JpcHRpb24gPSBcIlwiO1xuICAgIHZhciBzZWFzb24gPSBcIlwiO1xuICAgIHZhciBhbGxBY3RpdmV0aWVzID0gW107XG4gICAgdmFyIHRyaXBzID0gZGF0YS50cmlwcztcbiAgICB2YXIgYWxsQWN0aXZUb0xvd2VyQ2FzZSA9IFwiXCI7XG4gICAgLy8gY29uc29sZS5sb2codHJpcHMpO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdHJpcHMubGVuZ3RoOyBpKyspIHtcbiAgICAgIHRpdGxlID0gdHJpcHNbaV0udGl0bGUudG9Mb3dlckNhc2UoKTtcbiAgICAgIHRyaXBEZXNjcmlwdGlvbiA9IHRyaXBzW2ldLmRlc2NyaXB0aW9uLnRvTG93ZXJDYXNlKCk7XG4gICAgICBtYWluQWN0aXZldHkgPSB0cmlwc1tpXS5hY3Rpdml0eUNhdGVnb3JpZXNbMF07XG4gICAgICBhbGxBY3RpdmV0aWVzID0gdHJpcHNbaV0uYWN0aXZpdHlDYXRlZ29yaWVzO1xuICAgICAgc2Vhc29uID0gdHJpcHNbaV0uc2Vhc29uLnRvTG93ZXJDYXNlKCk7XG4gICAgICB2YXIgZmlsdGVyZWRBcnJheSA9IFtdO1xuICAgICAgc1Jlc3VsdHNEcm9wZG93bi5pbm5lckhUTUwgPSBcIlwiO1xuXG4gICAgICB2YXIgc2VhcmNoUmVzYXVsdHMgPSAgdGl0bGUuaW5jbHVkZXMoc1NlYXJjaFN0cmluZy50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgICAgIHRyaXBEZXNjcmlwdGlvbi5pbmNsdWRlcyhzU2VhcmNoU3RyaW5nLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICAgICAgLy8gYWxsQWN0aXZUb0xvd2VyQ2FzZS5pbmNsdWRlcyhzU2VhcmNoU3RyaW5nLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICAgICAgc2Vhc29uLmluY2x1ZGVzKHNTZWFyY2hTdHJpbmcudG9Mb3dlckNhc2UoKSk7XG5cbiAgICAgIGlmKCBzZWFyY2hSZXNhdWx0cyAmJiAhc1NlYXJjaFN0cmluZy5sZW5ndGggPCAxIClcbiAgICAgIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2codHJpcHNbaV0pO1xuICAgICAgICBzUmVzdWx0c0Ryb3Bkb3duLmNsYXNzTGlzdC5hZGQoJ3NlYXJjaEFjdGl2ZScpO1xuICAgICAgICBhSXRlbXMucHVzaCh0cmlwc1tpXSk7XG4gICAgICAgIGZpbHRlcmVkQXJyYXkgPSBhSXRlbXMuZmlsdGVyKGZ1bmN0aW9uKGl0ZW0sIHBvcyl7XG4gICAgICAgICAgcmV0dXJuIGFJdGVtcy5pbmRleE9mKGl0ZW0pID09IHBvcztcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdmFyIHJlc3VsdFRpdGxlID0gJyc7XG4gICAgICAgIHZhciByZXN1bHRBY3RpdmV0eSA9ICcnO1xuICAgICAgICB2YXIgc1Jlc3VsdFJlbmRlciA9IFwiXCI7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGZpbHRlcmVkQXJyYXkpO1xuICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGZpbHRlcmVkQXJyYXkubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAvLyBjb25zb2xlLmxvZyhmaWx0ZXJlZEFycmF5W2pdLnRpdGxlKTtcbiAgICAgICAgICByZXN1bHRUaXRsZSA9IGZpbHRlcmVkQXJyYXlbal0udGl0bGU7XG4gICAgICAgICAgcmVzdWx0QWN0aXZldHkgPSBmaWx0ZXJlZEFycmF5W2pdLnNlYXNvbjtcbiAgICAgICAgICBzUmVzdWx0UmVuZGVyICs9ICc8ZGl2IGNsYXNzPVwicmVzdWx0SXRlbVwiIGRhdGEtdHJpcGlkPVwiJytmaWx0ZXJlZEFycmF5W2pdLmlkKydcIj48c3BhbiBjbGFzcz1cInNTZWFyY2hWYWwgcmVzdWx0X3RpdGxlXCI+JytyZXN1bHRUaXRsZSsnPC9zcGFuPjxzcGFuIGNsYXNzPVwicmVzdWx0X3NlYXNvbiBzU2VhcmNoVmFsXCI+JytyZXN1bHRBY3RpdmV0eS5yZXBsYWNlKC9fL2csIFwiIFwiKSsnPC9zcGFuPjwvZGl2Pic7XG4gICAgICAgIH1cbiAgICAgICAgc1Jlc3VsdHNEcm9wZG93bi5pbm5lckhUTUwgPSBzUmVzdWx0UmVuZGVyO1xuXG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coc1NlYXJjaFN0cmluZy5sZW5ndGgpO1xuICAgICAgICBzUmVzdWx0c0Ryb3Bkb3duLmNsYXNzTGlzdC5yZW1vdmUoJ3NlYXJjaEFjdGl2ZScpO1xuICAgICAgICBzUmVzdWx0c0Ryb3Bkb3duLmlubmVySFRNTCA9ICcnO1xuICAgICAgfVxuXG5cbiAgICAgIC8vIGZvciAodmFyIHQgPSAwOyB0IDwgYWxsQWN0aXZldGllcy5sZW5ndGg7IHQrKylcbiAgICAgIC8vIHtcbiAgICAgIC8vICAgIGFsbEFjdGl2VG9Mb3dlckNhc2UgPSAgYWxsQWN0aXZldGllc1t0XS5yZXBsYWNlKC9fL2csIFwiIFwiKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgLy8gICAvLyBjb25zb2xlLmxvZyhhbGxBY3RpdlRvTG93ZXJDYXNlKTtcbiAgICAgIC8vICAgLy8gY29uc29sZS5sb2coc1NlYXJjaFN0cmluZyk7XG4gICAgICAvLyAgIC8vIGNvbnNvbGUubG9nKHRpdGxlKTtcbiAgICAgIC8vXG4gICAgICAvLyAgIC8vIGVsc2Uge1xuICAgICAgLy8gICAvLyAgICAgc1Jlc3VsdHNEcm9wZG93bi5jbGFzc0xpc3QucmVtb3ZlKCdzZWFyY2hBY3RpdmUnKTtcbiAgICAgIC8vICAgLy8gfVxuICAgICAgLy8gICBpZihzUmVzdWx0c0Ryb3Bkb3duLm9mZnNldEhlaWdodCA+IDIxKXtcbiAgICAgIC8vXG4gICAgICAvLyAgICAgLy8gIHNSZXN1bHRzRHJvcGRvd24uY2xhc3NMaXN0LnJlbW92ZSgnc2VhcmNoQWN0aXZlJyk7XG4gICAgICAvLyAgIH1cbiAgICAgIC8vICAgLy8gZWxzZSB7XG4gICAgICAvLyAgIC8vICAgc1Jlc3VsdHNEcm9wZG93bi5jbGFzc0xpc3QuYWRkKCdzZWFyY2hBY3RpdmUnKTtcbiAgICAgIC8vICAgLy8gfVxuICAgICAgLy8gfVxuICAgIH1cblxuICAgIC8vIGNvbnNvbGUubG9nKHNSZXN1bHRSZW5kZXIpO1xuXG5cbiAgICAvLyBmaWx0ZXJlZEFycmF5ID0gW107XG4gICAgY29uc29sZS5sb2coZmlsdGVyZWRBcnJheSk7XG4gIH0pO1xufSk7XG5cbmZ1bmN0aW9uIGlzRGVzY2VuZGFudChwYXJlbnQsIGNoaWxkKSB7XG4gIHZhciBub2RlID0gY2hpbGQucGFyZW50Tm9kZTtcbiAgd2hpbGUgKG5vZGUgIT0gbnVsbCkge1xuICAgIGlmIChub2RlID09IHBhcmVudCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIG5vZGUgPSBub2RlLnBhcmVudE5vZGU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxudmFyIGlDb3VudCA9IDA7XG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGZ1bmN0aW9uKGUpe1xuICB2YXIgc2VhcmNoVmFsdWU9Jyc7XG4gIHZhciBzZWFyY2hWYWx1ZUlkID0gJyc7XG4gIGlmKGUudGFyZ2V0LmNsYXNzTGlzdC5jb250YWlucygncmVzdWx0SXRlbScpKXtcbiAgICAvLyBjb25zb2xlLmRpcihlLnRhcmdldC5jaGlsZHJlblswXS5pbm5lckhUTUwpO1xuICAgIHNlYXJjaFZhbHVlID0gZS50YXJnZXQuY2hpbGRyZW5bMF0uaW5uZXJIVE1MO1xuICAgIGFjdGl2aXRpZXNTZWFyY2gudmFsdWUgPSBzZWFyY2hWYWx1ZTtcbiAgICBzUmVzdWx0c0Ryb3Bkb3duLmNsYXNzTGlzdC5yZW1vdmUoJ3NlYXJjaEFjdGl2ZScpO1xuXG4gIH1cbiAgaWYoZS50YXJnZXQuY2xhc3NMaXN0LmNvbnRhaW5zKCdyZXN1bHRfc2Vhc29uJykpe1xuICAgIC8vIGNvbnNvbGUuZGlyKGUudGFyZ2V0LnByZXZpb3VzRWxlbWVudFNpYmxpbmcuaW5uZXJIVE1MKTtcbiAgICBzZWFyY2hWYWx1ZSA9IGUudGFyZ2V0LnByZXZpb3VzRWxlbWVudFNpYmxpbmcuaW5uZXJIVE1MO1xuICAgIC8vIGNvbnNvbGUubG9nKHNlYXJjaFZhbHVlSWQpO1xuICAgIGFjdGl2aXRpZXNTZWFyY2gudmFsdWUgPSBzZWFyY2hWYWx1ZTtcbiAgICBzUmVzdWx0c0Ryb3Bkb3duLmNsYXNzTGlzdC5yZW1vdmUoJ3NlYXJjaEFjdGl2ZScpO1xuICB9XG4gIGlmKGUudGFyZ2V0LmNsYXNzTGlzdC5jb250YWlucygncmVzdWx0X3RpdGxlJykpe1xuICAgIC8vIGNvbnNvbGUuZGlyKGUudGFyZ2V0LnByZXZpb3VzRWxlbWVudFNpYmxpbmcuaW5uZXJIVE1MKTtcbiAgICBzZWFyY2hWYWx1ZSA9IGUudGFyZ2V0LmlubmVySFRNTDtcbiAgICBhY3Rpdml0aWVzU2VhcmNoLnZhbHVlID0gc2VhcmNoVmFsdWU7XG4gICAgc1Jlc3VsdHNEcm9wZG93bi5jbGFzc0xpc3QucmVtb3ZlKCdzZWFyY2hBY3RpdmUnKTtcbiAgfVxuICAvLyBjb25zb2xlLmxvZyhlLnRhcmdldCk7XG4gIGlmIChlLnRhcmdldC5jbGFzc0xpc3QuY29udGFpbnMoJ3NTZWFyY2hWYWwnKSkge1xuICAgIC8vIGNvbnNvbGUubG9nKCd4Jyk7XG4gICAgdmFyIHBhcmVudElEID0gZS50YXJnZXQucGFyZW50RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2RhdGEtdHJpcGlkJyk7XG4gICAgLy8gJCgnI2FjdGl2aXRpZXNTZWFyY2gnKS52YWwoKSA9IHBhcmVudElEO1xuICAgIHdpZGdldF9pZC52YWx1ZSA9IHBhcmVudElEO1xuICAgIC8vIGNvbnNvbGUubG9nKHBhcmVudElEKTtcbiAgfVxuICAvLyB2YXIgY291bnRlckNvbnRhaW5lciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5jb3VudGVyQ29udGFpbmVyJyk7XG4gIGlmIChlLnRhcmdldC5pZCA9PSAnY291bnRlcicpIHtcbiAgICAvLyBjb25zb2xlLmxvZyhjb3VudGVyQ29udGFpbmVyKTtcbiAgICAgIGNvdW50ZXJDb250YWluZXIuY2xhc3NMaXN0LmFkZCgnc2NhbGVVcCcpO1xuICB9XG4gIGlmKGUudGFyZ2V0LmNsYXNzTGlzdC5jb250YWlucygnYnRuQ2xvc2VDb3VudCcpICkge1xuICAgIGNvdW50ZXJDb250YWluZXIuY2xhc3NMaXN0LnJlbW92ZSgnc2NhbGVVcCcpO1xuICB9XG5cbiAvLyBjb25zb2xlLmxvZyhpc0Rlc2NlbmRhbnQoY291bnRlckNvbnRhaW5lciwgZS50YXJnZXQpKTtcbiAgdmFyIGJ0bkNvdW50ZXJDb3VudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNjb3VudGVyJyk7XG4gIGlmKGJ0bkNvdW50ZXJDb3VudClcbiAge1xuICAgIHZhciBpc0NsaWNrSW5pZGUgPSBidG5Db3VudGVyQ291bnQuY29udGFpbnMoZS50YXJnZXQpIHx8IGlzRGVzY2VuZGFudChjb3VudGVyQ29udGFpbmVyLCBlLnRhcmdldCk7XG4gICAgaWYgKCFpc0NsaWNrSW5pZGUgJiYgY291bnRlckNvbnRhaW5lci5jbGFzc0xpc3QuY29udGFpbnMoJ3NjYWxlVXAnKSl7XG4gICAgIGNvdW50ZXJDb250YWluZXIuY2xhc3NMaXN0LnRvZ2dsZSgnc2NhbGVVcCcpO1xuICAgIH1cbiAgfVxuICB2YXIgaW5wdXRDb3VudCA9IFwiXCI7XG4gIGlmKGUudGFyZ2V0LmNsYXNzTGlzdC5jb250YWlucygnYnRuUGx1cycpKSB7XG4gICAgaW5wdXRDb3VudCA9IGUudGFyZ2V0LnBhcmVudE5vZGUucGFyZW50Tm9kZS5jaGlsZHJlblswXS5jaGlsZHJlblswXTtcbiAgICBpQ291bnQgPSBOdW1iZXIoaW5wdXRDb3VudC52YWx1ZSkgKzE7XG4gICAgaWYoIE51bWJlcihpbnB1dENvdW50LnZhbHVlKSA8IDUpIHtcbiAgICAgIGlucHV0Q291bnQudmFsdWUgPSBpQ291bnQ7XG4gICAgfVxuXG4gIH1cbiAgaWYoZS50YXJnZXQuY2xhc3NMaXN0LmNvbnRhaW5zKCdidG5NaW51cycpKSB7XG4gICAgaW5wdXRDb3VudCA9IGUudGFyZ2V0LnBhcmVudE5vZGUucGFyZW50Tm9kZS5jaGlsZHJlblswXS5jaGlsZHJlblswXTtcbiAgICBpQ291bnQgPSBOdW1iZXIoaW5wdXRDb3VudC52YWx1ZSkgLTE7XG4gICAgaWYoTnVtYmVyKGlucHV0Q291bnQudmFsdWUpID4gMCApIHtcbiAgICAgIGlucHV0Q291bnQudmFsdWUgPSBpQ291bnQ7XG4gICAgfVxuICB9XG59KTtcblxuJCgnI3Nob3dGaWx0ZXJlZFRyaXAnKS5jbGljayhmdW5jdGlvbigpe1xuICAkLnBvc3QodGVtcGxhdGVVcmwrXCIvbGlicmFyeS9ib2t1bi5waHA/Y2hlY2t0cmlwPXRydWVcIiwgJCggXCIjZnBGaWx0ZXJcIiApLnNlcmlhbGl6ZSgpLCBmdW5jdGlvbihkYXRhKXtcbiAgICBjb25zb2xlLmxvZyhkYXRhKTtcbiAgfSk7XG59KVxuIiwialF1ZXJ5KGRvY3VtZW50KS5mb3VuZGF0aW9uKCk7XG4iLCIvLyBKb3lyaWRlIGRlbW9cbiQoJyNzdGFydC1qcicpLm9uKCdjbGljaycsIGZ1bmN0aW9uKCkge1xuICAkKGRvY3VtZW50KS5mb3VuZGF0aW9uKCdqb3lyaWRlJywnc3RhcnQnKTtcbn0pOyIsImZ1bmN0aW9uIHJlc2l6ZShldmVudCkge1xuICAvLyBjb25zb2xlLmxvZyhldmVudCk7XG4gIG93bC50cmlnZ2VyKCdkZXN0cm95Lm93bC5jYXJvdXNlbCcpO1xufVxuaWYod2luZG93LmlubmVyV2lkdGggPD0gMTAyNCl7XG4gIHZhciBvd2wgPSAkKCcjY2FyZHMnKTtcbiAgb3dsLm93bENhcm91c2VsKHtcbiAgICBkb3RzOiBmYWxzZSxcbiAgICByZXNwb25zaXZlOntcbiAgICAgICAgMDp7XG4gICAgICAgICAgaXRlbXM6MSxcbiAgICAgICAgICBuYXY6ZmFsc2UsXG4gICAgICAgICAgbG9vcDogdHJ1ZSxcbiAgICAgICAgICBzdGFnZVBhZGRpbmc6IDMwLFxuICAgICAgICAgIGRvdHM6IGZhbHNlXG4gICAgICAgIH0sXG4gICAgICAgIDY0MDp7XG4gICAgICAgICAgaXRlbXM6MixcbiAgICAgICAgICBuYXY6ZmFsc2UsXG4gICAgICAgICAgbG9vcDogdHJ1ZSxcbiAgICAgICAgICBzdGFnZVBhZGRpbmc6IDEwLFxuICAgICAgICAgIGRvdHM6IGZhbHNlXG4gICAgICAgIH0sXG4gICAgICAgIDEwMjQ6e1xuICAgICAgICAgIGl0ZW1zOjIsXG4gICAgICAgICAgbmF2OmZhbHNlLFxuICAgICAgICAgIGxvb3A6IHRydWUsXG4gICAgICAgICAgc3RhZ2VQYWRkaW5nOiAzNSxcbiAgICAgICAgICBkb3RzOiBmYWxzZSxcbiAgICAgICAgICBvblJlc2l6ZTogcmVzaXplXG4gICAgICAgIH1cbiAgICAgfVxuICAgfSk7XG5cbn1cblxudmFyIHBvc3RPd2wgPSAkKCcjY2FyZHNQb3N0Jyk7XG5wb3N0T3dsLm93bENhcm91c2VsKHtcbiAgaXRlbXM6MSxcbiAgbmF2OmZhbHNlLFxuICBsb29wOiB0cnVlLFxuICBzdGFnZVBhZGRpbmc6IDEwLFxuICBkb3RzOiBmYWxzZSxcbiAgYXV0b3BsYXk6IHRydWUsXG5cbiAgcmVzcG9uc2l2ZTp7XG4gICAgICAwOntcbiAgICAgICAgaXRlbXM6MSxcbiAgICAgICAgbmF2OmZhbHNlLFxuICAgICAgICBsb29wOiB0cnVlLFxuICAgICAgICBzdGFnZVBhZGRpbmc6IDMwLFxuICAgICAgICBkb3RzOiBmYWxzZVxuICAgICAgfSxcbiAgICAgIDY0MDp7XG4gICAgICAgIGl0ZW1zOjIsXG4gICAgICAgIG5hdjpmYWxzZSxcbiAgICAgICAgbG9vcDogdHJ1ZSxcbiAgICAgICAgc3RhZ2VQYWRkaW5nOiA5MCxcbiAgICAgICAgZG90czogZmFsc2VcbiAgICAgIH0sXG4gICAgICAxMDI0OntcbiAgICAgICAgaXRlbXM6MyxcbiAgICAgICAgbmF2OmZhbHNlLFxuICAgICAgICBsb29wOiB0cnVlLFxuICAgICAgICBzdGFnZVBhZGRpbmc6IDEwLFxuICAgICAgICBkb3RzOiBmYWxzZVxuICAgICAgICAvLyBvblJlc2l6ZTogcmVzaXplXG4gICAgICB9LFxuICAgICAgMTIwMDp7XG4gICAgICAgIGl0ZW1zOjQsXG4gICAgICAgIG5hdjpmYWxzZSxcbiAgICAgICAgbG9vcDogdHJ1ZSxcbiAgICAgICAgc3RhZ2VQYWRkaW5nOiAxMCxcbiAgICAgICAgZG90czogZmFsc2VcbiAgICAgICAgLy8gb25SZXNpemU6IHJlc2l6ZVxuICAgICAgfVxuICAgIH1cbn0pO1xuXG5cblxuXG5cbi8vICQod2luZG93KS5yZXNpemUoZnVuY3Rpb24oKXtcbi8vICAgY29uc29sZS5sb2coJ3gnKTtcbi8vICAgaWYod2luZG93LmlubmVyV2lkdGggPD0gMTAyNCkge1xuLy8gICAgICBvd2wudHJpZ2dlcignZGVzdHJveS5vd2wuY2Fyb3VzZWwnKTtcbi8vICAgfVxuLy9cbi8vIH0pXG4iLCIiLCIkKGRvY3VtZW50KS5yZWFkeShmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHZpZGVvcyA9ICQoJ2lmcmFtZVtzcmMqPVwidmltZW8uY29tXCJdLCBpZnJhbWVbc3JjKj1cInlvdXR1YmUuY29tXCJdJyk7XG5cbiAgICB2aWRlb3MuZWFjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBlbCA9ICQodGhpcyk7XG4gICAgICAgIGVsLndyYXAoJzxkaXYgY2xhc3M9XCJyZXNwb25zaXZlLWVtYmVkIHdpZGVzY3JlZW5cIi8+Jyk7XG4gICAgfSk7XG59KTtcbiIsInZhciBvblNjcm9sbCA9IGZ1bmN0aW9uKGNvbnRhaW5lciwgdGhlY2xhc3MsIGFtb3VudCkge1xuXHRcdHZhciB3cmFwID0gJChjb250YWluZXIpO1xuXHRcdCQod2luZG93KS5zY3JvbGwoZnVuY3Rpb24oKXtcblx0XHRcdGlmICgkKGRvY3VtZW50KS5zY3JvbGxUb3AoKSA+IGFtb3VudCkge1xuXHRcdFx0XHR3cmFwLmFkZENsYXNzKHRoZWNsYXNzKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHQgIHdyYXAucmVtb3ZlQ2xhc3ModGhlY2xhc3MpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHR9O1xuXG5vblNjcm9sbCgnLm1haW4tbmF2LWNvbnRhaW5lcicsJ3NldC1uYXYtcG9zaXRpb24nLCAxICk7XG5cbiQoJy5jYWxsJykuY2xpY2soZnVuY3Rpb24oKXtcblx0JCgnLmJ1cmdlcicpLnRvZ2dsZUNsYXNzKCd0aGV4Jyk7XG5cdCQoJ2JvZHknKS50b2dnbGVDbGFzcygnc3RvcC1zY3JvbGxpbmcnKTtcblx0Ly8gJCgnI29mZkNhbnZhcycpLnRvZ2dsZUNsYXNzKCdwb3NpdGlvbi1sZWZ0Jyk7XG5cdC8vICAkKGRvY3VtZW50KS5mb3VuZGF0aW9uKCk7XG59KTtcblxuJCgnLmlzLWFjY29yZGlvbi1zdWJtZW51LXBhcmVudCcpLmNsaWNrKGZ1bmN0aW9uKCl7XG5cdC8vICQoJ2JvZHknKS50b2dnbGVDbGFzcygnc3RvcC1zY3JvbGxpbmcnKTtcbn0pO1xuXG4kKCcuaXMtZHJvcGRvd24tc3VibWVudS1wYXJlbnQnKS5tb3VzZW92ZXIoZnVuY3Rpb24oKXtcblx0JCgnLmZpcnN0LXN1YicpLnRvZ2dsZUNsYXNzKCdtZW51LWFuaW1hdGlvbicpO1xufSk7XG5cbiQoJy5maWx0ZXJidXR0b24nKS5vbignY2xpY2snLCBmdW5jdGlvbigpe1xuXHQkKCcjbmF2QWN0aXZldHknKS5hZGRDbGFzcygnc2hvd05hdkFjdGl2ZXR5Jyk7XG5cdCQoJ2JvZHknKS5hZGRDbGFzcygnc3RvcC1zY3JvbGxpbmcnKTtcbn0pO1xuXG4kKCcjY2xvc2VBY3RpdmV0eU5hdicpLm9uKCdjbGljaycsIGZ1bmN0aW9uKCl7XG5cdCQoJyNuYXZBY3RpdmV0eScpLnJlbW92ZUNsYXNzKCdzaG93TmF2QWN0aXZldHknKTtcblx0JCgnYm9keScpLnJlbW92ZUNsYXNzKCdzdG9wLXNjcm9sbGluZycpO1xufSk7XG4iLCJcbiQod2luZG93KS5iaW5kKCcgbG9hZCByZXNpemUgb3JpZW50YXRpb25DaGFuZ2UgJywgZnVuY3Rpb24gKCkge1xuICAgdmFyIGZvb3RlciA9ICQoXCIjZm9vdGVyLWNvbnRhaW5lclwiKTtcbiAgIHZhciBwb3MgPSBmb290ZXIucG9zaXRpb24oKTtcbiAgIHZhciBoZWlnaHQgPSAkKHdpbmRvdykuaGVpZ2h0KCk7XG4gICBoZWlnaHQgPSBoZWlnaHQgLSBwb3MudG9wO1xuICAgaGVpZ2h0ID0gaGVpZ2h0IC0gZm9vdGVyLmhlaWdodCgpIC0xO1xuXG4gICBmdW5jdGlvbiBzdGlja3lGb290ZXIoKSB7XG4gICAgIGZvb3Rlci5jc3Moe1xuICAgICAgICAgJ21hcmdpbi10b3AnOiBoZWlnaHQgKyAncHgnXG4gICAgIH0pO1xuICAgfVxuXG4gICBpZiAoaGVpZ2h0ID4gMCkge1xuICAgICBzdGlja3lGb290ZXIoKTtcbiAgIH1cbn0pO1xuIl19
