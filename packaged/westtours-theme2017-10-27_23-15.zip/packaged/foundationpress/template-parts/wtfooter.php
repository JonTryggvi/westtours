<div class="wt-footer expanded row align-center">
  <div class="wt-footer-smedia medium-4">
    <ul class="wt-footer-smedia-list row align-spaced">
      <li class="trip"><a href="#"><img src="<?php echo get_template_directory_uri().'/assets/images/icons/tripadvisor-logotype.svg'; ?>" alt="tripadvisor link icon" /></a></li>
      <li class="facebook"><a href="#"><img src="<?php echo get_template_directory_uri(). '/assets/images/icons/Facebook.svg'; ?>" alt="facebook link icon" /></a></li>
      <li class="twitter"><a href="#"><img src="<?php echo get_template_directory_uri(). '/assets/images/icons/Twitter.svg'; ?>" alt="twitter link icon" /></a></li>
      <li class="Instagram"><a href="#"><img src="<?php echo get_template_directory_uri().'/assets/images/icons/Instagram.svg'; ?>" alt="instagram link icon" /></a></li>
    </ul>
  </div>
  <div class="wt-footer-adress-secton medium-12 row align-center">
    <ul class="wt-footer-contact medium-6 row align-spaced">
      <li class="medium-2">Aðalstræti 7</li>
      <li class="medium-3">400 Ísafjörður</li>
      <li class="medium-3"><a href="tel:+3544565111">Phone: +354 456 5111</a></li>
      <li class="medium-3"><a href="mailto:westtours@westtours.is">westtours@westtours.is</a></li>
    </ul>
  </div>
</div>
