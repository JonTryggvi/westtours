$('#from').dateRange({
  selected: function(dates) {
    var from = dates[0];
    var to = dates[1];
    // console.log(dates);
    //do something special
  }
});