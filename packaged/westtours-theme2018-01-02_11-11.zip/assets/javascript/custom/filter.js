function searchJson(that, data) {
  var sSearchString = that.val();
  var aItems = [];
  // console.log(typeof sSearchString);

  var title = '';
  var mainActivety = "";
  var tripDescription = "";
  var season = "";
  var allActiveties = [];
  var trips = data.trips;
  var allActivToLowerCase = "";
  // console.log(trips);

  var aTripTitles = [];
  var aTripDescription = [];
  var aAllCategories = [];
  for (var i = 0; i < trips.length; i++) {
    title = trips[i].title.toLowerCase();
    aTripTitles.push(title);
    tripDescription = trips[i].description.toLowerCase();
    aTripDescription.push(tripDescription);
    mainActivety = trips[i].activityCategories[0];
    allActiveties = trips[i].activityCategories;
    aAllCategories.push(allActiveties);

    season = trips[i].season.toLowerCase();
    var filteredArray = [];
    // sResultsDropdown.innerHTML = "";
    // console.log(title);
    var searchResaults = aTripTitles.find(a => a.includes(sSearchString.toLowerCase())) ||
      aTripDescription.find(a => a.includes(sSearchString.toLowerCase())) ||
      aAllCategories.find(a => a.includes(sSearchString.toLowerCase())) ||
      season.includes(sSearchString.toLowerCase());



    if (searchResaults && !sSearchString.length < 1) {
      // console.log(trips[i]);


      aItems.push(trips[i]);
      filteredArray = aItems.filter(function(item, pos) {
        return aItems.indexOf(item) == pos;
      });
      if (aItems.length > 0) {
        sResultsDropdown.classList.add('searchActive');
      }
      var resultTitle = '';
      var resultActivety = '';
      var sResultRender = "";
      // console.log(aItems);
      // console.log(filteredArray);
      for (var j = 0; j < filteredArray.length; j++) {
        // console.log(filteredArray[j].title);
        resultTitle = filteredArray[j].title;
        resultActivety = filteredArray[j].season;
        sResultRender += '<div class="resultItem" data-tripid="' + filteredArray[j].id + '"><span class="sSearchVal result_title">' + resultTitle + '</span><span class="result_season sSearchVal">' + resultActivety.replace(/_/g, " ") + '</span></div>';
      }
      sResultsDropdown.innerHTML = sResultRender;
    } else {
      // console.log(sSearchString.length);
      sResultsDropdown.classList.remove('searchActive');
      sResultsDropdown.innerHTML = '';
    }
  }
}

function checkAvailable(id) {
  $.post(templateUrl + "/library/bokun.php?checkAvailable=true", {
    "tripId": id
  }, function(data) {
    var aData = JSON.parse(data);
    // console.log(aData);
    var parseTimeFirst = new Date(aData[0].date);
    var parseTimeLast = new Date(aData[9].date);
    // console.log(parseTimeLast);



  });
}


$.getJSON(templateUrl + "/library/detailedtrips.json", function(data) {
  $('#activitiesSearch').on('keyup', function() {
    var that = $(this);
    searchJson(that, data);
  });
  $('#activetySearchPost').on('keyup', function() {
    var that = $(this);
    searchJson(that, data);
  });
});

function renderCounter() {
  var sCounterResult = '';
  var counter = $('#counter');
  var iAdultVal = Number($('#txtAdult').val());
  var iChildVal = Number($('#txtChild').val());
  var iInfantVal = Number($('#txtInfant').val());
  if (iAdultVal > 0 && iAdultVal < 2) {
    sCounterResult = iAdultVal + ' adult';
    counter.val(sCounterResult);
  } else if (iAdultVal > 1) {
    sCounterResult = iAdultVal + ' adults';
    counter.val(sCounterResult);
  }
  if (iChildVal > 0 && iChildVal < 2) {
    if (iAdultVal < 1) {
      counter.val('min 1 adult');
      return;
    }
    sCounterResult = sCounterResult + ', ' + iChildVal + ' child';
    counter.val(sCounterResult);
  } else if (iChildVal > 1) {
    sCounterResult = sCounterResult + ', ' + iChildVal + ' children';
    counter.val(sCounterResult);
  }

  if (iInfantVal > 0 && iInfantVal < 2) {
    if (iAdultVal < 1) {
      counter.val('min 1 adult');
      return;
    }
    sCounterResult = sCounterResult + ', ' + iInfantVal + ' infant';
    counter.val(sCounterResult);
  } else if (iInfantVal > 1) {
    sCounterResult = sCounterResult + ', ' + iInfantVal + ' infants';
    counter.val(sCounterResult);
  }
}


function isDescendant(parent, child) {
  var node = child.parentNode;
  while (node != null) {
    if (node == parent) {
      return true;
    }
    node = node.parentNode;
  }
  return false;
}
var iCount = 0;
document.addEventListener('click', function(e) {
  // console.log(e.target);
  var searchValue = '';
  var searchValueId = '';
  var searchTripId = '';
  if (e.target.classList.contains('resultItem')) {
    // console.dir(e.target.children[0].innerHTML);
    searchValue = e.target.children[0].innerHTML;
    searchTripId = e.target.getAttribute('data-tripid');
    // checkAvailable(searchTripId);
    activitiesSearch.value = searchValue;
    sResultsDropdown.classList.remove('searchActive');


  }
  if (e.target.classList.contains('result_season')) {
    // console.dir(e.target.previousElementSibling.innerHTML);
    searchValue = e.target.previousElementSibling.innerHTML;
    searchTripId = e.target.parentNode.getAttribute('data-tripid');
    // console.log(searchValueId);
    // checkAvailable(searchTripId);
    activitiesSearch.value = searchValue;
    sResultsDropdown.classList.remove('searchActive');
  }
  if (e.target.classList.contains('result_title')) {
    // console.dir(e.target.previousElementSibling.innerHTML);
    searchValue = e.target.innerHTML;
    searchTripId = e.target.parentNode.getAttribute('data-tripid');
    activitiesSearch.value = searchValue;
    // checkAvailable(searchTripId);
    sResultsDropdown.classList.remove('searchActive');
  }
  // console.log(e.target);
  if (e.target.classList.contains('sSearchVal')) {
    // console.log('x');
    var parentID = e.target.parentElement.getAttribute('data-tripid');
    // $('#activitiesSearch').val() = parentID;
    widget_id.value = parentID;
    // console.log(parentID);
  }
  // var counterContainer = document.querySelectorAll('.counterContainer');
  if (e.target.id == 'counter') {
    // console.log(counterContainer);
    counterContainer.classList.add('setFlex');
  }
  if (e.target.classList.contains('btnCloseCount')) {
    counterContainer.classList.remove('setFlex');
    renderCounter();
  }

  // console.log(isDescendant(counterContainer, e.target));
  var btnCounterCount = document.querySelector('#counter');
  if (btnCounterCount) {
    var isClickInide = btnCounterCount.contains(e.target) || isDescendant(counterContainer, e.target);
    if (!isClickInide && counterContainer.classList.contains('setFlex')) {
      counterContainer.classList.toggle('setFlex');
      renderCounter();
    }
  }
  var inputCount = "";
  if (e.target.classList.contains('btnPlus')) {
    inputCount = e.target.parentNode.parentNode.children[0].children[0];
    iCount = Number(inputCount.value) + 1;
    if (Number(inputCount.value) < 5) {
      inputCount.value = iCount;
    }

  }
  if (e.target.classList.contains('btnMinus')) {
    inputCount = e.target.parentNode.parentNode.children[0].children[0];
    iCount = Number(inputCount.value) - 1;
    if (Number(inputCount.value) > 0) {
      inputCount.value = iCount;
    }
  }
  if (e.target.classList.contains('btnTripDate')) {
    var sjActivetyObj = e.target.getAttribute('data-cost');
    var sjTickedType = e.target.getAttribute('data-tickettype');
    console.log(sjTickedType);
    var jActivetyObj = JSON.parse(sjActivetyObj);
    var jTickedType = JSON.parse(sjTickedType);
    $.post(templateUrl + "/library/bokun.php?checkprice=true", {
      "trip": jActivetyObj,
      "ticket": jTickedType
    }, function(sajData) {
      // console.log(sajData);
      var ajFiltered = JSON.parse(sajData);
      // console.log(ajFiltered[0][0]);
      var jFilteredPrice = ajFiltered[0][0];
      var ajFilteredTicket = ajFiltered[1];
      var ajFilteredPriceTicket = jFilteredPrice.pricingCategoryBookings;
      var jFilteredDate = ajFiltered[0][0].date;
      // console.log(jFilteredDate);
      // console.log(ajFilteredPriceTicket);
      // console.log(ajFilteredTicket);
      // console.log(ajFiltered);
      var ticketName = "",
        ticketCountAdult,
        ticketCountChild,
        ticketCountInfant,
        adultTicketid,
        childTicketId,
        infantTicketId,
        adultAmount,
        childAmount,
        infantAmount;
      for (var i = 0; i < ajFilteredPriceTicket.length; i++) {
        if (ajFilteredPriceTicket[i].pricingCategoryId == ajFilteredTicket[i].pricingCategoryId) {
          ticketName = ajFilteredTicket[i].type;
          switch (ticketName) {
            case "ADULT":
              ticketCountAdult = ajFilteredPriceTicket.length;
              // console.log(ticketCountAdult);
              adultTicketid = ajFilteredPriceTicket[i].pricingCategoryId;
              adultAmount = ajFilteredPriceTicket[i].bookedPrice * ticketCountAdult;
              break;
            case "CHILD":
              ticketCountChild = ajFilteredPriceTicket.length;
              childTicketId = ajFilteredPriceTicket[i].pricingCategoryId;
              childAmount = ajFilteredPriceTicket[i].bookedPrice * ticketCountChild;
              break;
            case "INFANT":
              ticketCountInfant = ajFilteredPriceTicket.length;
              infantTicketId = ajFilteredPriceTicket[i].pricingCategoryId;
              infantAmount = ajFilteredPriceTicket[i].bookedPrice * ticketCountInfant;
              break;
            default:
              ticketCountAdult = 0;
              ticketCountChild = 0;
              ticketCountInfant = 0;
          }
        }
      }
      // console.log('adtul: ' + ticketCountAdult,'child: ' + ticketCountChild);
      var totalPrice = jFilteredPrice.totalPrice;
      // console.log(jFilteredPrice);
      // console.log(totalPrice);
      var jTrip = {
        "totalPrice": totalPrice,
        "adultPrice": adultAmount,
        "childPrice": childAmount,
        "infantPrice": infantAmount,
        "adultCount": ticketCountAdult,
        "childCount": ticketCountChild,
        "infantCount": ticketCountInfant,
        "tripDate": jFilteredDate
      }

      $.get(rootUrl + '/wp-json/wp/v2/tour_post_type?per_page=100', function(wpPostData) {
        var permaLink = "";
        for (var w = 0; w < wpPostData.length; w++) {
          // console.log(wpPostData[w]);
          if (jFilteredPrice.activity.id == wpPostData[w].acf.bokun_int_id) {
            // console.log( wpPostData[w] );
            permaLink = wpPostData[w].link;
          }
        }
        $(location).attr('href', permaLink + '?total=' + jTrip.totalPrice + '&adult=' + jTrip.adultPrice + '&child=' + jTrip.childPrice + '&infant=' + jTrip.infantPrice + '&adulti=' + jTrip.adultCount + '&childi=' + jTrip.childCount + '&=infanti=' + jTrip.infantCount + '&date=' + jTrip.tripDate);
      });
      // console.log(permaLink);
    });
  }
  if (e.target.classList.contains('close') || e.target.classList.contains('fa-times')) {
    fpFilterResults.classList.remove('scaleUp');
  }
  if (e.target.id == 'activitiesSearch') {
    e.target.value = '';
  }
});



$('#showFilteredTrip').click(function() {
  $.post(templateUrl + "/library/bokun.php?checktrip=true", $("#fpFilter").serialize(), function(data) {
    // console.log(data);
    $.get(templateUrl + '/library/detailedtrips.json', function(wpData) {
      // console.log(wpData);
      var ajData = JSON.parse(data);
      // console.log(ajData);
      if (ajData.length > 0) {
        localStorage.fpResults = ajData[1];
        var tripId = ajData[1].tripId;
        var adults = ajData[1].adult;
        var children = ajData[1].children;
        var infant = ajData[1].infant;
        var dRange = ajData[1].date_range;
        fpFilterResults.classList.add('scaleUp');
        var sHtmlAvailableTrips = '';
        for (var i = 0; i < ajData[0].length; i++) {
          // console.log(ajData[0][i]);

          for (var c = 0; c < wpData.trips.length; c++) {
            var wpTripId = wpData.trips[c].id;
            // console.log(wpTripId);
            var iActId = ajData[0][i].activityId;
            if (wpTripId == iActId) {
              // var postPermaLink = wpData[c].link;
              // console.log(wpData.trips[c]);
              // console.log(ajData[0][i]);
              var activetyId = ajData[0][i].activityId;
              var sActDate = ajData[0][i].localizedDate;
              var sStartTime = ajData[0][i].startTime;
              var sTartTimeId = ajData[0][i].startTimeId;
              var sActiveUnixDate = ajData[0][i].date;
              var sFormatDate = new Date(sActiveUnixDate).toISOString();
              // console.log(sFormatDate);
              var toObjDate = moment(sFormatDate).format("YYYY-MM-DD");
              var boolPickUp = wpData.trips[c].pickupService;
              var priceCat = wpData.trips[c].pricingCategories;
              var aPriceCats = [];
              var aPricWithNames = [];
              for (var p = 0; p < priceCat.length; p++) {
                var priceId = priceCat[p].id;
                var priceType = priceCat[p].ticketCategory
                // aPriceCats.push({
                //   "id": priceId,
                //   "type": priceType
                // });
                switch (priceType) {
                  case "ADULT":
                    var iAdults = Number(adults);
                    for (var a = 0; a < iAdults; a++) {
                      aPriceCats.push({
                        "pricingCategoryId": Number(priceId)
                      });
                      aPricWithNames.push({
                        "pricingCategoryId": Number(priceId),
                        "type": priceType
                      });
                    }
                    break;
                  case "CHILD":
                    var iChild = Number(children);
                    for (var z = 0; z < iChild; z++) {
                      aPriceCats.push({
                        "pricingCategoryId": Number(priceId)
                      });
                      aPricWithNames.push({
                        "pricingCategoryId": Number(priceId),
                        "type": priceType
                      });
                    }
                    break;
                  case "INFANT":
                    var iInfant = Number(infant);
                    for (var b = 0; b < iInfant; b++) {
                      aPriceCats.push({
                        "pricingCategoryId": Number(priceId)
                      });
                      aPricWithNames.push({
                        "pricingCategoryId": Number(priceId),
                        "type": priceType
                      });
                    }
                    break;
                  default:
                }
              }
              // console.log(aPriceCats);

              var costQuery = {
                "activityId": Number(activetyId),
                "startTimeId": Number(sTartTimeId),
                "date": toObjDate,
                "pricingCategoryBookings": aPriceCats,
                "pickup": boolPickUp,
                "pickupPlaceId": null,
                "pickupPlaceRoomNumber": "",
                "extras": [{
                  "extraId": null,
                  "unitCount": null
                }]
              };

              var sCostQuery = JSON.stringify(costQuery);
              var saPricWithNames = JSON.stringify(aPricWithNames);
              // console.log(costQuery);
              sHtmlAvailableTrips += "<button type='button' class='btnTripDate' data-tickettype='" + saPricWithNames + " 'data-cost=' " + sCostQuery + " '> " + sActDate + "  </button>";

              break;
            }
          }
        }
        fpFilteredOptionsContainer.innerHTML = '<h3 class="availableTrips">Available trips</h3>' + sHtmlAvailableTrips;
        // console.log(sHtmlAvailableTrips);
      } else {
        fpFilterResults.classList.add('scaleUp');
        fpFilteredOptionsContainer.innerHTML = '<h3>NO TRIPS FOUND</h3>';
      }
    });
  });
});