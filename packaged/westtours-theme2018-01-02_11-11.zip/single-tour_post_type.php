<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package FoundationPress
 * @since FoundationPress 1.0.0
 */
get_header(); ?>

<div id="single-post" role="main" class="row">

<?php do_action('foundationpress_before_content');
  $filter = $_GET;
  $sDate = $_GET['date'];
  $sBookingdate = date("d. M Y", (int)$sDate/1000);

  $sBookingPriceAdult = (int)$_GET['adulti'];
  $sBookingPriceChild = (int)$_GET['childi'];
  $sBookingPriceInfant = (int)$_GET['infanti'];
  $sBooking = "";
  if ($sBookingPriceAdult <= 1) {
      $sBooking = $sBookingPriceAdult . " Adult";
  } elseif ($sBookingPriceAdult > 1) {
      $sBooking = $sBookingPriceAdult . " Adults";
  }

  if ($sBookingPriceChild <= 1  && $sBookingPriceChild != 0) {
      $sBooking .= ", " . $sBookingPriceChild . " Child";
  } elseif ($sBookingPriceChild > 1 && $sBookingPriceChild != 0) {
      $sBooking .= ", " . $sBookingPriceChild . " Children";
  }

  if ($sBookingPriceInfant <= 1  && $sBookingPriceInfant != 0) {
      $sBooking .= ", " . $sBookingPriceInfant . " Infant";
  } elseif ($sBookingPriceInfant > 1 && $sBookingPriceInfant != 0) {
      $sBooking .= ", " . $sBookingPriceInfant . " Infants";
  }
  $totalPassengers = $sBookingPriceAdult + $sBookingPriceChild + $sBookingPriceInfant;
 ?>

<?php while (have_posts()) : the_post();
  $tourId = get_field('bokun_int_id');
  $bokunImg = get_field('bokun_img');
  $nutrition_image = get_field('img');
  $img = $nutrition_image['sizes']['fp-xlarge'];
  $imgX2 = $nutrition_image['sizes']['hero-img-sizer'];
  $alt = $nutrition_image['alt'];
  $iconImg = '';
    if (get_field('activety')=='sailing') {
        $iconImg = '/assets/images/icons/catIcons/sailing.svg';
    } elseif (get_field('activety')=='food') {
        $iconImg = '/assets/images/icons/catIcons/food.svg';
    } elseif (get_field('activety')=='cycling') {
        $iconImg = '/assets/images/icons/catIcons/cycling.svg';
    } elseif (get_field('activety')=='animal life') {
        $iconImg = '/assets/images/icons/catIcons/animal-life.svg';
    } elseif (get_field('activety')=='hiking') {
        $iconImg = '/assets/images/icons/catIcons/hiking.svg';
    }
    $activetys = get_field('activety');
    // var_dump(gettype($activetys));
    if (gettype($activetys)=="array") {
        $activety = $activetys;
    } elseif (gettype($activetys)=="string") {
        $activety = json_decode($activetys);
    }
    // var_dump(get_field('activety'));
    // $activety_small = get_field('activety');
    if ($activety[0]=='WALKING_TOUR' || $activety[0]=='HIKING') {
        $mainActivety = 'hiking';
        $mainActivetyIcon = $mainActivety;
    } elseif ($activety[0]=='SAILING_OR_BOAT_TOUR' || $activety[0]== 'DOLPHIN_OR_WHALEWATCHING') {
        $mainActivety = 'sailing';
        $mainActivetyIcon = $mainActivety;
    } elseif ($activety[0]=='SAFARI_AND_WILDLIFE' || $activety[0]== 'BIRD_WATCHING') {
        $mainActivety = 'animal life';
        $mainActivetyIcon = 'animal-life';
    } elseif ($activety[0]=='BIKE_TOUR') {
        $mainActivety = 'cycling';
        $mainActivetyIcon = $mainActivety;
    }

    // var_dump($mainActivety);
    $season = get_field('season');

    $date_start = get_field('season-start', false, false);
    $date_start = new DateTime($date_start);
    $season_start = $date_start->format('j/m/Y');

    $date_end = get_field('season-end', false, false);
    $date_end = new DateTime($date_end);
    $season_end = $date_end->format('j/m/Y');

    $date_departure = get_field('departure', false, false);
    // $date_departure = new DateTime($date_departure);
    // $date_departure = $date_departure->format('j/m/Y');

    $number = get_field('cost_per_adult');
    if ($number < 9999) {
        $format_number = number_format($number, 0, ',', '.');
    } elseif ($number >= 10000) {
        $format_number = number_format($number, 0, ',', '.');
    }

    if (!empty(get_field('cost_per_children'))) {
        $number_child = get_field('cost_per_children');
        if ($number_child < 9999) {
            $format_child = number_format($number_child, 3, ',', '.');
        } elseif ($number_child >= 10000) {
            $format_number = number_format($number_child, 0, ',', '.');
        }
    } elseif (!empty(get_field('cost_per_infant'))) {
        $number_infant = get_field('cost_per_infant');
        if ($number_infant < 9999) {
            $format_infant = number_format($number_infant, 3, ',', '.');
        } elseif ($number_infant >= 10000) {
            $format_infant = number_format($number_infant, 3, ',', '.');
        }
    }
    $location = get_field('location');
 ?>

	<article <?php post_class('main-content'); ?> id="post-<?php the_ID(); ?>" data-tourid="<?php echo $tourId; ?>">
		<header>
			<h1 class="entry-title"><?php the_title(); ?></h1>
      <?php if ($filter): ?>
        <div class="totalPrice">
          <span><?php echo number_format($filter['total']/$totalPassengers, 0, ',', '.'); ?> ISK</span>
          <p>avg per person</p>
        </div>

      <?php endif; ?>
		</header>


		<?php do_action('foundationpress_post_before_entry_content'); ?>
		<div class="entry-content">
			<section class="post-image" style="background-image: url(<?php echo $bokunImg ?>);">
				<!-- <img src="<?php echo $bokunImg; ?>" alt=""> -->

        <div class="single-booked">

          <div class="medium-10 medium-offset-1 single-booked-placeholder">
            <form id="spBooking" class="filter-container-post">
              <input id="widget_id" type="hidden" name="tripId" value="<?php echo $tourId; ?>" readonly>
              <div id="activety-autocompleat" class="activities-container">
                <label for="activities-search">Activety</label>
                <button class="filterbutton show-for-small-only" type="button" name="button">What do you like?</button>
                <input id="activetySearchPost" class="search-field hide-for-small-only" type="text" name="tripTitle" value="<?php the_title(); ?>" placeholder="What do you like?" >
                <div id="sResultsDropdown" class="search-field__results">

                </div>
              </div>
              <div class="when-container hide-for-small-only">
                <label for="when">When
                  <input type="text" id="from" name="date_range" class="pickTime" value="<?php if ($sBookingdate) {
     echo $sBookingdate;
 } else {
     echo "";
 } ?>" >
                </label>
                <!-- <input type="text" id="from" class="pickTime" placeholder="Pick a date">
                <input type="text" class="pickTime" id="to" placeholder="Pick a date"> -->
              </div>
              <div class="party-container hide-for-small-only">
                <label for="counter">Participants</label>
                <input id="counter" type="text" placeholder="How many" value="<?php echo $sBooking; ?>" readonly/>
                <div id="counterContainer" class="counterContainer">
                  <label for="adult">
                    <span><input id="txtAdult" type="text" name="adult" value="<?php if ($sBookingPriceAdult) {
     echo $sBookingPriceAdult;
 } else {
     echo 0;
 } ?>" readonly>
                    adult</span>
                    <div>
                      <button class="btnMinus" type="button" name="button"></button><button class="btnPlus" type="button" name="button"></button>
                    </div>
                  </label>
                  <label for="children">
                    <span><input id="txtChild" type="text" name="children" value="<?php if ($sBookingPriceChild) {
     echo $sBookingPriceChild;
 } else {
     echo 0;
 } ?>" readonly>
                    children <span>2 - 14</span></span>

                    <div>
                      <button class="btnMinus" type="button" name="button"></button><button class="btnPlus" type="button" name="button"></button>
                    </div>
                  </label>
                  <label for="infant">
                    <span><input id="txtInfant" type="text" name="infant" value="<?php if ($sBookingPriceInfant) {
     echo $sBookingPriceInfant;
 } else {
     echo 0;
 } ?>" readonly>
                    inftants <span>0 - 2</span></span>
                    <div>
                      <button class="btnMinus" type="button" name="button"></button><button class="btnPlus" type="button" name="button"></button>
                    </div>
                  </label>
                  <button class="btnCloseCount" type="button">ok</button>
                </div>
              </div>
              <div class="button-container hide-for-small-only">
                <button id="bookFilteredTrip" class="btn" type="button" name="button">Book now</button>
              </div>
            </form>
          </div>

        </div>

			</section>
      <div class="activety-icon">
        <img src="<?php echo get_template_directory_uri().'/assets/images/icons/catIcons/'.$mainActivetyIcon.'.svg'; ?>" alt=""/>
        <p class='single-cat'> <?php echo $mainActivety . ' / ' . $season; ?> </p>
      </div>
      <section class="post-paragraph">
        <?php the_content(); ?>

          <?php  if (!empty(get_field('special-anounsment'))) : ?>
            <p class="special-anounsment"><strong><?php the_field('special-anounsment'); ?></strong>  </p>
          <?php endif; ?>
        <ul>
          <li><strong> Season:</strong> <?php echo $season_start.' - '. $season_end;  ?></li>
          <li><strong>Departure:</strong> <?php echo $date_departure; ?></li>
          <li><strong>Duration:</strong> <?php the_field('duration'); ?> hours</li>
          <li><strong>Included:</strong> <?php the_field('included'); ?></li>
          <!-- <li><strong>Minimum:</strong> <?php # the_field('minimum');?></li> -->
          <li><strong>Maximum:</strong> <?php the_field('max_customers'); ?></li>
          <li><strong>Price:</strong> <?php echo $format_number; ?> ISK per person <?php if (!empty(get_field('cost_per_children'))): ?>, <?php echo $format_child; ?><p>ISK per child</p>
          <?php elseif (!empty(get_field('cost_per_infant'))) :?>,
          <?php echo $format_infant;?>
          <p>ISK per infant</p>
          <?php endif; ?></li>
        </ul>

        </section>
        <section class="map-container">
          <h2>Map view</h2>
        </section>
        <section id="theMap" class="acf-map">
          <div class="marker" data-lat="<?php echo $location['lat']; ?>" data-lng="<?php echo $location['lng']; ?>"></div>
        </section>

		</div>
    	<?php edit_post_link(__('Edit', 'foundationpress'), '<span class="edit-link">', '</span>'); ?>


		<footer>

		</footer>
		<?php // the_post_navigation();?>

	</article>
<?php endwhile; wp_reset_query(); ?>



<?php do_action('foundationpress_after_content'); ?>

</div>

<?php $loop = new WP_Query(array( 'post_type' => 'wiki_post_type', 'posts_per_page' => 1, 'orderby' => 'rand' )); $count = mt_rand(1, 2); $color; ?>
<?php while ($loop->have_posts()) : $loop->the_post();
$nutrition_image = get_field('info-img');
$img_info = $nutrition_image['sizes']['info-img-sizer'];
$alt = $nutrition_image['alt'];
 if ($count == 1) {
     $color = 'red';
 } elseif ($count == 2) {
     $color='blue';
 }
 $excerpt = get_field('excerpt');

 if (strlen($excerpt) > 200) {
     $excerptShort = substr($excerpt, 0, 200);
 } else {
     $excerptShort = $excerpt;
 }
?>
<h2 style="text-align: center;">Did you know?</h2>
<section class="fw chapter-parent chapter-single-page">

  <div class="row align-center small-12 medium-12 large-6 chapter-<?php echo $color; ?>">
    <div class="small-10 small-offset-1">
      <h2><?php the_title(); ?></h2>
      <p>
        <?php echo $excerptShort . ' ...'; ?>
      </p>

    </div>
    <a class="chapter-<?php echo $color; ?>-btn" href="<?php echo get_permalink(); ?>">Read More</a>
  </div>

  <div class="small-12 medium-12 large-6 chapter-<?php echo $color; ?>-img" style="background-image:url(<?php echo $img_info ?>);">

  </div>

</section>
<?php endwhile; wp_reset_query(); ?>

<section class="front-smallCards-container smallCards-single">
  <h1>Interesting activeties</h1>

    <div id="cardsPost" class="cards owl-carousel test">
      <?php # echo do_shortcode('[ajax_load_more id="smallCardId" posts_per_page="4" container_type="div" post_type="tour_post_type" scroll_container="#cards" button_label="Show more trips" button_loading_label="Hang on!"]');?>
      <?php
        $args2 = array( 'post_type' => 'tour_post_type' );
        $query_smallCards = new WP_Query($args2);

        if ($query_smallCards->have_posts()): while ($query_smallCards->have_posts()) : $query_smallCards->the_post();
        $tripId = get_field('bokun_id');
        $isPopular = get_field('is_popular');

        $bokunImg = get_field('bokun_img');

        $activety_small = get_field('activety');
        if ($activety_small[0]=='WALKING_TOUR' || $activety_small[0]=='HIKING') {
            $mainActivety = 'hiking';
            $mainActivetyIcon = $mainActivety;
        } elseif ($activety_small[0]=='SAILING_OR_BOAT_TOUR' || $activety_small[0]== 'DOLPHIN_OR_WHALEWATCHING') {
            $mainActivety = 'sailing';
            $mainActivetyIcon = $mainActivety;
        } elseif ($activety_small[0]=='SAFARI_AND_WILDLIFE' || $activety_small[0]== 'BIRD_WATCHING') {
            $mainActivety = 'animal life';
            $mainActivetyIcon = 'animal-life';
        } elseif ($activety_small[0]=='BIKE_TOUR') {
            $mainActivety = 'cycling';
            $mainActivetyIcon = $mainActivety;
        }


        // var_dump($mainActivety);
        $season = get_field('season');
        if ($mainActivety == 'animal life') {
            $mainActivety = 'animal-life';
        } else {
            $mainActivety = $mainActivety;
        }
         if ($isPopular == null) :
          // var_dump($activety_small);

          $title = get_the_title();
          // var_dump(strlen($title));
          if (strlen($title) > 19) {
              $smallerH2 = 'smallerH2';
          } else {
              $smallerH2 = '';
          }
          $excerpt_small = get_the_excerpt();
          $excerpt_small = substr($excerpt_small, 0, 50);
          $cardImg = get_field('info_img');

      ?>
        <div class="small-12 medium-6 large-4 xlarge-3 card-container">
          <div class="card" role="article" >
            <a href="<?php the_permalink(); ?>">
              <?php if (!$cardImg): ?>
              <div class="image" style="background-image:url('<?php echo $bokunImg; ?>');"></div>
              <?php else: ?>
              <div class="image" style="background-image:url('<?php echo $img; ?>');"></div>
              <?php endif; ?>
              <div class="icon icon-<?php echo $mainActivety; ?>" style="background-image:url(<?php echo get_template_directory_uri().'/assets/images/icons/catIcons/'.$mainActivetyIcon.'.svg'; ?>);" ></div>
              <p class="cat-string"> <?php echo str_replace('_', ' ', $mainActivety); ?> / <?php echo $season; ?> </p>
              <header class="card-content article-header">
                <h2 class="entry-title single-title <?php echo $smallerH2; ?>" itemprop="headline"><?php echo $title; ?></h2>
                <p><?php echo $excerpt_small.' ...'; ?></p>
              </header>
              <button href="<?php the_permalink(); ?>" type="button" class="bookBtn btnCard" data-tripid="<?php echo $tripId ?>">Book</button>
            </a>
          </div>
        </div>
      <?php endif; endwhile; endif; wp_reset_query(); ?>
    </div>
    <!-- <button id="btnShowMore" type="button" class="show-more" name="button">Show more trips</button> -->
  </section>



<?php get_footer();
