<section class="e-list hide-for-small-only">
  <h2 >join our Maillist</h2>
  <p>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam et dui id enim consectetur pretium. Duis facilisis efficitur imperdiet. Nulla tincidunt mollis augue, vitae commodo nisi facilisis sit amet. Donec ornare vel sem quis maximus. Phasellus eget lectus nec leo.
  </p>
  <input class="e-mail" type="email" name="email-list" value="" placeholder="Your E-mail">
  <button class="btn" type="button" name="button">Sign up</button>
</section>
