$(window).load(function() {
  // Animate loader off screen
  $("#loader").fadeOut(1000);
});