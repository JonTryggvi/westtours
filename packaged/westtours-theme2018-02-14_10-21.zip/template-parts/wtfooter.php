<div class="wt-footer">
  <div class="wt-footer-smedia">
    <ul class="wt-footer-smedia-list">
      <li class="trip"><a href="#"><img src="<?php echo get_template_directory_uri().'/assets/images/icons/tripadvisor-logotype.svg'; ?>" alt="tripadvisor link icon" /></a></li>
      <li class="facebook"><a href="#"><img src="<?php echo get_template_directory_uri(). '/assets/images/icons/Facebook.svg'; ?>" alt="facebook link icon" /></a></li>
      <li class="twitter"><a href="#"><img src="<?php echo get_template_directory_uri(). '/assets/images/icons/Twitter.svg'; ?>" alt="twitter link icon" /></a></li>
      <li class="Instagram"><a href="#"><img src="<?php echo get_template_directory_uri().'/assets/images/icons/Instagram.svg'; ?>" alt="instagram link icon" /></a></li>
    </ul>
  </div>
  <div class="wt-footer-adress-secton ">
    <!-- medium-12 row align-center -->
    <ul class="wt-footer-contact  ">
      <li class="">Aðalstræti 7</li>
      <li class="">400 Ísafjörður</li>
      <li class=""><a href="tel:+3544565111">Phone: +354 456 5111</a></li>
      <li class=""><a href="mailto:westtours@westtours.is">westtours@westtours.is</a></li>
    </ul>
  </div>
</div>
