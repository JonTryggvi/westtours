<svg width="48px" height="48px" viewBox="0 0 48 48" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs></defs>
  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <g id="Style-Guide" transform="translate(-735.000000, -1102.000000)">
      <g id="Group-9" transform="translate(736.000000, 1103.000000)">
        <g id="Group-7" transform="translate(12.000000, 16.000000)" fill="#56B881">
          <rect id="Rectangle-9-Copy-3" transform="translate(15.035482, 8.035482) rotate(-45.000000) translate(-15.035482, -8.035482) " x="8.33335469" y="6.20214902" width="13.4042553" height="3.66666667"></rect>
          <rect id="Rectangle-9-Copy-5" transform="translate(6.035482, 6.035482) rotate(45.000000) translate(-6.035482, -6.035482) " x="-0.666645311" y="4.20214902" width="13.4042553" height="3.66666667"></rect>
        </g>
        <circle id="Oval-2-Copy" stroke="#56B881" stroke-width="2" cx="23" cy="23" r="23"></circle>
      </g>
    </g>
  </g>
</svg>